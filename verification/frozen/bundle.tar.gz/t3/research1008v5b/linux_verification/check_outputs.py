"""Linux evaluator-only output/gate/reference check, after container exit."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

import pandas as pd
import pyarrow.parquet as pq

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "Agenthon-2026/03_track3_simulation"))
sys.path.insert(0, str(REPO / "Agenthon-2026/00_shared_toolkit/common"))
from qfbench2_track_simulation.scoring import build_developer_verifier


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--unit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if args.receipt.exists():
        raise ValueError("immutable output receipt exists")
    batch = (args.unit / "batch.json").exists()
    subs = sorted(p.stem for p in (args.unit / "scenarios").glob("*.json") if not p.name.startswith("._")) if batch else []
    expected = {f"{sub}/{name}" for sub in subs for name in ("trace.parquet", "message_trace.parquet")} if batch else {"trace.parquet", "message_trace.parquet"}
    paths = [p for p in sorted(args.output.rglob("*.parquet")) if not p.name.startswith("._")]
    actual = {p.relative_to(args.output).as_posix() for p in paths}
    assert expected and actual == expected, {"expected": sorted(expected), "actual": sorted(actual)}
    frames, digests, counts = [], {}, {}
    for path in paths:
        if path.name.startswith("._"):
            continue
        relative = path.relative_to(args.output)
        reference = args.unit / "checks/reference_data" / relative
        if not reference.exists():
            reference = args.unit / relative
        if not reference.exists():
            reference = args.unit / "checks" / relative
        pd.testing.assert_frame_equal(pd.read_parquet(reference), pd.read_parquet(path), check_exact=True)
        frames.append(str(relative))
        digests[str(relative)] = hashlib.sha256(path.read_bytes()).hexdigest()
        if path.name == "trace.parquet":
            counts[str(relative)] = pq.ParquetFile(path).metadata.num_rows
    metadata = json.loads((args.output / ("batch_events.json" if batch else "events.json")).read_text())
    count = sum(counts.values())
    assert count == metadata["total_events" if batch else "n_events"]
    if batch:
        subs = {str(Path(relative).parent): count for relative, count in counts.items()}
        assert subs == {row["sub"]: row["n_events"] for row in metadata["per_scenario"]}
    context = {"unit_dir": str(args.unit), "output_dir": str(args.output)}
    verdict = asdict(build_developer_verifier(context).run(context))
    assert verdict["admissible"], verdict
    report = {"rankable": False, "all_reference_frames_exact": True,
              "frames": frames, "parquet_sha256": digests, "footer_event_count": count,
              "developer_admissible": True, "gate_verdict": verdict,
              "limits": "Evaluator-only unchanged developer gates; no signed C1/C2/C7 or official telemetry."}
    args.receipt.write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key not in ("parquet_sha256", "gate_verdict", "frames")}))


if __name__ == "__main__":
    main()
