"""Offline Linux-only source-mount verification; never pulls/publishes an image."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import statistics
import subprocess
import sys
import threading
import time

HERE = Path(__file__).resolve().parent
ROUND = HERE.parent
REPO = HERE.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def verify():
    protocol = json.loads((HERE / "PROTOCOL.json").read_text())
    freeze = json.loads((HERE / "FREEZE.json").read_text())
    assert sha(HERE / "PROTOCOL.json") == freeze["protocol_sha256"]
    for relative, digest in freeze["files"].items():
        assert sha(REPO / relative) == digest, relative
    return protocol


def capture(command):
    return subprocess.run(command, check=True, capture_output=True, text=True).stdout


def process_run(protocol, evaluator, image, cpus, runtime, out, unit, variant):
    source = ROUND / ("baseline" if variant == "v3" else "runtime")
    scenario = REPO / "t3/evaluation_references" / unit
    out.mkdir(parents=True)
    out.chmod(0o777)
    batch = (scenario / "batch.json").exists()
    name = "t3verify-" + hashlib.sha256(str(out).encode()).hexdigest()[:24]
    input_path = scenario / "scenarios" if batch else scenario / "scenario.json"
    input_mount = "/input/scenarios" if batch else "/input/scenario.json"
    args = ["simulate-batch", "--batch-dir", input_mount, "--out-dir", "/output"] if batch else ["simulate", "--config", input_mount, "--out", "/output/trace.parquet"]
    command = ["docker", "create", "--pull", "never", "--name", name, "--runtime", runtime,
               "--network", "none", "--read-only", "--user", "65534:65534",
               "--cpuset-cpus", cpus, "--memory", "16g", "--memory-swap", "16g",
               "--pids-limit", "256", "--ulimit", "nofile=1024:1024",
               "--ulimit", "nproc=256:256", "--cap-drop", "ALL",
               "--security-opt", "no-new-privileges",
               "--env", "OPENBLAS_NUM_THREADS=1", "--env", "OMP_NUM_THREADS=1",
               "--env", "MKL_NUM_THREADS=1", "--env", "NUMEXPR_NUM_THREADS=1",
               "--env", "PYTHONDONTWRITEBYTECODE=1", "--env", "PYTHONHASHSEED=0",
               "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m",
               "--mount", f"type=bind,src={source},dst=/opt/t3,readonly",
               "--mount", f"type=bind,src={input_path},dst={input_mount},readonly",
               "--mount", f"type=bind,src={out},dst=/output",
               image, *args]
    start = time.perf_counter()
    identifier = capture(command).strip()
    stop = threading.Event()
    telemetry = []

    def sample():
        cgroup = None
        while not stop.is_set():
            if cgroup is None:
                try:
                    pid = int(capture(["docker", "inspect", "--format", "{{.State.Pid}}", identifier]).strip())
                    if pid:
                        relative = next(line.split("::", 1)[1] for line in Path(f"/proc/{pid}/cgroup").read_text().splitlines() if line.startswith("0::"))
                        cgroup = Path("/sys/fs/cgroup") / relative.lstrip("/")
                except (ValueError, OSError, subprocess.CalledProcessError, StopIteration):
                    pass
            if cgroup is not None:
                try:
                    row = {"elapsed_sec": time.perf_counter() - start,
                           "memory_current_bytes": int((cgroup / "memory.current").read_text()),
                           "memory_peak_bytes": int((cgroup / "memory.peak").read_text()),
                           "cpu_stat": (cgroup / "cpu.stat").read_text(), "cgroup": str(cgroup)}
                    telemetry.append(row)
                except OSError:
                    pass
            stop.wait(.05)

    thread = threading.Thread(target=sample, daemon=True)
    thread.start()
    launch = None
    failure = None
    state = {}
    wall = None
    cleanup = []
    try:
        launch = subprocess.run(["docker", "start", "--attach", identifier], capture_output=True, text=True, timeout=protocol["timeout_sec"])
        wall = time.perf_counter() - start
        (out / "process.log").write_text(launch.stdout + "\n" + launch.stderr)
    except BaseException as exc:
        wall = time.perf_counter() - start
        failure = exc
        def decode(value):
            return value.decode(errors="replace") if isinstance(value, bytes) else (value or "")
        (out / "process.log").write_text(decode(getattr(exc, "stdout", "")) + "\n" + decode(getattr(exc, "stderr", "")))
        (out / "failure.json").write_text(json.dumps({"type": type(exc).__name__, "reason": str(exc), "host_wall_sec": wall, "no_replacement_run": True}, indent=2) + "\n")
    finally:
        stop.set()
        thread.join(timeout=30)
        try:
            state = json.loads(capture(["docker", "inspect", identifier]))[0]["State"]
            (out / "container_state.json").write_text(json.dumps(state, indent=2) + "\n")
            if state.get("Running"):
                stopped = subprocess.run(["docker", "stop", "--time", "5", identifier], capture_output=True, text=True, timeout=15)
                cleanup.append({"action": "stop", "returncode": stopped.returncode, "stderr": stopped.stderr})
                state_after = json.loads(capture(["docker", "inspect", identifier]))[0]["State"]
                if state_after.get("Running"):
                    killed = subprocess.run(["docker", "kill", identifier], capture_output=True, text=True, timeout=15)
                    cleanup.append({"action": "kill", "returncode": killed.returncode, "stderr": killed.stderr})
            logs = subprocess.run(["docker", "logs", identifier], capture_output=True, text=True, timeout=15)
            (out / "container.log").write_text(logs.stdout + "\n" + logs.stderr)
            removed = subprocess.run(["docker", "rm", "--force", identifier], capture_output=True, text=True, timeout=15)
            cleanup.append({"action": "rm_own_ephemeral_container", "returncode": removed.returncode, "stderr": removed.stderr})
        except BaseException as exc:
            cleanup.append({"cleanup_error": type(exc).__name__, "reason": str(exc), "container_id": identifier})
            # Only the identifier returned by this run's docker create is eligible.
            try:
                removed = subprocess.run(["docker", "rm", "--force", identifier], capture_output=True, text=True, timeout=15)
                cleanup.append({"action": "rm_own_ephemeral_container_after_cleanup_error", "returncode": removed.returncode, "stderr": removed.stderr})
            except BaseException as final_error:
                cleanup.append({"cleanup_unresolved": str(final_error), "container_id": identifier})
            if failure is None:
                failure = exc
        (out / "cleanup.json").write_text(json.dumps(cleanup, indent=2) + "\n")
        (out / "cgroup_samples.json").write_text(json.dumps(telemetry, indent=2) + "\n")
    if failure is not None:
        raise RuntimeError("container run/cleanup failure; evidence preserved, no replacement run") from failure
    assert launch is not None
    if launch.returncode or state["ExitCode"] or state["OOMKilled"]:
        raise RuntimeError("container failure; preserve evidence, no repeated run")
    if not telemetry:
        raise RuntimeError("host cgroup-v2 telemetry absent; preserve evidence and stop")
    receipt = out / "evaluator.json"
    subprocess.run([evaluator, str(HERE / "check_outputs.py"), "--unit", str(scenario),
                    "--output", str(out), "--receipt", str(receipt)], check=True, capture_output=True, text=True)
    evaluated = json.loads(receipt.read_text())
    return {"variant": variant, "unit": unit, "host_wall_sec": wall,
            "footer_event_count": evaluated["footer_event_count"],
            "host_events_per_sec": evaluated["footer_event_count"] / wall,
            "parquet_sha256": evaluated["parquet_sha256"],
            "host_cgroup_peak_bytes": max(row["memory_peak_bytes"] for row in telemetry),
            "reference_frames": len(evaluated["frames"]), "developer_admissible": True,
            "all_reference_frames_exact": True, "telemetry_samples": len(telemetry)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("preflight", "correctness", "timing"))
    parser.add_argument("--evaluator-python")
    parser.add_argument("--cpuset-cpus")
    parser.add_argument("--runtime", choices=("runc", "runsc"), default="runc")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    protocol = verify()
    if args.mode == "preflight":
        print(json.dumps({"frozen_bytes_exact": True, "execution": False, "protocol_sha256": sha(HERE / "PROTOCOL.json")}))
        return
    if sys.platform != "linux" or platform.machine() != "x86_64":
        raise RuntimeError("actual Linux/amd64 host required; no Mac or architecture emulation")
    if not args.evaluator_python or not args.cpuset_cpus or not args.out:
        parser.error("Linux run requires existing evaluator Python, exclusive frozen CPU set and fresh output directory")
    if args.out.exists():
        raise ValueError("immutable output directory already exists")
    if args.out.resolve().is_relative_to((ROUND / "runtime").resolve()) or args.out.resolve().is_relative_to((ROUND / "baseline").resolve()):
        raise ValueError("evaluation cannot write into runtime sources")
    image = protocol["existing_image"]
    inspect = json.loads(capture(["docker", "image", "inspect", image]))[0]
    assert inspect["Architecture"] == "amd64" and inspect["Os"] == "linux"
    versions = json.loads(capture(["docker", "run", "--pull", "never", "--rm", "--network", "none", "--read-only", "--user", "65534:65534",
        "--entrypoint", "/usr/local/bin/python", image, "-c",
        "import json,sys,numpy,pandas,scipy,pyarrow;print(json.dumps(dict(python=sys.version.split()[0],numpy=numpy.__version__,pandas=pandas.__version__,scipy=scipy.__version__,pyarrow=pyarrow.__version__)))"]))
    assert versions == protocol["runtime_versions"], versions
    args.out.mkdir(parents=True)
    environment = {"host": platform.platform(), "machine": platform.machine(),
        "docker_version": capture(["docker", "version", "--format", "{{json .}}"]),
        "cpu_set": args.cpuset_cpus, "runtime": args.runtime, "image": image,
        "image_id": inspect["Id"], "versions": versions, "evaluator_python": args.evaluator_python,
        "protocol_sha256": sha(HERE / "PROTOCOL.json"), "freeze_sha256": sha(HERE / "FREEZE.json"),
        "created_before_cohort": True, "rankable": False, "source_bind_mount": True}
    (args.out / "ENVIRONMENT.json").write_text(json.dumps(environment, indent=2) + "\n")
    units = protocol["correctness_units"] if args.mode == "correctness" else protocol["timing_units"]
    plan = {"warmup_pairs": 0, "measured_pairs": 1} if args.mode == "correctness" else protocol["timing"]
    records = []
    for ui, unit in enumerate(units):
        for pair in range(-plan["warmup_pairs"], plan["measured_pairs"]):
            order = ("v3", "v5b") if (ui + pair) % 2 == 0 else ("v5b", "v3")
            for variant in order:
                verify()
                row = process_run(protocol, args.evaluator_python, image, args.cpuset_cpus, args.runtime,
                    args.out / variant / str(pair) / unit, unit, variant)
                row.update(pair=pair, phase="warmup" if pair < 0 else "measured")
                records.append(row)
                (args.out / "raw_runs.json").write_text(json.dumps(records, indent=2) + "\n")
                print(unit, pair, variant, row["host_events_per_sec"], flush=True)
                group = [record for record in records if record["unit"] == unit]
                assert all(record["parquet_sha256"] == group[0]["parquet_sha256"] and record["footer_event_count"] == group[0]["footer_event_count"] for record in group)
    summary = []
    for unit in units:
        group = [row for row in records if row["unit"] == unit and row["phase"] == "measured"]
        base = {row["pair"]: row for row in group if row["variant"] == "v3"}
        own = {row["pair"]: row for row in group if row["variant"] == "v5b"}
        ratios = [base[pair]["host_wall_sec"] / own[pair]["host_wall_sec"] for pair in sorted(base)]
        summary.append({"unit": unit, "paired_ratios": ratios,
                        "paired_median_speed_ratio": statistics.median(ratios),
                        "geomean_speed_ratio": math.exp(statistics.mean(map(math.log, ratios))),
                        "median_cgroup_peak_ratio": statistics.median(row["host_cgroup_peak_bytes"] for row in own.values()) / statistics.median(row["host_cgroup_peak_bytes"] for row in base.values())})
    report = {"rankable": False, "mode": args.mode, "processes": len(records), "units": summary,
              "all_output_bytes_counts_reference_frames_and_developer_gates_exact": True}
    if args.mode == "timing":
        rng = random.Random(protocol["bootstrap"]["seed"])
        draws = []
        for _ in range(protocol["bootstrap"]["draws"]):
            selected = [rng.choice(summary) for _ in summary]
            draws.append(math.exp(statistics.mean(statistics.mean(math.log(rng.choice(row["paired_ratios"])) for _ in row["paired_ratios"]) for row in selected)))
        draws.sort()
        ci = [draws[int(q * len(draws)) - 1] for q in (.025, .975)]
        report.update(macro_geomean_speed_ratio=math.exp(statistics.mean(math.log(row["geomean_speed_ratio"]) for row in summary)), descriptive_ci95=ci,
            timing_admission=ci[0] > 1 and sum(row["paired_median_speed_ratio"] >= 1 for row in summary) >= 8 and all(row["paired_median_speed_ratio"] >= .97 and row["median_cgroup_peak_ratio"] <= 1.05 for row in summary))
    (args.out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "units"}, indent=2))


if __name__ == "__main__":
    main()
