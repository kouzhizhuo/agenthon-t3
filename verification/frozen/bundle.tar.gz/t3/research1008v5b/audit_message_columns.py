"""Differential typed message-ledger controls against immutable v3 extraction."""
import argparse,copy,hashlib,importlib.util,json,random,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--runtime',default=str(HERE/'runtime'));args=parser.parse_args()
if sys.version_info[:2]==(3,9):sys.path.insert(0,str(HERE.parent/'.runtime'))
sys.path.insert(0,args.runtime)
from bootstrap import activate
activate()
import numpy as np,pandas as pd
from abides_fork import trace
spec=importlib.util.spec_from_file_location('independent_original_message_trace',HERE/'baseline/abides_fork/trace.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)

def row(mid=1,dst=2):
 return {'message_id':mid,'src_id':1,'dst_id':dst,'t_send_ns':1600000000000000000,'t_recv_ns':1600000000000000013,'latency_ns':13,'msg_type':'LIMIT_ORDER','order_id':17,'causal_parent':11}

def check(state):
 outcomes=[]
 for module in (old,trace):
  try:outcomes.append(('frame',module.extract_message_trace(copy.deepcopy(state))))
  except Exception as exc:outcomes.append(('error',type(exc).__name__))
 assert outcomes[0][0]==outcomes[1][0],outcomes
 if outcomes[0][0]=='error':assert outcomes[0][1]==outcomes[1][1],outcomes
 else:pd.testing.assert_frame_equal(outcomes[0][1],outcomes[1][1],check_exact=True)

cases=0
for state in [{},{'message_ledger':[]},{'message_ledger':[row()],'deliver_seq_by_key':{}},
 {'message_ledger':[row(1,2),row(1,3),row(2,2)],'deliver_seq_by_key':{(1,2):3,(1,3):2}}]:
 check(state);cases+=1
# Exact int64 boundaries and nullable values must not round via float inference.
for name in ['t_recv_ns','t_send_ns','latency_ns','src_id','dst_id','message_id','order_id','causal_parent']:
 for value in [None,True,False,-1,0,np.int32(12),np.int64(13),-(1<<63),(1<<63)-1,1<<63,-(1<<63)-1,1<<31,1.0,np.float64(3.),'17',pd.NA,float('nan')]:
  r=row();r[name]=value
  try:key=(int(r['message_id']),int(r['dst_id']))
  except Exception:key=(1,2)
  check({'message_ledger':[r],'deliver_seq_by_key':{key:0}});cases+=1
for value in [None,True,1,2.0,'LIMIT_ORDER','',pd.NA]:
 r=row();r['msg_type']=value;check({'message_ledger':[r],'deliver_seq_by_key':{(1,2):0}});cases+=1
for value in [None,True,False,np.int32(1),np.int64(2),1.5,'2',-1,(1<<63)-1,1<<63]:
 check({'message_ledger':[row()],'deliver_seq_by_key':{(1,2):value}});cases+=1
for name in row():
 r=row();del r[name];check({'message_ledger':[r],'deliver_seq_by_key':{(1,2):0}});cases+=1
# Stable equal-sequence order, broadcasts, null roots, shuffled ledgers and sends
# after stop_time; no filtering or reordering other than original sort.
rng=random.Random(730108)
for case in range(400):
 ledger=[];seq={}
 for i in range(case%53+1):
  r=row(i//3,i%3);r['t_send_ns']=None if i%5==0 else 1600000000000000000+i
  r['t_recv_ns']=1600000000000000013+i;r['causal_parent']=None if i%7==0 else i-1
  r['order_id']=None if i%4==0 else i;r['src_id']=np.int32(i%3);r['latency_ns']=np.int64(13)
  ledger.append(r)
  if i%11:seq[(r['message_id'],r['dst_id'])]=i//2
 rng.shuffle(ledger);check({'message_ledger':ledger,'deliver_seq_by_key':seq});cases+=1
report={'passed':True,'cases':cases,'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,
 'source_sha256':hashlib.sha256((Path(args.runtime)/'abides_fork/trace.py').read_bytes()).hexdigest(),
 'baseline_sha256':hashlib.sha256((HERE/'baseline/abides_fork/trace.py').read_bytes()).hexdigest(),
 'scope':'exact frame values/dtypes/index/order and fallback error classes; no forecast/timing'}
(HERE/('controls_py'+str(sys.version_info.major)+str(sys.version_info.minor)+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
