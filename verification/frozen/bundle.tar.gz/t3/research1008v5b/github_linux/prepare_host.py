"""Untimed public-reference acquisition and explicit VM preflight for frozen harness."""
import argparse,hashlib,json,os,platform,subprocess,sys,tarfile,urllib.request
from pathlib import Path
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def memory():
 return {line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.split(':')[0] in ('MemTotal','MemAvailable')}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
 if sys.platform!='linux' or platform.machine()!='x86_64':raise ValueError('actual Linuxamd64 required')
 mem=memory()
 if mem['MemTotal']<12*1024**3 or mem['MemAvailable']<4*1024**3:raise ValueError('VMRAM below frozen GitHubenvironment guard')
 if not Path('/sys/fs/cgroup/cgroup.controllers').exists():raise ValueError('readable cgroupv2 required')
 cpus=sorted(os.sched_getaffinity(0));assert cpus
 cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text().strip() if Path('/sys/fs/cgroup/cpu.max').exists() else 'unknown'
 if cpu_max.split()[0]!='max':raise ValueError('host cgroupCPUquota imposed')
 (args.out/'HOST_PREFLIGHT.json').write_text(json.dumps({'rankable':False,'host':platform.platform(),'machine':platform.machine(),'memory':mem,'cpuset':','.join(map(str,cpus)),'cpu_max':cpu_max,'lscpu':subprocess.run(['lscpu'],capture_output=True,text=True,check=True).stdout,'physicalhostexclusive_certified':False},indent=2)+'\n')
 (args.out/'cpuset.txt').write_text(','.join(map(str,cpus))+'\n')
 refs=json.loads((HERE/'PUBLIC_REFERENCE_MANIFEST.json').read_text());archive=args.out/'public-organizer.tar.gz'
 request=urllib.request.Request(refs['archive_url'],headers={'User-Agent':'t3-frozen-evaluator'})
 with urllib.request.urlopen(request,timeout=120) as response:archive.write_bytes(response.read())
 acquisition={'url':refs['archive_url'],'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'files':[]}
 with tarfile.open(archive,'r:gz') as tar:
  prefix='track3-simulation-public-'+refs['commit']+'/units/'
  members={m.name:m for m in tar.getmembers()}
  for rel,row in refs['files'].items():
   name=prefix+row['organizer_relative'];member=members[name]
   if not member.isfile():raise ValueError('nonregular reference member')
   data=tar.extractfile(member).read()
   if row['git_lfs']:
    if not data.startswith(b'version https://git-lfs.github.com/spec/v1') or ('oid sha256:'+row['sha256']).encode() not in data:raise ValueError('unexpected LFS pointer')
    request=urllib.request.Request(row['url'],headers={'User-Agent':'t3-frozen-evaluator'})
    with urllib.request.urlopen(request,timeout=120) as response:data=response.read()
   if len(data)!=row['bytes']:raise ValueError('frozenreferencebytesize mismatch:'+rel)
   if hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('frozen publicreference mismatch:'+rel)
   path=REPO/rel;path.parent.mkdir(parents=True,exist_ok=True)
   if path.exists():raise ValueError('refuseoverwrite frozenreference')
   path.write_bytes(data);acquisition['files'].append({'path':rel,'sha256':row['sha256']})
   (args.out/'REFERENCE_ACQUISITION_IN_PROGRESS.json').write_text(json.dumps(acquisition,indent=2)+'\n')
 (args.out/'REFERENCE_ACQUISITION.json').write_text(json.dumps(acquisition,indent=2)+'\n')
 print(json.dumps({'reference_files':len(acquisition['files']),'cpuset':cpus,'memory':mem}))
if __name__=='__main__':main()
