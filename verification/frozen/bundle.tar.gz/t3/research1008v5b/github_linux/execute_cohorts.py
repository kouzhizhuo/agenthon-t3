"""Dedicated VM orchestration; preserves original run.py and stops on host-health failures."""
import argparse,hashlib,json,os,subprocess,sys,threading,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROUND=HERE.parent;REPO=HERE.parents[2]
def available():
 return next(int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
 args.out.mkdir(parents=True,exist_ok=True);cpus=(args.out/'cpuset.txt').read_text().strip();stop=threading.Event();samples=[];low=threading.Event()
 def monitor():
  while not stop.is_set():
   row={'wall_time':time.time(),'MemAvailable':available(),'proc_stat_cpu':Path('/proc/stat').read_text().splitlines()[0]};samples.append(row)
   if row['MemAvailable']<4*1024**3:low.set()
   stop.wait(.5)
 worker=threading.Thread(target=monitor,daemon=True);worker.start();proc=None
 try:
  for mode in ('correctness','timing'):
   if low.is_set():raise RuntimeError('hostMemAvailableguard failed beforecohort')
   cmd=[sys.executable,str(ROUND/'linux_verification/run.py'),mode,'--evaluator-python',sys.executable,'--cpuset-cpus',cpus,'--runtime','runc','--out',str(args.out/mode)]
   with (args.out/(mode+'.log')).open('w') as log:
    proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    while proc.poll() is None:
     if low.is_set():
      import signal
      os.killpg(proc.pid,signal.SIGINT)
      try:proc.wait(timeout=45)
      except subprocess.TimeoutExpired:
       os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=45)
      raise RuntimeError('hostmemoryguard failed; originalrun cleanup triggered; no replacement')
     time.sleep(.5)
    if proc.returncode:raise RuntimeError('frozencohort failed; preservepartialevidence')
   report=json.loads((args.out/mode/'summary.json').read_text())
   expected=142 if mode=='correctness' else 120
   if report['processes']!=expected:raise RuntimeError('incompletefrozencohort')
   for cgroup_file in (args.out/mode).rglob('cgroup_samples.json'):
    for row in json.loads(cgroup_file.read_text()):
     stats=dict(line.split() for line in row['cpu_stat'].splitlines())
     if int(stats.get('nr_throttled',0)) or int(stats.get('throttled_usec',0)):raise RuntimeError('observedcgroupCPUthrottling invalidatesdedicatedVMtiming')
  result={'rankable':False,'correctness_and_timing_completed':True,'actual313_controls':json.loads((args.out/'controls313/controls_py313.json').read_text()),'actual311_controls':json.loads((args.out/'controls311/controls_py311.json').read_text())}
  c=json.loads((args.out/'correctness/summary.json').read_text());t=json.loads((args.out/'timing/summary.json').read_text());result['correctness_summary']=c;result['timing_summary']=t
  result['combined_admission']=c['processes']==142 and t['processes']==120 and c['all_output_bytes_counts_reference_frames_and_developer_gates_exact'] and t.get('timing_admission',False) and result['actual313_controls']['passed'] and result['actual311_controls']['passed']
  (args.out/'COMBINED_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
 finally:
  stop.set();worker.join(timeout=10);(args.out/'HOST_MEMORY_SAMPLES.json').write_text(json.dumps(samples,indent=2)+'\n')
if __name__=='__main__':main()
