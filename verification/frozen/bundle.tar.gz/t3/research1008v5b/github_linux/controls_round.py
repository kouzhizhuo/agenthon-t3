"""Create an evaluator-only writable audit round from exact frozen old/new sources."""
import argparse,hashlib,json,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROUND=HERE.parent
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
if args.out.exists():raise ValueError('immutableauditroundexists')
args.out.mkdir(parents=True)
for branch in ('baseline','runtime'):
 (args.out/branch/'abides_fork').mkdir(parents=True)
 shutil.copy2(ROUND/branch/'abides_fork/trace.py',args.out/branch/'abides_fork/trace.py')
shutil.copy2(ROUND/'audit_message_columns.py',args.out/'audit_message_columns.py')
(args.out/'bootstrap.py').write_text('def activate(): pass\n')
(args.out/'CONTROL_SOURCE_RECEIPT.json').write_text(json.dumps({'rankable':False,'source_sha256':{str(p.relative_to(args.out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in args.out.rglob('*.py') if not p.name.startswith('._')},'runtime_mount_readonly':True},indent=2)+'\n')
