"""Compile only explicitly declared genuine extensions once in Linux CPython."""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import sysconfig
from common import sha, write


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    import Cython
    from setuptools import Extension, setup
    from Cython.Build import cythonize
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64") or platform.python_version() != "3.11.17" or Cython.__version__ != "3.1.3":
        raise ValueError("Linux amd64 CPython3.11.17 Cython3.1.3 required")
    spec = json.loads((root / "ARM.json").read_text())
    extensions = spec["native"]
    if not extensions:
        raise ValueError("source-only arms must not enter compiler stage")
    os.chdir(root)
    rows = []
    for item in extensions:
        source = root / item["source"]
        if sha(source) != item["sha256"]:
            raise ValueError("native input source differs")
        setup(name="t3-screen-" + spec["name"], ext_modules=cythonize([
            Extension(item["module"], [str(source)], extra_compile_args=["-O2", "-fno-fast-math", "-ffp-contract=off"])],
            compiler_directives={"language_level": 3, "annotation_typing": False, "infer_types": False, "binding": True},
            build_dir="generated"), script_args=["build_ext", "--inplace", "--build-temp", "objects"])
        target = root / (item["module"] + sysconfig.get_config_var("EXT_SUFFIX"))
        if not target.is_file():
            raise ValueError("exact native output missing")
        installed = root / item["install_dir"] / target.name
        shutil.copyfile(target, installed)
        rows.append({"module": item["module"], "source": item["source"], "source_sha256": sha(source),
                     "extension": installed.relative_to(root).as_posix(), "extension_sha256": sha(installed),
                     "bytes": installed.stat().st_size})
    write(root / "NATIVE_BUILD_RECEIPT.json", {"schema": "t3-screen-native-build-v1", "python": sys.version,
        "cython": Cython.__version__, "platform": platform.platform(), "ext_suffix": sysconfig.get_config_var("EXT_SUFFIX"),
        "compile_flags": ["-O2", "-fno-fast-math", "-ffp-contract=off"], "modules": rows,
        "simulation_executed": False, "generic_modules_compiled": 0})


if __name__ == "__main__":
    main()
