"""Freeze reviewed source and PASS receipts; this command does not run experiments."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import BASE, MAX_BYTES, MAX_FILES, SMOKE, STRESS, UNITS, get_field, inventory, safe_name, sha, write

HERE = Path(__file__).resolve().parent
COMPLETION = HERE.parent
MODULES = {
    "abides_core.agent": "vendor/abides/abides-core/abides_core/agent.py",
    "abides_core.kernel": "vendor/abides/abides-core/abides_core/kernel.py",
    "abides_core.abides": "vendor/abides/abides-core/abides_core/abides.py",
    "abides_core.message": "vendor/abides/abides-core/abides_core/message.py",
    "abides_core.latency_model": "vendor/abides/abides-core/abides_core/latency_model.py",
    "abides_core.utils": "vendor/abides/abides-core/abides_core/utils.py",
    "abides_fork.agents": "abides_fork/agents.py", "abides_fork.config": "abides_fork/config.py",
    "abides_fork.trace": "abides_fork/trace.py", "abides_fork.simulate": "abides_fork/simulate.py",
    "abides_markets.agents.exchange_agent": "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py",
    "abides_markets.agents.trading_agent": "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py",
    "abides_markets.agents.financial_agent": "vendor/abides/abides-markets/abides_markets/agents/financial_agent.py",
    "abides_markets.utils": "vendor/abides/abides-markets/abides_markets/utils/__init__.py",
    "abides_markets.orders": "vendor/abides/abides-markets/abides_markets/orders.py",
    "abides_markets.order_book": "vendor/abides/abides-markets/abides_markets/order_book.py",
    "abides_markets.price_level": "vendor/abides/abides-markets/abides_markets/price_level.py",
    "optimizations": "optimizations.py", "t3_canonical_engine": "t3_canonical_engine.py",
    "column_trace": "column_trace.py", "contracts": "contracts.py"}


def standard_recipes():
    return [
        {"name": "canonical", "root": str(COMPLETION), "runtime": "runtime", "entrypoint": "runtime/agent.py",
         "entry_module_name": "agent", "no_run_patch": True, "no_enabled_patch": True,
         "runtime_manifest": "RUNTIME_MANIFEST.json", "manifest_paths_have_runtime": True,
         "receipts": [], "extra_files": [], "native": [], "extra_modules": {}},
        {"name": "mixed_static_v2", "root": str(COMPLETION / "candidates/mixed_static_v2"), "runtime": "runtime",
         "entry_module_name": "agent", "no_run_patch": True, "no_enabled_patch": True,
         "entrypoint": "runtime/agent.py", "runtime_manifest": "SNAPSHOT_MANIFEST.json", "extra_files": [], "native": [], "extra_modules": {},
         "receipts": [{"path": "CONTROLS_RESULT.json", "pass_field": "all_passed"},
                      {"path": str(COMPLETION / "verification/mixed_static_semantic_v2/RESULT.json"), "pass_field": "all_passed"}]},
        {"name": "observer_mixed_v2_authcache", "root": str(COMPLETION / "candidates/observer_mixed_v2_authcache"), "runtime": "runtime",
         "entry_module_name": "agent", "no_run_patch": True, "no_enabled_patch": True,
         "entrypoint": "runtime/agent.py", "runtime_manifest": "SNAPSHOT_MANIFEST.json", "extra_files": [], "native": [],
         "extra_modules": {"observer": "runtime/observer.py", "observer_domain": "runtime/observer_domain.py"},
         "observer_probe": True,
         "binding_aliases": {"abides_fork.trace:extract_trace#0": "abides_fork.trace:_extract_trace_observer_original", "abides_fork.trace:extract_trace#1": "abides_fork.trace:extract_trace"},
         "bound_source_artifacts": {"manifest_sha256": "SNAPSHOT_MANIFEST.json", "snapshot_manifest_sha256": "SNAPSHOT_MANIFEST.json",
                                    "patch_manifest_sha256": "PATCH_MANIFEST.json", "source_diff_sha256": "SOURCE_DIFF.patch", "source_readiness_sha256": "SOURCE_READINESS.json"},
         "require_candidate_runtime_inventory": True,
         "required_source_artifact_groups": [["manifest_sha256", "snapshot_manifest_sha256"], ["patch_manifest_sha256"], ["source_diff_sha256"], ["source_readiness_sha256"]],
         "receipts": [{"path": "CORRECTNESS_EVIDENCE.json", "pass_field": "all_passed",
                       "required_fields": {"sources_unchanged": True}}]},
        {"name": "book_metric_online_v1", "root": str(COMPLETION / "candidates/book_metric_online_v1"), "runtime": "runtime",
         "entrypoint": "runtime/agent.py", "entry_module_name": "agent", "runtime_manifest": "SNAPSHOT_MANIFEST.json",
         "extra_files": [], "native": [],
         "extra_modules": {"online_domain": "runtime/online_domain.py", "online_metric": "runtime/online_metric.py"},
         "no_run_patch": True, "no_enabled_patch": True, "online_probe": True, "online_expect_admitted": True,
         "bound_source_artifacts": {"snapshot_manifest_sha256": "SNAPSHOT_MANIFEST.json", "source_diff_sha256": "SOURCE_DIFF.patch",
                                    "source_readiness_sha256": "SOURCE_READINESS.json"},
         "require_candidate_runtime_inventory": True,
         "required_source_artifact_groups": [["snapshot_manifest_sha256"], ["source_diff_sha256"], ["source_readiness_sha256"]],
         "receipts": [{"path": "CORRECTNESS_EVIDENCE.json", "pass_field": "all_passed",
                       "required_fields": {"sources_unchanged": True, "status": "passed_untimed_finite_admission_and_four_market_controls"}}]},
    ]


def copy_source(source, target):
    if source.is_symlink() or not source.is_file():
        raise ValueError("ordinary source file required: " + str(source))
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def freeze_arm(recipe, destination):
    root = Path(recipe["root"]).resolve()
    runtime_relative = safe_name(recipe["runtime"])
    runtime = root / runtime_relative
    if not recipe.get("receipts") and recipe["name"] != "canonical":
        raise ValueError("candidate lacks final PASS receipts: " + recipe["name"])
    receipt_rows = []
    for index, item in enumerate(recipe["receipts"]):
        path = Path(item["path"])
        if not path.is_absolute():
            path = root / path
        data = json.loads(path.read_text())
        if get_field(data, item["pass_field"]) != item.get("pass_equals", True):
            raise ValueError("candidate PASS receipt is missing/false: " + str(path))
        for field, expected in item.get("required_fields", {}).items():
            if get_field(data, field) != expected:
                raise ValueError("candidate receipt final-scope requirement differs: " + str(path) + ":" + field)
        if data.get("finite_only") is True or data.get("failures"):
            raise ValueError("candidate receipt is partial or contains failures: " + str(path))
        for group in recipe.get("required_source_artifact_groups", []):
            if not any(field in data for field in group):
                raise ValueError("final source artifact binding is missing: " + str(path) + ":" + repr(group))
        for field, relative_source in recipe.get("bound_source_artifacts", {}).items():
            if field in data:
                artifact = root / safe_name(relative_source)
                if not artifact.is_file() or sha(artifact) != data[field]:
                    raise ValueError("source artifact differs from final receipt: " + str(path) + ":" + field)
                copy_source(artifact, destination / "receipts/source-artifacts" / safe_name(relative_source))
        relative = "receipts/%02d-%s" % (index, path.name)
        copy_source(path, destination / relative)
        receipt_rows.append({"source_path": str(path), "path": relative, "sha256": sha(path), "pass_field": item["pass_field"]})
        # Follow exact recorded receipts; never treat a stale summary as evidence.
        for recorded, digest in data.get("receipts", {}).items():
            bound = Path(recorded)
            if not bound.is_file() or sha(bound) != digest:
                raise ValueError("nested semantic receipt changed: " + recorded)
            follow = json.loads(bound.read_text())
            if follow.get("all_passed") is not True or follow.get("finite_only") is True or follow.get("failures"):
                raise ValueError("nested semantic receipt is not PASS")
            nested = "receipts/%02d-nested-%s-%s" % (index, digest[:12], bound.name)
            copy_source(bound, destination / nested)
        if "result_path" in data:
            bound = Path(data["result_path"])
            final_result = json.loads(bound.read_text())
            if (sha(bound) != data["result_sha256"] or final_result.get("all_passed") is not True
                    or final_result.get("finite_only") is True or final_result.get("failures")):
                raise ValueError("exact recorded semantic result differs/is not PASS")
            copy_source(bound, destination / ("receipts/%02d-final-RESULT.json" % index))
    snapshot = json.loads((root / recipe["runtime_manifest"]).read_text())
    expected = {}
    for row in snapshot.get("files", snapshot.get("runtime_files", [])):
        relative = safe_name(row["path"])
        if recipe.get("manifest_paths_have_runtime"):
            relative = Path(relative).relative_to(runtime_relative).as_posix()
        expected[relative] = row["sha256"]
    actual = {name: row["sha256"] for name, row in inventory(runtime).items()
              if not name.endswith((".so", ".pyd", ".pyc"))}
    if actual != expected:
        raise ValueError("complete candidate runtime differs from final manifest: " + recipe["name"])
    for name in expected:
        copy_source(runtime / name, destination / runtime_relative / name)
    for name in recipe.get("extra_files", []):
        copy_source(root / safe_name(name), destination / safe_name(name))
    if recipe.get("tested_source_manifest"):
        tested_path = root / recipe["tested_source_manifest"]
        tested = json.loads(tested_path.read_text())
        for row in tested["source_files"]:
            path = destination / row["path"]
            if not path.is_file() or sha(path) != row["sha256"] or path.stat().st_size != row["bytes"]:
                raise ValueError("tested candidate top-level source differs: " + row["path"])
        if sha(root / recipe["runtime_manifest"]) != tested["runtime_pin_sha256"]:
            raise ValueError("tested runtime manifest differs")
        copy_source(tested_path, destination / "receipts/TESTED_SOURCE_MANIFEST.json")
        foreign = root / "STATIC_BINDING_PINS.json"
        if sha(foreign) != tested["static_binding_pins_sha256"]:
            raise ValueError("preserved foreign interpreter binding evidence differs")
        copy_source(foreign, destination / "receipts/FOREIGN_STATIC_BINDING_PINS.json")
        if sha(Path(recipe["receipts"][0]["path"])) != tested["control_result_sha256"] or sha(Path(recipe["receipts"][1]["path"])) != tested["finite_result_sha256"]:
            raise ValueError("tested direct PASS receipt differs")
    copy_source(root / recipe["runtime_manifest"], destination / "receipts/RUNTIME_INPUT_MANIFEST.json")
    entrypoint = safe_name(recipe["entrypoint"])
    if not (destination / entrypoint).is_file():
        raise ValueError("final entrypoint has not been staged")
    sources = inventory(destination)
    sources = {name: row for name, row in sources.items() if not name.startswith("receipts/")}
    # Bind source hashes published by the finite control receipts when available.
    for item in recipe["receipts"]:
        path = Path(item["path"])
        path = path if path.is_absolute() else root / path
        data = json.loads(path.read_text())
        if recipe.get("require_candidate_runtime_inventory"):
            current_expected = {name: sha(destination / runtime_relative / name) for name in expected}
            if data.get("candidate_runtime_sha256") != current_expected:
                raise ValueError("complete runtime inventory missing/different in final receipt: " + str(path))
        for name, digest in data.get("candidate_runtime_sha256", {}).items():
            if name.endswith((".so", ".pyd", ".pyc")):
                continue
            staged = destination / runtime_relative / name
            if not staged.is_file() or sha(staged) != digest:
                raise ValueError("finite runtime binding differs: " + name)
        # Some controls bind their original comparison arm as runtime_sha256.
        # Prefer the explicit candidate map; use the older final-observer map
        # only when no separate candidate binding is present.
        legacy_runtime = (data.get("runtime_sha256", {})
            if data.get("snapshot_manifest_sha256") and not data.get("candidate_runtime_sha256") else {})
        for name, digest in legacy_runtime.items():
            staged = destination / runtime_relative / name
            if not staged.is_file() or sha(staged) != digest:
                raise ValueError("final runtime receipt binding differs: " + name)
        if data.get("snapshot_manifest_sha256") and sha(root / recipe["runtime_manifest"]) != data["snapshot_manifest_sha256"]:
            raise ValueError("final snapshot receipt differs")
        for name, digest in data.get("candidate_source_sha256", {}).items():
            if sha(root / name) != digest:
                raise ValueError("final candidate helper/control source differs: " + name)
            copy_source(root / safe_name(name), destination / "receipts/tested-source" / safe_name(name))
        for name, digest in data.get("source", {}).items():
            staged = destination / name
            if staged.is_file() and sha(staged) != digest:
                raise ValueError("semantic source binding differs: " + name)
        for key, prefix in (("sources", ""), ("runtime", runtime_relative + "/")):
            for name, digest in data.get("bindings", {}).get(key, {}).items():
                staged = destination / (prefix + name)
                if staged.is_file() and sha(staged) != digest:
                    raise ValueError("source-closed control binding differs: " + name)
    native = []
    for item in recipe.get("native", []):
        source = safe_name(item["source"])
        native.append({**item, "source": source, "sha256": sha(destination / source)})
    excluded = set(recipe.get("host_only_sources", [])) | {item["source"] for item in native}
    participant = {name: row for name, row in sources.items() if name not in excluded}
    spec = {"schema": "t3-screen-arm-v1", "name": recipe["name"], "runtime": runtime_relative,
        "entrypoint": entrypoint, "source_inventory": sources, "mode": "optimized", "native": native,
        "entry_module_name": recipe.get("entry_module_name", "_t3_screen_real_entry"),
        "participant_inventory": participant, "host_only_source_files": recipe.get("host_only_sources", []),
        "dependency_versions": {"numpy": "1.26.4", "pandas": "1.5.3", "pyarrow": "15.0.2"},
        "modules": {**{name: runtime_relative + "/" + path for name, path in MODULES.items()},
                    "@entry": entrypoint, **recipe.get("extra_modules", {})},
        "expected_kernel": recipe.get("expected_kernel", "t3_canonical_engine:CanonicalKernel"),
        "expected_latency": recipe.get("expected_latency", "optimizations:scalar_latency"),
        "active_probe": recipe.get("active_probe"), "probe_equals": recipe.get("probe_equals", {}),
        "no_run_patch": recipe.get("no_run_patch", False), "preflight": recipe.get("preflight"),
        "no_enabled_patch": recipe.get("no_enabled_patch", False),
        "online_probe": recipe.get("online_probe", False), "online_expect_admitted": recipe.get("online_expect_admitted", False),
        "generated_files": recipe.get("generated_files", []),
        "binding_aliases": recipe.get("binding_aliases", {}),
        "observer_probe": recipe.get("observer_probe", False),
        "receipts": receipt_rows}
    write(destination / "ARM.json", spec)
    return spec


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True, help="new staging directory")
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--recipes", type=Path, help="explicit complete JSON recipe list; unready candidates must be omitted")
    parser.add_argument("--arms", nargs="+", help="explicit chosen names; canonical must be first")
    args = parser.parse_args()
    probe = HERE / "entry_probe.py"
    if not probe.is_file():
        raise ValueError("root-owned final v2 entry_probe.py is required before staging")
    probe_tree = ast.parse(probe.read_bytes(), filename=str(probe))
    probe_schema = [node.value.value for node in probe_tree.body if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "PROBE_SCHEMA" for target in node.targets)
        and isinstance(node.value, ast.Constant)]
    if probe_schema != ["t3-screen-entry-probe-v2"]:
        raise ValueError("exact root-owned v2 probe schema is required")
    probe_fields = {node.value for node in ast.walk(probe_tree) if isinstance(node, ast.Constant) and isinstance(node.value, str)}
    if not {"no_enabled_patch", "no_run_patch", "entry_module_name", "online_probe", "online_expect_admitted"}.issubset(probe_fields):
        raise ValueError("v2 probe lacks required preserved-alias/online path branches")
    if args.out.exists() or args.archive.exists():
        raise ValueError("new staging and archive paths required")
    recipes = json.loads(args.recipes.read_text()) if args.recipes else standard_recipes()
    if args.arms:
        mapping = {row["name"]: row for row in recipes}
        recipes = [mapping[name] for name in args.arms]
    names = [item["name"] for item in recipes]
    if not names or names[0] != "canonical" or len(set(names)) != len(names) or any(safe_name(n) != n or "/" in n for n in names):
        raise ValueError("canonical first plus unique simple arm names required")
    args.out.mkdir(parents=True)
    arms = [freeze_arm(item, args.out / "arms" / item["name"]) for item in recipes]
    for path in HERE.glob("*.py"):
        if not path.name.startswith("._"):
            copy_source(path, args.out / "control" / path.name)
    for name in ("verify_linux.py", "verify_public.py", "fetch_evaluation.py"):
        copy_source(COMPLETION / name, args.out / "host" / name)
    write(args.out / "SCREEN_PLAN.json", {"schema": "t3-linux-screen-plan-v2", "rankable": False,
        "scope": "serial rotating candidate screen; one canonical baseline per round, less closely paired than dedicated paired experiments",
        "base": BASE, "arms": names, "smoke_units": SMOKE, "stress_units": STRESS, "units": UNITS,
        "warmups": 1, "measured_repeats": 3, "retain_success_outputs_until_job_end": True,
        "promotion_requires_separate_full71": True, "unready_arms_omitted": [],
        "candidate_gains_assumed_additive": False,
        "planned_non_isolated_runs": len(names) * (len(SMOKE) + len(STRESS) + 1 + len(UNITS) * 4),
        "planned_batch_isolated_runs": len(names) * 5})
    files = inventory(args.out)
    if len(files) + 1 > MAX_FILES or sum(row["bytes"] for row in files.values()) > MAX_BYTES:
        raise ValueError("source payload exceeds materialization bounds")
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-screen-payload-v1", "files": files})
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.archive, "w:xz", preset=6) as archive:
        for path in sorted(args.out.rglob("*")):
            if not path.is_file() or path.name.startswith("._") or "__pycache__" in path.parts:
                continue
            data = path.read_bytes()
            info = tarfile.TarInfo(path.relative_to(args.out).as_posix())
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
    write(args.archive.with_name(args.archive.name + ".json"), {"archive": str(args.archive),
        "sha256": sha(args.archive), "bytes": args.archive.stat().st_size, "arms": names,
        "source_only": True, "builds_or_simulations_executed": False})
    print(json.dumps({"archive_sha256": sha(args.archive), "arms": names}))


if __name__ == "__main__":
    main()
