"""Prepared bounded source-closed controls; no checks run during authoring."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root):
    return {str(path.relative_to(root)): sha(path) for path in sorted(root.rglob("*"))
            if path.is_file() and not path.name.startswith("._") and "__pycache__" not in path.parts}


def source_binding():
    return {"candidate_runtime_sha256": inventory(HERE / "runtime"),
        "candidate_source_sha256": {path.name: sha(path) for path in sorted(HERE.glob("*.py")) if not path.name.startswith("._")},
        "original_runtime_sha256": inventory(ROOT / "runtime")}


def launch(worker, runtime, output, folder):
    env = dict(os.environ, PYTHONPATH=str(ROOT.parent / ".runtime"), PYTHONDONTWRITEBYTECODE="1")
    command = ["/usr/bin/python3", "-B", str(HERE / worker), "--runtime", str(runtime), "--out", str(output)]
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "run.log").open("xb") as stream:
        result = subprocess.run(command, env=env, cwd=runtime, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    if result.returncode:
        raise ValueError("worker failed; preserved log: " + str(folder))
    return {"command": command, "returncode": result.returncode, "timing_claim": False,
            "receipt_sha256": sha(output / "WORKER_RECEIPT.json")}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--stage", choices=("finite", "admission", "market"), default="finite")
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("new evidence directory required")
    before = source_binding()
    manifest = json.loads((HERE / "SNAPSHOT_MANIFEST.json").read_text())
    if before["candidate_runtime_sha256"] != {row["path"]: row["sha256"] for row in manifest["files"]}:
        raise ValueError("candidate snapshot changed")
    args.out.mkdir(parents=True)
    result = {"schema": "t3-book-metric-online-controls-v1", "stage": args.stage, "all_passed": False,
        "rankable": False, "official_gate": False, "timing_claim": False, **before, "runs": [], "failures": []}
    try:
        worker = {"finite": "finite_worker.py", "admission": "admission_worker.py", "market": "semantic_worker.py"}[args.stage]
        arms = (("online", HERE / "runtime"),) if args.stage == "admission" else (("canonical", ROOT / "runtime"), ("online", HERE / "runtime"))
        for arm, runtime in arms:
            result["runs"].append(launch(worker, runtime, args.out / arm / "values", args.out / arm))
        if args.stage == "finite":
            a, b = [(args.out / arm / "values/FINITE_VALUES.json").read_bytes() for arm in ("canonical", "online")]
            if a != b:
                raise ValueError("metric fields/types/warning/empty-identity finite values differ")
            result["cases"] = len(json.loads(a))
            if result["cases"] != 165:
                raise ValueError("finite roster incomplete")
        elif args.stage == "admission":
            values = json.loads((args.out / "online/values/ADMISSION_VALUES.json").read_text())
            if len(values["scenario_cases"]) != 15 or len(values["binding_mutations"]) != 7:
                raise ValueError("admission roster incomplete")
            if not (all(row["actual"] is row["expected"] for row in values["scenario_cases"])
                    and all(row["rejected"] and row["restored"] for row in values["binding_mutations"])
                    and values["batch_fresh_accumulator"] and values["whole_episode_fallback_original_snapshot"]):
                raise ValueError("admission/batch/fallback control failed")
            result["cases"] = 15
            result["binding_mutations"] = 7
        else:
            import pickle
            import sys
            sys.path.insert(0, str(ROOT.parent / ".runtime"))
            import pandas as pd
            a, b = [pickle.loads((args.out / arm / "values/SEMANTIC_VALUES.pkl").read_bytes()) for arm in ("canonical", "online")]
            if len(a) != 4 or len(b) != 4:
                raise ValueError("four complete-market cases required")
            for original, candidate in zip(a, b):
                if original["seed"] != candidate["seed"]:
                    raise ValueError("market seed differs")
                for x, y in zip(original["frames"], candidate["frames"]):
                    pd.testing.assert_frame_equal(x, y, check_dtype=True, check_exact=True, rtol=0, atol=0)
                if original["payload"] != candidate["payload"]:
                    raise ValueError("book/summary/metric/queue/ledger/RNG/ID/Parquet state differs")
            result["cases"] = 4
        if source_binding() != before:
            raise ValueError("source changed during controls")
        result.update(all_passed=True, source_unchanged=True)
    except Exception as error:
        result["failures"].append({"type": type(error).__name__, "message": str(error)})
    (args.out / "RESULT.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"all_passed": result["all_passed"], "stage": args.stage, "failures": result["failures"]}))
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
