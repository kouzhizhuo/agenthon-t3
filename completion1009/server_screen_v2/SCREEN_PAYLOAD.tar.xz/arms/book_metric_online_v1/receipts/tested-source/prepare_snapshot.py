"""Materialize a separate static online-metric source; no simulation or native."""
import ast
import hashlib
import json
import difflib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SNAPSHOT = HERE / "runtime"
BOOK = "vendor/abides/abides-markets/abides_markets/order_book.py"
EXCHANGE = "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def once(source, before, after):
    if source.count(before) != 1:
        raise ValueError("frozen source replacement differs: " + before[:80])
    return source.replace(before, after, 1)


def transform(relative, data):
    source = data.decode()
    original = source
    replacements = []

    def change(before, after):
        nonlocal source
        source = once(source, before, after)
        replacements.append((before, after))

    changes = []
    if relative == BOOK:
        change("import sys\n", "import sys\nimport online_metric as _online_metric\n")
        change("        self.book_log2: List[Dict[str, Any]] = []\n", "        self.book_log2: List[Dict[str, Any]] = []\n        self._online_metric = _online_metric.accumulator()\n")
        change("    def append_book_log2(self):\n", "    def append_book_log2(self):\n        if self._online_metric is not None:\n            self._online_metric.observe(self.owner.current_time, not self.bids, not self.asks)\n            return\n")
        changes = ["OrderBook.__init__", "OrderBook.append_book_log2"]
    elif relative == EXCHANGE:
        change("import logging\n", "import logging\nimport online_metric as _online_metric\n")
        change("    def analyse_order_book(self, symbol: str):\n        book = self.order_books[symbol].book_log2\n", "    def analyse_order_book(self, symbol: str):\n        accumulator = self.order_books[symbol]._online_metric\n        if accumulator is not None:\n            accumulator.apply(self, symbol)\n            return\n        book = self.order_books[symbol].book_log2\n")
        changes = ["ExchangeAgent.analyse_order_book"]
    elif relative == "agent.py":
        change("from contracts import sha256, validate_scenario, validate_frames\n", "from contracts import sha256, validate_scenario, validate_frames\nimport online_metric\nfrom online_domain import authenticate_loaded\n")
        change("    validate_scenario(scenario)\n", "    validate_scenario(scenario)\n    online_metric.begin_episode(scenario, authenticate_loaded())\n")
        changes = ["simulate"]
    if relative.endswith(".py"):
        ast.parse(source)
    restored = source
    for before, after in reversed(replacements):
        restored = once(restored, after, before)
    if restored != original or (relative.endswith(".py") and ast.dump(ast.parse(restored), include_attributes=False) != ast.dump(ast.parse(original), include_attributes=False)):
        raise ValueError("undeclared source or AST change: " + relative)
    return source.encode(), changes


def main():
    if SNAPSHOT.exists():
        raise ValueError("new independent snapshot required; do not overwrite")
    manifest_path = ROOT / "RUNTIME_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    rows, changed, diffs = [], [], []
    for item in manifest["files"]:
        relative = str(Path(item["path"]).relative_to("runtime"))
        original = (ROOT / item["path"]).read_bytes()
        if sha(original) != item["sha256"] or len(original) != item["bytes"]:
            raise ValueError("frozen source differs: " + relative)
        data, definitions = transform(relative, original)
        if definitions:
            diffs.extend(difflib.unified_diff(original.decode().splitlines(keepends=True), data.decode().splitlines(keepends=True),
                fromfile="original/" + relative, tofile="candidate/" + relative))
        target = SNAPSHOT / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        if target.name in ("agent.py", "simulate", "simulate-batch"):
            target.chmod(0o755)
        rows.append({"path": relative, "bytes": len(data), "sha256": sha(data), "original_sha256": sha(original), "changed": bool(definitions)})
        changed.extend({"path": relative, "definition": name} for name in definitions)
    for name in ("online_metric.py", "online_domain.py"):
        data = (HERE / name).read_bytes()
        (SNAPSHOT / name).write_bytes(data)
        rows.append({"path": name, "bytes": len(data), "sha256": sha(data), "added": True})
    pins = {"schema": "t3-online-metric-runtime-pins-v1", "files": {row["path"]: row["sha256"] for row in rows},
            "frozen_manifest_sha256": sha(manifest_path.read_bytes())}
    data = (json.dumps(pins, indent=2, sort_keys=True) + "\n").encode()
    (SNAPSHOT / "ONLINE_RUNTIME_PINS.json").write_bytes(data)
    rows.append({"path": "ONLINE_RUNTIME_PINS.json", "bytes": len(data), "sha256": sha(data), "added": True})
    receipt = {"schema": "t3-book-metric-online-snapshot-v1", "files": rows, "changed_definitions": changed,
        "frozen_manifest_sha256": sha(manifest_path.read_bytes()), "builder_sha256": sha(Path(__file__).read_bytes()),
        "native_compiled": False, "controls_run": False, "markets_run": False, "timing_claim": False, "rankable": False,
        "all_declared_source_changes_reverse_to_frozen_bytes_and_ast": True,
        "excluded_private_state": ["OrderBook.book_log2 complete-depth diagnostic history", "OrderBook._online_metric representation"],
        "preserved": "all market messages, order history/live queries, trace/ledger, summaries, RNG/IDs and completed-interval MetricTracker fields"}
    (HERE / "SNAPSHOT_MANIFEST.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    (HERE / "SOURCE_DIFF.patch").write_text("".join(diffs))
    print(json.dumps({"status": "source_snapshot_prepared", "files": len(rows), "changed_definitions": changed,
                      "controls_run": False, "markets_run": False}, indent=2))


if __name__ == "__main__":
    main()
