"""Prepared finite admission/batch controls; no market simulation is needed."""
import argparse
from pathlib import Path
import sys
parser = argparse.ArgumentParser()
parser.add_argument("--runtime", type=Path, required=True)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
runtime = args.runtime.resolve()
sys.path.insert(0, str(runtime))
from bootstrap import activate
activate()
import hashlib
import json
from types import SimpleNamespace
import online_metric as online
import online_domain as domain
from abides_fork import agents, config
from abides_markets.orders import LimitOrder
from abides_markets.order_book import OrderBook
import optimizations


def valid():
    return {"horizon_ns": 1000000000, "exchange_config": {},
        "agent_configs": [{"agent_type": name, "count": 1, "params": {}}
                          for name in sorted(online.STRATEGIES)],
        "latency_config": {"model": "uniform", "params": {"min_ns": 0, "max_ns": 1000}}}


def scenarios():
    result = [("bounded-four-strategy", valid(), True)]
    value = valid(); value.pop("latency_config")
    result.append(("default-latency", value, True))
    value = valid(); value["exchange_config"] = {"protocol_enforcement": True, "ack_delay_ns": 5, "compute_delay_ns": 10}
    result.append(("bounded-protocol", value, True))
    edits = [
        ("large-horizon", lambda v: v.update(horizon_ns=10 ** 15 + 1)),
        ("non-int-horizon", lambda v: v.update(horizon_ns=1.0)),
        ("negative-latency", lambda v: v["latency_config"]["params"].update(min_ns=-1)),
        ("nan-latency", lambda v: v["latency_config"]["params"].update(max_ns=float("nan"))),
        ("large-latency", lambda v: v["latency_config"]["params"].update(max_ns=10 ** 15 + 1)),
        ("reversed-latency", lambda v: v["latency_config"]["params"].update(min_ns=2000)),
        ("large-interval", lambda v: v["agent_configs"][0]["params"].update(rebalance_interval_ns=10 ** 15 + 1)),
        ("zero-interval", lambda v: v["agent_configs"][0]["params"].update(rebalance_interval_ns=0)),
        ("negative-protocol", lambda v: v["exchange_config"].update(protocol_enforcement=True, ack_delay_ns=-1)),
        ("large-protocol", lambda v: v["exchange_config"].update(protocol_enforcement=True, compute_delay_ns=10 ** 15 + 1)),
        ("unknown-strategy", lambda v: v["agent_configs"][0].update(agent_type="CustomTrader")),
        ("boolean-count", lambda v: v["agent_configs"][0].update(count=True)),
    ]
    for name, edit in edits:
        value = valid(); edit(value); result.append((name, value, False))
    return result


def substitute(name, owner, attribute, replacement):
    old = getattr(owner, attribute)
    try:
        setattr(owner, attribute, replacement)
        assert domain.authenticate_loaded() is False, "substitution admitted: " + name
    finally:
        setattr(owner, attribute, old)
    assert domain.authenticate_loaded() is True, "restored binding rejected: " + name
    return {"name": name, "rejected": True, "restored": True}


def main():
    args.out.mkdir(parents=True, exist_ok=False)
    assert domain.authenticate_loaded() is True, "frozen loaded source failed admission"
    cases = []
    for name, value, expected in scenarios():
        got = online.admitted_scenario(value)
        assert got is expected, name
        cases.append({"name": name, "expected": expected, "actual": got})
    original = optimizations.enabled
    def wrapped(*args, **kwargs):
        return original(*args, **kwargs)
    wrapped.__wrapped__ = original.__wrapped__
    mutations = [substitute("actual-wrapper-changed", optimizations, "enabled", wrapped),
        substitute("exported-metric-class-changed", online, "OnlineMetric", type("Replacement", (), {})),
        substitute("registry-copy-rebound", config, "AGENT_REGISTRY", dict(agents.AGENT_REGISTRY)),
        substitute("bound-horizon-constant-changed", online, "TIME_COMPONENT_BOUND", 10 ** 15 + 1),
        substitute("native-callable-substituted", OrderBook, "append_book_log2", list.append),
        substitute("inherited-callback-overridden", agents.NoiseTrader, "wakeup", lambda *a: None)]
    old_defaults = LimitOrder.__init__.__defaults__
    try:
        LimitOrder.__init__.__defaults__ = (True,) + old_defaults[1:]
        assert domain.authenticate_loaded() is False, "changed limit defaults admitted"
    finally:
        LimitOrder.__init__.__defaults__ = old_defaults
    assert domain.authenticate_loaded() is True
    mutations.append({"name": "limit-defaults-changed", "rejected": True, "restored": True})
    # Fresh whole-episode selection happens before construction. Fallback books
    # retain original snapshot arrays, and the next admitted book starts empty.
    owner = SimpleNamespace(current_time=17, mkt_open=0, book_log_depth=10)
    assert online.begin_episode(valid(), domain.authenticate_loaded()) is True
    first = OrderBook(owner, "ABM"); first.append_book_log2()
    assert first._online_metric.rows == 1 and first.book_log2 == []
    assert online.begin_episode({"horizon_ns": -1}, domain.authenticate_loaded()) is False
    fallback = OrderBook(owner, "ABM"); fallback.append_book_log2()
    assert fallback._online_metric is None and len(fallback.book_log2) == 1
    assert online.begin_episode(valid(), domain.authenticate_loaded()) is True
    last = OrderBook(owner, "ABM")
    assert last._online_metric is not first._online_metric and last._online_metric.rows == 0 and last.book_log2 == []
    value = {"scenario_cases": cases, "binding_mutations": mutations,
        "batch_fresh_accumulator": True, "whole_episode_fallback_original_snapshot": True,
        "native_bindings": "Python source gate rejects non-FunctionType; native proof is separate"}
    blob = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    (args.out / "ADMISSION_VALUES.json").write_bytes(blob)
    (args.out / "WORKER_RECEIPT.json").write_text(json.dumps({"values_sha256": hashlib.sha256(blob).hexdigest(),
        "timing_claim": False, "simulation_execution": False, "cases": len(cases),
        "binding_mutations": len(mutations)}, indent=2) + "\n")
    print(json.dumps({"cases": len(cases), "binding_mutations": len(mutations)}))


if __name__ == "__main__":
    main()
