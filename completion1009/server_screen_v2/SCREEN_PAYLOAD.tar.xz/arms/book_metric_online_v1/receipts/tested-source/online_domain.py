"""Authenticate the static positive-order domain once, then check bindings.

This gate expects frozen Python source and the standard Python contextlib
wrapper. It rejects native or customized producers before constructing agents.
"""
import ast
import contextlib
import hashlib
import importlib
import inspect
import json
from pathlib import Path
import sys
import types
import numpy as np

ROOT = Path(__file__).resolve().parent
_BOUND = None
_ENABLED = None
_CLASSES = None

CHECKS = (
    ("abides_core.abides", "vendor/abides/abides-core/abides_core/abides.py", None, ("run",)),
    ("abides_core.utils", "vendor/abides/abides-core/abides_core/utils.py", None, ("subdict", "str_to_ns")),
    ("abides_core.kernel", "vendor/abides/abides-core/abides_core/kernel.py", "Kernel", ("__init__", "run", "initialize", "runner", "terminate", "send_message", "set_wakeup", "get_agent_compute_delay", "set_agent_compute_delay", "delay_agent")),
    ("abides_core.agent", "vendor/abides/abides-core/abides_core/agent.py", "Agent", ("__init__", "kernel_initializing", "kernel_starting", "kernel_stopping", "kernel_terminating", "receive_message", "wakeup", "send_message", "set_wakeup", "set_computation_delay", "delay")),
    ("abides_core.latency_model", "vendor/abides/abides-core/abides_core/latency_model.py", "LatencyModel", ("__init__", "get_latency", "_extract")),
    ("abides_markets.utils", "vendor/abides/abides-markets/abides_markets/utils/__init__.py", None, ("generate_latency_model", "generate_uniform_random_pairwise_dist_on_line", "meters_to_light_ns")),
    ("t3_canonical_engine", "t3_canonical_engine.py", "CanonicalKernel", ("__init__", "runner", "send_message", "set_wakeup")),
    ("t3_canonical_engine", "t3_canonical_engine.py", "FlatHeap", ("__init__", "empty", "qsize")),
    ("t3_canonical_engine", "t3_canonical_engine.py", "ColumnLedger", ("__init__", "__len__", "append_values")),
    ("column_trace", "column_trace.py", None, ("make_extractor",)),
    ("optimizations", "optimizations.py", None, ("scalar_latency",)),
    ("abides_fork.simulate", "abides_fork/simulate.py", None, ("reset_abides_counters",)),
    ("abides_fork.config", "abides_fork/config.py", None, ("build_config", "_agent_kwargs", "_interval_ns", "_draw_random_state", "_oracle_kappa_per_ns", "_oracle_megashock_rate_per_ns")),
    ("abides_fork.config", "abides_fork/config.py", "ScenarioLatencyModel", ("__init__", "get_latency")),
    ("abides_fork.agents", "abides_fork/agents.py", "ScheduledAgent", ("__init__", "wakeup", "receive_message", "kernel_starting", "get_wake_frequency")),
    ("abides_markets.orders", "vendor/abides/abides-markets/abides_markets/orders.py", "Order", ("__init__", "to_dict")),
    ("abides_markets.orders", "vendor/abides/abides-markets/abides_markets/orders.py", "LimitOrder", ("__init__", "__deepcopy__")),
    ("abides_markets.agents.financial_agent", "vendor/abides/abides-markets/abides_markets/agents/financial_agent.py", "FinancialAgent", ("__init__",)),
    ("abides_markets.agents.trading_agent", "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py", "TradingAgent", ("__init__", "kernel_starting", "wakeup", "receive_message", "create_limit_order", "place_limit_order", "cancel_all_orders", "cancel_order", "order_executed")),
    ("abides_markets.order_book", "vendor/abides/abides-markets/abides_markets/order_book.py", "OrderBook", ("__init__", "handle_limit_order", "execute_order", "enter_order", "cancel_order", "modify_order", "partial_cancel_order", "append_book_log2", "get_l2_bid_data", "get_l2_ask_data")),
    ("abides_markets.price_level", "vendor/abides/abides-markets/abides_markets/price_level.py", "PriceLevel", ("__init__", "add_order", "pop", "remove_order", "update_order_quantity", "total_quantity", "is_empty")),
    ("abides_markets.agents.exchange_agent", "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py", "ExchangeAgent", ("__init__", "kernel_initializing", "kernel_terminating", "wakeup", "receive_message", "send_message", "analyse_order_book", "get_time_dropout", "_original_time_dropout")),
    ("contracts", "contracts.py", None, ("validate_scenario", "validate_frames")),
    ("online_metric", "online_metric.py", None, ("admitted_scenario", "begin_episode", "accumulator")),
    ("online_metric", "online_metric.py", "OnlineMetric", ("__init__", "observe", "apply")),
)


def _function(value):
    # Unwrap only frozen descriptors. Arbitrary __wrapped__ is not admission.
    if isinstance(value, property):
        return value.fget
    if isinstance(value, (staticmethod, classmethod)):
        return value.__func__
    return value


def _default_state(value):
    if isinstance(value, np.generic):
        return (type(value), _default_state(value.item()))
    if value is None or type(value) in (bool, int, float, str, bytes):
        return (type(value), value)
    if type(value) in (tuple, list):
        return (type(value), tuple(_default_state(v) for v in value))
    if type(value) is dict:
        return (dict, tuple((_default_state(k), _default_state(v)) for k, v in value.items()))
    return (type(value), id(value))


def _expected_defaults(function_node, module):
    def value(node):
        try:
            return ast.literal_eval(node)
        except (TypeError, ValueError):
            if (isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name)
                    and node.value.id == "sys" and node.attr == "maxsize"
                    and getattr(module, "sys", None) is sys):
                return sys.maxsize
            if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                    and node.func.id == "str_to_ns" and len(node.args) == 1
                    and not node.keywords and isinstance(node.args[0], ast.Constant)
                    and type(node.args[0].value) is str):
                # Only the frozen kernel's fixed clock defaults use this helper.
                from abides_core import utils
                if module.str_to_ns is not utils.str_to_ns:
                    raise ValueError("frozen clock helper rebound")
                return module.str_to_ns(node.args[0].value)
            raise ValueError("unsupported frozen default expression")
    defaults = tuple(value(node) for node in function_node.args.defaults) or None
    kwdefaults = {arg.arg: value(node) for arg, node in
                  zip(function_node.args.kwonlyargs, function_node.args.kw_defaults)
                  if node is not None} or None
    return _default_state(defaults), _default_state(kwdefaults)


def _driver():
    for name in ("__main__", "agent"):
        module = sys.modules.get(name)
        if module is not None and getattr(module, "__file__", None):
            if Path(module.__file__).resolve() == ROOT / "agent.py":
                return module
    return None


def _cross_bindings():
    from abides_fork import config, agents, simulate
    from abides_markets import orders, order_book, price_level, utils as market_utils
    from abides_markets.agents import trading_agent, exchange_agent, financial_agent
    from abides_core import abides, kernel, agent, latency_model, utils as core_utils
    import column_trace
    import contracts
    import online_metric
    import optimizations
    import t3_canonical_engine as engine
    strategy_bindings = all(
        getattr(agents, name).__bases__ == (agents.ScheduledAgent,)
        and all(getattr(getattr(agents, name), method) is getattr(owner, method)
                for owner, method in ((agents.ScheduledAgent, "wakeup"),
                    (agents.ScheduledAgent, "receive_message"),
                    (agents.ScheduledAgent, "kernel_starting"),
                    (agents.ScheduledAgent, "get_wake_frequency"),
                    (trading_agent.TradingAgent, "place_limit_order"),
                    (trading_agent.TradingAgent, "create_limit_order"),
                    (trading_agent.TradingAgent, "cancel_all_orders"),
                    (agent.Agent, "send_message"), (agent.Agent, "set_wakeup")))
        for name in online_metric.STRATEGIES)
    valid = (strategy_bindings and abides.Kernel is kernel.Kernel
        and abides.subdict is core_utils.subdict
        and engine.IncumbentKernel is kernel.Kernel
        and engine.CanonicalKernel.__bases__ == (kernel.Kernel,)
        and all(getattr(engine.CanonicalKernel, name) is getattr(kernel.Kernel, name)
                for name in ("run", "initialize", "terminate", "set_agent_compute_delay", "delay_agent"))
        and agents.ScheduledAgent.__bases__ == (trading_agent.TradingAgent,)
        and trading_agent.TradingAgent.__bases__ == (financial_agent.FinancialAgent,)
        and financial_agent.FinancialAgent.__bases__ == (agent.Agent,)
        and agents.AGENT_REGISTRY == {name: getattr(agents, name) for name in online_metric.STRATEGIES}
        and config.AGENT_REGISTRY is agents.AGENT_REGISTRY
        and config.ExchangeAgent is exchange_agent.ExchangeAgent
        and config.generate_latency_model is market_utils.generate_latency_model
        and config.LatencyModel is latency_model.LatencyModel
        and config.str_to_ns is core_utils.str_to_ns
        and kernel.str_to_ns is core_utils.str_to_ns
        and market_utils.LatencyModel is latency_model.LatencyModel
        and agents.TradingAgent is trading_agent.TradingAgent
        and trading_agent.LimitOrder is orders.LimitOrder and trading_agent.Side is orders.Side
        and order_book.PriceLevel is price_level.PriceLevel
        and order_book.LimitOrder is orders.LimitOrder and order_book.Side is orders.Side
        and exchange_agent.OrderBook is order_book.OrderBook
        and order_book._online_metric is online_metric and exchange_agent._online_metric is online_metric
        and online_metric.TIME_COMPONENT_BOUND == 10 ** 15
        and type(online_metric.TIME_COMPONENT_BOUND) is int
        and online_metric.STRATEGIES == frozenset(("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"))
        and type(online_metric.STRATEGIES) is frozenset
        and config._DATE == "20210205" and config._STARTING_CASH == 10_000_000
        and trading_agent.TradingAgent.place_limit_order.__defaults__ == (None, False, False, False, False, True, None)
        and orders.LimitOrder.__init__.__defaults__ == (False, False, False, False, None, None))
    driver = _driver()
    if driver is not None:
        valid = valid and all(getattr(driver, name) is value for name, value in (
            ("build_config", config.build_config), ("reset_abides_counters", simulate.reset_abides_counters),
            ("enabled", optimizations.enabled), ("abides", abides), ("Kernel", kernel.Kernel),
            ("online_metric", online_metric), ("authenticate_loaded", authenticate_loaded),
            ("validate_scenario", contracts.validate_scenario), ("validate_frames", contracts.validate_frames)))
    return valid


def _enabled_binding(compiled):
    import optimizations
    wrapper = optimizations.enabled
    raw = getattr(wrapper, "__wrapped__", None)
    helper = next(c for c in contextlib.contextmanager.__code__.co_consts
                  if type(c) is types.CodeType and c.co_name == "helper")
    expected = next(c for c in compiled[ROOT / "optimizations.py"].co_consts
                    if type(c) is types.CodeType and c.co_name == "enabled")
    if (type(wrapper) is not types.FunctionType or wrapper.__code__ != helper
            or wrapper.__globals__ is not vars(contextlib) or wrapper.__defaults__ is not None
            or wrapper.__kwdefaults__ is not None or wrapper.__code__.co_freevars != ("func",)
            or len(wrapper.__closure__ or ()) != 1 or wrapper.__closure__[0].cell_contents is not raw
            or type(raw) is not types.FunctionType or raw.__code__ != expected
            or raw.__globals__ is not vars(optimizations) or raw.__defaults__ != (True,)
            or raw.__kwdefaults__ is not None):
        return None
    # contextlib is part of the trusted interpreter; bind its actual dispatcher
    # class and methods as well as the wrapper closure across batch episodes.
    manager = contextlib._GeneratorContextManager
    manager_bindings = tuple((name, getattr(manager, name), getattr(manager, name).__code__)
                             for name in ("__init__", "__enter__", "__exit__"))
    return (wrapper, wrapper.__code__, raw, raw.__code__, manager, manager_bindings)


def _enabled_unchanged():
    import optimizations
    wrapper, code, raw, raw_code, manager, methods = _ENABLED
    return (optimizations.enabled is wrapper and wrapper.__code__ is code
        and wrapper.__globals__ is vars(contextlib) and wrapper.__defaults__ is None
        and wrapper.__kwdefaults__ is None and wrapper.__wrapped__ is raw
        and wrapper.__closure__[0].cell_contents is raw and raw.__code__ is raw_code
        and raw.__defaults__ == (True,) and raw.__kwdefaults__ is None
        and contextlib._GeneratorContextManager is manager
        and all(getattr(manager, name) is function and function.__code__ is old_code
                for name, function, old_code in methods))


def authenticate_loaded():
    global _BOUND, _ENABLED, _CLASSES
    try:
        if _BOUND is not None:
            return (all(getattr(module, classname) is cls for module, classname, cls in _CLASSES)
                and all(_function(inspect.getattr_static(getattr(module, classname) if classname else module, name)) is function
                        and function.__code__ is code
                        and _default_state(function.__defaults__) == defaults
                        and _default_state(function.__kwdefaults__) == kwdefaults
                        for module, classname, name, function, code, defaults, kwdefaults in _BOUND)
                and _enabled_unchanged() and _cross_bindings())
        pins = json.loads((ROOT / "ONLINE_RUNTIME_PINS.json").read_text())
        current = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(ROOT.rglob("*")) if path.is_file() and not path.name.startswith("._")
            and "__pycache__" not in path.parts and path.name != "ONLINE_RUNTIME_PINS.json"}
        if current != pins["files"]:
            return False
        checks = list(CHECKS)
        for name in ("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"):
            checks.append(("abides_fork.agents", "abides_fork/agents.py", name, ("__init__", "act")))
        driver = _driver()
        if driver is not None:
            checks.append((driver.__name__, "agent.py", None, ("simulate",)))
        compiled, parsed, bindings, classes = {}, {}, [], []
        for module_name, relative, class_name, names in checks:
            module = importlib.import_module(module_name)
            path = ROOT / relative
            if Path(module.__file__).resolve() != path:
                return False
            if path not in compiled:
                compiled[path] = compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
                parsed[path] = ast.parse(path.read_bytes())
            code = compiled[path]
            tree = parsed[path]
            owner = module
            if class_name is not None:
                owner = getattr(module, class_name)
                classes.append((module, class_name, owner))
                if not isinstance(owner, type) or owner.__module__ != module.__name__:
                    return False
                code = next(c for c in code.co_consts if type(c) is types.CodeType and c.co_name == class_name)
                tree = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name)
            for name in names:
                function = _function(inspect.getattr_static(owner, name))
                expected = next(c for c in code.co_consts if type(c) is types.CodeType and c.co_name == name)
                node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)
                defaults, kwdefaults = _expected_defaults(node, module)
                if (type(function) is not types.FunctionType or function.__code__ != expected
                        or function.__globals__ is not vars(module)
                        or _default_state(function.__defaults__) != defaults
                        or _default_state(function.__kwdefaults__) != kwdefaults):
                    return False
                bindings.append((module, class_name, name, function, function.__code__,
                                 defaults, kwdefaults))
        enabled = _enabled_binding(compiled)
        if enabled is None or not _cross_bindings():
            return False
        _BOUND, _CLASSES, _ENABLED = tuple(bindings), tuple(classes), enabled
        return True
    except (AttributeError, IndexError, KeyError, StopIteration, TypeError, ValueError, OSError, SyntaxError):
        return False
