"""Constant-space exact liquidity intervals for the admitted frozen CLI."""
import math
import numpy as np

ACTIVE = False
EPISODES = 0
TIME_COMPONENT_BOUND = 10 ** 15
STRATEGIES = frozenset(("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"))


def admitted_scenario(scenario):
    """Conservatively keep every possible observed time inside int64.

    The fixed 2021 market origin is below 2e18 ns. The kernel stops dispatch
    after market close +1s, so its final popped event adds at most one bounded
    interval or latency/compute/ack chain. Nonnegative bounded components keep
    all book observations well inside int64. Unsupported timing shapes take
    the original whole-episode snapshot path before any agents are created.
    """
    try:
        if (type(scenario) is not dict or type(scenario.get("horizon_ns")) is not int
                or not 0 < scenario["horizon_ns"] <= TIME_COMPONENT_BOUND
                or type(scenario.get("agent_configs")) is not list
                or not scenario["agent_configs"]):
            return False
        from abides_fork.config import _interval_ns
        for item in scenario["agent_configs"]:
            if (type(item) is not dict or item.get("agent_type") not in STRATEGIES
                    or type(item.get("count")) is not int or item["count"] < 0
                    or type(item.get("params", {})) is not dict):
                return False
            interval = _interval_ns(item.get("params", {}))
            if type(interval) is not int or not 0 < interval <= TIME_COMPONENT_BOUND:
                return False
        latency = scenario.get("latency_config")
        if latency:
            if type(latency) is not dict or type(latency.get("params", {})) is not dict:
                return False
            params = latency.get("params", {})
            low, high = float(params.get("min_ns", 0)), float(params.get("max_ns", 1e12))
            if not (math.isfinite(low) and math.isfinite(high) and 0 <= low <= high <= TIME_COMPONENT_BOUND):
                return False
        exchange = scenario["exchange_config"]
        if type(exchange) is not dict:
            return False
        if exchange.get("protocol_enforcement", False):
            for name in ("ack_delay_ns", "compute_delay_ns"):
                value = int(exchange.get(name, 0))
                if not 0 <= value <= TIME_COMPONENT_BOUND:
                    return False
        return True
    except (TypeError, ValueError, OverflowError, KeyError):
        return False


def begin_episode(scenario, authenticated):
    global ACTIVE, EPISODES
    ACTIVE = bool(authenticated and admitted_scenario(scenario))
    EPISODES += 1
    return ACTIVE


def accumulator():
    return OnlineMetric() if ACTIVE else None


class OnlineMetric:
    """Only completed empty→liquid intervals contribute, exactly as original."""
    __slots__ = ("rows", "first", "last", "bid_empty", "ask_empty", "bid_first",
                 "ask_first", "bid_time", "ask_time")

    def __init__(self):
        self.rows = 0
        self.first = self.last = None
        self.bid_empty = self.ask_empty = False
        self.bid_first = self.ask_first = self.bid_time = self.ask_time = 0

    def observe(self, timestamp, bid_empty, ask_empty):
        if self.rows == 0:
            self.first = timestamp
        self.last = timestamp
        self.rows += 1
        # Original fast get_time_dropout converts each observation to Python int
        # before interval subtraction; accumulators remain unbounded Python int.
        timestamp = int(timestamp)
        if bid_empty and not self.bid_empty:
            self.bid_first, self.bid_empty = timestamp, True
        elif not bid_empty and self.bid_empty:
            self.bid_time += timestamp - self.bid_first
            self.bid_empty = False
        if ask_empty and not self.ask_empty:
            self.ask_first, self.ask_empty = timestamp, True
        elif not ask_empty and self.ask_empty:
            self.ask_time += timestamp - self.ask_first
            self.ask_empty = False

    def apply(self, exchange, symbol):
        if self.rows == 0:
            # The original empty history returns without replacing its tracker.
            return
        total_time = np.int64(self.last) - np.int64(self.first)
        # Keep operation order, NumPy denominator type, zero-total warnings,
        # possible int64 subtraction overflow and NaN/Inf behavior unchanged.
        exchange.metric_trackers[symbol] = exchange.MetricTracker(
            total_time_no_liquidity_asks=self.ask_time / 1000000000.0,
            total_time_no_liquidity_bids=self.bid_time / 1000000000.0,
            pct_time_no_liquidity_asks=100 * self.ask_time / total_time,
            pct_time_no_liquidity_bids=100 * self.bid_time / total_time)
