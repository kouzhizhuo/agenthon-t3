#!/usr/bin/env python3
"""Prepared untimed full-market worker; parent schedules its execution."""
import argparse
from pathlib import Path
import sys
parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
RUNTIME = Path(args.runtime).resolve()
OUTPUT = Path(args.out).resolve()
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
from contextlib import nullcontext
import hashlib
import io
import json
import pickle
import types
import numpy as np
import pandas as pd
from abides_core import abides
from abides_core.agent import Agent
from abides_core.kernel import Kernel
from abides_core.message import Message
from abides_fork.config import build_config
from abides_fork.simulate import reset_abides_counters
from abides_fork import trace
from abides_markets.orders import Order, Side
from abides_markets.order_book import OrderBook
from optimizations import enabled

online = None
if (RUNTIME / "online_metric.py").is_file():
    import online_metric as online
    from online_domain import authenticate_loaded

def encode(value):
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.ndarray):
        return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if isinstance(value, dict): return [type(value).__name__, [(encode(k), encode(v)) for k, v in value.items()]]
    if type(value) in (list, tuple): return [type(value).__name__, [encode(v) for v in value]]
    if type(value) is Side: return ["Side", value.value]
    if hasattr(value, "__dict__"): return [type(value).__module__, type(value).__name__, encode(vars(value))]
    return [type(value).__name__, repr(value)]


def graph(value, seen=None):
    """Encode exact deterministic state and aliases, including all agent logs."""
    seen = {} if seen is None else seen
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, np.generic): return [type(value).__name__, graph(value.item(), seen)]
    if type(value) is Side: return ["Side", value.value]
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)):
        return ["binding", getattr(value, "__module__", ""), getattr(value, "__qualname__", getattr(value, "__name__", ""))]
    if id(value) in seen: return ["ref", seen[id(value)]]
    serial = len(seen)
    seen[id(value)] = serial
    if isinstance(value, np.random.RandomState):
        return ["RandomState", serial, encode(value.get_state())]
    if isinstance(value, np.ndarray):
        return ["ndarray", serial, str(value.dtype), list(value.shape), value.tobytes().hex()]
    if isinstance(value, dict):
        return ["dict", serial, [(graph(k, seen), graph(v, seen)) for k, v in value.items()]]
    if type(value) in (list, tuple):
        return [type(value).__name__, serial, [graph(v, seen) for v in value]]
    if type(value) in (set, frozenset):
        return [type(value).__name__, serial, sorted([encode(v) for v in value], key=repr)]
    if isinstance(value, (pd.DataFrame, pd.Series)):
        return [type(value).__name__, serial, str(value.dtypes), encode(value.to_dict())]
    if isinstance(value, pd.Timestamp): return ["Timestamp", serial, value.isoformat()]
    if hasattr(value, "__dict__"):
        attrs = [(k, v) for k, v in vars(value).items()
                 if not ((isinstance(value, Agent) and k == "kernel")
                         or (isinstance(value, OrderBook) and k in ("book_log2", "_online_metric")))]
        return [type(value).__module__, type(value).__name__, serial,
                [(k, graph(v, seen)) for k, v in attrs]]
    return [type(value).__name__, serial, str(value)]


def rng_states(value, path="root", seen=None):
    seen = set() if seen is None else seen
    if isinstance(value, np.random.RandomState): return {path: encode(value.get_state())}
    if value is None or isinstance(value, (int, str, float, bool, np.ndarray, np.generic)): return {}
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)): return {}
    if id(value) in seen: return {}
    seen.add(id(value))
    if isinstance(value, dict): children = [(str(k), v) for k, v in value.items()]
    elif isinstance(value, (list, tuple)): children = [(str(i), v) for i, v in enumerate(value)]
    elif hasattr(value, "__dict__"): children = list(vars(value).items())
    else: return {}
    result = {}
    for key, child in children:
        if isinstance(value, Agent) and key == "kernel": continue
        if isinstance(value, OrderBook) and key in ("book_log2", "_online_metric"): continue
        result.update(rng_states(child, path + "/" + key, seen))
    return result


def scenario(seed, latency):
    value = {"scenario_id": "book-metric-online-state-controls-" + str(seed), "seed": seed,
        "horizon_ns": 2000000000,
        "exchange_config": {"symbol": "CTRL", "tick_size": 1, "lot_size": 1, "min_price": 1, "max_price": 1000000},
        "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100000, "kappa": .05,
            "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}},
        "agent_configs": [
            {"agent_type": "NoiseTrader", "count": 2, "params": {"arrival_rate_hz": 6., "order_size_mean": 10}},
            {"agent_type": "MarketMaker", "count": 1, "params": {"spread_ticks": 2, "depth_levels": 3,
                "size_per_level": 12, "rebalance_interval_ns": 300000000}},
            {"agent_type": "ValueTrader", "count": 1, "params": {"arrival_rate_hz": 4., "threshold_ticks": 2}},
            {"agent_type": "MomentumTrader", "count": 1, "params": {"arrival_rate_hz": 5., "threshold_ticks": 2}}]}
    if latency is not None:
        value["latency_config"] = latency
    if seed == 82009:
        value["exchange_config"].update(protocol_enforcement=True, stp_policy="cancel_oldest",
                                        ack_delay_ns=1500, compute_delay_ns=700)
    return value


def summary_aliases(kernel):
    result = []
    for entry in kernel.summary_log:
        a = kernel.agents[entry["AgentID"]]
        # Every diagnostic log remains retained in this candidate.
        matches = [(event_type, int(ns)) for ns, event_type, payload in a.log
                   if event_type == entry["EventType"] and payload is entry["Event"]]
        result.append([int(entry["AgentID"]), entry["EventType"], matches])
    return result


def run(config_value):
    if online is not None:
        if not authenticate_loaded() or not online.begin_episode(config_value, True):
            raise ValueError("candidate actual loaded source/domain admission failed")
    reset_abides_counters()
    np.random.seed(19301009)
    original_summary = Kernel.write_summary_log
    Kernel.write_summary_log = lambda self: None
    bindings = (Agent.logEvent, Agent.kernel_terminating, OrderBook.append_book_log2)
    try:
        with nullcontext({}) as counters:
            config = build_config(config_value)
            with enabled(True) as extractor: state = abides.run(config)
            frames = [trace.extract_trace(state), extractor(state)]
            blobs = []
            for frame in frames:
                stream = io.BytesIO()
                frame.to_parquet(stream, compression="snappy", index=False)
                blobs.append(stream.getvalue())
            kernel = state["agents"][0].kernel
            kernel_fields = {key: value for key, value in vars(kernel).items()
                if key not in ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir", "agents", "gym_agents", "custom_state")}
            # Structural kernel snapshot retains queue, every ledger column, summary,
            # scheduling/causal metadata and all deterministic state. Clock telemetry
            # is excluded because these controls make no timing claims.
            semantic_end = {key: value for key, value in state.items()
                            if key not in ("kernel_event_queue_elapsed_wallclock", "agents")}
            snapshot = graph([state["agents"], config, kernel_fields, semantic_end])
            rngs = {"numpy_global": encode(np.random.get_state()), **rng_states(config),
                    "kernel": encode(kernel.random_state.get_state())}
            aliases = summary_aliases(kernel)
            live_depth = [[int(a.id), symbol, depth, [encode(book.get_l1_bid_data()), encode(book.get_l1_ask_data()),
                                              encode(book.get_l2_bid_data(depth)),
                                              encode(book.get_l2_ask_data(depth)),
                                              encode(book.get_l3_bid_data(depth)),
                                              encode(book.get_l3_ask_data(depth))]]
                          for a in state["agents"] for symbol, book in getattr(a, "order_books", {}).items()
                          for depth in (0, 1, 10, -1)]
            metrics = [[int(a.id), symbol, encode(vars(tracker))]
                       for a in state["agents"] for symbol, tracker in getattr(a, "metric_trackers", {}).items()]
            payload = [blobs, snapshot, rngs, [Order._order_id_counter, Message._Message__message_id_counter],
                       aliases, metrics, live_depth]
            books = [book for a in state["agents"] for book in getattr(a, "order_books", {}).values()]
            path_witness = {"online_admitted": online is not None,
                "retained_history_rows": sum(len(book.book_log2) for book in books),
                "online_observation_rows": sum(getattr(getattr(book, "_online_metric", None), "rows", 0) for book in books)}
            if online is not None:
                assert path_witness["retained_history_rows"] == 0 and path_witness["online_observation_rows"] > 0
                assert all(type(book._online_metric) is online.OnlineMetric for book in books)
            else:
                assert path_witness["retained_history_rows"] > 0
            stats = {"counters": dict(counters), "private_diagnostic_log_rows": sum(len(a.log) for a in state["agents"]),
                     "rng_states": len(rngs), "summary_rows": len(kernel.summary_log),
                     "book_count": sum(len(getattr(a, "order_books", {})) for a in state["agents"]),
                     "kernel_type": type(kernel).__name__, "ttl_messages": kernel.ttl_messages,
                     "path_witness": path_witness}
        assert bindings == (Agent.logEvent, Agent.kernel_terminating, OrderBook.append_book_log2), "bindings not restored"
        return frames, payload, stats
    finally:
        Kernel.write_summary_log = original_summary


def main():
    OUTPUT.mkdir(parents=True, exist_ok=False)
    values = []
    stats = []
    for seed, latency in [(81009, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}),
            (82009, {"model": "deterministic", "params": {"mean_ns": 0}}),
            (83009, {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}),
            (84009, None)]:
        frames, payload, details = run(scenario(seed, latency))
        values.append({"seed": seed, "frames": frames, "payload": payload})
        stats.append({"seed": seed, "trace_rows": len(frames[0]), "message_rows": len(frames[1]),
                      "metric_trackers": len(payload[5]), "details": details})
    data = pickle.dumps(values, protocol=4)
    (OUTPUT / "SEMANTIC_VALUES.pkl").write_bytes(data)
    (OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps({"candidate_online": online is not None,
        "candidate_loaded_bindings_authenticated": online is not None, "timing_claim": False,
        "private_exclusions": ["OrderBook.book_log2", "OrderBook._online_metric"],
        "cases": stats, "values_sha256": hashlib.sha256(data).hexdigest()}, indent=2) + "\n")
    print(json.dumps(stats, indent=2))
    return 0

if __name__ == "__main__": raise SystemExit(main())
