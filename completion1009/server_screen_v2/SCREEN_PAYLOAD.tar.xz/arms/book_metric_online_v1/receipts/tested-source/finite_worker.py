"""Prepared untimed arithmetic worker; execution is scheduled by the parent."""
import argparse
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", type=Path, required=True)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
runtime = args.runtime.resolve()
sys.path.insert(0, str(runtime))
from bootstrap import activate
activate()
import hashlib
import itertools
import json
from types import SimpleNamespace
import warnings
import numpy as np
from abides_markets.agents.exchange_agent import ExchangeAgent

online = None
if (runtime / "online_metric.py").is_file():
    import online_metric as online
    from online_domain import authenticate_loaded
    if not authenticate_loaded():
        raise ValueError("candidate actual source binding admission failed")


def encode(value):
    if isinstance(value, np.generic):
        return [type(value).__name__, encode(value.item())]
    if type(value) is float:
        return ["float", value.hex()]
    if value is None or type(value) in (str, int, bool):
        return [type(value).__name__, value]
    if isinstance(value, dict):
        return [[key, encode(item)] for key, item in value.items()]
    if type(value) in (tuple, list):
        return [encode(item) for item in value]
    raise TypeError("unexpected finite control type")


def run(timestamps, emptiness):
    tracker = ExchangeAgent.MetricTracker(total_exchanged_volume=17, last_trade=23)
    exchange = SimpleNamespace(metric_trackers={"ABM": tracker}, MetricTracker=ExchangeAgent.MetricTracker)
    rows = [{"QuoteTime": timestamp, "bids": [] if bid else [None], "asks": [] if ask else [None]}
            for timestamp, (bid, ask) in zip(timestamps, emptiness)]
    accumulator = None
    if online is not None:
        accumulator = online.OnlineMetric()
        for row in rows:
            accumulator.observe(row["QuoteTime"], not row["bids"], not row["asks"])
    results = []
    # Analyze twice without modifying observations. This detects accidental
    # terminal-empty closure or total consumption on the first analysis.
    for repetition in range(2):
        error = None
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            try:
                if online is None:
                    ExchangeAgent.get_time_dropout(exchange, rows, "ABM")
                else:
                    accumulator.apply(exchange, "ABM")
            except Exception as exc:
                error = [type(exc).__name__, str(exc)]
        results.append({"fields": encode(vars(exchange.metric_trackers["ABM"])),
            "same_initial_tracker": exchange.metric_trackers["ABM"] is tracker,
            "warnings": [[row.category.__name__, str(row.message)] for row in caught], "error": error})
    return results


def main():
    args.out.mkdir(parents=True, exist_ok=False)
    values = [{"name": "empty-history-preserves-existing-tracker", "result": run([], [])}]
    patterns = list(itertools.product((False, True), repeat=4))
    schedules = [[0, 0, 0, 0], [0, 1, 1, 4], [10, 20, 40, 80], [80, 40, 20, 10],
                 [int(np.iinfo(np.int64).min), -1, 0, int(np.iinfo(np.int64).max)]]
    for schedule_index, times in enumerate(schedules):
        for mask_index, flags in enumerate(patterns):
            states = [(flags[i], flags[3-i]) for i in range(4)]
            for scalar in (int, np.int64):
                values.append({"name": "time%d-mask%d-%s" % (schedule_index, mask_index, scalar.__name__),
                    "result": run([scalar(time) for time in times], states)})
    for state in itertools.product((False, True), repeat=2):
        values.append({"name": "single-row-" + str(state), "result": run([np.int64(17)], [state])})
    blob = (json.dumps(values, indent=2, sort_keys=True) + "\n").encode()
    (args.out / "FINITE_VALUES.json").write_bytes(blob)
    (args.out / "WORKER_RECEIPT.json").write_text(json.dumps({"cases": len(values), "values_sha256": hashlib.sha256(blob).hexdigest(),
        "candidate_online": online is not None, "timing_claim": False, "simulation_execution": False}, indent=2) + "\n")
    print(json.dumps({"cases": len(values), "candidate_online": online is not None}))


if __name__ == "__main__":
    main()
