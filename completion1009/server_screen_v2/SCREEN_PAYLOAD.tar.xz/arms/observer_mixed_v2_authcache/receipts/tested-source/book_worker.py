#!/usr/bin/env python3
"""Prepared active/inactive metric witness controls; root schedules execution."""
import argparse
from pathlib import Path
import sys
parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
RUNTIME = Path(args.runtime).resolve()
OUTPUT = Path(args.out).resolve()
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
from contextlib import nullcontext
import hashlib
import json
import warnings
import numpy as np
from abides_markets.order_book import OrderBook
from abides_markets.price_level import PriceLevel
from abides_markets.agents.exchange_agent import ExchangeAgent
from abides_markets.orders import LimitOrder, Order, Side

def authenticate_loaded():
    from abides_markets import order_book, price_level
    from abides_markets.agents import exchange_agent
    from abides_fork import config, agents
    expected = ((order_book, "vendor/abides/abides-markets/abides_markets/order_book.py", "OrderBook", ("__init__", "append_book_log2", "get_l2_bid_data", "get_l2_ask_data")),
                (price_level, "vendor/abides/abides-markets/abides_markets/price_level.py", "PriceLevel", ("__init__", "add_order", "total_quantity")),
                (exchange_agent, "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py", "ExchangeAgent", ("get_time_dropout", "_original_time_dropout", "analyse_order_book", "kernel_terminating")))
    import types
    for module, relative, classname, names in expected:
        path = RUNTIME / relative
        assert Path(module.__file__).resolve() == path, "loaded runtime module mismatch"
        tree = compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
        cls_code = next(c for c in tree.co_consts if type(c) is types.CodeType and c.co_name == classname)
        cls = getattr(module, classname)
        assert cls.__module__ == module.__name__, "loaded class module mismatch"
        for name in names:
            function = getattr(cls, name)
            if isinstance(function, property): function = function.fget
            expected_code = next(c for c in cls_code.co_consts if type(c) is types.CodeType and c.co_name == name)
            assert type(function) is types.FunctionType and function.__code__ == expected_code, "loaded method differs: " + name
            assert function.__globals__["__file__"] == str(path), "loaded function file mismatch"
    assert order_book.PriceLevel is price_level.PriceLevel and exchange_agent.OrderBook is order_book.OrderBook
    assert config.ExchangeAgent is exchange_agent.ExchangeAgent
    assert agents.AGENT_REGISTRY == {name: getattr(agents, name) for name in ("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader")}

def encode(value):
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.ndarray):
        return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if isinstance(value, dict): return [type(value).__name__, [(encode(k), encode(v)) for k, v in value.items()]]
    if type(value) in (list, tuple): return [type(value).__name__, [encode(v) for v in value]]
    if type(value) is Side: return ["Side", value.value]
    if hasattr(value, "__dict__"): return [type(value).__module__, type(value).__name__, encode(vars(value))]
    return [type(value).__name__, repr(value)]


def levels(spec, side):
    result = []
    for index, (visible, hidden) in enumerate(spec):
        orders = [(LimitOrder(1, 1, "ABM", qty, side, 100 + index,
                              is_hidden=False, order_id=10 * index + n), {})
                  for n, qty in enumerate(visible)]
        orders += [(LimitOrder(1, 1, "ABM", qty, side, 100 + index,
                               is_hidden=True, order_id=10000 + 10 * index + n), {})
                   for n, qty in enumerate(hidden)]
        result.append(PriceLevel(orders))
    return result


POS = [([3, 4], [])]
ZERO = [([3, -3], [])]
NEG = [([-2, -1], [])]
HIDDEN = [([], [12])]
MIXED = ZERO + NEG + HIDDEN + POS + [([8], [])]


def sequences():
    yield "no_snapshots", []
    yield "one_empty", [(10, [], [])]
    yield "equal_timestamps", [(10, [], POS), (10, POS, []), (10, [], []), (10, POS, POS)]
    yield "all_empty", [(10, [], []), (11, [], []), (20, [], [])]
    yield "closed_and_unclosed_intervals", [(0, POS, POS), (2, [], POS), (5, [], []),
                                          (8, POS, []), (13, POS, POS), (21, [], [])]
    yield "repeated_boundaries", [(0, [], []), (0, [], POS), (3, POS, POS),
                                 (3, [], []), (3, POS, POS)]
    yield "nonpositive_and_hidden_quantity", [(0, MIXED, HIDDEN), (3, ZERO, NEG),
                                             (8, POS, MIXED), (12, [], [])]
    yield "nonmonotonic_timestamps", [(8, [], []), (3, POS, POS), (-2, [], POS), (10, POS, [])]
    yield "numpy_timestamps", [(np.int64(-5), [], POS), (np.int64(2), POS, []),
                               (np.int64(8), POS, POS)]
    yield "float_timestamp_original_fallback", [(0.5, [], []), (2.5, POS, POS)]
    yield "large_timestamp_original_fallback", [(2**65, [], []), (2**65 + 3, POS, POS)]
    yield "int64_wraparound_original_metric", [(np.iinfo(np.int64).min, [], []),
                                             (np.iinfo(np.int64).max, POS, POS)]


def execute(rows, depth, active):
    Order._order_id_counter = 0
    with nullcontext({}) as counters:
        exchange = ExchangeAgent(0, 0, 100, ["ABM"], random_state=np.random.RandomState(100),
                                 book_log_depth=depth, log_orders=None)
        book = exchange.order_books["ABM"]
        emitted, live = [], []
        with warnings.catch_warnings(record=True) as observed:
            warnings.simplefilter("always")
            try:
                for timestamp, bids, asks in rows:
                    exchange.current_time = timestamp
                    book.bids, book.asks = levels(bids, Side.BID), levels(asks, Side.ASK)
                    live.append([encode(book.get_l2_bid_data(depth)), encode(book.get_l2_ask_data(depth)),
                                 encode(book.get_l3_bid_data(depth)), encode(book.get_l3_ask_data(depth))])
                    book.append_book_log2()
                    row = book.book_log2[-1]
                    emitted.append([encode(row["QuoteTime"]), len(row["bids"]) != 0, len(row["asks"]) != 0])
                    # Inactive unsupported episodes retain exact full depth arrays.
                    if not active:
                        emitted[-1].extend([encode(row["bids"]), encode(row["asks"])])
                    assert book.get_l2_bid_data(depth) == [x for x in book.get_l2_bid_data(depth)], "live depth changed"
                exchange.get_time_dropout(book.book_log2, "ABM")
                outcome = ["metrics", encode(exchange.metric_trackers)]
            except Exception as error:
                outcome = ["exception", type(error).__name__, str(error)]
            warning_values = [(item.category.__name__, str(item.message)) for item in observed]
        return {"outcome": outcome, "warnings": warning_values, "emitted": emitted,
                "live": live, "ids": Order._order_id_counter, "counters": dict(counters)}


def main():
    authenticate_loaded()
    if (RUNTIME / "observer.py").exists():
        import observer
        from observer_domain import authenticate_loaded as authenticate_composition
        assert authenticate_composition(), "combined domain differs"
    else:
        observer = None
    cases = []
    for depth in (None, 0, 1, 2, 3, 10, -1, -2, -4, False, True, np.int64(1)):
        for name, rows in sequences():
            for active in (False, True):
                if observer is not None:
                    if active: observer.begin_episode({"agent_configs": [{"agent_type": "NoiseTrader", "count": 1}]})
                    else: observer.finish_episode()
                try:
                    result = execute(rows, depth, active)
                finally:
                    if observer is not None: observer.finish_episode()
                result.pop("counters")
                cases.append({"name": name + "_depth_" + repr(depth) + "_active_" + str(active), "values": result})
    data = (json.dumps(cases, indent=2) + "\n").encode()
    OUTPUT.mkdir(parents=True, exist_ok=False)
    (OUTPUT / "FINITE_VALUES.json").write_bytes(data)
    (OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps({"loaded_bindings_authenticated": True, "cases": len(cases), "timing_claim": False, "values_sha256": hashlib.sha256(data).hexdigest()}, indent=2) + "\n")
    print("finite cases:", len(cases))
    return 0

if __name__ == "__main__": raise SystemExit(main())
