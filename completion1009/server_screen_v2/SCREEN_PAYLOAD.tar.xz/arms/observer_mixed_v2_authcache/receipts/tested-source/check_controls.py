#!/usr/bin/env python3
"""Prepared serial combined controls driver; never time these runs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--out", required=True)
parser.add_argument("--finite-only", action="store_true")
args = parser.parse_args()
OUTPUT = Path(args.out).resolve()


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(path):
    return {str(p.relative_to(path)): sha(p) for p in sorted(path.rglob("*"))
            if p.is_file() and not p.name.startswith("._") and "__pycache__" not in p.parts}
def hashes():
    return {"runtime_sha256": inventory(ROOT / "runtime"), "candidate_runtime_sha256": inventory(HERE / "runtime"),
            "candidate_source_sha256": {p.name: sha(p) for p in sorted(HERE.glob("*.py")) if not p.name.startswith("._")},
            "manifest_sha256": sha(HERE / "SNAPSHOT_MANIFEST.json"),
            "patch_manifest_sha256": sha(HERE / "PATCH_MANIFEST.json"),
            "source_diff_sha256": sha(HERE / "SOURCE_DIFF.patch")}


def authenticate_snapshot():
    manifest = json.loads((HERE / "SNAPSHOT_MANIFEST.json").read_text())
    assert inventory(HERE / "runtime") == {row["path"]: row["sha256"] for row in manifest["files"]}, "candidate snapshot differs"
    assert sha(ROOT / "RUNTIME_MANIFEST.json") == manifest["frozen_manifest_sha256"]
    assert sha(HERE / "PATCH_MANIFEST.json") == manifest["patch_manifest_sha256"]
    patch = json.loads((HERE / "PATCH_MANIFEST.json").read_text())
    assert sha(HERE / "SOURCE_DIFF.patch") == patch["source_diff_sha256"]
    assert {p.name: sha(p) for p in sorted(HERE.glob("*.py")) if not p.name.startswith("._")} == patch["controls_source_sha256"]
    for row in json.loads((ROOT / "RUNTIME_MANIFEST.json").read_text())["files"]:
        assert sha(ROOT / row["path"]) == row["sha256"], "original runtime differs"


def launch(worker, runtime, out):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT.parent / ".runtime")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    cmd = ["/usr/bin/python3", str(HERE / worker), "--runtime", str(runtime), "--out", str(out)]
    with (OUTPUT / (out.name + ".log")).open("w") as stream:
        result = subprocess.run(cmd, cwd=runtime, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    assert result.returncode == 0, worker + " failed: " + out.name
    return {"worker": worker, "runtime": str(runtime), "command": cmd, "exit_code": result.returncode,
            "receipt_sha256": sha(out / "WORKER_RECEIPT.json")}


def launch_lazy(runtime, out, expect_lazy):
    env = os.environ.copy()
    env.update(PYTHONPATH=str(ROOT.parent / ".runtime"), PYTHONDONTWRITEBYTECODE="1")
    cmd = ["/usr/bin/python3", str(HERE / "lazy_worker.py"), "--runtime", str(runtime), "--out", str(out)]
    if expect_lazy: cmd.append("--expect-lazy")
    with (OUTPUT / (out.name + ".log")).open("w") as stream:
        result = subprocess.run(cmd, cwd=runtime, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    assert result.returncode == 0, "lazy worker failed: " + out.name
    return {"worker": "lazy_worker.py", "runtime": str(runtime), "command": cmd, "exit_code": result.returncode,
            "receipt_sha256": sha(out / "CONTROL_RECEIPT.json")}


def compare_outcomes(a, b):
    import pandas as pd
    assert a["kind"] == b["kind"]
    if a["kind"] == "exception": assert a == b
    else:
        pd.testing.assert_frame_equal(a["frame"], b["frame"], check_dtype=True, check_exact=True, rtol=0, atol=0)
        assert a["parquet"] == b["parquet"], "Parquet bytes differ"


def main():
    if OUTPUT.exists(): raise ValueError("control attempt already exists")
    authenticate_snapshot()
    OUTPUT.mkdir(parents=True)
    before = hashes()
    plan = {"schema": "t3-observer-mixed-authcache-controls-v2", "timing_claim": False, "rankable": False,
        "finite_only": args.finite_only,
        "private_exclusion": "Agent.log exploratory contents/observer storage; only admitted book_log2 bids/asks historical depth payload representation; nondeterministic clocks/log directory; Agent.kernel separately represented",
        "preserved": "QuoteTime and all snapshot keys/order/side presence; summary event fields/aliases; complete business/callback/scalar metrics/book/history/live depth/queue/ledger/RNG/ID; canonical/message dtype/value/bytes; full numeric inference rows/index and replay",
        **before}
    (OUTPUT / "PREDECLARED_PLAN.json").write_text(json.dumps(plan, indent=2) + "\n")
    result = {**plan, "all_passed": False, "runs": [], "cases": [], "failures": []}
    try:
        for arm, runtime in (("original", ROOT / "runtime"), ("observer", HERE / "runtime")):
            result["runs"].append(launch("controls.py", runtime, OUTPUT / (arm + "_finite")))
        a, b = [pickle.loads((OUTPUT / (arm + "_finite") / "FINITE_VALUES.pkl").read_bytes()) for arm in ("original", "observer")]
        assert len(a["cases"]) == len(b["cases"])
        for left, right in zip(a["cases"], b["cases"]):
            assert left["name"] == right["name"]
            compare_outcomes(left["outcome"], right["outcome"])
            assert left["projected_rows"] == right["projected_rows"], "numeric inference rows/index differ: " + left["name"]
            result["cases"].append({"name": left["name"], "passed": True, "outcome": left["outcome"]["kind"], "observer_counters": right["observer_counters"]})
        assert a["summary_cases"] == b["summary_cases"], "summary payload/copy aliases differ"
        warm = json.loads((OUTPUT / "observer_finite/WORKER_RECEIPT.json").read_text())["warm_cache_controls"]
        assert len(warm) == 19, "warm cache mutation/refusal/count controls incomplete"
        result["cases"].append({"family": "warm_cache_loaded_mutations", "cases": len(warm), "passed": True, "checks": warm})
        for arm, runtime in (("original", ROOT / "runtime"), ("observer", HERE / "runtime")):
            result["runs"].append(launch("book_worker.py", runtime, OUTPUT / (arm + "_book")))
        a, b = [(OUTPUT / (arm + "_book") / "FINITE_VALUES.json").read_bytes() for arm in ("original", "observer")]
        assert a == b and len(json.loads(a)) == 288, "active/inactive witness/metric/live-depth/exception controls differ"
        result["cases"].append({"family": "active_inactive_metric_witness", "cases": 288, "passed": True})
        for arm, runtime in (("original", ROOT / "runtime"), ("observer", HERE / "runtime")):
            result["runs"].append(launch_lazy(runtime, OUTPUT / (arm + "_lazy"), arm == "observer"))
        a, b = [(OUTPUT / (arm + "_lazy") / "control_state.pkl").read_bytes() for arm in ("original", "observer")]
        assert a == b, "lazy pair-distance/default-latency/RNG/public-binding controls differ"
        result["cases"].append({"family": "lazy_import_default_latency", "cases": 34, "passed": True})
        if not args.finite_only:
            for arm, runtime in (("original", ROOT / "runtime"), ("observer", HERE / "runtime")):
                result["runs"].append(launch("semantic_worker.py", runtime, OUTPUT / (arm + "_semantic")))
            a, b = [pickle.loads((OUTPUT / (arm + "_semantic") / "SEMANTIC_VALUES.pkl").read_bytes()) for arm in ("original", "observer")]
            assert len(a) == len(b) == 4
            import pandas as pd
            for left, right in zip(a, b):
                assert left["seed"] == right["seed"]
                for x, y in zip(left["frames"], right["frames"]):
                    pd.testing.assert_frame_equal(x, y, check_dtype=True, check_exact=True, rtol=0, atol=0)
                assert len(left["payload"]) == len(right["payload"]) == 9
                for name, x, y in zip(("Parquet", "retained state/aliases", "RNG", "IDs", "summary aliases", "live depths", "AGENT_TYPE/summary log values+aliases", "Agent.kernel aliases", "snapshot timestamp/presence/metrics/consumers"), left["payload"], right["payload"]):
                    assert x == y, name + " differs at seed " + str(left["seed"])
                assert right["details"]["observer"]["order_rows"] > 0
                result["cases"].append({"seed": left["seed"], "passed": True, "trace_rows": len(left["frames"][0]), "message_rows": len(left["frames"][1]), "details": right["details"]})
        assert before == hashes(), "sources changed during controls"
        result.update(all_passed=True, sources_unchanged=True)
    except Exception as error:
        result["failures"].append({"type": type(error).__name__, "message": str(error)})
    (OUTPUT / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if not key.endswith("sha256")}, indent=2))
    return 0 if result["all_passed"] else 1


if __name__ == "__main__": raise SystemExit(main())
