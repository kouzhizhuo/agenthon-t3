#!/usr/bin/env python3
"""Prepared finite combined-observer controls; execution requires root CPU slot."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import pickle
import sys
from types import SimpleNamespace

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
RUNTIME, OUTPUT = Path(args.runtime).resolve(), Path(args.out).resolve()
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
import numpy as np
import pandas as pd
from abides_core.agent import Agent
from abides_core.kernel import Kernel
from abides_fork import trace
from abides_markets.orders import LimitOrder, MarketOrder, Order, Side
if (RUNTIME / "observer.py").exists():
    import observer
    from observer_domain import authenticate_loaded
else:
    observer = None


def outcome(agents):
    try:
        frame = trace.extract_trace({"agents": agents})
        stream = io.BytesIO()
        frame.to_parquet(stream, compression="snappy", index=False)
        return {"kind": "frame", "frame": frame, "parquet": stream.getvalue()}
    except Exception as error:
        return {"kind": "exception", "type": type(error).__name__, "message": str(error)}


def scenario(): return {"agent_configs": [{"agent_type": "NoiseTrader", "count": 1}]}
def order(aid, oid, qty=3, price=100, fill=100, side=Side.BID):
    value = LimitOrder(aid, 1612517400000000000, "ABM", qty, side, price, order_id=oid)
    value.fill_price = fill
    return value


def rows():
    for number in (4, (1 << 53) + 1, (1 << 53) + 2):
        yield "composed_diagnostic_numeric_rows_" + str(number), [
            (0, 9, "diagnostic", "BID_DEPTH", [(99, 4)]),
            (0, 9, "imbalance", "IMBALANCE", ([(99, 4)], [(101, 5)])),
            (0, 10, "order", "ORDER_EXECUTED", order(0, number, 1)),
            (0, 10, "order", "CANCEL_SUBMITTED", order(0, number + 1, 2)),
            (0, 10, "diagnostic", "ASK_DEPTH", [(101, 5)]),
            (0, 10, "order", "ORDER_EXECUTED", order(0, number, 3)),
            (0, 11, "diagnostic", "QuerySpreadMsg", SimpleNamespace(symbol="ABM", depth=3))]
    yield "market_missing_limit_column", [(0, 10, "order", "ORDER_SUBMITTED",
        MarketOrder(0, 1612517400000000000, "ABM", 3, Side.BID, order_id=4))]
    yield "producer_basic", [(0, 10, "order", "ORDER_SUBMITTED", order(0, 4)),
        (0, 11, "order", "ORDER_ACCEPTED", order(0, 4)),
        (0, 12, "order", "ORDER_EXECUTED", order(0, 4, qty=1)),
        (0, 13, "order", "ORDER_EXECUTED", order(0, 4, qty=2))]
    yield "equal_time_cross_agent_emission", [
        (1, 10, "order", "ORDER_EXECUTED", order(1, 8, 2, side=Side.ASK)),
        (0, 10, "order", "ORDER_EXECUTED", order(0, 8, 1)),
        (0, 10, "quote", "BEST_BID", ("ABM", 99, 5)),
        (1, 10, "quote", "BEST_BID", ("ABM", 100, 6)),
        (0, 10, "quote", "BEST_ASK", ("ABM", 101, 7)),
        (1, 10, "quote", "BEST_ASK", ("ABM", 102, 8))]
    yield "time_sort_before_fill_finality", [
        (0, 20, "order", "ORDER_EXECUTED", order(0, 4, 1)),
        (0, 10, "order", "ORDER_EXECUTED", order(0, 4, 2)),
        (0, 20, "order", "ORDER_EXECUTED", order(0, 4, 3))]
    yield "agent_id_payload_override", [(0, 10, "order", "ORDER_SUBMITTED", order(19, 4))]
    yield "fills_only_missing_price", [(0, 10, "order", "ORDER_EXECUTED", order(0, 4, fill=None))]
    yield "no_fills", [(0, 10, "order", "ORDER_SUBMITTED", order(0, 4, fill=None))]
    yield "diagnostic_order_zero_canonical", [(0, 10, "order", "CANCEL_SUBMITTED", order(0, 4))]
    yield "no_order_columns_original_exception", [(0, 10, "raw", "FINAL_HOLDINGS", "Cash: 10")]
    yield "quote_and_diagnostic_empty_order_frame", [(0, 10, "quote", "BEST_BID", ("ABM", 100, 3)),
        (0, 11, "order", "CANCEL_SUBMITTED", order(0, 4))]
    yield "diagnostic_alias_snapshot", [(0, 10, "raw", "HOLDINGS_UPDATED", {"ABM": 3}),
        (0, 11, "order", "ORDER_SUBMITTED", order(0, 4))]
    yield "malformed_quote_symbol_replay", [(0, 10, "quote", "BEST_BID", ("A,B", 100, 3)),
        (0, 11, "order", "ORDER_SUBMITTED", order(0, 4))]
    yield "noninteger_timestamp_original_zero", [(0, "unknown", "order", "ORDER_SUBMITTED", order(0, 4))]
    for number in ((1 << 53) - 1, 1 << 53, (1 << 53) + 1, (1 << 53) + 2):
        yield "large_adjacent_id_" + str(number), [
            (0, 10, "order", "ORDER_EXECUTED", order(0, number)),
            (0, 11, "order", "ORDER_EXECUTED", order(0, number + 1)),
            (0, 12, "order", "CANCEL_SUBMITTED", order(0, number + 2))]
        yield "large_quantity_price_" + str(number), [(0, 10, "order", "ORDER_SUBMITTED", order(0, 4, number, number)),
            (0, 10, "quote", "BEST_BID", ("ABM", number, number))]
    for key, value in (("EventTime", 77), ("EventType", "ORDER_EXECUTED"), ("agent_id", 19), ("ScalarEventValue", "ABM,101,4")):
        payload = {"agent_id": 0, "order_id": 4, "side": Side.BID, "quantity": 3,
                   "limit_price": 100, "fill_price": 100, key: value}
        yield "raw_reserved_override_" + key, [(0, 10, "raw", "ORDER_SUBMITTED", payload)]


def projected_rows(agents):
    """Normalize only the already-declared private diagnostic scalar payload.

    Exact row positions, event type/time and all raw reserved/numeric fields are
    compared independently of final frames to exercise full replay inputs.
    """
    source = observer.replay_state({"agents": agents})["agents"] if observer and observer.STATE is not None else agents
    fields = ("ScalarEventValue", "agent_id", "order_id", "side", "quantity", "limit_price", "fill_price", "EventTime", "EventType")
    def encode(value):
        if type(value) is Side: return ("Side", value.value)
        if isinstance(value, np.generic): return (type(value).__name__, value.item())
        if type(value) is dict: return {key: encode(child) for key, child in value.items()}
        if type(value) in (list, tuple): return (type(value).__name__, tuple(encode(child) for child in value))
        return value
    result = []
    for agent in source:
        log = []
        for timestamp, event_type, payload in agent.log:
            if type(payload) is dict: payload = {key: payload[key] for key in fields if key in payload}
            elif payload is not None and type(payload) not in (str, int, float, bool): payload = ""
            log.append((encode(timestamp), event_type, encode(payload)))
        result.append((agent.id, log))
    return result


def run_rows(name, values, agent_type="Finite", logging=True, active=True):
    if observer is not None:
        if active: observer.begin_episode(scenario())
        else: observer.finish_episode()
    agents = [Agent(i, type=agent_type, log_events=logging, random_state=np.random.RandomState(100 + i))
              for i in range(1 + max((row[0] for row in values), default=0))]
    for aid, timestamp, kind, event_type, payload in values:
        agent = agents[aid]
        agent.current_time = timestamp
        if kind == "order":
            if observer is not None: observer.order(agent, event_type, payload, deepcopy_event=False)
            else: agent.logEvent(event_type, payload.to_dict(), deepcopy_event=False)
            payload.quantity += 100  # Snapshot must remain immutable after producer.
        elif kind == "quote":
            if observer is not None: observer.quote(agent, event_type, *payload)
            else: agent.logEvent(event_type, "{},{},{}".format(*payload))
        elif kind == "diagnostic":
            if observer is not None: observer.diagnostic(agent, event_type, payload)
            else: agent.logEvent(event_type, payload)
        elif kind == "imbalance":
            bids, asks = payload
            if observer is not None: observer.imbalance(agent, bids, asks)
            else: agent.logEvent(event_type, [sum([x[1] for x in bids]), sum([x[1] for x in asks])])
        else:
            agent.logEvent(event_type, payload)
    result = outcome(agents)
    inference = projected_rows(agents)
    counters = vars(observer.STATE).copy() if observer is not None and observer.STATE is not None else {}
    counters.pop("inference", None); counters.pop("contract", None)
    if observer is not None: observer.finish_episode()
    return {"name": name, "outcome": result, "projected_rows": inference, "observer_counters": counters}


def summary_cases():
    results = []
    for copy_event in (False, True):
        for logging in (False, True):
            if observer is not None: observer.begin_episode(scenario())
            agent = Agent(0, type="Finite", log_events=logging, random_state=np.random.RandomState(1))
            kernel = SimpleNamespace(summary_log=[])
            def append_summary(aid, event_type, event): kernel.summary_log.append((aid, event_type, event))
            kernel.append_summary_log = append_summary
            agent.kernel = kernel
            payload = {"cash": 10}
            agent.current_time = 10
            agent.logEvent("SUMMARY", payload, True, deepcopy_event=copy_event)
            payload["cash"] = 20
            alias = [(row[2] is log[2]) for row in kernel.summary_log for log in agent.log if row[1] == log[1]]
            results.append({"name": "summary_copy_" + str(copy_event) + "_logging_" + str(logging),
                            "summary": kernel.summary_log, "original_payload_alias": [row[2] is payload for row in kernel.summary_log], "log_alias": alias})
            if observer is not None: observer.finish_episode()
    return results


def admission_controls():
    if observer is None: return []
    results = []
    for name, value, authenticated in (("supported", scenario(), True), ("changed_source", scenario(), False),
            ("unsupported_strategy", {"agent_configs": [{"agent_type": "Custom", "count": 1}]}, True),
            ("boolean_count", {"agent_configs": [{"agent_type": "NoiseTrader", "count": True}]}, True),
            ("empty_roster", {"agent_configs": []}, True)):
        admitted = observer.begin_episode(value, authenticated)
        assert admitted == (name == "supported"), name
        results.append({"name": name, "admitted": admitted})
    observer.finish_episode()
    from abides_markets.agents.trading_agent import TradingAgent
    original = TradingAgent.order_executed
    try:
        TradingAgent.order_executed = lambda self, value: None
        assert authenticate_loaded() is False, "modified callable domain admitted"
        results.append({"name": "changed_loaded_method", "admitted": False})
    finally:
        TradingAgent.order_executed = original
    assert authenticate_loaded(), "loaded method restoration differs"
    for name in ("order", "quote", "record_log", "diagnostic", "imbalance"):
        original = getattr(observer, name)
        try:
            setattr(observer, name, lambda *args, **kwargs: None)
            assert authenticate_loaded() is False, "changed observer helper admitted: " + name
            results.append({"name": "changed_observer_" + name, "admitted": False})
        finally:
            setattr(observer, name, original)
    original = trace._extract_trace_observer_original
    try:
        trace._extract_trace_observer_original = lambda value: None
        assert authenticate_loaded() is False, "changed extractor fallback admitted"
        results.append({"name": "changed_extractor_fallback", "admitted": False})
    finally:
        trace._extract_trace_observer_original = original
    assert authenticate_loaded(), "helper/fallback restoration differs"
    import abides_markets.utils as utils
    from abides_fork import config
    from abides_markets import order_book, price_level
    from abides_markets.agents import exchange_agent
    for owner, name in ((utils, "__getattr__"), (utils, "generate_latency_model"),
            (utils, "generate_uniform_random_pairwise_dist_on_line"), (config, "generate_latency_model"),
            (order_book.OrderBook, "append_book_log2"), (exchange_agent.ExchangeAgent, "get_time_dropout"),
            (price_level.PriceLevel, "total_quantity")):
        original = getattr(owner, name)
        try:
            setattr(owner, name, lambda *a, **k: None)
            assert authenticate_loaded() is False, "combined loaded binding admitted: " + name
            results.append({"name": "changed_combined_" + owner.__name__ + "_" + name, "admitted": False})
        finally:
            setattr(owner, name, original)
    original = order_book.OrderBook.get_l2_bid_data.__defaults__
    try:
        order_book.OrderBook.get_l2_bid_data.__defaults__ = (1,)
        assert authenticate_loaded() is False, "modified depth default admitted"
        results.append({"name": "changed_depth_default", "admitted": False})
    finally:
        order_book.OrderBook.get_l2_bid_data.__defaults__ = original
    assert authenticate_loaded(), "combined bindings restoration differs"
    return results


def warm_cache_controls():
    """Refuse live mutations after a successful admission without recompiling."""
    if observer is None: return []
    import types
    import observer_domain as domain
    from abides_fork import agents, config
    from abides_markets import order_book
    from abides_markets.agents import trading_agent
    import abides_markets.utils as utils
    assert domain.CACHE_VERSION == 1
    assert authenticate_loaded(), "first warm cache admission differs"
    counts = (domain._CACHE_COMPILES, domain._CACHE_AST_PARSES)
    assert counts == (len(domain._SOURCE_PINS), len(domain._SOURCE_PINS)), "source expectations not compiled once"
    assert authenticate_loaded(), "second warm cache admission differs"
    assert counts == (domain._CACHE_COMPILES, domain._CACHE_AST_PARSES), "unchanged warm admission recompiled"
    results = [{"name": "warm_cache_reused_exact_source_expectations", "admitted": True, "compile_count": counts[0], "ast_parse_count": counts[1]}]
    original = trading_agent.TradingAgent.order_executed
    cloned_globals = dict(original.__globals__)
    clones = types.FunctionType(original.__code__, cloned_globals, original.__name__, original.__defaults__, original.__closure__)
    clones.__kwdefaults__ = original.__kwdefaults__
    mutations = [
        (trading_agent.TradingAgent, "order_executed", lambda *a, **k: None, "callable"),
        (trading_agent.TradingAgent, "order_executed", clones, "owning_globals"),
        (order_book.OrderBook.get_l2_bid_data, "__defaults__", (1,), "depth_default"),
        (order_book.OrderBook, "__module__", "modified_after_admission", "class_module"),
        (agents, "AGENT_REGISTRY", {}, "registry"),
        (config, "AGENT_REGISTRY", dict(agents.AGENT_REGISTRY), "registry_identity"),
        (trading_agent, "TradingAgent", type("TradingAgent", trading_agent.TradingAgent.__bases__, dict(vars(trading_agent.TradingAgent))), "class_export_identity"),
        (observer, "Episode", type("Episode", observer.Episode.__bases__, dict(vars(observer.Episode))), "episode_class_identity"),
        (observer, "ORDER_FIELDS", ("modified",), "observer_constant"),
        (trace, "TRACE_COLUMNS", ["modified"], "trace_constant"),
        (order_book, "__file__", str(RUNTIME / "unshipped_order_book.py"), "module_path"),
        (utils, "pdist", lambda *a: None, "scipy_identity"),
    ]
    for owner, name, replacement, label in mutations:
        had_value = name in vars(owner) if owner is utils and name == "pdist" else hasattr(owner, name)
        original = getattr(owner, name) if had_value else None
        try:
            setattr(owner, name, replacement)
            assert authenticate_loaded() is False, "warm cached admission ignored mutation: " + label
            results.append({"name": "warm_cache_mutation_" + label, "admitted": False})
        finally:
            if had_value: setattr(owner, name, original)
            else: delattr(owner, name)
        assert authenticate_loaded(), "warm cache restoration differs: " + label
    # Redirect the exact module source read only in this test. The on-disk
    # frozen runtime remains unchanged; differing bytes must refuse admission.
    original_reader = Path.read_bytes
    target = (RUNTIME / "vendor/abides/abides-markets/abides_markets/order_book.py").resolve()
    def changed_source(self):
        data = original_reader(self)
        return data + b"\n# mutation after warm admission\n" if self.resolve() == target else data
    try:
        Path.read_bytes = changed_source
        assert authenticate_loaded() is False, "warm cache admitted differing source bytes"
        results.append({"name": "warm_cache_changed_source_bytes", "admitted": False})
    finally:
        Path.read_bytes = original_reader
    assert authenticate_loaded(), "warm source reader restoration differs"
    key = next(key for key in domain._SOURCE_CACHE if key[0] == target)
    original = domain._SOURCE_CACHE[key]
    for label, replacement in (("malformed", {"code": None}), ("replaced_same_shape", dict(original)), ("missing", None)):
        try:
            if replacement is None: del domain._SOURCE_CACHE[key]
            else: domain._SOURCE_CACHE[key] = replacement
            assert authenticate_loaded() is False, "warm cache ignored corrupted expected entry: " + label
            results.append({"name": "warm_cache_corruption_" + label, "admitted": False})
        finally:
            domain._SOURCE_CACHE[key] = original
        assert authenticate_loaded(), "warm cache entry restoration differs: " + label
    original_tree = original["tree"]
    try:
        original["tree"] = None
        assert authenticate_loaded() is False, "warm cache ignored malformed cached AST entry"
        results.append({"name": "warm_cache_corruption_malformed_tree", "admitted": False})
    finally:
        original["tree"] = original_tree
    assert authenticate_loaded(), "warm malformed tree restoration differs"
    assert counts == (domain._CACHE_COMPILES, domain._CACHE_AST_PARSES), "warm mutation checks recompiled"
    results.append({"name": "warm_cache_counts_stable_after_refusals", "admitted": True, "compile_count": counts[0], "ast_parse_count": counts[1]})
    return results


def termination_cases():
    if observer is None: return []
    results = []
    for active in (False, True):
        for skip_log in (False, True):
            if active: observer.begin_episode(scenario())
            else: observer.finish_episode()
            agent = Agent(0, type="Finite", random_state=np.random.RandomState(1))
            agent.kernel = SimpleNamespace(skip_log=skip_log)
            actual = observer.skip_termination(agent)
            assert actual == (active and skip_log)
            results.append({"active": active, "skip_log": skip_log, "discarded_frame": actual})
    observer.finish_episode()
    return results


def main():
    if OUTPUT.exists(): raise ValueError("finite output already exists")
    OUTPUT.mkdir(parents=True)
    if observer is not None: assert authenticate_loaded(), "source domain authentication failed"
    saved_ids = Order._order_id_counter
    results = []
    for name, values in rows(): results.append(run_rows(name, values))
    for name, values in rows():
        if name.startswith("composed_diagnostic_numeric_rows_"):
            results.append(run_rows("inactive_" + name, values, active=False))
    for logging in (False, True):
        results.append(run_rows("logging_flag_" + str(logging), [(0, 10, "order", "ORDER_SUBMITTED", order(0, 4))], logging=logging))
    results.append(run_rows("none_agent_type_no_scalar", [(0, 10, "order", "ORDER_SUBMITTED", order(0, 4))], agent_type=None))
    results.append(run_rows("none_agent_type_later_scalar", [(0, 10, "order", "CANCEL_SUBMITTED", order(0, 4)),
        (0, 11, "raw", "FINAL_HOLDINGS", "Cash: 10")], agent_type=None))
    assert Order._order_id_counter == saved_ids, "finite ID counter changed"
    value = {"cases": results, "summary_cases": summary_cases()}
    data = pickle.dumps(value, protocol=4)
    (OUTPUT / "FINITE_VALUES.pkl").write_bytes(data)
    receipt = {"schema": "t3-observer-mixed-finite-worker-v1", "cases": len(results),
        "summary_cases": len(value["summary_cases"]), "admission": admission_controls(),
        "warm_cache_controls": warm_cache_controls(),
        "termination": termination_cases(),
        "values_sha256": hashlib.sha256(data).hexdigest(), "source_domain_authenticated": observer is None or authenticate_loaded(),
        "timing_claim": False}
    (OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__": main()
