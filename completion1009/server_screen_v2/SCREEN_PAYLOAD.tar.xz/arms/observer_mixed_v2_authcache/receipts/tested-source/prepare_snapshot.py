#!/usr/bin/env python3
"""Prepare an additive exact-source authentication cache without runtime tests."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PARENT = HERE.parent / "observer_mixed_v1"
DEST = HERE / "runtime"


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob("*"))
            if p.is_file() and not p.name.startswith("._") and "__pycache__" not in p.parts}


def authenticate_parent():
    manifest = json.loads((PARENT / "SNAPSHOT_MANIFEST.json").read_text())
    proof = json.loads((PARENT / "CORRECTNESS_EVIDENCE.json").read_text())
    source = {p.name: sha(p) for p in sorted(PARENT.glob("*.py")) if not p.name.startswith("._")}
    result_path = Path(proof["result_path"])
    result = json.loads(result_path.read_text())
    expected = {"candidate_runtime_sha256": inventory(PARENT / "runtime"), "candidate_source_sha256": source,
                "runtime_sha256": inventory(ROOT / "runtime"), "manifest_sha256": sha(PARENT / "SNAPSHOT_MANIFEST.json"),
                "patch_manifest_sha256": sha(PARENT / "PATCH_MANIFEST.json"), "source_diff_sha256": sha(PARENT / "SOURCE_DIFF.patch")}
    if not result.get("all_passed") or not result.get("sources_unchanged"):
        raise ValueError("parent does not have passing preserved controls")
    for key, value in expected.items():
        if result.get(key) != value: raise ValueError("parent stale result binding: " + key)
    if (proof["result_sha256"] != sha(result_path)
            or proof["snapshot_manifest_sha256"] != expected["manifest_sha256"]
            or proof["candidate_source_sha256"] != source
            or proof["candidate_runtime_sha256"] != expected["candidate_runtime_sha256"]
            or expected["candidate_runtime_sha256"] != {row["path"]: row["sha256"] for row in manifest["files"]}):
        raise ValueError("parent correctness evidence differs")
    if sha(ROOT / "RUNTIME_MANIFEST.json") != manifest["frozen_manifest_sha256"]:
        raise ValueError("frozen runtime manifest changed")
    for row in json.loads((ROOT / "RUNTIME_MANIFEST.json").read_text())["files"]:
        if sha(ROOT / row["path"]) != row["sha256"]: raise ValueError("frozen original runtime changed")
    return manifest, {"candidate": PARENT.name, "manifest_sha256": expected["manifest_sha256"],
        "patch_manifest_sha256": expected["patch_manifest_sha256"], "correctness_evidence_sha256": sha(PARENT / "CORRECTNESS_EVIDENCE.json"),
        "result_path": str(result_path), "result_sha256": sha(result_path)}


def main():
    if DEST.exists(): raise ValueError("authcache candidate exists; preserve source/history")
    parent, receipt = authenticate_parent()
    rows, diffs = [], []
    for item in parent["files"]:
        relative = item["path"]
        before = (PARENT / "runtime" / relative).read_bytes()
        data = (HERE / "observer_domain.py").read_bytes() if relative == "observer_domain.py" else before
        if relative.endswith(".py"): ast.parse(data)
        target = DEST / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod((PARENT / "runtime" / relative).stat().st_mode & 0o777)
        rows.append({"path": relative, "bytes": len(data), "sha256": sha(target),
                     "parent_sha256": item["sha256"], "changed_from_parent": data != before})
        if data != before:
            diffs.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), data.decode().splitlines(keepends=True),
                fromfile="observer_mixed_v1/runtime/" + relative, tofile="observer_mixed_v2_authcache/runtime/" + relative))
    (HERE / "SOURCE_DIFF.patch").write_text("".join(diffs))
    status = {"tests_run": False, "simulation_run": False, "timing_run": False, "native_compiled": False,
              "official_gate": False, "rankable": False}
    patch = {"schema": "t3-observer-mixed-authcache-source-v2", **status, "parent_receipt": receipt,
        "changed_runtime_files": ["observer_domain.py"], "builder_sha256": sha(Path(__file__)),
        "source_diff_sha256": sha(HERE / "SOURCE_DIFF.patch"),
        "controls_source_sha256": {p.name: sha(p) for p in sorted(HERE.glob("*.py")) if not p.name.startswith("._")},
        "cache_scope": "Expected module code/AST/default descriptors by canonical path plus exact pinned source digest; no admission-result cache",
        "first_process_admission": "Read/hash each authenticated module; compile/AST parse each exact source once; authenticate loaded functions/defaults/globals/export identities/registries/constants and SciPy identities",
        "every_later_admission": "Read/hash exact pinned module bytes once per call; reuse expectations; recheck all actual loaded domain bindings and mutable defaults",
        "unsupported_source": "Missing/noncanonical/outside-image paths, changed bytes and read failures refuse whole-episode observer admission before agents exist",
        "complexity": "First call O(source bytes + compile/AST + callable checks); warm call O(source bytes + callable/default/global/identity checks); expected-source cache O(authenticated source/code/AST) memory",
        "no_stat_only_shortcut": True, "no_whole_admission_cache": True, "market_logic_unchanged": True,
        "fresh_controls_required": True, "parent_pass_is_not_candidate_pass": True}
    (HERE / "PATCH_MANIFEST.json").write_text(json.dumps(patch, indent=2) + "\n")
    manifest = {"schema": patch["schema"], **status, "files": rows,
        "frozen_manifest_sha256": parent["frozen_manifest_sha256"], "patch_manifest_sha256": sha(HERE / "PATCH_MANIFEST.json"),
        "parent_receipt": receipt, "direct_cli": str(DEST / "agent.py")}
    (HERE / "SNAPSHOT_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"status": "source_snapshot_prepared", "files": len(rows), "changes": ["observer_domain.py"], **status}, indent=2))


if __name__ == "__main__": main()
