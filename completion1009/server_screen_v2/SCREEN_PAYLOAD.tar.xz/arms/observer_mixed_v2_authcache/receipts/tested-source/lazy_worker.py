#!/usr/bin/env python3
"""Separate interpreter import/default-latency controls for one source arm."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import pickle
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--expect-lazy", action="store_true")
args = parser.parse_args()
sys.path.insert(0, args.runtime)
from bootstrap import activate
activate()
import agent
import numpy as np
from abides_fork.config import build_config
import abides_markets.utils as utils
from abides_markets.agents import ExchangeAgent, MomentumAgent, NoiseAgent, ValueAgent, AdaptiveMarketMakerAgent

HERE = Path(__file__).resolve().parent
RUNTIME = Path(args.runtime).resolve()
if (RUNTIME / "observer.py").exists():
    from observer_domain import authenticate_loaded
    assert authenticate_loaded(), "combined lazy domain differs"
SCENARIO = HERE.parents[2] / "evaluation_references/t3-s001-price-time-priority/scenario.json"
scipy_loaded = any(name == "scipy" or name.startswith("scipy.") for name in sys.modules)
if args.expect_lazy and scipy_loaded:
    raise AssertionError("candidate imports scipy before its default latency fallback")
if not args.expect_lazy and not scipy_loaded:
    raise AssertionError("source control did not load original scipy dependency")

state = {"scipy_loaded_at_import": scipy_loaded, "pairs": [], "configs": [],
         "stock_agent_api": [cls.__name__ for cls in (ExchangeAgent, MomentumAgent, NoiseAgent, ValueAgent, AdaptiveMarketMakerAgent)]}
for seed in (0, 1, 20261009):
    for points in (1, 2, 9, 64):
        rng = np.random.RandomState(seed)
        distances = utils.generate_uniform_random_pairwise_dist_on_line(-11.125, 1000000.75, points, rng)
        state["pairs"].append({"seed": seed, "points": points, "dtype": str(distances.dtype),
                               "shape": distances.shape, "bytes": distances.tobytes(), "rng_state": rng.get_state()})
for latency_type in ("deterministic", "no_latency"):
    for seed in (0, 17, 20261009):
        for agents in (1, 9, 32):
            np.random.seed(seed)
            model = utils.generate_latency_model(agents, latency_type)
            state["configs"].append({"type": latency_type, "seed": seed, "agents": agents,
                                      "model_state": model.__dict__, "global_rng": np.random.get_state()})
scenario = json.loads(SCENARIO.read_text())
for mode in ("scenario_latency", "default_fallback"):
    config = json.loads(json.dumps(scenario))
    if mode == "default_fallback":
        config.pop("latency_config", None)
    built = build_config(config)
    model = built["agent_latency_model"]
    state.setdefault("scenario_configs", []).append({"mode": mode, "model": model.__dict__,
        "agent_rng": [(a.id, a.random_state.get_state()) for a in built["agents"]],
        "kernel_rng": built["random_state_kernel"].get_state(), "global_rng": np.random.get_state()})
from scipy.spatial.distance import pdist, squareform
if utils.pdist is not pdist or utils.squareform is not squareform:
    raise AssertionError("lazy public attribute differs from original scipy function")
try:
    utils.undefined_attribute_for_control
except AttributeError:
    pass
else:
    raise AssertionError("unknown attribute unexpectedly accepted")
state["scipy_loaded_after_fallback"] = any(name == "scipy" or name.startswith("scipy.") for name in sys.modules)
# scipy_loaded_at_import is the deliberately changed field, not a simulation result.
output = Path(args.out)
output.mkdir(parents=True, exist_ok=False)
(output / "control_state.pkl").write_bytes(pickle.dumps({k: v for k, v in state.items() if k != "scipy_loaded_at_import"}, protocol=4))
(output / "CONTROL_RECEIPT.json").write_text(json.dumps({"passed": True, "cases": 34,
    "pair_distance_cases": len(state["pairs"]), "latency_model_cases": len(state["configs"]),
    "scenario_config_cases": len(state["scenario_configs"]), "scipy_loaded_at_import": scipy_loaded,
    "scipy_loaded_after_fallback": state["scipy_loaded_after_fallback"],
    "public_api_retained": True, "runtime": args.runtime}, indent=2) + "\n")
print(json.dumps({"passed": True, "scipy_loaded_at_import": scipy_loaded, "cases": 34}))
