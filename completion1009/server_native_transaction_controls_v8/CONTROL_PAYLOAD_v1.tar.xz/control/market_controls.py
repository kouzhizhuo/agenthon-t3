#!/usr/bin/env python3
"""Compare eight fresh full markets after explicit representation checks."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ARMS = ("original_canonical", "actual_native")
SEEDS = (81009, 82009, 83009, 84009)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("fresh full-market output required")
    args.out.mkdir(parents=True)
    report = {"schema": "t3-native-transaction-v8-market-controls", "arms": list(ARMS),
              "cases": [], "failures": [], "all_passed": False, "rankable": False,
              "timing_claim": False, "official_gate": False,
              "source_mapping_spec_sha256": sha(HERE / "SOURCE_MAPPING_SPEC.json"),
              "workers": {}, "data_sha256": {}, "worker_receipt_sha256": {},
              "literal_unmapped_representation_equality_claimed": False}
    try:
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
            env[key] = "1"
        for arm in ARMS:
            with (args.out / (arm + ".log")).open("xb") as stream:
                completed = subprocess.run([sys.executable, "-B", str(HERE / "semantic_worker.py"),
                    "--runtime", str(args.runtime.resolve()), "--candidate", str(args.candidate.resolve()),
                    "--arm", arm, "--out", str((args.out / arm).resolve())],
                    stdout=stream, stderr=subprocess.STDOUT, env=env, cwd=str(HERE), timeout=900)
            if completed.returncode:
                raise ValueError("fresh market worker failed: " + arm)
            receipt = json.loads((args.out / arm / "WORKER_RECEIPT.json").read_text())
            if (receipt.get("schema") != "t3-native-transaction-v8-semantic-worker"
                    or receipt.get("arm") != arm or receipt.get("timing_claim") is not False
                    or receipt.get("rankable") is not False or receipt.get("json_domain_admitted_all") is not True
                    or receipt.get("source_mapping_spec_sha256") != report["source_mapping_spec_sha256"]
                    or receipt.get("values_sha256") != sha(args.out / arm / "SEMANTIC_VALUES.pkl")
                    or [r["seed"] for r in receipt.get("cases", [])] != list(SEEDS)):
                raise ValueError("full market worker receipt differs: " + arm)
            report["workers"][arm] = receipt
            report["data_sha256"][arm] = receipt["values_sha256"]
            report["worker_receipt_sha256"][arm] = sha(args.out / arm / "WORKER_RECEIPT.json")
        # Only these fresh, authored, local control-worker values are read here.
        # A separate retained-evidence audit must decode them inertly afterwards.
        sys.path.insert(0, str(args.runtime.resolve()))
        from bootstrap import activate
        activate()
        import pandas as pd
        values = [pickle.loads((args.out / arm / "SEMANTIC_VALUES.pkl").read_bytes()) for arm in ARMS]
        if not all(len(rows) == 4 for rows in values):
            raise ValueError("four complete market records per arm required")
        for index, seed in enumerate(SEEDS):
            rows = [value[index] for value in values]
            expected = rows[0]
            witnesses = {}
            for arm, row in zip(ARMS, rows):
                if (row["seed"] != seed or len(row["frames"]) != 2 or len(row["payload"]) != 9
                        or row["details"] != expected["details"]):
                    raise ValueError("complete details or graph component roster differs")
                for a, b in zip(expected["frames"], row["frames"]):
                    pd.testing.assert_frame_equal(a, b, check_exact=True, check_dtype=True, rtol=0, atol=0)
                if row["payload"] != expected["payload"]:
                    raise ValueError("complete mapped nine-component business state/aliases differ")
                if row["payload"][0] != [
                    (args.out / arm / str(seed) / "trace.parquet").read_bytes(),
                    (args.out / arm / str(seed) / "message_trace.parquet").read_bytes()]:
                    raise ValueError("full serialized frames and retained Parquet bytes differ")
                witness = row["scheduler_witness"]
                if (witness["scheduler_arm"] != arm or witness["native_active"] is not (arm == "actual_native")
                        or witness["fallback_used"] is not False or witness["json_domain_admitted"] is not True
                        or witness["complete_trace_rows"] != len(row["frames"][0])
                        or witness["message_rows"] != len(row["frames"][1])
                        or witness["installation_restored"] is not True
                        or witness["contract_frames_validated"] is not True
                        or witness["per_episode_original_source_compilations"] != 0
                        or witness["per_episode_source_hashes"] != 0
                        or witness["per_episode_native_hash_audit"] is not False
                        or witness["control_probe_loaded"] is not (arm == "actual_native")):
                    raise ValueError("actual arm/execution witness differs")
                mapped = witness["mapping"]
                if (mapped["arm"] != arm or mapped["mapping_version"] != "t3-transaction-representation-v8"
                        or mapped["ledger_rows"] <= 0 or mapped["end_state_aliases"] != [True, True, True]
                        or mapped["scheduler_owner_verified"] is not (arm != "original_canonical")
                        or mapped["original_has_no_scheduler"] is not (arm == "original_canonical")
                        or not all(mapped[key] is True for key in ("exact_kernel_heap_ledger_types", "heap_queue_original_list",
                            "columns_tuple_retained", "nine_distinct_exact_list_aliases", "all_agent_kernel_aliases",
                            "exact_installed_kernel_class", "exact_book_level_raw_owner_types"))):
                    raise ValueError("mapping lacks actual owner/list/end-state evidence")
                if arm == "actual_native":
                    if (witness["native_receipt"]["native_load_count"] != 1
                            or not mapped["native_private_witness"]
                            or witness["native_receipt"]["deployment_authority"]["audit_all_passed"] is not True):
                        raise ValueError("actual native/probe witness missing")
                elif witness["native_receipt"] is not None or mapped["native_private_witness"] is not None:
                    raise ValueError("Python arm claims a native receipt")
                if witness != report["workers"][arm]["cases"][index]["scheduler_witness"]:
                    raise ValueError("full market values and worker witness differ")
                witnesses[arm] = witness
            report["cases"].append({"seed": seed, "passed": True, "two_way_complete_equal": True,
                "trace_rows": len(expected["frames"][0]), "message_rows": len(expected["frames"][1]),
                "details": expected["details"], "witnesses": witnesses})
        report.update(all_passed=True, market_records=8, control_parquet_blobs=16,
                      market_seed_cases=4, worker_roots=2, nine_payload_components=True)
    except Exception as error:
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    report["controls_source_sha256"] = sha(Path(__file__))
    (args.out / "RESULT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
