"""Actual bounded serial Docker execution with failure evidence and final absence."""
import json
from pathlib import Path
import uuid
from common import BASE, CANDIDATE, ENTRYPOINT, sha, write, inventory


def cleanup(args, name, label, call):
    removal = call(args, [args.docker, "rm", "-f", name], label + "-remove", allow_failure=True)
    absent = call(args, [args.docker, "inspect", name], label + "-absent", allow_failure=True)
    text = (args.evidence / (label + "-absent.log")).read_text()
    result = {"name": name, "remove": removal, "final_inspect": absent,
              "settled": removal["returncode"] == 0 and absent["returncode"] == 1
                  and absent["timed_out"] is False and absent["failure"] is None
                  and ("No such object: " + name in text or "No such container: " + name in text),
              "rankable": False}
    write(args.evidence / (label + "-cleanup.json"), result)
    return result


def resources(raw, inputs, outputs, command):
    host, cfg = raw["HostConfig"], raw["Config"]
    if (cfg["Entrypoint"] != ENTRYPOINT or cfg["Cmd"] != command or cfg["User"] != "65534:65534"
            or cfg["WorkingDir"] != "/output" or host["NetworkMode"] != "none"
            or host["ReadonlyRootfs"] is not True or host["NanoCpus"] != 4000000000
            or host["Memory"] != 16 * 1024 ** 3 or host["MemorySwap"] != 16 * 1024 ** 3
            or host.get("PidsLimit") != 256 or host.get("CapDrop") != ["ALL"]
            or not any(v in ("no-new-privileges", "no-new-privileges:true") for v in host.get("SecurityOpt", []))
            or host.get("Tmpfs", {}).get("/tmp") != "rw,noexec,nosuid,nodev,size=64m"):
        raise ValueError("actual fixed execution resources/CLI envelope differs")
    limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
    binds = [m for m in raw["Mounts"] if m.get("Type") == "bind"]
    if (limits != {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
            or len(binds) != 2 or {m["Destination"]: (m["RW"], m["Source"]) for m in binds}
               != {"/input": (False, str(inputs.resolve())), "/output": (True, str(outputs.resolve()))}):
        raise ValueError("actual fixed execution limits/mounts differ")


def run_container(args, image, inputs, outputs, command, label, call, inspect, arm=None, seconds=3600):
    name = "t3-native-v8-" + label + "-" + uuid.uuid4().hex
    error = None
    before = after = attach = None
    prior_inputs = inventory(inputs)
    create = [args.docker, "create", "--name", name, "--cpus", "4", "--memory", "16g", "--memory-swap", "16g",
        "--network", "none", "--read-only", "--user", "65534:65534", "--pids-limit", "256",
        "--ulimit", "nofile=1024:1024", "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456",
        "--security-opt", "no-new-privileges", "--cap-drop", "ALL", "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m",
        "--mount", "type=bind,src=" + str(inputs.resolve()) + ",dst=/input,readonly",
        "--mount", "type=bind,src=" + str(outputs.resolve()) + ",dst=/output"]
    if arm is not None:
        create += ["--env", "T3_TRANSACTION_CONTROL_ARM=" + arm]
    create += [image, *command]
    record = {"schema": "t3-native-transaction-v8-actual-container-execution-v1", "name": name,
        "command": command, "arm": arm, "input": str(inputs.resolve()), "output": str(outputs.resolve()),
        "input_inventory_before": prior_inputs, "all_passed": False, "timing_executed": False, "rankable": False}
    try:
        created = call(args, create, label + "-create", allow_failure=True)
        record["create"] = created
        if created["returncode"] != 0 or created["timed_out"] or created["failure"] is not None:
            raise RuntimeError("actual bounded container create failed: " + label)
        before = inspect(args, name, label + "-inspect-before")
        record["inspect_before"] = before
        resources(before, inputs, outputs, command)
        attach = call(args, [args.docker, "start", "-a", name], label + "-run", seconds, allow_failure=True)
        record["attach"] = attach
        if attach["returncode"] != 0 or attach["timed_out"] or attach["failure"] is not None:
            raise RuntimeError("actual native control/CLI process failed: " + label)
    except BaseException as failure:
        error = failure
        record["failure"] = {"type": type(failure).__name__, "message": str(failure)}
    finally:
        # Inspect before removal even after attach failure or timeout. Preserve
        # the terminal/running/OOM evidence as data rather than inventing PASS.
        try:
            after = inspect(args, name, label + "-inspect-after")
            record["inspect_after"] = after
            resources(after, inputs, outputs, command)
            if (after["State"]["ExitCode"] != 0 or after["State"].get("OOMKilled") is not False
                    or after["State"].get("Running") is not False):
                raise ValueError("actual completed process failed/OOM/still running")
        except BaseException as failure:
            record["final_inspection_failure"] = {"type": type(failure).__name__, "message": str(failure)}
            if error is None:
                error = failure
        try:
            settled = cleanup(args, name, label, call)
            record["cleanup"] = settled
            record["input_inventory_after"] = inventory(inputs)
            if record["input_inventory_after"] != prior_inputs or settled["settled"] is not True:
                raise ValueError("actual input changed or cleanup did not settle")
        except BaseException as failure:
            record["cleanup_or_input_failure"] = {"type": type(failure).__name__, "message": str(failure)}
            if error is None:
                error = failure
        record["all_passed"] = error is None
        write(args.evidence / (label + "-EXECUTION.json"), record)
    if error is not None:
        raise error
    return record


def production_paths(args, image, plan, proof, authority, call, inspect):
    from cli_cases import ARMS, scenarios, subname
    from cli_output_controls import check_cli_outputs
    from common import SOURCE_RECEIPT_SHA256
    marker = "T3_NATIVE_V8_PRODUCTION_PATH_WITNESS "
    runs = []

    def execute(arm, mode, seed, inputs, outputs, command, label, seconds):
        run = {"arm": arm, "mode": mode, "seed": seed, "output": str(outputs.resolve()),
               "execution": None, "all_passed": False}
        runs.append(run)
        try:
            execution = run_container(args, image, inputs, outputs, command, label, call, inspect, arm, seconds)
            run["execution"] = execution
            log = Path(execution["attach"]["log"]["path"])
            lines = [line[len(marker):] for line in log.read_text().splitlines() if line.startswith(marker)]
            if len(lines) != 1:
                raise ValueError("exact one real production CLI marker required")
            witness = json.loads(lines[0])
            if (witness["schema"] != "t3-native-transaction-v8-production-cli-witness-v1"
                    or witness["arm"] != arm or witness["actual_cli_parser_executed"] is not True
                    or witness["official_argv"] != command
                    or witness["entry_source_sha256"] != plan["control_sources"]["cli_entry.py"]["sha256"]
                    or witness["actual_cli_source_sha256"] != next(row["sha256"] for row in plan["candidate_sources"] if row["path"] == "production_cli.py")
                    or witness["ordinary_scenario_count"] != (1 if mode == "simulate" else 4)
                    or witness["timing_executed"] is not False or witness["rankable"] is not False):
                raise ValueError("actual production CLI/source/argv witness differs")
            if arm == "actual_native":
                receipt = witness["native_receipt"]
                if (receipt["native_load_count"] != 1 or receipt["source_receipt_sha256"] != SOURCE_RECEIPT_SHA256
                        or receipt["deployment_authority"] != authority
                        or receipt["deployment_authority"]["proof_report_sha256"] != authority["proof_report_sha256"]):
                    raise ValueError("actual production native source/proof receipt differs")
            elif witness["native_receipt"] is not None:
                raise ValueError("original production falsely claims native receipt")
            run["production_witness"] = witness
            run["all_passed"] = True
        except BaseException as error:
            saved = args.evidence / (label + "-EXECUTION.json")
            if run["execution"] is None and saved.is_file():
                run["execution"] = json.loads(saved.read_text())
            run["failure"] = {"type": type(error).__name__, "message": str(error)}
            raise
        finally:
            # Every attempted CLI container is retained, including the first
            # failed container. No later controls are represented as executed.
            write(args.evidence / "CLI_RAW_RESULTS.json", runs)

    try:
        for arm in ARMS:
            for scenario in scenarios():
                seed = scenario["seed"]
                folder = args.evidence / "cli" / arm / ("single_" + str(seed))
                inputs, outputs = folder / "input", folder / "output"
                inputs.mkdir(parents=True); outputs.mkdir(); outputs.chmod(0o777)
                write(inputs / "scenario.json", scenario)
                command = ["simulate", "--config", "/input/scenario.json", "--out", "/output/trace.parquet"]
                label = arm + "-single-" + str(seed)
                execute(arm, "simulate", seed, inputs, outputs, command, label, 900)
            folder = args.evidence / "cli" / arm / "batch"
            inputs, outputs = folder / "input", folder / "output"
            (inputs / "scenarios").mkdir(parents=True); outputs.mkdir(); outputs.chmod(0o777)
            for scenario in scenarios():
                write(inputs / "scenarios" / (subname(scenario["seed"]) + ".json"), scenario)
            command = ["simulate-batch", "--batch-dir", "/input/scenarios", "--out-dir", "/output"]
            execute(arm, "simulate-batch", None, inputs, outputs, command, arm + "-batch", 1800)
        result = check_cli_outputs(args.evidence, runs)
    except BaseException as error:
        write(args.evidence / "CLI_PIPELINE_FAILURE.json", {"type": type(error).__name__, "message": str(error),
            "attempted_container_count": len(runs), "completed_container_count": sum(row["all_passed"] is True for row in runs),
            "timing_executed": False, "official_gate": False, "rankable": False})
        raise
    return {"runs": runs, "output_controls": result, "actual_cli_runs": 10,
            "actual_episode_count": 16, "actual_container_count": 10, "timing_executed": False, "rankable": False}
