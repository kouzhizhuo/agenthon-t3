"""Execute the actual packaged production CLI main through official verbs."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys

ROOT = Path("/opt/native-transaction-controls")
CANDIDATE = ROOT / "completion1009/candidates/native_canonical_transaction_v8"
RUNTIME = ROOT / "completion1009/candidates/lean_production_native_projection_v1/runtime"
MARKER = "T3_NATIVE_V8_PRODUCTION_PATH_WITNESS "


def main():
    verb = sys.argv[1] if len(sys.argv) > 1 else None
    if verb == "simulate":
        if sys.argv[1:] != ["simulate", "--config", "/input/scenario.json", "--out", "/output/trace.parquet"]:
            raise ValueError("exact official single CLI shape required")
        expected = 1
    elif verb == "simulate-batch":
        if sys.argv[1:] != ["simulate-batch", "--batch-dir", "/input/scenarios", "--out-dir", "/output"]:
            raise ValueError("exact official batch CLI shape required")
        expected = 4
    else:
        raise ValueError("official production simulate verb required")
    arm = os.environ.get("T3_TRANSACTION_CONTROL_ARM")
    if arm not in ("original_canonical", "actual_native"):
        raise ValueError("reviewed ordinary control arm required")
    native = arm == "actual_native"
    for name in ("proof_authentication", "host_proof", "transaction_owner_probe", "production_cli", "transaction_loader", "native_canonical_transaction"):
        if name in sys.modules:
            raise ValueError("fresh actual production CLI process required")
    sys.path.insert(0, str(CANDIDATE))
    sys.path.insert(0, str(RUNTIME))
    old_argv = list(sys.argv)
    # The baseline control selects the already reviewed original arm through
    # the actual parser option. Native/default invocation keeps official argv.
    if not native:
        sys.argv += ["--arm", arm]
    try:
        namespace = runpy.run_path(str(CANDIDATE / "production_cli.py"), run_name="__main__")
    finally:
        sys.argv = old_argv
    episodes = namespace["episode_probes"]()
    if len(episodes) != expected:
        raise ValueError("actual production CLI episode roster differs")
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_fork.config import ScenarioLatencyModel
    from abides_markets.agents import exchange_agent
    from abides_markets.order_book import OrderBook
    import observer
    if (abides.Kernel is not Kernel or exchange_agent.OrderBook is not OrderBook
            or observer.STATE is not None or "transaction_owner_probe" in sys.modules
            or "proof_authentication" in sys.modules or "host_proof" in sys.modules):
        raise ValueError("actual production CLI bindings/state/module boundary not restored")
    if native:
        from transaction_loader import native_receipt
        receipt = native_receipt()
        if receipt["native_load_count"] != 1 or not all(row["native_receipt"] == receipt for row in episodes):
            raise ValueError("actual production batch must share exactly one native loader owner")
    else:
        receipt = None
        if "native_canonical_transaction" in sys.modules or "transaction_loader" in sys.modules:
            raise ValueError("original production control unexpectedly loaded native code")
    for row in episodes:
        if (row["scheduler_arm"] != arm or row["native_active"] is not native
                or row["fallback_used"] is not False or row["json_domain_admitted"] is not True
                or row["installation_restored"] is not True or row["control_probe_loaded"] is not False
                or row["installed_engine"] != "canonical" or row["observer_authenticated"] is not True
                or row["per_episode_source_hashes"] != 0 or row["per_episode_original_source_compilations"] != 0
                or row["runtime_native_compilation"] is not False or row["per_episode_native_hash_audit"] is not False
                or row["rankable"] is not False):
            raise ValueError("actual production episode/source/admission/owner witness differs")
    marker = {"schema": "t3-native-transaction-v8-production-cli-witness-v1", "arm": arm,
        "official_argv": old_argv[1:], "actual_cli_parser_executed": True,
        "actual_cli_source": str(CANDIDATE / "production_cli.py"),
        "actual_cli_source_sha256": hashlib.sha256((CANDIDATE / "production_cli.py").read_bytes()).hexdigest(),
        "entry_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "episodes": episodes, "native_receipt": receipt, "original_kernel_binding_restored": True,
        "original_book_binding_restored": True, "inactive_observer_after": True,
        "production_probe_loaded": False, "production_research_auth_loaded": False,
        "external_proof_reexecuted_in_production": False, "timing_executed": False, "rankable": False,
        "latency_binding_restored_by_actual_production_cli": True,
        "ordinary_scenario_count": expected}
    print(MARKER + json.dumps(marker, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
