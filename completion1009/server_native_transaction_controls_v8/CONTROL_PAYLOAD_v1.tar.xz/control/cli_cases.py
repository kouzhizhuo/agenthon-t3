"""Author fixed ordinary JSON path controls; no participant import or execution."""
SEEDS = (81009, 82009, 83009, 84009)
ARMS = ("original_canonical", "actual_native")


def scenario(seed, latency, protocol=False):
    value = {"scenario_id": "native-v8-production-path-" + str(seed), "seed": seed,
        "horizon_ns": 2000000000,
        "exchange_config": {"symbol": "CTRL", "tick_size": 1, "lot_size": 1, "min_price": 1, "max_price": 1000000},
        "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100000, "kappa": .05,
            "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}},
        "agent_configs": [
            {"agent_type": "NoiseTrader", "count": 2, "params": {"arrival_rate_hz": 6., "order_size_mean": 10}},
            {"agent_type": "MarketMaker", "count": 1, "params": {"spread_ticks": 2, "depth_levels": 3,
                "size_per_level": 12, "rebalance_interval_ns": 300000000}},
            {"agent_type": "ValueTrader", "count": 1, "params": {"arrival_rate_hz": 4., "threshold_ticks": 2}},
            {"agent_type": "MomentumTrader", "count": 1, "params": {"arrival_rate_hz": 5., "threshold_ticks": 2}}]}
    if latency is not None:
        value["latency_config"] = latency
    if protocol:
        value["exchange_config"].update(protocol_enforcement=True, stp_policy="cancel_oldest", ack_delay_ns=400, compute_delay_ns=100)
    return value


def scenarios():
    return [scenario(seed, latency, protocol) for seed, latency, protocol in (
        (81009, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}, False),
        (82009, {"model": "deterministic", "params": {"mean_ns": 0}}, False),
        (83009, {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}, True),
        (84009, None, False))]


def subname(seed):
    return "scenario_" + str(seed)
