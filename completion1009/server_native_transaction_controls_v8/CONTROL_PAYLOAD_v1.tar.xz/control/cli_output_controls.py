"""Actual Linux host output checks for real CLI runs; no simulation execution."""
import json
import math
from pathlib import Path
from cli_cases import ARMS, SEEDS, subname
from common import sha, write

TRACE = {"t_ns": "int64", "agent_id": "int32", "msg_type": "string", "side": "string",
         "price": "int64", "size": "int64", "order_id": "int64"}
MESSAGE = {"seq": "int64", "t_recv_ns": "int64", "t_send_ns": "Int64", "latency_ns": "int64",
           "src_id": "int32", "dst_id": "int32", "message_id": "int64", "msg_type": "string",
           "order_id": "Int64", "causal_parent": "Int64"}
EVENT_TYPES = {"ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_FILLED", "PARTIAL_FILL",
               "ORDER_CANCELLED", "ORDER_REPLACED", "QUOTE_UPDATE"}


def positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def frames(root):
    import pandas as pd
    import pyarrow
    if pd.__version__ != "1.5.3" or pyarrow.__version__ != "15.0.2":
        raise ValueError("actual host output decoder dependency versions differ")
    values, report = [], []
    for name, types in (("trace", TRACE), ("message_trace", MESSAGE)):
        path = root / (name + ".parquet")
        data = path.read_bytes()
        if len(data) < 12 or data[:4] != data[-4:] or data[:4] != b"PAR1":
            raise ValueError("complete actual Parquet envelope required")
        frame = pd.read_parquet(path)
        if list(frame.columns) != list(types) or {k: str(frame[k].dtype) for k in types} != types or frame.empty:
            raise ValueError("actual production output contract differs")
        values.append(frame)
        report.append({"name": name, "rows": len(frame), "dtypes": types, "bytes": len(data), "sha256": sha(path),
            "null_counts": {key: int(frame[key].isna().sum()) for key in types}})
    if not set(values[0]["msg_type"]).issubset(EVENT_TYPES) or not values[0]["side"].dropna().isin(["BID", "ASK"]).all():
        raise ValueError("actual production output event/side contract differs")
    return values, report


def check_cli_outputs(evidence, runs):
    import pandas as pd
    by_key = {(row["arm"], row["mode"], row["seed"]): row for row in runs}
    if len(runs) != 10 or len(by_key) != 10:
        raise ValueError("exact distinct ten production CLI runs required")
    expected_keys = {(arm, "simulate", seed) for arm in ARMS for seed in SEEDS} | {(arm, "simulate-batch", None) for arm in ARMS}
    if set(by_key) != expected_keys:
        raise ValueError("complete production single/batch arm roster required")
    episodes, outputs = {}, []
    for arm in ARMS:
        singles = []
        for seed in SEEDS:
            run = by_key[arm, "simulate", seed]
            root = Path(run["output"])
            values, report = frames(root)
            events = json.loads((root / "events.json").read_text())
            if events["scenario_id"] != "native-v8-production-path-" + str(seed) or events["seed"] != seed:
                raise ValueError("actual production sidecar identity differs")
            if (type(events["n_events"]) is not int or events["n_events"] != len(values[0])
                    or events["trace_sha256"] != sha(root / "trace.parquet")
                    or not positive(events["wall_clock_sec"]) or not positive(events["events_per_sec"])
                    or abs(events["events_per_sec"] / (events["n_events"] / events["wall_clock_sec"]) - 1) > .05
                    or events["gpu_seconds"] != 0.0 or type(events["peak_memory_bytes"]) is not int or events["peak_memory_bytes"] <= 0):
                raise ValueError("actual production sidecar count/hash/arithmetic/memory differs")
            witness = run["production_witness"]
            row = witness["episodes"][0]
            if row["complete_trace_rows"] != len(values[0]) or row["message_rows"] != len(values[1]):
                raise ValueError("actual CLI witness frame row binding differs")
            if {p.name for p in root.iterdir() if p.is_file()} != {"trace.parquet", "message_trace.parquet", "events.json"}:
                raise ValueError("exact official single output roster required")
            episodes[arm, seed] = (root, values, events)
            singles.append(events)
            outputs.append({"arm": arm, "mode": "simulate", "seed": seed, "frames": report,
                "event_sidecar_checked": True, "timing_executed": False})
        batch = by_key[arm, "simulate-batch", None]
        root = Path(batch["output"])
        meta = json.loads((root / "batch_events.json").read_text())
        if (meta["n_scenarios"] != 4 or type(meta["total_events"]) is not int
                or meta["total_events"] != sum(row["n_events"] for row in singles)
                or [row["sub"] for row in meta["per_scenario"]] != [subname(seed) for seed in SEEDS]
                or not positive(meta["wall_clock_sec"]) or not positive(meta["events_per_sec"])
                or abs(meta["events_per_sec"] / (meta["total_events"] / meta["wall_clock_sec"]) - 1) > .05):
            raise ValueError("actual official aggregate count/order/arithmetic differs")
        if {p.name for p in root.iterdir()} != {subname(seed) for seed in SEEDS} | {"batch_events.json"}:
            raise ValueError("exact official batch output root roster required")
        for index, seed in enumerate(SEEDS):
            single_root, single_frames, event = episodes[arm, seed]
            batch_root = root / subname(seed)
            values, report = frames(batch_root)
            other = json.loads((batch_root / "events.json").read_text())
            for column, filename in enumerate(("trace.parquet", "message_trace.parquet")):
                pd.testing.assert_frame_equal(single_frames[column], values[column], check_exact=True,
                    check_dtype=True, check_names=True, check_like=False, rtol=0, atol=0)
                if (single_root / filename).read_bytes() != (batch_root / filename).read_bytes():
                    raise ValueError("actual fresh single/batch state isolation output bytes differ")
            if {p.name for p in batch_root.iterdir()} != {"trace.parquet", "message_trace.parquet", "events.json"}:
                raise ValueError("exact official batch sub output roster required")
            if any(other[k] != event[k] for k in ("scenario_id", "seed", "n_events", "trace_sha256")):
                raise ValueError("actual batch sub identity/count/hash differ from fresh single")
            if (not positive(other["wall_clock_sec"]) or not positive(other["events_per_sec"])
                    or abs(other["events_per_sec"] / (other["n_events"] / other["wall_clock_sec"]) - 1) > .05
                    or other["gpu_seconds"] != 0.0 or type(other["peak_memory_bytes"]) is not int
                    or other["peak_memory_bytes"] <= 0):
                raise ValueError("actual batch sub sidecar arithmetic differs")
            expected = {"sub": subname(seed), **{k: event[k] for k in ("n_events", "scenario_id", "seed")}}
            if meta["per_scenario"][index] != expected:
                raise ValueError("actual batch aggregate not bound to sub sidecars")
            witness = batch["production_witness"]["episodes"][index]
            if witness["complete_trace_rows"] != len(values[0]) or witness["message_rows"] != len(values[1]):
                raise ValueError("actual batch witness episode/count differs")
            outputs.append({"arm": arm, "mode": "simulate-batch", "seed": seed, "frames": report,
                "fresh_single_batch_exact_isolation_checked": True, "timing_executed": False})
    for seed in SEEDS:
        left, right = episodes[ARMS[0], seed], episodes[ARMS[1], seed]
        for column, filename in enumerate(("trace.parquet", "message_trace.parquet")):
            pd.testing.assert_frame_equal(left[1][column], right[1][column], check_exact=True,
                check_dtype=True, check_names=True, check_like=False, rtol=0, atol=0)
            if (left[0] / filename).read_bytes() != (right[0] / filename).read_bytes():
                raise ValueError("actual original/native production CLI outputs differ")
        if any(left[2][k] != right[2][k] for k in ("scenario_id", "seed", "n_events", "trace_sha256")):
            raise ValueError("actual two-arm production sidecar identity/count/hash differ")
    report = {"schema": "t3-native-transaction-v8-production-path-output-controls-v1", "all_passed": True,
        "actual_cli_runs": 10, "single_runs": 8, "batch_runs": 2, "actual_episodes": 16,
        "actual_Parquet_files_decoded": 32, "fresh_single_batch_isolation_pairs": 8, "cross_arm_single_pairs": 4,
        "all_values_dtypes_nulls_rows_bytes_equal": True, "actual_official_verb_shape_checked": True,
        "source_output_contract_checked": True, "required_sidecar_arithmetic_checked": True,
        "timing_executed": False, "official_gate": False, "full71": False, "rankable": False, "outputs": outputs}
    write(evidence / "CLI_OUTPUT_CONTROLS.json", report)
    return report
