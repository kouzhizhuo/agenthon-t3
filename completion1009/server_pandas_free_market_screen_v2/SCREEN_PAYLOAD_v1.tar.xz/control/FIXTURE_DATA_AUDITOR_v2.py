"""Audit retained fixture data only; never import participant or control modules."""
import argparse
import ast
import base64
import hashlib
import json
from pathlib import Path
import sys

ARMS = ("baseline", "new", "cold-new")
VERSIONS = {"numpy": "1.26.4", "pandas": "1.5.3", "pyarrow": "15.0.2"}
TRACE = {"t_ns": "int64", "agent_id": "int32", "msg_type": "string", "side": "string",
         "price": "int64", "size": "int64", "order_id": "int64"}
MESSAGE = {"seq": "int64", "t_recv_ns": "int64", "t_send_ns": "Int64", "latency_ns": "int64",
           "src_id": "int32", "dst_id": "int32", "message_id": "int64", "msg_type": "string",
           "order_id": "Int64", "causal_parent": "Int64"}
BASE_NS = 1612517400000000123
GROUPS = ("actual-projection", "ordinary-all-valid", "all-null-nullable", "utf8-empty-null", "signed-range", "zero-row")
LABELS = ("base-pull", "base-inspect", "image-build", "image-inspect", "evidence-create",
          "installed-copy", "evidence-remove", "fixture-create", "fixture-inspect-before",
          "fixture-run", "fixture-inspect-after", "fixture-remove")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob(path, limit=32 * 1024 ** 2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), "ordinary retained file absent: " + str(path))
    require(0 <= path.stat().st_size <= limit, "retained byte bound: " + str(path))
    return path.read_bytes()


def read_json(path):
    return json.loads(blob(path))


def pin(path):
    data = blob(path)
    return {"bytes": len(data), "sha256": digest(data)}


def inventory(root):
    root = Path(root)
    result = {}
    for path in sorted(root.rglob("*")):
        if path.name.startswith("._") or "__pycache__" in path.parts:
            continue
        require(not path.is_symlink(), "retained symlink refused")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = pin(path)
    return result


def original_values():
    return {
        "trace": {"t_ns": [BASE_NS, BASE_NS, *([BASE_NS + 1] * 5)],
            "agent_id": [1, 2, 0, 0, 1, 1, 1],
            "msg_type": ["ORDER_SUBMITTED", "ORDER_ACCEPTED", "QUOTE_UPDATE", "QUOTE_UPDATE", "PARTIAL_FILL", "ORDER_FILLED", "ORDER_CANCELLED"],
            "side": ["BID", "ASK", "ASK", "BID", "BID", "BID", None], "price": [101, 105, 103, 100, 101, 101, 0],
            "size": [10, 1, 17, 8, 3, 7, 2], "order_id": [42, 44, -1, -1, 42, 42, 43]},
        "message_trace": {"seq": [2, 7, 8, 8], "t_recv_ns": [BASE_NS + 2, BASE_NS + 5, BASE_NS + 9, BASE_NS + 10],
            "t_send_ns": [None, BASE_NS + 2, BASE_NS, BASE_NS + 1], "latency_ns": [0, 3, 9, 9], "src_id": [0, 0, 1, 1],
            "dst_id": [0, 1, 0, 0], "message_id": [11, 12, 9, 9], "msg_type": ["AGENT_WAKEUP", "ORDER_ACCEPTED", "LIMIT_ORDER", "LIMIT_ORDER"],
            "order_id": [None, 42, 42, 42], "causal_parent": [None, 9, 7, 7]}}


def domains(contract, kind):
    result = [(GROUPS[0], original_values()[kind])]
    for label, n in zip(GROUPS[1:], (2, 2, 3, 2, 0)):
        values = {}
        for name, dtype in contract.items():
            if dtype == "string":
                column = ["x"] * n
                if label == "all-null-nullable":
                    column = [None] * n
                elif label == "utf8-empty-null":
                    column = ["", "买入🙂", None]
            else:
                column = list(range(1, n + 1))
                if dtype == "Int64" and label == "ordinary-all-valid":
                    column = [BASE_NS, BASE_NS + 1]
                elif dtype == "Int64" and label == "all-null-nullable":
                    column = [None] * n
                elif label == "signed-range":
                    bits = 32 if dtype == "int32" else 64
                    column = [-(1 << (bits - 1)), (1 << (bits - 1)) - 1]
            values[name] = column
        result.append((label, values))
    return result


def audit_payload(root, spec):
    payload = root / "payload"
    actual = inventory(payload)
    actual.pop("MATERIALIZATION.json", None)
    manifest = read_json(payload / "PAYLOAD_MANIFEST.json")
    require(pin(payload / "PAYLOAD_MANIFEST.json")["sha256"] == spec["manifest_sha256"], "sealed payload manifest changed")
    actual.pop("PAYLOAD_MANIFEST.json")
    require(actual == manifest["files"] and len(actual) == 142, "sealed143 payload member bytes changed")
    plan = read_json(payload / "FIXTURE_PLAN.json")
    require(plan["candidate_source_receipt_sha256"] == spec["candidate_receipt_sha256"], "candidate receipt binding")
    require(plan["independent_review_sha256"] == spec["candidate_review_sha256"]
            and plan["independent_wrapper_review_sha256"] == spec["wrapper_review_sha256"]
            and plan["prototype_only"] is False, "sealed independent reviews absent")
    candidate = payload / plan["candidate"]
    receipt = read_json(candidate / "SOURCE_PREPARATION_RECEIPT_v3.json")
    require(pin(candidate / "SOURCE_PREPARATION_RECEIPT_v3.json")["sha256"] == spec["candidate_receipt_sha256"], "payload receipt actual SHA")
    require(receipt["files"] == plan["candidate_sources"] and len(receipt["files"]) == 70, "candidate70 roster")
    require(len(plan["baseline_sources"]) == 64 and len(plan["control_sources"]) == 5, "donor/control roster")
    for row in receipt["files"]:
        require(pin(candidate / row["path"]) == {k: row[k] for k in ("bytes", "sha256")}, "candidate source changed")
    for name, expected in plan["control_sources"].items():
        require(pin(payload / "control" / name) == expected, "payload control changed")
    return plan


def audit_commands(evidence):
    commands = {}
    for label in LABELS:
        record = read_json(evidence / (label + ".json"))
        require(record["returncode"] == 0 and record["timed_out"] is False and record["failure"] is None,
                "actual command failed/timeout: " + label)
        require(pin(evidence / (label + ".log")) == {k: record["log"][k] for k in ("bytes", "sha256")}, "raw command log changed")
        require(type(record["command"]) is list and record["command"], "raw command absent")
        commands[label] = record["command"]
    before = read_json(evidence / "fixture-inspect-before.log")[0]
    after = read_json(evidence / "fixture-inspect-after.log")[0]
    image = read_json(evidence / "image-inspect.log")[0]
    base = read_json(evidence / "base-inspect.log")[0]
    require(before["Id"] == after["Id"] and before["Image"] == image["Id"], "actual container/image identity")
    require(before["State"]["Status"] == "created" and before["State"]["Running"] is False,
            "fixture container was not fresh created")
    host, config = before["HostConfig"], before["Config"]
    require(config["Entrypoint"] == ["/usr/local/bin/python", "-B", "/opt/pandas-free-fixtures/control/entry.py"]
            and config["Cmd"] == ["controls"] and config["User"] == "65534:65534", "actual fixture entry")
    require(host["NanoCpus"] == 4000000000 and host["Memory"] == 16 * 1024 ** 3
            and host["MemorySwap"] == 16 * 1024 ** 3 and host["ReadonlyRootfs"] is True
            and host["NetworkMode"] == "none", "actual resource envelope")
    require(host["PidsLimit"] == 256 and host["CapDrop"] == ["ALL"]
            and any(x in ("no-new-privileges", "no-new-privileges:true") for x in host["SecurityOpt"])
            and host["Tmpfs"] == {"/tmp": "rw,noexec,nosuid,nodev,size=64m"}, "actual security/tmpfs")
    require({x["Name"]: (x["Soft"], x["Hard"]) for x in host["Ulimits"]}
            == {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}, "actual ulimits")
    binds = [x for x in before["Mounts"] if x["Type"] == "bind"]
    require(len(binds) == 2 and {x["Destination"]: x["RW"] for x in binds} == {"/input": False, "/output": True}, "actual mounts")
    create = commands["fixture-create"]
    expected_paths = {"/input": next(x["Source"] for x in binds if x["Destination"] == "/input"),
                      "/output": next(x["Source"] for x in binds if x["Destination"] == "/output")}
    require("type=bind,src=" + expected_paths["/input"] + ",dst=/input,readonly" in create
            and "type=bind,src=" + expected_paths["/output"] + ",dst=/output" in create, "raw created mount source")
    require(after["State"]["ExitCode"] == 0 and after["State"]["OOMKilled"] is False
            and after["State"]["Running"] is False, "actual process completion")
    name = create[create.index("--name") + 1]
    require(commands["fixture-run"][1:] == ["start", "-a", name]
            and commands["fixture-remove"][1:] == ["rm", "-f", name], "actual run/cleanup chain")
    evidence_name = commands["evidence-create"][commands["evidence-create"].index("--name") + 1]
    require(commands["evidence-remove"][1:] == ["rm", "-f", evidence_name], "evidence cleanup chain")
    require(commands["base-pull"][-1] in base["RepoDigests"], "actual pinned base digest")
    return {"commands": len(commands), "actual_image": image["Id"], "actual_base": base["Id"],
            "container_id": before["Id"], "resources_verified": True, "both_cleanup_returncodes_zero": True}


def audit_build(evidence, plan, commands):
    installed = evidence / "installed"
    report = read_json(evidence / "ACTUAL_BUILD_INVENTORY_v1.json")
    require(report["installed_files"] == inventory(installed), "actual installed whole inventory")
    require(report["fixture_image"] == commands["actual_image"] and report["base_image"] == commands["actual_base"], "build image identities")
    require(report["candidate_executed_during_build"] is False and report["kernel_or_market_run"] is False and report["rankable"] is False, "build execution scope")
    candidate = installed / plan["candidate"]
    for row in plan["candidate_sources"]:
        require(pin(candidate / row["path"]) == {k: row[k] for k in ("bytes", "sha256")}, "actual installed candidate source")
    baseline = installed / "completion1009/candidates/lean_production_native_projection_v1/runtime"
    require(inventory(baseline) == plan["baseline_sources"], "actual installed64 donor sources")
    for name, expected in plan["control_sources"].items():
        require(pin(installed / "control" / name) == expected, "actual installed control")
    generator = installed / "completion1009/research/pandas_free_output_route_v1/prepare_schema_metadata_source_v1.py"
    require(pin(generator)["sha256"] == plan["generator_sha256"], "actual generator bytes")
    metadata_path = candidate / "runtime/schema_metadata_v1.json"
    pin_path = candidate / "runtime/schema_metadata_pin_v1.py"
    generated = read_json(metadata_path)
    baseline_receipt = read_json(installed / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json")
    deployed = read_json(installed / "schema-build/DEPLOYED_SCHEMA_PIN_RECEIPT_v1.json")
    require(baseline_receipt["versions"] == VERSIONS and baseline_receipt["generator"]["sha256"] == plan["generator_sha256"], "pinned schema versions/generator")
    for receipt in (baseline_receipt, deployed):
        require({k: receipt["metadata"][k] for k in ("bytes", "sha256")} == pin(metadata_path), "actual schema bytes/receipt")
    require({k: deployed["source_pin"][k] for k in ("bytes", "sha256")} == pin(pin_path)
            and deployed["baseline_receipt_sha256"] == pin(installed / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json")["sha256"], "actual source pin/parent receipt")
    tree = ast.parse(blob(pin_path))
    assignments = [x for x in tree.body if isinstance(x, ast.Assign)]
    require(len(assignments) == 1 and len(assignments[0].targets) == 1
            and isinstance(assignments[0].targets[0], ast.Name) and assignments[0].targets[0].id == "SCHEMA_METADATA_SHA256"
            and ast.literal_eval(assignments[0].value) == pin(metadata_path)["sha256"], "literal generated pin (never exec)")
    runtime = inventory(candidate / "runtime")
    runtime.pop("schema_metadata_v1.json"); runtime.pop("schema_metadata_pin_v1.py")
    require(runtime == {x["path"][8:]: {k: x[k] for k in ("bytes", "sha256")}
            for x in plan["candidate_sources"] if x["path"].startswith("runtime/")}, "deployed runtime extras/changes")
    require(generated["schema"] == "t3-pandas-free-schema-metadata-v1"
            and {name: generated[name + "_version"] for name in VERSIONS} == VERSIONS, "actual generated schema contract")
    return generated


def audit_fixtures(evidence, generated):
    # The trusted local decoder reads inert Parquet bytes; participant modules
    # and downloaded Python files never enter sys.path or execute.
    import pandas as pd
    import pyarrow as pa
    import pyarrow.parquet as pq
    require(pd.__version__ == "2.3.3" and pa.__version__ == "21.0.0", "approved data-only decoder versions")
    folder = evidence / "output/fixtures"
    result = read_json(folder / "RESULT_v1.json")
    require(result["schema"] == "t3-pandas-free-fixture-only-container-result-v1" and result["all_passed"] is True
            and result["retained_parquets"] == 6 and result["kernel_or_market_run"] is False
            and result["timing_result"] is False and result["rankable"] is False, "actual fixture result scope")
    children = {}
    for arm in ARMS:
        child = read_json(folder / arm / "DOMAIN_RECEIPT_v1.json")
        worker = read_json(folder / arm / "receipt.json")
        require(result["children"][arm] == child and child["candidate_writer_fixture"] == worker, "retained3 receipts mismatch")
        require(child["arm"] == arm and worker["arm"] == arm and child["actual_config_constructed"] is True
                and child["kernel_or_market_run"] is False and worker["market_executed"] is False
                and worker["timing_result"] is False and worker["expected_values_equal"] is True
                and worker["raw_state_unchanged"] is True, "actual child scope/state assertions")
        require(worker["versions"]["numpy"] == VERSIONS["numpy"] and worker["versions"]["pyarrow"] == VERSIONS["pyarrow"], "actual writer dependencies")
        require(worker["pandas_import_attempts"] == [] and child["pandas_import_attempts_through_domains"] == [], "actual cold attempt lists")
        if arm == "cold-new":
            require(worker["pandas_loaded"] is False and child["pandas_loaded_after_domains"] is False, "actual cold pandas absence")
        if arm != "baseline":
            require(worker["source_domain_callback_controls"] == [], "custom callback counter")
        children[arm] = child
    baseline = children["baseline"]
    require(len(baseline["public_time_results"]) == 16 and len(baseline["general_original_output_results"]) == 4,
            "actual publictime/fallback case roster")
    require(len(baseline["normal_time_controls"]) == 8, "actual normal return roster")
    normal_expected = [("09:30:00", 34200000000000), ("16:00:00", 57600000000000),
                       ("1s", 1000000000), ("60s", 60000000000), ("1min", 60000000000),
                       ("12", 12), (str(-(1 << 63) + 1), -(1 << 63) + 1),
                       (str((1 << 63) - 1), (1 << 63) - 1)]
    require(baseline["normal_time_controls"] == [{"value": label, "type": "numpy.int64", "result": number}
            for label, number in normal_expected], "actual normal signed64 sentinel exclusion/return type")
    sentinel_outcomes = baseline["public_time_results"][7:10]
    require(sentinel_outcomes == [{"kind": "duration", "input": label, "returned": False,
             "type": "builtins.AttributeError", "message": "'NaTType' object has no attribute 'to_timedelta64'"}
             for label in (str(-(1 << 63)), str(-(1 << 63)), "NaT")],
            "actual Pythonint/NumPyint64/NaT original duration throw outcomes")
    require([x["case"] for x in baseline["general_original_output_results"]]
            == ["wide-id", "np32-time", "bool-time", "legacy-dict-ledger"], "fallback cases")
    require(children["new"]["public_time_results"] == baseline["public_time_results"]
            and children["new"]["general_original_output_results"] == baseline["general_original_output_results"], "actual original/new returns/types/errors")
    for arm in ARMS:
        require(children[arm]["actual_config"] == baseline["actual_config"]
                and children[arm]["normal_time_controls"] == baseline["normal_time_controls"], "actual config/time equality")
    decoded = []
    all_groups = []
    for kind, contract in (("trace", TRACE), ("message_trace", MESSAGE)):
        groups = domains(contract, kind)
        expected = {name: [v for _, values in groups for v in values[name]] for name in contract}
        schemas, frames, data = [], [], []
        for arm in ARMS:
            path = folder / arm / (kind + ".parquet")
            actual_pin = pin(path)
            require(actual_pin == children[arm]["candidate_writer_fixture"]["files"][path.name], "actual Parquet bytes/hash receipt")
            data.append(blob(path))
            table = pq.ParquetFile(path).read()
            frame = pd.read_parquet(path)
            schema = table.schema
            require(table.column_names == list(contract) and table.to_pydict() == expected, "independently decoded full fixture values/order")
            require({name: str(frame[name].dtype) for name in frame.columns} == contract, "actual pandas readback logical dtypes")
            definition = generated["tables"][kind]
            metadata = lambda items: {base64.b64decode(x["key_b64"], validate=True): base64.b64decode(x["value_b64"], validate=True) for x in items} or None
            require(schema.metadata == metadata(definition["schema_metadata"]), "actual schema metadata bytes")
            for field, row in zip(schema, definition["columns"]):
                require(field.name == row["name"] and str(field.type) == row["arrow_type"]
                        and field.nullable == row["nullable"] and field.metadata == metadata(row["field_metadata"]), "actual field/schema contract")
            encoded_schema = pq.ParquetFile(path).metadata.metadata.get(b"ARROW:schema")
            require(type(encoded_schema) is bytes, "actual Parquet ARROW:schema absent")
            serialized = base64.b64decode(encoded_schema, validate=True)
            require(digest(serialized) == definition["schema_serialized_sha256"]
                    and base64.b64encode(serialized).decode("ascii") == definition["schema_serialized_b64"], "actual retained serialized schema")
            require(pa.ipc.read_schema(pa.BufferReader(serialized)).equals(schema, check_metadata=True), "retained Arrow IPC schema differs")
            worker = children[arm]["candidate_writer_fixture"]
            ordinary = original_values()[kind]
            require(worker["production_write_api_readbacks"][kind] == {"rows": len(ordinary[next(iter(contract))]),
                "schema_sha256": digest(serialized), "null_counts": {name: ordinary[name].count(None) for name in contract}}, "primary actual production API readback receipt")
            expected_groups = [{"table": kind, "group": label, "rows": len(values[next(iter(contract))]),
                "actual_write_table_called": True, "schema_sha256": digest(serialized),
                "null_counts": {name: values[name].count(None) for name in contract}} for label, values in groups]
            actual_groups = [x for x in worker["full_serializer_groups"] if x["table"] == kind]
            require(actual_groups == expected_groups, "group/schema/null/zero-writer invocation receipts")
            schemas.append(schema); frames.append(frame)
            decoded.append({"arm": arm, "table": kind, "rows": table.num_rows,
                "bytes": actual_pin["bytes"], "sha256": actual_pin["sha256"], "schema_sha256": digest(serialized),
                "null_counts": {name: table[name].null_count for name in table.column_names}})
        require(data[0] == data[1] == data[2], "six retained fullParquetbytes differ")
        for i in (1, 2):
            require(schemas[0].equals(schemas[i], check_metadata=True), "decoded schema equality")
            pd.testing.assert_frame_equal(frames[0], frames[i], check_dtype=True, check_exact=True)
        all_groups.extend(children["baseline"]["candidate_writer_fixture"]["full_serializer_groups"][:6] if kind == "trace"
                          else children["baseline"]["candidate_writer_fixture"]["full_serializer_groups"][6:])
    for arm in ("new", "cold-new"):
        require(children[arm]["candidate_writer_fixture"]["production_write_api_files"]
                == baseline["candidate_writer_fixture"]["production_write_api_files"], "primary API bytes/hash mismatch")
    require(len([p for p in folder.glob("*/*.parquet") if not any(part.startswith("._") for part in p.relative_to(folder).parts)]) == 6, "exact six retained ordinary Parquets")
    return {"decoded_retained_parquets": decoded, "decoder": {"pandas": pd.__version__, "pyarrow": pa.__version__},
            "full_serializer_group_calls": len(all_groups), "primary_API_equal": True,
            "primary_API_bytes_retained": False, "raw_state_equal_evidence": "source-bound worker assertions only; no raw graph payload retained",
            "cold_final_attempt_lists_empty": True, "public_time_cases": 16, "normal_return_cases": 8, "sentinel_throw_cases": 3, "general_fallback_cases": 4}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive-root", type=Path, required=True)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh audit report required")
    spec = read_json(args.spec)
    require(spec["schema"] == "t3-pandas-free-fixture-saved-audit-spec-v2", "audit spec schema")
    root = args.archive_root.resolve()
    require(root.is_dir() and not any(x in sys.modules for x in ("observer", "abides_core", "abides_fork", "canonical_buffers", "t3_canonical_engine")), "participant module imported")
    result = {"schema": "t3-pandas-free-fixture-data-only-actual-audit-v2", "all_passed": False,
        "rankable": False, "official_gate": False, "market_executed": False, "participant_imported": False,
        "source_auditor_sha256": pin(Path(__file__))["sha256"], "spec_sha256": pin(args.spec)["sha256"], "archive_root": str(root)}
    try:
        result["retained_archive_inventory"] = inventory(root)
        require(not (root / "evidence/FAILURE_v1.json").exists(), "actual screen failure retained")
        plan = audit_payload(root, spec)
        result["commands"] = audit_commands(root / "evidence")
        generated = audit_build(root / "evidence", plan, result["commands"])
        result["fixtures"] = audit_fixtures(root / "evidence", generated)
        screen = read_json(root / "evidence/SCREEN_RESULT_v1.json")
        require(screen["all_passed"] is True and len(screen["retained_parquets"]) == 6
                and screen["result"] == read_json(root / "evidence/output/fixtures/RESULT_v1.json")
                and screen["kernel_or_market_run"] is False and screen["timing_result"] is False
                and screen["official_gate"] is False and screen["rankable"] is False, "host result actual binding")
        require(screen["actual_container"] == read_json(root / "evidence/fixture-inspect-after.log")[0], "host actual inspected state binding")
        suffixes = set()
        for row in screen["retained_parquets"]:
            suffix = row["path"].split("/output/fixtures/", 1)[-1]
            require(suffix in {arm + "/" + name for arm in ARMS for name in ("trace.parquet", "message_trace.parquet")}
                    and suffix not in suffixes, "host retained Parquet unique roster")
            suffixes.add(suffix)
            require(pin(root / "evidence/output/fixtures" / suffix) == {k: row[k] for k in ("bytes", "sha256")}, "host retained Parquet hash/bytes")
        require(not any(x in sys.modules for x in ("observer", "abides_core", "abides_fork", "canonical_buffers", "t3_canonical_engine")), "participant import during data decode")
        result["all_passed"] = True
        result["limitations"] = ["The independent decoder versions differ from pinned participant libraries; retained exact schema and bytes remain compared.",
            "Primary API files were overwritten after size/SHA+Arrow readback; retained6 files are complete serializer controls.",
            "Raw state unchanged is an actual source-bound assertion, not an independently decoded raw graph.",
            "Fixture/config controls do not establish full-market semantics, throughput, official score or submission readiness."]
    except BaseException as error:
        result["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        with args.out.open("x") as stream:
            stream.write(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
