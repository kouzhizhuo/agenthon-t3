# Dynamic arena V1.1 source repair Linux control wrapper

Fresh wrapper for the minimal six-helper source repair. Candidate, payload, workflow destination, evidence and artifact names are versioned; the GitHub concurrency group stays t3-serial-linux-screen-v2 to retain the shared serial lock. Existing pinned image, resource verification, failure capture, container cleanup, readonly build and complete original/native/native controls mechanics are reused.

The build container first runs a source-bound Cython translation-only preflight, verifies the generated C receipt/hash and absence of ELF/native execution, then invokes the unchanged native compiler build. Controls start only after the full build succeeds. Whole-JSON Parquet/STATE/native-selection/arena-diagnostic checks remain required. Source packaging performs no participant import, Cython translation, Docker, simulation, performance measurement or official submission.

This wrapper is unfrozen until independent source/translation gate and exact candidate/wrapper/archive binding review completes. Actual native correctness and speed are unverified. Only root uploads and serially dispatches the final byte-bound picker bundle.
