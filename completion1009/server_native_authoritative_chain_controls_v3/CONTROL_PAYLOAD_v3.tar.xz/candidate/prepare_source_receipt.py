"""Freeze fresh V3 source-only repair; never compile native or run participants."""
from pathlib import Path
import ast,hashlib,json
HERE=Path(__file__).resolve().parent
TARGET=HERE/"SOURCE_PREPARATION_RECEIPT_v1.json"
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    if TARGET.exists(): raise ValueError("fresh receipt required")
    report=json.loads((HERE/"TYPED_COMPREHENSION_REPAIR_v1.json").read_bytes())
    if report["other_private_slot_comprehensions"] != 0 or sha(HERE/"authoritative_chain.pyx")!=report["v3_pyx_sha256"]: raise ValueError("finite repair binding differs")
    review=json.loads((HERE/"INDEPENDENT_V3_TYPED_COMPREHENSION_REPAIR_REVIEW_v1.json").read_bytes())
    if review.get("status") != "PASS_SOURCE_ONLY" or review.get("all_passed") is not True or review.get("unresolved_source_blockers") != []: raise ValueError("independent finite source review required")
    paths=[p for p in sorted(HERE.rglob("*")) if p.is_file() and not any(x.startswith("._") or x=="__pycache__" for x in p.parts) and not p.name.startswith("SOURCE_PREPARATION_RECEIPT_")]
    python=[]
    for p in paths:
        if p.suffix==".py": ast.parse(p.read_bytes());compile(p.read_bytes(),str(p),"exec",dont_inherit=True);python.append(p.relative_to(HERE).as_posix())
    transcription=json.loads((HERE/"TRANSCRIPTION_v1.json").read_bytes())
    transcription.update(unfrozen=False,frozen_build_input=True)
    (HERE/"TRANSCRIPTION_v1.json").write_text(json.dumps(transcription,indent=2,sort_keys=True)+"\n")
    receipt={"schema":"t3-authoritative-chain-v3-frozen-source-preparation-v1","executive_summary":"Fresh V3 repairs the actual V2 runtime loss of NativeBook typing inside the only private-slot comprehension. An explicit typed loop preserves dictionary order and one close-price message construction, as checked independently. V2 explicit optional-call fixes remain intact. This is a frozen build input, not proof of Cython compilation, runtime outputs, speed or rank.","source_only":True,"unfrozen":False,"frozen_build_input":True,"source_pass":False,"runtime_pass":False,"participant_imported":False,"native_build_executed":False,"market_executed":False,"speed_claim":False,"python_AST_compile_checked":python,"selected_business_bodies":118,"runtime_pins_checked":64,"static_typed_source_closure":json.loads((HERE/"SOURCE_STATIC_CHECK_v1.json").read_bytes())["closure"],"typed_comprehensions_repaired":1,"supersedes":{"path":str(HERE.with_name("native_authoritative_chain_v2")/"SOURCE_PREPARATION_RECEIPT_v1.json"),"sha256":report["baseline_candidate_receipt_sha256"],"reason":"actual native runtime AttributeError at V2 _wakeup dict comprehension"},"independent_review_sha256":sha(HERE/"INDEPENDENT_V3_TYPED_COMPREHENSION_REPAIR_REVIEW_v1.json"),"files":[{"path":p.relative_to(HERE).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)} for p in paths],"remaining":["actual Linux Cython compile","original/native/native real JSON complete output/state/RNG/identity controls","measured throughput"]}
    TARGET.write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"path":str(TARGET),"bytes":TARGET.stat().st_size,"sha256":sha(TARGET),"candidate_files":len(paths)}))
if __name__=="__main__":main()
