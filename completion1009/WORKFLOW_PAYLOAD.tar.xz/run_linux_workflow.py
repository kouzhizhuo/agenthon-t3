"""Finite production-image experiment: native vs source, then select only a verified image.

Reference data and official scorers live on the evaluator host. This controller
never mounts them into a participant container or publishes an unverified arm.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
BASE = 'ghcr.io/kouzhizhuo/agenthon-t3@sha256:5a190afe0bdfe7685e64cbf1aec30d39885199c85f688a971b8d4a0ab8d217eb'
UNITS = ['t3-s001-price-time-priority', 't3-as06-throughput-fast',
         't3-mp01-stp-newest-baseline', 't3-ra01-fundamental-shock-mid', 't3-gbatch-hetero-mix']


def run(command, log, timeout=1800, env=None):
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('xb') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, timeout=timeout, env=env)
    print(log.name, 'exit', result.returncode, flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-8000:], flush=True)
        raise RuntimeError('failed stage: ' + log.name)


def inspect(image, output):
    result = subprocess.run(['docker', 'image', 'inspect', image], capture_output=True,
                            check=True, timeout=30)
    raw = result.stdout
    info = json.loads(raw)[0]
    if info.get('Os') != 'linux' or info.get('Architecture') != 'amd64':
        raise ValueError('Linux/amd64 image required')
    if info.get('Config', {}).get('Volumes'):
        raise ValueError('inherited or declared Docker VOLUME prohibited')
    output.write_bytes(raw)
    return info


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('build', 'controls', 'full', 'pilot', 'select'))
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--evaluation', type=Path, required=True)
    args = parser.parse_args()
    evidence, evaluation = args.evidence.resolve(), args.evaluation.resolve()
    evidence.mkdir(parents=True, exist_ok=True)
    if args.stage == 'build':
        # Register the base in the local Docker store before admission; BuildKit
        # alone can resolve FROM without making docker image inspect available.
        anonymous = evidence / 'anonymous-config'
        anonymous.mkdir()
        env = os.environ.copy(); env['DOCKER_CONFIG'] = str(anonymous)
        run(['docker', 'pull', '--platform', 'linux/amd64', BASE], evidence / 'base-pull.log', 600, env)
        inspect(BASE, evidence / 'BASE_IMAGE.json')
        for target in ('compiler', 'source', 'native'):
            command = ['docker', 'build', '--platform', 'linux/amd64', '--target', target,
                       '--iidfile', str(evidence / (target + '.image-id')), '-t', 't3-completion:' + target,
                       '-f', str(HERE / 'Dockerfile'), str(HERE)]
            run(command, evidence / (target + '-build.log'), 900)
            inspect('t3-completion:' + target, evidence / (target.upper() + '_IMAGE.json'))
        name = 't3-receipt-' + os.environ.get('GITHUB_RUN_ID', 'local')
        subprocess.run(['docker', 'create', '--name', name, '--entrypoint', '/usr/local/bin/python',
                        't3-completion:compiler', '--help'], check=True, timeout=30)
        try:
            subprocess.run(['docker', 'cp', name + ':/build/NATIVE_BUILD_RECEIPT.json',
                            str(evidence / 'NATIVE_BUILD_RECEIPT.json')], check=True, timeout=30)
        finally:
            subprocess.run(['docker', 'rm', name], check=True, timeout=30)
    elif args.stage == 'controls':
        for arm in ('source', 'native'):
            command = ['docker', 'run', '--rm', '--pull', 'never', '--network', 'none', '--read-only',
                       '--user', '65534:65534', '--cpus', '4', '--memory', '16g', '--memory-swap', '16g',
                       '--pids-limit', '256', '--ulimit', 'nofile=1024:1024', '--cap-drop', 'ALL',
                       '--security-opt', 'no-new-privileges', '--tmpfs', '/tmp:rw,noexec,nosuid,nodev,size=64m',
                       '--mount', 'type=bind,src=' + str(HERE / 'check_build_imports.py') + ',dst=/control.py,readonly',
                       '--entrypoint', '/usr/local/bin/python', 't3-completion:' + arm,
                       '-B', '/control.py', '--arm', arm, '--runtime', '/opt/t3-production']
            run(command, evidence / (arm + '-import-controls.json'), 180)
    elif args.stage in ('full', 'pilot'):
        command = [sys.executable, str(HERE / 'verify_linux.py'), '--image', 't3-completion:native',
                   '--baseline-image', 't3-completion:source', '--reference-root', str(evaluation / 'references'),
                   '--out-dir', str(evidence / args.stage), '--gate-python', sys.executable,
                   '--gate-kit', str(evaluation / 'track3'), '--require-gate', '--stop-on-failure']
        if args.stage == 'pilot':
            command += ['--units', *UNITS, '--repeats', '5', '--warmups', '1']
        run(command, evidence / (args.stage + '-process.log'), 5400)
    else:
        run([sys.executable, str(HERE / 'select_linux_image.py'), '--full-dir', str(evidence / 'full'),
             '--pilot-dir', str(evidence / 'pilot'), '--out', str(evidence / 'SELECTED_IMAGE.json')],
            evidence / 'select-process.log', 60)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
