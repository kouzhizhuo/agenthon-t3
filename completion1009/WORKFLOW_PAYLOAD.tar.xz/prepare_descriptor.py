"""Prepare a sealed development descriptor with the current official toolkit.

The Team Key and team proof are deliberately handled later by the official pack
command on the user's machine. This file contains only the team's public alias.
"""
import argparse
import json
from pathlib import Path
from qfbench2_common.contracts.descriptor import SubmissionDescriptor, seal_descriptor_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--digest', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if not args.digest.startswith('sha256:') or len(args.digest) != 71:
        raise ValueError('immutable SHA256 digest required')
    int(args.digest[7:], 16)
    value = {'schema_version':'1.1.0','interface_version':'2.0',
        'competition_id':'agenthon2026-simulation-dev',
        'team_id':'team-7fad481a2beb3205ab908b09d8a56ad2',
        'track':'simulation','phase':'dev','category':'simulator',
        'image':{'registry':'ghcr.io','repository':'kouzhizhuo/agenthon-t3','digest':args.digest},
        'image_access':'public','models':[],'license':'BSD-3-Clause'}
    sealed=seal_descriptor_digest(value)
    SubmissionDescriptor.from_mapping(sealed)
    args.out.write_text(json.dumps(sealed,indent=2)+'\n')
    print('official descriptor parser and JCS seal passed')


if __name__=='__main__':
    main()
