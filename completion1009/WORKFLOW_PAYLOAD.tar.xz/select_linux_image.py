#!/usr/bin/env python3
"""Select a tested local image from complete Linux correctness/timing evidence.

Selection is an unrankable local policy. This script never builds, publishes,
pushes, or submits an image; it only writes a selection receipt.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ARMS = ("candidate", "baseline")
ARM_NAMES = {"candidate": "native", "baseline": "source"}
PILOT_UNITS = {"t3-s001-price-time-priority", "t3-as06-throughput-fast",
               "t3-mp01-stp-newest-baseline", "t3-ra01-fundamental-shock-mid",
               "t3-gbatch-hetero-mix"}
NATIVE_SELECTION_RATIO = 1.01


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text())


def finite_positive(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_summary(summary, count, measured, isolation):
    require(isinstance(summary, dict), "summary must be an object")
    require(summary.get("rankable") is False, "local evidence must be unrankable")
    require(summary.get("all_passed") is True and summary.get("complete_roster") is True,
            "complete all-passed verification required")
    require(summary.get("planned_units") == count and summary.get("completed_units") == count
            and summary.get("passed_units") == count, "completed/passed unit counts differ")
    require(summary.get("records") == measured + (10 if count == 5 else 0)
            and summary.get("measured_records") == measured, "summary run counts differ")
    require(summary.get("isolated_markets") == isolation
            and summary.get("isolated_markets_passed") == isolation, "batch isolation counts differ")
    require(summary.get("failure") is None and summary.get("cancelled_signal") is None,
            "failed or cancelled verification cannot select an image")
    for field in ("input_files_unchanged", "reference_files_unchanged", "validator_unchanged",
                  "verifier_unchanged", "all_container_cleanup_passed"):
        require(summary.get(field) is True, "verification condition failed: " + field)


def frame_identity(frame):
    require(frame.get("passed") is True, "reference frame comparison failed")
    candidate, reference = frame.get("candidate_sha256"), frame.get("reference_sha256")
    require(all(isinstance(value, str) and len(value) == 64
                and all(char in "0123456789abcdef" for char in value)
                for value in (candidate, reference)), "frame SHA256 missing or malformed")
    require(frame.get("candidate_rows") == frame.get("reference_rows"), "reference row count differs")
    return (candidate, reference, frame["candidate_rows"])


def validate_rows(rows, expected_units, repeats, include_warmup, expected_frames=None):
    require(isinstance(rows, list), "RAW_RESULTS must be a list")
    units = {row.get("unit") for row in rows}
    require(units == expected_units, "RAW_RESULTS unit roster differs")
    expected_repeats = set(range(repeats)) | ({-1} if include_warmup else set())
    require(len(rows) == len(units) * len(expected_repeats) * 2, "RAW_RESULTS run count differs")
    indexed, images = {}, {}
    frame_count = 0
    for row in rows:
        key = (row.get("unit"), row.get("arm"), row.get("repeat"))
        require(key not in indexed and key[1] in ARMS and key[2] in expected_repeats,
                "duplicate or unknown unit/arm/repeat")
        require(row.get("warmup") is (key[2] < 0), "warmup marker differs from repeat")
        require(row.get("rankable") is False and row.get("passed") is True, "failed/rankable raw run")
        execution, checks = row.get("execution", {}), row.get("checks", {})
        require(execution.get("succeeded") is True and execution.get("exit_code") == 0
                and execution.get("OOMKilled") is False, "failed container execution")
        require(checks.get("passed") is True, "output contracts failed")
        cleanup = execution.get("cleanup", {})
        require(cleanup.get("settled") is True and cleanup.get("final_absent") is True
                and cleanup.get("errors") == [], "container cleanup failed")
        developer = row.get("developer_verifier", {})
        require(developer.get("status") == "completed" and developer.get("admissible") is True
                and developer.get("verdict", {}).get("admissible") is True,
                "current developer verifier did not admit every run")
        image = execution.get("image_id")
        require(isinstance(image, str) and image.startswith("sha256:") and len(image) == 71,
                "immutable image ID required")
        if key[1] in images:
            require(images[key[1]] == image, "image changed within an arm")
        images[key[1]] = image
        wall, rate, count = execution.get("host_wall_sec"), row.get("host_events_per_sec"), checks.get("actual_events")
        require(finite_positive(wall) and finite_positive(rate) and isinstance(count, int)
                and not isinstance(count, bool) and count > 0, "invalid host wall/rate/event count")
        require(math.isclose(rate, count / wall, rel_tol=1e-9, abs_tol=1e-9), "host rate does not match host elapsed")
        frames = checks.get("frames")
        require(isinstance(frames, list) and len(frames) >= 2 and len(frames) % 2 == 0,
                "market/ledger reference frame pairs missing")
        identities = [frame_identity(frame) for frame in frames]
        frame_count += len(frames)
        repeated = row.get("repeat_parquet_equality")
        if key[2] > 0:
            require(isinstance(repeated, dict) and repeated.get("passed") is True
                    and len(repeated.get("frames", [])) == len(frames)
                    and all(frame.get("passed") is True and frame.get("byte_equal") is True
                            for frame in repeated["frames"]), "repeat byte stability evidence failed")
        indexed[key] = {"row": row, "frames": identities, "count": count}
    for unit in units:
        for arm in ARMS:
            require({key[2] for key in indexed if key[:2] == (unit, arm)} == expected_repeats,
                    "missing repeat or warmup")
            first = indexed[(unit, arm, min(expected_repeats))]
            for repeat in expected_repeats:
                current = indexed[(unit, arm, repeat)]
                require(current["frames"] == first["frames"] and current["count"] == first["count"],
                        "Parquet bytes or event count changed across repeats/warmup")
        for repeat in expected_repeats:
            a, b = indexed[(unit, "candidate", repeat)], indexed[(unit, "baseline", repeat)]
            require(a["frames"] == b["frames"] and a["count"] == b["count"],
                    "native/source paired Parquet output differs")
    if expected_frames is not None:
        require(frame_count == expected_frames, "full reference frame count differs")
    require(set(images) == set(ARMS), "both image arms required")
    return indexed, images, frame_count


def select(full_dir, pilot_dir):
    full_summary, full_rows = read_json(full_dir / "SUMMARY.json"), read_json(full_dir / "RAW_RESULTS.json")
    pilot_summary, pilot_rows = read_json(pilot_dir / "SUMMARY.json"), read_json(pilot_dir / "RAW_RESULTS.json")
    check_summary(full_summary, 71, 142, 60)
    check_summary(pilot_summary, 5, 50, 10)
    full_units = {row.get("unit") for row in full_rows}
    require(len(full_units) == 71 and "t3-EXAMPLE-vectorized-matching" not in full_units,
            "full current 71-unit roster required")
    require(PILOT_UNITS <= full_units, "full roster lacks fixed pilot units")
    _, full_images, frame_count = validate_rows(full_rows, full_units, 1, False, 380)
    indexed, pilot_images, pilot_frames = validate_rows(pilot_rows, PILOT_UNITS, 5, True)
    require(full_images == pilot_images, "pilot and full correctness images differ")
    unit_rates = []
    means = {arm: [] for arm in ARMS}
    for unit in sorted(PILOT_UNITS):
        rates = {arm: [indexed[(unit, arm, repeat)]["row"]["host_events_per_sec"]
                       for repeat in range(5)] for arm in ARMS}
        medians = {arm: statistics.median(values) for arm, values in rates.items()}
        for arm in ARMS:
            means[arm].append(medians[arm])
        unit_rates.append({"unit": unit, "measured_host_events_per_sec": rates,
                           "median_host_events_per_sec": {ARM_NAMES[arm]: value for arm, value in medians.items()},
                           "native_over_source_ratio": medians["candidate"] / medians["baseline"]})
    scores = {arm: statistics.mean(values) for arm, values in means.items()}
    ratio = scores["candidate"] / scores["baseline"]
    chosen = "candidate" if ratio > NATIVE_SELECTION_RATIO else "baseline"
    return {"status": "selected", "rankable": False, "selected_arm": ARM_NAMES[chosen],
            "selected_raw_arm": chosen, "selected_image_id": full_images[chosen],
            "image_ids": {ARM_NAMES[arm]: image for arm, image in full_images.items()},
            "selection_policy": "arithmetic mean of per-unit median host_events_per_sec; choose native only if native/source > 1.01, otherwise source",
            "policy_is_official_gate": False, "native_selection_ratio_strictly_greater_than": NATIVE_SELECTION_RATIO,
            "arithmetic_mean_unit_median_host_events_per_sec": {ARM_NAMES[arm]: score for arm, score in scores.items()},
            "native_over_source_score_ratio": ratio, "unit_rates": unit_rates,
            "validated": {"full_units": 71, "full_runs": 142, "full_isolated_markets": 60,
                          "full_reference_frame_comparisons": frame_count, "pilot_units": 5,
                          "pilot_measured_runs": 50, "pilot_warmup_runs": 10,
                          "pilot_isolated_markets": 10, "pilot_frame_comparisons": pilot_frames,
                          "all_current_developer_verdicts_admissible": True,
                          "all_repeat_and_pair_parquet_bytes_identical": True},
            "publication_performed": False, "competition_upload_performed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full-dir", type=Path, required=True)
    parser.add_argument("--pilot-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True, help="fresh SELECTED_IMAGE.json file")
    args = parser.parse_args()
    paths = {"full_dir": args.full_dir.resolve(), "pilot_dir": args.pilot_dir.resolve()}
    try:
        result = select(paths["full_dir"], paths["pilot_dir"])
        code = 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        result = {"status": "rejected_evidence", "rankable": False,
                  "failure": {"type": type(error).__name__, "message": str(error)},
                  "publication_performed": False, "competition_upload_performed": False}
        code = 1
    result["evidence"] = {name: str(path) for name, path in paths.items()}
    result["evidence_file_sha256"] = {name + "/" + file: sha256(path / file)
        for name, path in paths.items() for file in ("SUMMARY.json", "RAW_RESULTS.json") if (path / file).is_file()}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main())
