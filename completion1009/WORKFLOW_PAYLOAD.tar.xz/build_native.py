"""Build the ten exact-object Cython modules without compiling numeric operations."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import sysconfig

from Cython.Compiler.Main import CompilationOptions, default_options, compile as generate
import Cython


root = Path(__file__).resolve().parent
spec = json.loads((root / 'build_spec.json').read_text())
if Cython.__version__ != spec['cython']:
    raise RuntimeError('pinned Cython version required')
runtime = root / 'runtime'
generated = root / 'generated'
generated.mkdir(exist_ok=True)
receipts = []
for module in spec['modules']:
    source = runtime / module['source_relative']
    original = source.read_bytes()
    if len(original) != module['bytes'] or hashlib.sha256(original).hexdigest() != module['sha256']:
        raise ValueError('frozen source mismatch: ' + module['name'])
    tree = ast.parse(original)
    future_annotations = any(isinstance(node, ast.ImportFrom) and node.module == '__future__'
        and any(alias.name == 'annotations' for alias in node.names) for node in tree.body)
    restored_classes = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        fields = [field for field in node.body if isinstance(field, ast.AnnAssign)
                  and isinstance(field.target, ast.Name)]
        if fields:
            # Cython's annotation_typing=False protects Python numeric semantics,
            # but dataclasses still need their Python class annotations at import.
            values = [ast.Constant(ast.unparse(field.annotation)) if future_annotations
                      else field.annotation for field in fields]
            node.body.append(ast.Assign(targets=[ast.Name(id='__annotations__', ctx=ast.Store())],
                value=ast.Dict(keys=[ast.Constant(field.target.id) for field in fields], values=values)))
            restored_classes.append(node.name)
    ast.fix_missing_locations(tree)
    source.write_text(ast.unparse(tree) + '\n')
    output = generated / (module['name'].replace('.', '_') + '.c')
    options = CompilationOptions(default_options, compiler_directives=spec['directives'],
                                 output_file=str(output), include_path=[str(runtime)], cplus=False)
    result = generate(str(source), options=options, full_module_name=module['name'])
    if result.num_errors:
        raise RuntimeError('Cython generation failed: ' + module['name'])
    target = source.with_name(source.stem + sysconfig.get_config_var('EXT_SUFFIX'))
    command = ['gcc', '-shared', *spec['compile_flags'],
               '-I' + sysconfig.get_paths()['include'], str(output), '-o', str(target)]
    subprocess.run(command, check=True, timeout=180)
    receipts.append({'module': module['name'], 'original_sha256': module['sha256'],
        'compiled_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'restored_class_annotations': restored_classes,
        'extension': target.relative_to(runtime).as_posix(),
        'extension_sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
    print(module['name'], target.name, flush=True)
(root / 'NATIVE_BUILD_RECEIPT.json').write_text(json.dumps({'Cython': Cython.__version__,
    'directives': spec['directives'], 'compile_flags': spec['compile_flags'], 'modules': receipts}, indent=2) + '\n')
