#!/usr/bin/env python3
"""Workflow import controls for the built Linux image; no simulation is run.

Invoke with the image's Python through an entrypoint override. JSON goes to
stdout so the workflow can preserve it outside the competition output tree.
"""
import argparse
from dataclasses import fields
import hashlib
import importlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import sysconfig
from typing import Optional

MODULES = {
    "abides_core.agent": "vendor/abides/abides-core/abides_core/agent.py",
    "abides_core.kernel": "vendor/abides/abides-core/abides_core/kernel.py",
    "abides_fork.agents": "abides_fork/agents.py",
    "abides_fork.trace": "abides_fork/trace.py",
    "abides_markets.agents.exchange_agent": "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py",
    "abides_markets.agents.trading_agent": "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py",
    "abides_markets.order_book": "vendor/abides/abides-markets/abides_markets/order_book.py",
    "abides_markets.orders": "vendor/abides/abides-markets/abides_markets/orders.py",
    "abides_markets.price_level": "vendor/abides/abides-markets/abides_markets/price_level.py",
    "t3_canonical_engine": "t3_canonical_engine.py",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, default=Path("/opt/t3-production"))
    parser.add_argument("--arm", choices=("source", "native"), required=True)
    args = parser.parse_args()
    if platform.system() != "Linux" or platform.machine() != "x86_64":
        raise RuntimeError("Linux x86_64 image required")
    if platform.python_implementation() != "CPython" or platform.python_version() != "3.11.17":
        raise RuntimeError("pinned CPython 3.11.17 required")
    runtime = args.runtime.resolve(strict=True)
    sys.path.insert(0, str(runtime))
    from bootstrap import activate
    activate()
    origins = []
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    for name, relative in MODULES.items():
        module = importlib.import_module(name)
        origin = Path(module.__file__).resolve(strict=True)
        source = runtime / relative
        expected = source if args.arm == "source" else source.with_name(source.stem + suffix)
        if origin != expected:
            raise RuntimeError("incorrect module origin: " + name + " " + str(origin))
        raw = origin.read_bytes()
        if args.arm == "native":
            if len(raw) < 20 or raw[:4] != b"\x7fELF" or raw[4:6] != b"\x02\x01" or int.from_bytes(raw[18:20], "little") != 62:
                raise RuntimeError("ELF64 little-endian x86_64 extension required: " + name)
        origins.append({"name": name, "origin": str(origin), "bytes": len(raw),
                        "sha256": hashlib.sha256(raw).hexdigest()})

    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.orders import Side
    expected_fields = {
        "MetricTracker": [("total_time_no_liquidity_asks", int), ("total_time_no_liquidity_bids", int),
                          ("pct_time_no_liquidity_asks", float), ("pct_time_no_liquidity_bids", float),
                          ("total_exchanged_volume", int), ("last_trade", Optional[int])],
        "BaseDataSubscription": [("agent_id", int), ("last_update_ts", int)],
        "FrequencyBasedSubscription": [("agent_id", int), ("last_update_ts", int), ("freq", int)],
        "L1DataSubscription": [("agent_id", int), ("last_update_ts", int), ("freq", int)],
        "L2DataSubscription": [("agent_id", int), ("last_update_ts", int), ("freq", int), ("depth", int)],
        "L3DataSubscription": [("agent_id", int), ("last_update_ts", int), ("freq", int), ("depth", int)],
        "TransactedVolDataSubscription": [("agent_id", int), ("last_update_ts", int), ("freq", int), ("lookback", str)],
        "EventBasedSubscription": [("agent_id", int), ("last_update_ts", int), ("event_in_progress", bool)],
        "BookImbalanceDataSubscription": [("agent_id", int), ("last_update_ts", int),
            ("event_in_progress", bool), ("min_imbalance", float), ("imbalance", Optional[float]), ("side", Optional[Side])],
    }
    dataclasses = []
    for name, expected in expected_fields.items():
        cls = getattr(ExchangeAgent, name)
        actual = [(field.name, field.type) for field in fields(cls)]
        if actual != expected:
            raise RuntimeError("dataclass fields/types differ: " + name + " " + repr(actual))
        kwargs = {key: (False if dtype is bool else "5s" if dtype is str else
                        0.3 if dtype is float else None if key in ("side", "imbalance") else 7)
                  for key, dtype in expected}
        value = cls(**kwargs)
        if vars(value) != kwargs or value != cls(**kwargs):
            raise RuntimeError("dataclass keyword construction/equality differs: " + name)
        dataclasses.append({"name": name, "fields": [key for key, _ in actual]})
    tracker = ExchangeAgent.MetricTracker()
    if any(value != 0 for value in vars(tracker).values()):
        raise RuntimeError("MetricTracker defaults differ")
    subscription = ExchangeAgent.BookImbalanceDataSubscription(2, 101, False, 0.3)
    if subscription.imbalance is not None or subscription.side is not None:
        raise RuntimeError("BookImbalanceDataSubscription defaults differ")
    from abides_core.message import Message, MessageBatch, WakeupMsg
    from abides_markets.orders import Order
    if [(field.name, field.type) for field in fields(Message)] != [("message_id", int)]:
        raise RuntimeError("Python message dataclass/ID annotations differ")
    if dict(Order.__annotations__) != {"_order_id_counter": int}:
        raise RuntimeError("Order class counter annotation differs")
    first, second = WakeupMsg(), WakeupMsg()
    if second.message_id != first.message_id + 1 or not first < second:
        raise RuntimeError("message ID ordering differs")
    batch = MessageBatch([first, second])
    if batch.messages != [first, second] or batch.message_id != second.message_id + 1:
        raise RuntimeError("message batch dataclass constructor differs")
    if list(Side.__members__) != ["BID", "ASK"] or not Side.BID.is_bid() or not Side.ASK.is_ask():
        raise RuntimeError("Side Enum behavior differs")

    help_runs = []
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    for verb in ("simulate", "simulate-batch"):
        result = subprocess.run([sys.executable, "-B", str(runtime / "agent.py"), verb, "--help"],
                                cwd="/", env=env, text=True, capture_output=True, timeout=60)
        if result.returncode != 0 or verb not in result.stdout:
            raise RuntimeError("CLI help failed: " + verb + " " + result.stderr)
        help_runs.append({"verb": verb, "returncode": result.returncode})
    print(json.dumps({"status": "passed", "arm": args.arm,
                      "python": platform.python_version(), "platform": platform.platform(),
                      "uid": os.getuid(), "modules": origins, "dataclasses": dataclasses,
                      "verb_help": help_runs, "simulation_runs": 0}, indent=2))


if __name__ == "__main__":
    main()
