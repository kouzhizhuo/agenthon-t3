"""Future isolated configured-latency build or after-each-call scalar container entry."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
from common import (CANDIDATE_RECEIPT, CANDIDATE_SHA256, inventory, safe_name, sha, verify_candidate, verify_payload, write)
from raw_check import check_controls

ROOT = Path("/opt/configured-latency-owned")
OUT = Path("/output")
FLAGS = ["-fno-fast-math", "-ffp-contract=off", "-fno-associative-math", "-fno-unsafe-math-optimizations"]


def call(command, label, seconds, allow_failure=False):
    log = OUT / (label + ".log")
    result, failure = None, None
    with log.open("xb") as stream:
        try:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=seconds)
        except BaseException as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    row = {"command": command, "returncode": None if result is None else result.returncode,
        "failure": failure, "log": {"path": log.name, "bytes": log.stat().st_size, "sha256": sha(log)}}
    write(OUT / (label + ".json"), row)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual configured-latency operation failed: " + label)
    return row


def check_build(build, candidate_review_sha256):
    verify_candidate(build)
    receipt_path = build / "BUILD_RECEIPT.json"
    receipt = json.loads(receipt_path.read_bytes())
    if (receipt.get("schema") != "t3-configured-latency-owned-actual-build-v1" or receipt.get("source_receipt_sha256") != CANDIDATE_SHA256
            or receipt.get("independent_review_sha256") != candidate_review_sha256
            or receipt.get("rng_or_market_executed") is not False or receipt.get("candidate_imported_during_build") is not False
            or receipt.get("rankable") is not False or receipt.get("numeric_flags") != FLAGS
            or receipt.get("versions", {}).get("numpy") != "1.26.4" or receipt.get("versions", {}).get("Cython") != "3.1.3"):
        raise ValueError("actual isolated build source/version/flags binding differs")
    binaries = list(build.glob("_latency_owned*.so"))
    path = safe_name(receipt["extension"]["path"])
    if len(binaries) != 1 or len(path.parts) != 1 or binaries[0] != build / path:
        raise ValueError("one exact configured-latency extension required")
    for actual_path, pin in ((binaries[0], receipt["extension"]), (build / "configured_latency.c", receipt["generated_c"]),
            (receipt_path.with_suffix(".build.log"), receipt["log"])):
        if actual_path.stat().st_size != pin["bytes"] or sha(actual_path) != pin["sha256"]:
            raise ValueError("actual generated/build bytes differ")
    with binaries[0].open("rb") as stream:
        if stream.read(4) != b"\x7fELF":
            raise ValueError("actual Linux ELF header required")
    if receipt.get("command") != [sys.executable, "-B", str(build / "setup.py"), "build_ext", "--inplace"]:
        # The controls bind mount changes only the absolute scratch directory;
        # the retained build command is checked against its original build path.
        if receipt.get("command") != [sys.executable, "-B", "/output/build/setup.py", "build_ext", "--inplace"]:
            raise ValueError("actual single setup build command differs")
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("build", "controls"))
    args = parser.parse_args()
    report = {"schema": "t3-configured-latency-owned-finite-actual-result-v1-4", "all_passed": False,
        "rankable": False, "speed_claim": False, "official_gate": False, "full71": False,
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "actual_native_build_invocations": 0,
        "mode": args.verb, "source_before": None, "source_after": None,
        "build_verified": False, "failure": None}
    build = OUT / "build" if args.verb == "build" else Path("/build")
    try:
        plan = verify_payload(ROOT)
        candidate_review_sha256 = plan["independent_candidate_review_sha256"]
        report["source_before"] = inventory(ROOT)
        if args.verb == "build":
            if build.exists():
                raise ValueError("fresh writable build scratch required")
            shutil.copytree(ROOT / "candidate", build)
            verify_candidate(build)
            report["actual_native_build_invocations"] += 1
            report["build_command"] = call([sys.executable, "-B", str(build / "build.py"),
                "--receipt", str(build / "BUILD_RECEIPT.json"), "--review", str(ROOT / "source_review/INDEPENDENT_CANDIDATE_REVIEW.json"),
                "--review-sha256", candidate_review_sha256], "native-build", 900)
        report["build_before"] = inventory(build)
        receipt = check_build(build, candidate_review_sha256)
        report.update(build_verified=True, build_receipt=receipt)
        if args.verb == "controls":
            actual_path = OUT / "LATENCY_RESULT.json"
            operation = call([sys.executable, "-B", str(build / "controls.py"),
                "--runtime", str(ROOT / "runtime/source"), "--build-receipt", str(build / "BUILD_RECEIPT.json"),
                "--out", str(actual_path)], "latency-controls", 600, allow_failure=True)
            report["controls_command"] = operation
            if actual_path.is_file():
                actual = json.loads(actual_path.read_bytes())
                report["actual_controls_summary"] = check_controls(actual, build)
                report["actual_controls_file"] = {"path": actual_path.name, "bytes": actual_path.stat().st_size, "sha256": sha(actual_path)}
            else:
                raise ValueError("actual latency result missing; see retained logs")
            if operation["returncode"] != 0 or operation["failure"] is not None:
                raise ValueError("actual latency control process failed")
        report["build_after"] = inventory(build)
        if report["build_before"] != report["build_after"]:
            raise ValueError("compiled scratch/build bytes changed during controls")
        report["all_passed"] = True
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        try:
            verify_payload(ROOT)
            report["source_after"] = inventory(ROOT)
            if report["source_before"] != report["source_after"]:
                raise ValueError("installed source changed during build/controls")
            if build.exists():
                verify_candidate(build)
            if args.verb == "controls" and report.get("build_before") is not None:
                report["build_after"] = inventory(build)
                if report["build_before"] != report["build_after"]:
                    raise ValueError("readonly build changed during failed controls")
        except BaseException as error:
            report["all_passed"] = False
            report["source_failure"] = {"type": type(error).__name__, "message": str(error)}
        # Full latency states, partial results, generated C, objects, ELF and both
        # build/control logs remain under /output even on a failed stage.
        report["retained_output_inventory"] = inventory(OUT)
        write(OUT / "ACTUAL_RESULT.json", report)
    if report["all_passed"] is not True:
        raise RuntimeError("actual configured-latency finite build/controls failed")


if __name__ == "__main__":
    main()
