Configured latency owned finite server controls V1.4.

This scratch wrapper prepares a future single native build and a separate original/new/new-repeat latency correctness run. It uses frozen configured_latency_owned_control_v1_4 and the unchanged64-file original runtime. Source-only preparation does not import or execute participant, NumPy, Cython, native, simulator, Docker or network code locally.

Candidate and wrapper source PASS reviews must be supplied with their exact SHA256 and complete reviewed file rosters before prepare.py can seal the archive. The base is the exact pinned T3 Linux amd64 image. The compiler image adds gcc/libc headers and pinned Cython3.1.3; native compilation happens once in a nonroot/offline/read-only build container with1CPU,8GiB and1GiB tmpfs. Generated C, objects, ELF, compiler/library/strict numeric flags and build logs remain retained.

The independent nonroot/offline/read-only correctness container binds compiled source at /build read-only, with4CPU,16GiB,64MiB noexec tmpfs and file/process limits. It runs24 original configured model cases with4410 calls per arm,96 scalar postprocessing transforms,4 unchanged constructor errors, default/shared/callback/global declines, model mutation, removed external-token argument, cold primitive source checks, postownership asarray/uint32 mutation and guard BaseException export. Raw per-call outcome/error/warning and complete624-word before/after states, cache bits and final actual public exports are retained.

raw_check.py uses stdlib only and rechecks fixed case/count/order/IDs, retained original/new/repeat outcomes, every complete public state, state continuity, final actual exported states, scalar bits/round results, expected native ownership/fallback, required RNG branches and mutation controls. It runs in the correctness entry process and independently in the Linux host controller. It does not treat a summary flag as the actual evidence. Saved raw data and the compiled build can be reviewed again without importing the candidate.

Container cleanup runs after any create attempt, including a create timeout. It requires exact owned name/image before kill/remove, settled PID0, successful removal and exact absence, or exact initial absence if creation was never observed. Unknown or ambiguous creation remains a failure. The workflow retains shared t3-serial-linux-screen-v2 concurrency. Full or partial results are always preserved.

This experiment establishes only finite standalone source/build/latency equivalence if actual evidence passes. It performs no market, arena integration, benchmark, full71, official submission or scoring and makes no speed/rank claim. The actual NumPy1.26.4 installed source bytes and dispatcher topology must pass authentication on the server; a mismatch is a failed prerequisite.

Fresh V1.4 binds the reviewed candidate changes and adds host raw checks for late alias predecline state export,4degenerate signedzero model cases,5string/class lookup mutations and retained full failed-constructor states. Frozen V1.2 remains unchanged.

Fresh V1.4 additionally checks constant model lookup order and4internal token mutation handoffs with an internal NumPy authority replacement. Admission cross-checks the original mtrand C RandomState state descriptors; no private C layout is used. Frozen earlier sources remain unchanged.
