"""Cold source/function/field/alias authentication for a single latency stream."""
import ast
import builtins
import hashlib
import importlib
import json
import math
from pathlib import Path
import struct
import types
import numpy_authentication as numpy_auth

HERE = Path(__file__).resolve().parent
MODEL_FIELDS = ("_model", "_mean_ns", "_sigma", "_min_ns", "_max_ns", "_alpha", "_mu", "latency_model", "random_state", "min_latency")
FLOAT_FIELDS = ("_mean_ns", "_sigma", "_min_ns", "_max_ns", "_alpha", "_mu")
BUILTINS = {n: getattr(builtins, n) for n in ("float", "int", "round", "str", "super", "type")}


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def code_for(module, class_name, name):
    tree = compile(Path(module.__file__).read_bytes(), str(Path(module.__file__)), "exec", dont_inherit=True)
    cls = next(v for v in tree.co_consts if isinstance(v, types.CodeType) and v.co_name == class_name)
    return next(v for v in cls.co_consts if isinstance(v, types.CodeType) and v.co_name == name)


def field_stamp(model):
    values = vars(model)
    return {n: struct.pack("!d", values[n]).hex() for n in FLOAT_FIELDS} | {
        "_model": values["_model"], "latency_model": values["latency_model"],
        "random_state_identity": id(values["random_state"]), "min_latency_identity": id(values["min_latency"])}


def finite_fields(model):
    values = vars(model)
    if set(values) != set(MODEL_FIELDS) or type(values["_model"]) is not str:
        return None
    if any(type(values[n]) is not float or not math.isfinite(values[n]) for n in FLOAT_FIELDS):
        return None
    low, high = values["_min_ns"], values["_max_ns"]
    if not 0 <= low <= high <= 2 ** 53 or not math.isfinite(high - low):
        return None
    if values["_model"] == "log_normal" and math.copysign(1.0, values["_sigma"]) < 0:
        return None
    if values["_model"] == "pareto" and values["_alpha"] <= 0:
        return None
    return {n: values[n] for n in ("_model", *FLOAT_FIELDS)}


class Admission:
    """Authenticated pristine source domain; no source hashing inside sample."""
    def __init__(self, config_module, latency_module, np):
        self.config, self.base, self.np = config_module, latency_module, np
        self.model_class, self.base_class = config_module.ScenarioLatencyModel, latency_module.LatencyModel
        pins = json.loads((HERE / "RUNTIME_SOURCE_PINS_v1.json").read_text())
        runtime = Path(config_module.__file__).resolve().parents[1]
        if np.__version__ != "1.26.4" or config_module.np is not np or latency_module.np is not np:
            raise ValueError("exact original NumPy modules required")
        for name, expected in pins["files"].items():
            if pin(runtime / name) != expected:
                raise ValueError("original configured/base latency source changed")
        if (Path(config_module.__file__).resolve() != runtime / "abides_fork/config.py"
                or Path(latency_module.__file__).resolve() != runtime / "vendor/abides/abides-core/abides_core/latency_model.py"
                or type(self.model_class) is not type or type(self.base_class) is not type
                or self.model_class.__bases__ != (self.base_class,) or config_module.LatencyModel is not self.base_class):
            raise ValueError("original latency class/base source identity differs")
        methods = ((config_module, self.model_class, "ScenarioLatencyModel", "__init__"),
                   (config_module, self.model_class, "ScenarioLatencyModel", "get_latency"),
                   (latency_module, self.base_class, "LatencyModel", "__init__"),
                   (latency_module, self.base_class, "LatencyModel", "get_latency"))
        # Cold source class rosters exclude injected descriptors/lookup methods.
        # Every source-declared method, including base _extract, is code-bound.
        for module, cls, class_name in ((config_module, self.model_class, "ScenarioLatencyModel"),
                                        (latency_module, self.base_class, "LatencyModel")):
            if cls.__getattribute__ is not object.__getattribute__ or hasattr(cls, "__getattr__"):
                raise ValueError("original ordinary class attribute lookup required")
            source_class = next(node for node in ast.parse(Path(module.__file__).read_bytes()).body
                                if isinstance(node, ast.ClassDef) and node.name == class_name)
            declarations = {node.name: node for node in source_class.body if isinstance(node, ast.FunctionDef)}
            roster = vars(cls)
            expected_names = {"__module__", "__doc__", *declarations}
            if cls is self.base_class:
                expected_names |= {"__dict__", "__weakref__"}
            if (set(roster) != expected_names or roster["__module__"] != module.__name__
                    or roster["__doc__"] != ast.get_docstring(source_class, clean=False)):
                raise ValueError("original source class dictionary roster differs")
            for name in ("__dict__", "__weakref__"):
                if name in roster and (type(roster[name]) is not types.GetSetDescriptorType
                        or roster[name].__objclass__ is not cls or roster[name].__name__ != name):
                    raise ValueError("original object storage descriptor differs")
            for name, declaration in declarations.items():
                fn = roster[name]
                defaults = tuple(ast.literal_eval(value) for value in declaration.args.defaults) or None
                if (type(fn) is not types.FunctionType or fn.__code__ != code_for(module, class_name, name)
                        or fn.__globals__ is not vars(module) or fn.__defaults__ != defaults or fn.__kwdefaults__ is not None):
                    raise ValueError("source-declared class method code/defaults/globals differs")
        if self.model_class.__mro__ != (self.model_class, self.base_class, object) or self.base_class.__mro__ != (self.base_class, object):
            raise ValueError("original fixed latency class MRO required")
        self.class_rosters = {cls: dict(vars(cls)) for cls in (self.model_class, self.base_class)}
        self.class_mros = {cls: cls.__mro__ for cls in (self.model_class, self.base_class)}
        self.functions, self.function_metadata = {}, {}
        for module, cls, cname, name in methods:
            value = vars(cls)[name]
            if (type(value) is not types.FunctionType or value.__code__ != code_for(module, cname, name)
                    or value.__globals__ is not vars(module) or value.__kwdefaults__ is not None):
                raise ValueError("actual original method code/globals differs")
            expected_defaults = None if cls is self.model_class else (("cubic", True, 0.5, 0.1, 10.0) if name == "__init__" else None)
            if value.__defaults__ != expected_defaults:
                raise ValueError("original latency method defaults differ")
            self.functions[(cls, name)] = value
            self.function_metadata[(cls, name)] = (value.__code__, value.__defaults__, value.__kwdefaults__, value.__globals__)
        for name, value in BUILTINS.items():
            for module in (config_module, latency_module):
                if name in vars(module) and vars(module)[name] is not value:
                    raise ValueError("overridden numeric source global")
            if getattr(builtins, name) is not value:
                raise ValueError("patched numeric builtins")
        # This constructor creates its own fresh token only after authenticating
        # the exact own source/helper/class code. No caller token is accepted.
        if (numpy_auth.__name__ != "numpy_authentication"
                or Path(numpy_auth.__file__).resolve() != HERE / "numpy_authentication.py"):
            raise ValueError("loaded authentication module must be the exact pinned own source path")
        token_class = numpy_auth.PristineToken
        own_receipt = json.loads((HERE / "SOURCE_PREPARATION_RECEIPT_v1_4.json").read_text())
        for name in ("latency_admission.py", "numpy_authentication.py"):
            expected = next(row for row in own_receipt["files"] if row["path"] == name)
            if pin(HERE / name) != {key: expected[key] for key in ("bytes", "sha256")}:
                raise ValueError("authenticated cold owner source changed")
        for name in ("__init__", "guard_identities", "verify_loaded"):
            fn = vars(token_class).get(name)
            if (type(fn) is not types.FunctionType or fn.__code__ != code_for(numpy_auth, "PristineToken", name)
                    or fn.__globals__ is not vars(numpy_auth) or fn.__defaults__ is not None or fn.__kwdefaults__ is not None):
                raise ValueError("token class method code/defaults/globals differs")
        helper_definitions = ((numpy_auth, "pin"), (numpy_auth, "all_codes"), (numpy_auth, "establish_pristine_token"))
        for module, name in helper_definitions:
            fn = vars(module).get(name)
            source = compile(Path(module.__file__).read_bytes(), str(Path(module.__file__)), "exec", dont_inherit=True)
            expected_code = next(value for value in source.co_consts if isinstance(value, types.CodeType) and value.co_name == name)
            if (type(fn) is not types.FunctionType or fn.__code__ != expected_code
                    or fn.__globals__ is not vars(module) or fn.__defaults__ is not None or fn.__kwdefaults__ is not None):
                raise ValueError("token source helper code/defaults/globals differs")
        expected_token_names = {"__module__", "__doc__", "__dict__", "__weakref__", "__init__", "guard_identities", "verify_loaded"}
        token_class_vars = vars(token_class)
        if (token_class.__module__ != numpy_auth.__name__ or token_class.__bases__ != (object,)
                or set(token_class_vars) != expected_token_names
                or token_class.__getattribute__ is not object.__getattribute__ or hasattr(token_class, "__getattr__")):
            raise ValueError("exact own token class source/lookup roster required")
        for name in ("__dict__", "__weakref__"):
            descriptor = token_class_vars[name]
            if (type(descriptor) is not types.GetSetDescriptorType or descriptor.__objclass__ is not token_class
                    or descriptor.__name__ != name):
                raise ValueError("original token storage descriptor required")
        # Genuine class.__new__ with fabricated fields can never substitute for
        # executing this authenticated constructor and all original source tests.
        numpy_token = token_class(np)
        if (type(numpy_token) is not token_class or numpy_token.np is not np
                or numpy_token.source_verified is not True or not numpy_token.verify_loaded()):
            raise ValueError("fresh internally authenticated NumPy source required")
        # The internally created token has immutable imported-authority tables.
        # Keep exact class and instance rosters plus original unbound callback;
        # a mutable instance method/class replacement can never bypass the guard.
        numpy_token.modules = types.MappingProxyType(dict(numpy_token.modules))
        numpy_token.functions = types.MappingProxyType(dict(numpy_token.functions))
        numpy_token.identities = tuple(numpy_token.identities)
        self.numpy_token_class = token_class
        self.numpy_token_roster = dict(vars(token_class))
        if (token_class.__getattribute__ is not object.__getattribute__ or hasattr(token_class, "__getattr__")
                or token_class.__mro__ != (token_class, object)):
            raise ValueError("original token ordinary attribute lookup required")
        self.numpy_token_state = dict(object.__getattribute__(numpy_token, "__dict__"))
        self.numpy_token_methods = {name: (vars(token_class)[name], vars(token_class)[name].__code__,
            vars(token_class)[name].__defaults__, vars(token_class)[name].__kwdefaults__, vars(token_class)[name].__globals__)
            for name in ("__init__", "guard_identities", "verify_loaded")}
        self.numpy_guard = vars(token_class)["guard_identities"]
        self.numpy_token = numpy_token
        self.bound_clip, self.bound_log, self.bound_zeros = np.clip, np.log, np.zeros
        self.bound_asarray, self.bound_uint32 = np.asarray, np.uint32
        mtrand = importlib.import_module("numpy.random.mtrand")
        self.randomstate_class = np.random.RandomState
        if (self.randomstate_class is not mtrand.RandomState or type(self.randomstate_class) is not type
                or self.randomstate_class.__module__ != "numpy.random.mtrand"):
            raise ValueError("original mtrand C RandomState class origin required")
        self.mtrand = mtrand
        self.rng_descriptors = {name: vars(self.randomstate_class)[name] for name in ("get_state", "set_state")}
        if any(type(value) is not types.MethodDescriptorType or value.__objclass__ is not self.randomstate_class
               or value.__name__ != name for name, value in self.rng_descriptors.items()):
            raise ValueError("original mtrand C public state descriptors required")

    def class_lookup_pristine(self, model):
        if type(model) is not self.model_class:
            return False
        for cls, roster in self.class_rosters.items():
            current = vars(cls)
            if (set(current) != set(roster) or any(current[name] is not value for name, value in roster.items())
                    or cls.__mro__ != self.class_mros[cls] or cls.__getattribute__ is not object.__getattribute__
                    or hasattr(cls, "__getattr__")):
                return False
        return True

    def guard(self, model, original_rng, stamp):
        if type(original_rng) is not self.randomstate_class or not self.class_lookup_pristine(model):
            return False
        # No model lookup/vars() can run until every source class lookup
        # authority passes; access the original raw storage only after that.
        values = object.__getattribute__(model, "__dict__")
        if (type(values) is not dict or set(values) != set(MODEL_FIELDS) or values["random_state"] is not original_rng
                or type(values["_model"]) is not str or type(values["latency_model"]) is not str
                or any(type(values[n]) is not float for n in FLOAT_FIELDS)):
            return False
        if (self.config.ScenarioLatencyModel is not self.model_class or self.config.LatencyModel is not self.base_class
                or self.config.np is not self.np or self.base.np is not self.np
                or self.np.clip is not self.bound_clip or self.np.log is not self.bound_log or self.np.zeros is not self.bound_zeros
                or self.np.random.RandomState is not self.randomstate_class or self.mtrand.RandomState is not self.randomstate_class
                or any(vars(self.randomstate_class).get(name) is not value for name, value in self.rng_descriptors.items())):
            return False
        for key, fn in self.functions.items():
            cls, name = key
            code, defaults, kwdefaults, globals_ = self.function_metadata[key]
            if (vars(cls).get(name) is not fn or fn.__code__ is not code or fn.__defaults__ != defaults
                    or fn.__kwdefaults__ != kwdefaults or fn.__globals__ is not globals_):
                return False
        token_class = self.numpy_token_class
        if (type(self.numpy_token) is not token_class or token_class.__mro__ != (token_class, object)
                or token_class.__getattribute__ is not object.__getattribute__ or hasattr(token_class, "__getattr__")):
            return False
        current = vars(token_class)
        if set(current) != set(self.numpy_token_roster) or any(current[name] is not value for name, value in self.numpy_token_roster.items()):
            return False
        token_state = object.__getattribute__(self.numpy_token, "__dict__")
        if (type(token_state) is not dict or set(token_state) != set(self.numpy_token_state)
                or any(token_state[name] is not value for name, value in self.numpy_token_state.items())):
            return False
        for name, (fn, code, defaults, kwdefaults, globals_) in self.numpy_token_methods.items():
            if (current.get(name) is not fn or fn.__code__ is not code or fn.__defaults__ != defaults
                    or fn.__kwdefaults__ != kwdefaults or fn.__globals__ is not globals_):
                return False
        if not self.numpy_guard(self.numpy_token):
            return False
        if any(getattr(builtins, name) is not value for name, value in BUILTINS.items()):
            return False
        if any(name in vars(self.config) and vars(self.config)[name] is not value for name, value in BUILTINS.items()):
            return False
        return field_stamp(model) == stamp


class LatencyRegistry:
    def __init__(self, admission, native):
        self.admission, self.native, self.owners, self.original_models, self.declines = admission, native, {}, {}, []

    def acquire(self, model, active_consumer_rngs):
        # Caller enumerates actual active consumers after initialization. Any
        # second alias (trader/oracle/kernel/other latency) prevents migration.
        a = self.admission
        if type(model) is not a.model_class:
            self.declines.append("unknown-or-default-latency-class")
            return None
        # Class lookup can have changed since admission. Export a previously
        # owned model using registry identity before any possibly changed lookup.
        if not a.class_lookup_pristine(model):
            for identity, original_model in self.original_models.items():
                if original_model is model:
                    self.owners[identity].export_to_original()
            self.declines.append("unproved-method-field-or-numpy-domain")
            return None
        raw = object.__getattribute__(model, "__dict__")
        rng = raw.get("random_state") if type(raw) is dict else None
        identity = id(rng)
        if type(rng) is not a.randomstate_class or any(v is rng for v in active_consumer_rngs):
            if identity in self.owners:
                self.owners[identity].export_to_original()
            self.declines.append("nonoriginal-or-shared-randomstate")
            return None
        if identity in self.owners:
            if self.original_models[identity] is not model:
                self.owners[identity].export_to_original()
                self.declines.append("second-active-latency-model-alias")
                return None
            return self.owners[identity]
        snapshot = finite_fields(model)
        if snapshot is None or not a.guard(model, rng, field_stamp(model)):
            self.declines.append("unproved-method-field-or-numpy-domain")
            return None
        state = rng.get_state()
        if (type(state) is not tuple or len(state) != 5 or state[0] != "MT19937"
                or type(state[1]) is not a.np.ndarray or state[1].dtype != a.np.dtype("uint32")
                or state[1].shape != (624,) or type(state[2]) is not int or not 0 <= state[2] <= 624
                or type(state[3]) is not int or state[3] not in (0, 1)
                or type(state[4]) is not float or not math.isfinite(state[4])):
            self.declines.append("unproved-public-randomstate-domain")
            return None
        owner = self.native.ConfiguredLatencyOwner(model, a.np,
            (state[0], [int(v) for v in state[1]], state[2], state[3], state[4]), snapshot,
            a.guard, field_stamp(model), a.functions[(a.model_class, "get_latency")],
            a.bound_asarray, a.bound_uint32, rng.set_state)
        self.owners[identity], self.original_models[identity] = owner, model
        return owner

    def release_all(self):
        for owner in self.owners.values():
            owner.export_to_original()
