"""Future standalone scalar/actual-method controls; no market or arena integration."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import warnings

HERE = Path(__file__).resolve().parent


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def scalar(value, np):
    kind = type(value).__module__ + "." + type(value).__name__
    if type(value) in (float, np.float64):
        return {"type": kind, "bits": struct.pack("!d", value).hex()}
    if type(value) is int:
        return {"type": kind, "value": str(value)}
    if value is None:
        return {"type": "builtins.NoneType"}
    if type(value) is np.ndarray:
        return {"type": kind, "dtype": str(value.dtype), "shape": list(value.shape), "bytes": value.tobytes().hex()}
    if type(value) is np.int64:
        return {"type": kind, "value": str(int(value))}
    if type(value) is str:
        return {"type": kind, "value": value}
    raise TypeError("unsupported retained scalar input/result")


def state_record(rng, np, owner=None):
    state = owner.state_tuple() if owner is not None else rng.get_state()
    return {"kind": state[0], "words_le_hex": struct.pack("<624I", *state[1]),
            "position": state[2], "has_gauss": state[3], "gauss_bits": struct.pack("!d", state[4])}


def json_state(state):
    return dict(state, words_le_hex=state["words_le_hex"].hex(), gauss_bits=state["gauss_bits"].hex())


def outcome(call, np):
    with warnings.catch_warnings(record=True) as observed:
        warnings.simplefilter("always")
        try:
            value = call()
        except Exception as error:
            result = {"returned": False, "error_type": type(error).__module__ + "." + type(error).__name__, "message": str(error)}
        else:
            result = {"returned": True, "result": scalar(value, np)}
        result["warnings"] = [{"type": v.category.__module__ + "." + v.category.__name__, "message": str(v.message)} for v in observed]
        return result


def transform_cases(np):
    values = [-0.0, 0.0, -1.0, 0.5, 1.5, 2.5, 3.0,
              float(np.nextafter(0.5, 0.0)), float(np.nextafter(0.5, 1.0)),
              float(np.nextafter(1.5, 1.0)), float(np.nextafter(1.5, 2.0)),
              float(2 ** 52 - 0.5), float(2 ** 52), float(2 ** 53), float("inf"), float("-inf")]
    cases = []
    for lower, upper in ((0.0, 3.0), (-0.0, 0.0), (0.0, -0.0), (-0.0, -0.0), (1.5, 1.5), (0.0, float(2 ** 53))):
        for value in values:
            cases.append((value, lower, upper))
    return cases


def model_cases():
    # Every constructor stays original; fields may be explicitly patched solely
    # for finite fallback controls and the exact patches are retained.
    return [
        ("uniform", {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}, {}, {}, 700),
        ("lognormal", {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}, {}, {}, 700),
        ("pareto", {"model": "pareto", "params": {"min_ns": 1, "max_ns": 2000, "alpha": 1.5}}, {}, {}, 700),
        ("uniform_equal_still_draws", {"model": "uniform", "params": {"min_ns": 5, "max_ns": 5}}, {}, {}, 20),
        ("lognormal_zero_sigma_still_draws", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 0}}, {}, {}, 20),
        ("rollover622", {"model": "uniform"}, {}, {"position": 622}, 700),
        ("rollover623", {"model": "uniform"}, {}, {"position": 623}, 700),
        ("rollover624", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"position": 624}, 700),
        ("pending_positive_zero", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"has_gauss": 1, "gauss": 0.0}, 20),
        ("pending_negative_zero", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"has_gauss": 1, "gauss": -0.0}, 20),
        ("pending_nonzero", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"has_gauss": 1, "gauss": -1.2345}, 20),
        ("lognormal_positive_overflow", {"model": "log_normal", "params": {"mean_ns": 1, "sigma": 1}}, {"_mu": 710.0}, {}, 20),
        ("pareto_positive_overflow", {"model": "pareto", "params": {"alpha": 1e-300}}, {}, {}, 20),
        ("constant_unknown", {"model": "source-unknown-constant", "params": {"mean_ns": 1.5}}, {}, {}, 20),
        ("negativezero_sigma_fallback", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": -0.0}}, {}, {}, 5),
        ("negative_sigma_fallback", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": -1}}, {}, {}, 5),
        ("invalid_alpha_fallback", {"model": "pareto", "params": {"alpha": 0}}, {}, {}, 5),
        ("negative_bounds_fallback", {"model": "uniform", "params": {"min_ns": -3, "max_ns": 3}}, {}, {}, 5),
        ("reversed_bounds_fallback", {"model": "uniform", "params": {"min_ns": 3, "max_ns": 0}}, {}, {}, 5),
        ("nan_string_fallback", {"model": "uniform", "params": {"min_ns": "nan", "max_ns": 3}}, {}, {}, 5),
        ("infinity_string_fallback", {"model": "uniform", "params": {"min_ns": 0, "max_ns": "inf"}}, {}, {}, 5),
        ("nullfield_fallback", {"model": "deterministic"}, {"_min_ns": None}, {}, 5),
        ("numpyfield_fallback", {"model": "deterministic"}, {"_min_ns": "NP_FLOAT64"}, {}, 5),
        ("arrayfield_fallback", {"model": "deterministic"}, {"_min_ns": "NP_ARRAY"}, {}, 5),
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(sys.platform == "linux" and not args.out.exists(), "fresh isolated Linux data controls required")
    from latency_admission import Admission, LatencyRegistry
    from numpy_authentication import establish_pristine_token
    import numpy as np
    require(np.__version__ == "1.26.4", "pinned NumPy1.26.4 required")
    build = json.loads(args.build_receipt.read_text())
    require(build["source_receipt_sha256"] == pin(HERE / "SOURCE_PREPARATION_RECEIPT_v1_4.json")["sha256"], "actual source build binding")
    extension = HERE / build["extension"]["path"]
    require(pin(extension) == {k: build["extension"][k] for k in ("bytes", "sha256")}, "actual extension pin")
    spec = importlib.util.spec_from_file_location("_latency_owned", extension)
    native = importlib.util.module_from_spec(spec); spec.loader.exec_module(native)
    sys.path.insert(0, str(args.runtime.resolve()))
    import bootstrap
    bootstrap.activate()
    from abides_fork import config
    from abides_core import latency_model
    token = establish_pristine_token(np)
    admission = Admission(config, latency_model, np)
    results = {"schema": "t3-configured-latency-standalone-controls-v1-4", "all_passed": False,
               "source_receipt_sha256": build["source_receipt_sha256"], "build_receipt": pin(args.build_receipt),
               "transforms": [], "models": [], "rankable": False, "market_executed": False, "arena_modified": False}
    try:
        for value, lower, upper in transform_cases(np):
            a = float(np.clip(value, lower, upper)); b, final = native.scalar_postprocess(value, lower, upper, np.clip)
            row = {"value": scalar(value, np), "lower": scalar(lower, np), "upper": scalar(upper, np),
                   "baseline_intermediate": scalar(a, np), "new_intermediate": scalar(b, np),
                   "baseline_result": scalar(int(round(a)), np), "new_result": scalar(final, np)}
            require(row["baseline_intermediate"] == row["new_intermediate"] and row["baseline_result"] == row["new_result"], "clip/tie/sign-zero transform differs")
            results["transforms"].append(row)
        for index, (name, definition, patch, state_patch, count) in enumerate(model_cases()):
            models, rngs = [], []
            for arm in range(3):
                rng = np.random.RandomState(93009 + index)
                model = config.ScenarioLatencyModel(2, definition, rng)
                for key, value in patch.items():
                    if type(value) is str and value == "NP_FLOAT64": value = np.float64(0.0)
                    if type(value) is str and value == "NP_ARRAY": value = np.array([0.0, 1.0])
                    setattr(model, key, value)
                if state_patch:
                    state = list(rng.get_state()); state[2] = state_patch.get("position", state[2]); state[3] = state_patch.get("has_gauss", state[3]); state[4] = state_patch.get("gauss", state[4]); rng.set_state(tuple(state))
                models.append(model); rngs.append(rng)
            registries = [LatencyRegistry(admission, native), LatencyRegistry(admission, native)]
            owners = [None, registries[0].acquire(models[1], []), registries[1].acquire(models[2], [])]
            expected_owned = "fallback" not in name
            require([owner is not None for owner in owners] == [False, expected_owned, expected_owned],
                    "expected exact native ownership or whole-method fallback not selected")
            originals = [model.random_state for model in models]
            rows = []
            try:
                for ordinal in range(count):
                    # Self IDs and repeat independent sends interleaved. Every
                    # nonself call makes its original single distribution draw.
                    sender, recipient = (0, 0) if ordinal % 7 == 0 else ((0, 1) if ordinal % 2 else (1, 0))
                    outcomes, states = [], []
                    for arm in range(3):
                        before = state_record(rngs[arm], np, owners[arm])
                        call = (lambda arm=arm: owners[arm].sample(sender, recipient)) if owners[arm] is not None else (lambda arm=arm: models[arm].get_latency(sender, recipient))
                        result = outcome(call, np)
                        after = state_record(rngs[arm], np, owners[arm])
                        outcomes.append(result); states.append((before, after))
                    require(outcomes[0] == outcomes[1] == outcomes[2] and states[0] == states[1] == states[2], "actual original latency outcome/full624 state differs")
                    require(all(m.random_state is original for m, original in zip(models, originals)), "original model/RNG identity changed")
                    rows.append({"ordinal": ordinal, "sender": sender, "recipient": recipient, "outcomes": outcomes,
                                 "before_states": [json_state(s[0]) for s in states], "after_states": [json_state(s[1]) for s in states]})
            finally:
                for registry in registries: registry.release_all(); registry.release_all()
            exported = [json_state(state_record(rng, np)) for rng in rngs]
            require(exported[0] == exported[1] == exported[2], "actual original public exported tuple differs")
            results["models"].append({"name": name, "definition": definition, "field_patch": {k: scalar(getattr(models[0], k), np) for k in patch},
                "initial_state_patch": state_patch, "calls": rows, "owners_selected": [owner is not None for owner in owners],
                "final_exported_actual_states": exported, "diagnostics": [None if owner is None else owner.diagnostics() for owner in owners],
                "declines": [registry.declines for registry in registries]})
        constructors = []
        for definition in ({"model": "uniform", "params": {"min_ns": None}},
                           {"model": "log_normal", "params": {"sigma": None}},
                           {"model": "pareto", "params": {"alpha": None}},
                           {"model": "uniform", "params": {"min_ns": "not-a-number"}}):
            outcomes, constructor_before, constructor_after = [], [], []
            for arm in range(3):
                rng = np.random.RandomState(96009)
                before = json_state(state_record(rng, np))
                with warnings.catch_warnings(record=True) as observed:
                    warnings.simplefilter("always")
                    try:
                        config.ScenarioLatencyModel(2, definition, rng)
                    except Exception as error:
                        row = {"returned": False, "error_type": type(error).__module__ + "." + type(error).__name__, "message": str(error)}
                    else:
                        row = {"returned": True}
                    row["warnings"] = [{"type": w.category.__module__ + "." + w.category.__name__, "message": str(w.message)} for w in observed]
                after = json_state(state_record(rng, np))
                require(before == after, "original failed constructor consumed RNG")
                constructor_before.append(before); constructor_after.append(after)
                outcomes.append(row)
            require(outcomes[0] == outcomes[1] == outcomes[2] and outcomes[0]["returned"] is False, "original constructor fallback/errors differ")
            constructors.append({"definition": definition, "outcomes": outcomes, "no_native_acquisition": True,
                                 "before_states": constructor_before, "after_states": constructor_after})
        results["original_constructor_errors"] = constructors
        # Original default generated class stays original with no owner.
        rng = np.random.RandomState(95108)
        default_model = latency_model.LatencyModel(rng, np.zeros((2, 2)), latency_model="deterministic")
        registry = LatencyRegistry(admission, native)
        before = json_state(state_record(rng, np))
        require(registry.acquire(default_model, []) is None and registry.owners == {}, "default latency wrongly acquired")
        result = outcome(lambda: default_model.get_latency(0, 1), np)
        results["default_fallback"] = {"outcome": result, "before": before, "after": json_state(state_record(rng, np)), "declines": registry.declines}
        # Direct alias controls: acquisition must decline before any draw.
        model = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95109))
        registry = LatencyRegistry(admission, native)
        before = json_state(state_record(model.random_state, np))
        require(registry.acquire(model, [model.random_state]) is None and registry.owners == {}, "shared active consumer wrongly migrated")
        require(before == json_state(state_record(model.random_state, np)), "alias decline consumed RNG")
        results["alias_decline"] = {"initial_state": before, "declines": registry.declines, "no_native_acquisition": True}
        # Mutation after ownership exports the consumed state before original
        # fallback and remains original; the market is never rerun.
        model_a = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95110))
        model_b = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95110))
        registry = LatencyRegistry(admission, native); owner = registry.acquire(model_b, [])
        require(owner is not None, "mutation control native owner absent")
        require(model_a.get_latency(0, 1) == owner.sample(0, 1), "mutation prelude differs")
        model_a._max_ns = model_b._max_ns = -1.0
        a = outcome(lambda: model_a.get_latency(0, 1), np); b = outcome(lambda: owner.sample(0, 1), np)
        require(a == b and json_state(state_record(model_a.random_state, np)) == json_state(state_record(model_b.random_state, np)), "mutation whole-method export/fallback differs")
        require(owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1, "mutated field failed permanent export")
        registry.release_all();registry.release_all()
        results["mutation_fallback"] = {"outcomes": [a, b], "actual_exported_state": json_state(state_record(model_b.random_state, np)), "diagnostics": owner.diagnostics()}
        # Existing genuine method can be independently monkeypatched; admission
        # must refuse before acquiring state and restore exact source identity.
        old = config.ScenarioLatencyModel.get_latency
        patched = lambda self, sender, recipient: old(self, sender, recipient)
        config.ScenarioLatencyModel.get_latency = patched
        try:
            model = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95111))
            registry = LatencyRegistry(admission, native)
            before = json_state(state_record(model.random_state, np))
            require(registry.acquire(model, []) is None and registry.owners == {}, "patched callback migrated")
            require(before == json_state(state_record(model.random_state, np)), "patched callback decline changed RNG")
            results["patched_callback_fallback"] = {"declines": registry.declines, "before": before, "no_acquisition": True}
        finally:
            config.ScenarioLatencyModel.get_latency = old
        old_clip = np.clip
        np.clip = lambda *a, **k: old_clip(*a, **k)
        try:
            model = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95112))
            registry = LatencyRegistry(admission, native)
            before = json_state(state_record(model.random_state, np))
            require(registry.acquire(model, []) is None and registry.owners == {}, "patched numpy global migrated")
            require(before == json_state(state_record(model.random_state, np)), "patched global decline changed RNG")
            results["patched_np_clip_fallback"] = {"declines": registry.declines, "before": before, "no_acquisition": True}
        finally:
            np.clip = old_clip
        # The old external-token interface is removed: even a genuine token
        # class constructed without __init__ cannot enter Admission.
        forged_token = type(token).__new__(type(token))
        forged_token.np, forged_token.source_verified = np, True
        try:
            Admission(config, latency_model, np, forged_token)
        except TypeError:
            results["forged_token_refused"] = {"external_token_parameter_removed": True, "error_type": "builtins.TypeError"}
        else:
            raise ValueError("external forged token still accepted")
        # Cold source authentication must reject changed primitive authorities.
        results["cold_export_helper_declines"] = []
        for key, replacement in (("asarray", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("patched export asarray invoked"))),
                                 ("uint32", int)):
            original = getattr(np, key)
            setattr(np, key, replacement)
            try:
                try:
                    Admission(config, latency_model, np)
                except ValueError as error:
                    results["cold_export_helper_declines"].append({"name": key, "error_type": "builtins.ValueError", "message": str(error)})
                else:
                    raise ValueError("changed cold export helper authenticated")
            finally:
                setattr(np, key, original)
        # A postownership replacement that would break live export is never
        # called. The saved original helper and original bound set_state export
        # before the current original method handles the next call.
        results["export_helper_mutation_fallbacks"] = []
        for index, key in enumerate(("asarray", "uint32")):
            model_a = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95200 + index))
            model_b = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95200 + index))
            registry = LatencyRegistry(admission, native); owner = registry.acquire(model_b, [])
            require(owner is not None, "export helper mutation owner absent")
            before = [json_state(state_record(model_a.random_state, np)), json_state(state_record(model_b.random_state, np, owner))]
            prelude = [outcome(lambda: model_a.get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
            require(prelude[0] == prelude[1], "export helper mutation prelude differs")
            consumed = [json_state(state_record(model_a.random_state, np)), json_state(state_record(model_b.random_state, np, owner))]
            require(before[0] == before[1] and consumed[0] == consumed[1], "export helper mutation prelude state differs")
            original, changed_calls = getattr(np, key), []
            def changed_helper(*args, **kwargs):
                changed_calls.append(True)
                raise RuntimeError("patched export helper invoked")
            setattr(np, key, changed_helper)
            try:
                pair = [outcome(lambda: model_a.get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
                actual = [json_state(state_record(model_a.random_state, np)), json_state(state_record(model_b.random_state, np))]
                require(pair[0] == pair[1] and actual[0] == actual[1], "export helper mutation actual original fallback differs")
                require(changed_calls == [] and owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1,
                        "changed export helper called or permanent export failed")
                registry.release_all(); registry.release_all()
                results["export_helper_mutation_fallbacks"].append({"name": key, "before": before, "prelude": prelude,
                    "consumed_states": consumed, "fallback_outcomes": pair, "final_actual_exported_states": actual,
                    "changed_helper_calls": len(changed_calls), "diagnostics": owner.diagnostics()})
            finally:
                setattr(np, key, original)
        # Guard failures raise BaseException without another RNG draw. Public
        # sample exports the consumed state before that exception is observed.
        class ControlAbort(BaseException):
            pass
        model_a = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95210))
        model_b = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95210))
        active_guard = {"raise": False}
        def guard_or_abort(model, rng, stamp):
            if active_guard["raise"]:
                raise ControlAbort("finite guard abort")
            return admission.guard(model, rng, stamp)
        abort_admission = Admission(config, latency_model, np)
        abort_admission.guard = guard_or_abort
        registry = LatencyRegistry(abort_admission, native); owner = registry.acquire(model_b, [])
        require(owner is not None, "guard abort owner absent")
        prelude = [outcome(lambda: model_a.get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
        consumed = [json_state(state_record(model_a.random_state, np)), json_state(state_record(model_b.random_state, np, owner))]
        require(prelude[0] == prelude[1] and consumed[0] == consumed[1], "guard abort consumed prelude differs")
        active_guard["raise"] = True
        try:
            owner.sample(0, 1)
        except ControlAbort as error:
            observed_abort = {"type": "ControlAbort", "message": str(error)}
        else:
            raise ValueError("guard BaseException swallowed")
        actual = json_state(state_record(model_b.random_state, np))
        require(actual == consumed[0] and owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1,
                "guard BaseException consumed state not exported")
        registry.release_all(); registry.release_all()
        results["guard_baseexception_export"] = {"prelude": prelude, "consumed_states": consumed,
            "observed_exception": observed_abort, "final_actual_exported_state": actual, "diagnostics": owner.diagnostics()}
        # A consumer alias may be discovered only after an owned draw. Any
        # reacquisition must export the authoritative stream before declining.
        model_a = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95220))
        model_b = config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95220))
        registry = LatencyRegistry(admission, native); owner = registry.acquire(model_b, [])
        require(owner is not None, "late alias owner absent")
        before = [json_state(state_record(model_a.random_state, np)), json_state(state_record(model_b.random_state, np, owner))]
        prelude = [outcome(lambda: model_a.get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
        consumed = [json_state(state_record(model_a.random_state, np)), json_state(state_record(model_b.random_state, np, owner))]
        require(before[0] == before[1] and prelude[0] == prelude[1] and consumed[0] == consumed[1], "late alias prelude differs")
        require(registry.acquire(model_b, [model_b.random_state]) is None, "late active alias wrongly retained")
        actual = json_state(state_record(model_b.random_state, np))
        require(actual == consumed[0] and owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1,
                "late active alias failed predecline export")
        followup = [outcome(lambda: model_a.get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
        final = [json_state(state_record(model_a.random_state, np)), json_state(state_record(model_b.random_state, np))]
        require(followup[0] == followup[1] and final[0] == final[1], "late alias original followup differs")
        registry.release_all(); registry.release_all()
        results["late_alias_export"] = {"before": before, "prelude": prelude, "consumed_states": consumed,
            "actual_export_after_decline": actual, "followup": followup, "final_actual_states": final,
            "diagnostics": owner.diagnostics(), "declines": registry.declines}
        # Degenerate bounds select original NumPy's operand sign even when the
        # already-drawn value lies strictly outside the equal +/-zero interval.
        results["degenerate_signedzero_models"] = []
        for index, (lower, upper, mean) in enumerate(((-0.0, 0.0, -1.0), (0.0, -0.0, -1.0), (-0.0, -0.0, 1.0), (0.0, 0.0, 1.0))):
            models = [config.ScenarioLatencyModel(2, {"model": "deterministic", "params": {"mean_ns": mean}}, np.random.RandomState(95230 + index)) for _ in range(3)]
            for model in models:
                model._min_ns, model._max_ns = lower, upper
            registries = [LatencyRegistry(admission, native), LatencyRegistry(admission, native)]
            owners = [None, registries[0].acquire(models[1], []), registries[1].acquire(models[2], [])]
            require(all(owner is not None for owner in owners[1:]), "degenerate signedzero owner absent")
            before = [json_state(state_record(model.random_state, np, owner)) for model, owner in zip(models, owners)]
            outcomes = [outcome((lambda model=model: model.get_latency(0, 1)) if owner is None else (lambda owner=owner: owner.sample(0, 1)), np) for model, owner in zip(models, owners)]
            for registry in registries: registry.release_all(); registry.release_all()
            actual = [json_state(state_record(model.random_state, np)) for model in models]
            require(outcomes[0] == outcomes[1] == outcomes[2] and before[0] == before[1] == before[2]
                    and actual[0] == actual[1] == actual[2] == before[0], "degenerate signedzero original postprocess differs")
            require(all(owner.diagnostics()["postprocess_handoffs"] == 1 and owner.diagnostics()["handoffs"] == 1 for owner in owners[1:]),
                    "degenerate bounds did not use original postprocess")
            results["degenerate_signedzero_models"].append({"lower": scalar(lower, np), "upper": scalar(upper, np), "mean": scalar(mean, np),
                "before_states": before, "outcomes": outcomes, "final_actual_states": actual,
                "diagnostics": [None if owner is None else owner.diagnostics() for owner in owners]})
        # Exact str drift and class lookup mutations must export before current
        # original fallback, even if an equal-valued subclass disguises itself.
        class BranchString(str):
            def __eq__(self, other):
                return other == "log_normal"
        results["lookup_mutation_fallbacks"] = []
        for index, mutation in enumerate(("model-string-subclass", "latency-string-subclass", "class-getattribute", "class-getattr", "class-descriptor")):
            models = [config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95240 + index)) for _ in range(2)]
            registry = LatencyRegistry(admission, native); owner = registry.acquire(models[1], [])
            require(owner is not None, "lookup mutation owner absent")
            prelude = [outcome(lambda: models[0].get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
            consumed = [json_state(state_record(models[0].random_state, np)), json_state(state_record(models[1].random_state, np, owner))]
            require(prelude[0] == prelude[1] and consumed[0] == consumed[1], "lookup mutation prelude differs")
            changed_class_key = None
            if mutation == "model-string-subclass":
                for model in models: model._model = BranchString("uniform")
            elif mutation == "latency-string-subclass":
                for model in models: model.latency_model = BranchString("deterministic")
            elif mutation == "class-getattribute":
                changed_class_key = "__getattribute__"
                def changed_attribute(self, name):
                    if name == "_max_ns": return 1.0
                    return object.__getattribute__(self, name)
                setattr(config.ScenarioLatencyModel, changed_class_key, changed_attribute)
            elif mutation == "class-getattr":
                changed_class_key = "__getattr__"
                setattr(config.ScenarioLatencyModel, changed_class_key, lambda self, name: 0)
            else:
                changed_class_key = "_max_ns"
                setattr(config.ScenarioLatencyModel, changed_class_key, property(lambda self: 1.0))
            try:
                outcomes = [outcome(lambda: models[0].get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
                actual = [json_state(state_record(models[0].random_state, np)), json_state(state_record(models[1].random_state, np))]
                require(outcomes[0] == outcomes[1] and actual[0] == actual[1] and owner.diagnostics()["owned"] is False
                        and owner.diagnostics()["handoffs"] == 1, "lookup mutation original export/fallback differs")
                registry.release_all(); registry.release_all()
                results["lookup_mutation_fallbacks"].append({"name": mutation, "prelude": prelude, "consumed_states": consumed,
                    "outcomes": outcomes, "final_actual_states": actual, "diagnostics": owner.diagnostics()})
            finally:
                if changed_class_key is not None:
                    delattr(config.ScenarioLatencyModel, changed_class_key)
        # A guard lookup must not touch a changed random_state attribute when
        # the current original constant branch never reads that attribute.
        models = [config.ScenarioLatencyModel(2, {"model": "deterministic", "params": {"mean_ns": 1}}, np.random.RandomState(95250)) for _ in range(2)]
        rngs = [model.random_state for model in models]
        registry = LatencyRegistry(admission, native); owner = registry.acquire(models[1], [])
        require(owner is not None, "guard lookup order owner absent")
        def changed_rng_lookup(self, name):
            if name == "random_state": raise RuntimeError("changed RNG lookup must not run")
            return object.__getattribute__(self, name)
        config.ScenarioLatencyModel.__getattribute__ = changed_rng_lookup
        try:
            outcomes = [outcome(lambda: models[0].get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
            actual = [json_state(state_record(rng, np)) for rng in rngs]
            require(outcomes[0] == outcomes[1] and outcomes[0]["returned"] is True and actual[0] == actual[1]
                    and owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1, "guard invoked changed RNG lookup before original fallback")
            registry.release_all(); registry.release_all()
            results["guard_lookup_order_fallback"] = {"outcomes": outcomes, "final_actual_states": actual, "diagnostics": owner.diagnostics()}
        finally:
            del config.ScenarioLatencyModel.__getattribute__
        # Internal token class/instance authorities are mutable in Python, but
        # the original unbound guard and immutable snapshot refuse all changes.
        from numpy_authentication import PristineToken
        results["token_mutation_fallbacks"] = []
        for index, mutation in enumerate(("class-guard", "instance-guard", "class-getattribute", "instance-identities")):
            models = [config.ScenarioLatencyModel(2, {"model": "uniform"}, np.random.RandomState(95260 + index)) for _ in range(2)]
            registry = LatencyRegistry(admission, native); owner = registry.acquire(models[1], [])
            require(owner is not None, "token mutation owner absent")
            prelude = [outcome(lambda: models[0].get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
            consumed = [json_state(state_record(models[0].random_state, np)), json_state(state_record(models[1].random_state, np, owner))]
            require(prelude[0] == prelude[1] and consumed[0] == consumed[1], "token mutation prelude differs")
            saved = None
            if mutation == "class-guard":
                saved = PristineToken.guard_identities
                PristineToken.guard_identities = lambda self: True
            elif mutation == "instance-guard":
                admission.numpy_token.guard_identities = lambda: True
            elif mutation == "class-getattribute":
                PristineToken.__getattribute__ = lambda self, name: (True if name == "source_verified" else object.__getattribute__(self, name))
            else:
                saved = admission.numpy_token.identities
                admission.numpy_token.identities = ()
            fromnumeric = admission.numpy_token.modules["numpy.core.fromnumeric"]
            old_wrapfunc = fromnumeric._wrapfunc
            fromnumeric._wrapfunc = lambda *args, **kwargs: old_wrapfunc(*args, **kwargs)
            try:
                outcomes = [outcome(lambda: models[0].get_latency(0, 1), np), outcome(lambda: owner.sample(0, 1), np)]
                actual = [json_state(state_record(models[0].random_state, np)), json_state(state_record(models[1].random_state, np))]
                require(outcomes[0] == outcomes[1] and actual[0] == actual[1] and owner.diagnostics()["owned"] is False
                        and owner.diagnostics()["handoffs"] == 1, "token mutation bypassed source guard")
                registry.release_all(); registry.release_all()
                results["token_mutation_fallbacks"].append({"name": mutation, "prelude": prelude, "consumed_states": consumed,
                    "outcomes": outcomes, "final_actual_states": actual, "diagnostics": owner.diagnostics()})
            finally:
                fromnumeric._wrapfunc = old_wrapfunc
                if mutation == "class-guard": PristineToken.guard_identities = saved
                elif mutation == "instance-guard": del admission.numpy_token.guard_identities
                elif mutation == "class-getattribute": del PristineToken.__getattribute__
                else: admission.numpy_token.identities = saved
        results["all_passed"] = True
    except BaseException as error:
        results["failure"] = {"type": type(error).__name__, "message": str(error)}
    args.out.write_text(json.dumps(results, sort_keys=True, indent=2, allow_nan=False) + "\n")
    require(results["all_passed"], "standalone configured latency control failed")


if __name__ == "__main__":
    main()
