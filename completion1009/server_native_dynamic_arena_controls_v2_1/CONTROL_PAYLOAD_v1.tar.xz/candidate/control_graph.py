"""Finite exact cold graph for actual JSON controls, never production imported."""
from collections import defaultdict, deque
from datetime import datetime, timedelta

BOOK_FIELDS = ("owner", "symbol", "bids", "asks", "last_trade", "book_log2", "quotes_seen", "history", "last_update_ts", "buy_transactions", "sell_transactions")
LEVEL_FIELDS = ("visible_orders", "hidden_orders", "price", "side")


def immutable_set_key(value):
    """Sort finite immutable members before allocating any alias serial."""
    if value is None or type(value) in (str, int, bool):
        return (type(value).__name__, repr(value))
    if type(value) is float:
        return ("float", value.hex())
    if type(value) is tuple:
        return ("tuple", tuple(immutable_set_key(child) for child in value))
    raise TypeError("unadmitted mutable set member")


def graph(value, np, memo=None, arena_memo=None):
    memo = {} if memo is None else memo
    arena_memo = {} if arena_memo is None else arena_memo
    if value is None or type(value) in (str, int, bool):
        return [type(value).__name__, value]
    if type(value) is float:
        return ["float", value.hex()]
    if type(value) is bytes:
        return ["bytes", value.hex()]
    from abides_markets.orders import Side
    if type(value) is Side:
        return ["Side", value.value]
    if isinstance(value, np.generic):
        return [type(value).__name__, graph(value.item(), np, memo, arena_memo)]
    if type(value) is datetime:
        return ["datetime", value.isoformat()]
    if type(value) is timedelta:
        return ["timedelta", value.days, value.seconds, value.microseconds]
    if id(value) in memo:
        return ["ref", memo[id(value)][0]]
    serial = len(memo)
    memo[id(value)] = (serial, value)
    if isinstance(value, np.random.RandomState):
        return ["RandomState", serial, graph(value.get_state(), np, memo, arena_memo)]
    if isinstance(value, np.ndarray):
        return ["ndarray", serial, str(value.dtype), list(value.shape), graph(value.tolist(), np, memo, arena_memo) if value.dtype.hasobject else value.tobytes().hex()]
    if type(value) in (list, tuple, deque):
        return [type(value).__name__, serial, [graph(child, np, memo, arena_memo) for child in value]]
    if type(value) is defaultdict:
        if value.default_factory is not None and value.default_factory is not list:
            raise TypeError("unadmitted defaultdict factory; never invoked")
        factory = ["NoneType", None] if value.default_factory is None else ["binding", "builtins", "list"]
        return ["defaultdict", serial, factory, [[graph(k, np, memo, arena_memo), graph(v, np, memo, arena_memo)] for k, v in value.items()]]
    if type(value) is dict:
        return ["dict", serial, [[graph(k, np, memo, arena_memo), graph(v, np, memo, arena_memo)] for k, v in value.items()]]
    if type(value) in (set, frozenset):
        members = sorted(value, key=immutable_set_key)
        return [type(value).__name__, serial, [graph(child, np, memo, arena_memo) for child in members]]
    name, module = type(value).__name__, type(value).__module__
    if name in ("NativeTrader", "NativeExchange"):
        original = value.source_identity()
        module, name = type(original).__module__, type(original).__name__
        attrs = value.snapshot_fields()
        if type(value).__name__ == "NativeTrader":
            import dynamic_arena_chain
            attrs["orders"] = dynamic_arena_chain.cold_order_dict(value,attrs["orders"],arena_memo)
    elif name in ("NativeBook", "OrderBook"):
        module, name = "original_mapping", "OrderBook"
        attrs = {n: getattr(value, n) for n in BOOK_FIELDS}
    elif name in ("NativeLevel", "PriceLevel"):
        module, name = "original_mapping", "PriceLevel"
        if type(value).__name__ == "NativeLevel":
            import dynamic_arena_chain
            attrs = dynamic_arena_chain.cold_level_fields(value,arena_memo)
        else:
            attrs = {n:getattr(value,n) for n in LEVEL_FIELDS}
    elif hasattr(value, "__dict__"):
        attrs = vars(value)
    else:
        raise TypeError("unadmitted cold graph object: " + name)
    # Attribute order is a representation detail mapped in this cold control;
    # dict payload/insertion order and all alias edges remain exact.
    # Book.owner is a business alias edge and resolves to the already-memoized
    # native/original exchange. Kernel state is represented by explicit roots.
    return [module, name, serial, [[key, graph(attrs[key], np, memo, arena_memo)] for key in sorted(attrs) if key != "kernel"]]


def snapshot(end_state, np):
    import observer
    kernel = end_state["agents"][0].kernel
    ledger = end_state["message_ledger"]
    names = ("message_id", "src_id", "dst_id", "t_send_ns", "t_recv_ns", "latency_ns", "msg_type", "order_id", "causal_parent")
    if type(ledger).__name__ == "ColumnLedger":
        ledger_rows = [tuple(column[i] for column in ledger.columns) for i in range(len(ledger))]
    else:
        ledger_rows = [tuple(row[name] for name in names) for row in ledger]
    arena_memo = {}
    queue = kernel.messages.queue
    if type(kernel.messages).__name__ == "DeliveryHeap":
        queue_rows=kernel.messages.cold_rows(arena_memo)
    else:
        queue_rows = [tuple(row) if len(row) == 4 else (row[0],) + tuple(row[1]) for row in queue]
    roots = {"agents": end_state["agents"], "oracle": kernel.oracle,
        "kernel_rng": kernel.random_state, "latency": kernel.agent_latency_model,
        "global_rng": np.random.get_state(), "ttl_messages": kernel.ttl_messages,
        "deliver_seq": kernel._deliver_seq, "deliver_seq_by_key": kernel._deliver_seq_by_key,
        "current_time": kernel.current_time, "current_causal_uid": kernel._current_causal_uid,
        "agent_current_times": kernel.agent_current_times, "agent_computation_delays": kernel.agent_computation_delays,
        "current_agent_additional_delay": kernel.current_agent_additional_delay,
        "ledger": ledger_rows, "queue": queue_rows, "observer": vars(observer.STATE),
        "summary_log": kernel.summary_log, "mean_result_by_agent_type": kernel.mean_result_by_agent_type,
        "agent_count_by_type": kernel.agent_count_by_type,
        "custom_state": {k: v for k, v in kernel.custom_state.items() if k not in ("agents", "message_ledger", "deliver_seq_by_key", "kernel_event_queue_elapsed_wallclock")}}
    from abides_core.message import Message
    from abides_markets.orders import Order
    roots["message_counter"] = Message._Message__message_id_counter
    roots["order_counter"] = Order._order_id_counter
    return graph(roots,np,arena_memo=arena_memo)
