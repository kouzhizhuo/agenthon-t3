"""Future finite actual JSON controls. Source preparation never runs this file."""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def run_arm(candidate, scenario, out, runtime, build, arm):
    command = [sys.executable, str(candidate / "control_child.py"), "--config", str(scenario),
        "--out", str(out / "trace.parquet"), "--runtime", str(runtime), "--build", str(build), "--arm", arm]
    process = subprocess.run(command, capture_output=True, text=True, check=False)
    out.mkdir(parents=True, exist_ok=True)
    (out / "stdout.log").write_text(process.stdout)
    (out / "stderr.log").write_text(process.stderr)
    if process.returncode:
        raise RuntimeError("actual JSON arm failed: " + arm + ", exit=" + str(process.returncode))
    return json.loads((out / "events.json").read_bytes())


def first_frame_difference(left, right):
    if list(left.columns) != list(right.columns):
        return {"kind": "column_order", "original": list(left.columns), "native": list(right.columns)}
    if [str(x) for x in left.dtypes] != [str(x) for x in right.dtypes]:
        return {"kind": "dtype", "original": [str(x) for x in left.dtypes], "native": [str(x) for x in right.dtypes]}
    if left.shape != right.shape:
        return {"kind": "shape", "original": list(left.shape), "native": list(right.shape)}
    for name in left.columns:
        a, b = left[name], right[name]
        mask = ~(a.eq(b) | (a.isna() & b.isna()))
        indices = mask.fillna(True).to_numpy().nonzero()[0]
        if len(indices):
            index = int(indices[0])
            return {"kind": "value", "column": name, "index": index, "original_repr": repr(a.iloc[index]), "native_repr": repr(b.iloc[index])}
    return None


def first_graph_difference(left, right, path="$"):
    """Locate the first retained JSON snapshot divergence for root repair."""
    if type(left) is not type(right):
        return {"path": path, "kind": "type", "original_repr": repr(left), "native_repr": repr(right)}
    if type(left) is dict:
        if list(left) != list(right):
            return {"path": path, "kind": "keys", "original": list(left), "native": list(right)}
        for key in left:
            difference = first_graph_difference(left[key], right[key], path + "[" + repr(key) + "]")
            if difference is not None:
                return difference
    elif type(left) is list:
        if len(left) != len(right):
            return {"path": path, "kind": "length", "original": len(left), "native": len(right)}
        for index, (a, b) in enumerate(zip(left, right)):
            difference = first_graph_difference(a, b, path + "[" + str(index) + "]")
            if difference is not None:
                return difference
    elif left != right:
        return {"path": path, "kind": "value", "original_repr": repr(left), "native_repr": repr(right)}
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    candidate = Path(__file__).resolve().parent
    if args.out.exists():
        raise ValueError("fresh actual evidence directory required")
    args.out.mkdir(parents=True)
    report = {"schema": "t3-authoritative-chain-real-json-controls-v1", "all_passed": False,
        "source_only": False, "rankable": False, "speed_claim": False, "cases": []}
    try:
        import pandas as pd
        outputs = []
        for arm, name in (("original", "original"), ("native_owner", "native1"), ("native_owner", "native2")):
            out = args.out / name
            outputs.append(run_arm(candidate, candidate / "control_scenario.json", out, args.runtime, args.build, arm))
        selections=[json.loads((args.out/name/"ARM_SELECTION.json").read_bytes()) for name in ("original","native1","native2")]
        report["cases"].append({"case":"actual_requested_arm_selected","selections":selections,"passed":all(row["passed"] for row in selections)})
        for filename in ("trace.parquet", "message_trace.parquet"):
            frames = [pd.read_parquet(args.out / name / filename) for name in ("original", "native1", "native2")]
            differences = [first_frame_difference(frames[0], frames[1]), first_frame_difference(frames[1], frames[2])]
            case = {"file": filename, "original_native_first_difference": differences[0],
                "native_repeat_first_difference": differences[1], "passed": differences == [None, None]}
            case["original_native_file_bytes_equal"] = (args.out / "original" / filename).read_bytes() == (args.out / "native1" / filename).read_bytes()
            if (args.out / "native1" / filename).read_bytes() != (args.out / "native2" / filename).read_bytes():
                case.update(passed=False, native_stable_file_bytes=False)
            else:
                case["native_stable_file_bytes"] = True
            report["cases"].append(case)
        counts = [x["n_events"] for x in outputs]
        report["cases"].append({"case": "exact_event_count", "counts": counts, "passed": len(set(counts)) == 1})
        states = [json.loads((args.out / name / "STATE.json").read_bytes()) for name in ("original", "native1", "native2")]
        graph_differences = [first_graph_difference(states[0], states[1]), first_graph_difference(states[1], states[2])]
        report["cases"].append({"case": "complete_cold_rng_counter_ledger_observer_alias_graph",
            "passed": graph_differences == [None, None], "actual_snapshots_retained": True,
            "original_native_first_difference": graph_differences[0],
            "native_repeat_first_difference": graph_differences[1]})
        report["all_passed"] = all(case["passed"] for case in report["cases"])
        if not report["all_passed"]:
            raise AssertionError("actual JSON output differs; retained original/native files and first differences")
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (args.out / "CONTROLS.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
