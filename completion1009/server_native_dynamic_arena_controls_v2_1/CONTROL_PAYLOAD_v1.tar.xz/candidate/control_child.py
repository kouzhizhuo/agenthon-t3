"""Future child control capture around actual production CLI function."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--arm", choices=("original", "native_owner"), required=True)
    args = parser.parse_args()
    import production_cli
    production_cli.activate_paths(args.runtime)
    from abides_core import abides
    import numpy as np
    from control_graph import snapshot
    original_run = abides.run
    def captured(config):
        end_state = original_run(config)
        kernel=end_state["agents"][0].kernel
        selected=type(kernel).__name__
        from abides_core.kernel import Kernel
        native=False
        if selected=="NativeOwnerKernel":
            from native_owner_kernel import NativeOwnerKernel
            native=type(kernel) is NativeOwnerKernel and "_chain_migration" in kernel.__dict__
        args.out.parent.mkdir(parents=True, exist_ok=True)
        selection={"requested_arm":args.arm,"selected_kernel":selected,"selected_kernel_module":type(kernel).__module__,"native_authority":native,"passed":native if args.arm=="native_owner" else type(kernel) is Kernel and not native}
        (args.out.parent / "ARM_SELECTION.json").write_text(json.dumps(selection,sort_keys=True,indent=2)+"\n")
        if not selection["passed"]:raise AssertionError("control arm did not select its required actual kernel: "+selected)
        if native:
            scheduler=kernel._chain_scheduler
            queue=scheduler.heap.queue
            diagnostics={"source_only":False,"control_only":True,"rankable":False,"speed_claim":False,"orders":scheduler.orders.statistics(),"messages":scheduler.messages.statistics(),"pending_deliveries":scheduler.heap.qsize(),"distinct_pending_message_handles":len({row[4] for row in queue})}
            (args.out.parent / "ARENA_DIAGNOSTICS.json").write_text(json.dumps(diagnostics,sort_keys=True,indent=2)+"\n")
        state = snapshot(end_state, np)
        (args.out.parent / "STATE.json").write_text(json.dumps(state, ensure_ascii=True, indent=2) + "\n")
        return end_state
    abides.run = captured
    try:
        result = production_cli.simulate(args.config, args.out, args.build, args.runtime, args.arm, production_cli.ENTRY_STARTED)
        print(json.dumps(result))
    finally:
        abides.run = original_run


if __name__ == "__main__":
    main()
