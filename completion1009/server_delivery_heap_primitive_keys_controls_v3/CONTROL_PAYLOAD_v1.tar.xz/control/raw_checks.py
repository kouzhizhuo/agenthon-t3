"""Server host saved-JSON checks; imports no participants or scientific modules."""
import heapq
import json
from pathlib import Path
import struct
from common import inventory, safe_name, sha


PAYLOAD = Path(__file__).resolve().parents[1]

HEAP_CASES = ("four_key_lexicographic", "all_equal_right_child", "equal_time_src_dst", "int64_edges",
    "overflow_each_key", "int_subclass_fallback", "bignum_fallback", "bool_fallback", "numpy_fallback",
    "mixed_float_fallback", "resize_2050", "numpy_int64_timestamp_edges", "mixed_timestamp_53bit",
    "mixed_timestamp_63bit", "mixed_timestamp_equal_right_child", "numpy_non_time_keys_fallback",
    "numpy_other_timestamp_fallback", "numpy_timestamp_subclass_fallback", "mixed_timestamp_overflow_fallback",
    "original_heap_physical_import", "mixed_original_heap_physical_import", "numpy_C_API_exact_scalar_authority", "explicit_ids_leave_counters")
TYPED_CASES = (["valid_checked_scalar"] + ["cold_invalid_type_range"] * 9
    + ["typed_invalid_zero_generation_index"] * 4
    + ["distinct_mutable_clone", "clone_tag_deepcopy", "typed_stale", "generation_reuse",
       "stable_chunks_growth", "message_no_order_public_None"] + ["cold_message_exception_priority"] * 3
    + ["message_order_C_handle", "message_owns_released_local", "message_final_release_stale",
       "full_live_release", "explicit_ids_no_constructor_counter"])


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_elf(path):
    data = Path(path).read_bytes()
    require(len(data) >= 64 and data[:7] == b"\x7fELF\x02\x01\x01", "actual ELF64 little-endian header required")
    require(struct.unpack_from("<HH", data, 16) == (3, 62), "actual x86_64 shared ELF required")
    return {"bytes": len(data), "sha256": sha(path), "ELF64_little_endian_x86_64_shared": True}


def check_build_raw(build, translated, receipt, translation_receipt):
    generated = receipt["generated_C"]
    require(len(generated) == len(translation_receipt["generated_C"]) == 1, "one full native module C required")
    built = Path(build) / safe_name(generated[0]["path"])
    translated_c = Path(translated) / safe_name(translation_receipt["generated_C"][0]["path"])
    require(built.read_bytes() == translated_c.read_bytes(), "all actual translated/compiled C bytes must match")
    extensions = receipt["extensions"]
    require(len(extensions) == 1 and extensions[0]["module"] == "dynamic_arena_chain", "single typed/heap native ELF required")
    native = Path(build) / safe_name(extensions[0]["path"])
    require(native.suffix == ".so" and native.stat().st_size == extensions[0]["bytes"] and sha(native) == extensions[0]["sha256"], "exact native ELF receipt required")
    objects = inventory(Path(build) / "objects")
    require(objects and any(Path(row["path"]).suffix == ".o" for row in objects), "actual retained compiler objects required")
    object_headers = []
    for row in objects:
        if Path(row["path"]).suffix == ".o":
            data = (Path(build) / "objects" / row["path"]).read_bytes()
            require(len(data) >= 64 and data[:7] == b"\x7fELF\x02\x01\x01" and struct.unpack_from("<HH", data, 16) == (1, 62), "actual x86_64 relocatable objects required")
            object_headers.append(row)
    header_a, header_b = receipt["numpy_headers"], translation_receipt["numpy_headers"]
    pins = json.loads((PAYLOAD / "candidate/NUMPY_HEADER_SOURCE_PINS_v1.json").read_bytes())
    require(header_a == json.loads((Path(build) / "NUMPY_HEADERS_RECEIPT.json").read_bytes())
        and header_b == json.loads((Path(translated) / "NUMPY_HEADERS_RECEIPT.json").read_bytes()), "complete actual saved NumPy header receipts differ")
    require(header_a["files"] == header_b["files"] and header_a["official_source_pins"] == header_b["official_source_pins"] == pins
        and header_a["numpy_version"] == header_b["numpy_version"] == "1.26.4"
        and header_a["schema"] == header_b["schema"] == "t3-heap-v3-actual-numpy-header-snapshot-v1"
        and header_a["snapshot_include"] == header_b["snapshot_include"] == "numpy_headers"
        and header_a["scientific_market_executed"] is header_b["scientific_market_executed"] is False,
        "actual translated/compiled NumPy headers differ from frozen official source pins")
    require(header_a["installed_include"] == header_b["installed_include"]
        and Path(header_a["installed_include"]).is_absolute()
        and receipt["actual_compiler_include_dirs"] == ["/opt/delivery-heap-primitive-v3/candidate", "/output/build/numpy_headers"],
        "actual compiler must use frozen candidate and saved exact NumPy header snapshot")
    require(inventory(Path(build) / "numpy_headers") == header_a["files"]
        and inventory(Path(translated) / "numpy_headers") == header_b["files"], "complete actual compiler NumPy header snapshot required")
    for row in header_a["official_source_pins"]["files"]:
        require((Path(build) / "numpy_headers" / row["path"]).stat().st_size == row["bytes"]
            and sha(Path(build) / "numpy_headers" / row["path"]) == row["sha256"], "actual NumPy C header differs from pinned upstream")
    return {"translation_build_C_fullbytes_equal": True, "native_ELF": read_elf(native), "actual_objects": object_headers,
        "full_actual_NumPy_header_snapshot_equal": True, "official_NumPy1264_header_source_exact": True, "actual_compiler_saved_header_include_dirs_exact": True}


def key(kind, value):
    return {"type": kind, "hex" if kind == "float" else "value": float(value).hex() if kind == "float" else str(float(value)) if kind == "float64" else str(value)}


def keys(values, kinds=None):
    return [key("int" if kinds is None else kinds[i], value) for i, value in enumerate(values)]


def prepared_patterns():
    patterns = [
        [keys(v) for v in [(7, 2, 1, 9), (7, 1, 9, 3), (7, 1, 8, 4), (6, 9, 9, 5), (7, 1, 8, 2)]],
        [keys((4, 2, 3, 8)) for _ in range(31)],
        [keys((9, 1, 1, i % 4)) for i in range(33)],
        [keys(tuple(edge if j == field else 0 for j in range(4))) for field in range(4) for edge in (-(1 << 63), (1 << 63) - 1, -1)],
        [keys(tuple(edge if j == field else 0 for j in range(4))) for field in range(4) for edge in (-(1 << 63) - 1, 1 << 63)],
        [keys(tuple(j + 2 if j == field else 0 for j in range(4)), tuple("_HeapControlInt" if j == field else "int" for j in range(4))) for field in range(4)],
        [keys(((1 << 63) + i, 0, 0, i + 1)) for i in (3, 1, 4, 0, 2)] + [keys((-(1 << 80), 0, 0, 99))],
        [keys((True, False, 0, 1), ("bool", "bool", "int", "int")), keys((1, 0, 0, 2)), keys((False, 1, 1, 3), ("bool", "int", "int", "int")), keys((0, True, 1, 4), ("int", "bool", "int", "int"))],
        [keys((3, 0, 0, 1), ("int64", "int", "int", "int")), keys((-4, 0, 0, 2), ("int64", "int", "int", "int")), keys((3, 0, 0, 3), ("int", "int32", "int", "int"))],
        [keys((3.0, 0, 0, 1), ("float", "int", "int", "int")), keys((2, 0, 0, 2)), keys((-0.0, 0, 0, 3), ("float", "int", "int", "int")), keys((0.0, 0, 0, 4), ("float", "int", "int", "int"))],
        [keys((i % 9, (i // 9) % 7, (i // 63) % 5, i % 11)) for i in range(2050)],
        [keys((edge, 0, 0, i), ("int64", "int", "int", "int")) for i, edge in enumerate((-(1 << 63), (1 << 63) - 1, -1, 0, 1))],
        [keys((value, 0, 0, i), ("int64" if i % 2 else "int", "int", "int", "int")) for i, value in enumerate((-(1 << 53) - 1, -(1 << 53), -(1 << 53) + 1, (1 << 53) - 1, 1 << 53, (1 << 53) + 1, (1 << 53) + 2))],
        [keys((value, 0, 0, i), ("int64" if i % 2 else "int", "int", "int", "int")) for i, value in enumerate((-(1 << 63), -(1 << 63) + 1, -1, 0, 1, (1 << 63) - 2, (1 << 63) - 1))],
        [keys((1 << 53, 2, 3, 8), ("int64" if i % 2 else "int", "int", "int", "int")) for i in range(31)],
        [keys(tuple(3 if field == j else 0 for j in range(4)), tuple("int64" if field == j else "int" for j in range(4))) for field in (1, 2, 3)],
        [keys((-3, 0, 0, 1), ("int32", "int", "int", "int")), keys((4, 0, 0, 2), ("uint64", "int", "int", "int")), keys((5.0, 0, 0, 3), ("float64", "int", "int", "int"))],
        [keys((-2, 0, 0, 1), ("_HeapControlNPInt64", "int", "int", "int")), keys((3, 0, 0, 2), ("int64", "int", "int", "int")), keys((-1, 0, 0, 3))],
        [keys(((1 << 63) - 1, 0, 0, 1), ("int64", "int", "int", "int")), keys((1 << 63, 0, 0, 2)), keys((-(1 << 63) - 1, 0, 0, 3)), keys((-(1 << 63), 0, 0, 4), ("int64", "int", "int", "int"))],
    ]
    return dict(zip(HEAP_CASES[:19], patterns))


def decode_key(value):
    require(type(value) is dict and value.get("type") in ("int", "bool", "int64", "int32", "uint64", "float64", "_HeapControlInt", "_HeapControlNPInt64", "float"), "source-prepared primitive key type required")
    kind = value["type"]
    if kind == "float":
        require(set(value) == {"type", "hex"} and type(value["hex"]) is str, "exact float hex key required")
        number = float.fromhex(value["hex"])
        require(number.hex() == value["hex"], "canonical finite prepared float required")
        return number
    require(set(value) == {"type", "value"} and type(value["value"]) is str, "exact scalar value key required")
    if kind == "bool":
        require(value["value"] in ("True", "False"), "exact bool witness required")
        return value["value"] == "True"
    if kind == "float64":
        number = float(value["value"])
        require(str(number) == value["value"], "canonical prepared NumPy float string required")
        return number
    number = int(value["value"])
    require(str(number) == value["value"], "canonical prepared integer required")
    return number


class SavedRow:
    def __init__(self, encoded):
        require(type(encoded) is list and len(encoded) == 5 and type(encoded[4]) is int and encoded[4] > 0, "saved four keys plus positive handle required")
        self.encoded = encoded
        self.values = tuple(decode_key(value) for value in encoded[:4])

    def __lt__(self, other):
        # The fourth item represents Message.__lt__'s message_id, without adding
        # the retained ownership handle to the original four-key ordering.
        return self.values < other.values


def valid_primitive(row):
    return valid_primitive_keys(row.encoded[:4])


def valid_primitive_keys(row):
    return (row[0]["type"] in ("int", "int64") and -(1 << 63) <= int(row[0]["value"]) <= (1 << 63) - 1
        and all(v["type"] == "int" and -(1 << 63) <= int(v["value"]) <= (1 << 63) - 1 for v in row[1:4]))


def check_controls_raw(actual):
    typed, heap = actual["typed"], actual["heap"]
    require(actual.get("schema") == "t3-typed-and-heap-primitive-finite-v3" and actual.get("all_passed") is True
        and actual.get("rankable") is False and actual.get("speed_claim") is False and actual.get("market_executed") is False, "exact full raw finite report required")
    require(typed.get("schema") == "t3-typed-order-handle-finite-controls-v1" and typed.get("control_only") is True and typed.get("source_only") is False
        and typed.get("all_passed") is True and typed.get("rankable") is False and typed.get("speed_claim") is False
        and [row.get("case") for row in typed.get("cases", [])] == TYPED_CASES and all(row.get("passed") is True for row in typed["cases"]), "all28 exact raw typed controls required")
    require([r.get("input_repr") for r in typed["cases"][1:10]] == ["None", "True", "False", "0", "1", "-1", "18446744073709551616", "1.0", "'1'"]
        and [r.get("input_repr") for r in typed["cases"][10:14]] == ["0", "1", "4294968320", "8589934591"]
        and [r.get("kind") for r in typed["cases"][20:23]] == [0, 14, 7], "full typed invalid-input and priority witnesses required")
    require(heap.get("schema") == "t3-delivery-heap-primitive-keys-finite-v3" and heap.get("all_passed") is True
        and heap.get("rankable") is False and heap.get("speed_claim") is False
        and tuple(row.get("case") for row in heap.get("cases", [])) == HEAP_CASES and all(row.get("passed") is True for row in heap["cases"]), "all23 exact raw heap controls required")
    patterns = prepared_patterns()
    summaries = []
    for case in heap["cases"][:19]:
        expected_keys = patterns[case["case"]]
        count = len(expected_keys)
        require(case["inserted"] == count and len(case["push_physical_witness"]) == len(case["cache_witness"]) == len(case["pop_witness"]) == count, "complete push/cache/pop roster required")
        reference, handles = [], set()
        unsupported_mixed = case["case"] == "mixed_timestamp_overflow_fallback"
        if count < 40:
            require(case["original_push_physical_witness"] == case["push_physical_witness"]
                and case["original_pop_witness"] == case["pop_witness"], "saved complete original/native small physical witnesses differ")
        for i, expected in enumerate(expected_keys):
            if count < 40:
                witness = case["push_physical_witness"][i]
                require(type(witness) is list and len(witness) == i + 1, "full small push physical witness required")
                candidates = [row for row in witness if row[4] not in handles]
                require(len(candidates) == 1 and candidates[0][:4] == expected, "exact source-prepared inserted key sequence required")
                current = SavedRow(candidates[0])
                handles.add(current.encoded[4])
                if not unsupported_mixed:
                    heapq.heappush(reference, current)
                    require(witness == [row.encoded for row in reference], "full original heapq push physical replay differs")
            else:
                require(case["push_physical_witness"][i] == {"rows": i + 1, "live_full_rows_compared": True}, "large live-check count witness required")
            expected_valid = sum(valid_primitive_keys(row) for row in expected_keys[:i + 1])
            require(case["cache_witness"][i] == {"rows": i + 1, "valid_primitive_rows": expected_valid}, "exact immutable signed64 cache census required")
        if count >= 40:
            saved = [SavedRow(row["popped"]) for row in case["pop_witness"]]
            require(len({row.encoded[4] for row in saved}) == count, "distinct large saved message handles required")
            by_keys = {}
            for row in saved:
                encoded = tuple((k["type"], k.get("value"), k.get("hex")) for k in row.encoded[:4])
                by_keys.setdefault(encoded, []).append(row)
            for expected in expected_keys:
                encoded = tuple((k["type"], k.get("value"), k.get("hex")) for k in expected)
                require(encoded in by_keys and by_keys[encoded], "large saved popped key multiset differs")
                heapq.heappush(reference, by_keys[encoded].pop())
            require(not any(by_keys.values()), "large extra saved popped rows refused")
        for i, witness in enumerate(case["pop_witness"]):
            if unsupported_mixed:
                require(witness == case["original_pop_witness"][i]
                    and len(witness["remaining_physical_rows"]) == count - i - 1, "full saved original unsupported-mixed physical result differs")
                continue
            popped = heapq.heappop(reference)
            if count < 40:
                require(witness["popped"] == popped.encoded and witness["remaining_physical_rows"] == [row.encoded for row in reference], "full original heapq pop physical replay differs")
            else:
                require(SavedRow(witness["popped"]).values == popped.values and witness["remaining_physical_rows"] == {"rows": count - i - 1, "live_full_rows_compared": True}, "large saved pop numeric ordering/count differs")
        require(not reference, "full saved heap drains required")
        summaries.append({"case": case["case"], "inserted": count, "source_prepared_key_sequence_or_multiset_exact": True,
            "full_small_physical_replay": count < 40 and not unsupported_mixed,
            "full_saved_original_unsupported_mixed_physical_equality": unsupported_mixed,
            "large_pop_numeric_order_and_counts": count >= 40})
    imported = heap["cases"][19]
    require(len(imported["initial"]) == len(imported["pop_witness"]) == 25, "full25 original physical import witnesses required")
    reference = [SavedRow(row) for row in imported["initial"]]
    require(len({r.encoded[4] for r in reference}) == 25, "distinct retained imported message handles required")
    expected_imported = sorted((i % 4, i % 3, i % 2, i % 5) for i in range(25))
    require(sorted(r.values for r in reference) == expected_imported, "original25 source-prepared import key multiset differs")
    for i, row in enumerate(reference):
        if i:
            require(not row < reference[(i - 1) // 2], "original imported physical heap property required")
    for witness in imported["pop_witness"]:
        popped = heapq.heappop(reference)
        require(witness["popped"] == popped.encoded and witness["remaining_physical_rows"] == [row.encoded for row in reference], "full imported original heapq pop physical replay differs")
    imported = heap["cases"][20]
    require(len(imported["initial"]) == len(imported["pop_witness"]) == 25
        and imported["initial_cache"] == {"rows": 25, "valid_primitive_rows": 25}, "full25 mixed original physical import required")
    reference = [SavedRow(row) for row in imported["initial"]]
    times = (-(1 << 63), -(1 << 53) - 1, -1, 0, (1 << 53) + 1, (1 << 63) - 1)
    expected_keys = [keys((times[i % 6], i % 3, i % 2, i % 5), ("int64" if i % 2 else "int", "int", "int", "int")) for i in range(25)]
    require(sorted(str(row.encoded[:4]) for row in reference) == sorted(str(row) for row in expected_keys)
        and len({row.encoded[4] for row in reference}) == 25, "mixed original full source keys/types/handles differ")
    for i, row in enumerate(reference):
        if i:
            require(not row < reference[(i - 1) // 2], "mixed imported physical heap property required")
    for witness in imported["pop_witness"]:
        popped = heapq.heappop(reference)
        require(witness["popped"] == popped.encoded and witness["remaining_physical_rows"] == [row.encoded for row in reference], "full mixed imported heapq physical replay differs")
    authority = heap["cases"][21]
    require(authority["numpy_version"] == "1.26.4" and authority["long_bits"] == 64
        and authority["C_API_type_is_np_int64"] is True, "actual exact NumPy C API scalar authority required")
    return {"all28_typed_cases_and_inputs": True, "all23_heap_cases": True, "patterns": summaries,
        "full25_imported_saved_physical_pop_replay": True, "handles_never_added_to_ordering": True,
        "full25_mixed_imported_saved_physical_pop_replay": True, "actual_numpy_C_API_authority_saved": True,
        "saved_large_limits": "2050 live physical rows are self-reported checks; saved replay checks key multiset, popped numeric order and counts only.",
        "saved_identity_limits": "Original key object identity is checked by native live controls; JSON cannot independently recover Python object identity."}
