"""Stdlib source-only frozen staging and independent candidate/wrapper seal."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import (BASE, CANDIDATE_RECEIPT, CANDIDATE_SHA256, CANDIDATE_FILE_COUNT,
    CANDIDATE_REVIEW_SHA256, WRAPPER_FILE_COUNT, MAX_BYTES, MAX_FILES,
    inventory, require_review, safe_name, sha, verify_payload, verify_rows, write)

HERE = Path(__file__).resolve().parent
COMPLETION = HERE.parent
CANDIDATE = COMPLETION / "candidates/delivery_heap_primitive_keys_controls_v3"
RUNTIME = COMPLETION / "candidates/lean_production_native_projection_v1/runtime"


def copy(source, target):
    if source.is_symlink() or not source.is_file():
        raise ValueError("ordinary reviewed source required")
    data = source.read_bytes()
    if source.suffix == ".py":
        ast.parse(data)
        compile(data, str(source), "exec", dont_inherit=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    target.chmod(0o644)
    if sha(source) != sha(target):
        raise ValueError("exact source copy differs")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--candidate-review", type=Path, required=True)
    parser.add_argument("--candidate-review-sha256", required=True)
    parser.add_argument("--wrapper-review", type=Path)
    parser.add_argument("--wrapper-review-sha256")
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink() or args.archive is not None and args.archive.exists():
        raise ValueError("fresh source staging/archive outputs required")
    candidate_receipt = CANDIDATE / CANDIDATE_RECEIPT
    candidate = json.loads(candidate_receipt.read_bytes())
    if (sha(candidate_receipt) != CANDIDATE_SHA256 or len(candidate["files"]) != CANDIDATE_FILE_COUNT
            or candidate.get("frozen_build_input") is not True or candidate.get("unfrozen") is not False):
        raise ValueError("exact frozen17 heap source receipt required")
    verify_rows(CANDIDATE, candidate["files"])
    if sha(args.candidate_review) != args.candidate_review_sha256 or args.candidate_review_sha256 != CANDIDATE_REVIEW_SHA256:
        raise ValueError("exact independent frozen candidate source review required")
    require_review(args.candidate_review, CANDIDATE_SHA256, candidate["files"])
    runtime = json.loads((CANDIDATE / "RUNTIME_PINS.json").read_bytes())
    if len(runtime["files"]) != 64 or inventory(RUNTIME) != sorted(runtime["files"], key=lambda row: row["path"]):
        raise ValueError("complete original64 runtime source required")
    verify_rows(RUNTIME, runtime["files"])
    wrapper_receipt = HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"
    wrapper = json.loads(wrapper_receipt.read_bytes())
    if wrapper.get("source_frozen") is not True or len(wrapper["files"]) != WRAPPER_FILE_COUNT:
        raise ValueError("frozen complete11 wrapper source required")
    verify_rows(HERE, wrapper["files"])
    if args.archive is not None:
        if args.wrapper_review is None or args.wrapper_review_sha256 is None or sha(args.wrapper_review) != args.wrapper_review_sha256:
            raise ValueError("independent exact wrapper review required before seal")
        require_review(args.wrapper_review, sha(wrapper_receipt), wrapper["files"])
    args.out.mkdir(parents=True)
    for row in candidate["files"]:
        copy(CANDIDATE / safe_name(row["path"]), args.out / "candidate" / row["path"])
    copy(candidate_receipt, args.out / "candidate" / CANDIDATE_RECEIPT)
    for row in runtime["files"]:
        copy(RUNTIME / safe_name(row["path"]), args.out / "runtime" / row["path"])
    for row in wrapper["files"]:
        copy(HERE / safe_name(row["path"]), args.out / "control" / row["path"])
        copy(HERE / safe_name(row["path"]), args.out / "wrapper_source" / row["path"])
    copy(args.candidate_review, args.out / "source_review/INDEPENDENT_CANDIDATE_SOURCE_REVIEW.json")
    copy(wrapper_receipt, args.out / "source_review/WRAPPER_SOURCE_PREPARATION_RECEIPT_v1.json")
    if args.archive is not None:
        copy(args.wrapper_review, args.out / "source_review/INDEPENDENT_WRAPPER_SOURCE_REVIEW.json")
    plan = {"schema": "t3-delivery-heap-primitive-v3-source-controls-plan-v1",
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "candidate_sources": candidate["files"],
        "candidate_review_sha256": CANDIDATE_REVIEW_SHA256,
        "wrapper_source_receipt_sha256": sha(wrapper_receipt),
        "wrapper_review_sha256": None if args.archive is None else sha(args.wrapper_review),
        "control_sources": inventory(args.out / "control"), "base": BASE,
        "frozen_source_inputs": True, "prototype_only": args.archive is None,
        "native_builds": 1, "Cython_translation_only_preflights": 1,
        "translation_required_before_build": True, "translation_build_C_fullbytes_equal_required": True,
        "typed_handle_control_invocations": 1, "typed_handle_control_cases": 28,
        "heap_control_invocations": 1, "heap_control_cases": 23, "typed_controls_before_heap": True,
        "market_episodes": 0, "timing_runs": 0, "official_verifier_calls": 0,
        "runtime_containers": 2, "raw_controls_replay_required": True,
        "actual_execution": False, "rankable": False, "speed_claim": False,
        "official_submission": False, "full71": False,
        "material_limits": ["Finite native heap and typed primitives only; no complete market semantics, throughput,230000 or ranking conclusion.",
            "2050 growth physical comparisons are live native assertions; saved host replay independently checks key multiset, numeric pop order and counts only.",
            "JSON saved output cannot independently prove Python object identity; small physical heap rows and ownership handles are replayed exactly."]}
    write(args.out / "CONTROL_PLAN.json", plan)
    pins = inventory(args.out)
    if len(pins) + 1 > MAX_FILES or sum(row["bytes"] for row in pins) > MAX_BYTES:
        raise ValueError("bounded frozen source payload exceeded")
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-delivery-heap-source-controls-manifest-v1", "files": pins})
    if args.archive is not None:
        verify_payload(args.out)
        with tarfile.open(args.archive, "w:xz", format=tarfile.PAX_FORMAT) as archive:
            for row in inventory(args.out):
                data = (args.out / row["path"]).read_bytes()
                member = tarfile.TarInfo(row["path"])
                member.size, member.mode, member.mtime = len(data), 0o644, 0
                member.uid = member.gid = 0
                archive.addfile(member, io.BytesIO(data))
    print(json.dumps({"source_only": True, "prototype_only": args.archive is None,
        "actual_execution": False, "archive_sha256": None if args.archive is None else sha(args.archive)}))


if __name__ == "__main__":
    main()
