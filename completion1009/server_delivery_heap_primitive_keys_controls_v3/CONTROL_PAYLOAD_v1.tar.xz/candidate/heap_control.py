"""Future exact Linux typed/heap controls; no local participant execution."""
import argparse,json,sys
from pathlib import Path
EXPECTED=("four_key_lexicographic","all_equal_right_child","equal_time_src_dst","int64_edges","overflow_each_key","int_subclass_fallback","bignum_fallback","bool_fallback","numpy_fallback","mixed_float_fallback","resize_2050","numpy_int64_timestamp_edges","mixed_timestamp_53bit","mixed_timestamp_63bit","mixed_timestamp_equal_right_child","numpy_non_time_keys_fallback","numpy_other_timestamp_fallback","numpy_timestamp_subclass_fallback","mixed_timestamp_overflow_fallback","original_heap_physical_import","mixed_original_heap_physical_import","numpy_C_API_exact_scalar_authority","explicit_ids_leave_counters")
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--runtime",type=Path,required=True)
    parser.add_argument("--build",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    if args.out.exists():raise ValueError("fresh finite raw evidence required")
    sys.path.insert(0,str(args.runtime.resolve()))
    from bootstrap import activate
    activate()
    from native_loader import load
    native=load(args.build,args.runtime)["dynamic_arena_chain"]
    typed=native.control_typed_handle_checks()
    if typed.get("all_passed") is not True or len(typed.get("cases",[]))!=28:
        raise AssertionError("all28 actual typed prerequisites required")
    heap=native.control_primitive_heap_keys()
    report={"schema":"t3-typed-and-heap-primitive-finite-v3","typed":typed,"heap":heap,"all_passed":False,"rankable":False,"speed_claim":False,"market_executed":False}
    report["all_passed"]=(heap.get("all_passed") is True and heap.get("schema")=="t3-delivery-heap-primitive-keys-finite-v3" and tuple(row.get("case") for row in heap.get("cases",[]))==EXPECTED and all(row.get("passed") is True for row in heap["cases"]))
    args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
    if not report["all_passed"]:raise AssertionError("actual heap controls incomplete")
if __name__=="__main__":main()
