#ifndef T3_HEAP_NUMPY_INT64_H
#define T3_HEAP_NUMPY_INT64_H

#include <Python.h>
#include <stdint.h>
#include <limits.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <numpy/arrayscalars.h>

/* This candidate's mixed comparison proof is specifically NumPy1.26.4 LP64.
 * Never substitute a serialized layout or a Python int() conversion. */
#if NPY_SIZEOF_LONG != 8 || NPY_SIZEOF_INTP != 8
#error "T3 exact signed timestamp cache requires the pinned LP64 NumPy ABI"
#endif
typedef char t3_heap_int64_size_check[(sizeof(npy_int64) == 8 && sizeof(int64_t) == 8 && sizeof(long) == 8) ? 1 : -1];

static int t3_heap_numpy_import(void) {
    return _import_array();
}

static PyObject *t3_heap_numpy_int64_type(void) {
    return (PyObject *)&PyInt64ArrType_Type;
}

static int t3_heap_numpy_exact_int64(PyObject *value) {
    return Py_TYPE(value) == &PyInt64ArrType_Type;
}

static int64_t t3_heap_numpy_read_int64(PyObject *value) {
    return (int64_t)PyArrayScalar_VAL(value, Int64);
}

static unsigned int t3_heap_numpy_long_bits(void) {
    return (unsigned int)(sizeof(long) * CHAR_BIT);
}

#endif
