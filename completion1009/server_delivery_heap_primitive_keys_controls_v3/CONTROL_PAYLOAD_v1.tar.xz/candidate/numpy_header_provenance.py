"""Future Linux actual NumPy C-header snapshot; no local scientific imports."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent


def snapshot_numpy_headers(output):
    import numpy as np
    if np.__version__ != "1.26.4":
        raise ValueError("pinned NumPy1.26.4 C headers required")
    source = Path(np.get_include()).resolve()
    target = Path(output) / "numpy_headers"
    if target.exists():
        raise ValueError("fresh actual NumPy header snapshot required")
    pins = json.loads((HERE / "NUMPY_HEADER_SOURCE_PINS_v1.json").read_bytes())
    for row in pins["files"]:
        path = source / row["path"]
        data = path.read_bytes()
        if path.is_symlink() or len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            raise ValueError("actual installed NumPy header differs from pinned official source")
    rows = []
    for path in sorted(source.rglob("*")):
        if path.is_symlink():
            raise ValueError("actual NumPy C header tree contains symlink")
        if path.is_file():
            relative = path.relative_to(source)
            if any(part in ("..", "__pycache__", "__MACOSX") or part.startswith("._") for part in relative.parts):
                raise ValueError("ordinary actual NumPy C header tree required")
            dest = target / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, dest)
            data = dest.read_bytes()
            if data != path.read_bytes():
                raise ValueError("exact actual NumPy C header snapshot differs")
            rows.append({"path": relative.as_posix(), "bytes": len(data),
                         "sha256": hashlib.sha256(data).hexdigest()})
    receipt = {"schema": "t3-heap-v3-actual-numpy-header-snapshot-v1", "numpy_version": np.__version__,
        "installed_include": str(source), "snapshot_include": "numpy_headers", "files": rows,
        "official_source_pins": pins, "scientific_market_executed": False}
    (Path(output) / "NUMPY_HEADERS_RECEIPT.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    return target, receipt
