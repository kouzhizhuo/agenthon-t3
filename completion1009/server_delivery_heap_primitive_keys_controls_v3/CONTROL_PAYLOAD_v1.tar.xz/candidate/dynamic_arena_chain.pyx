# cython: language_level=3, annotation_typing=False, infer_types=False
"""Typed-slot authoritative trader; original numeric/object semantics retained.

Generated from pinned original AST, no participant body is invoked on an
incompatible extension instance. Original initialization must complete first.
"""
import logging
import sys
import warnings
from copy import deepcopy
import numpy as np
import pandas as pd
import observer as _observer
from abides_core.agent import logger as agent_logger
from abides_core.utils import fmt_ts
from abides_core.message import MessageBatch
from abides_markets.agents.trading_agent import TradingAgent, logger as trading_logger
from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
from abides_markets.messages.market import MarketClosePriceRequestMsg, MarketClosePriceMsg, MarketClosedMsg, MarketHoursRequestMsg, MarketHoursMsg
from abides_markets.messages.marketdata import MarketDataMsg, L2DataMsg
from abides_markets.messages.order import LimitOrderMsg, MarketOrderMsg, PartialCancelOrderMsg, CancelOrderMsg, ModifyOrderMsg, ReplaceOrderMsg
from abides_markets.messages.orderbook import OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg, OrderPartialCancelledMsg, OrderModifiedMsg, OrderReplacedMsg
from abides_markets.messages.query import QueryLastTradeMsg, QueryLastTradeResponseMsg, QuerySpreadMsg, QuerySpreadResponseMsg, QueryOrderStreamMsg, QueryOrderStreamResponseMsg, QueryTransactedVolMsg, QueryTransactedVolResponseMsg
from abides_markets.orders import LimitOrder, MarketOrder, Order, Side
from abides_markets.utils import dollarize

DEFAULT_CANCEL_TAG, DEFAULT_CANCEL_METADATA = TradingAgent.cancel_order.__defaults__
DEFAULT_PARTIAL_CANCEL_TAG, DEFAULT_PARTIAL_CANCEL_METADATA = TradingAgent.partial_cancel_order.__defaults__
_MISSING = object()
FIELDS = ('MKT_BUY', 'MKT_SELL', '_mid_history', 'basket_size', 'book', 'current_time', 'daily_close_price', 'depth_levels', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'lookback', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'order_size_std', 'orders', 'price_offset_ticks', 'random_state', 'reference_price', 'sigma_n', 'size_per_level', 'spread_ticks', 'starting_cash', 'state', 'stream_history', 'symbol', 'threshold_ticks', 'transacted_volume', 'type')
REQUIRED_FIELDS = {'NoiseTrader': ('MKT_BUY', 'MKT_SELL', 'basket_size', 'current_time', 'daily_close_price', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'order_size_std', 'orders', 'price_offset_ticks', 'random_state', 'reference_price', 'starting_cash', 'state', 'stream_history', 'symbol', 'transacted_volume', 'type'), 'MarketMaker': ('MKT_BUY', 'MKT_SELL', 'basket_size', 'current_time', 'daily_close_price', 'depth_levels', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'orders', 'random_state', 'reference_price', 'size_per_level', 'spread_ticks', 'starting_cash', 'state', 'stream_history', 'symbol', 'transacted_volume', 'type'), 'ValueTrader': ('MKT_BUY', 'MKT_SELL', 'basket_size', 'current_time', 'daily_close_price', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'orders', 'random_state', 'sigma_n', 'starting_cash', 'state', 'stream_history', 'symbol', 'threshold_ticks', 'transacted_volume', 'type'), 'MomentumTrader': ('MKT_BUY', 'MKT_SELL', '_mid_history', 'basket_size', 'current_time', 'daily_close_price', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'lookback', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'orders', 'random_state', 'starting_cash', 'state', 'stream_history', 'symbol', 'threshold_ticks', 'transacted_volume', 'type')}
ORIGINAL_CLASSES = {"NoiseTrader": NoiseTrader, "MarketMaker": MarketMaker,
                    "ValueTrader": ValueTrader, "MomentumTrader": MomentumTrader}


def exact_original_class(value):
    for name, klass in ORIGINAL_CLASSES.items():
        if type(value) is klass:
            return name
    raise ValueError("typed trader requires exact declared original strategy")


import heapq
from datetime import datetime
from abides_core.kernel import Kernel as IncumbentKernel, logger as kernel_logger
from abides_core.message import WakeupMsg
from abides_core.utils import str_to_ns, ns_date
from abides_markets.order_book import logger as book_logger
from abides_markets.agents.exchange_agent import ExchangeAgent, logger as exchange_logger
from abides_markets.messages.marketdata import BookImbalanceDataMsg, L1SubReqMsg, L2SubReqMsg, L3SubReqMsg, TransactedVolSubReqMsg, MarketDataSubReqMsg, L1DataMsg, L2DataMsg, L3DataMsg, TransactedVolDataMsg, BookImbalanceSubReqMsg, MarketDataEventMsg
from abides_markets.messages.order import OrderMsg
from abides_markets.messages.query import QueryMsg
from abides_markets.price_level import PriceLevel
import sys
def _positive_row(row):
    return row[1] > 0


from libc.stdlib cimport calloc, realloc, free
from libc.stdint cimport uint32_t, uint64_t, int64_t, UINT32_MAX
from cpython.ref cimport PyObject, Py_INCREF, Py_DECREF
from cpython.long cimport PyLong_CheckExact
cdef extern from "Python.h":
    long long PyLong_AsLongLongAndOverflow(object value, int *overflow) except? -1
cdef extern from "heap_numpy_int64.h":
    int t3_heap_numpy_import() except -1
    PyObject *t3_heap_numpy_int64_type()
    bint t3_heap_numpy_exact_int64(PyObject *value)
    int64_t t3_heap_numpy_read_int64(PyObject *value)
    unsigned int t3_heap_numpy_long_bits()

# One cold C-API initialization and exact scalar identity check. No constructor,
# __int__, layout guess, or timestamp arithmetic participates in the cache.
t3_heap_numpy_import()
if (np.__version__ != "1.26.4" or t3_heap_numpy_long_bits() != 64
        or np.int64 is not <object>t3_heap_numpy_int64_type()):
    raise ValueError("pinned NumPy1.26.4 LP64 exact int64 scalar C API required")
from abides_core.message import Message

ORDER_FIELD_NAMES = ('agent_id', 'time_placed', 'symbol', 'quantity', 'side', 'order_id', 'fill_price', 'tag', 'limit_price', 'is_hidden', 'is_price_to_comply', 'insert_by_id', 'is_post_only')
MESSAGE_KIND_NAMES = ('WakeupMsg', 'MarketClosePriceRequestMsg', 'MarketHoursRequestMsg', 'MarketHoursMsg', 'QuerySpreadMsg', 'QuerySpreadResponseMsg', 'LimitOrderMsg', 'OrderAcceptedMsg', 'OrderExecutedMsg', 'CancelOrderMsg', 'OrderCancelledMsg', 'MarketClosePriceMsg', 'MarketClosedMsg')

cdef class OrderArena:
    def __cinit__(self):
        self._chunks = NULL
        self._chunks_n = 0
        self._directory_n = 0
        self._slots_n = 0
        self._free_head = UINT32_MAX
        self._live_n = 0
        self._clones_n = 0

    def __dealloc__(self):
        cdef size_t c, i, f
        cdef OrderSlot *s
        if self._chunks != NULL:
            for c in range(self._chunks_n):
                for i in range(1024):
                    s = &self._chunks[c][i]
                    for f in range(13):
                        if s.fields[f] != NULL:
                            Py_DECREF(<object>s.fields[f])
                free(self._chunks[c])
            free(self._chunks)

    cdef OrderSlot *_index(self, uint32_t i) noexcept:
        return &self._chunks[i // 1024][i % 1024]

    cdef void _grow(self) except *:
        cdef OrderSlot *block
        cdef OrderSlot **directory
        cdef size_t capacity
        cdef uint32_t i
        if self._slots_n > UINT32_MAX - 1024:
            raise OverflowError("dynamic order addressing exhausted")
        block = <OrderSlot *>calloc(1024, sizeof(OrderSlot))
        if block == NULL:
            raise MemoryError("dynamic order chunk allocation failed")
        if self._chunks_n == self._directory_n:
            capacity = 4 if self._directory_n == 0 else self._directory_n * 2
            directory = <OrderSlot **>realloc(self._chunks, capacity * sizeof(OrderSlot *))
            if directory == NULL:
                free(block)
                raise MemoryError("dynamic order directory allocation failed")
            self._chunks = directory
            self._directory_n = capacity
        for i in range(1024):
            block[i].generation = 1
            block[i].next_free = self._slots_n+i+1 if i < 1023 else self._free_head
        self._chunks[self._chunks_n] = block
        self._chunks_n += 1
        self._free_head = self._slots_n
        self._slots_n += 1024

    cdef OrderSlot *_lookup(self, object handle) except NULL:
        cdef uint64_t h
        cdef uint32_t index, generation
        cdef OrderSlot *s
        if type(handle) is not int or handle <= 0 or handle > 18446744073709551615:
            raise ValueError("invalid native order handle")
        h = handle
        index, generation = <uint32_t>h, <uint32_t>(h >> 32)
        if index >= self._slots_n or generation == 0:
            raise ValueError("invalid native order handle")
        s = self._index(index)
        if s.references == 0 or s.generation != generation:
            raise ValueError("stale native order handle")
        return s

    cdef uint64_t _checked_handle(self, object handle) except? 0:
        # Cold object admission preserves V1 exact type/range/stale exceptions.
        self._lookup(handle)
        return handle

    cdef OrderSlot *_lookup_u(self, uint64_t handle) except NULL:
        cdef uint32_t index=<uint32_t>handle
        cdef uint32_t generation=<uint32_t>(handle>>32)
        cdef OrderSlot *slot
        if handle==0 or index>=self._slots_n or generation==0:
            raise ValueError("invalid native order handle")
        slot=self._index(index)
        if slot.references==0 or slot.generation!=generation:
            raise ValueError("stale native order handle")
        return slot

    cdef uint64_t _allocate_u(self) except? 0:
        cdef uint32_t index
        cdef OrderSlot *s
        if self._free_head == UINT32_MAX:
            self._grow()
        index = self._free_head
        s = self._index(index)
        self._free_head = s.next_free
        s.references = 1
        self._live_n += 1
        return (<uint64_t>s.generation << 32) | index

    cdef object _get_u(self, uint64_t handle, unsigned int field):
        cdef OrderSlot *s = self._lookup_u(handle)
        if field >= 13 or s.fields[field] == NULL:
            raise ValueError("invalid native order field")
        return <object>s.fields[field]

    cdef void _set_u(self, uint64_t handle, unsigned int field, object value) except *:
        cdef OrderSlot *s = self._lookup_u(handle)
        if field >= 13:
            raise ValueError("invalid native order field")
        Py_INCREF(value)
        if s.fields[field] != NULL:
            Py_DECREF(<object>s.fields[field])
        s.fields[field] = <PyObject *>value

    cdef void _retain_u(self, uint64_t handle) except *:
        cdef OrderSlot *s = self._lookup_u(handle)
        if s.references == UINT32_MAX:
            raise OverflowError("native order references exhausted")
        s.references += 1

    cdef void _release_u(self, uint64_t handle) except *:
        cdef OrderSlot *s = self._lookup_u(handle)
        cdef unsigned int f
        cdef uint32_t index = <uint32_t>handle
        s.references -= 1
        if s.references:
            return
        for f in range(13):
            if s.fields[f] != NULL:
                Py_DECREF(<object>s.fields[f])
                s.fields[f] = NULL
        self._live_n -= 1
        if s.generation == UINT32_MAX:
            return
        s.generation += 1
        s.next_free = self._free_head
        self._free_head = index

    cdef uint64_t _new_limit_u(self, agent_id, time_placed, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, tag=None) except? 0:
        cdef uint64_t handle = self._allocate_u()
        if order_id is None:
            order_id = Order._order_id_counter
            Order._order_id_counter += 1
        try:
            self._set_u(handle,0,agent_id)
            self._set_u(handle,1,time_placed)
            self._set_u(handle,2,symbol)
            self._set_u(handle,3,quantity)
            self._set_u(handle,4,side)
            self._set_u(handle,5,order_id)
            self._set_u(handle,6,None)
            self._set_u(handle,7,tag)
            self._set_u(handle,8,limit_price)
            self._set_u(handle,9,is_hidden)
            self._set_u(handle,10,is_price_to_comply)
            self._set_u(handle,11,insert_by_id)
            self._set_u(handle,12,is_post_only)
            return handle
        except BaseException:
            self._release_u(handle)
            raise

    cdef uint64_t _clone_u(self, uint64_t handle) except? 0:
        cdef unsigned int f
        cdef uint64_t out = self._allocate_u()
        try:
            for f in range(13):
                self._set_u(out,f,self._get_u(handle,f))
            tag = self._get_u(handle,7)
            if tag is not None:
                self._set_u(out,7,deepcopy(tag))
            if self._get_u(out,5) is None:
                self._set_u(out,5,Order._order_id_counter)
                Order._order_id_counter += 1
            self._clones_n += 1
            return out
        except BaseException:
            self._release_u(out)
            raise

    cdef object _format_u(self, uint64_t handle):
        fill = self._get_u(handle,6)
        price = self._get_u(handle,8)
        tag = self._get_u(handle,7)
        return "(Agent {} @ {}{}) : {} {} {} @ {}{}".format(self._get_u(handle,0),fmt_ts(self._get_u(handle,1)),f" [{tag}]" if tag is not None else "",self._get_u(handle,4).value,self._get_u(handle,3),self._get_u(handle,2),dollarize(price) if abs(price)<sys.maxsize else "MKT"," (filled @ {})".format(dollarize(fill)) if fill else "")

    cdef object _allocate(self):
        return int(self._allocate_u())

    cdef object _get(self, object handle, unsigned int field):
        return self._get_u(self._checked_handle(handle),field)

    cdef void _set(self, object handle, unsigned int field, object value) except *:
        self._set_u(self._checked_handle(handle),field,value)

    cdef void _retain(self, object handle) except *:
        self._retain_u(self._checked_handle(handle))

    cdef void _release(self, object handle) except *:
        self._release_u(self._checked_handle(handle))

    cdef object _new_limit(self, agent_id, time_placed, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, tag=None):
        return int(self._new_limit_u(agent_id,time_placed,symbol,quantity,side,limit_price,order_id,is_hidden,is_price_to_comply,insert_by_id,is_post_only,tag))

    cdef object _clone(self, object handle):
        return int(self._clone_u(self._checked_handle(handle)))

    cdef object _format(self, object handle):
        return self._format_u(self._checked_handle(handle))

    def cold_materialize(self, handle, memo):
        # Control boundary only: never called by production callbacks.
        key = ("order",id(self),handle)
        if key in memo:
            return memo[key]
        self._lookup(handle)
        value = object.__new__(LimitOrder)
        memo[key] = value
        fields={}
        for i,name in enumerate(ORDER_FIELD_NAMES):fields[name]=self._get(handle,i)
        value.__dict__=fields
        return value

    def statistics(self):
        return {"live_orders":int(self._live_n),"order_clones":int(self._clones_n),"order_slots":int(self._slots_n)}

cdef class MessageArena:
    def __cinit__(self):
        self._chunks = NULL
        self._chunks_n = 0
        self._directory_n = 0
        self._slots_n = 0
        self._free_head = UINT32_MAX
        self._live_n = 0
        self._created_n = 0

    def __init__(self, OrderArena orders):
        self.orders = orders

    def __dealloc__(self):
        cdef size_t c,i,f
        cdef MessageSlot *s
        if self._chunks != NULL:
            for c in range(self._chunks_n):
                for i in range(1024):
                    s=&self._chunks[c][i]
                    for f in range(7):
                        if s.fields[f] != NULL:
                            Py_DECREF(<object>s.fields[f])
                free(self._chunks[c])
            free(self._chunks)

    cdef MessageSlot *_index(self, uint32_t i) noexcept:
        return &self._chunks[i // 1024][i % 1024]

    cdef void _grow(self) except *:
        cdef MessageSlot *block
        cdef MessageSlot **directory
        cdef size_t capacity
        cdef uint32_t i
        if self._slots_n > UINT32_MAX - 1024:
            raise OverflowError("dynamic message addressing exhausted")
        block=<MessageSlot *>calloc(1024,sizeof(MessageSlot))
        if block == NULL: raise MemoryError("dynamic message chunk allocation failed")
        if self._chunks_n == self._directory_n:
            capacity=4 if self._directory_n==0 else self._directory_n*2
            directory=<MessageSlot **>realloc(self._chunks,capacity*sizeof(MessageSlot *))
            if directory == NULL:
                free(block)
                raise MemoryError("dynamic message directory allocation failed")
            self._chunks=directory
            self._directory_n=capacity
        for i in range(1024):
            block[i].generation=1
            block[i].next_free=self._slots_n+i+1 if i<1023 else self._free_head
        self._chunks[self._chunks_n]=block
        self._chunks_n+=1
        self._free_head=self._slots_n
        self._slots_n+=1024

    cdef MessageSlot *_lookup(self, object handle) except NULL:
        cdef uint64_t h
        cdef uint32_t i,g
        cdef MessageSlot *s
        if type(handle) is not int or handle <= 0 or handle > 18446744073709551615:
            raise ValueError("invalid native message handle")
        h=handle
        i,g=<uint32_t>h,<uint32_t>(h>>32)
        if i>=self._slots_n or g==0: raise ValueError("invalid native message handle")
        s=self._index(i)
        if s.references==0 or s.generation!=g: raise ValueError("stale native message handle")
        return s

    cdef object _get(self, object handle, unsigned int field):
        cdef MessageSlot *s=self._lookup(handle)
        if field>=7 or s.fields[field]==NULL: raise ValueError("invalid message field")
        return <object>s.fields[field]

    cdef unsigned int _kind(self, object handle) except? 0:
        return self._lookup(handle).kind

    cdef object _id(self, object handle):
        return self._get(handle,0)

    cdef uint64_t _order_u(self, object handle) except? 0:
        cdef MessageSlot *slot=self._lookup(handle)
        if slot.order_handle:self.orders._lookup_u(slot.order_handle)
        return slot.order_handle

    cdef object _order(self, object handle):
        cdef uint64_t value=self._order_u(handle)
        return None if value==0 else int(value)

    cdef object _name(self, object handle):
        return MESSAGE_KIND_NAMES[self._kind(handle)-1]

    cdef object _new_u(self, unsigned int kind, uint64_t order=0, a=None,b=None,c=None,d=None,e=None,f=None,message_id=None):
        cdef uint32_t index
        cdef MessageSlot *s
        cdef unsigned int n
        if kind<1 or kind>13: raise ValueError("unsupported whole-episode message kind")
        if order: self.orders._lookup_u(order)
        if self._free_head==UINT32_MAX: self._grow()
        index=self._free_head
        s=self._index(index)
        self._free_head=s.next_free
        s.references=1
        s.kind=kind
        s.order_handle=0
        self._live_n+=1
        out=int((<uint64_t>s.generation<<32)|index)
        try:
            if message_id is None:
                message_id=Message._Message__message_id_counter
                Message._Message__message_id_counter+=1
                self._created_n+=1
            Py_INCREF(message_id)
            s.fields[0]=<PyObject *>message_id
            Py_INCREF(a)
            s.fields[1]=<PyObject *>a
            Py_INCREF(b)
            s.fields[2]=<PyObject *>b
            Py_INCREF(c)
            s.fields[3]=<PyObject *>c
            Py_INCREF(d)
            s.fields[4]=<PyObject *>d
            Py_INCREF(e)
            s.fields[5]=<PyObject *>e
            Py_INCREF(f)
            s.fields[6]=<PyObject *>f
            if order:
                self.orders._retain_u(order)
                s.order_handle=order
            return out
        except BaseException:
            self._release(out)
            raise

    cdef object _new(self, unsigned int kind, order=None, a=None,b=None,c=None,d=None,e=None,f=None,message_id=None):
        cdef uint64_t admitted=0
        if kind<1 or kind>13:raise ValueError("unsupported whole-episode message kind")
        if order is not None:admitted=self.orders._checked_handle(order)
        return self._new_u(kind,admitted,a,b,c,d,e,f,message_id)

    cdef void _retain(self, object handle) except *:
        cdef MessageSlot *s=self._lookup(handle)
        if s.references==UINT32_MAX: raise OverflowError("message references exhausted")
        s.references+=1

    cdef void _release(self, object handle) except *:
        cdef MessageSlot *s=self._lookup(handle)
        cdef unsigned int f
        cdef uint32_t index=<uint32_t><uint64_t>handle
        s.references-=1
        if s.references: return
        if s.order_handle:
            self.orders._release_u(s.order_handle)
            s.order_handle=0
        for f in range(7):
            if s.fields[f]!=NULL:
                Py_DECREF(<object>s.fields[f])
                s.fields[f]=NULL
        self._live_n-=1
        if s.generation==UINT32_MAX: return
        s.generation+=1
        s.next_free=self._free_head
        self._free_head=index

    def import_initial_wakeup(self, value):
        if type(value) is not WakeupMsg or set(value.__dict__) != {"message_id"}:
            raise ValueError("initial native queue requires exact original wakeups")
        return self._new(1, None, None, None, None, None, None, None, value.message_id)

    def cold_materialize(self,handle,memo):
        key=("message",id(self),handle)
        if key in memo: return memo[key]
        kinds=(WakeupMsg,MarketClosePriceRequestMsg,MarketHoursRequestMsg,MarketHoursMsg,QuerySpreadMsg,QuerySpreadResponseMsg,LimitOrderMsg,OrderAcceptedMsg,OrderExecutedMsg,CancelOrderMsg,OrderCancelledMsg,MarketClosePriceMsg,MarketClosedMsg)
        kind=self._kind(handle)
        value=object.__new__(kinds[kind-1])
        memo[key]=value
        value.message_id=self._id(handle)
        fields={4:("mkt_open","mkt_close"),5:("symbol","depth"),6:("symbol","mkt_closed","depth","bids","asks","last_trade"),10:("tag","metadata"),12:("close_prices",)}.get(kind,())
        for i,name in enumerate(fields): setattr(value,name,self._get(handle,i+1))
        order=self._order(handle)
        if order is not None: value.order=self.orders.cold_materialize(order,memo)
        return value

    def statistics(self):
        return {"live_messages":int(self._live_n),"constructed_messages":int(self._created_n),"message_slots":int(self._slots_n)}

cdef class DeliveryHeap:
    def __cinit__(self):
        self._rows=NULL
        self._size=0
        self._capacity=0

    def __init__(self, MessageArena messages):
        self.arena=messages

    def __dealloc__(self):
        cdef size_t i,j
        if self._rows != NULL:
            for i in range(self._size):
                for j in range(4):
                    Py_DECREF(<object>self._rows[i].keys[j])
            free(self._rows)

    def empty(self): return self._size==0
    def qsize(self): return int(self._size)

    def cold_key_cache_diagnostics(self):
        cdef size_t i, valid=0
        for i in range(self._size):
            if self._rows[i].primitive_keys_valid:
                valid+=1
        return {"rows":int(self._size),"valid_primitive_rows":int(valid)}

    property queue:
        def __get__(self):
            # Cold compatibility only, never a second live scheduling authority.
            rows=[]
            for i in range(self._size):
                rows.append((<object>self._rows[i].keys[0],<object>self._rows[i].keys[1],<object>self._rows[i].keys[2],<object>self._rows[i].keys[3],int(self._rows[i].handle)))
            return rows

    cdef void _cache_primitive_keys(self, DeliveryRow *row) except *:
        cdef unsigned int field
        cdef int overflow
        cdef long long value
        row.primitive_keys_valid = False
        # Only the timestamp additionally accepts the exact NumPy C-API scalar.
        # Other keys must remain exact Python ints within signed64. Bool,
        # subclasses, other NumPy scalars and overflow retain donor compares.
        if not (PyLong_CheckExact(<object>row.keys[0]) or t3_heap_numpy_exact_int64(row.keys[0])):
            return
        for field in range(1,4):
            if not PyLong_CheckExact(<object>row.keys[field]):
                return
        for field in range(4):
            if field==0 and t3_heap_numpy_exact_int64(row.keys[0]):
                row.primitive_keys[0] = t3_heap_numpy_read_int64(row.keys[0])
                continue
            overflow = 0
            value = PyLong_AsLongLongAndOverflow(<object>row.keys[field], &overflow)
            if overflow != 0:
                return
            row.primitive_keys[field] = <int64_t>value
        row.primitive_keys_valid = True

    cdef bint _before(self, DeliveryRow *left, DeliveryRow *right) except *:
        cdef unsigned int field
        if left.primitive_keys_valid and right.primitive_keys_valid:
            for field in range(4):
                if left.primitive_keys[field] != right.primitive_keys[field]:
                    return left.primitive_keys[field] < right.primitive_keys[field]
            return False
        for field in range(4):
            if (<object>left.keys[field]) != (<object>right.keys[field]):
                return (<object>left.keys[field]) < (<object>right.keys[field])
        return False

    cdef void _push(self, when,src,dst,handle) except *:
        cdef DeliveryRow *rows
        cdef DeliveryRow row
        cdef size_t capacity,index,parent
        if self._size==self._capacity:
            capacity=1024 if self._capacity==0 else self._capacity*2
            if capacity<=self._capacity or capacity > (<size_t>-1)//sizeof(DeliveryRow):
                raise OverflowError("native delivery heap capacity overflow")
            rows=<DeliveryRow *>realloc(self._rows,capacity*sizeof(DeliveryRow))
            if rows==NULL: raise MemoryError("native delivery heap allocation failed")
            self._rows=rows
            self._capacity=capacity
        mid=self.arena._id(handle)
        # Borrow only from live arguments/mid until cache conversion succeeds.
        # A conversion exception must not add message or key ownership.
        row.keys[0]=<PyObject *>when
        row.keys[1]=<PyObject *>src
        row.keys[2]=<PyObject *>dst
        row.keys[3]=<PyObject *>mid
        row.handle=handle
        self._cache_primitive_keys(&row)
        self.arena._retain(handle)
        Py_INCREF(when)
        Py_INCREF(src)
        Py_INCREF(dst)
        Py_INCREF(mid)
        # Fixed admitted scalar comparisons do not call participant code.
        index=self._size
        self._size+=1
        while index:
            parent=(index-1)//2
            if not self._before(&row,&self._rows[parent]):break
            self._rows[index]=self._rows[parent]
            index=parent
        self._rows[index]=row

    cdef object _pop(self):
        cdef DeliveryRow out,last
        cdef size_t index,left,right,child,parent
        cdef unsigned int field
        if self._size==0:raise IndexError("pop empty native delivery heap")
        out=self._rows[0]
        self._size-=1
        if self._size:
            last=self._rows[self._size]
            index=0
            # Match heapq._siftup: choose the right child on equal keys,
            # move to a leaf first, then _siftdown(last). This preserves the
            # retained internal heap arrangement as well as delivery order.
            while True:
                left=2*index+1
                if left>=self._size:break
                right=left+1
                child=right if right<self._size and not self._before(&self._rows[left],&self._rows[right]) else left
                self._rows[index]=self._rows[child]
                index=child
            while index:
                parent=(index-1)//2
                if not self._before(&last,&self._rows[parent]):break
                self._rows[index]=self._rows[parent]
                index=parent
            self._rows[index]=last
        result=(<object>out.keys[0],<object>out.keys[1],<object>out.keys[2],<object>out.keys[3],int(out.handle))
        for field in range(4):Py_DECREF(<object>out.keys[field])
        # Message ownership transfers to current dispatcher local.
        return result

    def import_rows(self,rows):
        cdef DeliveryRow *grown
        cdef DeliveryRow row
        # Original initialize already created the exact heap. Preserve its
        # physical row order rather than reinserting into a new heap.
        for when,src,dst,value in rows:
            handle=self.arena.import_initial_wakeup(value)
            if self._size==self._capacity:
                capacity=1024 if self._capacity==0 else self._capacity*2
                if capacity<=self._capacity or capacity>(<size_t>-1)//sizeof(DeliveryRow):
                    self.arena._release(handle)
                    raise OverflowError("native initial heap capacity overflow")
                grown=<DeliveryRow *>realloc(self._rows,capacity*sizeof(DeliveryRow))
                if grown==NULL:
                    self.arena._release(handle)
                    raise MemoryError("native initial heap allocation failed")
                self._rows=grown
                self._capacity=capacity
            mid=self.arena._id(handle)
            row.keys[0]=<PyObject *>when
            row.keys[1]=<PyObject *>src
            row.keys[2]=<PyObject *>dst
            row.keys[3]=<PyObject *>mid
            row.handle=handle
            try:
                self._cache_primitive_keys(&row)
            except BaseException:
                self.arena._release(handle)
                raise
            Py_INCREF(when)
            Py_INCREF(src)
            Py_INCREF(dst)
            Py_INCREF(mid)
            self._rows[self._size]=row
            self._size+=1
            # Newly imported message's single owner transfers to delivery.

    def cold_rows(self,memo):
        rows=[]
        for i in range(self._size):
            rows.append((<object>self._rows[i].keys[0],<object>self._rows[i].keys[1],<object>self._rows[i].keys[2],self.arena.cold_materialize(int(self._rows[i].handle),memo)))
        return rows


cdef void _observe_order(object owner, object event, OrderArena arena, uint64_t handle) except *:
    cdef NativeTrader trader
    cdef NativeExchange exchange
    state=_observer.STATE
    if state is None:raise ValueError("arena observer whole-episode admission missing")
    if type(owner) is NativeTrader:
        trader=owner
        if not trader._slot_log_events:return
        current_time=trader._slot_current_time
    elif type(owner) is NativeExchange:
        exchange=owner
        if not exchange._slot_log_events:return
        current_time=exchange._slot_current_time
    else:raise ValueError("unadmitted observer owner")
    record=(current_time,event,"order",(arena._get_u(handle,0),arena._get_u(handle,5),arena._get_u(handle,4),arena._get_u(handle,3),arena._get_u(handle,8),arena._get_u(handle,6)))
    canonical=event in _observer.ORDER_TYPES
    # Same two authoritative episode dicts and per-owner list insertion order.
    # No Python observer function/method or raw Order payload is called.
    state.inference.setdefault(owner,[]).append(record)
    if canonical:state.contract.setdefault(owner,[]).append(record)
    state.order_rows+=canonical
    state.private_rows+=not canonical

cdef void _observe_quote(object owner, object event, object symbol, object price, object quantity) except *:
    cdef NativeExchange exchange=owner
    state=_observer.STATE
    if state is None:raise ValueError("arena quote admission missing")
    if not exchange._slot_log_events:return
    record=(exchange._slot_current_time,event,"quote",(symbol,price,quantity))
    state.inference.setdefault(owner,[]).append(record)
    state.contract.setdefault(owner,[]).append(record)
    state.has_scalar=True
    state.quote_rows+=1

cdef void _observe_diagnostic(object owner, object event, object value) except *:
    cdef NativeTrader trader
    cdef NativeExchange exchange
    state=_observer.STATE
    if state is None:raise ValueError("arena diagnostic admission missing")
    if type(owner) is NativeTrader:
        trader=owner
        if not trader._slot_log_events:return
        current_time=trader._slot_current_time
    elif type(owner) is NativeExchange:
        exchange=owner
        if not exchange._slot_log_events:return
        current_time=exchange._slot_current_time
    else:raise ValueError("unadmitted diagnostic owner")
    state.inference.setdefault(owner,[]).append((current_time,event,"raw",""))
    state.has_scalar=True
    state.private_rows+=1

cdef bint _observe_log(object owner, object event_type, object event, object append_summary_log, object deepcopy_event) except *:
    cdef NativeTrader trader
    cdef NativeExchange exchange
    state=_observer.STATE
    if state is None:raise ValueError("arena log admission missing")
    if type(owner) is NativeTrader:
        trader=owner
        if not trader._slot_log_events:return True
        current_time=trader._slot_current_time
    elif type(owner) is NativeExchange:
        exchange=owner
        if not exchange._slot_log_events:return True
        current_time=exchange._slot_current_time
    else:raise ValueError("unadmitted log owner")
    scalar=False
    if event is None:payload=None
    elif type(event) is dict:
        payload={}
        for key in _observer.FIELDS:
            if key in event:payload[key]=event[key]
        scalar='ScalarEventValue' in event
    elif type(event) in (str,int,float,bool):payload,scalar=event,True
    else:payload,scalar='',True
    record=(current_time,event_type,'raw',payload)
    canonical=event_type in _observer.ORDER_TYPES or event_type in ('BEST_BID','BEST_ASK')
    state.inference.setdefault(owner,[]).append(record)
    if canonical:state.contract.setdefault(owner,[]).append(record)
    state.has_scalar |= scalar
    if append_summary_log or event_type=='AGENT_TYPE':return False
    state.private_rows+=not canonical
    return True


cdef class NativeTrader:
    def __cinit__(self):
        self._prepared = False
        self._bound = False

    def __init__(self, source_agent):
        if self._prepared:
            raise ValueError("native trader construction is one-shot")
        self._prepared = True
        self._scheduler = None
        self._missing = _MISSING
        self._bound = False
        self._strategy_name = exact_original_class(source_agent)
        self._origin_class = type(source_agent)
        self._source_agent = source_agent
        values = source_agent.__dict__
        if type(values) is not dict or set(values) != set(REQUIRED_FIELDS[self._strategy_name]):
            raise ValueError("original initialized strategy field roster differs")
        if values["kernel"] is None or values["oracle"] is not values["kernel"].oracle:
            raise ValueError("original initialization and oracle owner required")
        if type(values["id"]) is not int or values["id"] <= 0:
            raise ValueError("original dense trader identity required")
        self._slot_MKT_BUY = _MISSING
        self._slot_MKT_SELL = _MISSING
        self._slot__mid_history = _MISSING
        self._slot_basket_size = _MISSING
        self._slot_book = _MISSING
        self._slot_current_time = _MISSING
        self._slot_daily_close_price = _MISSING
        self._slot_depth_levels = _MISSING
        self._slot_exchange_id = _MISSING
        self._slot_exchange_ts = _MISSING
        self._slot_executed_orders = _MISSING
        self._slot_first_wake = _MISSING
        self._slot_holdings = _MISSING
        self._slot_id = _MISSING
        self._slot_interval_ns = _MISSING
        self._slot_kernel = _MISSING
        self._slot_known_asks = _MISSING
        self._slot_known_bids = _MISSING
        self._slot_last_trade = _MISSING
        self._slot_log = _MISSING
        self._slot_log_events = _MISSING
        self._slot_log_orders = _MISSING
        self._slot_log_to_file = _MISSING
        self._slot_lookback = _MISSING
        self._slot_mkt_close = _MISSING
        self._slot_mkt_closed = _MISSING
        self._slot_mkt_open = _MISSING
        self._slot_name = _MISSING
        self._slot_nav_diff = _MISSING
        self._slot_oracle = _MISSING
        self._slot_order_size_mean = _MISSING
        self._slot_order_size_std = _MISSING
        self._slot_orders = _MISSING
        self._slot_price_offset_ticks = _MISSING
        self._slot_random_state = _MISSING
        self._slot_reference_price = _MISSING
        self._slot_sigma_n = _MISSING
        self._slot_size_per_level = _MISSING
        self._slot_spread_ticks = _MISSING
        self._slot_starting_cash = _MISSING
        self._slot_state = _MISSING
        self._slot_stream_history = _MISSING
        self._slot_symbol = _MISSING
        self._slot_threshold_ticks = _MISSING
        self._slot_transacted_volume = _MISSING
        self._slot_type = _MISSING
        if 'MKT_BUY' in values:
            self._slot_MKT_BUY = values['MKT_BUY']
        if 'MKT_SELL' in values:
            self._slot_MKT_SELL = values['MKT_SELL']
        if '_mid_history' in values:
            self._slot__mid_history = values['_mid_history']
        if 'basket_size' in values:
            self._slot_basket_size = values['basket_size']
        if 'book' in values:
            self._slot_book = values['book']
        if 'current_time' in values:
            self._slot_current_time = values['current_time']
        if 'daily_close_price' in values:
            self._slot_daily_close_price = values['daily_close_price']
        if 'depth_levels' in values:
            self._slot_depth_levels = values['depth_levels']
        if 'exchange_id' in values:
            self._slot_exchange_id = values['exchange_id']
        if 'exchange_ts' in values:
            self._slot_exchange_ts = values['exchange_ts']
        if 'executed_orders' in values:
            self._slot_executed_orders = values['executed_orders']
        if 'first_wake' in values:
            self._slot_first_wake = values['first_wake']
        if 'holdings' in values:
            self._slot_holdings = values['holdings']
        if 'id' in values:
            self._slot_id = values['id']
        if 'interval_ns' in values:
            self._slot_interval_ns = values['interval_ns']
        if 'kernel' in values:
            self._slot_kernel = values['kernel']
        if 'known_asks' in values:
            self._slot_known_asks = values['known_asks']
        if 'known_bids' in values:
            self._slot_known_bids = values['known_bids']
        if 'last_trade' in values:
            self._slot_last_trade = values['last_trade']
        if 'log' in values:
            self._slot_log = values['log']
        if 'log_events' in values:
            self._slot_log_events = values['log_events']
        if 'log_orders' in values:
            self._slot_log_orders = values['log_orders']
        if 'log_to_file' in values:
            self._slot_log_to_file = values['log_to_file']
        if 'lookback' in values:
            self._slot_lookback = values['lookback']
        if 'mkt_close' in values:
            self._slot_mkt_close = values['mkt_close']
        if 'mkt_closed' in values:
            self._slot_mkt_closed = values['mkt_closed']
        if 'mkt_open' in values:
            self._slot_mkt_open = values['mkt_open']
        if 'name' in values:
            self._slot_name = values['name']
        if 'nav_diff' in values:
            self._slot_nav_diff = values['nav_diff']
        if 'oracle' in values:
            self._slot_oracle = values['oracle']
        if 'order_size_mean' in values:
            self._slot_order_size_mean = values['order_size_mean']
        if 'order_size_std' in values:
            self._slot_order_size_std = values['order_size_std']
        if 'orders' in values:
            self._slot_orders = values['orders']
        if 'price_offset_ticks' in values:
            self._slot_price_offset_ticks = values['price_offset_ticks']
        if 'random_state' in values:
            self._slot_random_state = values['random_state']
        if 'reference_price' in values:
            self._slot_reference_price = values['reference_price']
        if 'sigma_n' in values:
            self._slot_sigma_n = values['sigma_n']
        if 'size_per_level' in values:
            self._slot_size_per_level = values['size_per_level']
        if 'spread_ticks' in values:
            self._slot_spread_ticks = values['spread_ticks']
        if 'starting_cash' in values:
            self._slot_starting_cash = values['starting_cash']
        if 'state' in values:
            self._slot_state = values['state']
        if 'stream_history' in values:
            self._slot_stream_history = values['stream_history']
        if 'symbol' in values:
            self._slot_symbol = values['symbol']
        if 'threshold_ticks' in values:
            self._slot_threshold_ticks = values['threshold_ticks']
        if 'transacted_volume' in values:
            self._slot_transacted_volume = values['transacted_volume']
        if 'type' in values:
            self._slot_type = values['type']

    def bind_scheduler(self, scheduler):
        cdef ChainScheduler typed
        if type(scheduler) is not ChainScheduler:
            raise ValueError("same-extension trader scheduler required")
        typed = scheduler
        if typed.kernel is not self._slot_kernel:
            raise ValueError("trader scheduler/kernel identity differs")
        if self._scheduler is not None and self._scheduler is not typed:
            raise ValueError("trader scheduler already bound")
        self._scheduler = typed
        self._orders = typed.orders
        self._messages = typed.messages

    def bind_after_source_retired(self):
        # Coordinator retires the original raw object only after all owners,
        # kernel list slots and observer key changes are preflighted together.
        if self._bound:
            raise ValueError("native trader already authoritative")
        if self._source_agent.__dict__ != {"_native_moved_to": id(self)}:
            raise ValueError("source raw agent retains a shadow state")
        if self._slot_kernel.ttl_messages != 0 or self._slot_kernel._deliver_seq != 0:
            raise ValueError("authority migration requires no runner delivery")
        if self._scheduler is None:
            raise ValueError("trader scheduler unbound")
        self._bound = True

    def abort_before_first_delivery(self):
        if self._slot_kernel.ttl_messages != 0 or self._slot_kernel._deliver_seq != 0:
            raise ValueError("cannot roll back an owner after runner delivery")
        self._bound = False

    def origin_class(self):
        return self._origin_class

    def strategy_name(self):
        return self._strategy_name

    def authority_bound(self):
        return bool(self._bound)

    cdef object _require_bound(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")

    def snapshot_fields(self):
        # Cold control/output mapping only. The event path never exports or
        # synchronizes this dict back into the retired source object.
        result = {}
        if self._slot_MKT_BUY is not self._missing:
            result['MKT_BUY'] = self._slot_MKT_BUY
        if self._slot_MKT_SELL is not self._missing:
            result['MKT_SELL'] = self._slot_MKT_SELL
        if self._slot__mid_history is not self._missing:
            result['_mid_history'] = self._slot__mid_history
        if self._slot_basket_size is not self._missing:
            result['basket_size'] = self._slot_basket_size
        if self._slot_book is not self._missing:
            result['book'] = self._slot_book
        if self._slot_current_time is not self._missing:
            result['current_time'] = self._slot_current_time
        if self._slot_daily_close_price is not self._missing:
            result['daily_close_price'] = self._slot_daily_close_price
        if self._slot_depth_levels is not self._missing:
            result['depth_levels'] = self._slot_depth_levels
        if self._slot_exchange_id is not self._missing:
            result['exchange_id'] = self._slot_exchange_id
        if self._slot_exchange_ts is not self._missing:
            result['exchange_ts'] = self._slot_exchange_ts
        if self._slot_executed_orders is not self._missing:
            result['executed_orders'] = self._slot_executed_orders
        if self._slot_first_wake is not self._missing:
            result['first_wake'] = self._slot_first_wake
        if self._slot_holdings is not self._missing:
            result['holdings'] = self._slot_holdings
        if self._slot_id is not self._missing:
            result['id'] = self._slot_id
        if self._slot_interval_ns is not self._missing:
            result['interval_ns'] = self._slot_interval_ns
        if self._slot_kernel is not self._missing:
            result['kernel'] = self._slot_kernel
        if self._slot_known_asks is not self._missing:
            result['known_asks'] = self._slot_known_asks
        if self._slot_known_bids is not self._missing:
            result['known_bids'] = self._slot_known_bids
        if self._slot_last_trade is not self._missing:
            result['last_trade'] = self._slot_last_trade
        if self._slot_log is not self._missing:
            result['log'] = self._slot_log
        if self._slot_log_events is not self._missing:
            result['log_events'] = self._slot_log_events
        if self._slot_log_orders is not self._missing:
            result['log_orders'] = self._slot_log_orders
        if self._slot_log_to_file is not self._missing:
            result['log_to_file'] = self._slot_log_to_file
        if self._slot_lookback is not self._missing:
            result['lookback'] = self._slot_lookback
        if self._slot_mkt_close is not self._missing:
            result['mkt_close'] = self._slot_mkt_close
        if self._slot_mkt_closed is not self._missing:
            result['mkt_closed'] = self._slot_mkt_closed
        if self._slot_mkt_open is not self._missing:
            result['mkt_open'] = self._slot_mkt_open
        if self._slot_name is not self._missing:
            result['name'] = self._slot_name
        if self._slot_nav_diff is not self._missing:
            result['nav_diff'] = self._slot_nav_diff
        if self._slot_oracle is not self._missing:
            result['oracle'] = self._slot_oracle
        if self._slot_order_size_mean is not self._missing:
            result['order_size_mean'] = self._slot_order_size_mean
        if self._slot_order_size_std is not self._missing:
            result['order_size_std'] = self._slot_order_size_std
        if self._slot_orders is not self._missing:
            result['orders'] = self._slot_orders
        if self._slot_price_offset_ticks is not self._missing:
            result['price_offset_ticks'] = self._slot_price_offset_ticks
        if self._slot_random_state is not self._missing:
            result['random_state'] = self._slot_random_state
        if self._slot_reference_price is not self._missing:
            result['reference_price'] = self._slot_reference_price
        if self._slot_sigma_n is not self._missing:
            result['sigma_n'] = self._slot_sigma_n
        if self._slot_size_per_level is not self._missing:
            result['size_per_level'] = self._slot_size_per_level
        if self._slot_spread_ticks is not self._missing:
            result['spread_ticks'] = self._slot_spread_ticks
        if self._slot_starting_cash is not self._missing:
            result['starting_cash'] = self._slot_starting_cash
        if self._slot_state is not self._missing:
            result['state'] = self._slot_state
        if self._slot_stream_history is not self._missing:
            result['stream_history'] = self._slot_stream_history
        if self._slot_symbol is not self._missing:
            result['symbol'] = self._slot_symbol
        if self._slot_threshold_ticks is not self._missing:
            result['threshold_ticks'] = self._slot_threshold_ticks
        if self._slot_transacted_volume is not self._missing:
            result['transacted_volume'] = self._slot_transacted_volume
        if self._slot_type is not self._missing:
            result['type'] = self._slot_type
        return result

    def source_identity(self):
        return self._source_agent

    def __lt__(self, other):
        return f'{self.id}' < f'{other.id}'

    def __hash__(self):
        # Primitive observer uses identity-keyed dictionaries; rich comparison
        # support must never accidentally suppress extension identity hashing.
        return object.__hash__(self)

    def wakeup(self, current_time):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._wakeup(current_time)

    def receive_message(self, current_time, sender_id, message):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._receive_message(current_time, sender_id, message)

    def act(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._act()

    def kernel_stopping(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._kernel_stopping()

    def kernel_terminating(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._kernel_terminating()

    cdef object _act(self):
        if self._strategy_name == 'NoiseTrader':
            return self._act_NoiseTrader()
        elif self._strategy_name == 'MarketMaker':
            return self._act_MarketMaker()
        elif self._strategy_name == 'ValueTrader':
            return self._act_ValueTrader()
        elif self._strategy_name == 'MomentumTrader':
            return self._act_MomentumTrader()
        raise ValueError('typed trader has unknown admitted strategy')




    property MKT_BUY:
        def __get__(self):
            if self._slot_MKT_BUY is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_BUY'")
            return self._slot_MKT_BUY

        def __set__(self, value):
            self._slot_MKT_BUY = value

        def __del__(self):
            if self._slot_MKT_BUY is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_BUY'")
            self._slot_MKT_BUY = self._missing

    property MKT_SELL:
        def __get__(self):
            if self._slot_MKT_SELL is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_SELL'")
            return self._slot_MKT_SELL

        def __set__(self, value):
            self._slot_MKT_SELL = value

        def __del__(self):
            if self._slot_MKT_SELL is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_SELL'")
            self._slot_MKT_SELL = self._missing

    property _mid_history:
        def __get__(self):
            if self._slot__mid_history is self._missing:
                raise AttributeError("native owner has no initialized attribute '_mid_history'")
            return self._slot__mid_history

        def __set__(self, value):
            self._slot__mid_history = value

        def __del__(self):
            if self._slot__mid_history is self._missing:
                raise AttributeError("native owner has no initialized attribute '_mid_history'")
            self._slot__mid_history = self._missing

    property basket_size:
        def __get__(self):
            if self._slot_basket_size is self._missing:
                raise AttributeError("native owner has no initialized attribute 'basket_size'")
            return self._slot_basket_size

        def __set__(self, value):
            self._slot_basket_size = value

        def __del__(self):
            if self._slot_basket_size is self._missing:
                raise AttributeError("native owner has no initialized attribute 'basket_size'")
            self._slot_basket_size = self._missing

    property book:
        def __get__(self):
            if self._slot_book is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book'")
            return self._slot_book

        def __set__(self, value):
            self._slot_book = value

        def __del__(self):
            if self._slot_book is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book'")
            self._slot_book = self._missing

    property current_time:
        def __get__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            return self._slot_current_time

        def __set__(self, value):
            self._slot_current_time = value

        def __del__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            self._slot_current_time = self._missing

    property daily_close_price:
        def __get__(self):
            if self._slot_daily_close_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'daily_close_price'")
            return self._slot_daily_close_price

        def __set__(self, value):
            self._slot_daily_close_price = value

        def __del__(self):
            if self._slot_daily_close_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'daily_close_price'")
            self._slot_daily_close_price = self._missing

    property depth_levels:
        def __get__(self):
            if self._slot_depth_levels is self._missing:
                raise AttributeError("native owner has no initialized attribute 'depth_levels'")
            return self._slot_depth_levels

        def __set__(self, value):
            self._slot_depth_levels = value

        def __del__(self):
            if self._slot_depth_levels is self._missing:
                raise AttributeError("native owner has no initialized attribute 'depth_levels'")
            self._slot_depth_levels = self._missing

    property exchange_id:
        def __get__(self):
            if self._slot_exchange_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_id'")
            return self._slot_exchange_id

        def __set__(self, value):
            self._slot_exchange_id = value

        def __del__(self):
            if self._slot_exchange_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_id'")
            self._slot_exchange_id = self._missing

    property exchange_ts:
        def __get__(self):
            if self._slot_exchange_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_ts'")
            return self._slot_exchange_ts

        def __set__(self, value):
            self._slot_exchange_ts = value

        def __del__(self):
            if self._slot_exchange_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_ts'")
            self._slot_exchange_ts = self._missing

    property executed_orders:
        def __get__(self):
            if self._slot_executed_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'executed_orders'")
            return self._slot_executed_orders

        def __set__(self, value):
            self._slot_executed_orders = value

        def __del__(self):
            if self._slot_executed_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'executed_orders'")
            self._slot_executed_orders = self._missing

    property first_wake:
        def __get__(self):
            if self._slot_first_wake is self._missing:
                raise AttributeError("native owner has no initialized attribute 'first_wake'")
            return self._slot_first_wake

        def __set__(self, value):
            self._slot_first_wake = value

        def __del__(self):
            if self._slot_first_wake is self._missing:
                raise AttributeError("native owner has no initialized attribute 'first_wake'")
            self._slot_first_wake = self._missing

    property holdings:
        def __get__(self):
            if self._slot_holdings is self._missing:
                raise AttributeError("native owner has no initialized attribute 'holdings'")
            return self._slot_holdings

        def __set__(self, value):
            self._slot_holdings = value

        def __del__(self):
            if self._slot_holdings is self._missing:
                raise AttributeError("native owner has no initialized attribute 'holdings'")
            self._slot_holdings = self._missing

    property id:
        def __get__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            return self._slot_id

        def __set__(self, value):
            self._slot_id = value

        def __del__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            self._slot_id = self._missing

    property interval_ns:
        def __get__(self):
            if self._slot_interval_ns is self._missing:
                raise AttributeError("native owner has no initialized attribute 'interval_ns'")
            return self._slot_interval_ns

        def __set__(self, value):
            self._slot_interval_ns = value

        def __del__(self):
            if self._slot_interval_ns is self._missing:
                raise AttributeError("native owner has no initialized attribute 'interval_ns'")
            self._slot_interval_ns = self._missing

    property kernel:
        def __get__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            return self._slot_kernel

        def __set__(self, value):
            self._slot_kernel = value

        def __del__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            self._slot_kernel = self._missing

    property known_asks:
        def __get__(self):
            if self._slot_known_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_asks'")
            return self._slot_known_asks

        def __set__(self, value):
            self._slot_known_asks = value

        def __del__(self):
            if self._slot_known_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_asks'")
            self._slot_known_asks = self._missing

    property known_bids:
        def __get__(self):
            if self._slot_known_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_bids'")
            return self._slot_known_bids

        def __set__(self, value):
            self._slot_known_bids = value

        def __del__(self):
            if self._slot_known_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_bids'")
            self._slot_known_bids = self._missing

    property last_trade:
        def __get__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            return self._slot_last_trade

        def __set__(self, value):
            self._slot_last_trade = value

        def __del__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            self._slot_last_trade = self._missing

    property log:
        def __get__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            return self._slot_log

        def __set__(self, value):
            self._slot_log = value

        def __del__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            self._slot_log = self._missing

    property log_events:
        def __get__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            return self._slot_log_events

        def __set__(self, value):
            self._slot_log_events = value

        def __del__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            self._slot_log_events = self._missing

    property log_orders:
        def __get__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            return self._slot_log_orders

        def __set__(self, value):
            self._slot_log_orders = value

        def __del__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            self._slot_log_orders = self._missing

    property log_to_file:
        def __get__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            return self._slot_log_to_file

        def __set__(self, value):
            self._slot_log_to_file = value

        def __del__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            self._slot_log_to_file = self._missing

    property lookback:
        def __get__(self):
            if self._slot_lookback is self._missing:
                raise AttributeError("native owner has no initialized attribute 'lookback'")
            return self._slot_lookback

        def __set__(self, value):
            self._slot_lookback = value

        def __del__(self):
            if self._slot_lookback is self._missing:
                raise AttributeError("native owner has no initialized attribute 'lookback'")
            self._slot_lookback = self._missing

    property mkt_close:
        def __get__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            return self._slot_mkt_close

        def __set__(self, value):
            self._slot_mkt_close = value

        def __del__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            self._slot_mkt_close = self._missing

    property mkt_closed:
        def __get__(self):
            if self._slot_mkt_closed is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_closed'")
            return self._slot_mkt_closed

        def __set__(self, value):
            self._slot_mkt_closed = value

        def __del__(self):
            if self._slot_mkt_closed is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_closed'")
            self._slot_mkt_closed = self._missing

    property mkt_open:
        def __get__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            return self._slot_mkt_open

        def __set__(self, value):
            self._slot_mkt_open = value

        def __del__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            self._slot_mkt_open = self._missing

    property name:
        def __get__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            return self._slot_name

        def __set__(self, value):
            self._slot_name = value

        def __del__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            self._slot_name = self._missing

    property nav_diff:
        def __get__(self):
            if self._slot_nav_diff is self._missing:
                raise AttributeError("native owner has no initialized attribute 'nav_diff'")
            return self._slot_nav_diff

        def __set__(self, value):
            self._slot_nav_diff = value

        def __del__(self):
            if self._slot_nav_diff is self._missing:
                raise AttributeError("native owner has no initialized attribute 'nav_diff'")
            self._slot_nav_diff = self._missing

    property oracle:
        def __get__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            return self._slot_oracle

        def __set__(self, value):
            self._slot_oracle = value

        def __del__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            self._slot_oracle = self._missing

    property order_size_mean:
        def __get__(self):
            if self._slot_order_size_mean is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_mean'")
            return self._slot_order_size_mean

        def __set__(self, value):
            self._slot_order_size_mean = value

        def __del__(self):
            if self._slot_order_size_mean is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_mean'")
            self._slot_order_size_mean = self._missing

    property order_size_std:
        def __get__(self):
            if self._slot_order_size_std is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_std'")
            return self._slot_order_size_std

        def __set__(self, value):
            self._slot_order_size_std = value

        def __del__(self):
            if self._slot_order_size_std is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_std'")
            self._slot_order_size_std = self._missing

    property orders:
        def __get__(self):
            if self._slot_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'orders'")
            return self._slot_orders

        def __set__(self, value):
            self._slot_orders = value

        def __del__(self):
            if self._slot_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'orders'")
            self._slot_orders = self._missing

    property price_offset_ticks:
        def __get__(self):
            if self._slot_price_offset_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price_offset_ticks'")
            return self._slot_price_offset_ticks

        def __set__(self, value):
            self._slot_price_offset_ticks = value

        def __del__(self):
            if self._slot_price_offset_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price_offset_ticks'")
            self._slot_price_offset_ticks = self._missing

    property random_state:
        def __get__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            return self._slot_random_state

        def __set__(self, value):
            self._slot_random_state = value

        def __del__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            self._slot_random_state = self._missing

    property reference_price:
        def __get__(self):
            if self._slot_reference_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reference_price'")
            return self._slot_reference_price

        def __set__(self, value):
            self._slot_reference_price = value

        def __del__(self):
            if self._slot_reference_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reference_price'")
            self._slot_reference_price = self._missing

    property sigma_n:
        def __get__(self):
            if self._slot_sigma_n is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sigma_n'")
            return self._slot_sigma_n

        def __set__(self, value):
            self._slot_sigma_n = value

        def __del__(self):
            if self._slot_sigma_n is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sigma_n'")
            self._slot_sigma_n = self._missing

    property size_per_level:
        def __get__(self):
            if self._slot_size_per_level is self._missing:
                raise AttributeError("native owner has no initialized attribute 'size_per_level'")
            return self._slot_size_per_level

        def __set__(self, value):
            self._slot_size_per_level = value

        def __del__(self):
            if self._slot_size_per_level is self._missing:
                raise AttributeError("native owner has no initialized attribute 'size_per_level'")
            self._slot_size_per_level = self._missing

    property spread_ticks:
        def __get__(self):
            if self._slot_spread_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'spread_ticks'")
            return self._slot_spread_ticks

        def __set__(self, value):
            self._slot_spread_ticks = value

        def __del__(self):
            if self._slot_spread_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'spread_ticks'")
            self._slot_spread_ticks = self._missing

    property starting_cash:
        def __get__(self):
            if self._slot_starting_cash is self._missing:
                raise AttributeError("native owner has no initialized attribute 'starting_cash'")
            return self._slot_starting_cash

        def __set__(self, value):
            self._slot_starting_cash = value

        def __del__(self):
            if self._slot_starting_cash is self._missing:
                raise AttributeError("native owner has no initialized attribute 'starting_cash'")
            self._slot_starting_cash = self._missing

    property state:
        def __get__(self):
            if self._slot_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'state'")
            return self._slot_state

        def __set__(self, value):
            self._slot_state = value

        def __del__(self):
            if self._slot_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'state'")
            self._slot_state = self._missing

    property stream_history:
        def __get__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            return self._slot_stream_history

        def __set__(self, value):
            self._slot_stream_history = value

        def __del__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            self._slot_stream_history = self._missing

    property symbol:
        def __get__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            return self._slot_symbol

        def __set__(self, value):
            self._slot_symbol = value

        def __del__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            self._slot_symbol = self._missing

    property threshold_ticks:
        def __get__(self):
            if self._slot_threshold_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'threshold_ticks'")
            return self._slot_threshold_ticks

        def __set__(self, value):
            self._slot_threshold_ticks = value

        def __del__(self):
            if self._slot_threshold_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'threshold_ticks'")
            self._slot_threshold_ticks = self._missing

    property transacted_volume:
        def __get__(self):
            if self._slot_transacted_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'transacted_volume'")
            return self._slot_transacted_volume

        def __set__(self, value):
            self._slot_transacted_volume = value

        def __del__(self):
            if self._slot_transacted_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'transacted_volume'")
            self._slot_transacted_volume = self._missing

    property type:
        def __get__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            return self._slot_type

        def __set__(self, value):
            self._slot_type = value

        def __del__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            self._slot_type = self._missing

    def request_data_subscription(self, subscription_message):
        self._require_bound()
        return self._request_data_subscription(subscription_message)

    def cancel_data_subscription(self, subscription_message):
        self._require_bound()
        return self._cancel_data_subscription(subscription_message)

    def get_last_trade(self, symbol):
        self._require_bound()
        return self._get_last_trade(symbol)

    def get_current_spread(self, symbol, depth=1):
        self._require_bound()
        return self._get_current_spread(symbol, depth)

    def get_order_stream(self, symbol, length=1):
        self._require_bound()
        return self._get_order_stream(symbol, length)

    def get_transacted_volume(self, symbol, lookback_period='10min'):
        self._require_bound()
        return self._get_transacted_volume(symbol, lookback_period)

    def create_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None):
        self._require_bound()
        cdef uint64_t handle=self._create_limit_order(symbol, quantity, side, limit_price, order_id, is_hidden, is_price_to_comply, insert_by_id, is_post_only, ignore_risk, tag)
        return None if handle==0 else int(handle)

    def place_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None):
        self._require_bound()
        return self._place_limit_order(symbol, quantity, side, limit_price, order_id, is_hidden, is_price_to_comply, insert_by_id, is_post_only, ignore_risk, tag)

    def place_market_order(self, symbol, quantity, side, order_id=None, ignore_risk=True, tag=None):
        self._require_bound()
        return self._place_market_order(symbol, quantity, side, order_id, ignore_risk, tag)

    def place_multiple_orders(self, orders):
        self._require_bound()
        return self._place_multiple_orders(orders)

    def cancel_order(self, order, tag=DEFAULT_CANCEL_TAG, metadata=DEFAULT_CANCEL_METADATA):
        self._require_bound()
        return self._cancel_order(self._orders._checked_handle(order), tag, metadata)

    def cancel_all_orders(self):
        self._require_bound()
        return self._cancel_all_orders()

    def partial_cancel_order(self, order, quantity, tag=DEFAULT_PARTIAL_CANCEL_TAG, metadata=DEFAULT_PARTIAL_CANCEL_METADATA):
        self._require_bound()
        return self._partial_cancel_order(order, quantity, tag, metadata)

    def modify_order(self, order, new_order):
        self._require_bound()
        return self._modify_order(order, new_order)

    def replace_order(self, order, new_order):
        self._require_bound()
        return self._replace_order(order, new_order)

    def order_executed(self, order):
        self._require_bound()
        return self._order_executed(self._orders._checked_handle(order))

    def order_accepted(self, order):
        self._require_bound()
        return self._order_accepted(self._orders._checked_handle(order))

    def order_cancelled(self, order):
        self._require_bound()
        return self._order_cancelled(self._orders._checked_handle(order))

    def order_partial_cancelled(self, order):
        self._require_bound()
        return self._order_partial_cancelled(order)

    def order_modified(self, order):
        self._require_bound()
        return self._order_modified(order)

    def order_replaced(self, old_order, new_order):
        self._require_bound()
        return self._order_replaced(old_order, new_order)

    def market_closed(self):
        self._require_bound()
        return self._market_closed()

    def query_last_trade(self, symbol, price):
        self._require_bound()
        return self._query_last_trade(symbol, price)

    def query_spread(self, symbol, price, bids, asks, book):
        self._require_bound()
        return self._query_spread(symbol, price, bids, asks, book)

    def handle_market_data(self, message):
        self._require_bound()
        return self._handle_market_data(message)

    def query_order_stream(self, symbol, orders):
        self._require_bound()
        return self._query_order_stream(symbol, orders)

    def query_transacted_volume(self, symbol, bid_volume, ask_volume):
        self._require_bound()
        return self._query_transacted_volume(symbol, bid_volume, ask_volume)

    def get_known_bid_ask(self, symbol, best=True):
        self._require_bound()
        return self._get_known_bid_ask(symbol, best)

    def get_known_liquidity(self, symbol, within=0.0):
        self._require_bound()
        return self._get_known_liquidity(symbol, within)

    def get_book_liquidity(self, book, within):
        self._require_bound()
        return self._get_book_liquidity(book, within)

    def mark_to_market(self, holdings, use_midpoint=False):
        self._require_bound()
        return self._mark_to_market(holdings, use_midpoint)

    def get_holdings(self, symbol):
        self._require_bound()
        return self._get_holdings(symbol)

    def get_known_bid_ask_midpoint(self, symbol):
        self._require_bound()
        return self._get_known_bid_ask_midpoint(symbol)

    def get_average_transaction_price(self):
        self._require_bound()
        return self._get_average_transaction_price()

    def fmt_holdings(self, holdings):
        self._require_bound()
        return self._fmt_holdings(holdings)

    def logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        self._require_bound()
        return self._logEvent(event_type, event, append_summary_log, deepcopy_event)

    def send_message(self, recipient_id, message, delay=0):
        self._require_bound()
        return self._send_message(recipient_id, message, delay)

    def send_message_batch(self, recipient_id, messages, delay=0):
        self._require_bound()
        return self._send_message_batch(recipient_id, messages, delay)

    def set_wakeup(self, requested_time):
        self._require_bound()
        return self._set_wakeup(requested_time)

    def get_computation_delay(self):
        self._require_bound()
        return self._get_computation_delay()

    def set_computation_delay(self, requested_delay):
        self._require_bound()
        return self._set_computation_delay(requested_delay)

    def delay(self, additional_delay):
        self._require_bound()
        return self._delay(additional_delay)

    def write_log(self, df_log, filename=None):
        self._require_bound()
        return self._write_log(df_log, filename)

    def update_agent_state(self, state):
        self._require_bound()
        return self._update_agent_state(state)

    def dollarize(self, cents):
        self._require_bound()
        return self._dollarize(cents)

    def get_wake_frequency(self):
        self._require_bound()
        return self._get_wake_frequency()

    cdef object _base_wakeup(self, current_time):
        '\n        Agents can request a wakeup call at a future simulation time using\n        ``Agent.set_wakeup()``.\n\n        This is the method called when the wakeup time arrives.\n\n        Arguments:\n            current_time: The simulation time at which the kernel is delivering this\n                message -- the agent should treat this as "now".\n        '
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received wakeup.'.format(fmt_ts(current_time), self._slot_id, self._slot_name))

    cdef object _base_receive_message(self, current_time, sender_id, message):
        '\n        Called each time a message destined for this agent reaches the front of the\n        kernel\'s priority queue.\n\n        Arguments:\n            current_time: The simulation time at which the kernel is delivering this\n                message -- the agent should treat this as "now".\n            sender_id: The ID of the agent who sent the message.\n            message: An object guaranteed to inherit from the message.Message class.\n        '
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received: {}'.format(fmt_ts(current_time), self._slot_id, self._slot_name, message))

    cdef object _base_kernel_stopping(self):
        '\n        Called by the kernel one time before simulationTerminating.\n\n        All other agents are guaranteed to exist at this time.\n        '
        pass

    cdef object _kernel_terminating(self):
        '\n        Called by the kernel one time when simulation terminates.\n\n        No other agents are guaranteed to exist at this time.\n        '
        if _observer.skip_termination(self):
            return
        if self._slot_log and self._slot_log_to_file:
            df_log = pd.DataFrame(self._slot_log, columns=('EventTime', 'EventType', 'Event'))
            df_log.set_index('EventTime', inplace=True)
            self._write_log(df_log, None)

    cdef object _logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        "\n        Adds an event to this agent's log.\n\n        The deepcopy of the Event field, often an object, ensures later state\n        changes to the object will not retroactively update the logged event.\n\n        Arguments:\n            event_type: label of the event (e.g., Order submitted, order accepted last trade etc....)\n            event: actual event to be logged\n            append_summary_log:\n            deepcopy_event: Set to False to skip deepcopying the event object.\n        "
        if _observe_log(self,event_type,event,append_summary_log,deepcopy_event):
            return
        if not self._slot_log_events:
            return
        if deepcopy_event:
            if type(event) is dict and _primitive_event(event):
                event = event.copy()
            else:
                event = deepcopy(event)
        self._slot_log.append((self._slot_current_time, event_type, event))
        if append_summary_log:
            assert self._slot_kernel is not None
            self._slot_kernel.append_summary_log(self._slot_id, event_type, event)

    cdef object _send_message(self, recipient_id, message, delay=0):
        assert self._slot_kernel is not None
        try:
            return self._scheduler._send(self._slot_id, recipient_id, message, delay)
        finally:
            self._messages._release(message)

    cdef object _send_message_batch(self, recipient_id, messages, delay=0):
        raise ValueError("unsupported method escaped whole-input arena admission: _send_message_batch")

    cdef object _set_wakeup(self, requested_time):
        '\n        Called to receive a "wakeup call" from the kernel at some requested future time.\n\n        Arguments:\n            requested_time: Defaults to the next possible timestamp. Wakeup time cannot\n                be the current time or a past time.\n        '
        assert self._slot_kernel is not None
        self._scheduler._set_wakeup(self._slot_id, requested_time)

    cdef object _get_computation_delay(self):
        "Queries thr agent's current computation delay from the kernel."
        return self._slot_kernel.get_agent_compute_delay(sender_id=self._slot_id)

    cdef object _set_computation_delay(self, requested_delay):
        '\n        Calls the kernel to update the agent\'s computation delay.\n\n        This does not initiate a global delay, nor an immediate delay for the agent.\n        Rather it sets the new default delay for the calling agent. The delay will be\n        applied upon every return from wakeup or recvMsg.\n\n        Note that this delay IS applied to any messages sent by the agent during the\n        current wake cycle (simulating the messages popping out at the end of its\n        "thinking" time).\n\n        Also note that we DO permit a computation delay of zero, but this should really\n        only be used for special or massively parallel agents.\n\n        Arguments:\n            requested_delay: delay given in nanoseconds.\n        '
        assert self._slot_kernel is not None
        self._slot_kernel.set_agent_compute_delay(sender_id=self._slot_id, requested_delay=requested_delay)

    cdef object _delay(self, additional_delay):
        "\n        Accumulates a temporary delay for the current wake cycle for this agent.\n\n        This will apply the total delay (at time of send_message) to each message, and\n        will modify the agent's next available time slot.  These happen on top of the\n        agent's compute delay BUT DO NOT ALTER IT.  (i.e. effects are transient). Mostly\n        useful for staggering outbound messages.\n\n        Arguments:\n            additional_delay: additional delay given in nanoseconds.\n        "
        assert self._slot_kernel is not None
        self._slot_kernel.delay_agent(sender_id=self._slot_id, additional_delay=additional_delay)

    cdef object _write_log(self, df_log, filename=None):
        '\n        Called by the agent, usually at the very end of the simulation just before\n        kernel shutdown, to write to disk any log dataframe it has been accumulating\n        during simulation.\n\n        The format can be decided by the agent, although changes will require a special\n        tool to read and parse the logs.  The Kernel places the log in a unique\n        directory per run, with one filename per agent, also decided by the Kernel using\n        agent type, id, etc.\n\n        If filename is None the Kernel will construct a filename based on the name of\n        the Agent requesting log archival.\n\n        Arguments:\n            df_log: dataframe that contains all the logged events during the simulation\n            filename: Location on disk to write the log to.\n        '
        assert self._slot_kernel is not None
        self._slot_kernel.write_log(self._slot_id, df_log, filename)

    cdef object _update_agent_state(self, state):
        '\n        Agents should use this method to replace their custom state in the dictionary\n        the Kernel will return to the experimental config file at the end of the\n        simulation.\n\n        This is intended to be write-only, and agents should not use it to store\n        information for their own later use.\n\n        Arguments:\n            state: The new state.\n        '
        assert self._slot_kernel is not None
        self._slot_kernel.update_agent_state(self._slot_id, state)

    cdef object _dollarize(self, cents):
        '\n        Used by any subclass to dollarize an int-cents price for printing.\n        '
        return dollarize(cents)

    cdef object _trading_wakeup(self, current_time):

        """
            Arguments:
                current_time: The time that this agent was woken up by the kernel.
    
            Returns:
                For the sake of subclasses, TradingAgent now returns a boolean
                indicating whether the agent is "ready to trade" -- has it received
                the market open and closed times, and is the market not already closed.
            """
        self._base_wakeup(current_time)
        if self._slot_first_wake:
            self._logEvent('HOLDINGS_UPDATED', self._slot_holdings, False, True)
            self._slot_first_wake = False
            self._send_message(self._slot_exchange_id, self._messages._new_u(2, 0, None, None, None, None, None, None, None), 0)
        if self._slot_mkt_open is None:
            self._send_message(self._slot_exchange_id, self._messages._new_u(3, 0, None, None, None, None, None, None, None), 0)
        return (self._slot_mkt_open and self._slot_mkt_close) and (not self._slot_mkt_closed)

    cdef object _trading_receive_message(self, current_time, sender_id, message):

        """
            Arguments:
                current_time: The time that this agent received the message.
                sender_id: The ID of the agent who sent the message.
                message: The message contents.
            """
        assert self._slot_kernel is not None
        self._base_receive_message(current_time, sender_id, message)
        had_mkt_hours = self._slot_mkt_open is not None and self._slot_mkt_close is not None
        if self._messages._kind(message) in (4,):
            self._slot_mkt_open = self._messages._get(message, 1)
            self._slot_mkt_close = self._messages._get(message, 2)
            if trading_logger.isEnabledFor(10):
                trading_logger.debug('Recorded market open: {}'.format(fmt_ts(self._slot_mkt_open)))
            if trading_logger.isEnabledFor(10):
                trading_logger.debug('Recorded market close: {}'.format(fmt_ts(self._slot_mkt_close)))
        elif self._messages._kind(message) in (12,):
            for (symbol, close_price) in self._messages._get(message, 1).items():
                self._slot_last_trade[symbol] = close_price
        elif self._messages._kind(message) in (13,):
            self._market_closed()
        elif self._messages._kind(message) in (9,):
            self._order_executed(self._messages._order_u(message))
        elif self._messages._kind(message) in (8,):
            self._order_accepted(self._messages._order_u(message))
        elif self._messages._kind(message) in (11,):
            self._order_cancelled(self._messages._order_u(message))
        elif self._messages._kind(message) in (6,):
            if self._messages._get(message, 2):
                self._slot_mkt_closed = True
            self._query_spread(self._messages._get(message, 1), self._messages._get(message, 6), self._messages._get(message, 4), self._messages._get(message, 5), '')
        have_mkt_hours = self._slot_mkt_open is not None and self._slot_mkt_close is not None
        if have_mkt_hours and (not had_mkt_hours):
            ns_offset = self._get_wake_frequency()
            self._set_wakeup(self._slot_mkt_open + ns_offset)

    cdef object _kernel_stopping(self):
        self._base_kernel_stopping()
        assert self._slot_kernel is not None
        self._logEvent('FINAL_HOLDINGS', self._fmt_holdings(self._slot_holdings), False, False)
        self._logEvent('FINAL_CASH_POSITION', self._slot_holdings['CASH'], True, True)
        cash = self._mark_to_market(self._slot_holdings, False)
        self._logEvent('ENDING_CASH', cash, True, True)
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Final holdings for {}: {}. Marked to market: {}'.format(self._slot_name, self._fmt_holdings(self._slot_holdings), cash))
        mytype = self._slot_type
        gain = cash - self._slot_starting_cash
        if mytype in self._slot_kernel.mean_result_by_agent_type:
            self._slot_kernel.mean_result_by_agent_type[mytype] += gain
            self._slot_kernel.agent_count_by_type[mytype] += 1
        else:
            self._slot_kernel.mean_result_by_agent_type[mytype] = gain
            self._slot_kernel.agent_count_by_type[mytype] = 1

    cdef object _wakeup(self, current_time):
        self._trading_wakeup(current_time)
        if not self._slot_mkt_open or not self._slot_mkt_close or self._slot_mkt_closed:
            return
        self._set_wakeup(current_time + self._slot_interval_ns)
        self._get_current_spread(self._slot_symbol, 1)
        self._slot_state = 'AWAITING_SPREAD'

    cdef object _receive_message(self, current_time, sender_id, message):

        self._trading_receive_message(current_time, sender_id, message)
        if self._slot_state == 'AWAITING_SPREAD' and self._messages._kind(message) in (6,):
            if not self._slot_mkt_closed:
                self._act()
            self._slot_state = 'AWAITING_WAKEUP'

    cdef object _request_data_subscription(self, subscription_message):
        raise ValueError("unsupported method escaped whole-input arena admission: _request_data_subscription")

    cdef object _cancel_data_subscription(self, subscription_message):
        raise ValueError("unsupported method escaped whole-input arena admission: _cancel_data_subscription")

    cdef object _get_last_trade(self, symbol):
        raise ValueError("unsupported method escaped whole-input arena admission: _get_last_trade")

    cdef object _get_current_spread(self, symbol, depth=1):

        """
            Used by any Trading Agent subclass to query the current spread for a symbol.
    
            This activity is not logged.
    
            Arguments:
                symbol: The symbol to query.
                depth:
            """
        self._send_message(self._slot_exchange_id, self._messages._new_u(5, 0, symbol, depth, None, None, None, None, None), 0)

    cdef object _get_order_stream(self, symbol, length=1):
        raise ValueError("unsupported method escaped whole-input arena admission: _get_order_stream")

    cdef object _get_transacted_volume(self, symbol, lookback_period='10min'):
        raise ValueError("unsupported method escaped whole-input arena admission: _get_transacted_volume")

    cdef uint64_t _create_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None) except? 0:
        cdef uint64_t order

        """
            Used by any Trading Agent subclass to create a limit order.
    
            Arguments:
                symbol: A valid symbol.
                quantity: Positive share quantity.
                side: Side.BID or Side.ASK.
                limit_price: Price in cents.
                order_id: An optional order id (otherwise global autoincrement is used).
                is_hidden:
                is_price_to_comply:
                insert_by_id:
                is_post_only:
                ignore_risk: Whether cash or risk limits should be enforced or ignored for
                    the order.
                tag:
            """
        if is_hidden or is_price_to_comply or insert_by_id or is_post_only or tag is not None:
            raise ValueError("unsupported order flags escaped whole-input admission")
        order = self._orders._new_limit_u(self._slot_id, self._slot_current_time, symbol, quantity, side, limit_price, order_id, is_hidden, is_price_to_comply, insert_by_id, is_post_only, tag)
        if quantity > 0:
            new_holdings = self._slot_holdings.copy()
            q = self._orders._get_u(order, 3) if self._orders._get_u(order, 4).is_bid() else -self._orders._get_u(order, 3)
            if self._orders._get_u(order, 2) in new_holdings:
                new_holdings[self._orders._get_u(order, 2)] += q
            else:
                new_holdings[self._orders._get_u(order, 2)] = q
            if not ignore_risk:
                at_risk = self._mark_to_market(self._slot_holdings, False) - self._slot_holdings['CASH']
                new_at_risk = self._mark_to_market(new_holdings, False) - new_holdings['CASH']
                if new_at_risk > at_risk and new_at_risk > self._slot_starting_cash:
                    if trading_logger.isEnabledFor(10):
                        trading_logger.debug('TradingAgent ignored limit order due to at-risk constraints: {}\n{}'.format(order, self._fmt_holdings(self._slot_holdings)))
                    self._orders._release_u(order)
                    return 0
            return order
        else:
            warnings.warn(f'TradingAgent ignored limit order of quantity zero: {self._orders._format_u(order)}')
            self._orders._release_u(order)
            return 0

    cdef object _place_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None):
        cdef uint64_t order, cache, previous
        order=self._create_limit_order(symbol,quantity,side,limit_price,order_id,is_hidden,is_price_to_comply,insert_by_id,is_post_only,ignore_risk,tag)
        if order==0:return
        try:
            key=self._orders._get_u(order,5)
            previous=self._slot_orders.get(key,0)
            cache=self._orders._clone_u(order)
            try:self._slot_orders[key]=cache
            except BaseException:
                self._orders._release_u(cache)
                raise
            if previous:self._orders._release_u(previous)
            self._send_message(self._slot_exchange_id,self._messages._new_u(7,order,None,None,None,None,None,None,None),0)
            if self._slot_log_orders:
                _observe_order(self,'ORDER_SUBMITTED',self._orders,order)
        finally:
            self._orders._release_u(order)

    cdef object _place_market_order(self, symbol, quantity, side, order_id=None, ignore_risk=True, tag=None):
        raise ValueError("unsupported method escaped whole-input arena admission: _place_market_order")

    cdef object _place_multiple_orders(self, orders):
        raise ValueError("unsupported method escaped whole-input arena admission: _place_multiple_orders")

    cdef object _cancel_order(self, uint64_t order, tag=DEFAULT_CANCEL_TAG, metadata=DEFAULT_CANCEL_METADATA):

        """
            Used by derived classes of TradingAgent to cancel a limit order.
    
            The order must currently appear in the agent's open orders list.
    
            Arguments:
                order: The limit order to cancel.
                tag:
                metadata:
            """
        if True:
            self._send_message(self._slot_exchange_id, self._messages._new_u(10, order, tag, metadata, None, None, None, None, None), 0)
            if self._slot_log_orders:
                _observe_order(self, 'CANCEL_SUBMITTED', self._orders, order)
        else:
            warnings.warn(f'Order {order} of type, {type(order)} cannot be cancelled')

    cdef object _cancel_all_orders(self):
        cdef uint64_t order

        """
            Cancels all current limit orders held by this agent.
            """
        for order in self._slot_orders.values():
            if True:
                self._cancel_order(order, DEFAULT_CANCEL_TAG, DEFAULT_CANCEL_METADATA)

    cdef object _partial_cancel_order(self, order, quantity, tag=DEFAULT_PARTIAL_CANCEL_TAG, metadata=DEFAULT_PARTIAL_CANCEL_METADATA):
        raise ValueError("unsupported method escaped whole-input arena admission: _partial_cancel_order")

    cdef object _modify_order(self, order, new_order):
        raise ValueError("unsupported method escaped whole-input arena admission: _modify_order")

    cdef object _replace_order(self, order, new_order):
        raise ValueError("unsupported method escaped whole-input arena admission: _replace_order")

    cdef object _order_executed(self, uint64_t order):
        cdef uint64_t o

        """
            Handles OrderExecuted messages from an exchange agent.
    
            Subclasses may wish to extend, but should still call parent method for basic
            portfolio/returns tracking.
    
            Arguments:
                order: The order that has been executed by the exchange.
            """
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of execution for: {order}')
        if self._slot_log_orders:
            _observe_order(self, 'ORDER_EXECUTED', self._orders, order)
        qty = self._orders._get_u(order, 3) if self._orders._get_u(order, 4).is_bid() else -1 * self._orders._get_u(order, 3)
        sym = self._orders._get_u(order, 2)
        if sym in self._slot_holdings:
            self._slot_holdings[sym] += qty
        else:
            self._slot_holdings[sym] = qty
        if self._slot_holdings[sym] == 0:
            del self._slot_holdings[sym]
        self._slot_holdings['CASH'] -= qty * self._orders._get_u(order, 6)
        if self._orders._get_u(order, 5) in self._slot_orders:
            o = self._slot_orders[self._orders._get_u(order, 5)]
            if self._orders._get_u(order, 3) >= self._orders._get_u(o, 3):
                del self._slot_orders[self._orders._get_u(order, 5)]
                self._orders._release_u(o)
            else:
                self._orders._set_u(o, 3, self._orders._get_u(o, 3) - self._orders._get_u(order, 3))
        else:
            warnings.warn(f'Execution received for order not in orders list: {self._orders._format_u(order)}')
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'After order execution, agent open orders: {self._slot_orders}')
        self._logEvent('HOLDINGS_UPDATED', self._slot_holdings, False, True)

    cdef object _order_accepted(self, uint64_t order):

        """
            Handles OrderAccepted messages from an exchange agent.
    
            Subclasses may wish to extend.
    
            Arguments:
                order: The order that has been accepted from the exchange.
            """
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of acceptance for: {order}')
        if self._slot_log_orders:
            _observe_order(self, 'ORDER_ACCEPTED', self._orders, order)

    cdef object _order_cancelled(self, uint64_t order):
        cdef uint64_t cached

        """
            Handles OrderCancelled messages from an exchange agent.
    
            Subclasses may wish to extend.
    
            Arguments:
                order: The order that has been cancelled by the exchange.
            """
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of cancellation for: {order}')
        if self._slot_log_orders:
            _observe_order(self, 'ORDER_CANCELLED', self._orders, order)
        if self._orders._get_u(order, 5) in self._slot_orders:
            cached=self._slot_orders.pop(self._orders._get_u(order,5))
            self._orders._release_u(cached)
        else:
            warnings.warn(f'Cancellation received for order not in orders list: {self._orders._format_u(order)}')

    cdef object _order_partial_cancelled(self, order):
        raise ValueError("unsupported method escaped whole-input arena admission: _order_partial_cancelled")

    cdef object _order_modified(self, order):
        raise ValueError("unsupported method escaped whole-input arena admission: _order_modified")

    cdef object _order_replaced(self, old_order, new_order):
        raise ValueError("unsupported method escaped whole-input arena admission: _order_replaced")

    cdef object _market_closed(self):
        '\n        Handles MarketClosedMsg messages from an exchange agent.\n\n        Subclasses may wish to extend.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Received notification of market closure.')
        self._logEvent('MKT_CLOSED', '', False, True)
        self._slot_mkt_closed = True

    cdef object _query_last_trade(self, symbol, price):
        '\n        Handles QueryLastTradeResponseMsg messages from an exchange agent.\n\n        Arguments:\n            symbol: The symbol that was queried.\n            price: The price at which the last trade executed at.\n        '
        self._slot_last_trade[symbol] = price
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Received last trade price of {} for {}.'.format(self._slot_last_trade[symbol], symbol))
        if self._slot_mkt_closed:
            self._slot_daily_close_price[symbol] = self._slot_last_trade[symbol]
            if trading_logger.isEnabledFor(10):
                trading_logger.debug('Received daily close price of {} for {}.'.format(self._slot_last_trade[symbol], symbol))

    cdef object _query_spread(self, symbol, price, bids, asks, book):
        '\n        Handles QuerySpreadResponseMsg messages from an exchange agent.\n\n        Arguments:\n            symbol: The symbol that was queried.\n            price:\n            bids:\n            asks:\n            book:\n        '
        self._query_last_trade(symbol, price)
        self._slot_known_bids[symbol] = bids
        self._slot_known_asks[symbol] = asks
        if bids:
            (best_bid, best_bid_qty) = (bids[0][0], bids[0][1])
        else:
            (best_bid, best_bid_qty) = ('No bids', 0)
        if asks:
            (best_ask, best_ask_qty) = (asks[0][0], asks[0][1])
        else:
            (best_ask, best_ask_qty) = ('No asks', 0)
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Received spread of {} @ {} / {} @ {} for {}'.format(best_bid_qty, best_bid, best_ask_qty, best_ask, symbol))
        _observe_diagnostic(self, 'BID_DEPTH', bids)
        _observe_diagnostic(self, 'ASK_DEPTH', asks)
        _observe_diagnostic(self,'IMBALANCE',None)
        self._slot_book = book

    cdef object _handle_market_data(self, message):
        raise ValueError("unsupported method escaped whole-input arena admission: _handle_market_data")

    cdef object _query_order_stream(self, symbol, orders):
        raise ValueError("unsupported method escaped whole-input arena admission: _query_order_stream")

    cdef object _query_transacted_volume(self, symbol, bid_volume, ask_volume):
        raise ValueError("unsupported method escaped whole-input arena admission: _query_transacted_volume")

    cdef object _get_known_bid_ask(self, symbol, best=True):
        '\n        Extract the current known bid and asks.\n\n        This does NOT request new information.\n\n        Arguments:\n            symbol: The symbol to query.\n            best:\n        '
        if best:
            bid = self._slot_known_bids[symbol][0][0] if self._slot_known_bids[symbol] else None
            ask = self._slot_known_asks[symbol][0][0] if self._slot_known_asks[symbol] else None
            bid_vol = self._slot_known_bids[symbol][0][1] if self._slot_known_bids[symbol] else 0
            ask_vol = self._slot_known_asks[symbol][0][1] if self._slot_known_asks[symbol] else 0
            return (bid, bid_vol, ask, ask_vol)
        else:
            bids = self._slot_known_bids[symbol] if self._slot_known_bids[symbol] else None
            asks = self._slot_known_asks[symbol] if self._slot_known_asks[symbol] else None
            return (bids, asks)

    cdef object _get_known_liquidity(self, symbol, within=0.0):
        '\n        Extract the current bid and ask liquidity within a certain proportion of the\n        inside bid and ask.  (i.e. within=0.01 means to report total BID shares\n        within 1% of the best bid price, and total ASK shares within 1% of the best\n        ask price)\n\n        Arguments:\n            symbol: The symbol to query.\n            within:\n\n        Returns:\n            (bid_liquidity, ask_liquidity).  Note that this is from the order book\n            perspective, not the agent perspective.  (The agent would be selling into\n            the bid liquidity, etc.)\n        '
        bid_liq = self._get_book_liquidity(self._slot_known_bids[symbol], within)
        ask_liq = self._get_book_liquidity(self._slot_known_asks[symbol], within)
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Bid/ask liq: {}, {}'.format(bid_liq, ask_liq))
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Known bids: {}'.format(self._slot_known_bids[self._slot_symbol]))
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Known asks: {}'.format(self._slot_known_asks[self._slot_symbol]))
        return (bid_liq, ask_liq)

    cdef object _get_book_liquidity(self, book, within):
        '\n        Helper function for the above.  Checks one side of the known order book.\n\n        Arguments:\n            book:\n            within:\n        '
        liq = 0
        for (i, (price, shares)) in enumerate(book):
            if i == 0:
                best = price
            if abs(best - price) <= int(round(best * within)):
                if trading_logger.isEnabledFor(10):
                    trading_logger.debug('Within {} of {}: {} with {} shares'.format(within, best, price, shares))
                liq += shares
        return liq

    cdef object _mark_to_market(self, holdings, use_midpoint=False):
        '\n        Marks holdings to market (including cash).\n\n        Arguments:\n            holdings:\n            use_midpoint:\n        '
        cash = holdings['CASH']
        cash += self._slot_basket_size * self._slot_nav_diff
        for (symbol, shares) in holdings.items():
            if symbol == 'CASH':
                continue
            if use_midpoint:
                (bid, ask, midpoint) = self._get_known_bid_ask_midpoint(symbol)
                if bid is None or ask is None or midpoint is None:
                    value = self._slot_last_trade[symbol] * shares
                else:
                    value = midpoint * shares
            else:
                value = self._slot_last_trade[symbol] * shares
            cash += value
            self._logEvent('MARK_TO_MARKET', '{} {} @ {} == {}'.format(shares, symbol, self._slot_last_trade[symbol], value), False, True)
        self._logEvent('MARKED_TO_MARKET', cash, False, True)
        return cash

    cdef object _get_holdings(self, symbol):
        '\n        Gets holdings.  Returns zero for any symbol not held.\n\n        Arguments:\n            symbol: The symbol to query.\n        '
        return self._slot_holdings[symbol] if symbol in self._slot_holdings else 0

    cdef object _get_known_bid_ask_midpoint(self, symbol):
        '\n        Get the known best bid, ask, and bid/ask midpoint from cached data. No volume.\n\n        Arguments:\n            symbol: The symbol to query.\n        '
        bid = self._slot_known_bids[symbol][0][0] if self._slot_known_bids[symbol] else None
        ask = self._slot_known_asks[symbol][0][0] if self._slot_known_asks[symbol] else None
        midpoint = int(round((bid + ask) / 2)) if bid is not None and ask is not None else None
        return (bid, ask, midpoint)

    cdef object _get_average_transaction_price(self):
        'Calculates the average price paid (weighted by the order size).'
        return _average_transaction_price(self._slot_executed_orders)

    cdef object _fmt_holdings(self, holdings):
        '\n        Prints holdings.\n\n        Standard dictionary->string representation is almost fine, but it is less\n        confusing to see the CASH holdings in dollars and cents, instead of just integer\n        cents.  We could change to a Holdings object that knows to print CASH "special".\n\n        Arguments:\n            holdings:\n        '
        h = ''
        for (k, v) in sorted(holdings.items()):
            if k == 'CASH':
                continue
            h += '{}: {}, '.format(k, v)
        h += '{}: {}'.format('CASH', holdings['CASH'])
        h = '{ ' + h + ' }'
        return h

    cdef object _get_wake_frequency(self):
        'Offset (ns) for the parent-scheduled first wakeup; 0 = at market open.'
        return 0

    cdef object _act_NoiseTrader(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        size = int(max(1, round(self._slot_random_state.normal(self._slot_order_size_mean, self._slot_order_size_std))))
        buy = bool(self._slot_random_state.randint(0, 2))
        offset = int(self._slot_random_state.randint(0, self._slot_price_offset_ticks + 1))
        if buy:
            anchor = int(ask) if ask else int(bid) if bid else self._slot_reference_price
            self._place_limit_order(self._slot_symbol, size, Side.BID, anchor + offset, None, False, False, False, False, True, None)
        else:
            anchor = int(bid) if bid else int(ask) if ask else self._slot_reference_price
            self._place_limit_order(self._slot_symbol, size, Side.ASK, anchor - offset, None, False, False, False, False, True, None)

    cdef object _act_MarketMaker(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        mid = int((bid + ask) // 2) if bid and ask else self._slot_reference_price
        self._cancel_all_orders()
        half = self._slot_spread_ticks // 2
        for lvl in range(self._slot_depth_levels):
            self._place_limit_order(self._slot_symbol, self._slot_size_per_level, Side.BID, mid - half - lvl, None, False, False, False, False, True, None)
            self._place_limit_order(self._slot_symbol, self._slot_size_per_level, Side.ASK, mid + half + lvl, None, False, False, False, False, True, None)

    cdef object _act_ValueTrader(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        if bid and ask:
            mid = (int(bid) + int(ask)) / 2.0
        elif bid:
            mid = float(bid)
        elif ask:
            mid = float(ask)
        else:
            return
        fundamental = int(self._slot_oracle.observe_price(self._slot_symbol, self._slot_current_time, self._slot_random_state, sigma_n=self._slot_sigma_n))
        size = int(max(1, round(self._slot_order_size_mean)))
        if mid < fundamental - self._slot_threshold_ticks and ask:
            self._place_limit_order(self._slot_symbol, size, Side.BID, int(ask), None, False, False, False, False, True, None)
        elif mid > fundamental + self._slot_threshold_ticks and bid:
            self._place_limit_order(self._slot_symbol, size, Side.ASK, int(bid), None, False, False, False, False, True, None)

    cdef object _act_MomentumTrader(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        if bid and ask:
            mid = (int(bid) + int(ask)) / 2.0
        elif bid:
            mid = float(bid)
        elif ask:
            mid = float(ask)
        else:
            return
        self._slot__mid_history.append(mid)
        if len(self._slot__mid_history) > self._slot_lookback + 1:
            self._slot__mid_history.pop(0)
        if len(self._slot__mid_history) <= self._slot_lookback:
            return
        past = self._slot__mid_history[0]
        size = int(max(1, round(self._slot_order_size_mean)))
        if mid > past + self._slot_threshold_ticks and ask:
            self._place_limit_order(self._slot_symbol, size, Side.BID, int(ask), None, False, False, False, False, True, None)
        elif mid < past - self._slot_threshold_ticks and bid:
            self._place_limit_order(self._slot_symbol, size, Side.ASK, int(bid), None, False, False, False, False, True, None)

EXCHANGE_FIELDS = ('book_log_depth', 'book_logging', 'computation_delay', 'current_time', 'data_subscriptions', 'id', 'kernel', 'log', 'log_events', 'log_orders', 'log_to_file', 'market_close_price_subscriptions', 'metric_trackers', 'mkt_close', 'mkt_open', 'name', 'oracle', 'order_books', 'pipeline_delay', 'random_state', 'reschedule', 'stp_policy', 'stream_history', 'symbols', 'total_exchanged_volume', 'type')

cdef class NativeExchange:
    def __cinit__(self):
        self._prepared = False
        self._bound = False

    def __init__(self, source):
        if self._prepared or type(source) is not ExchangeAgent:
            raise ValueError("one-shot exact original exchange required")
        self._prepared = True
        self._missing = _MISSING
        self._source = source
        self._scheduler = None
        values = source.__dict__
        if type(values) is not dict or set(values) - set(EXCHANGE_FIELDS):
            raise ValueError("exchange initialized field domain differs")
        self._slot_book_log_depth = _MISSING
        self._slot_book_logging = _MISSING
        self._slot_computation_delay = _MISSING
        self._slot_current_time = _MISSING
        self._slot_data_subscriptions = _MISSING
        self._slot_id = _MISSING
        self._slot_kernel = _MISSING
        self._slot_log = _MISSING
        self._slot_log_events = _MISSING
        self._slot_log_orders = _MISSING
        self._slot_log_to_file = _MISSING
        self._slot_market_close_price_subscriptions = _MISSING
        self._slot_metric_trackers = _MISSING
        self._slot_mkt_close = _MISSING
        self._slot_mkt_open = _MISSING
        self._slot_name = _MISSING
        self._slot_oracle = _MISSING
        self._slot_order_books = _MISSING
        self._slot_pipeline_delay = _MISSING
        self._slot_random_state = _MISSING
        self._slot_reschedule = _MISSING
        self._slot_stp_policy = _MISSING
        self._slot_stream_history = _MISSING
        self._slot_symbols = _MISSING
        self._slot_total_exchanged_volume = _MISSING
        self._slot_type = _MISSING
        if 'book_log_depth' in values:
            self._slot_book_log_depth = values['book_log_depth']
        if 'book_logging' in values:
            self._slot_book_logging = values['book_logging']
        if 'computation_delay' in values:
            self._slot_computation_delay = values['computation_delay']
        if 'current_time' in values:
            self._slot_current_time = values['current_time']
        if 'data_subscriptions' in values:
            self._slot_data_subscriptions = values['data_subscriptions']
        if 'id' in values:
            self._slot_id = values['id']
        if 'kernel' in values:
            self._slot_kernel = values['kernel']
        if 'log' in values:
            self._slot_log = values['log']
        if 'log_events' in values:
            self._slot_log_events = values['log_events']
        if 'log_orders' in values:
            self._slot_log_orders = values['log_orders']
        if 'log_to_file' in values:
            self._slot_log_to_file = values['log_to_file']
        if 'market_close_price_subscriptions' in values:
            self._slot_market_close_price_subscriptions = values['market_close_price_subscriptions']
        if 'metric_trackers' in values:
            self._slot_metric_trackers = values['metric_trackers']
        if 'mkt_close' in values:
            self._slot_mkt_close = values['mkt_close']
        if 'mkt_open' in values:
            self._slot_mkt_open = values['mkt_open']
        if 'name' in values:
            self._slot_name = values['name']
        if 'oracle' in values:
            self._slot_oracle = values['oracle']
        if 'order_books' in values:
            self._slot_order_books = values['order_books']
        if 'pipeline_delay' in values:
            self._slot_pipeline_delay = values['pipeline_delay']
        if 'random_state' in values:
            self._slot_random_state = values['random_state']
        if 'reschedule' in values:
            self._slot_reschedule = values['reschedule']
        if 'stp_policy' in values:
            self._slot_stp_policy = values['stp_policy']
        if 'stream_history' in values:
            self._slot_stream_history = values['stream_history']
        if 'symbols' in values:
            self._slot_symbols = values['symbols']
        if 'total_exchanged_volume' in values:
            self._slot_total_exchanged_volume = values['total_exchanged_volume']
        if 'type' in values:
            self._slot_type = values['type']

    def bind_scheduler(self, scheduler):
        cdef ChainScheduler typed
        if type(scheduler) is not ChainScheduler:
            raise ValueError("same-extension exchange scheduler required")
        typed = scheduler
        if typed.kernel is not self._slot_kernel:
            raise ValueError("exchange scheduler/kernel differs")
        if self._scheduler is not None and self._scheduler is not typed:
            raise ValueError("exchange scheduler already bound")
        self._scheduler = typed
        self._orders = typed.orders
        self._messages = typed.messages

    def bind_after_source_retired(self):
        if self._bound or self._scheduler is None or self._source.__dict__ != {"_native_moved_to": id(self)}:
            raise ValueError("exchange retirement or binding differs")
        self._bound = True

    def abort_before_first_delivery(self):
        if self._slot_kernel.ttl_messages or self._slot_kernel._deliver_seq:
            raise ValueError("cannot abort exchange after delivery")
        self._bound = False

    def authority_bound(self):
        return bool(self._bound)

    def source_identity(self):
        return self._source

    def snapshot_fields(self):
        result = {}
        if self._slot_book_log_depth is not self._missing:
            result['book_log_depth'] = self._slot_book_log_depth
        if self._slot_book_logging is not self._missing:
            result['book_logging'] = self._slot_book_logging
        if self._slot_computation_delay is not self._missing:
            result['computation_delay'] = self._slot_computation_delay
        if self._slot_current_time is not self._missing:
            result['current_time'] = self._slot_current_time
        if self._slot_data_subscriptions is not self._missing:
            result['data_subscriptions'] = self._slot_data_subscriptions
        if self._slot_id is not self._missing:
            result['id'] = self._slot_id
        if self._slot_kernel is not self._missing:
            result['kernel'] = self._slot_kernel
        if self._slot_log is not self._missing:
            result['log'] = self._slot_log
        if self._slot_log_events is not self._missing:
            result['log_events'] = self._slot_log_events
        if self._slot_log_orders is not self._missing:
            result['log_orders'] = self._slot_log_orders
        if self._slot_log_to_file is not self._missing:
            result['log_to_file'] = self._slot_log_to_file
        if self._slot_market_close_price_subscriptions is not self._missing:
            result['market_close_price_subscriptions'] = self._slot_market_close_price_subscriptions
        if self._slot_metric_trackers is not self._missing:
            result['metric_trackers'] = self._slot_metric_trackers
        if self._slot_mkt_close is not self._missing:
            result['mkt_close'] = self._slot_mkt_close
        if self._slot_mkt_open is not self._missing:
            result['mkt_open'] = self._slot_mkt_open
        if self._slot_name is not self._missing:
            result['name'] = self._slot_name
        if self._slot_oracle is not self._missing:
            result['oracle'] = self._slot_oracle
        if self._slot_order_books is not self._missing:
            result['order_books'] = self._slot_order_books
        if self._slot_pipeline_delay is not self._missing:
            result['pipeline_delay'] = self._slot_pipeline_delay
        if self._slot_random_state is not self._missing:
            result['random_state'] = self._slot_random_state
        if self._slot_reschedule is not self._missing:
            result['reschedule'] = self._slot_reschedule
        if self._slot_stp_policy is not self._missing:
            result['stp_policy'] = self._slot_stp_policy
        if self._slot_stream_history is not self._missing:
            result['stream_history'] = self._slot_stream_history
        if self._slot_symbols is not self._missing:
            result['symbols'] = self._slot_symbols
        if self._slot_total_exchanged_volume is not self._missing:
            result['total_exchanged_volume'] = self._slot_total_exchanged_volume
        if self._slot_type is not self._missing:
            result['type'] = self._slot_type
        return result

    def __hash__(self):
        return object.__hash__(self)


    property book_log_depth:
        def __get__(self):
            if self._slot_book_log_depth is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log_depth'")
            return self._slot_book_log_depth

        def __set__(self, value):
            self._slot_book_log_depth = value

        def __del__(self):
            if self._slot_book_log_depth is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log_depth'")
            self._slot_book_log_depth = self._missing

    property book_logging:
        def __get__(self):
            if self._slot_book_logging is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_logging'")
            return self._slot_book_logging

        def __set__(self, value):
            self._slot_book_logging = value

        def __del__(self):
            if self._slot_book_logging is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_logging'")
            self._slot_book_logging = self._missing

    property computation_delay:
        def __get__(self):
            if self._slot_computation_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'computation_delay'")
            return self._slot_computation_delay

        def __set__(self, value):
            self._slot_computation_delay = value

        def __del__(self):
            if self._slot_computation_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'computation_delay'")
            self._slot_computation_delay = self._missing

    property current_time:
        def __get__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            return self._slot_current_time

        def __set__(self, value):
            self._slot_current_time = value

        def __del__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            self._slot_current_time = self._missing

    property data_subscriptions:
        def __get__(self):
            if self._slot_data_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'data_subscriptions'")
            return self._slot_data_subscriptions

        def __set__(self, value):
            self._slot_data_subscriptions = value

        def __del__(self):
            if self._slot_data_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'data_subscriptions'")
            self._slot_data_subscriptions = self._missing

    property id:
        def __get__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            return self._slot_id

        def __set__(self, value):
            self._slot_id = value

        def __del__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            self._slot_id = self._missing

    property kernel:
        def __get__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            return self._slot_kernel

        def __set__(self, value):
            self._slot_kernel = value

        def __del__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            self._slot_kernel = self._missing

    property log:
        def __get__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            return self._slot_log

        def __set__(self, value):
            self._slot_log = value

        def __del__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            self._slot_log = self._missing

    property log_events:
        def __get__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            return self._slot_log_events

        def __set__(self, value):
            self._slot_log_events = value

        def __del__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            self._slot_log_events = self._missing

    property log_orders:
        def __get__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            return self._slot_log_orders

        def __set__(self, value):
            self._slot_log_orders = value

        def __del__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            self._slot_log_orders = self._missing

    property log_to_file:
        def __get__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            return self._slot_log_to_file

        def __set__(self, value):
            self._slot_log_to_file = value

        def __del__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            self._slot_log_to_file = self._missing

    property market_close_price_subscriptions:
        def __get__(self):
            if self._slot_market_close_price_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'market_close_price_subscriptions'")
            return self._slot_market_close_price_subscriptions

        def __set__(self, value):
            self._slot_market_close_price_subscriptions = value

        def __del__(self):
            if self._slot_market_close_price_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'market_close_price_subscriptions'")
            self._slot_market_close_price_subscriptions = self._missing

    property metric_trackers:
        def __get__(self):
            if self._slot_metric_trackers is self._missing:
                raise AttributeError("native owner has no initialized attribute 'metric_trackers'")
            return self._slot_metric_trackers

        def __set__(self, value):
            self._slot_metric_trackers = value

        def __del__(self):
            if self._slot_metric_trackers is self._missing:
                raise AttributeError("native owner has no initialized attribute 'metric_trackers'")
            self._slot_metric_trackers = self._missing

    property mkt_close:
        def __get__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            return self._slot_mkt_close

        def __set__(self, value):
            self._slot_mkt_close = value

        def __del__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            self._slot_mkt_close = self._missing

    property mkt_open:
        def __get__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            return self._slot_mkt_open

        def __set__(self, value):
            self._slot_mkt_open = value

        def __del__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            self._slot_mkt_open = self._missing

    property name:
        def __get__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            return self._slot_name

        def __set__(self, value):
            self._slot_name = value

        def __del__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            self._slot_name = self._missing

    property oracle:
        def __get__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            return self._slot_oracle

        def __set__(self, value):
            self._slot_oracle = value

        def __del__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            self._slot_oracle = self._missing

    property order_books:
        def __get__(self):
            if self._slot_order_books is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_books'")
            return self._slot_order_books

        def __set__(self, value):
            self._slot_order_books = value

        def __del__(self):
            if self._slot_order_books is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_books'")
            self._slot_order_books = self._missing

    property pipeline_delay:
        def __get__(self):
            if self._slot_pipeline_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'pipeline_delay'")
            return self._slot_pipeline_delay

        def __set__(self, value):
            self._slot_pipeline_delay = value

        def __del__(self):
            if self._slot_pipeline_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'pipeline_delay'")
            self._slot_pipeline_delay = self._missing

    property random_state:
        def __get__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            return self._slot_random_state

        def __set__(self, value):
            self._slot_random_state = value

        def __del__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            self._slot_random_state = self._missing

    property reschedule:
        def __get__(self):
            if self._slot_reschedule is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reschedule'")
            return self._slot_reschedule

        def __set__(self, value):
            self._slot_reschedule = value

        def __del__(self):
            if self._slot_reschedule is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reschedule'")
            self._slot_reschedule = self._missing

    property stp_policy:
        def __get__(self):
            if self._slot_stp_policy is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stp_policy'")
            return self._slot_stp_policy

        def __set__(self, value):
            self._slot_stp_policy = value

        def __del__(self):
            if self._slot_stp_policy is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stp_policy'")
            self._slot_stp_policy = self._missing

    property stream_history:
        def __get__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            return self._slot_stream_history

        def __set__(self, value):
            self._slot_stream_history = value

        def __del__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            self._slot_stream_history = self._missing

    property symbols:
        def __get__(self):
            if self._slot_symbols is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbols'")
            return self._slot_symbols

        def __set__(self, value):
            self._slot_symbols = value

        def __del__(self):
            if self._slot_symbols is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbols'")
            self._slot_symbols = self._missing

    property total_exchanged_volume:
        def __get__(self):
            if self._slot_total_exchanged_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'total_exchanged_volume'")
            return self._slot_total_exchanged_volume

        def __set__(self, value):
            self._slot_total_exchanged_volume = value

        def __del__(self):
            if self._slot_total_exchanged_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'total_exchanged_volume'")
            self._slot_total_exchanged_volume = self._missing

    property type:
        def __get__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            return self._slot_type

        def __set__(self, value):
            self._slot_type = value

        def __del__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            self._slot_type = self._missing

    def kernel_terminating(self):
        return self._kernel_terminating()

    def wakeup(self, current_time):
        return self._wakeup(current_time)

    def receive_message(self, current_time, sender_id, message):
        return self._receive_message(current_time, sender_id, message)

    def publish_order_book_data(self):
        return self._publish_order_book_data()

    def handle_frequency_based_data_subscription(self, symbol, data_sub):
        return self._handle_frequency_based_data_subscription(symbol, data_sub)

    def handle_event_based_data_subscription(self, symbol, data_sub):
        return self._handle_event_based_data_subscription(symbol, data_sub)

    def logL2style(self, symbol):
        return self._logL2style(symbol)

    def send_message(self, recipient_id, message):
        return self._send_message(recipient_id, message)

    def analyse_order_book(self, symbol):
        return self._analyse_order_book(symbol)

    def _original_time_dropout(self, book, symbol):
        return self.__original_time_dropout(book, symbol)

    def get_time_dropout(self, book, symbol):
        return self._get_time_dropout(book, symbol)

    def logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        return self._logEvent(event_type, event, append_summary_log, deepcopy_event)

    def set_wakeup(self, requested_time):
        return self._set_wakeup(requested_time)

    def set_computation_delay(self, requested_delay):
        return self._set_computation_delay(requested_delay)

    def write_log(self, df_log, filename=None):
        return self._write_log(df_log, filename)

    def kernel_stopping(self):
        return self._kernel_stopping()

    cdef object _kernel_terminating(self):
        self._base_kernel_terminating()
        (bid_volume, ask_volume) = (<NativeBook>self._slot_order_books['ABM'])._get_transacted_volume(self._slot_current_time - self._slot_mkt_open)
        self._slot_total_exchanged_volume = bid_volume + ask_volume
        for symbol in self._slot_symbols:
            self._analyse_order_book(symbol)
        for symbol in self._slot_symbols:
            (bid_volume, ask_volume) = (<NativeBook>self._slot_order_books[symbol])._get_transacted_volume(self._slot_current_time - self._slot_mkt_open)
            self._slot_metric_trackers[symbol].total_exchanged_volume = bid_volume + ask_volume
            self._slot_metric_trackers[symbol].last_trade = (<NativeBook>self._slot_order_books[symbol])._slot_last_trade
        if self._slot_log_orders == None:
            return
        if hasattr(self._slot_oracle, 'f_log'):
            for symbol in self._slot_oracle.f_log:
                dfFund = pd.DataFrame(self._slot_oracle.f_log[symbol])
                if not dfFund.empty:
                    dfFund.set_index('FundamentalTime', inplace=True)
                    self._write_log(dfFund, 'fundamental_{}'.format(symbol))
                    if exchange_logger.isEnabledFor(10):
                        exchange_logger.debug('Fundamental archival complete.')

    cdef object _wakeup(self, current_time):
        cdef NativeBook book
        self._base_wakeup(current_time)
        if current_time >= self._slot_mkt_close:
            close_prices={}
            for symbol,book in self._slot_order_books.items():
                close_prices[symbol]=book._slot_last_trade
            message=self._messages._new_u(12, 0,close_prices,None,None,None,None,None,None)
            try:
                for agent in self._slot_market_close_price_subscriptions:
                    # One original close-price message, separate send ownership.
                    self._messages._retain(message)
                    self._send_message(agent,message)
            finally:
                self._messages._release(message)

    cdef object _receive_message(self, current_time, sender_id, message):
        cdef uint64_t copy
        self._base_receive_message(current_time, sender_id, message)
        self._set_computation_delay(self._slot_computation_delay)
        if current_time > self._slot_mkt_close:
            if self._messages._kind(message) in (7, 10):
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received {}: {}'.format(self._slot_name, self._messages._name(message), self._messages._order_u(message)))
                self._send_message(sender_id, self._messages._new_u(13, 0, None, None, None, None, None, None, None))
                return
            elif self._messages._kind(message) in (5,):
                pass
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received {}, discarded: market is closed.'.format(self._slot_name, self._messages._name(message)))
                self._send_message(sender_id, self._messages._new_u(13, 0, None, None, None, None, None, None, None))
                return
        if self._messages._kind(message) in (7, 10):
            if self._slot_log_orders:
                _observe_order(self, self._messages._name(message), self._orders, self._messages._order_u(message))
        else:
            _observe_diagnostic(self, self._messages._name(message), None)
        if self._messages._kind(message) in (3,):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received market hours request from agent {}'.format(self._slot_name, sender_id))
            self._set_computation_delay(0)
            self._send_message(sender_id, self._messages._new_u(4, 0, self._slot_mkt_open, self._slot_mkt_close, None, None, None, None, None))
        elif self._messages._kind(message) in (2,):
            self._slot_market_close_price_subscriptions.append(sender_id)
        elif self._messages._kind(message) in (5,):
            symbol = self._messages._get(message, 1)
            depth = self._messages._get(message, 2)
            if symbol not in self._slot_order_books:
                warnings.warn(f'Bid-ask spread request discarded. Unknown symbol: {symbol}')
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received QUERY_SPREAD ({}:{}) request from agent {}'.format(self._slot_name, symbol, depth, sender_id))
                self._send_message(sender_id, self._messages._new_u(6, 0, symbol, current_time > self._slot_mkt_close, depth, (<NativeBook>self._slot_order_books[symbol])._get_l2_bid_data(depth), (<NativeBook>self._slot_order_books[symbol])._get_l2_ask_data(depth), (<NativeBook>self._slot_order_books[symbol])._slot_last_trade, None))
        elif self._messages._kind(message) in (7,):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received LIMIT_ORDER: {}'.format(self._slot_name, self._messages._order_u(message)))
            if self._orders._get_u(self._messages._order_u(message),2) not in self._slot_order_books:
                warnings.warn(f'Limit Order discarded. Unknown symbol: {self._orders._get_u(self._messages._order_u(message),2)}')
            else:
                copy=self._orders._clone_u(self._messages._order_u(message))
                try: (<NativeBook>self._slot_order_books[self._orders._get_u(self._messages._order_u(message),2)])._handle_limit_order(copy, False)
                finally: self._orders._release_u(copy)
                self._publish_order_book_data()
        elif self._messages._kind(message) in (10,):
            tag = self._messages._get(message, 1)
            metadata = self._messages._get(message, 2)
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received CANCEL_ORDER: {}'.format(self._slot_name, self._messages._order_u(message)))
            if self._orders._get_u(self._messages._order_u(message),2) not in self._slot_order_books:
                warnings.warn(f'Cancellation request discarded. Unknown symbol: {self._orders._get_u(self._messages._order_u(message),2)}')
            else:
                copy=self._orders._clone_u(self._messages._order_u(message))
                try: (<NativeBook>self._slot_order_books[self._orders._get_u(self._messages._order_u(message),2)])._cancel_order(copy, tag, metadata, False)
                finally: self._orders._release_u(copy)
                self._publish_order_book_data()

    cdef object _publish_order_book_data(self):
        if any(self._slot_data_subscriptions.values()):
            raise ValueError("unsupported subscription escaped whole-input arena admission")

    cdef object _handle_frequency_based_data_subscription(self, symbol, data_sub):
        raise ValueError("unsupported subscription escaped whole-input admission")

    cdef object _handle_event_based_data_subscription(self, symbol, data_sub):
        raise ValueError("unsupported subscription escaped whole-input admission")

    cdef object _logL2style(self, symbol):
        cdef NativeBook book
        book = self._slot_order_books[symbol]
        if not book._slot_book_log2:
            return None
        tmp = book._slot_book_log2
        times = []
        booktop = []
        for t in tmp:
            times.append(t['QuoteTime'])
            booktop.append([t['bids'], t['asks']])
        return (times, booktop)

    cdef object _send_message(self, recipient_id, message):
        kind=self._messages._kind(message)
        try:
            if kind in (8,9,11):
                self._scheduler._send(self._slot_id, recipient_id, message, self._slot_pipeline_delay)
            else:
                self._scheduler._send(self._slot_id, recipient_id, message, 0)
        finally:
            self._messages._release(message)

    cdef object _analyse_order_book(self, symbol):
        book = (<NativeBook>self._slot_order_books[symbol])._slot_book_log2
        self._get_time_dropout(book, symbol)

    cdef object __original_time_dropout(self, book, symbol):
        if len(book) == 0:
            return
        df = pd.DataFrame(book)
        total_time = df['QuoteTime'].iloc[-1] - df['QuoteTime'].iloc[0]
        is_null_bids = False
        t_null_bids_first = 0
        T_null_bids = 0
        is_null_asks = False
        t_null_asks_first = 0
        T_null_asks = 0
        for (_, row) in df.iterrows():
            if (len(row['bids']) == 0) & (is_null_bids == False):
                t_null_bids_first = row['QuoteTime']
                is_null_bids = True
            elif (len(row['bids']) != 0) & (is_null_bids == True):
                T_null_bids += row['QuoteTime'] - t_null_bids_first
                is_null_bids = False
            if (len(row['asks']) == 0) & (is_null_asks == False):
                t_null_asks_first = row['QuoteTime']
                is_null_asks = True
            elif (len(row['asks']) != 0) & (is_null_asks == True):
                T_null_asks += row['QuoteTime'] - t_null_asks_first
                is_null_asks = False
        self._slot_metric_trackers[symbol] = ExchangeAgent.MetricTracker(total_time_no_liquidity_asks=T_null_asks / 1000000000.0, total_time_no_liquidity_bids=T_null_bids / 1000000000.0, pct_time_no_liquidity_asks=100 * T_null_asks / total_time, pct_time_no_liquidity_bids=100 * T_null_bids / total_time)

    cdef object _get_time_dropout(self, book, symbol):
        if not book:
            return
        limits = np.iinfo(np.int64)
        if _dropout_invalid(book, limits):
            return self.__original_time_dropout(book, symbol)
        total_time = np.int64(book[-1]['QuoteTime']) - np.int64(book[0]['QuoteTime'])
        is_null_bids = is_null_asks = False
        first_bid = first_ask = bid_time = ask_time = 0
        for row in book:
            timestamp = int(row['QuoteTime'])
            if len(row['bids']) == 0 and (not is_null_bids):
                (first_bid, is_null_bids) = (timestamp, True)
            elif len(row['bids']) != 0 and is_null_bids:
                bid_time += timestamp - first_bid
                is_null_bids = False
            if len(row['asks']) == 0 and (not is_null_asks):
                (first_ask, is_null_asks) = (timestamp, True)
            elif len(row['asks']) != 0 and is_null_asks:
                ask_time += timestamp - first_ask
                is_null_asks = False
        self._slot_metric_trackers[symbol] = ExchangeAgent.MetricTracker(total_time_no_liquidity_asks=ask_time / 1000000000.0, total_time_no_liquidity_bids=bid_time / 1000000000.0, pct_time_no_liquidity_asks=100 * ask_time / total_time, pct_time_no_liquidity_bids=100 * bid_time / total_time)

    cdef object _base_wakeup(self, current_time):
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received wakeup.'.format(fmt_ts(current_time), self._slot_id, self._slot_name))

    cdef object _base_receive_message(self, current_time, sender_id, message):
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received: {}'.format(fmt_ts(current_time), self._slot_id, self._slot_name, message))

    cdef object _base_kernel_terminating(self):
        if _observer.skip_termination(self):
            return
        if self._slot_log and self._slot_log_to_file:
            df_log = pd.DataFrame(self._slot_log, columns=('EventTime', 'EventType', 'Event'))
            df_log.set_index('EventTime', inplace=True)
            self._write_log(df_log, None)

    cdef object _logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        if _observe_log(self,event_type,event,append_summary_log,deepcopy_event):
            return
        if not self._slot_log_events:
            return
        if deepcopy_event:
            if type(event) is dict and _primitive_event(event):
                event = event.copy()
            else:
                event = deepcopy(event)
        self._slot_log.append((self._slot_current_time, event_type, event))
        if append_summary_log:
            assert self._slot_kernel is not None
            self._slot_kernel.append_summary_log(self._slot_id, event_type, event)

    cdef object _set_wakeup(self, requested_time):
        assert self._slot_kernel is not None
        self._scheduler._set_wakeup(self._slot_id, requested_time)

    cdef object _set_computation_delay(self, requested_delay):
        assert self._slot_kernel is not None
        self._slot_kernel.set_agent_compute_delay(sender_id=self._slot_id, requested_delay=requested_delay)

    cdef object _write_log(self, df_log, filename=None):
        assert self._slot_kernel is not None
        self._slot_kernel.write_log(self._slot_id, df_log, filename)

    cdef object _kernel_stopping(self):
        pass

cdef class NativeLevel:

    property hidden_orders:
        def __get__(self):
            if self._slot_hidden_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'hidden_orders'")
            return self._slot_hidden_orders

        def __set__(self, value):
            self._slot_hidden_orders = value

        def __del__(self):
            if self._slot_hidden_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'hidden_orders'")
            self._slot_hidden_orders = self._missing

    property price:
        def __get__(self):
            if self._slot_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price'")
            return self._slot_price

        def __set__(self, value):
            self._slot_price = value

        def __del__(self):
            if self._slot_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price'")
            self._slot_price = self._missing

    property side:
        def __get__(self):
            if self._slot_side is self._missing:
                raise AttributeError("native owner has no initialized attribute 'side'")
            return self._slot_side

        def __set__(self, value):
            self._slot_side = value

        def __del__(self):
            if self._slot_side is self._missing:
                raise AttributeError("native owner has no initialized attribute 'side'")
            self._slot_side = self._missing

    property visible_orders:
        def __get__(self):
            if self._slot_visible_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'visible_orders'")
            return self._slot_visible_orders

        def __set__(self, value):
            self._slot_visible_orders = value

        def __del__(self):
            if self._slot_visible_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'visible_orders'")
            self._slot_visible_orders = self._missing

    property total_quantity:
        def __get__(self):
            return self._total_quantity()

    property is_empty:
        def __get__(self):
            return self._is_empty()

    def add_order(self, order, metadata=None):
        return self._add_order(self._orders._checked_handle(order), metadata)

    def update_order_quantity(self, order_id, new_quantity):
        return self._update_order_quantity(order_id, new_quantity)

    def remove_order(self, order_id):
        return self._remove_order(order_id)

    def peek(self):
        return self._peek()

    def pop(self):
        return self._pop()

    def order_is_match(self, order):
        return self._order_is_match(self._orders._checked_handle(order))

    def order_has_better_price(self, order):
        return self._order_has_better_price(self._orders._checked_handle(order))

    def order_has_worse_price(self, order):
        return self._order_has_worse_price(self._orders._checked_handle(order))

    def order_has_equal_price(self, order):
        return self._order_has_equal_price(self._orders._checked_handle(order))

    def __init__(self, orders, OrderArena arena=None):
        if arena is None: raise ValueError("native level requires authoritative order arena")
        self._orders=arena
        self._missing = _MISSING
        if len(orders) == 0:
            raise ValueError('At least one LimitOrder must be given when initialising a PriceLevel.')
        self._slot_visible_orders = []
        self._slot_hidden_orders = []
        self._slot_price = self._orders._get(orders[0][0],8)
        self._slot_side = self._orders._get(orders[0][0],4)
        for (order, metadata) in orders:
            self._add_order(self._orders._checked_handle(order), metadata)

    cdef object _add_order(self, uint64_t order, metadata=None):
        cdef uint64_t order2

        self._orders._retain_u(order)
        if self._orders._get_u(order, 9):
            self._slot_hidden_orders.append((order, metadata or {}))
        elif self._orders._get_u(order, 11):
            insert_index = 0
            for (order2, _) in self._slot_visible_orders:
                if self._orders._get_u(order2, 5) > self._orders._get_u(order, 5):
                    break
                insert_index += 1
            self._slot_visible_orders.insert(insert_index, (order, metadata or {}))
        else:
            self._slot_visible_orders.append((order, metadata or {}))

    cdef object _update_order_quantity(self, order_id, new_quantity):
        cdef uint64_t order

        if new_quantity == 0:
            return False
        for (i, (order, metadata)) in enumerate(self._slot_visible_orders):
            if self._orders._get_u(order, 5) == order_id:
                if new_quantity <= self._orders._get_u(order, 3):
                    self._orders._set_u(order, 3, new_quantity)
                else:
                    self._slot_visible_orders.pop(i)
                    self._orders._set_u(order, 3, new_quantity)
                    self._slot_visible_orders.append((order, metadata))
                return True
        for (i, (order, metadata)) in enumerate(self._slot_hidden_orders):
            if self._orders._get_u(order, 5) == order_id:
                if new_quantity <= self._orders._get_u(order, 3):
                    self._orders._set_u(order, 3, new_quantity)
                else:
                    self._slot_hidden_orders.pop(i)
                    self._orders._set_u(order, 3, new_quantity)
                    self._slot_hidden_orders.append((order, metadata))
                return True
        return False

    cdef object _remove_order(self, order_id):
        cdef uint64_t book_order

        for (i, (book_order, _)) in enumerate(self._slot_visible_orders):
            if self._orders._get_u(book_order, 5) == order_id:
                return self._slot_visible_orders.pop(i)
        for (i, (book_order, _)) in enumerate(self._slot_hidden_orders):
            if self._orders._get_u(book_order, 5) == order_id:
                return self._slot_hidden_orders.pop(i)
        return None

    cdef object _peek(self):
        if len(self._slot_visible_orders) > 0:
            return self._slot_visible_orders[0]
        elif len(self._slot_hidden_orders) > 0:
            return self._slot_hidden_orders[0]
        else:
            raise ValueError("Can't peek at LimitOrder in PriceLevel as it contains no orders")

    cdef object _pop(self):
        if len(self._slot_visible_orders) > 0:
            return self._slot_visible_orders.pop(0)
        elif len(self._slot_hidden_orders) > 0:
            return self._slot_hidden_orders.pop(0)
        else:
            raise ValueError("Can't pop LimitOrder from PriceLevel as it contains no orders")

    cdef object _order_is_match(self, uint64_t order):

        if self._orders._get_u(order, 4) == self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if self._orders._get_u(order, 4).is_bid() and self._orders._get_u(order, 8) >= self._slot_price and (not (self._orders._get_u(order, 12) and self._total_quantity() == 0)):
            return True
        if self._orders._get_u(order, 4).is_ask() and self._orders._get_u(order, 8) <= self._slot_price and (not (self._orders._get_u(order, 12) and self._total_quantity() == 0)):
            return True
        return False

    cdef object _order_has_better_price(self, uint64_t order):

        if self._orders._get_u(order, 4) != self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if self._orders._get_u(order, 4).is_bid() and self._orders._get_u(order, 8) > self._slot_price:
            return True
        if self._orders._get_u(order, 4).is_ask() and self._orders._get_u(order, 8) < self._slot_price:
            return True
        return False

    cdef object _order_has_worse_price(self, uint64_t order):

        if self._orders._get_u(order, 4) != self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if self._orders._get_u(order, 4).is_bid() and self._orders._get_u(order, 8) < self._slot_price:
            return True
        if self._orders._get_u(order, 4).is_ask() and self._orders._get_u(order, 8) > self._slot_price:
            return True
        return False

    cdef object _order_has_equal_price(self, uint64_t order):

        if self._orders._get_u(order, 4) != self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        return self._orders._get_u(order, 8) == self._slot_price

    cdef object _total_quantity(self):
        cdef uint64_t order

        quantities = []
        for (order, _) in self._slot_visible_orders:
            quantities.append(self._orders._get_u(order, 3))
        return sum(quantities)

    cdef object _is_empty(self):
        return len(self._slot_visible_orders) == 0 and len(self._slot_hidden_orders) == 0

    def __eq__(self, other):
        if not isinstance(other, NativeLevel):
            raise NotImplementedError
        return self._slot_visible_orders == other.visible_orders and self._slot_hidden_orders == other.hidden_orders

cdef class NativeBook:

    property asks:
        def __get__(self):
            if self._slot_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'asks'")
            return self._slot_asks

        def __set__(self, value):
            self._slot_asks = value

        def __del__(self):
            if self._slot_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'asks'")
            self._slot_asks = self._missing

    property bids:
        def __get__(self):
            if self._slot_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'bids'")
            return self._slot_bids

        def __set__(self, value):
            self._slot_bids = value

        def __del__(self):
            if self._slot_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'bids'")
            self._slot_bids = self._missing

    property book_log2:
        def __get__(self):
            if self._slot_book_log2 is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log2'")
            return self._slot_book_log2

        def __set__(self, value):
            self._slot_book_log2 = value

        def __del__(self):
            if self._slot_book_log2 is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log2'")
            self._slot_book_log2 = self._missing

    property buy_transactions:
        def __get__(self):
            if self._slot_buy_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'buy_transactions'")
            return self._slot_buy_transactions

        def __set__(self, value):
            self._slot_buy_transactions = value

        def __del__(self):
            if self._slot_buy_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'buy_transactions'")
            self._slot_buy_transactions = self._missing

    property history:
        def __get__(self):
            if self._slot_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'history'")
            return self._slot_history

        def __set__(self, value):
            self._slot_history = value

        def __del__(self):
            if self._slot_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'history'")
            self._slot_history = self._missing

    property last_trade:
        def __get__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            return self._slot_last_trade

        def __set__(self, value):
            self._slot_last_trade = value

        def __del__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            self._slot_last_trade = self._missing

    property last_update_ts:
        def __get__(self):
            if self._slot_last_update_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_update_ts'")
            return self._slot_last_update_ts

        def __set__(self, value):
            self._slot_last_update_ts = value

        def __del__(self):
            if self._slot_last_update_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_update_ts'")
            self._slot_last_update_ts = self._missing

    property owner:
        def __get__(self):
            if self._slot_owner is self._missing:
                raise AttributeError("native owner has no initialized attribute 'owner'")
            return self._slot_owner

        def __set__(self, value):
            self._slot_owner = value

        def __del__(self):
            if self._slot_owner is self._missing:
                raise AttributeError("native owner has no initialized attribute 'owner'")
            self._slot_owner = self._missing

    property quotes_seen:
        def __get__(self):
            if self._slot_quotes_seen is self._missing:
                raise AttributeError("native owner has no initialized attribute 'quotes_seen'")
            return self._slot_quotes_seen

        def __set__(self, value):
            self._slot_quotes_seen = value

        def __del__(self):
            if self._slot_quotes_seen is self._missing:
                raise AttributeError("native owner has no initialized attribute 'quotes_seen'")
            self._slot_quotes_seen = self._missing

    property sell_transactions:
        def __get__(self):
            if self._slot_sell_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sell_transactions'")
            return self._slot_sell_transactions

        def __set__(self, value):
            self._slot_sell_transactions = value

        def __del__(self):
            if self._slot_sell_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sell_transactions'")
            self._slot_sell_transactions = self._missing

    property symbol:
        def __get__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            return self._slot_symbol

        def __set__(self, value):
            self._slot_symbol = value

        def __del__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            self._slot_symbol = self._missing

    def handle_limit_order(self, order, quiet=False):
        return self._handle_limit_order(self._orders._checked_handle(order), quiet)

    def handle_market_order(self, order):
        return self._handle_market_order(order)

    def execute_order(self, order):
        cdef uint64_t matched=self._execute_order(self._orders._checked_handle(order))
        return None if matched==0 else int(matched)

    def enter_order(self, order, metadata=None, quiet=False):
        return self._enter_order(self._orders._checked_handle(order), metadata, quiet)

    def cancel_order(self, order, tag=None, cancellation_metadata=None, quiet=False):
        return self._cancel_order(self._orders._checked_handle(order), tag, cancellation_metadata, quiet)

    def modify_order(self, order, new_order):
        return self._modify_order(order, new_order)

    def partial_cancel_order(self, order, quantity, tag=None, cancellation_metadata=None):
        return self._partial_cancel_order(order, quantity, tag, cancellation_metadata)

    def replace_order(self, agent_id, old_order, new_order):
        return self._replace_order(agent_id, old_order, new_order)

    def append_book_log2(self):
        return self._append_book_log2()

    def get_l1_bid_data(self):
        return self._get_l1_bid_data()

    def get_l1_ask_data(self):
        return self._get_l1_ask_data()

    def get_l2_bid_data(self, depth=sys.maxsize):
        return self._get_l2_bid_data(depth)

    def get_l2_ask_data(self, depth=sys.maxsize):
        return self._get_l2_ask_data(depth)

    def get_l3_bid_data(self, depth=sys.maxsize):
        return self._get_l3_bid_data(depth)

    def get_l3_ask_data(self, depth=sys.maxsize):
        return self._get_l3_ask_data(depth)

    def get_transacted_volume(self, lookback_period='10min'):
        return self._get_transacted_volume(lookback_period)

    def get_imbalance(self):
        return self._get_imbalance()

    def get_L1_snapshots(self):
        return self._get_L1_snapshots()

    def bids_padding(self, book, nlevels):
        return self._bids_padding(book, nlevels)

    def asks_padding(self, book, nlevels):
        return self._asks_padding(book, nlevels)

    def get_L2_snapshots(self, nlevels):
        return self._get_L2_snapshots(nlevels)

    def get_l3_itch(self):
        return self._get_l3_itch()

    def pretty_print(self, silent=True):
        return self._pretty_print(silent)

    def __init__(self, owner, symbol):
        self._scheduler = None
        self._missing = _MISSING
        self._slot_owner = owner
        self._owner = owner
        self._slot_symbol = symbol
        self._slot_bids = []
        self._slot_asks = []
        self._slot_last_trade = None
        self._slot_book_log2 = []
        self._slot_quotes_seen = set()
        self._slot_history = []
        self._slot_last_update_ts = self._owner._slot_mkt_open
        self._slot_buy_transactions = []
        self._slot_sell_transactions = []

    cdef object _handle_limit_order(self, uint64_t order, quiet=False):
        cdef uint64_t resting, cancelled, matched_order

        if self._orders._get_u(order, 2) != self._slot_symbol:
            warnings.warn(f'{self._orders._get_u(order, 2)} order discarded. Does not match OrderBook symbol: {self._slot_symbol}')
            return
        if self._orders._get_u(order, 3) <= 0 or int(self._orders._get_u(order, 3)) != self._orders._get_u(order, 3):
            warnings.warn(f'{self._orders._get_u(order, 2)} order discarded. Quantity ({self._orders._get_u(order, 3)}) must be a positive integer.')
            return
        if self._orders._get_u(order, 8) < 0 or int(self._orders._get_u(order, 8)) != self._orders._get_u(order, 8):
            warnings.warn(f'{self._orders._get_u(order, 2)} order discarded. Limit price ({self._orders._get_u(order, 8)}) must be a positive integer.')
            return
        executed = []
        while True:
            stp_policy = self._owner._slot_stp_policy
            if stp_policy:
                opp = self._slot_asks if self._orders._get_u(order, 4).is_bid() else self._slot_bids
                if opp and (<NativeLevel>opp[0])._order_is_match(order):
                    resting = (<NativeLevel>opp[0])._peek()[0]
                    if self._orders._get_u(resting, 0) == self._orders._get_u(order, 0):
                        if stp_policy == 'cancel_oldest' and self._cancel_order(resting, None, None, quiet):
                            continue
                        if stp_policy != 'cancel_oldest':
                            if not quiet:
                                cancelled=self._orders._clone_u(order)
                                try: self._send(self._orders._get_u(order,0),self._messages._new_u(11, cancelled, None, None, None, None, None, None, None))
                                finally: self._orders._release_u(cancelled)
                            break
            matched_order = self._execute_order(order)
            if matched_order!=0:
                assert self._orders._get_u(matched_order, 6) is not None
                executed.append((self._orders._get_u(matched_order, 3), self._orders._get_u(matched_order, 6)))
                self._orders._release_u(matched_order)
                if self._orders._get_u(order, 3) <= 0:
                    break
            else:
                self._enter_order(self._orders._clone_u(order), None, quiet)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('ACCEPTED: new order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order acceptance to agent {} for order {}', self._orders._get_u(order, 0), self._orders._get_u(order, 5))
                if not quiet:
                    self._send(self._orders._get_u(order, 0), self._messages._new_u(8, order, None, None, None, None, None, None, None))
                break
        if self._slot_bids:
            _observe_quote(self._slot_owner, 'BEST_BID', self._slot_symbol, (<NativeLevel>self._slot_bids[0])._slot_price, (<NativeLevel>self._slot_bids[0])._total_quantity())
        if self._slot_asks:
            _observe_quote(self._slot_owner, 'BEST_ASK', self._slot_symbol, (<NativeLevel>self._slot_asks[0])._slot_price, (<NativeLevel>self._slot_asks[0])._total_quantity())
        if len(executed) > 0:
            trade_qty = 0
            trade_price = 0
            for (q, p) in executed:
                if book_logger.isEnabledFor(10):
                    book_logger.debug('Executed: {} @ {}', q, p)
                trade_qty += q
                trade_price += p * q
            avg_price = int(round(trade_price / trade_qty))
            if book_logger.isEnabledFor(10):
                book_logger.debug(f'Avg: {trade_qty} @ ${avg_price:0.4f}')
            self._owner._logEvent('LAST_TRADE', f'{trade_qty},${avg_price:0.4f}', False, True)
            self._slot_last_trade = avg_price

    cdef object _handle_market_order(self, order):
        raise ValueError("unsupported book method escaped whole-input arena admission: _handle_market_order")

    cdef uint64_t _execute_order(self, uint64_t order) except? 0:
        cdef uint64_t matched_order, book_order, filled_order

        book = self._slot_asks if self._orders._get_u(order, 4).is_bid() else self._slot_bids
        if len(book) == 0:
            return 0
        elif True and (not (<NativeLevel>book[0])._order_is_match(order)):
            return 0
        elif self._orders._get_u(order, 7) in ['MR_preprocess_ADD', 'MR_preprocess_REPLACE']:
            self._owner._logEvent(self._orders._get_u(order, 7) + '_POST_ONLY', {'order_id': self._orders._get_u(order, 5)}, False, True)
            return 0
        else:
            is_ptc_exec = False
            if self._orders._get_u(order, 3) >= self._orders._get_u((<NativeLevel>book[0])._peek()[0],3):
                (matched_order, matched_order_metadata) = (<NativeLevel>book[0])._pop()
                if self._orders._get_u(matched_order, 10):
                    is_ptc_exec = True
                    if matched_order_metadata['ptc_hidden'] == False:
                        raise Exception('Should not be executing on the visible half of a price to comply order!')
                    assert (<NativeLevel>book[1])._remove_order(self._orders._get_u(matched_order, 5)) is not None
                    if (<NativeLevel>book[1])._is_empty():
                        del book[1]
                if (<NativeLevel>book[0])._is_empty():
                    del book[0]
            else:
                (book_order, book_order_metadata) = (<NativeLevel>book[0])._peek()
                matched_order = self._orders._clone_u(book_order)
                self._orders._set_u(matched_order, 3, self._orders._get_u(order, 3))
                self._orders._set_u(book_order, 3, self._orders._get_u(book_order, 3) - self._orders._get_u(matched_order, 3))
                if self._orders._get_u(book_order, 10):
                    is_ptc_exec = True
                    if book_order_metadata['ptc_hidden'] == False:
                        raise Exception('Should not be executing on the visible half of a price to comply order!')
                    raise ValueError('unsupported PTC flags escaped whole-input admission')
            self._orders._set_u(matched_order, 6, self._orders._get_u(matched_order, 8))
            if self._orders._get_u(order, 4).is_bid():
                self._slot_buy_transactions.append((self._owner._slot_current_time, self._orders._get_u(matched_order, 3)))
            else:
                self._slot_sell_transactions.append((self._owner._slot_current_time, self._orders._get_u(matched_order, 3)))
            self._slot_history.append(dict(time=self._owner._slot_current_time, type='EXEC', order_id=self._orders._get_u(matched_order, 5), agent_id=self._orders._get_u(matched_order, 0), oppos_order_id=self._orders._get_u(order, 5), oppos_agent_id=self._orders._get_u(order, 0), side='SELL' if self._orders._get_u(order, 4).is_bid() else 'BUY', quantity=self._orders._get_u(matched_order, 3), price=self._orders._get_u(matched_order, 8) if is_ptc_exec else None))
            filled_order = self._orders._clone_u(order)
            self._orders._set_u(filled_order, 3, self._orders._get_u(matched_order, 3))
            self._orders._set_u(filled_order, 6, self._orders._get_u(matched_order, 6))
            self._orders._set_u(order, 3, self._orders._get_u(order, 3) - self._orders._get_u(filled_order, 3))
            if book_logger.isEnabledFor(10):
                book_logger.debug('MATCHED: new order {} vs old order {}', filled_order, matched_order)
            if book_logger.isEnabledFor(10):
                book_logger.debug('SENT: notifications of order execution to agents {} and {} for orders {} and {}', self._orders._get_u(filled_order, 0), self._orders._get_u(matched_order, 0), self._orders._get_u(filled_order, 5), self._orders._get_u(matched_order, 5))
            self._send(self._orders._get_u(matched_order, 0), self._messages._new_u(9, matched_order, None, None, None, None, None, None, None))
            self._send(self._orders._get_u(order, 0), self._messages._new_u(9, filled_order, None, None, None, None, None, None, None))
            if self._owner._slot_book_logging == True:
                self._append_book_log2()
            self._orders._release_u(filled_order)
            return matched_order

    cdef object _enter_order(self, uint64_t order, metadata=None, quiet=False):
        cdef uint64_t hidden_order, visible_order
        cdef NativeLevel price_level
        if self._orders._get_u(order, 10) and (metadata is None or metadata == {} or 'ptc_hidden' not in metadata):
            hidden_order = self._orders._clone_u(order)
            visible_order = self._orders._clone_u(order)
            self._orders._set_u(hidden_order, 9, True)
            self._orders._set_u(hidden_order, 8, self._orders._get_u(hidden_order, 8) + (1 if self._orders._get_u(order, 4).is_bid() else -1))
            hidden_order_metadata = dict(ptc_hidden=True, ptc_other_half=visible_order)
            visible_order_metadata = dict(ptc_hidden=False, ptc_other_half=hidden_order)
            self._enter_order(hidden_order, hidden_order_metadata, True)
            self._enter_order(visible_order, visible_order_metadata, quiet)
            return
        book = self._slot_bids if self._orders._get_u(order, 4).is_bid() else self._slot_asks
        if len(book) == 0:
            book.append(NativeLevel([(order, metadata or {})], self._orders))
        elif (<NativeLevel>book[-1])._order_has_worse_price(order):
            book.append(NativeLevel([(order, metadata or {})], self._orders))
        else:
            for (i, price_level) in enumerate(book):
                if price_level._order_has_better_price(order):
                    book.insert(i, NativeLevel([(order, metadata or {})], self._orders))
                    break
                elif price_level._order_has_equal_price(order):
                    (<NativeLevel>book[i])._add_order(order, metadata or {})
                    break
        if quiet == False:
            self._slot_history.append(dict(time=self._owner._slot_current_time, type='LIMIT', order_id=self._orders._get_u(order, 5), agent_id=self._orders._get_u(order, 0), side=self._orders._get_u(order, 4).value, quantity=self._orders._get_u(order, 3), price=self._orders._get_u(order, 8)))
        if self._owner._slot_book_logging == True and quiet == False:
            self._append_book_log2()

        self._orders._release_u(order)

    cdef object _cancel_order(self, uint64_t order, tag=None, cancellation_metadata=None, quiet=False):
        cdef uint64_t cancelled_order
        cdef NativeLevel price_level
        book = self._slot_bids if self._orders._get_u(order, 4).is_bid() else self._slot_asks
        if not book:
            return False
        for (i, price_level) in enumerate(book):
            if not price_level._order_has_equal_price(order):
                continue
            cancelled_order_result = price_level._remove_order(self._orders._get_u(order, 5))
            if cancelled_order_result is not None:
                (cancelled_order, metadata) = cancelled_order_result
                if price_level._is_empty():
                    del book[i]
                if book_logger.isEnabledFor(10):
                    book_logger.debug('CANCELLED: order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order cancellation to agent {} for order {}', self._orders._get_u(cancelled_order, 0), self._orders._get_u(cancelled_order, 5))
                if self._orders._get_u(cancelled_order, 10):
                    self._cancel_order(metadata['ptc_other_half'], None, None, True)
                if not quiet:
                    self._slot_history.append(dict(time=self._owner._slot_current_time, type='CANCEL', order_id=self._orders._get_u(cancelled_order, 5), tag=tag, metadata=cancellation_metadata if tag == 'auctionFill' else None))
                    self._send(self._orders._get_u(order, 0), self._messages._new_u(11, cancelled_order, None, None, None, None, None, None, None))
                self._slot_last_update_ts = self._owner._slot_current_time
                if self._owner._slot_book_logging == True and quiet == False:
                    self._append_book_log2()
                self._orders._release_u(cancelled_order)
                return True
        return False

    cdef object _modify_order(self, order, new_order):
        raise ValueError("unsupported book method escaped whole-input arena admission: _modify_order")

    cdef object _partial_cancel_order(self, order, quantity, tag=None, cancellation_metadata=None):
        raise ValueError("unsupported book method escaped whole-input arena admission: _partial_cancel_order")

    cdef object _replace_order(self, agent_id, old_order, new_order):
        raise ValueError("unsupported book method escaped whole-input arena admission: _replace_order")

    cdef object _append_book_log2(self):
        cdef NativeLevel level
        if _observer.STATE is None:
            row = {'QuoteTime': self._owner._slot_current_time, 'bids': np.array(self._get_l2_bid_data(self._owner._slot_book_log_depth)), 'asks': np.array(self._get_l2_ask_data(self._owner._slot_book_log_depth))}
            self._slot_book_log2.append(row)
            return
        depth = self._owner._slot_book_log_depth
        bids = []
        for level in self._slot_bids[:depth]:
            if level._total_quantity() > 0:
                bids = [None]
                break
        asks = []
        for level in self._slot_asks[:depth]:
            if level._total_quantity() > 0:
                asks = [None]
                break
        self._slot_book_log2.append({'QuoteTime': self._owner._slot_current_time, 'bids': bids, 'asks': asks})

    cdef object _get_l1_bid_data(self):
        if len(self._slot_bids) == 0:
            return None
        index = 0
        while not (<NativeLevel>self._slot_bids[index])._total_quantity() > 0:
            index += 1
        return ((<NativeLevel>self._slot_bids[0])._slot_price, (<NativeLevel>self._slot_bids[0])._total_quantity())

    cdef object _get_l1_ask_data(self):
        if len(self._slot_asks) == 0:
            return None
        index = 0
        while not (<NativeLevel>self._slot_asks[index])._total_quantity() > 0:
            index += 1
        return ((<NativeLevel>self._slot_asks[index])._slot_price, (<NativeLevel>self._slot_asks[index])._total_quantity())

    cdef object _get_l2_bid_data(self, depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_bids[:depth]:
            rows.append((price_level._slot_price, price_level._total_quantity()))
        return list(filter(_positive_row, rows))

    cdef object _get_l2_ask_data(self, depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_asks[:depth]:
            rows.append((price_level._slot_price, price_level._total_quantity()))
        return list(filter(_positive_row, rows))

    cdef object _get_l3_bid_data(self, depth=sys.maxsize):
        cdef uint64_t order
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_bids[:depth]:
            quantities = []
            for (order, _) in price_level._slot_visible_orders:
                quantities.append(self._orders._get_u(order, 3))
            rows.append((price_level._slot_price, quantities))
        return rows

    cdef object _get_l3_ask_data(self, depth=sys.maxsize):
        cdef uint64_t order
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_asks[:depth]:
            quantities = []
            for (order, _) in price_level._slot_visible_orders:
                quantities.append(self._orders._get_u(order, 3))
            rows.append((price_level._slot_price, quantities))
        return rows

    cdef object _get_transacted_volume(self, lookback_period='10min'):
        window_start = self._owner._slot_current_time - str_to_ns(lookback_period)
        buy_transacted_volume = 0
        sell_transacted_volume = 0
        for (time, volume) in reversed(self._slot_buy_transactions):
            if time < window_start:
                break
            buy_transacted_volume += volume
        for (time, volume) in reversed(self._slot_sell_transactions):
            if time < window_start:
                break
            sell_transacted_volume += volume
        return (buy_transacted_volume, sell_transacted_volume)

    cdef object _get_imbalance(self):
        cdef NativeLevel price_level
        bid_quantities = []
        for price_level in self._slot_bids:
            bid_quantities.append(price_level._total_quantity())
        bid_vol = sum(bid_quantities)
        ask_quantities = []
        for price_level in self._slot_asks:
            ask_quantities.append(price_level._total_quantity())
        ask_vol = sum(ask_quantities)
        if bid_vol == ask_vol:
            return (0, None)
        elif bid_vol == 0:
            return (1.0, Side.ASK)
        elif ask_vol == 0:
            return (1.0, Side.BID)
        elif bid_vol < ask_vol:
            return (1 - bid_vol / ask_vol, Side.ASK)
        else:
            return (1 - ask_vol / bid_vol, Side.BID)

    cdef object _get_L1_snapshots(self):
        best_bids = []
        best_asks = []
        for d in self._slot_book_log2:
            best_bids.append([d['QuoteTime']] + _safe_first(d['bids']).tolist())
            best_asks.append([d['QuoteTime']] + _safe_first(d['asks']).tolist())
        best_bids = np.array(best_bids)
        best_asks = np.array(best_asks)
        return {'best_bids': best_bids, 'best_asks': best_asks}

    cdef object _bids_padding(self, book, nlevels):
        n = book.shape[0]
        if n == 0:
            return np.zeros((nlevels, 2), dtype=int)
        if n >= nlevels:
            return book[:nlevels, :]
        else:
            lowestprice = book[-1, 0] if len(book.shape) == 2 else book[0]
            npad = nlevels - n
            pad = np.transpose(np.array([-1 + np.arange(lowestprice, lowestprice - npad, -1, dtype=int), np.zeros(npad, dtype=int)]))
            if len(pad.shape) == 1:
                pad = pad.reshape(1, 2)
            return np.concatenate([book, pad])

    cdef object _asks_padding(self, book, nlevels):
        n = book.shape[0]
        if n == 0:
            return np.zeros((nlevels, 2), dtype=int)
        if n >= nlevels:
            return book[:nlevels, :]
        else:
            highestprice = book[-1, 0] if len(book.shape) == 2 else book[0]
            npad = nlevels - n
            pad = np.transpose(np.array([1 + np.arange(highestprice, highestprice + npad, 1, dtype=int), np.zeros(npad, dtype=int)]))
            if len(pad.shape) == 1:
                pad = pad.reshape(1, 2)
            return np.concatenate([book, pad])

    cdef object _get_L2_snapshots(self, nlevels):
        (times, bids, asks) = ([], [], [])
        for x in self._slot_book_log2:
            times.append(x['QuoteTime'])
            bids.append(self.bids_padding(x['bids'], nlevels))
            asks.append(self.asks_padding(x['asks'], nlevels))
        bids = np.array(bids)
        asks = np.array(asks)
        times = np.array(times)
        return {'times': times, 'bids': bids, 'asks': asks}

    cdef object _get_l3_itch(self):
        history_l3 = pd.DataFrame(self._slot_history)
        history_l3.loc[history_l3.tag == 'auctionFill', 'type'] = 'EXEC'
        history_l3.loc[history_l3.tag == 'auctionFill', 'quantity'] = history_l3.loc[history_l3.tag == 'auctionFill', 'metadata'].apply(_itch_quantity)
        history_l3.loc[history_l3.tag == 'auctionFill', 'price'] = history_l3.loc[history_l3.tag == 'auctionFill', 'metadata'].apply(_itch_price)
        history_l3['printable'] = np.nan
        history_l3['stock'] = np.nan
        if not 'REPLACE' in history_l3.type.unique():
            history_l3['new_order_id'] = np.nan
            history_l3['old_order_id'] = np.nan
        history_l3.loc[history_l3.type == 'REPLACE', 'order_id'] = history_l3.loc[history_l3.type == 'REPLACE', 'old_order_id']
        history_l3.loc[history_l3.type == 'EXEC', 'side'] = np.nan
        history_l3['type'] = history_l3['type'].replace({'LIMIT': 'ADD', 'CANCEL_PARTIAL': 'CANCEL', 'CANCEL': 'DELETE', 'EXEC': 'EXECUTE'})
        history_l3['side'] = history_l3['side'].replace({'ASK': 'S', 'BID': 'B'})
        history_l3['time'] = history_l3['time'] - ns_date(history_l3['time'])
        history_l3['price'] = history_l3['price'] * 100
        history_l3 = history_l3[['time', 'stock', 'type', 'order_id', 'side', 'quantity', 'price', 'new_order_id', 'printable']]
        history_l3 = history_l3.rename(columns={'time': 'timestamp', 'order_id': 'reference', 'new_order_id': 'new_reference', 'quantity': 'shares'})
        return history_l3

    cdef object _pretty_print(self, silent=True):
        assert self._slot_last_trade is not None
        book = '{} order book as of {}\n'.format(self._slot_symbol, self._owner._slot_current_time)
        book += 'Last trades: simulated {:d}, historical {:d}\n'.format(self._slot_last_trade, self._owner._slot_oracle.observe_price(self._slot_symbol, self._owner._slot_current_time, sigma_n=0, random_state=self._owner._slot_random_state))
        book += '{:10s}{:10s}{:10s}\n'.format('BID', 'PRICE', 'ASK')
        book += '{:10s}{:10s}{:10s}\n'.format('---', '-----', '---')
        for (quote, volume) in self._get_l2_ask_data(self._owner._slot_book_log_depth)[-1::-1]:
            book += '{:10s}{:10s}{:10s}\n'.format('', '{:d}'.format(quote), '{:d}'.format(volume))
        for (quote, volume) in self._get_l2_bid_data(self._owner._slot_book_log_depth):
            book += '{:10s}{:10s}{:10s}\n'.format('{:d}'.format(volume), '{:d}'.format(quote), '')
        if silent:
            return book
        else:
            print(book)
            return None

    cdef object _send(self, recipient_id, message):
        if self._scheduler is None:
            return self._owner._send_message(recipient_id, message)
        return self._owner._send_message(recipient_id, message)

    def bind_scheduler(self, scheduler):
        cdef ChainScheduler typed
        if type(scheduler) is not ChainScheduler:
            raise ValueError("same-extension book scheduler required")
        typed = scheduler
        if typed.kernel is not self._owner._slot_kernel:
            raise ValueError("book scheduler/kernel differs")
        if self._scheduler is not None and self._scheduler is not typed:
            raise ValueError("book scheduler already bound")
        self._scheduler = typed
        self._orders = typed.orders
        self._messages = typed.messages


cdef class FlatHeap:
    def __init__(self, queue):
        self.queue = queue
    def empty(self):
        return not self.queue
    def qsize(self):
        return len(self.queue)

cdef class ColumnLedger:
    def __init__(self):
        self.c0, self.c1, self.c2 = [], [], []
        self.c3, self.c4, self.c5 = [], [], []
        self.c6, self.c7, self.c8 = [], [], []
        self.columns = (self.c0, self.c1, self.c2, self.c3, self.c4, self.c5, self.c6, self.c7, self.c8)
    def __len__(self):
        return len(self.c0)
    cdef void _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns, latency_ns, msg_type, order_id, causal_parent) except *:
        self.c0.append(message_id)
        self.c1.append(src_id)
        self.c2.append(dst_id)
        self.c3.append(t_send_ns)
        self.c4.append(t_recv_ns)
        self.c5.append(latency_ns)
        self.c6.append(msg_type)
        self.c7.append(order_id)
        self.c8.append(causal_parent)

cdef class ChainScheduler:
    def __init__(self, kernel, ledger):
        self.kernel = kernel
        self.ledger = ledger
        self.orders = OrderArena()
        self.messages = MessageArena(self.orders)
        self.heap = DeliveryHeap(self.messages)
    def run(self, agent_actions=None):
        return self._run(agent_actions)
    def send(self, sender_id, recipient_id, message, delay=0):
        return self._send(sender_id, recipient_id, message, delay)
    def set_wakeup(self, sender_id, requested_time=None):
        return self._set_wakeup(sender_id, requested_time)
    cdef object _deliver_wakeup(self, recipient, current_time):
        cdef NativeTrader trader
        cdef NativeExchange exchange
        if type(recipient) is NativeTrader:
            trader = recipient
            trader._require_bound()
            return trader._wakeup(current_time)
        if type(recipient) is NativeExchange:
            exchange = recipient
            if not exchange._bound:
                raise ValueError("exchange authority unbound")
            return exchange._wakeup(current_time)
        raise ValueError("unadmitted receiver in authoritative roster")
    cdef object _deliver_message(self, recipient, current_time, sender_id, message):
        cdef NativeTrader trader
        cdef NativeExchange exchange
        if type(recipient) is NativeTrader:
            trader = recipient
            trader._require_bound()
            return trader._receive_message(current_time, sender_id, message)
        if type(recipient) is NativeExchange:
            exchange = recipient
            if not exchange._bound:
                raise ValueError("exchange authority unbound")
            return exchange._receive_message(current_time, sender_id, message)
        raise ValueError("unadmitted receiver in authoritative roster")


    cdef object _run(self, agent_actions=None):
        kernel=self.kernel
        if agent_actions is not None: raise ValueError("whole arena CLI admits no gym actions")
        while not self.heap.empty() and kernel.current_time and kernel.current_time <= kernel.stop_time:
            (kernel.current_time,sender_id,recipient_id,message_id,message)=self.heap._pop()
            assert kernel.current_time is not None
            try:
                if kernel.ttl_messages % 100000 == 0 and kernel_logger.isEnabledFor(20):
                    kernel_logger.info('--- Simulation time: {}, messages processed: {:,}, wallclock elapsed: {:.2f}s ---'.format(fmt_ts(kernel.current_time),kernel.ttl_messages,(datetime.now()-kernel.event_queue_wall_clock_start).total_seconds()))
                kernel.ttl_messages += 1
                kernel.current_agent_additional_delay=0
                if kernel.agent_current_times[recipient_id] > kernel.current_time:
                    self.heap._push(kernel.agent_current_times[recipient_id],sender_id,recipient_id,message)
                    continue
                kernel.agent_current_times[recipient_id]=kernel.current_time
                if self.messages._kind(message)==1:
                    kernel._current_causal_uid=message_id
                    kernel._deliver_seq_by_key[message_id,recipient_id]=kernel._deliver_seq
                    kernel._deliver_seq+=1
                    self.ledger._append(message_id,recipient_id,recipient_id,None,kernel.current_time,0,'AGENT_WAKEUP',None,None)
                    wakeup_result=self._deliver_wakeup(kernel.agents[recipient_id],kernel.current_time)
                    kernel.agent_current_times[recipient_id]+=kernel.agent_computation_delays[recipient_id]+kernel.current_agent_additional_delay
                    if wakeup_result is not None: return {'done':False,'result':wakeup_result}
                else:
                    kernel.agent_current_times[recipient_id]+=kernel.agent_computation_delays[recipient_id]+kernel.current_agent_additional_delay
                    kernel._current_causal_uid=message_id
                    kernel._deliver_seq_by_key[message_id,recipient_id]=kernel._deliver_seq
                    kernel._deliver_seq+=1
                    self._deliver_message(kernel.agents[recipient_id],kernel.current_time,sender_id,message)
            finally:
                self.messages._release(message)
        return {'done':True,'result':None}

    cdef object _send(self, sender_id, recipient_id, message, delay=0):
        cdef uint64_t order
        kernel=self.kernel
        sent_time=kernel.current_time+kernel.agent_computation_delays[sender_id]+kernel.current_agent_additional_delay+delay
        if kernel.agent_latency_model is not None:
            latency=kernel.agent_latency_model.get_latency(sender_id=sender_id,recipient_id=recipient_id)
            deliver_at=sent_time+int(latency)
        else:
            latency=kernel.agent_latency[sender_id][recipient_id]
            noise=kernel.random_state.choice(len(kernel.latency_noise),p=kernel.latency_noise)
            deliver_at=sent_time+int(latency+noise)
        self.heap._push(deliver_at,sender_id,recipient_id,message)
        order=self.messages._order_u(message)
        self.ledger._append(self.messages._id(message),sender_id,recipient_id,sent_time,deliver_at,deliver_at-sent_time,self.messages._name(message),None if order==0 else self.orders._get_u(order,5),kernel._current_causal_uid)

    cdef object _set_wakeup(self, sender_id, requested_time=None):
        kernel=self.kernel
        if requested_time is None: requested_time=kernel.current_time+1
        if kernel.current_time and requested_time<kernel.current_time:
            raise ValueError('set_wakeup() called with requested time not in future','current_time:',kernel.current_time,'requested_time:',requested_time)
        handle=self.messages._new_u(1, 0, None, None, None, None, None, None, None)
        try: self.heap._push(requested_time,sender_id,sender_id,handle)
        finally: self.messages._release(handle)



def cold_order_dict(owner,values,memo):
    cdef NativeTrader typed=owner
    result={}
    for key,handle in values.items():result[key]=typed._orders.cold_materialize(handle,memo)
    return result

def cold_level_fields(owner,memo):
    cdef NativeLevel typed=owner
    visible=[]
    hidden=[]
    for handle,metadata in typed._slot_visible_orders:
        visible.append((typed._orders.cold_materialize(handle,memo),metadata))
    for handle,metadata in typed._slot_hidden_orders:
        hidden.append((typed._orders.cold_materialize(handle,memo),metadata))
    return {"visible_orders":visible,"hidden_orders":hidden,"price":typed._slot_price,"side":typed._slot_side}


def control_typed_handle_checks():
    """Future finite control only; never invoked by production CLI or preparation."""
    cdef OrderArena arena=OrderArena()
    cdef MessageArena messages=MessageArena(arena)
    cdef uint64_t original=0
    cdef uint64_t clone=0
    cdef uint64_t reused=0
    cdef uint64_t message_order=0
    cdef uint64_t stale_clone=0
    cdef uint64_t stale_original=0
    cdef uint64_t invalid_typed=0
    cdef uint64_t created=0
    cdef object message=None
    from abides_markets.orders import Order
    original_counter=Order._order_id_counter
    from abides_core.message import Message
    original_message_counter=Message._Message__message_id_counter
    cases=[]
    owned=[]
    try:
        original=arena._new_limit_u(1,1,"ABM",10,Side.BID,100,91,False,False,False,False,None)
        cases.append({"case":"valid_checked_scalar","passed":arena._checked_handle(int(original))==original and arena._get(int(original),3)==arena._get_u(original,3)})
        for invalid in (None,True,False,0,1,-1,1<<64,1.0,"1"):
            try:arena._checked_handle(invalid)
            except ValueError as error:
                cases.append({"case":"cold_invalid_type_range","input_repr":repr(invalid),"passed":str(error)=="invalid native order handle"})
            else:cases.append({"case":"cold_invalid_type_range","input_repr":repr(invalid),"passed":False})
        for invalid in (0,1,(1<<32)|1024,(1<<32)|4294967295):
            invalid_typed=invalid
            try:arena._get_u(invalid_typed,3)
            except ValueError as error:
                cases.append({"case":"typed_invalid_zero_generation_index","input_repr":repr(invalid),"passed":str(error)=="invalid native order handle"})
            else:cases.append({"case":"typed_invalid_zero_generation_index","input_repr":repr(invalid),"passed":False})
        arena._set_u(original,7,{"nested":[1]})
        clone=arena._clone_u(original)
        arena._set_u(clone,3,4)
        cases.append({"case":"distinct_mutable_clone","passed":clone!=original and arena._get_u(original,3)==10 and arena._get_u(clone,3)==4})
        arena._get_u(clone,7)["nested"].append(2)
        cases.append({"case":"clone_tag_deepcopy","passed":arena._get_u(original,7)=={"nested":[1]} and arena._get_u(clone,7)=={"nested":[1,2]}})
        stale_clone=clone
        arena._release_u(clone)
        clone=0
        try:arena._get_u(stale_clone,3)
        except ValueError as error:cases.append({"case":"typed_stale","passed":str(error)=="stale native order handle"})
        else:cases.append({"case":"typed_stale","passed":False})
        reused=arena._new_limit_u(1,1,"ABM",6,Side.ASK,101,92,False,False,False,False,None)
        cases.append({"case":"generation_reuse","passed":(<uint32_t>reused)==(<uint32_t>stale_clone) and reused!=stale_clone and arena._get_u(reused,3)==6})
        arena._release_u(reused)
        reused=0
        for i in range(1100):
            created=arena._new_limit_u(1,1,"ABM",i,Side.BID,100,1000+i,False,False,False,False,None)
            owned.append(int(created))
            created=0
        cases.append({"case":"stable_chunks_growth","passed":arena._get_u(original,3)==10 and arena.statistics()["order_slots"]>=2048 and arena._get(owned[-1],3)==1099})
        message=messages._new_u(1,0,None,None,None,None,None,None,12344)
        cases.append({"case":"message_no_order_public_None","passed":messages._order_u(message)==0 and messages._order(message) is None})
        messages._release(message)
        message=None
        for kind,bad_order,expected in ((0,True,"unsupported whole-episode message kind"),(14,int(original),"unsupported whole-episode message kind"),(7,True,"invalid native order handle")):
            try:message=messages._new(kind,bad_order,None,None,None,None,None,None,12343)
            except ValueError as error:
                cases.append({"case":"cold_message_exception_priority","kind":kind,"passed":str(error)==expected})
            else:
                cases.append({"case":"cold_message_exception_priority","kind":kind,"passed":False})
                messages._release(message)
                message=None
        message=messages._new_u(7,original,None,None,None,None,None,None,12345)
        message_order=messages._order_u(message)
        cases.append({"case":"message_order_C_handle","passed":message_order==original and messages._order(message)==int(original)})
        stale_original=original
        arena._release_u(original)
        original=0
        cases.append({"case":"message_owns_released_local","passed":arena._get_u(message_order,3)==10})
        messages._release(message)
        message=None
        try:arena._checked_handle(int(stale_original))
        except ValueError as error:cases.append({"case":"message_final_release_stale","passed":str(error)=="stale native order handle"})
        else:cases.append({"case":"message_final_release_stale","passed":False})
        while owned:arena._release(owned.pop())
        cases.append({"case":"full_live_release","passed":arena.statistics()["live_orders"]==0 and messages.statistics()["live_messages"]==0})
        cases.append({"case":"explicit_ids_no_constructor_counter","passed":Order._order_id_counter==original_counter and Message._Message__message_id_counter==original_message_counter})
        return {"schema":"t3-typed-order-handle-finite-controls-v1","control_only":True,"source_only":False,"cases":cases,"all_passed":all(row["passed"] for row in cases),"rankable":False,"speed_claim":False}
    finally:
        if message is not None:messages._release(message)
        if created:arena._release_u(created)
        if clone:arena._release_u(clone)
        if reused:arena._release_u(reused)
        if original:arena._release_u(original)
        while owned:arena._release(owned.pop())

def _primitive_event(event):
    return all(type(key) is str and type(value) in (str, int, float, bool, type(None)) for key, value in event.items())
def _average_transaction_price(orders):
    return round(sum(order.quantity * order.fill_price for order in orders) / sum(order.quantity for order in orders), 2)
def _dropout_invalid(book, limits):
    return any(type(row.get('QuoteTime')) not in (int, np.int64) or not limits.min <= row['QuoteTime'] <= limits.max or type(row.get('bids')) not in (list, np.ndarray) or type(row.get('asks')) not in (list, np.ndarray) for row in book)
def _itch_quantity(x):
    return x['quantity']
def _itch_price(x):
    return x['price']
def _safe_first(x):
    return x[0] if len(x) > 0 else np.array([None, None])


def control_primitive_heap_keys():
    """Finite future Linux checks only; never called in a measured market."""
    cdef OrderArena orders
    cdef MessageArena messages
    cdef DeliveryHeap heap
    cases=[]
    order_counter=Order._order_id_counter
    message_counter=Message._Message__message_id_counter
    # Small patterns retain complete saved physical heaps. The large growth
    # case checks full rows live and saves only counts and popped rows.
    patterns=[
        ("four_key_lexicographic",[(7,2,1,9),(7,1,9,3),(7,1,8,4),(6,9,9,5),(7,1,8,2)]),
        ("all_equal_right_child",[(4,2,3,8)]*31),
        ("equal_time_src_dst",[(9,1,1,i%4) for i in range(33)]),
        ("int64_edges",[tuple(edge if j==field else 0 for j in range(4)) for field in range(4) for edge in (-(1<<63),(1<<63)-1,-1)]),
        ("overflow_each_key",[tuple(edge if j==field else 0 for j in range(4)) for field in range(4) for edge in (-(1<<63)-1,1<<63)]),
        ("int_subclass_fallback",[tuple(_HeapControlInt(j+2) if j==field else 0 for j in range(4)) for field in range(4)]),
        ("bignum_fallback",[((1<<63)+i,0,0,i+1) for i in (3,1,4,0,2)]+[(-(1<<80),0,0,99)]),
        ("bool_fallback",[(True,False,0,1),(1,0,0,2),(False,1,1,3),(0,True,1,4)]),
        ("numpy_fallback",[(np.int64(3),0,0,1),(np.int64(-4),0,0,2),(3,np.int32(0),0,3)]),
        ("mixed_float_fallback",[(3.0,0,0,1),(2,0,0,2),(-0.0,0,0,3),(0.0,0,0,4)]),
        ("resize_2050",[(i%9,(i//9)%7,(i//63)%5,i%11) for i in range(2050)]),
        ("numpy_int64_timestamp_edges",[(np.int64(edge),0,0,i) for i,edge in enumerate((-(1<<63),(1<<63)-1,-1,0,1))]),
        ("mixed_timestamp_53bit",[((np.int64(value) if i%2 else value),0,0,i) for i,value in enumerate((-(1<<53)-1,-(1<<53),-(1<<53)+1,(1<<53)-1,1<<53,(1<<53)+1,(1<<53)+2))]),
        ("mixed_timestamp_63bit",[((np.int64(value) if i%2 else value),0,0,i) for i,value in enumerate((-(1<<63),-(1<<63)+1,-1,0,1,(1<<63)-2,(1<<63)-1))]),
        ("mixed_timestamp_equal_right_child",[((np.int64(1<<53) if i%2 else 1<<53),2,3,8) for i in range(31)]),
        ("numpy_non_time_keys_fallback",[tuple(np.int64(3) if field==j else 0 for j in range(4)) for field in (1,2,3)]),
        ("numpy_other_timestamp_fallback",[(np.int32(-3),0,0,1),(np.uint64(4),0,0,2),(np.float64(5),0,0,3)]),
        ("numpy_timestamp_subclass_fallback",[(_HeapControlNPInt64(-2),0,0,1),(np.int64(3),0,0,2),(-1,0,0,3)]),
        ("mixed_timestamp_overflow_fallback",[(np.int64((1<<63)-1),0,0,1),(1<<63,0,0,2),(-(1<<63)-1,0,0,3),(np.int64(-(1<<63)),0,0,4)])]
    for name,values in patterns:
        orders=OrderArena();messages=MessageArena(orders);heap=DeliveryHeap(messages)
        reference=[];handles={};push_witness=[];pop_witness=[];passed=True;cache_witness=[]
        original_push_witness=[];original_pop_witness=[]
        try:
            for when,src,dst,mid in values:
                handle=messages._new_u(1,0,None,None,None,None,None,None,mid)
                try:
                    heap._push(when,src,dst,handle)
                    value=object.__new__(WakeupMsg);value.message_id=mid
                    handles[id(value)]=handle
                    # Exactly original four-tuple comparison. Handles never
                    # become an extra tie key in the control oracle.
                    heapq.heappush(reference,(when,src,dst,value))
                finally:
                    messages._release(handle)
                actual=heap.queue;expected_rows=_primitive_heap_reference_rows(reference,handles)
                passed=passed and actual==expected_rows
                passed=passed and all(actual[i][j] is expected_rows[i][j] for i in range(len(reference)) for j in range(4))
                expected_valid=sum(_primitive_heap_cache_expected(row) for row in actual)
                diagnostic=heap.cold_key_cache_diagnostics()
                passed=passed and diagnostic=={"rows":len(actual),"valid_primitive_rows":expected_valid}
                cache_witness.append(diagnostic)
                push_witness.append([_primitive_heap_encode_row(row) for row in actual] if len(values)<40 else {"rows":len(actual),"live_full_rows_compared":True})
                if len(values)<40:
                    original_push_witness.append([_primitive_heap_encode_row(row) for row in expected_rows])
            while reference:
                expected=_primitive_heap_reference_rows([heapq.heappop(reference)],handles)[0]
                actual=heap._pop()
                try:
                    passed=passed and actual==expected and all(actual[j] is expected[j] for j in range(4))
                    remaining=heap.queue;expected_remaining=_primitive_heap_reference_rows(reference,handles)
                    passed=passed and remaining==expected_remaining
                    passed=passed and all(remaining[i][j] is expected_remaining[i][j] for i in range(len(remaining)) for j in range(4))
                    pop_witness.append({"popped":_primitive_heap_encode_row(actual),"remaining_physical_rows":[_primitive_heap_encode_row(row) for row in remaining] if len(values)<40 else {"rows":len(remaining),"live_full_rows_compared":True}})
                    if len(values)<40:
                        original_pop_witness.append({"popped":_primitive_heap_encode_row(expected),"remaining_physical_rows":[_primitive_heap_encode_row(row) for row in expected_remaining]})
                finally:
                    messages._release(actual[4])
            passed=passed and heap.empty() and heap.qsize()==0 and messages.statistics()["live_messages"]==0
            cases.append({"case":name,"passed":bool(passed),"inserted":len(values),"push_physical_witness":push_witness,"cache_witness":cache_witness,"pop_witness":pop_witness,
                "original_push_physical_witness":original_push_witness,"original_pop_witness":original_pop_witness})
        finally:
            while not heap.empty():
                actual=heap._pop();messages._release(actual[4])
    # Import preserves the physical heap built by the original heapq route.
    orders=OrderArena();messages=MessageArena(orders);heap=DeliveryHeap(messages)
    original=[]
    for i in range(25):
        value=object.__new__(WakeupMsg);value.message_id=i%5
        original.append((i%4,i%3,i%2,value))
    heapq.heapify(original)
    heap.import_rows(original)
    observed=heap.queue
    handles={id(value):observed[i][4] for i,(when,src,dst,value) in enumerate(original)}
    reference=list(original)
    expected_initial=_primitive_heap_reference_rows(reference,handles)
    passed=observed==expected_initial and all(observed[i][j] is expected_initial[i][j] for i in range(len(observed)) for j in range(4))
    passed=passed and heap.cold_key_cache_diagnostics()=={"rows":25,"valid_primitive_rows":25}
    initial=[_primitive_heap_encode_row(row) for row in observed]
    popped=[]
    try:
        while reference:
            expected=_primitive_heap_reference_rows([heapq.heappop(reference)],handles)[0];actual=heap._pop()
            try:
                remaining=heap.queue;expected_remaining=_primitive_heap_reference_rows(reference,handles)
                passed=passed and actual==expected and all(actual[j] is expected[j] for j in range(4)) and remaining==expected_remaining
                passed=passed and all(remaining[i][j] is expected_remaining[i][j] for i in range(len(remaining)) for j in range(4))
                popped.append({"popped":_primitive_heap_encode_row(actual),"remaining_physical_rows":[_primitive_heap_encode_row(row) for row in remaining]})
            finally:messages._release(actual[4])
        passed=passed and messages.statistics()["live_messages"]==0
        cases.append({"case":"original_heap_physical_import","passed":bool(passed),"initial":initial,"pop_witness":popped})
    finally:
        while not heap.empty():actual=heap._pop();messages._release(actual[4])
    # The actual original initialize queue is mixed; preserve its physical
    # imported row arrangement and original scalar identities on every pop.
    orders=OrderArena();messages=MessageArena(orders);heap=DeliveryHeap(messages)
    original=[]
    times=(-(1<<63),-(1<<53)-1,-1,0,(1<<53)+1,(1<<63)-1)
    for i in range(25):
        value=object.__new__(WakeupMsg);value.message_id=i%5
        timestamp=times[i%6]
        if i%2:timestamp=np.int64(timestamp)
        original.append((timestamp,i%3,i%2,value))
    heapq.heapify(original)
    heap.import_rows(original)
    observed=heap.queue
    handles={id(value):observed[i][4] for i,(when,src,dst,value) in enumerate(original)}
    reference=list(original)
    expected_initial=_primitive_heap_reference_rows(reference,handles)
    passed=observed==expected_initial and all(observed[i][j] is expected_initial[i][j] for i in range(len(observed)) for j in range(4))
    initial_cache=heap.cold_key_cache_diagnostics()
    passed=passed and initial_cache=={"rows":25,"valid_primitive_rows":25}
    initial=[_primitive_heap_encode_row(row) for row in observed];popped=[]
    try:
        while reference:
            expected=_primitive_heap_reference_rows([heapq.heappop(reference)],handles)[0];actual=heap._pop()
            try:
                remaining=heap.queue;expected_remaining=_primitive_heap_reference_rows(reference,handles)
                passed=passed and actual==expected and all(actual[j] is expected[j] for j in range(4)) and remaining==expected_remaining
                passed=passed and all(remaining[i][j] is expected_remaining[i][j] for i in range(len(remaining)) for j in range(4))
                popped.append({"popped":_primitive_heap_encode_row(actual),"remaining_physical_rows":[_primitive_heap_encode_row(row) for row in remaining]})
            finally:messages._release(actual[4])
        passed=passed and messages.statistics()["live_messages"]==0
        cases.append({"case":"mixed_original_heap_physical_import","passed":bool(passed),"initial":initial,"initial_cache":initial_cache,"pop_witness":popped})
    finally:
        while not heap.empty():actual=heap._pop();messages._release(actual[4])
    cases.append({"case":"numpy_C_API_exact_scalar_authority","passed":np.__version__=="1.26.4" and np.int64 is <object>t3_heap_numpy_int64_type() and t3_heap_numpy_long_bits()==64,
        "numpy_version":np.__version__,"long_bits":int(t3_heap_numpy_long_bits()),"C_API_type_is_np_int64":np.int64 is <object>t3_heap_numpy_int64_type()})
    cases.append({"case":"explicit_ids_leave_counters","passed":Order._order_id_counter==order_counter and Message._Message__message_id_counter==message_counter})
    return {"schema":"t3-delivery-heap-primitive-keys-finite-v3","cases":cases,"all_passed":all(row["passed"] for row in cases),"rankable":False,"speed_claim":False}


def _primitive_heap_reference_rows(rows,handles):
    return [(when,src,dst,value.message_id,handles[id(value)]) for when,src,dst,value in rows]


def _primitive_heap_cache_expected(row):
    return (type(row[0]) in (int,np.int64) and -(1<<63)<=row[0]<=(1<<63)-1
        and all(type(key) is int and -(1<<63)<=key<=(1<<63)-1 for key in row[1:4]))


def _primitive_heap_encode_row(row):
    result=[]
    for value in row[:4]:
        if type(value) is float:
            result.append({"type":"float","hex":value.hex()})
        else:
            result.append({"type":type(value).__name__,"value":str(value)})
    result.append(int(row[4]))
    return result


class _HeapControlInt(int):
    """Finite control scalar subclass; never instantiated by a market."""
    pass


class _HeapControlNPInt64(np.int64):
    """Unsupported scalar subtype witness; never instantiated by a market."""
    pass
