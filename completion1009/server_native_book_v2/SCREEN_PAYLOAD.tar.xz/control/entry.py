"""Identical full-entry driver for original/native book arms; proof on stdout."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

CANDIDATE = Path('/opt/book-screen/completion1009/candidates/native_book_owner_v2')
MARKER = 'T3_NATIVE_BOOK_SCREEN='
TIMING_SCOPE = 'CLI ENTRY_STARTED through Parquet/hash/events wall; both-arm proof serialization after single wall; batch wall includes member proof serialization'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('verb', choices=('simulate', 'simulate-batch'))
    parser.add_argument('--config')
    parser.add_argument('--out')
    parser.add_argument('--batch-dir')
    parser.add_argument('--out-dir')
    parser.add_argument('--mode', choices=('canonical_book', 'native_book', 'controls'), required=True)
    args = parser.parse_args()
    receipt = str(CANDIDATE / 'artifacts/build_v1/BUILD_RECEIPT.json')
    os.environ['T3_NATIVE_BOOK_RECEIPT'] = receipt
    sys.path.insert(0, str(CANDIDATE))
    if args.mode == 'controls':
        if (args.verb != 'simulate' or args.config != '/input/scenario.json'
                or args.out != '/output/trace.parquet' or args.batch_dir or args.out_dir
                or json.loads(Path(args.config).read_text()) != {'proof_command': 'native-book-finite-and-four-markets-v1'}):
            raise ValueError('fixed controls input required')
        completed = subprocess.run([sys.executable, '-B', str(CANDIDATE / 'full_controls.py'),
            '--receipt', receipt, '--out', '/output/controls'], cwd='/output', timeout=840)
        raise SystemExit(completed.returncode)
    single = args.verb == 'simulate'
    if single:
        if args.config != '/input/scenario.json' or args.out != '/output/trace.parquet' or args.batch_dir or args.out_dir:
            raise ValueError('fixed single paths required')
    elif args.batch_dir != '/input/scenarios' or args.out_dir != '/output' or args.config or args.out:
        raise ValueError('fixed batch paths required')
    spec = importlib.util.spec_from_file_location('agent', CANDIDATE / 'cli.py')
    entry = importlib.util.module_from_spec(spec)
    sys.modules['agent'] = entry
    spec.loader.exec_module(entry)
    entry.authenticate()
    # Load/authenticate the same extension in both arms so startup work is paired.
    entry.ensure_native_admission()
    mode = 'optimized' if args.mode == 'native_book' else 'baseline'
    result = (entry.simulate(args.config, args.out, mode, started=entry.ENTRY_STARTED) if single
        else entry.simulate_batch(args.batch_dir, args.out_dir, mode, started=entry.ENTRY_STARTED))
    print(MARKER + json.dumps({'schema': 't3-native-book-entry-v1', 'arm': args.mode,
        'events': result, 'cli_source': str(CANDIDATE / 'cli.py'),
        'entry_source': str(Path(__file__).resolve()), 'rankable': False,
        'timing_scope': TIMING_SCOPE}, sort_keys=True, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()
