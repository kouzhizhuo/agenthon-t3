"""Future actual private/public/failed-export latency lifecycle controls."""
import argparse
import json
from pathlib import Path
import sys
from cleanup_errors import attach, detail

HERE = Path(__file__).resolve().parent


class FiniteAbort(BaseException):
    pass


class FiniteSendQueue:
    def __init__(self, original, phase):
        self.original, self.phase = original, phase
    def put(self, item):
        if self.phase == 1:
            raise RuntimeError("finite send failure after latency before heap")
        self.original.put(item)
        if self.phase == 2:
            raise RuntimeError("finite send failure after heap before ledger")


class ForeignID:
    def __init__(self, callback):
        self.callback = callback
    def __eq__(self, other):
        self.callback()
        return False


def require(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh actual latency lifecycle evidence required")
    from production_cli import activate_paths
    activate_paths(args.runtime)
    from native_loader import load
    native = load(args.build, args.runtime)["dynamic_arena_chain"]
    import numpy as np
    # Saved evidence preserves NumPy scalar identity and its exact integer value.
    # This callback runs only after every live comparison/cleanup, at JSON save.
    def evidence_scalar(value):
        if type(value) is np.int64:
            return {"__t3_scalar__": {"type": "numpy.int64", "decimal": str(int(value))}}
        raise TypeError("unsupported saved evidence scalar: " + type(value).__module__ + "." + type(value).__qualname__)
    from latency_control_fixture import fixture, cleanup
    from noise_expression_controls import state, observed, pin
    modes = ("property-getter", "model-public-call", "same-model-setter", "new-model-setter", "property-delete",
             "owner-public-sample", "owner-RNG", "owner-snapshot", "double-export",
             "direct-scheduler-return", "kernel-runner-return", "kernel-terminate", "runner-BaseException",
             "foreign-IDs", "public-send", "kernel-public-send", "postdraw-before-heap", "postdraw-before-ledger",
             "failed-export-getter", "failed-export-setter", "failed-export-delete", "failed-model-restore",
             "primary-abort-export-failure")
    result = {"schema": "t3-light-typed-noise-latency-actual-native-lifecycle-controls-v1", "all_passed": False,
        "arms": ["original", "new", "new-repeat"], "cases": [], "build_receipt": pin(args.build / "BUILD_RECEIPT.json"),
        "source_receipt": pin(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"), "rankable": False,
        "speed_claim": False, "actual_original_initialize": True, "actual_owner_migration": True,
        "closed_retired_source_alias_contract": True, "full_market_runner_executed": False,
        "untested": ["arbitrary external raw/function/RNG aliases", "full market partial-return callback"],
        "actual_original_send_fault_queue_adapter": True}
    try:
        for mode in modes:
            arms = []
            for arm in result["arms"]:
                values = fixture(native, np, arm != "original")
                kernel, model, rng, owner = (values[name] for name in ("kernel", "model", "rng", "owner"))
                restore_export = restore_fields = None
                active_error = None
                cleanup_failures = []
                failures = [0]
                foreign_calls = [0]
                primary = FiniteAbort("finite controlled primary abort")
                primary_identity = [False]
                attached_cleanup = []
                initial = prelude = consumed = outcome = partial = send_before = send_after = None
                def fail(*args, **kwargs):
                    failures[0] += 1
                    raise RuntimeError("finite latency export failure")
                def original_sample():
                    return model.get_latency(sender_id=0, recipient_id=1)
                def private_sample():
                    return original_sample() if owner is None else native.control_latency_private_sample(owner, 0, 1)
                try:
                    initial = state(rng.get_state())
                    prelude = observed(private_sample)
                    consumed = state(rng.get_state() if owner is None else owner.control_private_state())
                    if owner is not None:
                        require(owner.diagnostics()["owned"] and values["raw_dict"] == {},
                                "integrated model must be private with old rawdict retired")
                    installed = None
                    if mode == "new-model-setter":
                        from abides_fork.config import ScenarioLatencyModel
                        installed = ScenarioLatencyModel(2, {"model": "uniform", "params": {"max_ns": 7}}, np.random.RandomState(198))
                    failed_mode = mode.startswith("failed-") or mode == "primary-abort-export-failure"
                    if failed_mode and owner is not None:
                        if mode == "failed-model-restore":
                            restore_fields = owner.control_replace_restore_callback(fail)
                        else:
                            restore_export = owner.control_replace_export_callback(fail)
                    def send_snapshot():
                        if owner is not None:
                            return native.control_latency_send_snapshot(kernel._chain_scheduler)
                        from abides_core.message import Message
                        names = ("message_id", "src_id", "dst_id", "t_send_ns", "t_recv_ns", "latency_ns", "msg_type", "order_id", "causal_parent")
                        return {"queue_keys": [(row[0], row[1][0], row[1][1], row[1][2].message_id) for row in kernel.messages.queue],
                            "ledger_rows": [tuple(row[name] for name in names) for row in kernel._msg_ledger],
                            "message_counter": Message._Message__message_id_counter, "native": None}
                    send_before = send_snapshot() if mode in ("public-send", "kernel-public-send") or mode.startswith("postdraw-") else None
                    def public_action():
                        if mode in ("property-getter", "failed-export-getter", "failed-model-restore"):
                            return kernel.agent_latency_model is model
                        if mode == "model-public-call":
                            return kernel.agent_latency_model.get_latency(0, 1)
                        if mode in ("same-model-setter", "failed-export-setter"):
                            kernel.agent_latency_model = model
                            return None
                        if mode == "new-model-setter":
                            kernel.agent_latency_model = installed
                            return None
                        if mode in ("property-delete", "failed-export-delete"):
                            del kernel.agent_latency_model
                            return None
                        if mode == "owner-public-sample":
                            return original_sample() if owner is None else owner.sample(0, 1)
                        if mode == "owner-RNG":
                            return rng is (rng if owner is None else owner.rng_identity())
                        if mode == "owner-snapshot":
                            if owner is None: rng.get_state()
                            else: owner.snapshot()
                            return None
                        if mode == "double-export":
                            if owner is not None:
                                owner.export_to_original(); owner.export_to_original()
                            return None
                        if mode in ("direct-scheduler-return", "kernel-runner-return"):
                            kernel.stop_time = kernel.current_time - 1
                            value = kernel.runner() if owner is None else (kernel._chain_scheduler.run() if mode == "direct-scheduler-return" else kernel.runner())
                            return (value["done"], value["result"])
                        if mode == "kernel-terminate":
                            from abides_core.kernel import Kernel
                            old = Kernel.write_summary_log
                            Kernel.write_summary_log = lambda self: None
                            try: return kernel.terminate() is not None
                            finally: Kernel.write_summary_log = old
                        if mode == "primary-abort-export-failure":
                            def abort_primary(): raise primary
                            try:
                                if owner is None: return abort_primary()
                                return kernel._chain_episode_boundary.run(abort_primary)
                            except BaseException as error:
                                primary_identity[0] = error is primary
                                attached_cleanup.extend(getattr(error, "chain_ownership_cleanup_failures", []))
                                raise
                        if mode == "runner-BaseException":
                            def abort(): raise FiniteAbort("finite controlled abort")
                            if owner is None: return abort()
                            return kernel._chain_episode_boundary.run(abort)
                        if mode == "foreign-IDs":
                            def witness():
                                foreign_calls[0] += 1
                                require(state(rng.get_state()) == consumed, "foreign equality saw stale public RNG")
                            sid = ForeignID(witness)
                            return model.get_latency(sid, 1) if owner is None else owner.sample(sid, 1)
                        if mode in ("public-send", "kernel-public-send"):
                            if owner is None:
                                from abides_markets.messages.market import MarketHoursRequestMsg
                                return kernel.send_message(0, 1, MarketHoursRequestMsg())
                            call = native.control_latency_public_send if mode == "public-send" else native.control_latency_kernel_public_send
                            return call(kernel._chain_scheduler, 0, 1)
                        if mode.startswith("postdraw-"):
                            phase = 1 if mode == "postdraw-before-heap" else 2
                            if owner is None:
                                from abides_markets.messages.market import MarketHoursRequestMsg
                                message = MarketHoursRequestMsg()
                                queue = kernel.messages
                                kernel.messages = FiniteSendQueue(queue, phase)
                                try: return kernel.send_message(0, 1, message)
                                finally: kernel.messages = queue
                            return kernel._chain_episode_boundary.run(native.control_latency_private_send,
                                kernel._chain_scheduler, 0, 1, phase)
                        raise ValueError("unknown finite lifecycle mode")
                    outcome = observed(public_action)
                    send_after = send_snapshot() if send_before is not None else None
                    if send_before is not None:
                        pending_delta = 0 if mode == "postdraw-before-heap" else 1
                        ledger_delta = 1 if mode in ("public-send", "kernel-public-send") else 0
                        require(send_after["message_counter"] == send_before["message_counter"] + 1
                            and len(send_after["queue_keys"]) == len(send_before["queue_keys"]) + pending_delta
                            and len(send_after["ledger_rows"]) == len(send_before["ledger_rows"]) + ledger_delta,
                            "actual send message/queue/ledger operation counts differ")
                        require(send_after["ledger_rows"][:len(send_before["ledger_rows"])] == send_before["ledger_rows"],
                                "actual send mutated former ledger rows")
                        if owner is not None:
                            before_native, after_native = send_before["native"], send_after["native"]
                            require(after_native["messages"]["constructed_messages"] == before_native["messages"]["constructed_messages"] + 1
                                and after_native["messages"]["live_messages"] == before_native["messages"]["live_messages"] + pending_delta
                                and after_native["distinct_pending_handles"] == before_native["distinct_pending_handles"] + pending_delta
                                and after_native["orders"] == before_native["orders"],
                                "actual native send leaked or lost message/order handle authority")
                    partial = None
                    if failed_mode and owner is not None:
                        require(outcome["returned"] is False and failures[0] == 1 and owner.diagnostics()["owned"],
                                "failed export must retain private authority and fail exactly once")
                        require(kernel.__dict__["agent_latency_model"] is model,
                                "failed getter/setter/delete replaced original slot")
                        partial = {"diagnostics": owner.diagnostics(), "actual_public_state": state(rng.get_state())}
                        if mode == "failed-model-restore":
                            require(partial["diagnostics"]["rng_exported"] is True and partial["actual_public_state"] == consumed,
                                    "partial successful RNG write must be retained for restoration retry")
                            retry = observed(private_sample)
                            after_retry = owner.diagnostics()
                            require(retry["returned"] is False and failures[0] == 2
                                and after_retry == partial["diagnostics"]
                                and state(owner.control_private_state()) == consumed and state(rng.get_state()) == consumed,
                                "partial failed restoration permitted a draw or duplicated state export")
                            partial["failed_private_retry"] = retry
                            partial["diagnostics_after_retry"] = after_retry
                        else:
                            require(partial["diagnostics"]["rng_exported"] is False,
                                    "failed state callback must not mark successful export")
                        if mode == "primary-abort-export-failure":
                            require(primary_identity[0] and outcome["type"] == FiniteAbort.__module__ + ".FiniteAbort"
                                and outcome["message"] == "finite controlled primary abort" and attached_cleanup
                                and attached_cleanup[-1]["owner"] == "configured-latency"
                                and attached_cleanup[-1]["message"] == "finite latency export failure"
                                and kernel._noise_boundary.closed is True
                                and all(not entry[1].diagnostics()["owned"] for entry in kernel._noise_boundary.entries),
                                "primary BaseException replaced or all-owner cleanup evidence lost")
                        if restore_export is not None:
                            owner.control_replace_export_callback(restore_export); restore_export = None
                        if restore_fields is not None:
                            owner.control_replace_restore_callback(restore_fields); restore_fields = None
                        owner.export_to_original()
                    if mode == "property-delete" or mode == "failed-export-delete":
                        # Successful delete is checked before reinstalling the original
                        # model for a deterministic continuation. Failed delete must
                        # leave the initial slot; both then continue original route.
                        if mode == "property-delete":
                            require("agent_latency_model" not in kernel.__dict__, "public delete did not remove slot")
                        kernel.agent_latency_model = model
                    if mode == "new-model-setter":
                        require(kernel.agent_latency_model is installed, "replacement model identity lost")
                        kernel.agent_latency_model = model
                    if owner is not None:
                        owner.export_to_original()
                        require(owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1,
                                "public/terminal boundary did not permanently export")
                        require(kernel.agent_latency_model is model and type(model).__name__ == "ScenarioLatencyModel",
                                "public boundary did not restore original model identity/class")
                    if mode == "foreign-IDs":
                        require(foreign_calls[0] == 1, "foreign equality witness was not called exactly once")
                    if mode == "primary-abort-export-failure":
                        require(primary_identity[0], "primary BaseException identity lost")
                    exported = state(rng.get_state())
                    continuation = observed(original_sample)
                    after = state(rng.get_state())
                    rows = {"arm": arm, "initial_actual_state": initial, "prelude_outcome": prelude,
                        "consumed_full624_state": consumed, "public_outcome": outcome,
                        "partial_export_witness": partial, "failure_calls": failures[0], "foreign_calls": foreign_calls[0],
                        "send_before": send_before, "send_after": send_after,
                        "primary_identity_preserved": primary_identity[0], "attached_cleanup": attached_cleanup,
                        "exported_actual_state": exported, "continuation_outcome": continuation,
                        "continuation_actual_state": after, "native_diagnostics": None if owner is None else owner.diagnostics()}
                    arms.append(rows)
                except BaseException as error:
                    active_error = error
                    result["failed_case"] = {"case": mode, "active_arm": arm, "completed_arms": arms,
                        "active_observations": {"initial_actual_state": initial, "prelude_outcome": prelude,
                            "consumed_full624_state": consumed, "public_outcome": outcome,
                            "partial_export_witness": partial, "send_before": send_before, "send_after": send_after,
                            "failure_calls": failures[0], "foreign_calls": foreign_calls[0],
                            "primary_identity_preserved": primary_identity[0], "attached_cleanup": attached_cleanup}}
                    raise
                finally:
                    failures_cleanup = []
                    if owner is not None:
                        for callback, original in ((owner.control_replace_export_callback, restore_export),
                                                   (owner.control_replace_restore_callback, restore_fields)):
                            if original is not None:
                                try: callback(original)
                                except BaseException as error: failures_cleanup.append(detail(error))
                    try:
                        cleanup_failures = cleanup(values, active_error)
                    except BaseException as error:
                        failures_cleanup.append(detail(error))
                    if failures_cleanup:
                        if active_error is not None: attach(active_error, "finite_control_cleanup_failures", failures_cleanup)
                        else: raise RuntimeError("finite lifecycle cleanup incomplete")
            for field in ("initial_actual_state", "prelude_outcome", "consumed_full624_state",
                          "exported_actual_state", "continuation_outcome", "continuation_actual_state"):
                require(arms[0][field] == arms[1][field] == arms[2][field], "actual latency lifecycle state/outcome differs: " + field)
            require(arms[1]["public_outcome"] == arms[2]["public_outcome"]
                    and arms[1]["native_diagnostics"] == arms[2]["native_diagnostics"], "actual native-repeat lifecycle differs")
            if arms[0]["send_before"] is not None:
                for label in ("send_before", "send_after"):
                    for field in ("queue_keys", "ledger_rows", "message_counter"):
                        require(arms[0][label][field] == arms[1][label][field] == arms[2][label][field],
                                "actual original/native/repeat send graph differs: " + label + "/" + field)
                require(arms[1]["send_before"]["native"] == arms[2]["send_before"]["native"]
                    and arms[1]["send_after"]["native"] == arms[2]["send_after"]["native"],
                    "native repeat send handle census differs")
            if not mode.startswith("failed-"):
                require(arms[0]["public_outcome"] == arms[1]["public_outcome"], "original/native public outcome differs")
            result["cases"].append({"case": mode, "arms": arms, "passed": True})
        result["all_passed"] = True
    except BaseException as error:
        result["failure"] = detail(error)
        result.setdefault("failed_case", {"case": mode, "active_arm": arm, "completed_arms": arms})
        raise
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result,sort_keys=True,indent=2,allow_nan=False,default=evidence_scalar)+"\n")
    require(result["all_passed"], "actual latency lifecycle controls failed")


if __name__ == "__main__": main()
