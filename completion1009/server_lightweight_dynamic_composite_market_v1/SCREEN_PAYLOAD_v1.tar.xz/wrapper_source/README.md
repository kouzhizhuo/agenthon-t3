# Lightweight dynamic composite whole-market screen V1

Source-only wrapper for the frozen coherent V1 composite. Preparation does not
import or execute participant, NumPy, Cython, native, market, Docker or network
code. An exact candidate source PASS and exact complete wrapper source PASS are
required to seal. Prototype payloads deliberately refuse actual execution.

The actual Linux workflow anonymously pulls the exact public T3 amd64 base and
constructs a fresh image. The construction stage adds gcc/libc headers and pinned
Cython 3.1.3, runs explicit translation-only preflight, native build and the exact
baseline schema generator. Compiler/libc details, dependency/ABI/source pins,
generated C, objects, ELF, exact schema/pin and full logs remain in the image and
are copied to host evidence. A failed compiler command is recorded in a carrier
image so the host can preserve its partial evidence and reject BUILD_READY.
Construction resources are outside official runtime timing. Native code is
never compiled at participant runtime.

One immutable final image contains the untouched baseline runtime and exact
composite candidate. Entry routes to baseline `agent.py --mode optimized` or to
the candidate root `production_cli.py --arm light_canonical/light_dynamic` in the
same fresh process. Normal timed production uses no graph, witness or extra
output hook. The deployed native module is source/ABI/ELF authenticated. Before
the market controls, actual admission is checked for all nine original scenarios
covering the four official singles and five batch members.

The upfront control container runs six independent one-market children from the
frozen candidate controls: original, light canonical, light dynamic, dynamic
repeat, trace refusal and message refusal. Actual owner selection, full STATE,
both Parquet bytes/dtypes/counts, original/native/repeat equivalence, read-only
output graph, cold normal imports, complete two-output fallback without rerun,
entry restoration and observer lifetime are checked against actual saved files.
Refusal interventions belong only to their independent control children.

After control PASS, five official units run three arms with one warmup and two
measured repeats: 45 fresh serial containers. Each unit rotates arm order and
reverses the rotation on repeat 1. Fifteen separate fresh batch-member isolation
containers compare all three arms to their batch outputs. This totals 61 runtime
containers, 102 actual market episodes, 30 measured runs, 45 unchanged official
verifier calls and 180 required gate passes. No phase instrumentation is added.

Every runtime uses inspected 4 CPU, 16 GiB, swap equal memory, no network, read
only root, user 65534, dropped capabilities, no-new-privileges, process/file/log
limits, exact thread/hash/bytecode environment, and input/output-only mounts.
Docker create uncertain outcomes, timeout and failures still trigger exact random
name/owner/image inspection, terminal PID 0, removal and proven absence. Inputs,
references, payload and image inspection are checked unchanged after the screen.
All partial results are archived on failure.

Throughput is computed per actual run as event count N divided by settled Docker
StartedAt/FinishedAt duration T. Per-unit mean and median N/T are retained
separately. The five-unit surrogate averages the five per-unit median rates;
ratios of mean durations are not used. CLI real timing remains retained for
comparison. This finite shared-host diagnostic does not establish a full-suite
score, formal ranking, first place, 230000, or official submission readiness.
