# Lightweight canonical output with continuous dynamic native arenas V1

This source preparation combines the frozen lightweight canonical buffers V4
runtime with the frozen dynamic arena chain V1.1 owner implementation. The
default production entry uses the original constructors and initialization,
then the admitted native trader, exchange, book, message, order and scheduler
owners for the continuous market. Final projections read the primitive observer
and actual dynamic ColumnLedger directly. No owned latency or Noise RNG change
is included.

The root launchers implement the official single and batch argument contracts:

```
./simulate --config scenario.json --out result/trace.parquet
./simulate-batch --batch-dir scenarios --out-dir results
```

Both use the source-bound `runtime/` and prebuilt `build/` by default. The copied
runtime launchers remain the canonical donor controls; deployment must use the
root launchers. The native module is compiled only during an explicit pinned
Linux build, never at runtime. Dependency versions and floating-point flags stay
the V1.1 donor values. Exact Arrow schema metadata and its Python hash pin must be
generated on the real pinned build server from the baseline pandas/PyArrow
schemas. No local schema evidence is fabricated.

Source authentication checks the whole runtime roster and exact loaded producer
code before initialization. Native admission refusal keeps the original kernel
and matching original ledger as a complete episode. Once the native market has
begun, errors propagate. If either final projector declines, both outputs use
their matching legacy extraction on that same completed market, before any file
write. The market is never rerun and retired source state is never revived.

`SOURCE_CHANGE_MAP_v1.json` records all fourteen differences between the dynamic
donor's original runtime and the lightweight V4 runtime. Three runtime files
differ from V4: the direct dynamic owner/ledger projector, its exact engine
boundary, and the extended observer authentication pins. Sixty-five runtime
files retain exact V4 bytes. Native pandas import is delayed to five cold methods
that actually construct DataFrames; all 310 native method ASTs ignoring imports
remain donor-identical. The native module's public reflection namespace changes,
so this is a finite normal JSON domain rather than a claim about arbitrary
reflection or callbacks.

Future controls run six independent children with one actual market each:
original, lightweight canonical, lightweight dynamic, dynamic repeat, and each
of the two final projectors forced to decline. Controls require actual kernel
selection, complete STATE/trace/message bytes and event counts equal, read-only
output graph, restored entry bindings and observer lifetime, and no pandas,
SciPy, stock CLI or unused stock-agent imports during the normal composite
market and output. Forced refusal is a control-only function-code intervention
after the market; it explicitly verifies actual two-output pandas fallback and
no rerun. Production exposes no force-refusal switch.

The preparation receipt and source audits establish only immutable source bytes,
inert Python compile/name closure, and normalized native nonimport AST equality.
Actual pinned Cython translation, native build/admission, complete market tests,
full entry timing and official gates remain required. No score, speed or rank is
inferred from this source preparation.
