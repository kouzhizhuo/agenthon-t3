"""Future one actual market; cold graph/output bytes and required owner selection retained."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True); parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True); parser.add_argument("--build", type=Path)
    parser.add_argument("--arm", choices=("original", "light_canonical", "light_dynamic"), required=True)
    parser.add_argument("--projector-decline", choices=("none", "trace", "message_trace"), default="none")
    args = parser.parse_args()
    if args.projector_decline != "none" and args.arm != "light_dynamic":
        raise ValueError("forced projector refusal belongs to actual native control only")
    root = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(root))
    oracle = {"complete": False, "market_complete": False, "production_attempts": [], "fallback_attempts": [], "control_attempts": []}
    def audit(event, values):
        if event == "import" and values and (values[0] in ("pandas", "scipy", "abides_fork.simulate", "abides_markets.agents.examples.momentum_agent",
            "abides_markets.agents.market_makers.adaptive_market_maker_agent", "abides_markets.agents.noise_agent",
            "abides_markets.agents.value_agent") or values[0].startswith(("pandas.", "scipy."))):
            fallback = (args.projector_decline != "none" and oracle["market_complete"]
                and (values[0] == "pandas" or values[0].startswith("pandas.")))
            target = oracle["control_attempts"] if oracle["complete"] else oracle["fallback_attempts"] if fallback else oracle["production_attempts"]
            target.append(values[0])
            if not oracle["complete"] and not fallback and args.arm != "original":
                raise RuntimeError("normal composite production forbidden dependency: " + values[0])
    if args.arm != "original": sys.addaudithook(audit)
    sys.path.insert(0, str(args.runtime.resolve()))
    if args.arm == "original":
        spec = importlib.util.spec_from_file_location("original_actual_entry", args.runtime / "agent.py")
        cli = importlib.util.module_from_spec(spec); spec.loader.exec_module(cli)
    else:
        import production_cli as cli
        cli.activate_paths(args.runtime)
    from abides_core import abides
    from abides_core.kernel import Kernel
    import observer
    import numpy as np
    from control_graph import snapshot
    old_run = abides.run; old_summary = Kernel.write_summary_log; old_kernel = abides.Kernel
    captured = {"actual_markets": 0}
    projector = None
    projector_code = None
    if args.projector_decline != "none":
        import canonical_buffers
        projector = getattr(canonical_buffers, "project_trace" if args.projector_decline == "trace" else "project_messages")
        projector_code = projector.__code__
    def forced_decline(*args, **kwargs):
        from canonical_buffers import Declined
        return Declined("control-forced-projector-decline")
    def capture(config):
        captured["actual_markets"] += 1
        if captured["actual_markets"] != 1: raise ValueError("market rerun")
        state = old_run(config); kernel = state["agents"][0].kernel
        selected = type(kernel).__name__
        expected = "NativeOwnerKernel" if args.arm == "light_dynamic" else "CanonicalKernel"
        if selected != expected: raise ValueError("required actual kernel not selected: " + selected)
        if args.arm == "light_dynamic": kernel._chain_migration.assert_authority()
        args.out.parent.mkdir(parents=True, exist_ok=True)
        graph = snapshot(state, np)
        (args.out.parent / "STATE.json").write_text(json.dumps(graph, ensure_ascii=True, indent=2) + "\n")
        captured.update(state=state, episode=observer.STATE, graph_before=graph)
        selection = {"requested_arm": args.arm, "selected_kernel": selected, "selected_kernel_module": type(kernel).__module__,
            "native_authority": args.arm == "light_dynamic", "passed": True}
        (args.out.parent / "ARM_SELECTION.json").write_text(json.dumps(selection, sort_keys=True, indent=2) + "\n")
        if args.arm == "light_dynamic":
            scheduler = kernel._chain_scheduler
            diag = {"orders": scheduler.orders.statistics(), "messages": scheduler.messages.statistics(),
                "pending_deliveries": scheduler.heap.qsize(), "distinct_pending_message_handles": len({row[4] for row in scheduler.heap.queue}),
                "rankable": False, "speed_claim": False}
            (args.out.parent / "ARENA_DIAGNOSTICS.json").write_text(json.dumps(diag, sort_keys=True, indent=2) + "\n")
        # Control-only intervention starts after the one authenticated market.
        # Keep the imported function object but force this final projection to
        # decline. Production exposes no flag or environment bypass for this.
        oracle["market_complete"] = True
        if projector is not None: projector.__code__ = forced_decline.__code__
        return state
    abides.run = capture
    try:
        np.random.seed(19301009)
        if args.arm == "original": result = cli.simulate(args.config, args.out, mode="optimized", started=cli.ENTRY_STARTED)
        else: result = cli.simulate(args.config, args.out, args.build, args.runtime, args.arm, cli.ENTRY_STARTED, args.out.parent / "OUTPUT_WITNESS.json")
    finally:
        abides.run = old_run
        if projector is not None: projector.__code__ = projector_code
    if abides.Kernel is not old_kernel or Kernel.write_summary_log is not old_summary or observer.STATE is not None:
        raise ValueError("entry bindings/observer not restored")
    # Read retained actual episode directly; never restore process-global
    # observer state solely to map a completed market.
    after = snapshot(captured["state"], np, captured["episode"])
    if after != captured["graph_before"]: raise ValueError("output mutated authoritative graph/RNG/UID")
    status = {"pandas_loaded": any(n == "pandas" or n.startswith("pandas.") for n in sys.modules),
        "scipy_loaded": any(n == "scipy" or n.startswith("scipy.") for n in sys.modules), "stock_cli_loaded": "abides_fork.simulate" in sys.modules,
        "unused_stock_loaded": any(n in sys.modules for n in ("abides_markets.agents.examples.momentum_agent",
            "abides_markets.agents.market_makers.adaptive_market_maker_agent", "abides_markets.agents.noise_agent", "abides_markets.agents.value_agent"))}
    forbidden_status = any(value for name, value in status.items()
        if name != "pandas_loaded" or args.projector_decline == "none")
    if args.arm != "original" and (oracle["production_attempts"] or forbidden_status):
        raise ValueError("normal composite full market/output loaded forbidden dependencies")
    if args.projector_decline != "none" and not status["pandas_loaded"]:
        raise ValueError("forced fallback must demonstrate actual pandas extraction/writing")
    oracle["complete"] = True
    (args.out.parent / "CONTROL_CHILD.json").write_text(json.dumps({"schema": "t3-lightweight-dynamic-composite-child-v1",
        "arm": args.arm, "actual_markets": captured["actual_markets"], "graph_output_readonly": True,
        "bindings_restored": True, "observer_finished": True, "cold_import_status": status,
        "production_import_attempts": oracle["production_attempts"], "forced_projector_decline": args.projector_decline,
        "fallback_import_attempts": oracle["fallback_attempts"], "rankable": False}, sort_keys=True, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__": main()
