"""Future original/light canonical/light dynamic/repeat full-market finite controls."""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--baseline-runtime", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True); parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True); parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists(): raise ValueError("fresh composite control evidence required")
    args.out.mkdir(parents=True)
    root = Path(__file__).resolve().parents[1]
    rows = []; report = {"schema": "t3-lightweight-dynamic-composite-real-controls-v1", "all_passed": False,
        "rankable": False, "speed_claim": False, "source_only": False, "cases": []}
    try:
        for name, arm, decline in (("original", "original", "none"), ("light_canonical", "light_canonical", "none"),
                ("light_dynamic", "light_dynamic", "none"), ("light_dynamic_repeat", "light_dynamic", "none"),
                ("decline_trace", "light_dynamic", "trace"), ("decline_message_trace", "light_dynamic", "message_trace")):
            out = args.out / name; out.mkdir()
            command = [sys.executable, "-B", str(root / "controls/control_child.py"), "--config", str(args.config),
                "--out", str(out / "trace.parquet"), "--runtime", str(args.baseline_runtime if arm == "original" else args.runtime), "--arm", arm]
            if arm != "original": command += ["--build", str(args.build)]
            if decline != "none": command += ["--projector-decline", decline]
            with (out / "child.log").open("xb") as log:
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if result.returncode: raise RuntimeError("actual composite arm failed: " + name)
            rows.append(out)
        selections = [json.loads((out / "ARM_SELECTION.json").read_bytes()) for out in rows]
        report["cases"].append({"case": "actual_required_owner_selection", "selections": selections, "passed": all(row["passed"] for row in selections)})
        for filename in ("trace.parquet", "message_trace.parquet", "STATE.json"):
            data = [(out / filename).read_bytes() for out in rows]
            report["cases"].append({"case": filename, "all_six_actual_bytes_equal": all(item == data[0] for item in data),
                "passed": all(item == data[0] for item in data)})
        counts = [json.loads((out / "events.json").read_bytes())["n_events"] for out in rows]
        report["cases"].append({"case": "complete_actual_event_counts", "counts": counts, "passed": len(set(counts)) == 1})
        witnesses = [json.loads((out / "OUTPUT_WITNESS.json").read_bytes()) for out in rows[1:4]]
        fallback_witnesses = [json.loads((out / "OUTPUT_WITNESS.json").read_bytes()) for out in rows[4:]]
        children = [json.loads((out / "CONTROL_CHILD.json").read_bytes()) for out in rows]
        passed = all(row["projectors_admitted"] is True and row["source_authenticated"] is True
            and row["observer_admitted"] is True and row["declines"] == {} and row["output_mode"] == "canonical-arrow-buffers"
            and row["market_rerun"] is False for row in witnesses)
        passed = passed and all(row["actual_markets"] == 1 and row["graph_output_readonly"] and row["bindings_restored"] and row["observer_finished"] for row in children)
        report["cases"].append({"case": "cold_readonly_output_and_binding_controls", "witnesses": witnesses, "children": children, "passed": passed})
        fallback_passed = all(row["projectors_admitted"] is False and row["source_authenticated"] is True
            and row["observer_admitted"] is True and row["native_admitted"] is True
            and row["output_mode"] == "legacy-pandas" and row["market_rerun"] is False
            and row["declines"] == {name: "control-forced-projector-decline"}
            for name, row in zip(("trace", "message_trace"), fallback_witnesses))
        report["cases"].append({"case": "each_projector_complete_pair_fallback_without_rerun",
            "control_only_function_code_intervention": True, "witnesses": fallback_witnesses, "passed": fallback_passed})
        report["all_passed"] = all(row["passed"] for row in report["cases"])
        if not report["all_passed"]: raise ValueError("actual composite graph/output differs")
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (args.out / "CONTROLS.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__": main()
