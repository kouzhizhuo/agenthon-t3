"""Future Linux native cold ABI/output controls; preparation never executes it.

The original arm runs genuine original trace extractors in its own process.
The native arm allocates genuine extension owners without initialization solely
for cold primitive projection fixtures. Whole-market controls separately require
authenticated initialized owners; these fixtures make no ownership/speed claim.
"""
import argparse
import copy
import gc
import hashlib
import json
from pathlib import Path
import sys


def import_oracle():
    attempts = []
    def audit(event, values):
        if event == "import" and values and (values[0] in ("pandas", "scipy")
                or values[0].startswith(("pandas.", "scipy."))):
            attempts.append(values[0])
            raise RuntimeError("cold native fixture forbidden dependency: " + values[0])
    sys.addaudithook(audit)
    return attempts


def trace_fixtures(np, side):
    base = 1612517400000000123
    ties = [
        [(base + 5, "BEST_BID", "quote", ("ABM", 100, 1)),
         (base + 5, "BEST_ASK", "quote", ("ABM", 102, 2)),
         (base + 5, "BEST_BID", "quote", ("ABM", 101, 9))],
        [(base + 9, "ORDER_EXECUTED", "order", (1, 0, side.BID, 1, 100, 100)),
         (base + 2, "ORDER_EXECUTED", "order", (1, 0, side.BID, 2, 100, 100)),
         (base + 5, "ORDER_EXECUTED", "order", (1, 42, side.ASK, 3, 102, 102)),
         (base + 5, "ORDER_CANCELLED", "order", (1, -1, None, 2, None, None)),
         (base + 5, "ORDER_REPLACED", "order", (1, 42, side.ASK, 4, 103, None)),
         (base + 5, "ORDER_SUBMITTED", "order", (1, -2, side.BID, 1, 98, None)),
         (base + 5, "ORDER_SUBMITTED", "order", (1, None, None, None, None, None))],
        [(base + 5, "ORDER_EXECUTED", "order", (2, 42, side.ASK, 5, 102, 102)),
         (base + 5, "ORDER_ACCEPTED", "order", (2, 42, side.ASK, 6, 102, None)),
         (base + 5, "ORDER_EXECUTED", "order", (2, 42, side.ASK, 7, 102, 102)),
         (base + 5, "ORDER_SUBMITTED", "order", (2, -1, side.BID, 1, 99, None))],
    ]
    expected = [
        [base + 2, 1, "PARTIAL_FILL", "BID", 100, 2, 0],
        [base + 5, 1, "ORDER_SUBMITTED", "BID", 98, 1, -2],
        [base + 5, 1, "ORDER_CANCELLED", None, 0, 2, -1],
        [base + 5, 2, "ORDER_SUBMITTED", "BID", 99, 1, -1],
        [base + 5, 0, "QUOTE_UPDATE", "BID", 101, 9, -1],
        [base + 5, 0, "QUOTE_UPDATE", "ASK", 102, 2, -1],
        [base + 5, 1, "PARTIAL_FILL", "ASK", 102, 3, 42],
        [base + 5, 1, "ORDER_REPLACED", "ASK", 103, 4, 42],
        [base + 5, 2, "PARTIAL_FILL", "ASK", 102, 5, 42],
        [base + 5, 2, "ORDER_ACCEPTED", "ASK", 102, 6, 42],
        [base + 5, 2, "ORDER_FILLED", "ASK", 102, 7, 42],
        [base + 9, 1, "ORDER_FILLED", "BID", 100, 1, 0],
    ]
    timestamps = [True, np.int64(2), 2.5, np.int32(3), None, "x"]
    normalization = [[], [(value, "ORDER_SUBMITTED", "order", (None, index, "askbid", np.int32(1), None, None))
        for index, value in enumerate(timestamps)], []]
    normalized_expected = [[0, 1, "ORDER_SUBMITTED", "BID", 0, 1, index] for index in (2, 3, 4, 5)]
    normalized_expected += [[1, 1, "ORDER_SUBMITTED", "BID", 0, 1, 0], [2, 1, "ORDER_SUBMITTED", "BID", 0, 1, 1]]
    limits = [[], [
        (-(1 << 63), "ORDER_SUBMITTED", "order", (-(1 << 31), -(1 << 53), None, -(1 << 53), -(1 << 53), None)),
        ((1 << 63) - 1, "ORDER_ACCEPTED", "order", ((1 << 31) - 1, (1 << 53), side.ASK, (1 << 53), (1 << 53), None))], []]
    limits[1].extend([
        (np.int64(base), "ORDER_SUBMITTED", "order", (np.int32(1), np.int64(-123), side.BID, np.int64(7), np.int32(100), None)),
        (np.int64(base + 1), "ORDER_ACCEPTED", "order", (np.int32(2), np.int32(124), side.ASK, np.int32(8), np.int64(102), None))])
    limit_expected = [[-(1 << 63), -(1 << 31), "ORDER_SUBMITTED", None, -(1 << 53), -(1 << 53), -(1 << 53)],
        [(1 << 63) - 1, (1 << 31) - 1, "ORDER_ACCEPTED", "ASK", (1 << 53), (1 << 53), (1 << 53)]]
    limit_expected = [limit_expected[0],
        [base, 1, "ORDER_SUBMITTED", "BID", 100, 7, -123],
        [base + 1, 2, "ORDER_ACCEPTED", "ASK", 102, 8, 124], limit_expected[1]]
    return [("stable_cross_owner_ties", ties, expected), ("exact_timestamp_side_normalization", normalization, normalized_expected),
        ("signed_trace_boundaries", limits, limit_expected)]


def message_fixtures(np):
    base = 1612517400000000123
    ordinary = [(9, 1, 0, base, base + 9, 9, "LIMIT_ORDER", 42, 7),
        (9, 1, 0, base + 1, base + 10, 9, "LIMIT_ORDER", 42, 7),
        (11, 0, 0, None, base + 2, 0, "AGENT_WAKEUP", None, None),
        (12, 0, 1, base + 2, base + 5, 3, "ORDER_ACCEPTED", 42, 9),
        (13, "unselected", 0, object(), "unselected", "unselected", object(), object(), object())]
    expected = [[2, base + 2, None, 0, 0, 0, 11, "AGENT_WAKEUP", None, None],
        [7, base + 5, base + 2, 3, 0, 1, 12, "ORDER_ACCEPTED", 42, 9],
        [8, base + 9, base, 9, 1, 0, 9, "LIMIT_ORDER", 42, 7],
        [8, base + 10, base + 1, 9, 1, 0, 9, "LIMIT_ORDER", 42, 7]]
    nullable = []
    null_expected = []
    vocabulary = [None, "", "买入🙂", "x", None, "ASK", "", "Ω", None]
    for index, value in enumerate(vocabulary):
        row = (100 + index, index, 0, None, base + index, index, value, None, None)
        nullable.append(row)
        null_expected.append([index, base + index, None, index, index, 0, 100 + index, value, None, None])
    ranges = [(-(1 << 63), -(1 << 31), -(1 << 31), -(1 << 63), -(1 << 63), -(1 << 63), "", -(1 << 63), -(1 << 63)),
        ((1 << 63) - 1, (1 << 31) - 1, (1 << 31) - 1, (1 << 63) - 1, (1 << 63) - 1, (1 << 63) - 1, "🙂", (1 << 63) - 1, (1 << 63) - 1)]
    ranges.extend([
        (np.int64(301), np.int32(1), np.int32(0), np.int64(base), np.int64(base + 3), np.int32(3), "EXACT_NUMPY", np.int32(42), np.int64(7)),
        (np.int32(302), np.int64(2), np.int64(0), None, np.int64(base + 4), np.int64(0), "", None, np.int32(-1))])
    range_expected = [[None if value is None else value if index == 7 else int(value)
        for index, value in enumerate((row[0], row[4], row[3], row[5], row[1], row[2], row[0], row[6], row[7], row[8]))] for row in ranges]
    range_expected.sort(key=lambda row: row[0])
    return [("duplicate_final_sequence_and_unselected_nonkeys", ordinary, {(9, 0): 8, (11, 0): 2, (12, 1): 7}, expected),
        ("nullable_utf8_padding_and_empty", nullable, {(100 + index, 0): index for index in range(9)}, null_expected),
        ("signed_message_boundaries", ranges, {(int(row[0]), int(row[2])): int(row[0]) for row in ranges}, range_expected)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path)
    parser.add_argument("--arm", choices=("original", "native"), required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists(): raise ValueError("fresh native fixture evidence required")
    args.out.mkdir(parents=True)
    root = Path(__file__).resolve().parents[1]
    attempts = import_oracle() if args.arm == "native" else []
    runtime = args.runtime.resolve()
    if args.arm == "native":
        sys.path.insert(0, str(root))
        from production_cli import activate_paths
        activate_paths(runtime)
    else:
        for path in reversed((runtime, runtime / "vendor/abides/abides-core", runtime / "vendor/abides/abides-markets")):
            sys.path.insert(0, str(path))
    import numpy as np
    import pyarrow as pa
    import pyarrow.parquet as pq
    from abides_fork import trace
    from abides_markets.orders import Side
    versions = {"numpy": np.__version__, "pyarrow": pa.__version__}
    if versions != {"numpy": "1.26.4", "pyarrow": "15.0.2"}: raise ValueError("pinned native fixture dependencies differ")
    if args.arm == "native":
        import observer
        from native_loader import load
        engine = load(args.build, runtime)["dynamic_arena_chain"]
        direct_clone_controls = engine.control_direct_clone_checks()
        from latency_controls import run_controls, run_source_controls
        latency_result = run_controls()
        source_controls = run_source_controls()
        if direct_clone_controls.get("all_passed") is not True:
            raise AssertionError("direct clone finite controls failed")
        from canonical_buffers import validate_admitted_columns, write_outputs, project_messages, Declined
        owners = [engine.NativeExchange.__new__(engine.NativeExchange)]
        owners += [engine.NativeTrader.__new__(engine.NativeTrader) for _ in range(2)]
        for index, owner in enumerate(owners): owner.id = index
    else:
        import pandas as pd
        from abides_fork.agents import NoiseTrader, MarketMaker
        from abides_markets.agents.exchange_agent import ExchangeAgent
        versions["pandas"] = pd.__version__
        if versions["pandas"] != "1.5.3": raise ValueError("pinned original pandas differs")
        owners = [cls.__new__(cls) for cls in (ExchangeAgent, NoiseTrader, MarketMaker)]
        for index, owner in enumerate(owners): owner.id = index; owner.log = []
    trace_contract = {"t_ns": "int64", "agent_id": "int32", "msg_type": "string", "side": "string", "price": "int64", "size": "int64", "order_id": "int64"}
    message_contract = {"seq": "int64", "t_recv_ns": "int64", "t_send_ns": "Int64", "latency_ns": "int64", "src_id": "int32", "dst_id": "int32", "message_id": "int64", "msg_type": "string", "order_id": "Int64", "causal_parent": "Int64"}
    labels = []
    trace_cases = trace_fixtures(np, Side)
    message_cases = message_fixtures(np)
    lifetime_pair = None
    for (label, records, expected_trace), (message_label, sent, seqmap, expected_messages) in zip(trace_cases, message_cases):
        out = args.out / label; out.mkdir()
        raw_before = copy.deepcopy(records)
        ledger_before = tuple(tuple(row) for row in sent)
        map_before = dict(seqmap)
        if args.arm == "native":
            episode = observer.Episode(); episode.has_scalar = True
            episode.contract = {owner: list(rows) for owner, rows in zip(owners, records)}
            ledger = engine.ColumnLedger()
            for row in sent:
                for column, value in zip(ledger.columns, row): column.append(value)
            state = {"agents": owners, "message_ledger": ledger, "deliver_seq_by_key": seqmap}
            projected_trace = engine.cold_trace_buffers(state, episode)
            projected_messages = engine.cold_message_buffers(state, engine.ColumnLedger)
            validate_admitted_columns(projected_trace, projected_messages)
            contract_unchanged = all(episode.contract[owner] == original for owner, original in zip(owners, raw_before))
            if not contract_unchanged or records != raw_before or tuple(tuple(column[index] for column in ledger.columns) for index in range(len(sent))) != ledger_before or seqmap != map_before:
                raise AssertionError("native cold projection mutated fixture source")
            # Every descriptor is byte-owned. Check null slots and bitmap padding
            # independently of Arrow, then destroy original graph storage.
            for columns in (projected_trace, projected_messages):
                for dtype, validity, offsets, payload, nulls in columns.fields:
                    if type(payload) is not bytes or offsets is not None and type(offsets) is not bytes:
                        raise AssertionError("native descriptor lacks immutable storage")
                    if validity is not None:
                        if columns.n_rows % 8 and validity[-1] >> (columns.n_rows % 8): raise AssertionError("native null bitmap padding is nonzero")
                        if sum(not (validity[index >> 3] & (1 << (index & 7))) for index in range(columns.n_rows)) != nulls:
                            raise AssertionError("native bitmap count differs")
                        if dtype != "string":
                            width = 4 if dtype == "int32" else 8
                            if any(payload[index * width:(index + 1) * width] != bytes(width)
                                    for index in range(columns.n_rows) if not (validity[index >> 3] & (1 << (index & 7)))):
                                raise AssertionError("native numeric null storage differs")
            descriptor_before = (projected_trace.fields, projected_messages.fields)
            del state, episode, ledger
            gc.collect()
            write_outputs(projected_trace, projected_messages, out / "trace.parquet")
            if descriptor_before != (projected_trace.fields, projected_messages.fields): raise AssertionError("native buffers changed after source destruction")
            lifetime_pair = (projected_trace, projected_messages)
        else:
            fields = ("agent_id", "order_id", "side", "quantity", "limit_price", "fill_price")
            for owner, rows in zip(owners, records):
                owner.log = [(0, "AGENT_TYPE", "fixed-source-fixture")]
                for timestamp, event, kind, values in rows:
                    payload = dict(zip(fields, values)) if kind == "order" else "{},{},{}".format(*values)
                    owner.log.append((timestamp, event, payload))
            names = ("message_id", "src_id", "dst_id", "t_send_ns", "t_recv_ns", "latency_ns", "msg_type", "order_id", "causal_parent")
            state = {"agents": owners, "message_ledger": [dict(zip(names, row)) for row in sent], "deliver_seq_by_key": seqmap}
            projected_trace = trace.extract_trace(state)
            projected_messages = trace.extract_message_trace(state)
            projected_trace.to_parquet(out / "trace.parquet", compression="snappy", index=False)
            projected_messages.to_parquet(out / "message_trace.parquet", compression="snappy", index=False)
        values_trace = {name: [row[index] for row in expected_trace] for index, name in enumerate(trace_contract)}
        values_message = {name: [row[index] for row in expected_messages] for index, name in enumerate(message_contract)}
        for filename, expected in (("trace.parquet", values_trace), ("message_trace.parquet", values_message)):
            table = pq.ParquetFile(out / filename).read(use_threads=False, use_pandas_metadata=False)
            if table.to_pydict() != expected: raise AssertionError("explicit native fixture expected values differ: " + filename)
        labels.append({"trace_case": label, "message_case": message_label, "expected_trace": values_trace,
            "expected_messages": values_message, "input_readonly": True})
    if args.arm == "native":
        boundary_clone_result = direct_clone_controls
    else:
        boundary_clone_result = None
    boundary_cases = []
    if args.arm == "native":
        callbacks = []
        class Collision:
            def __init__(self, target): self.target = target
            def __hash__(self): return hash(self.target)
            def __eq__(self, other): callbacks.append("eq"); raise AssertionError("untrusted dictionary callback")
        for target, operation in (("agents", lambda state: engine.cold_trace_buffers(state, observer.Episode())),
                ("message_ledger", lambda state: engine.cold_message_buffers(state, engine.ColumnLedger)),
                ("message_ledger", lambda state: project_messages(state, engine.ColumnLedger))):
            if type(operation({Collision(target): None})) not in (str, Declined) or callbacks:
                raise AssertionError("nonstring endstate keys must decline before lookup")
        boundary_cases.append("nonstring_endstate_keys_decline_without_callbacks")
        normal = engine.ColumnLedger()
        sample = (1, 0, 0, None, 1, 0, "", None, None)
        for column, value in zip(normal.columns, sample): column.append(value)
        def message_declines(columns, mapping):
            ledger = engine.ColumnLedger(); ledger.columns = columns
            return type(engine.cold_message_buffers({"message_ledger": ledger, "deliver_seq_by_key": mapping}, engine.ColumnLedger)) is str
        if not message_declines((normal.columns[0],) * 9, {(1, 0): 1}): raise AssertionError("aliased native ledger must decline")
        if not message_declines(normal.columns, {Collision((1, 0)): 1}) or callbacks: raise AssertionError("native map must decline before key comparisons")
        for position, value in ((0, -(1 << 63) - 1), (0, 1 << 100), (2, np.int64(1 << 31)), (1, np.int64(-(1 << 31) - 1)), (0, True), (0, 1 << 63), (2, 1 << 31), (1, True), (3, 1 << 63), (6, b"x")):
            copied = tuple(list(column) for column in normal.columns); copied[position][0] = value
            if not message_declines(copied, {(1, 0): 1}): raise AssertionError("native invalid scalar must decline")
        if not message_declines(normal.columns, {(1, 0): 1 << 63}): raise AssertionError("native sequence overflow must decline")
        class HostileInt(int):
            def __int__(self): callbacks.append("int"); raise AssertionError("custom numeric conversion")
            def __lt__(self, other): callbacks.append("lt"); raise AssertionError("custom comparison")
        for position in (0, 1, 2, 3, 4, 5, 7, 8):
            copied = tuple(list(column) for column in normal.columns); copied[position][0] = HostileInt(1)
            if not message_declines(copied, {(1, 0): 1}) or callbacks:
                raise AssertionError("exact cold scalar lane must refuse subclasses without callback")
        boundary_cases += ["ledger_alias_and_hostile_map", "message_bool_range_and_string_declines"]
        for timestamp, aid, oid, side, quantity, price, event in ((1 << 63, 1, 1, Side.BID, 1, 1, "ORDER_SUBMITTED"),
                (0, 1 << 31, 1, Side.BID, 1, 1, "ORDER_SUBMITTED"), (0, 1, (1 << 53) + 1, Side.BID, 1, 1, "ORDER_SUBMITTED"),
                (0, 1, 1, Side.BID, True, 1, "ORDER_SUBMITTED"), (0, 1, 1, b"BID", 1, 1, "ORDER_SUBMITTED"),
                (0, 1, 1, Side.BID, 1, 1, "UNKNOWN"),
                (-(1 << 63) - 1, 1, 1, Side.BID, 1, 1, "ORDER_SUBMITTED"),
                (0, 1, np.int64((1 << 53) + 1), Side.BID, 1, 1, "ORDER_SUBMITTED")):
            episode = observer.Episode(); episode.has_scalar = True
            episode.contract = {owners[1]: [(timestamp, event, "order", (aid, oid, side, quantity, price, None))]}
            if type(engine.cold_trace_buffers({"agents": owners}, episode)) is not str: raise AssertionError("native trace domain must decline")
        boundary_cases.append("trace_signed53_bool_side_unknown_event_declines")
        try: engine.NativeColumns()
        except TypeError: pass
        else: raise AssertionError("native output constructor must refuse public initialization")
        forged = engine.NativeColumns.__new__(engine.NativeColumns)
        if forged.sealed(): raise AssertionError("public native allocation must remain unsealed")
        try: validate_admitted_columns(forged, lifetime_pair[1])
        except ValueError: pass
        else: raise AssertionError("unsealed public columns must fail admission")
        for name in ("kind", "n_rows", "fields"):
            try: setattr(lifetime_pair[0], name, None)
            except (AttributeError, TypeError): pass
            else: raise AssertionError("native descriptor fields must be readonly")
        boundary_cases.append("sealed_immutable_native_descriptor_authority")
        del owners, owner, records, sent, seqmap, normal, episode, raw_before, ledger_before, map_before
        gc.collect()
        retained_trace, retained_messages = lifetime_pair
        retained = args.out / "retained_after_owner_destruction"; retained.mkdir()
        write_outputs(retained_trace, retained_messages, retained / "trace.parquet")
        source = args.out / labels[-1]["trace_case"]
        if any((retained / name).read_bytes() != (source / name).read_bytes() for name in ("trace.parquet", "message_trace.parquet")):
            raise AssertionError("native bytes lifetime changed after owner destruction")
        boundary_cases.append("immutable_buffers_survive_graph_owner_destruction")
        if attempts: raise AssertionError("native fixture attempted forbidden scientific imports")
    files = [{"path": path.relative_to(args.out).as_posix(), "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in sorted(args.out.rglob("*.parquet"))]
    receipt = {"schema": "t3-cold-native-projection-buffer-fixtures-v1", "arm": args.arm, "versions": versions,
        "classic_latency_controls": latency_result if args.arm == "native" else None,
        "classic_source_controls": source_controls if args.arm == "native" else None,
        "direct_clone_controls": boundary_clone_result, "cases": labels, "boundary_cases": boundary_cases, "files": files, "forbidden_import_attempts": attempts,
        "native_fixture_owners_initialized": False, "market_executed": False, "rankable": False, "speed_claim": False}
    (args.out / "FIXTURE_RECEIPT.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__": main()
