This candidate uses exact scalar latency functions in the native event engine and resolves paths once inside each fresh source-authentication call. It retains the original model and RandomState, full source/ELF checks, state ownership and output contract. Linux equality, full random-state and same-run performance tests are required before promotion.

# Changes

Classical algorithm selection happens before event processing. Unsupported latency models retain their own original callback. Source verification reads each file once for both length and digest; all files are checked afresh.
