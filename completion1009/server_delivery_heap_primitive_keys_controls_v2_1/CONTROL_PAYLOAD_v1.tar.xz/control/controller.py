"""Future serial native build and exact-resource finite heap control."""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time
import uuid
from common import BASE, CANDIDATE_SHA256, ENTRYPOINT, inventory, sha, verify_payload, write
from raw_checks import check_build_raw, check_controls_raw

PAYLOAD = Path(__file__).resolve().parents[1]
RESOURCES = {
    "build": {"NanoCpus": 1000000000, "Memory": 8 * 1024**3, "MemorySwap": 8 * 1024**3,
        "PidsLimit": 256, "ReadonlyRootfs": True, "NetworkMode": "none", "CapDrop": ["ALL"],
        "SecurityOpt": ["no-new-privileges"], "Tmpfs": {"/tmp": "rw,nosuid,nodev,size=1g"}},
    "controls": {"NanoCpus": 4000000000, "Memory": 16 * 1024**3, "MemorySwap": 16 * 1024**3,
        "PidsLimit": 256, "ReadonlyRootfs": True, "NetworkMode": "none", "CapDrop": ["ALL"],
        "SecurityOpt": ["no-new-privileges"], "Tmpfs": {"/tmp": "rw,noexec,nosuid,nodev,size=64m"}},
}


def resource_contract(value, mode, output, build):
    host = value["HostConfig"]
    selected = {name: host.get(name) for name in RESOURCES[mode]}
    if selected != RESOURCES[mode] or value["Config"]["User"] != "65534:65534":
        raise ValueError("actual " + mode + " container resources differ")
    if value["Config"]["Entrypoint"] != ENTRYPOINT or value["Config"]["Cmd"] != [mode]:
        raise ValueError("actual " + mode + " entrypoint/verb differs")
    mounts = {row["Destination"]: {key: row[key] for key in ("Type", "Source", "RW")}
        for row in value["Mounts"] if row["Type"] == "bind"}
    expected_mounts = {"/output": {"Type": "bind", "Source": str(output), "RW": True}}
    if mode == "controls":
        expected_mounts["/build"] = {"Type": "bind", "Source": str(build), "RW": False}
    if mounts != expected_mounts:
        raise ValueError("actual " + mode + " output/build mounts differ")
    if any(row["Type"] not in ("bind", "tmpfs") or (row["Type"] == "tmpfs" and row["Destination"] != "/tmp") for row in value["Mounts"]):
        raise ValueError("unadmitted actual mounted volume")
    if mode == "controls":
        limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
        if limits != {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}:
            raise ValueError("actual correctness process/file limits differ")
    env = value["Config"].get("Env", [])
    for name, required in (("PYTHONHASHSEED", "0"), ("OPENBLAS_NUM_THREADS", "1"),
            ("OMP_NUM_THREADS", "1"), ("MKL_NUM_THREADS", "1"), ("NUMEXPR_NUM_THREADS", "1")):
        if [item.split("=", 1)[1] for item in env if item.startswith(name + "=")] != [required]:
            raise ValueError("actual control thread/seed environment differs")
    return {"HostConfig": selected, "mounts": mounts}


def call(args, command, label, seconds=60, allow_failure=False):
    path = args.evidence / (label + ".log")
    result, failure = None, None
    started = time.monotonic()
    with path.open("xb") as stream:
        try:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=seconds)
        except BaseException as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    row = {"command": command, "returncode": None if result is None else result.returncode,
        "failure": failure, "host_elapsed_sec": time.monotonic() - started,
        "log": {"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path)}}
    write(args.evidence / (label + ".json"), row)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual bounded host command failed: " + label)
    return row


def inspect(args, value, label):
    call(args, [args.docker, "inspect", value], label)
    data = json.loads((args.evidence / (label + ".log")).read_bytes())
    if type(data) is not list or len(data) != 1:
        raise ValueError("one inspected Docker object required")
    return data[0]


def exact_absence(args, name, label):
    absent = call(args, [args.docker, "inspect", name], label, allow_failure=True)
    lines = [line.strip() for line in (args.evidence / (label + ".log")).read_text().splitlines() if line.strip()]
    return (absent["returncode"] == 1 and absent["failure"] is None and sorted(lines) == sorted(
        ["[]", "Error: No such object: " + name]))


def cleanup(args, name, image_id, mode):
    result = {"settled": False, "removed": False, "exact_owned_name": name}
    label = mode + "-cleanup-"
    try:
        first = call(args, [args.docker, "inspect", name], label + "inspect", allow_failure=True)
        if first["returncode"] != 0 or first["failure"] is not None:
            if exact_absence(args, name, label + "initial-absence"):
                result.update(settled=True, removed=True, exact_no_such_object=True, object_never_observed=True)
            else:
                raise ValueError("create-attempt state ambiguous; exact absence not proved")
        else:
            values = json.loads((args.evidence / (label + "inspect.log")).read_bytes())
            if type(values) is not list or len(values) != 1 or values[0].get("Name") != "/" + name or values[0].get("Image") != image_id:
                raise ValueError("exact owned container name/image required before cleanup")
            value = values[0]
            if value["State"]["Running"]:
                call(args, [args.docker, "kill", name], label + "kill", allow_failure=True)
            call(args, [args.docker, "wait", name], label + "wait", 60, allow_failure=True)
            value = inspect(args, name, label + "settled-inspect")
            if value.get("Name") != "/" + name or value.get("Image") != image_id:
                raise ValueError("cleanup container authority changed")
            result["settled"] = value["State"]["Running"] is False and value["State"].get("Pid") == 0
            result["state"] = value["State"]
            call(args, [args.docker, "logs", name], mode + "-container-complete-logs", allow_failure=True)
            if result["settled"]:
                removal = call(args, [args.docker, "rm", name], label + "remove", allow_failure=True)
                result["exact_no_such_object"] = exact_absence(args, name, label + "absence")
                result["removed"] = removal["returncode"] == 0 and removal["failure"] is None and result["exact_no_such_object"]
    except BaseException as error:
        result["failure"] = {"type": type(error).__name__, "message": str(error)}
    write(args.evidence / (mode + "-CLEANUP.json"), result)
    return result


def stage(args, image_id, mode, build=None):
    name, create_attempted = "t3-chain-" + mode + "-" + uuid.uuid4().hex, False
    output = args.evidence / mode / "output"
    output.mkdir(parents=True); output.chmod(0o777)
    row = {"mode": mode, "all_passed": False, "output": str(output), "failure": None}
    try:
        resource = RESOURCES[mode]
        command = [args.docker, "create", "--name", name, "--network", "none", "--read-only",
            "--cpus", str(resource["NanoCpus"] // 1000000000), "--memory", str(resource["Memory"]),
            "--memory-swap", str(resource["MemorySwap"]), "--pids-limit", "256", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--user", "65534:65534", "--tmpfs", "/tmp:" + resource["Tmpfs"]["/tmp"],
            "--mount", "type=bind,src=" + str(output) + ",dst=/output", "--env", "PYTHONHASHSEED=0",
            "--env", "OPENBLAS_NUM_THREADS=1", "--env", "OMP_NUM_THREADS=1", "--env", "MKL_NUM_THREADS=1",
            "--env", "NUMEXPR_NUM_THREADS=1"]
        if mode == "controls":
            command += ["--mount", "type=bind,src=" + str(build) + ",dst=/build,readonly",
                "--ulimit", "nofile=1024:1024", "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456"]
        command += [image_id, mode]
        create_attempted = True
        call(args, command, mode + "-container-create")
        row["container_before"] = inspect(args, name, mode + "-container-before")
        if row["container_before"]["Image"] != image_id:
            raise ValueError("actual " + mode + " container image identity differs")
        row["resources_before"] = resource_contract(row["container_before"], mode, output, build)
        if mode == "build":
            installed = args.evidence / "installed"
            call(args, [args.docker, "cp", name + ":/opt/delivery-heap-primitive-v2-1", str(installed)], "installed-source-copy")
            verify_payload(installed)
            row["installed_source_inventory"] = inventory(installed)
        call(args, [args.docker, "start", name], mode + "-container-start")
        call(args, [args.docker, "wait", name], mode + "-container-wait", 1200 if mode == "build" else 900)
        value = inspect(args, name, mode + "-container-after")
        row["container_after"] = value
        row["resources_after"] = resource_contract(value, mode, output, build)
        if row["resources_before"] != row["resources_after"]:
            raise ValueError("actual resources changed during " + mode)
        if value["State"]["Running"] or value["State"]["ExitCode"] != 0 or value["State"].get("OOMKilled"):
            raise ValueError("actual " + mode + " container failed")
        result = json.loads((output / "ACTUAL_RESULT.json").read_bytes())
        if (result.get("all_passed") is not True or result.get("mode") != mode
                or result.get("actual_native_build_invocations") != (1 if mode == "build" else 0)
                or result.get("actual_Cython_translation_only_invocations") != (1 if mode == "build" else 0)
                or (mode == "build" and result.get("translation_verified") is not True)
                or (mode == "build" and result.get("translation_build_C_fullbytes_equal") is not True)
                or result.get("actual_typed_handle_control_invocations") != (1 if mode == "controls" else 0)
                or (mode == "controls" and (result.get("typed_handle_controls_verified") is not True or result.get("heap_controls_verified") is not True))
                or result.get("build_verified") is not True or result["candidate_source_receipt_sha256"] != CANDIDATE_SHA256):
            raise ValueError("actual " + mode + " result/source/native-build binding differs")
        row["actual_result"] = result
        if mode == "build":
            row["independent_host_raw_build"] = check_build_raw(output / "build", output / "translation",
                result["build_receipt"], result["translation_receipt"])
        else:
            finite = json.loads((output / "HEAP_CONTROLS.json").read_bytes())
            if result.get("actual_controls_file") != {"path": "HEAP_CONTROLS.json", "bytes": (output / "HEAP_CONTROLS.json").stat().st_size, "sha256": sha(output / "HEAP_CONTROLS.json")}:
                raise ValueError("actual saved full finite report receipt differs")
            row["independent_host_saved_controls"] = check_controls_raw(finite)
            if result.get("raw_controls_checks") != row["independent_host_saved_controls"]:
                raise ValueError("actual worker/host saved full raw checks differ")
        row["all_passed"] = True
    except BaseException as error:
        row["failure"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        if create_attempted:
            row["cleanup"] = cleanup(args, name, image_id, mode)
            if not all(row["cleanup"].get(key) is True for key in ("settled", "removed")):
                row["all_passed"] = False
        row["output_inventory"] = inventory(output)
        write(args.evidence / (mode + "-STAGE_RESULT.json"), row)
    return row


def run(args):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("Linux amd64 Docker host required")
    verify_payload(PAYLOAD)
    record = {"schema": "t3-authoritative-chain-host-controls-v1", "all_passed": False,
        "rankable": False, "official_submission": False, "speed_claim": False,
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "failure": None, "stages": []}
    image_id = None
    try:
        anonymous = args.evidence / "anonymous-docker-config"
        anonymous.mkdir()
        previous = os.environ.get("DOCKER_CONFIG")
        os.environ["DOCKER_CONFIG"] = str(anonymous)
        try:
            call(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], "base-pull", 600)
        finally:
            if previous is None:
                os.environ.pop("DOCKER_CONFIG", None)
            else:
                os.environ["DOCKER_CONFIG"] = previous
        base = inspect(args, BASE, "base-inspect")
        if BASE.split("@", 1)[1] not in " ".join(base.get("RepoDigests", [])):
            raise ValueError("pinned Linux base digest differs")
        tag = "t3-authoritative-chain-controls:" + uuid.uuid4().hex
        call(args, [args.docker, "build", "--platform", "linux/amd64", "--pull=false", "--no-cache",
            "-t", tag, "-f", str(PAYLOAD / "control/Dockerfile"), str(PAYLOAD)], "compiler-image-build", 900)
        image = inspect(args, tag, "image-before")
        image_id = image["Id"]
        if (image["Config"]["Entrypoint"] != ENTRYPOINT or image["Config"]["User"] != "65534:65534"
                or image["Architecture"] != "amd64" or image["Os"] != "linux"):
            raise ValueError("actual compiler/control image ABI/entry/user differs")
        built = stage(args, image_id, "build")
        record["stages"].append(built)
        if built["all_passed"] is not True:
            raise ValueError("actual native build failed; no controls dispatched")
        build = args.evidence / "build/output/build"
        record["compiled_build_before_controls"] = inventory(build)
        controlled = stage(args, image_id, "controls", build)
        record["stages"].append(controlled)
        record["compiled_build_after_controls"] = inventory(build)
        if (controlled["all_passed"] is not True
                or record["compiled_build_before_controls"] != record["compiled_build_after_controls"]):
            raise ValueError("actual finite heap controls or readonly build bytes changed")
        record["all_passed"] = True
    except BaseException as error:
        record["failure"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        try:
            verify_payload(PAYLOAD)
            if image_id is not None:
                after = inspect(args, image_id, "image-after")
                record["image_unchanged"] = image == after
                if record["image_unchanged"] is not True:
                    record["all_passed"] = False
            record["retained_evidence_inventory"] = inventory(args.evidence)
        except BaseException as error:
            record["all_passed"] = False
            record["retention_failure"] = {"type": type(error).__name__, "message": str(error)}
        write(args.evidence / "HOST_RESULT.json", record)
    if record["all_passed"] is not True:
        raise RuntimeError("actual finite heap Linux control incomplete or failed")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("run", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--artifact", type=Path)
    parser.add_argument("--docker", default="docker")
    args = parser.parse_args()
    args.evidence = args.evidence.resolve()
    if args.verb == "artifact":
        if args.artifact is None or args.artifact.exists():
            raise ValueError("fresh artifact directory required")
        args.artifact.mkdir(parents=True)
        if args.evidence.exists():
            shutil.copytree(args.evidence, args.artifact / "evidence", ignore=shutil.ignore_patterns("anonymous-docker-config"))
        shutil.copytree(PAYLOAD, args.artifact / "payload")
        write(args.artifact / "ARTIFACT_INVENTORY.json", inventory(args.artifact))
        return
    if args.evidence.exists():
        raise ValueError("fresh evidence directory required")
    args.evidence.mkdir(parents=True)
    run(args)


if __name__ == "__main__":
    main()
