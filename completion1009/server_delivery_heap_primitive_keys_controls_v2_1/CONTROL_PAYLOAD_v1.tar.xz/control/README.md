This fresh V2.1 server wrapper repairs the archive file/directory collision
guard from frozen wrapper V2. The prior guard compared a string parent name
against a set of Path values, so it could not reject that collision explicitly.
Fresh V2.1 converts the complete validated Path inventory to canonical strings
before checking every parent. The frozen V2 wrapper remains unchanged.

This server test checks whether caching exact integer event keys preserves the
original delivery heap's behavior. It first translates and compiles one frozen
native extension, then runs 28 typed-handle cases and 13 heap cases. It runs no
markets and records no throughput result. Passing these checks permits further
market experiments; it does not establish a competitive score or submission.

The candidate is `candidates/delivery_heap_primitive_keys_controls_v2`, frozen
with receipt SHA256
`052d8d2a5db0b2a40ecbe578a308f950d9cd72f0b1018152e2037a262a2382a2`.
The independent frozen source review is
`985b577b6be70b454f4685f16df6f0e3a99197b3b58ba4daeda9be04b58e6733`.
Its 11 files retain the typed V2.1 engine and original 64 runtime files. The
changed heap caches exact Python integers within signed 64-bit bounds. Bool,
subclasses, NumPy scalar values, floating values and overflow use the original
comparison. Existing key objects, message ownership and physical heap tie rules
remain authoritative. No frozen candidate files are changed by this wrapper.

The first container runs one translation-only preflight and one native build.
The complete generated C recorded as the actual compiler input must equal the
complete translated C. Retained compiler objects and the extension must have
the expected x86_64 ELF headers. Source, runtime, compiler specification,
dependency and ABI receipts remain available for independent saved review.
The build container has one CPU and 8 GiB, an offline network, a read-only root,
an unprivileged user, and only its output directory writable. These construction
resources are outside any future market timing.

The separate control container mounts the completed build read-only, uses four
CPUs and 16 GiB, remains offline and unprivileged, and has a read-only root.
It runs the typed controls before the heap controls. Source and build inventories
must match before and after. The host independently reads the saved full JSON,
requires every named case and invalid-input witness, checks expected immutable
cache counts, and replays small physical heaps with Python's standard heapq.
The import case retains all 25 physical rows and every pop. The 2050-item growth
case saves complete popped rows and counts; its full physical comparisons occur
live in the native control, so saved review can independently check its key
multiset, numeric pop order and counts. Saved JSON cannot reconstruct Python
object identity, which remains a live control assertion.

All attempted container creations retain exact name/image authority. Cleanup
settles and removes the owned container, then proves exact absence. Partial
source, translation, object, ELF, build, JSON and process logs are retained even
after failure. The GitHub workflow serializes with other T3 Linux screens and
uses a source archive whose full manifest and independent source reviews must
verify before any build begins.

Root supplied the five initial source scaffolds. Their exact pre-edit hashes are
saved in `ROOT_SCAFFOLD_LINEAGE_v1.json`. Completion adds explicit frozen-source
and review binding, source-only staging, raw saved checks, and documentation.
It also corrects the materializer's parent path handling and binds the
canonical string inventory used for file/directory collision checks.
No local participant imports, scientific execution, native builds or controls
are used during preparation. Any root-owned upload and actual Linux outcomes
are recorded separately from this frozen source description.
