"""Future source/ELF-bound import; never compiles at runtime."""
import json
from pathlib import Path
import platform
import struct
import sys
import sysconfig
from source_provenance import HERE, SOURCE_RECEIPT, sha, verify_sources, verify_runtime


def load(build_dir, runtime):
    import importlib
    root = Path(build_dir).resolve()
    verify_sources()
    verify_runtime(runtime)
    spec = json.loads((HERE / "compile_spec.json").read_bytes())
    receipt = json.loads((root / "BUILD_RECEIPT.json").read_bytes())
    if (receipt["build_succeeded"] is not True
            or receipt["source_receipt_sha256"] != sha(HERE / SOURCE_RECEIPT)
            or receipt["runtime_pins_sha256"] != sha(HERE / "RUNTIME_PINS.json")
            or receipt["compile_spec_sha256"] != sha(HERE / "compile_spec.json")
            or sys.platform != "linux" or platform.machine() != "x86_64"
            or list(sys.version_info[:3]) != spec["python"] or struct.calcsize("P") != 8 or sys.byteorder != "little"):
        raise ValueError("source, build or Linux ABI authority differs")
    generated_rows = receipt.get("generated_C", [])
    if len(generated_rows) != 1 or generated_rows[0].get("module") != "dynamic_arena_chain":
        raise ValueError("actual compiled C source binding required")
    for row in generated_rows:
        path = root / row["path"]
        if (path.suffix != ".c" or not path.resolve().is_relative_to(root)
                or path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]):
            raise ValueError("actual compiled C source differs")
    paths = {}
    for row in receipt["extensions"]:
        path = root / row["path"]
        expected = root / "native" / (row["module"] + sysconfig.get_config_var("EXT_SUFFIX"))
        if path != expected or path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("native ELF artifact differs")
        paths[row["module"]] = path
    if set(paths) != set(spec["modules"]):
        raise ValueError("native extension roster differs")
    from importlib.metadata import version
    if {name: version(name) for name in spec["dependencies"]} != spec["dependencies"]:
        raise ValueError("loaded runtime dependencies differ from compiled ABI")
    sys.path.insert(0, str(root / "native"))
    modules = {}
    for name in ("dynamic_arena_chain",):
        module = importlib.import_module(name)
        if Path(module.__file__).resolve() != paths[name].resolve():
            raise ValueError("native module loaded from wrong path")
        modules[name] = module
    return modules
