"""Future explicit Linux build; does not import participants or run controls."""
import argparse
import json
import os
from pathlib import Path
import platform
import struct
import sys
import sysconfig
from source_provenance import HERE, SOURCE_RECEIPT, sha, verify_runtime, verify_sources


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    output = args.out.resolve()
    if output.exists():
        raise ValueError("fresh build directory required")
    spec = json.loads((HERE / "compile_spec.json").read_bytes())
    if (sys.platform != "linux" or platform.machine() != "x86_64"
            or sys.implementation.name != "cpython" or list(sys.version_info[:3]) != spec["python"]
            or struct.calcsize("P") != 8 or sys.byteorder != "little"):
        raise ValueError("pinned Linux x86_64 CPython ABI required")
    from importlib.metadata import version
    installed = {name: version(name) for name in spec["dependencies"]}
    if installed != spec["dependencies"]:
        raise ValueError("pinned build dependencies differ")
    ambient = {name: os.environ.get(name, "") for name in ("CFLAGS", "CPPFLAGS", "LDFLAGS")}
    unsafe = ("-ffast-math", "-Ofast", "-funsafe-math-optimizations", "-ffinite-math-only",
              "-freciprocal-math", "-fassociative-math")
    if any(flag in value for value in ambient.values() for flag in unsafe):
        raise ValueError("unsafe ambient compiler flag")
    sources = verify_sources()
    runtime = verify_runtime(args.runtime)
    output.mkdir(parents=True)
    receipt = {"schema": "t3-native-authoritative-chain-build-v1", "build_succeeded": False,
        "source_receipt_sha256": sha(HERE / SOURCE_RECEIPT),
        "runtime_pins_sha256": sha(HERE / "RUNTIME_PINS.json"), "compile_spec_sha256": sha(HERE / "compile_spec.json"),
        "ABI": {"python": list(sys.version_info[:3]), "implementation": sys.implementation.name,
                "platform": sys.platform, "machine": platform.machine(), "pointer_bits": struct.calcsize("P") * 8,
                "byteorder": sys.byteorder, "extension_suffix": sysconfig.get_config_var("EXT_SUFFIX")},
        "dependencies": installed, "ambient_flags": ambient,
        "participant_imported": False, "market_executed": False, "speed_claim": False}
    try:
        from Cython.Build import cythonize
        from setuptools import Extension
        from setuptools.dist import Distribution
        extensions = cythonize([Extension(name, [str(HERE / (name + ".pyx"))], extra_compile_args=spec["compile_flags"])
                                for name in spec["modules"]], include_path=[str(HERE)],
            build_dir=str(output / "generated"), compiler_directives=spec["directives"], force=True, annotate=False)
        generated_rows = []
        for extension in extensions:
            if extension.name not in spec["modules"] or len(extension.sources) != 1:
                raise ValueError("one actual generated C per native module required")
            generated = Path(extension.sources[0]).resolve()
            relative = generated.relative_to(output)
            if generated.suffix != ".c" or not generated.is_file():
                raise ValueError("actual generated C compilation source required")
            generated_rows.append({"module": extension.name, "path": str(relative),
                "bytes": generated.stat().st_size, "sha256": sha(generated)})
        receipt["generated_C"] = generated_rows
        dist = Distribution({"name": "t3-native-authoritative-chain-proof", "ext_modules": extensions})
        command = dist.get_command_obj("build_ext")
        command.build_lib, command.build_temp = str(output / "native"), str(output / "objects")
        command.inplace = False
        command.ensure_finalized()
        command.run()
        artifact_rows = []
        for name in spec["modules"]:
            path = output / "native" / (name + sysconfig.get_config_var("EXT_SUFFIX"))
            if not path.is_file():
                raise ValueError("compiled extension absent")
            artifact_rows.append({"module": name, "path": str(path.relative_to(output)),
                                  "bytes": path.stat().st_size, "sha256": sha(path),
                                  "control_only": name == "trader_probe"})
        for row in generated_rows:
            generated = output / row["path"]
            if generated.stat().st_size != row["bytes"] or sha(generated) != row["sha256"]:
                raise ValueError("actual compiled C source changed")
        if verify_sources() != sources or verify_runtime(args.runtime) != runtime:
            raise ValueError("sources changed during native build")
        receipt.update(build_succeeded=True, extensions=artifact_rows, extension_build_count=len(artifact_rows))
    except BaseException as error:
        receipt["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "BUILD_RECEIPT.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__":
    main()
