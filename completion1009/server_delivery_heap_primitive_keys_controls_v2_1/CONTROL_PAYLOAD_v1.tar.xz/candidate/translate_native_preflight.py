"""Future pinned Linux Cython translation only; no participant import or ELF."""
import argparse
import hashlib
import json
import platform
import struct
import sys
from importlib.metadata import version
from pathlib import Path
from source_provenance import HERE, SOURCE_RECEIPT, sha, verify_runtime, verify_sources


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    output = args.out.resolve()
    if output.exists():
        raise ValueError("fresh translation evidence required")
    spec = json.loads((HERE / "compile_spec.json").read_bytes())
    if (sys.platform != spec["platform"] or platform.machine() != spec["machine"]
            or sys.implementation.name != spec["implementation"]
            or list(sys.version_info[:3]) != spec["python"]
            or struct.calcsize("P") * 8 != spec["pointer_bits"]
            or sys.byteorder != spec["byteorder"]):
        raise ValueError("pinned Linux CPython translation environment required")
    installed = {name: version(name) for name in spec["dependencies"]}
    if installed != spec["dependencies"]:
        raise ValueError("pinned translation dependencies differ")
    sources, runtime = verify_sources(), verify_runtime(args.runtime)
    output.mkdir(parents=True)
    receipt = {"schema": "t3-cython-translation-only-preflight-v1", "translation_succeeded": False,
               "source_receipt_sha256": sha(HERE / SOURCE_RECEIPT),
               "compile_spec_sha256": sha(HERE / "compile_spec.json"),
               "runtime_pins_sha256": sha(HERE / "RUNTIME_PINS.json"),
               "dependencies": installed, "C_compiler_run": False, "ELF_built": False,
               "participant_imported": False, "market_executed": False,
               "runtime_pass": False, "speed_claim": False}
    try:
        from Cython.Build import cythonize
        from setuptools import Extension
        extensions = cythonize(
            [Extension(name, [str(HERE / (name + ".pyx"))],
                       extra_compile_args=spec["compile_flags"]) for name in spec["modules"]],
            include_path=[str(HERE)], build_dir=str(output / "generated"),
            compiler_directives=spec["directives"], force=True, annotate=False)
        if len(extensions) != len(spec["modules"]):
            raise ValueError("translation module count differs")
        rows = []
        for extension in extensions:
            if extension.name not in spec["modules"] or len(extension.sources) != 1:
                raise ValueError("unexpected translated source")
            path = Path(extension.sources[0]).resolve()
            relative = path.relative_to(output)
            if (path.suffix != ".c" or not path.is_file()
                    or any(part.startswith("._") or part == "__pycache__" for part in relative.parts)):
                raise ValueError("ordinary generated C source required")
            rows.append({"module": extension.name, "path": str(relative),
                         "bytes": path.stat().st_size,
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        if verify_sources() != sources or verify_runtime(args.runtime) != runtime:
            raise ValueError("input sources changed during translation")
        receipt.update(translation_succeeded=True, generated_C=rows)
    except BaseException as error:
        receipt["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "TRANSLATION_RECEIPT.json").write_text(
            json.dumps(receipt, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__":
    main()
