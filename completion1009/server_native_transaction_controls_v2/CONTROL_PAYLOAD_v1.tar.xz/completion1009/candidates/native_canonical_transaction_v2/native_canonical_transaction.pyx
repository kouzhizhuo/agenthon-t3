# cython: language_level=3, annotation_typing=False, infer_types=False

import observer as _observer
from abides_markets.agents.exchange_agent import ExchangeAgent, logger as exchange_logger
from abides_markets.agents.financial_agent import FinancialAgent
from abides_markets.messages.market import MarketClosedMsg, MarketHoursMsg, MarketHoursRequestMsg, MarketClosePriceRequestMsg, MarketClosePriceMsg
from abides_markets.messages.marketdata import BookImbalanceDataMsg, L1SubReqMsg, L2SubReqMsg, L3SubReqMsg, TransactedVolSubReqMsg, MarketDataSubReqMsg, L1DataMsg, L2DataMsg, L3DataMsg, TransactedVolDataMsg, BookImbalanceSubReqMsg, MarketDataEventMsg
from abides_markets.messages.order import LimitOrderMsg, MarketOrderMsg, PartialCancelOrderMsg, CancelOrderMsg, ModifyOrderMsg, ReplaceOrderMsg, OrderMsg
from abides_markets.messages.query import QueryLastTradeMsg, QueryLastTradeResponseMsg, QueryMsg, QuerySpreadMsg, QuerySpreadResponseMsg, QueryOrderStreamMsg, QueryOrderStreamResponseMsg, QueryTransactedVolMsg, QueryTransactedVolResponseMsg

# Derived by prepare_transaction_source_v1.py from pinned original ASTs.
# Compilation and simulation are separate root-scheduled operations.
import logging
import sys
import warnings
from copy import deepcopy
import numpy as np
import pandas as pd
from abides_core.utils import str_to_ns, ns_date
from abides_markets.messages.orderbook import OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg, OrderPartialCancelledMsg, OrderModifiedMsg, OrderReplacedMsg
from abides_markets.orders import LimitOrder, MarketOrder, Order, Side
from abides_markets.price_level import PriceLevel as OriginalPriceLevel
from abides_markets.order_book import OrderBook as OriginalOrderBook
from abides_markets.order_book import logger as book_logger

def _positive_row(row):
    return row[1] > 0


cdef class NativeLevel:

    def __init__(self, orders):
        if len(orders) == 0:
            raise ValueError('At least one LimitOrder must be given when initialising a PriceLevel.')
        self.visible_orders = []
        self.hidden_orders = []
        self.price = orders[0][0].limit_price
        self.side = orders[0][0].side
        for (order, metadata) in orders:
            self._add_order(order, metadata)

    def add_order(self, order, metadata=None):
        return self._add_order(order, metadata)

    cdef object _add_order(self, object order, object metadata=None):
        if order.is_hidden:
            self.hidden_orders.append((order, metadata or {}))
        elif order.insert_by_id:
            insert_index = 0
            for (order2, _) in self.visible_orders:
                if order2.order_id > order.order_id:
                    break
                insert_index += 1
            self.visible_orders.insert(insert_index, (order, metadata or {}))
        else:
            self.visible_orders.append((order, metadata or {}))

    def update_order_quantity(self, order_id, new_quantity):
        return self._update_order_quantity(order_id, new_quantity)

    cdef object _update_order_quantity(self, object order_id, object new_quantity):
        if new_quantity == 0:
            return False
        for (i, (order, metadata)) in enumerate(self.visible_orders):
            if order.order_id == order_id:
                if new_quantity <= order.quantity:
                    order.quantity = new_quantity
                else:
                    self.visible_orders.pop(i)
                    order.quantity = new_quantity
                    self.visible_orders.append((order, metadata))
                return True
        for (i, (order, metadata)) in enumerate(self.hidden_orders):
            if order.order_id == order_id:
                if new_quantity <= order.quantity:
                    order.quantity = new_quantity
                else:
                    self.hidden_orders.pop(i)
                    order.quantity = new_quantity
                    self.hidden_orders.append((order, metadata))
                return True
        return False

    def remove_order(self, order_id):
        return self._remove_order(order_id)

    cdef object _remove_order(self, object order_id):
        for (i, (book_order, _)) in enumerate(self.visible_orders):
            if book_order.order_id == order_id:
                return self.visible_orders.pop(i)
        for (i, (book_order, _)) in enumerate(self.hidden_orders):
            if book_order.order_id == order_id:
                return self.hidden_orders.pop(i)
        return None

    def peek(self):
        return self._peek()

    cdef object _peek(self):
        if len(self.visible_orders) > 0:
            return self.visible_orders[0]
        elif len(self.hidden_orders) > 0:
            return self.hidden_orders[0]
        else:
            raise ValueError("Can't peek at LimitOrder in PriceLevel as it contains no orders")

    def pop(self):
        return self._pop()

    cdef object _pop(self):
        if len(self.visible_orders) > 0:
            return self.visible_orders.pop(0)
        elif len(self.hidden_orders) > 0:
            return self.hidden_orders.pop(0)
        else:
            raise ValueError("Can't pop LimitOrder from PriceLevel as it contains no orders")

    def order_is_match(self, order):
        return self._order_is_match(order)

    cdef object _order_is_match(self, object order):
        if order.side == self.side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if order.side.is_bid() and order.limit_price >= self.price and (not (order.is_post_only and self._total_quantity() == 0)):
            return True
        if order.side.is_ask() and order.limit_price <= self.price and (not (order.is_post_only and self._total_quantity() == 0)):
            return True
        return False

    def order_has_better_price(self, order):
        return self._order_has_better_price(order)

    cdef object _order_has_better_price(self, object order):
        if order.side != self.side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if order.side.is_bid() and order.limit_price > self.price:
            return True
        if order.side.is_ask() and order.limit_price < self.price:
            return True
        return False

    def order_has_worse_price(self, order):
        return self._order_has_worse_price(order)

    cdef object _order_has_worse_price(self, object order):
        if order.side != self.side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if order.side.is_bid() and order.limit_price < self.price:
            return True
        if order.side.is_ask() and order.limit_price > self.price:
            return True
        return False

    def order_has_equal_price(self, order):
        return self._order_has_equal_price(order)

    cdef object _order_has_equal_price(self, object order):
        if order.side != self.side:
            raise ValueError('Attempted to compare order on wrong side of book')
        return order.limit_price == self.price

    @property
    def total_quantity(self):
        return self._total_quantity()

    cdef object _total_quantity(self):
        quantities = []
        for order, _ in self.visible_orders:
            quantities.append(order.quantity)
        return sum(quantities)

    @property
    def is_empty(self):
        return self._is_empty()

    cdef object _is_empty(self):
        return len(self.visible_orders) == 0 and len(self.hidden_orders) == 0

    def __eq__(self, other):
        if not isinstance(other, NativeLevel):
            raise NotImplementedError
        return self.visible_orders == other.visible_orders and self.hidden_orders == other.hidden_orders


cdef class NativeBook:

    def __init__(self, owner, symbol):
        self._scheduler = None
        self.owner = owner
        self.symbol = symbol
        self.bids = []
        self.asks = []
        self.last_trade = None
        self.book_log2 = []
        self.quotes_seen = set()
        self.history = []
        self.last_update_ts = self.owner.mkt_open
        self.buy_transactions = []
        self.sell_transactions = []

    def handle_limit_order(self, order, quiet=False):
        return self._handle_limit_order(order, quiet)

    cdef object _handle_limit_order(self, object order, object quiet=False):
        cdef NativeLevel level
        if order.symbol != self.symbol:
            warnings.warn(f'{order.symbol} order discarded. Does not match OrderBook symbol: {self.symbol}')
            return
        if order.quantity <= 0 or int(order.quantity) != order.quantity:
            warnings.warn(f'{order.symbol} order discarded. Quantity ({order.quantity}) must be a positive integer.')
            return
        if order.limit_price < 0 or int(order.limit_price) != order.limit_price:
            warnings.warn(f'{order.symbol} order discarded. Limit price ({order.limit_price}) must be a positive integer.')
            return
        executed = []
        while True:
            stp_policy = getattr(self.owner, 'stp_policy', None)
            if stp_policy:
                opp = self.asks if order.side.is_bid() else self.bids
                if opp and (<NativeLevel>opp[0])._order_is_match(order):
                    resting = (<NativeLevel>opp[0])._peek()[0]
                    if resting.agent_id == order.agent_id:
                        if stp_policy == 'cancel_oldest' and self._cancel_order(resting, None, None, quiet):
                            continue
                        if stp_policy != 'cancel_oldest':
                            if not quiet:
                                self._send(order.agent_id, OrderCancelledMsg(deepcopy(order)))
                            break
            matched_order = self._execute_order(order)
            if matched_order is not None:
                assert matched_order.fill_price is not None
                executed.append((matched_order.quantity, matched_order.fill_price))
                if order.quantity <= 0:
                    break
            else:
                self._enter_order(deepcopy(order), None, quiet)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('ACCEPTED: new order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order acceptance to agent {} for order {}', order.agent_id, order.order_id)
                if not quiet:
                    self._send(order.agent_id, OrderAcceptedMsg(order))
                break
        if self.bids:
            self.owner.logEvent('BEST_BID', '{},{},{}'.format(self.symbol, self.bids[0].price, (<NativeLevel>self.bids[0])._total_quantity()))
        if self.asks:
            self.owner.logEvent('BEST_ASK', '{},{},{}'.format(self.symbol, self.asks[0].price, (<NativeLevel>self.asks[0])._total_quantity()))
        if len(executed) > 0:
            trade_qty = 0
            trade_price = 0
            for (q, p) in executed:
                if book_logger.isEnabledFor(10):
                    book_logger.debug('Executed: {} @ {}', q, p)
                trade_qty += q
                trade_price += p * q
            avg_price = int(round(trade_price / trade_qty))
            if book_logger.isEnabledFor(10):
                book_logger.debug(f'Avg: {trade_qty} @ ${avg_price:0.4f}')
            self.owner.logEvent('LAST_TRADE', f'{trade_qty},${avg_price:0.4f}')
            self.last_trade = avg_price

    def handle_market_order(self, order):
        return self._handle_market_order(order)

    cdef object _handle_market_order(self, object order):
        cdef NativeLevel level
        if order.symbol != self.symbol:
            warnings.warn(f'{order.symbol} order discarded. Does not match OrderBook symbol: {self.symbol}')
            return
        if order.quantity <= 0 or int(order.quantity) != order.quantity:
            warnings.warn(f'{order.symbol} order discarded.  Quantity ({order.quantity}) must be a positive integer.')
            return
        order = deepcopy(order)
        while order.quantity > 0:
            stp_policy = getattr(self.owner, 'stp_policy', None)
            if stp_policy:
                opp = self.asks if order.side.is_bid() else self.bids
                if opp and (<NativeLevel>opp[0])._peek()[0].agent_id == order.agent_id:
                    if stp_policy == 'cancel_oldest' and self._cancel_order((<NativeLevel>opp[0])._peek()[0]):
                        continue
                    if stp_policy != 'cancel_oldest':
                        self._send(order.agent_id, OrderCancelledMsg(deepcopy(order)))
                        break
            if self._execute_order(order) is None:
                break

    def execute_order(self, order):
        return self._execute_order(order)

    cdef object _execute_order(self, object order):
        cdef NativeLevel level
        book = self.asks if order.side.is_bid() else self.bids
        if len(book) == 0:
            return None
        elif isinstance(order, LimitOrder) and (not (<NativeLevel>book[0])._order_is_match(order)):
            return None
        elif order.tag in ['MR_preprocess_ADD', 'MR_preprocess_REPLACE']:
            self.owner.logEvent(order.tag + '_POST_ONLY', {'order_id': order.order_id})
            return None
        else:
            is_ptc_exec = False
            if order.quantity >= (<NativeLevel>book[0])._peek()[0].quantity:
                (matched_order, matched_order_metadata) = (<NativeLevel>book[0])._pop()
                if matched_order.is_price_to_comply:
                    is_ptc_exec = True
                    if matched_order_metadata['ptc_hidden'] == False:
                        raise Exception('Should not be executing on the visible half of a price to comply order!')
                    assert (<NativeLevel>book[1])._remove_order(matched_order.order_id) is not None
                    if (<NativeLevel>book[1])._is_empty():
                        del book[1]
                if (<NativeLevel>book[0])._is_empty():
                    del book[0]
            else:
                (book_order, book_order_metadata) = (<NativeLevel>book[0])._peek()
                matched_order = deepcopy(book_order)
                matched_order.quantity = order.quantity
                book_order.quantity -= matched_order.quantity
                if book_order.is_price_to_comply:
                    is_ptc_exec = True
                    if book_order_metadata['ptc_hidden'] == False:
                        raise Exception('Should not be executing on the visible half of a price to comply order!')
                    book_order_metadata['ptc_other_half'].quantity -= matched_order.quantity
            matched_order.fill_price = matched_order.limit_price
            if order.side.is_bid():
                self.buy_transactions.append((self.owner.current_time, matched_order.quantity))
            else:
                self.sell_transactions.append((self.owner.current_time, matched_order.quantity))
            self.history.append(dict(time=self.owner.current_time, type='EXEC', order_id=matched_order.order_id, agent_id=matched_order.agent_id, oppos_order_id=order.order_id, oppos_agent_id=order.agent_id, side='SELL' if order.side.is_bid() else 'BUY', quantity=matched_order.quantity, price=matched_order.limit_price if is_ptc_exec else None))
            filled_order = deepcopy(order)
            filled_order.quantity = matched_order.quantity
            filled_order.fill_price = matched_order.fill_price
            order.quantity -= filled_order.quantity
            if book_logger.isEnabledFor(10):
                book_logger.debug('MATCHED: new order {} vs old order {}', filled_order, matched_order)
            if book_logger.isEnabledFor(10):
                book_logger.debug('SENT: notifications of order execution to agents {} and {} for orders {} and {}', filled_order.agent_id, matched_order.agent_id, filled_order.order_id, matched_order.order_id)
            self._send(matched_order.agent_id, OrderExecutedMsg(matched_order))
            self._send(order.agent_id, OrderExecutedMsg(filled_order))
            if self.owner.book_logging == True:
                self._append_book_log2()
            return matched_order

    def enter_order(self, order, metadata=None, quiet=False):
        return self._enter_order(order, metadata, quiet)

    cdef object _enter_order(self, object order, object metadata=None, object quiet=False):
        cdef NativeLevel price_level
        if order.is_price_to_comply and (metadata is None or metadata == {} or 'ptc_hidden' not in metadata):
            hidden_order = deepcopy(order)
            visible_order = deepcopy(order)
            hidden_order.is_hidden = True
            hidden_order.limit_price += 1 if order.side.is_bid() else -1
            hidden_order_metadata = dict(ptc_hidden=True, ptc_other_half=visible_order)
            visible_order_metadata = dict(ptc_hidden=False, ptc_other_half=hidden_order)
            self._enter_order(hidden_order, hidden_order_metadata, quiet=True)
            self._enter_order(visible_order, visible_order_metadata, quiet=quiet)
            return
        book = self.bids if order.side.is_bid() else self.asks
        if len(book) == 0:
            book.append(NativeLevel([(order, metadata or {})]))
        elif (<NativeLevel>book[-1])._order_has_worse_price(order):
            book.append(NativeLevel([(order, metadata or {})]))
        else:
            for (i, price_level) in enumerate(book):
                if price_level._order_has_better_price(order):
                    book.insert(i, NativeLevel([(order, metadata or {})]))
                    break
                elif price_level._order_has_equal_price(order):
                    (<NativeLevel>book[i])._add_order(order, metadata or {})
                    break
        if quiet == False:
            self.history.append(dict(time=self.owner.current_time, type='LIMIT', order_id=order.order_id, agent_id=order.agent_id, side=order.side.value, quantity=order.quantity, price=order.limit_price))
        if self.owner.book_logging == True and quiet == False:
            self._append_book_log2()

    def cancel_order(self, order, tag=None, cancellation_metadata=None, quiet=False):
        return self._cancel_order(order, tag, cancellation_metadata, quiet)

    cdef object _cancel_order(self, object order, object tag=None, object cancellation_metadata=None, object quiet=False):
        cdef NativeLevel price_level
        book = self.bids if order.side.is_bid() else self.asks
        if not book:
            return False
        for (i, price_level) in enumerate(book):
            if not price_level._order_has_equal_price(order):
                continue
            cancelled_order_result = price_level._remove_order(order.order_id)
            if cancelled_order_result is not None:
                (cancelled_order, metadata) = cancelled_order_result
                if price_level._is_empty():
                    del book[i]
                if book_logger.isEnabledFor(10):
                    book_logger.debug('CANCELLED: order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order cancellation to agent {} for order {}', cancelled_order.agent_id, cancelled_order.order_id)
                if cancelled_order.is_price_to_comply:
                    self._cancel_order(metadata['ptc_other_half'], None, None, True)
                if not quiet:
                    self.history.append(dict(time=self.owner.current_time, type='CANCEL', order_id=cancelled_order.order_id, tag=tag, metadata=cancellation_metadata if tag == 'auctionFill' else None))
                    self._send(order.agent_id, OrderCancelledMsg(cancelled_order))
                self.last_update_ts = self.owner.current_time
                if self.owner.book_logging == True and quiet == False:
                    self._append_book_log2()
                return True
        return False

    def modify_order(self, order, new_order):
        return self._modify_order(order, new_order)

    cdef object _modify_order(self, object order, object new_order):
        cdef NativeLevel price_level
        if order.order_id != new_order.order_id:
            return
        book = self.bids if order.side.is_bid() else self.asks
        for price_level in book:
            if not price_level._order_has_equal_price(order):
                continue
            if price_level._update_order_quantity(order.order_id, new_order.quantity):
                self.history.append(dict(time=self.owner.current_time, type='MODIFY', order_id=order.order_id, new_side=order.side.value, new_quantity=new_order.quantity))
                if book_logger.isEnabledFor(10):
                    book_logger.debug('MODIFIED: order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order modification to agent {} for order {}', new_order.agent_id, new_order.order_id)
                self._send(order.agent_id, OrderModifiedMsg(new_order))
                self.last_update_ts = self.owner.current_time
                if self.owner.book_logging == True is not None:
                    self._append_book_log2()

    def partial_cancel_order(self, order, quantity, tag=None, cancellation_metadata=None):
        return self._partial_cancel_order(order, quantity, tag, cancellation_metadata)

    cdef object _partial_cancel_order(self, object order, object quantity, object tag=None, object cancellation_metadata=None):
        cdef NativeLevel price_level
        if order.order_id == 19653081:
            print('inside OB partialCancel')
        book = self.bids if order.side.is_bid() else self.asks
        new_order = deepcopy(order)
        new_order.quantity -= quantity
        for price_level in book:
            if not price_level._order_has_equal_price(order):
                continue
            if price_level._update_order_quantity(order.order_id, new_order.quantity):
                self.history.append(dict(time=self.owner.current_time, type='CANCEL_PARTIAL', order_id=order.order_id, quantity=quantity, tag=tag, metadata=cancellation_metadata if tag == 'auctionFill' else None))
                if book_logger.isEnabledFor(10):
                    book_logger.debug('CANCEL_PARTIAL: order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order partial cancellation to agent {} for order {}', new_order.agent_id, quantity)
                self._send(order.agent_id, OrderPartialCancelledMsg(new_order))
                self.last_update_ts = self.owner.current_time
                if self.owner.book_logging == True:
                    self._append_book_log2()

    def replace_order(self, agent_id, old_order, new_order):
        return self._replace_order(agent_id, old_order, new_order)

    cdef object _replace_order(self, object agent_id, object old_order, object new_order):
        if self._cancel_order(old_order, None, None, True) == True:
            self.history.append(dict(time=self.owner.current_time, type='REPLACE', old_order_id=old_order.order_id, new_order_id=new_order.order_id, quantity=new_order.quantity, price=new_order.limit_price))
            self._handle_limit_order(new_order, quiet=True)
            if book_logger.isEnabledFor(10):
                book_logger.debug('SENT: notifications of order replacement to agent {agent_id} for old order {old_order.order_id}, new order {new_order.order_id}')
            self._send(agent_id, OrderReplacedMsg(old_order, new_order))
        if self.owner.book_logging == True:
            self._append_book_log2()

    def append_book_log2(self):
        return self._append_book_log2()

    cdef object _append_book_log2(self):
        row = {'QuoteTime': self.owner.current_time, 'bids': np.array(self._get_l2_bid_data(depth=self.owner.book_log_depth)), 'asks': np.array(self._get_l2_ask_data(depth=self.owner.book_log_depth))}
        self.book_log2.append(row)

    def get_l1_bid_data(self):
        return self._get_l1_bid_data()

    cdef object _get_l1_bid_data(self):
        if len(self.bids) == 0:
            return None
        index = 0
        while not (<NativeLevel>self.bids[index])._total_quantity() > 0:
            index += 1
        return (self.bids[0].price, (<NativeLevel>self.bids[0])._total_quantity())

    def get_l1_ask_data(self):
        return self._get_l1_ask_data()

    cdef object _get_l1_ask_data(self):
        if len(self.asks) == 0:
            return None
        index = 0
        while not (<NativeLevel>self.asks[index])._total_quantity() > 0:
            index += 1
        return (self.asks[index].price, (<NativeLevel>self.asks[index])._total_quantity())

    def get_l2_bid_data(self, depth=sys.maxsize):
        return self._get_l2_bid_data(depth)

    cdef object _get_l2_bid_data(self, object depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self.bids[:depth]:
            rows.append((price_level.price, price_level._total_quantity()))
        return list(filter(_positive_row, rows))

    def get_l2_ask_data(self, depth=sys.maxsize):
        return self._get_l2_ask_data(depth)

    cdef object _get_l2_ask_data(self, object depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self.asks[:depth]:
            rows.append((price_level.price, price_level._total_quantity()))
        return list(filter(_positive_row, rows))

    def get_l3_bid_data(self, depth=sys.maxsize):
        return self._get_l3_bid_data(depth)

    cdef object _get_l3_bid_data(self, object depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self.bids[:depth]:
            quantities = []
            for order, _ in price_level.visible_orders:
                quantities.append(order.quantity)
            rows.append((price_level.price, quantities))
        return rows

    def get_l3_ask_data(self, depth=sys.maxsize):
        return self._get_l3_ask_data(depth)

    cdef object _get_l3_ask_data(self, object depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self.asks[:depth]:
            quantities = []
            for order, _ in price_level.visible_orders:
                quantities.append(order.quantity)
            rows.append((price_level.price, quantities))
        return rows

    def get_transacted_volume(self, lookback_period='10min'):
        return self._get_transacted_volume(lookback_period)

    cdef object _get_transacted_volume(self, object lookback_period='10min'):
        window_start = self.owner.current_time - str_to_ns(lookback_period)
        buy_transacted_volume = 0
        sell_transacted_volume = 0
        for (time, volume) in reversed(self.buy_transactions):
            if time < window_start:
                break
            buy_transacted_volume += volume
        for (time, volume) in reversed(self.sell_transactions):
            if time < window_start:
                break
            sell_transacted_volume += volume
        return (buy_transacted_volume, sell_transacted_volume)

    def get_imbalance(self):
        return self._get_imbalance()

    cdef object _get_imbalance(self):
        cdef NativeLevel price_level
        bid_quantities = []
        for price_level in self.bids:
            bid_quantities.append(price_level._total_quantity())
        bid_vol = sum(bid_quantities)
        ask_quantities = []
        for price_level in self.asks:
            ask_quantities.append(price_level._total_quantity())
        ask_vol = sum(ask_quantities)
        if bid_vol == ask_vol:
            return (0, None)
        elif bid_vol == 0:
            return (1.0, Side.ASK)
        elif ask_vol == 0:
            return (1.0, Side.BID)
        elif bid_vol < ask_vol:
            return (1 - bid_vol / ask_vol, Side.ASK)
        else:
            return (1 - ask_vol / bid_vol, Side.BID)

    def get_L1_snapshots(self):
        best_bids = []
        best_asks = []

        def safe_first(x):
            return x[0] if len(x) > 0 else np.array([None, None])
        for d in self.book_log2:
            best_bids.append([d['QuoteTime']] + safe_first(d['bids']).tolist())
            best_asks.append([d['QuoteTime']] + safe_first(d['asks']).tolist())
        best_bids = np.array(best_bids)
        best_asks = np.array(best_asks)
        return {'best_bids': best_bids, 'best_asks': best_asks}

    def bids_padding(self, book, nlevels):
        n = book.shape[0]
        if n == 0:
            return np.zeros((nlevels, 2), dtype=int)
        if n >= nlevels:
            return book[:nlevels, :]
        else:
            lowestprice = book[-1, 0] if len(book.shape) == 2 else book[0]
            npad = nlevels - n
            pad = np.transpose(np.array([-1 + np.arange(lowestprice, lowestprice - npad, -1, dtype=int), np.zeros(npad, dtype=int)]))
            if len(pad.shape) == 1:
                pad = pad.reshape(1, 2)
            return np.concatenate([book, pad])

    def asks_padding(self, book, nlevels):
        n = book.shape[0]
        if n == 0:
            return np.zeros((nlevels, 2), dtype=int)
        if n >= nlevels:
            return book[:nlevels, :]
        else:
            highestprice = book[-1, 0] if len(book.shape) == 2 else book[0]
            npad = nlevels - n
            pad = np.transpose(np.array([1 + np.arange(highestprice, highestprice + npad, 1, dtype=int), np.zeros(npad, dtype=int)]))
            if len(pad.shape) == 1:
                pad = pad.reshape(1, 2)
            return np.concatenate([book, pad])

    def get_L2_snapshots(self, nlevels):
        (times, bids, asks) = ([], [], [])
        for x in self.book_log2:
            times.append(x['QuoteTime'])
            bids.append(self.bids_padding(x['bids'], nlevels))
            asks.append(self.asks_padding(x['asks'], nlevels))
        bids = np.array(bids)
        asks = np.array(asks)
        times = np.array(times)
        return {'times': times, 'bids': bids, 'asks': asks}

    def get_l3_itch(self):
        history_l3 = pd.DataFrame(self.history)
        history_l3.loc[history_l3.tag == 'auctionFill', 'type'] = 'EXEC'
        history_l3.loc[history_l3.tag == 'auctionFill', 'quantity'] = history_l3.loc[history_l3.tag == 'auctionFill', 'metadata'].apply(lambda x: x['quantity'])
        history_l3.loc[history_l3.tag == 'auctionFill', 'price'] = history_l3.loc[history_l3.tag == 'auctionFill', 'metadata'].apply(lambda x: x['price'])
        history_l3['printable'] = np.nan
        history_l3['stock'] = np.nan
        if not 'REPLACE' in history_l3.type.unique():
            history_l3['new_order_id'] = np.nan
            history_l3['old_order_id'] = np.nan
        history_l3.loc[history_l3.type == 'REPLACE', 'order_id'] = history_l3.loc[history_l3.type == 'REPLACE', 'old_order_id']
        history_l3.loc[history_l3.type == 'EXEC', 'side'] = np.nan
        history_l3['type'] = history_l3['type'].replace({'LIMIT': 'ADD', 'CANCEL_PARTIAL': 'CANCEL', 'CANCEL': 'DELETE', 'EXEC': 'EXECUTE'})
        history_l3['side'] = history_l3['side'].replace({'ASK': 'S', 'BID': 'B'})
        history_l3['time'] = history_l3['time'] - ns_date(history_l3['time'])
        history_l3['price'] = history_l3['price'] * 100
        history_l3 = history_l3[['time', 'stock', 'type', 'order_id', 'side', 'quantity', 'price', 'new_order_id', 'printable']]
        history_l3 = history_l3.rename(columns={'time': 'timestamp', 'order_id': 'reference', 'new_order_id': 'new_reference', 'quantity': 'shares'})
        return history_l3

    def pretty_print(self, silent=True):
        assert self.last_trade is not None
        book = '{} order book as of {}\n'.format(self.symbol, self.owner.current_time)
        book += 'Last trades: simulated {:d}, historical {:d}\n'.format(self.last_trade, self.owner.oracle.observe_price(self.symbol, self.owner.current_time, sigma_n=0, random_state=self.owner.random_state))
        book += '{:10s}{:10s}{:10s}\n'.format('BID', 'PRICE', 'ASK')
        book += '{:10s}{:10s}{:10s}\n'.format('---', '-----', '---')
        for (quote, volume) in self._get_l2_ask_data()[-1::-1]:
            book += '{:10s}{:10s}{:10s}\n'.format('', '{:d}'.format(quote), '{:d}'.format(volume))
        for (quote, volume) in self._get_l2_bid_data():
            book += '{:10s}{:10s}{:10s}\n'.format('{:d}'.format(volume), '{:d}'.format(quote), '')
        if silent:
            return book
        else:
            print(book)
            return None



    cdef object _send(self, recipient_id, message):
        if self._scheduler is None:
            return self.owner.send_message(recipient_id, message)
        return self._scheduler._exchange_send(self.owner, recipient_id, message)

    def bind_scheduler(self, scheduler):
        cdef CanonicalScheduler native_scheduler
        if type(scheduler) is not CanonicalScheduler:
            raise ValueError('transaction book scheduler/raw owner identity differs')
        native_scheduler = scheduler
        if self.owner.kernel is not None and native_scheduler.kernel is not self.owner.kernel:
            raise ValueError('transaction book scheduler/raw owner identity differs')
        if self._scheduler is not None and self._scheduler is not native_scheduler:
            raise ValueError('transaction book scheduler already bound')
        self._scheduler = native_scheduler


# cython: language_level=3, annotation_typing=False, infer_types=False
"""Original heapq/Python arithmetic scheduler with direct cdef object-list ledger.

Source-only prototype. No synthetic envelopes, fixed-width event arithmetic,
changed callback/RNG path. Same-extension typed book return leg; production
installation authenticates original source tokens before configuration.
"""
import heapq
from datetime import datetime
from abides_core.kernel import Kernel as IncumbentKernel, logger, fmt_ts
from abides_core.message import Message, MessageBatch, WakeupMsg

cdef class FlatHeap:

    def __init__(self):
        self.queue = []

    def empty(self):
        return not self.queue

    def qsize(self):
        return len(self.queue)

cdef class ColumnLedger:

    def __init__(self):
        self.c0, self.c1, self.c2 = [], [], []
        self.c3, self.c4, self.c5 = [], [], []
        self.c6, self.c7, self.c8 = [], [], []
        self.columns = (self.c0, self.c1, self.c2, self.c3, self.c4,
                        self.c5, self.c6, self.c7, self.c8)

    def __len__(self):
        return len(self.c0)

    cdef void _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                     latency_ns, msg_type, order_id, causal_parent) except *:
        self.c0.append(message_id)
        self.c1.append(src_id)
        self.c2.append(dst_id)
        self.c3.append(t_send_ns)
        self.c4.append(t_recv_ns)
        self.c5.append(latency_ns)
        self.c6.append(msg_type)
        self.c7.append(order_id)
        self.c8.append(causal_parent)

    def append_values(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                      latency_ns, msg_type, order_id, causal_parent):
        self._append(message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                     latency_ns, msg_type, order_id, causal_parent)

cdef class CanonicalScheduler:

    def __init__(self, kernel):
        self.kernel = kernel
        self.exchange_owner = None

    def run(self, agent_actions=None):
        return self._run(agent_actions)

    def send(self, sender_id, recipient_id, message, delay=0):
        return self._send(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        return self._set_wakeup(sender_id, requested_time)

    cdef object _receive(self, kernel, sender_id, recipient_id, message):
        kernel.agent_current_times[recipient_id] += kernel.agent_computation_delays[recipient_id] + kernel.current_agent_additional_delay
        if kernel.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('After receive_message return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
        kernel._current_causal_uid = message.message_id
        kernel._deliver_seq_by_key[message.message_id, recipient_id] = kernel._deliver_seq
        kernel._deliver_seq += 1
        recipient = kernel.agents[recipient_id]
        if recipient is self.exchange_owner:
            self._exchange_receive(recipient, kernel.current_time, sender_id, message)
        else:
            recipient.receive_message(kernel.current_time, sender_id, message)

    cdef object _record_send(self, kernel, message, sender_id, recipient_id,
                             sent_time, deliver_at):
        cdef ColumnLedger ledger
        order = getattr(message, 'order', None)
        ledger = kernel._msg_ledger
        ledger._append(message.message_id, sender_id, recipient_id, sent_time,
            deliver_at, deliver_at - sent_time, message.type(),
            getattr(order, 'order_id', None), kernel._current_causal_uid)

    cdef object _run(self, agent_actions):
        cdef object kernel = self.kernel
        cdef ColumnLedger ledger
        """
        Start the simulation and processing of the message queue.
        Possibility to add the optional argument agent_actions. It is a list of dictionaries corresponding
        to actions to be performed by the experimental agent (Gym Agent).

        Arguments:
            agent_actions: A list of the different actions to be performed represented in a dictionary per action.

        Returns:
          - it is a dictionnary composed of two elements:
            - "done": boolean True if the simulation is done, else False. It is true when simulation reaches end_time or when the message queue is empty.
            - "results": it is the raw_state returned by the gym experimental agent, contains data that will be formated in the gym environement to formulate state, reward, info etc.. If
               there is no gym experimental agent, then it is None.
        """
        if agent_actions is not None:
            exp_agent, action_list = agent_actions
            exp_agent.apply_actions(action_list)
        while not kernel.messages.empty() and kernel.current_time and (kernel.current_time <= kernel.stop_time):
            kernel.current_time, sender_id, recipient_id, message = heapq.heappop(kernel.messages.queue)
            assert kernel.current_time is not None
            if kernel.ttl_messages % 100000 == 0:
                if logger.isEnabledFor(20):
                    logger.info('--- Simulation time: {}, messages processed: {:,}, wallclock elapsed: {:.2f}s ---'.format(fmt_ts(kernel.current_time), kernel.ttl_messages, (datetime.now() - kernel.event_queue_wall_clock_start).total_seconds()))
            if kernel.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('--- Kernel Event Queue pop ---')
                if logger.isEnabledFor(10):
                    logger.debug('Kernel handling {} message for agent {} at time {}'.format(message.type(), recipient_id, kernel.current_time))
            kernel.ttl_messages += 1
            kernel.current_agent_additional_delay = 0
            if isinstance(message, WakeupMsg):
                if kernel.agent_current_times[recipient_id] > kernel.current_time:
                    heapq.heappush(kernel.messages.queue, (kernel.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if kernel.show_trace_messages:
                        if logger.isEnabledFor(10):
                            logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
                    continue
                kernel.agent_current_times[recipient_id] = kernel.current_time
                kernel._current_causal_uid = message.message_id
                kernel._deliver_seq_by_key[message.message_id, recipient_id] = kernel._deliver_seq
                kernel._deliver_seq += 1
                ledger = kernel._msg_ledger
                ledger._append(message.message_id, recipient_id, recipient_id, None, kernel.current_time, 0, 'AGENT_WAKEUP', None, None)
                wakeup_result = kernel.agents[recipient_id].wakeup(kernel.current_time)
                kernel.agent_current_times[recipient_id] += kernel.agent_computation_delays[recipient_id] + kernel.current_agent_additional_delay
                if kernel.show_trace_messages:
                    if logger.isEnabledFor(10):
                        logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
                if wakeup_result != None:
                    return {'done': False, 'result': wakeup_result}
            else:
                if kernel.agent_current_times[recipient_id] > kernel.current_time:
                    heapq.heappush(kernel.messages.queue, (kernel.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if kernel.show_trace_messages:
                        if logger.isEnabledFor(10):
                            logger.debug('Agent in future: message requeued for {}'.format(fmt_ts(kernel.agent_current_times[recipient_id])))
                    continue
                kernel.agent_current_times[recipient_id] = kernel.current_time
                if isinstance(message, MessageBatch):
                    messages = message.messages
                    for message in messages:
                        self._receive(kernel, sender_id, recipient_id, message)
                else:
                    self._receive(kernel, sender_id, recipient_id, message)
        if kernel.messages.empty():
            if logger.isEnabledFor(10):
                logger.debug('--- Kernel Event Queue empty ---')
        if kernel.current_time and kernel.current_time > kernel.stop_time:
            if logger.isEnabledFor(10):
                logger.debug('--- Kernel Stop Time surpassed ---')
        if len(kernel.gym_agents) > 0:
            kernel.gym_agents[0].update_raw_state()
            return {'done': True, 'result': kernel.gym_agents[0].get_raw_state()}
        else:
            return {'done': True, 'result': None}

    cdef object _send(self, sender_id, recipient_id, message, delay):
        cdef object kernel = self.kernel
        """
        Called by an agent to send a message to another agent.

        The kernel supplies its own current_time (i.e. "now") to prevent possible abuse
        by agents. The kernel will handle computational delay penalties and/or network
        latency.

        Arguments:
            sender_id: ID of the agent sending the message.
            recipient_id: ID of the agent receiving the message.
            message: The ``Message`` class instance to send.
            delay: Represents an agent's request for ADDITIONAL delay (beyond the
                Kernel's mandatory computation + latency delays). Represents parallel
                pipeline processing delays (that should delay the transmission of
                messages but do not make the agent "busy" and unable to respond to new
                messages)
        """
        sent_time = kernel.current_time + kernel.agent_computation_delays[sender_id] + kernel.current_agent_additional_delay + delay
        if kernel.agent_latency_model is not None:
            latency: float = kernel.agent_latency_model.get_latency(sender_id=sender_id, recipient_id=recipient_id)
            deliver_at = sent_time + int(latency)
            if kernel.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('Kernel applied latency {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, kernel.current_agent_additional_delay, delay, kernel.agents[sender_id].name, kernel.agents[recipient_id].name, fmt_ts(deliver_at)))
        else:
            latency = kernel.agent_latency[sender_id][recipient_id]
            noise = kernel.random_state.choice(len(kernel.latency_noise), p=kernel.latency_noise)
            deliver_at = sent_time + int(latency + noise)
            if kernel.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('Kernel applied latency {}, noise {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, noise, kernel.current_agent_additional_delay, delay, kernel.agents[sender_id].name, kernel.agents[recipient_id].name, fmt_ts(deliver_at)))
        heapq.heappush(kernel.messages.queue, (deliver_at, sender_id, recipient_id, message))
        if isinstance(message, MessageBatch):
            _ledger_msgs = message.messages
            for _lm in _ledger_msgs:
                self._record_send(kernel, _lm, sender_id, recipient_id, sent_time, deliver_at)
        else:
            self._record_send(kernel, message, sender_id, recipient_id, sent_time, deliver_at)
        if kernel.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('Sent time: {}, current time {}, computation delay {}'.format(sent_time, fmt_ts(kernel.current_time), kernel.agent_computation_delays[sender_id]))
            if logger.isEnabledFor(10):
                logger.debug('Message queued: {}'.format(message))

    cdef object _set_wakeup(self, sender_id, requested_time):
        cdef object kernel = self.kernel
        """
        Called by an agent to receive a "wakeup call" from the kernel at some requested
        future time.

        NOTE: The agent is responsible for maintaining any required state; the kernel
        will not supply any parameters to the ``wakeup()`` call.

        Arguments:
            sender_id: The ID of the agent making the call.
            requested_time: Defaults to the next possible timestamp.  Wakeup time cannot
            be the current time or a past time.
        """
        if requested_time is None:
            requested_time = kernel.current_time + 1
        if kernel.current_time and requested_time < kernel.current_time:
            raise ValueError('set_wakeup() called with requested time not in future', 'current_time:', kernel.current_time, 'requested_time:', requested_time)
        if kernel.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('Kernel adding wakeup for agent {} at time {}'.format(sender_id, fmt_ts(requested_time)))
        heapq.heappush(kernel.messages.queue, (requested_time, sender_id, sender_id, WakeupMsg()))


    cdef object _exchange_receive(self, a, current_time, sender_id, message):
        '\n        Arguments:\n            current_time:\n            sender_id:\n            message:\n        '
        FinancialAgent.receive_message(a, current_time, sender_id, message)
        a.set_computation_delay(a.computation_delay)
        if current_time > a.mkt_close:
            if isinstance(message, OrderMsg):
                if isinstance(message, ModifyOrderMsg):
                    if exchange_logger.isEnabledFor(10):
                        exchange_logger.debug('{} received {}: OLD: {} NEW: {}'.format(a.name, message.type(), message.old_order, message.new_order))
                elif exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received {}: {}'.format(a.name, message.type(), message.order))
                self._exchange_send(a, sender_id, MarketClosedMsg())
                return
            elif isinstance(message, QueryMsg):
                pass
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received {}, discarded: market is closed.'.format(a.name, message.type()))
                self._exchange_send(a, sender_id, MarketClosedMsg())
                return
        if isinstance(message, OrderMsg):
            if a.log_orders:
                if isinstance(message, (ModifyOrderMsg, ReplaceOrderMsg)):
                    _observer.order(a, message.type(), message.new_order, deepcopy_event=False)
                else:
                    _observer.order(a, message.type(), message.order, deepcopy_event=False)
        else:
            _observer.diagnostic(a, message.type(), message)
        if isinstance(message, MarketDataSubReqMsg):
            if message.symbol not in a.order_books:
                return
            if message.cancel == True:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received MarketDataSubscriptionCancellation request from agent {}'.format(a.name, sender_id))
                for data_sub in a.data_subscriptions[message.symbol]:
                    if data_sub.agent_id == sender_id and data_sub.freq == message.freq and (data_sub.depth == message.depth) and (data_sub.__class__ == message.__class__):
                        a.data_subscriptions[message.symbol].remove(data_sub)
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received MarketDataSubscriptionRequest request from agent {}'.format(a.name, sender_id))
                if isinstance(message, L1SubReqMsg):
                    sub = a.L1DataSubscription(sender_id, current_time, message.freq)
                elif isinstance(message, L2SubReqMsg):
                    sub = a.L2DataSubscription(sender_id, current_time, message.freq, message.depth)
                elif isinstance(message, L3SubReqMsg):
                    sub = a.L3DataSubscription(sender_id, current_time, message.freq, message.depth)
                elif isinstance(message, TransactedVolSubReqMsg):
                    sub = a.TransactedVolDataSubscription(sender_id, current_time, message.freq, message.lookback)
                elif isinstance(message, BookImbalanceSubReqMsg):
                    sub = a.BookImbalanceDataSubscription(sender_id, current_time, False, message.min_imbalance)
                else:
                    raise Exception
                a.data_subscriptions[message.symbol].append(sub)
        if isinstance(message, MarketHoursRequestMsg):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received market hours request from agent {}'.format(a.name, sender_id))
            a.set_computation_delay(0)
            self._exchange_send(a, sender_id, MarketHoursMsg(a.mkt_open, a.mkt_close))
        elif isinstance(message, MarketClosePriceRequestMsg):
            a.market_close_price_subscriptions.append(sender_id)
        elif isinstance(message, QueryLastTradeMsg):
            symbol = message.symbol
            if symbol not in a.order_books:
                warnings.warn(f'Last trade request discarded. Unknown symbol: {symbol}')
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received QUERY_LAST_TRADE ({}) request from agent {}'.format(a.name, symbol, sender_id))
                self._exchange_send(a, sender_id, QueryLastTradeResponseMsg(symbol=symbol, last_trade=a.order_books[symbol].last_trade, mkt_closed=current_time > a.mkt_close))
        elif isinstance(message, QuerySpreadMsg):
            symbol = message.symbol
            depth = message.depth
            if symbol not in a.order_books:
                warnings.warn(f'Bid-ask spread request discarded. Unknown symbol: {symbol}')
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received QUERY_SPREAD ({}:{}) request from agent {}'.format(a.name, symbol, depth, sender_id))
                self._exchange_send(a, sender_id, QuerySpreadResponseMsg(symbol=symbol, depth=depth, bids=a.order_books[symbol].get_l2_bid_data(depth), asks=a.order_books[symbol].get_l2_ask_data(depth), last_trade=a.order_books[symbol].last_trade, mkt_closed=current_time > a.mkt_close))
        elif isinstance(message, QueryOrderStreamMsg):
            symbol = message.symbol
            length = message.length
            if symbol not in a.order_books:
                warnings.warn(f'Order stream request discarded. Unknown symbol: {symbol}')
            elif exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received QUERY_ORDER_STREAM ({}:{}) request from agent {}'.format(a.name, symbol, length, sender_id))
            self._exchange_send(a, sender_id, QueryOrderStreamResponseMsg(symbol=symbol, length=length, orders=a.order_books[symbol].history[1:length + 1], mkt_closed=current_time > a.mkt_close))
        elif isinstance(message, QueryTransactedVolMsg):
            symbol = message.symbol
            lookback_period = message.lookback_period
            if symbol not in a.order_books:
                warnings.warn(f'Order stream request discarded. Unknown symbol: {symbol}')
            elif exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received QUERY_TRANSACTED_VOLUME ({}:{}) request from agent {}'.format(a.name, symbol, lookback_period, sender_id))
            (bid_volume, ask_volume) = a.order_books[symbol].get_transacted_volume(lookback_period)
            self._exchange_send(a, sender_id, QueryTransactedVolResponseMsg(symbol=symbol, bid_volume=bid_volume, ask_volume=ask_volume, mkt_closed=current_time > a.mkt_close))
        elif isinstance(message, LimitOrderMsg):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received LIMIT_ORDER: {}'.format(a.name, message.order))
            if message.order.symbol not in a.order_books:
                warnings.warn(f'Limit Order discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>a.order_books[message.order.symbol])._handle_limit_order(deepcopy(message.order))
                self._publish(a)
        elif isinstance(message, MarketOrderMsg):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received MARKET_ORDER: {}'.format(a.name, message.order))
            if message.order.symbol not in a.order_books:
                warnings.warn(f'Market Order discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>a.order_books[message.order.symbol])._handle_market_order(deepcopy(message.order))
                self._publish(a)
        elif isinstance(message, CancelOrderMsg):
            tag = message.tag
            metadata = message.metadata
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received CANCEL_ORDER: {}'.format(a.name, message.order))
            if message.order.symbol not in a.order_books:
                warnings.warn(f'Cancellation request discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>a.order_books[message.order.symbol])._cancel_order(deepcopy(message.order), tag, metadata)
                self._publish(a)
        elif isinstance(message, PartialCancelOrderMsg):
            tag = message.tag
            metadata = message.metadata
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received PARTIAL_CANCEL_ORDER: {}, new order: {}'.format(a.name, message.order, message.quantity))
            if message.order.symbol not in a.order_books:
                warnings.warn(f'Modification request discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>a.order_books[message.order.symbol])._partial_cancel_order(deepcopy(message.order), message.quantity, tag, metadata)
                self._publish(a)
        elif isinstance(message, ModifyOrderMsg):
            old_order = message.old_order
            new_order = message.new_order
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received MODIFY_ORDER: {}, new order: {}'.format(a.name, old_order, new_order))
            if old_order.symbol not in a.order_books:
                warnings.warn(f'Modification request discarded. Unknown symbol: {old_order.symbol}')
            else:
                (<NativeBook>a.order_books[old_order.symbol])._modify_order(deepcopy(old_order), deepcopy(new_order))
                self._publish(a)
        elif isinstance(message, ReplaceOrderMsg):
            agent_id = message.agent_id
            order = message.old_order
            new_order = message.new_order
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received REPLACE_ORDER: {}, new order: {}'.format(a.name, order, new_order))
            if order.symbol not in a.order_books:
                warnings.warn(f'Replacement request discarded. Unknown symbol: {order.symbol}')
            else:
                (<NativeBook>a.order_books[order.symbol])._replace_order(agent_id, deepcopy(order), deepcopy(new_order))
                self._publish(a)

    cdef object _publish(self, a):
        '\n        The exchange agents sends an order book update to the agents using the\n        subscription API if one of the following conditions are met:\n\n        1) agent requests ALL order book updates (freq == 0)\n        2) order book update timestamp > last time agent was updated AND the orderbook\n           update time stamp is greater than the last agent update time stamp by a\n           period more than that specified in the freq parameter.\n        '
        for (symbol, data_subs) in a.data_subscriptions.items():
            book = a.order_books[symbol]
            for data_sub in data_subs:
                if isinstance(data_sub, a.FrequencyBasedSubscription):
                    messages = a.handle_frequency_based_data_subscription(symbol, data_sub)
                elif isinstance(data_sub, a.EventBasedSubscription):
                    messages = a.handle_event_based_data_subscription(symbol, data_sub)
                else:
                    raise Exception('Got invalid data subscription object')
                for message in messages:
                    self._exchange_send(a, data_sub.agent_id, message)
                if len(messages) > 0:
                    data_sub.last_update_ts = book.last_update_ts

    cdef object _exchange_send(self, a, recipient_id, message):
        if isinstance(message, (OrderAcceptedMsg, OrderCancelledMsg, OrderExecutedMsg)):
            assert a.kernel is not None
            self._send(a.id, recipient_id, message, a.pipeline_delay)
            if a.log_orders:
                _observer.order(a, message.type(), message.order)
        else:
            assert a.kernel is not None
            self._send(a.id, recipient_id, message, 0)

    def bind_exchange(self, exchange):
        if type(exchange) is not ExchangeAgent or exchange.kernel is not None and exchange.kernel is not self.kernel:
            raise ValueError('transaction requires admitted original exchange owner')
        if self.exchange_owner is not None and self.exchange_owner is not exchange:
            raise ValueError('transaction exchange already bound')
        for book in exchange.order_books.values():
            if type(book) is not NativeBook or book.owner is not exchange:
                raise ValueError('transaction typed book owner differs')
        self.exchange_owner = exchange
        for book in exchange.order_books.values():
            book.bind_scheduler(self)


class CanonicalKernel(IncumbentKernel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.messages = FlatHeap()
        self._msg_ledger = ColumnLedger()
        self._canonical_scheduler = CanonicalScheduler(self)

    def runner(self, agent_actions=None):
        return self._canonical_scheduler.run(agent_actions)

    def send_message(self, sender_id, recipient_id, message, delay=0):
        return self._canonical_scheduler.send(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        return self._canonical_scheduler.set_wakeup(sender_id, requested_time)
