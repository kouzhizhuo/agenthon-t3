cdef class FlatHeap:
    cdef dict __dict__

cdef class ColumnLedger:
    cdef dict __dict__
    cdef list c0, c1, c2, c3, c4, c5, c6, c7, c8
    cdef void _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                     latency_ns, msg_type, order_id, causal_parent) except *

cdef class CanonicalScheduler:
    cdef object kernel
    cdef object exchange_owner
    cdef object _run(self, agent_actions)
    cdef object _send(self, sender_id, recipient_id, message, delay)
    cdef object _set_wakeup(self, sender_id, requested_time)
    cdef object _receive(self, kernel, sender_id, recipient_id, message)
    cdef object _record_send(self, kernel, message, sender_id, recipient_id,
                             sent_time, deliver_at)
    cdef object _exchange_receive(self, a, current_time, sender_id, message)
    cdef object _exchange_send(self, a, recipient_id, message)
    cdef object _publish(self, a)

cdef class NativeLevel:
    cdef dict __dict__
    cdef object _add_order(self, object order, object metadata=*)
    cdef object _update_order_quantity(self, object order_id, object new_quantity)
    cdef object _remove_order(self, object order_id)
    cdef object _peek(self)
    cdef object _pop(self)
    cdef object _order_is_match(self, object order)
    cdef object _order_has_better_price(self, object order)
    cdef object _order_has_worse_price(self, object order)
    cdef object _order_has_equal_price(self, object order)
    cdef object _total_quantity(self)
    cdef object _is_empty(self)

cdef class NativeBook:
    cdef dict __dict__
    cdef CanonicalScheduler _scheduler
    cdef object _handle_limit_order(self, object order, object quiet=*)
    cdef object _handle_market_order(self, object order)
    cdef object _execute_order(self, object order)
    cdef object _enter_order(self, object order, object metadata=*, object quiet=*)
    cdef object _cancel_order(self, object order, object tag=*, object cancellation_metadata=*, object quiet=*)
    cdef object _modify_order(self, object order, object new_order)
    cdef object _partial_cancel_order(self, object order, object quantity, object tag=*, object cancellation_metadata=*)
    cdef object _replace_order(self, object agent_id, object old_order, object new_order)
    cdef object _append_book_log2(self)
    cdef object _get_l1_bid_data(self)
    cdef object _get_l1_ask_data(self)
    cdef object _get_l2_bid_data(self, object depth=*)
    cdef object _get_l2_ask_data(self, object depth=*)
    cdef object _get_l3_bid_data(self, object depth=*)
    cdef object _get_l3_ask_data(self, object depth=*)
    cdef object _get_transacted_volume(self, object lookback_period=*)
    cdef object _get_imbalance(self)
    cdef object _send(self, recipient_id, message)
