"""Explicit frozen-source build. This step never imports or executes the kernel."""
import argparse
import json
import os
from pathlib import Path
import sys
import sysconfig

from provenance import HERE, abi, dependencies, sha, verify_runtime, verify_sources


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    output = args.out.resolve()
    if output.exists():
        raise ValueError("fresh scheduler build directory required")
    spec = json.loads((HERE / "compile_spec.json").read_text())
    if (sys.implementation.name != spec["implementation"]
            or list(sys.version_info[:3]) != spec["python"]
            or sys.platform != "linux" or abi()["machine"] != "x86_64"
            or abi()["pointer_bits"] != 64 or abi()["byteorder"] != "little"):
        raise ValueError("scheduler requires the pinned Linux x86_64 CPython ABI")
    import Cython
    if Cython.__version__ != spec["cython"]:
        raise ValueError("scheduler requires pinned Cython 3.1.3")
    installed = dependencies(spec)
    ambient = {name: os.environ.get(name, "") for name in ("CFLAGS", "CPPFLAGS", "LDFLAGS")}
    unsafe = ("-ffast-math", "-Ofast", "-funsafe-math-optimizations", "-ffinite-math-only",
              "-freciprocal-math", "-fassociative-math")
    if any(flag in value for value in ambient.values() for flag in unsafe):
        raise ValueError("unsafe ambient compiler flags")
    source_before = verify_sources()
    runtime_before = verify_runtime(args.runtime)
    output.mkdir(parents=True)
    receipt = {"schema": "t3-native-canonical-transaction-build-v2",
        "candidate": HERE.name, "build_succeeded": False, "abi": abi(),
        "dependencies": installed, "cython": Cython.__version__,
        "source_receipt_sha256": sha(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"),
        "candidate_sources": source_before, "runtime": runtime_before,
        "compile_spec_sha256": sha(HERE / "compile_spec.json"),
        "pyx_sha256": sha(HERE / spec["source"]), "pxd_sha256": sha(HERE / spec["pxd"]),
        "control_probe_source_sha256": sha(HERE / spec["control_probe_source"]),
        "extension_build_count": 2, "build_invocations": 1,
        "production_extension_owners": 1, "control_probe_extensions": 1,
        "compiler_configuration": {name: sysconfig.get_config_var(name) for name in
            ("CC", "CXX", "CFLAGS", "CCSHARED", "LDSHARED")},
        "ambient_flags": ambient, "compile_flags": spec["compile_flags"],
        "directives": spec["directives"], "candidate_imported": False,
        "market_executed": False, "timing_claim": False}
    try:
        from Cython.Build import cythonize
        from setuptools import Extension
        from setuptools.dist import Distribution
        extensions = cythonize([
            Extension(spec["module"], [str(HERE / spec["source"])], extra_compile_args=spec["compile_flags"]),
            Extension(spec["control_probe_module"], [str(HERE / spec["control_probe_source"])], extra_compile_args=spec["compile_flags"])],
            include_path=[str(HERE)], build_dir=str(output / "generated"),
            compiler_directives=spec["directives"], force=True, annotate=False)
        distribution = Distribution({"name": "t3-native-canonical-transaction-proof",
                                     "ext_modules": extensions})
        command = distribution.get_command_obj("build_ext")
        command.build_lib, command.build_temp = str(output / "native"), str(output / "objects")
        command.inplace = False
        command.ensure_finalized()
        command.run()
        extension = output / "native" / (spec["module"] + sysconfig.get_config_var("EXT_SUFFIX"))
        control_probe = output / "native" / (spec["control_probe_module"] + sysconfig.get_config_var("EXT_SUFFIX"))
        generated = {str(path.relative_to(output)): sha(path) for path in
            sorted((output / "generated").rglob("*.c")) if not path.name.startswith("._")}
        if (not extension.is_file() or not control_probe.is_file() or len(generated) != 2 or verify_sources() != source_before
                or verify_runtime(args.runtime) != runtime_before):
            raise ValueError("missing artifact or source changed during scheduler build")
        receipt.update(build_succeeded=True,
            extension={"path": str(extension.relative_to(output)),
                       "bytes": extension.stat().st_size, "sha256": sha(extension)},
            control_probe={"path": str(control_probe.relative_to(output)),
                           "bytes": control_probe.stat().st_size, "sha256": sha(control_probe), "control_only": True},
            generated_c=generated)
    except BaseException as error:
        receipt["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "BUILD_RECEIPT.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
