"""Future isolated Linux finite controls; source preparation never runs main."""
import argparse
import hashlib
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def load_extension(name, path):
    if name in sys.modules:
        raise ValueError("fresh control extension owner required")
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or not isinstance(spec.loader, importlib.machinery.ExtensionFileLoader):
        raise ValueError("finite controls require real extension loader")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
        if Path(module.__file__).resolve() != path.resolve():
            raise ValueError("control extension origin differs")
    except BaseException:
        sys.modules.pop(name, None)
        raise
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--extension", type=Path, required=True)
    parser.add_argument("--probe", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("fresh complete boundary report required")
    for row in json.loads((HERE / "RUNTIME_PINS.json").read_text())["files"]:
        data = (args.runtime / row["path"]).read_bytes()
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            raise ValueError("finite controls runtime bytes differ")
    sys.path.insert(0, str(args.runtime.resolve()))
    from bootstrap import activate
    activate()
    import numpy as np
    native = load_extension("native_canonical_transaction", args.extension.resolve())
    probe = load_extension("transaction_owner_probe", args.probe.resolve())
    from transaction_fixtures import CASES, run_all
    report = {"schema": "t3-native-canonical-transaction-boundary-result-v2", "source_only": False,
        "production_hot_counters": False, "rankable": False, "timing_claim": False,
        "extension": str(args.extension.resolve()), "probe": str(args.probe.resolve()), "cases": [],
        "admission_children": [], "failures": []}
    try:
        report["cases"] = run_all(native, probe, np)
        assert len(report["cases"]) == len(CASES) == 28
        assert all(row["return_checked"] and row["same_extension_owner_checked"] for row in report["cases"])
        from transaction_admission_controls import run_all as admission_children
        report["admission_children"] = admission_children(args.runtime)
        assert len(report["admission_children"]) == 8
    except BaseException as error:
        report["failures"].append({"type": type(error).__name__, "args": repr(error.args)})
    report["all_passed"] = (len(report["cases"]) == 28 and len(report["admission_children"]) == 8
                            and not report["failures"])
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
