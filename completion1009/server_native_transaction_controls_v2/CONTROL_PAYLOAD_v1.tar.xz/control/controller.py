"""Bounded actual native build + full correctness container; no timing/publish."""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time
import uuid
from common import BASE, CANDIDATE, BASELINE, ENTRYPOINT, SOURCE_RECEIPT_SHA256, sha, inventory, verify_payload, write

PAYLOAD = Path(__file__).resolve().parents[1]


def call(args, command, label, seconds=60, allow_failure=False):
    path = args.evidence / (label + ".log")
    started = time.monotonic()
    result = None
    failure = None
    timed_out = False
    with path.open("xb") as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=seconds)
        except subprocess.TimeoutExpired as error:
            timed_out = True
            failure = {"type": type(error).__name__, "message": str(error)}
        except OSError as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    record = {"command": command, "returncode": None if result is None else result.returncode,
              "timed_out": timed_out, "failure": failure, "host_elapsed_sec": time.monotonic() - started,
              "log": {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}}
    write(args.evidence / (label + ".json"), record)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual bounded command failed: " + label)
    return record


def inspect(args, name, label):
    call(args, [args.docker, "inspect", name], label)
    value = json.loads((args.evidence / (label + ".log")).read_text())
    if type(value) is not list or len(value) != 1:
        raise ValueError("one actual inspected object required")
    return value[0]


def run(args):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("actual Linux amd64 host required")
    verify_payload(PAYLOAD)
    plan = json.loads((PAYLOAD / "CONTROL_PLAN.json").read_text())
    if (plan.get("schema") != "t3-native-transaction-v2-complete-controls-source-plan"
            or plan.get("prototype_only") is not False or plan.get("actual_execution") is not False
            or plan.get("timing_executed") is not False or plan.get("rankable") is not False
            or plan.get("candidate") != CANDIDATE
            or plan.get("candidate_source_receipt_sha256") != SOURCE_RECEIPT_SHA256
            or len(plan.get("candidate_sources", [])) != 30
            or len(plan.get("baseline_sources", {})) != 64):
        raise ValueError("sealed fixed candidate and source-only control plan required")
    for label, receipt_digest in (("candidate", SOURCE_RECEIPT_SHA256),
                                  ("wrapper", plan["wrapper_source_receipt_sha256"])):
        path = PAYLOAD / "source_review" / (label + ".json")
        review = json.loads(path.read_text())
        if (sha(path) != plan[label + "_review_sha256"]
                or review.get("status") != "PASS_SOURCE_ONLY"
                or review.get("unresolved_source_blockers") != []
                or review.get("frozen_source_receipt_sha256") != receipt_digest):
            raise ValueError("actual payload independent frozen source review differs")
    if sha(PAYLOAD / "source_review/WRAPPER_SOURCE_RECEIPT.json") != plan["wrapper_source_receipt_sha256"]:
        raise ValueError("actual payload wrapper receipt differs")
    if args.evidence.exists():
        raise ValueError("fresh transaction control evidence directory required")
    args.evidence.mkdir(parents=True)
    anonymous = args.evidence / "anonymous-docker-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        call(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    base = inspect(args, BASE, "base-inspect")
    if "sha256:5a190afe0bdfe7685e64cbf1aec30d39885199c85f688a971b8d4a0ab8d217eb" not in " ".join(base.get("RepoDigests", [])):
        raise ValueError("actual base digest differs")
    tag = "t3-native-transaction-controls-v2:" + uuid.uuid4().hex
    call(args, [args.docker, "build", "--platform", "linux/amd64", "--pull=false", "-t", tag,
                "-f", str(PAYLOAD / "control/Dockerfile"), str(PAYLOAD)], "image-build", 600)
    image = inspect(args, tag, "image-inspect")
    if image["Config"]["Entrypoint"] != ENTRYPOINT or image["Config"]["User"] != "65534:65534":
        raise ValueError("actual control image entry/user differs")
    evidence_name = "t3-transaction-evidence-" + uuid.uuid4().hex
    try:
        call(args, [args.docker, "create", "--name", evidence_name, tag], "evidence-create")
        copied = args.evidence / "installed"
        call(args, [args.docker, "cp", evidence_name + ":/opt/native-transaction-controls", str(copied)], "installed-copy")
    finally:
        call(args, [args.docker, "rm", "-f", evidence_name], "evidence-remove", allow_failure=True)
    # Actual installed source/build/ELF/proof bytes are retained and inspected.
    for row in plan["candidate_sources"]:
        actual = copied / CANDIDATE / row["path"]
        if actual.stat().st_size != row["bytes"] or sha(actual) != row["sha256"]:
            raise ValueError("installed candidate source differs")
    if inventory(copied / BASELINE) != plan["baseline_sources"]:
        raise ValueError("installed baseline source differs")
    for filename, row in plan["control_sources"].items():
        actual = copied / "control" / filename
        if actual.stat().st_size != row["bytes"] or sha(actual) != row["sha256"]:
            raise ValueError("actual installed control source differs")
    deployment = json.loads((copied / CANDIDATE / "DEPLOYMENT.json").read_text())
    authority = json.loads((copied / CANDIDATE / "DEPLOYMENT_AUTHORITY.json").read_text())
    proof = json.loads((copied / CANDIDATE / "DEPLOYMENT_PROOF.json").read_text())
    create = json.loads((copied / "build-proof-create.json").read_text())
    bindings = ("candidate", "abi", "extension_path", "extension_sha256", "extension_bytes",
                "build_receipt_sha256", "source_receipt_sha256", "runtime_pins_sha256",
                "compile_spec_sha256", "control_probe_source_sha256", "control_probe")
    extension = copied / CANDIDATE / deployment["extension_path"]
    probe = copied / CANDIDATE / deployment["control_probe"]["path"]
    if (deployment["schema"] != "t3-native-canonical-transaction-deployment-v2"
            or deployment["extension_sha256"] != sha(extension)
            or deployment["extension_bytes"] != extension.stat().st_size
            or deployment["control_probe"]["sha256"] != sha(probe)
            or deployment["control_probe"]["bytes"] != probe.stat().st_size
            or authority.get("schema") != "t3-native-transaction-external-authority-v2"
            or proof.get("schema") != "t3-native-transaction-deployment-proof-v2"
            or authority["audit_all_passed"] is not True or proof["audit_all_passed"] is not True
            or proof.get("actual_external_audit_executed") is not True
            or proof.get("actual_extension_loader") != "ExtensionFileLoader"
            or proof["deployment_sha256"] != sha(copied / CANDIDATE / "DEPLOYMENT.json")
            or proof["bindings"] != {key: deployment[key] for key in bindings}
            or any(authority[key] != deployment[key] for key in bindings)
            or authority["proof_report_sha256"] != sha(copied / CANDIDATE / "DEPLOYMENT_PROOF.json")
            or deployment["build_receipt_sha256"] != sha(copied / CANDIDATE / "BUILD_RECEIPT.json")
            or deployment["source_receipt_sha256"] != plan["candidate_source_receipt_sha256"]
            or sha(copied / CANDIDATE / "SOURCE_PREPARATION_RECEIPT_v1.json") != SOURCE_RECEIPT_SHA256
            or create.get("schema") != "t3-native-transaction-host-audit-result-v2"
            or create.get("mode") != "create" or create.get("audit_all_passed") is not True
            or create.get("proof") != proof or create.get("deployment_authority") != authority
            or create.get("deployment_proof_sha256") != sha(copied / CANDIDATE / "DEPLOYMENT_PROOF.json")
            or create.get("authority_sha256") != sha(copied / CANDIDATE / "DEPLOYMENT_AUTHORITY.json")):
        raise ValueError("actual built deployment/source/ELF/external authority differs")
    write(args.evidence / "ACTUAL_BUILD_INSPECTION.json", {
        "schema": "t3-native-transaction-v2-host-build-inspection", "all_passed": True,
        "base_image": base["Id"], "control_image": image["Id"], "installed_files": inventory(copied),
        "deployment": deployment, "authority": authority, "proof": proof,
        "source_ELF_external_proof_checked": True, "timing_executed": False, "rankable": False})
    inputs, outputs = args.evidence / "input", args.evidence / "output"
    inputs.mkdir(); outputs.mkdir(); outputs.chmod(0o777)
    write(inputs / "command.json", {"command": "native-transaction-v2-all-controls-before-timing"})
    name = "t3-native-transaction-controls-" + uuid.uuid4().hex
    try:
        call(args, [args.docker, "create", "--name", name, "--cpus", "4", "--memory", "16g", "--memory-swap", "16g",
            "--network", "none", "--read-only", "--user", "65534:65534", "--pids-limit", "256",
            "--ulimit", "nofile=1024:1024", "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456",
            "--security-opt", "no-new-privileges", "--cap-drop", "ALL", "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m",
            "--mount", "type=bind,src=" + str(inputs.resolve()) + ",dst=/input,readonly",
            "--mount", "type=bind,src=" + str(outputs.resolve()) + ",dst=/output", tag, "controls"], "fixture-create")
        before = inspect(args, name, "fixture-inspect-before")
        host = before["HostConfig"]
        if (before["Config"]["Entrypoint"] != ENTRYPOINT or before["Config"]["Cmd"] != ["controls"]
                or before["Config"]["User"] != "65534:65534" or host["NetworkMode"] != "none"
                or host["ReadonlyRootfs"] is not True or host["NanoCpus"] != 4000000000
                or host["Memory"] != 16 * 1024 ** 3 or host["MemorySwap"] != 16 * 1024 ** 3):
            raise ValueError("actual one-container resources/entry differ")
        limits = {item["Name"]: (item["Soft"], item["Hard"]) for item in host.get("Ulimits", [])}
        if (limits != {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
                or host.get("PidsLimit") != 256 or host.get("CapDrop") != ["ALL"]
                or not any(value in ("no-new-privileges", "no-new-privileges:true") for value in host.get("SecurityOpt", []))
                or host.get("Tmpfs", {}).get("/tmp") != "rw,noexec,nosuid,nodev,size=64m"):
            raise ValueError("actual fixture ulimits/capabilities/tmpfs differ")
        binds = [m for m in before["Mounts"] if m.get("Type") == "bind"]
        if (len(binds) != 2 or {m["Destination"]: (m["RW"], m["Source"]) for m in binds}
                != {"/input": (False, str(inputs.resolve())), "/output": (True, str(outputs.resolve()))}):
            raise ValueError("actual fixture mounts differ")
        call(args, [args.docker, "start", "-a", name], "fixture-run", 3600)
        after = inspect(args, name, "fixture-inspect-after")
        if after["State"]["ExitCode"] != 0 or after["State"].get("OOMKilled") is not False:
            raise ValueError("actual fixture process failed or OOM")
    finally:
        call(args, [args.docker, "rm", "-f", name], "fixture-remove", allow_failure=True)
    result = json.loads((outputs / "controls/RESULT.json").read_text())
    if (result.get("schema") != "t3-native-transaction-v2-control-container-result"
            or result.get("all_passed") is not True or result.get("timing_executed") is not False
            or result.get("rankable") is not False or result.get("boundary_case_count") != 69
            or result.get("fresh_admission_children") != 8 or result.get("full_market_equality") is not True
            or result.get("guard_subchecks") != 22 or result.get("scheduler_integration_children") != 5
            or result.get("official_gate") is not False
            or result.get("stages") != ["actual_host_proof_before", "41_scheduler_boundaries_33variants_99arms",
                "28_transaction_boundaries_8fresh_admission_children", "4_full_market_cases_2arms_16Parquets_9components",
                "actual_host_proof_after"]):
        raise ValueError("complete actual before-timing correctness result required")
    for name in ("host_proof_before", "host_proof_after"):
        actual_proof = result[name]
        if (actual_proof.get("schema") != "t3-native-transaction-host-audit-result-v2"
                or actual_proof.get("mode") != "verify" or actual_proof.get("audit_all_passed") is not True
                or actual_proof.get("proof") != proof or actual_proof.get("deployment_authority") != authority
                or actual_proof.get("deployment_proof_sha256") != authority["proof_report_sha256"]
                or actual_proof.get("authority_sha256") != sha(copied / CANDIDATE / "DEPLOYMENT_AUTHORITY.json")):
            raise ValueError("actual runtime proof differs from retained actual built image proof")
    if result["host_proof_before"] != result["host_proof_after"]:
        raise ValueError("actual before/after runtime proof differs")
    files = sorted((outputs / "controls/markets").glob("*/*/*.parquet"))
    if len(files) != 16:
        raise ValueError("exact16 actual full-market Parquet outputs required")
    for seed in (81009, 82009, 83009, 84009):
        for filename in ("trace.parquet", "message_trace.parquet"):
            left = outputs / "controls/markets/original_canonical" / str(seed) / filename
            right = outputs / "controls/markets/actual_native" / str(seed) / filename
            if left.read_bytes() != right.read_bytes():
                raise ValueError("host actual full-market Parquet bytes differ")
    if inventory(inputs) != {"command.json": {"bytes": (inputs / "command.json").stat().st_size,
                              "sha256": sha(PAYLOAD / "CONTROL_COMMAND.json")}}:
        raise ValueError("read-only fixed control input was changed")
    verify_payload(PAYLOAD)
    write(args.evidence / "SCREEN_RESULT.json", {"schema": "t3-native-transaction-v2-control-host-result", "all_passed": True,
        "result": result, "actual_container": after, "actual_image_digest": image["Id"],
        "retained_parquets": [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p)} for p in files],
        "timing_executed": False, "official_gate": False, "rankable": False,
        "promotion_requires_full71_official_gates_then_committed_timing_repeats": True})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("run", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--artifact", type=Path)
    parser.add_argument("--docker", default="docker")
    args = parser.parse_args()
    if args.verb == "artifact":
        if args.artifact is None or args.artifact.exists():
            raise ValueError("fresh artifact directory required")
        args.artifact.mkdir(parents=True)
        if args.evidence.exists():
            shutil.copytree(args.evidence, args.artifact / "evidence", ignore=shutil.ignore_patterns("anonymous-docker-config"))
        shutil.copytree(PAYLOAD, args.artifact / "payload")
        return
    try:
        run(args)
    except BaseException as error:
        write(args.evidence / "FAILURE_v1.json", {"type": type(error).__name__, "message": str(error),
              "timing_executed": False, "rankable": False})
        raise


if __name__ == "__main__":
    main()
