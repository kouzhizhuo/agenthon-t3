"""Actual pinned image controls; build and all correctness precede any timing."""
import json
from pathlib import Path
import subprocess
import sys
import sysconfig

ROOT = Path("/opt/native-transaction-controls")
CANDIDATE = ROOT / "completion1009/candidates/native_canonical_transaction_v2"
RUNTIME = ROOT / "completion1009/candidates/lean_production_native_projection_v1/runtime"


def call(label, command, output, seconds):
    with (output / (label + ".log")).open("xb") as log:
        completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=seconds)
    if completed.returncode:
        raise RuntimeError("actual transaction control command failed: " + label)


def main():
    if sys.argv[1:] != ["controls"]:
        raise ValueError("fixed complete-controls entry required")
    if json.loads(Path("/input/command.json").read_text()) != {"command": "native-transaction-v2-all-controls-before-timing"}:
        raise ValueError("fixed reviewed control input required")
    output = Path("/output/controls")
    if output.exists():
        raise ValueError("fresh complete controls directory required")
    output.mkdir()
    report = {"schema": "t3-native-transaction-v2-control-container-result", "all_passed": False,
              "stages": [], "timing_executed": False, "rankable": False, "official_gate": False}
    try:
        common = ["--runtime", str(RUNTIME)]
        call("host-proof-before", [sys.executable, "-B", str(CANDIDATE / "host_proof.py"),
             "--mode", "verify", *common, "--out", str(output / "HOST_PROOF_BEFORE.json")], output, 120)
        before = json.loads((output / "HOST_PROOF_BEFORE.json").read_text())
        assert before["audit_all_passed"] is True
        report["stages"].append("actual_host_proof_before")
        extension = CANDIDATE / "native" / ("native_canonical_transaction" + sysconfig.get_config_var("EXT_SUFFIX"))
        probe = CANDIDATE / "native" / ("transaction_owner_probe" + sysconfig.get_config_var("EXT_SUFFIX"))
        call("scheduler-boundaries", [sys.executable, "-B", str(CANDIDATE / "scheduler_controls.py"),
             *common, "--extension", str(extension), "--out", str(output / "SCHEDULER_CONTROLS.json")], output, 600)
        scheduler = json.loads((output / "SCHEDULER_CONTROLS.json").read_text())
        assert scheduler["all_passed"] is True and len(scheduler["cases"]) == 41
        assert scheduler["scheduler_variant_count"] == 33 and scheduler["scheduler_arm_executions"] == 99
        integrations = [row for row in scheduler["cases"] if "integration_witnesses" in row]
        guards = [row for row in scheduler["cases"] if "guard_witnesses" in row]
        assert len(integrations) == 5 and len(guards) == 2
        assert sum(len(row["integration_witnesses"]) for row in integrations) == 5
        assert all(check.get("passed") is True and
                   (check.get("fresh_process") is True or
                    check.get("actual_extension_exec_completed_before_controlled_failure") is True)
                   for row in integrations for check in row["integration_witnesses"])
        assert sum(len(row["guard_witnesses"]) for row in guards) == 22
        assert all(check.get("accepted") is True or check.get("rejected") is True
                   for row in guards for check in row["guard_witnesses"])
        report["stages"].append("41_scheduler_boundaries_33variants_99arms")
        call("transaction-boundaries", [sys.executable, "-B", str(CANDIDATE / "boundary_controls.py"),
             *common, "--extension", str(extension), "--probe", str(probe),
             "--out", str(output / "TRANSACTION_CONTROLS.json")], output, 900)
        transaction = json.loads((output / "TRANSACTION_CONTROLS.json").read_text())
        assert transaction["all_passed"] is True and len(transaction["cases"]) == 28
        assert len(transaction["admission_children"]) == 8
        assert all(row["passed"] is True and row["fresh_process"] is True
                   for row in transaction["admission_children"])
        report["stages"].append("28_transaction_boundaries_8fresh_admission_children")
        call("complete-markets", [sys.executable, "-B", str(ROOT / "control/market_controls.py"),
             *common, "--candidate", str(CANDIDATE), "--out", str(output / "markets")], output, 1800)
        markets = json.loads((output / "markets/RESULT.json").read_text())
        assert markets["all_passed"] is True and len(markets["cases"]) == 4
        assert markets["market_records"] == 8 and markets["control_parquet_blobs"] == 16
        assert markets["nine_payload_components"] is True
        report["stages"].append("4_full_market_cases_2arms_16Parquets_9components")
        call("host-proof-after", [sys.executable, "-B", str(CANDIDATE / "host_proof.py"),
             "--mode", "verify", *common, "--out", str(output / "HOST_PROOF_AFTER.json")], output, 120)
        after = json.loads((output / "HOST_PROOF_AFTER.json").read_text())
        assert after["audit_all_passed"] is True and before == after
        report["stages"].append("actual_host_proof_after")
        report.update(all_passed=True, scheduler=scheduler, transaction=transaction,
                      markets=markets, host_proof_before=before, host_proof_after=after,
                      full_market_equality=True, boundary_case_count=69, fresh_admission_children=8,
                      guard_subchecks=22, scheduler_integration_children=5)
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "RESULT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
