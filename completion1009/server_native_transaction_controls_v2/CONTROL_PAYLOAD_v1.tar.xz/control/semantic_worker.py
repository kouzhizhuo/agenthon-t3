#!/usr/bin/env python3
"""Untimed, complete two-arm transaction worker with explicit representations."""
import argparse
import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import pickle
import sys
import types
import warnings

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--candidate", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--arm", choices=("original_canonical", "actual_native"), required=True)
args = parser.parse_args()
RUNTIME, CANDIDATE, OUTPUT = (Path(p).resolve() for p in (args.runtime, args.candidate, args.out))
sys.path.insert(0, str(CANDIDATE))
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
import numpy as np
import pandas as pd
from abides_core import abides
from abides_core.kernel import Kernel
from abides_core.message import Message
from abides_fork.config import build_config, ScenarioLatencyModel
from abides_fork.simulate import reset_abides_counters
from abides_fork import trace
from abides_markets.orders import Order
from abides_markets.agents import exchange_agent
from contracts import validate_frames, validate_scenario
import observer
from transaction_installation import enabled
import semantic_mapping as mapping
from semantic_mapping import encode, graph

if args.arm == "actual_native":
    from transaction_loader import load_transaction, native_receipt
    engine = load_transaction()
    from owner_probe_loader import load_owner_probe
    owner_probe = load_owner_probe(engine)
else:
    engine = importlib.import_module("original_canonical_engine")
    owner_probe = None
    if "native_canonical_transaction" in sys.modules or "transaction_owner_probe" in sys.modules:
        raise ValueError("Python control arm unexpectedly loaded native code")

def snapshot_witness(rows):
    # Extra consumer witness only. graph() retains the complete original
    # bids/asks payload and its aliases, without this projection.
    return [{key: (len(child) != 0 if key in ("bids", "asks") else child)
             for key, child in row.items()} for row in rows]

def witness_consumers(kernel):
    values = []
    for agent in kernel.agents:
        for symbol, book in getattr(agent, "order_books", {}).items():
            consumers = []
            for method in ("get_time_dropout", "_original_time_dropout"):
                probe = type(agent).__new__(type(agent))
                probe.metric_trackers = {symbol: agent.MetricTracker()}
                with warnings.catch_warnings(record=True) as observed:
                    warnings.simplefilter("always")
                    try:
                        getattr(probe, method)(book.book_log2, symbol)
                        result = ["metrics", encode(probe.metric_trackers)]
                    except Exception as error:
                        result = ["exception", type(error).__name__, str(error)]
                    warning_values = [(w.category.__name__, str(w.message)) for w in observed]
                consumers.append([method, result, warning_values])
            values.append([int(agent.id), symbol, encode(snapshot_witness(book.book_log2)),
                           encode(agent.metric_trackers[symbol]), consumers])
    return values

def rng_states(value, path="root", seen=None):
    seen = set() if seen is None else seen
    if isinstance(value, np.random.RandomState): return {path: encode(value.get_state())}
    if value is None or isinstance(value, (int, str, float, bool, np.ndarray, np.generic)): return {}
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)): return {}
    if id(value) in seen: return {}
    seen.add(id(value))
    if isinstance(value, dict): children = [(str(k), v) for k, v in value.items()]
    elif isinstance(value, (list, tuple)): children = [(str(i), v) for i, v in enumerate(value)]
    elif hasattr(value, "__dict__"): children = list(vars(value).items())
    else: return {}
    result = {}
    for key, child in children:
        result.update(rng_states(child, path + "/" + key, seen))
    return result

def scenario(seed, latency, protocol=False):
    result = {"scenario_id": "streaming-observer-controls-" + str(seed), "seed": seed,
        "horizon_ns": 2000000000,
        "exchange_config": {"symbol": "CTRL", "tick_size": 1, "lot_size": 1, "min_price": 1, "max_price": 1000000},
        "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100000, "kappa": .05,
            "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}},
        "agent_configs": [
            {"agent_type": "NoiseTrader", "count": 2, "params": {"arrival_rate_hz": 6., "order_size_mean": 10}},
            {"agent_type": "MarketMaker", "count": 1, "params": {"spread_ticks": 2, "depth_levels": 3,
                "size_per_level": 12, "rebalance_interval_ns": 300000000}},
            {"agent_type": "ValueTrader", "count": 1, "params": {"arrival_rate_hz": 4., "threshold_ticks": 2}},
            {"agent_type": "MomentumTrader", "count": 1, "params": {"arrival_rate_hz": 5., "threshold_ticks": 2}}]}
    if latency is not None: result["latency_config"] = latency
    if protocol: result["exchange_config"].update(protocol_enforcement=True, stp_policy="cancel_oldest", ack_delay_ns=400, compute_delay_ns=100)
    return result

def summary_aliases(kernel):
    # Extra explicit summary-row associations; full logs also enter graph().
    return [[int(entry["AgentID"]), entry["EventType"],
        [(event_type, int(timestamp)) for timestamp, event_type, payload in kernel.agents[entry["AgentID"]].log
         if event_type == entry["EventType"] and payload is entry["Event"]]] for entry in kernel.summary_log]

def retained_logs(kernel):
    # Shared graph preserves every private log and original summary alias.
    rows = [[agent.id, agent.log] for agent in kernel.agents]
    return graph([rows, kernel.summary_log])

def run(value):
    validate_scenario(value)
    reset_abides_counters()
    np.random.seed(19301009)
    original_summary = Kernel.write_summary_log
    original_kernel, original_latency = abides.Kernel, ScenarioLatencyModel.get_latency
    original_book = exchange_agent.OrderBook
    try:
        with enabled(value, args.arm) as installed:
            assert installed["native_active"] is (args.arm == "actual_native")
            assert installed["fallback_before_configuration"] is False
            assert installed["per_episode_source_hashes"] == 0
            assert installed["per_episode_original_source_compilations"] == 0
            admitted = observer.begin_episode(value, authenticated=installed["observer_authenticated"])
            assert admitted, "fixed control scenario declined the observer domain"
            installed_kernel = abides.Kernel
            config = build_config(value)
            Kernel.write_summary_log = lambda self: None
            state = abides.run(config)
            extractor = installed["extractor"]
        assert (abides.Kernel is original_kernel and ScenarioLatencyModel.get_latency is original_latency
                and exchange_agent.OrderBook is original_book)
        frames = [trace.extract_trace(state), extractor(state)]
        validate_frames(*frames)
        blobs = []
        parquet_folder = OUTPUT / str(value["seed"])
        parquet_folder.mkdir()
        for name, frame in zip(("trace.parquet", "message_trace.parquet"), frames):
            stream = io.BytesIO()
            frame.to_parquet(stream, compression="snappy", index=False)
            blobs.append(stream.getvalue())
            (parquet_folder / name).write_bytes(blobs[-1])
        kernel = state["agents"][0].kernel
        mapping.configure(engine, args.arm, owner_probe, installed_kernel)
        owner_witness = mapping.audit_kernel(kernel, state)
        fields = mapping.kernel_fields(kernel)
        end = {key: child for key, child in state.items()
               if key not in ("kernel_event_queue_elapsed_wallclock", "agents")}
        retained = graph([state["agents"], config, fields, end])
        rngs = {"numpy_global": encode(np.random.get_state()), **rng_states(config),
                "kernel": encode(kernel.random_state.get_state())}
        depth = [[int(agent.id), symbol, depth, encode(book.get_l2_bid_data(depth)), encode(book.get_l2_ask_data(depth)),
                  encode(book.get_l3_bid_data(depth)), encode(book.get_l3_ask_data(depth))]
                 for agent in state["agents"] for symbol, book in getattr(agent, "order_books", {}).items()
                 for depth in (0, 1, 10, -1)]
        counters = {key: child for key, child in vars(observer.STATE).items() if key not in ("inference", "contract")}
        details = {"private_log_rows": sum(len(agent.log) for agent in state["agents"]),
                   "summary_rows": len(kernel.summary_log), "observer": counters,
                   "ttl_messages": kernel.ttl_messages,
                   "book_rows": sum(len(book.book_log2) for agent in state["agents"] for book in getattr(agent, "order_books", {}).values())}
        receipt = native_receipt() if args.arm == "actual_native" else None
        if receipt is not None:
            assert receipt["native_load_count"] == 1
        witness = {"scheduler_arm": args.arm, "native_active": args.arm == "actual_native", "fallback_used": False,
                   "json_domain_admitted": admitted, "complete_trace_rows": len(frames[0]),
                   "message_rows": len(frames[1]), "native_receipt": receipt,
                   "installation_restored": True, "mapping": owner_witness,
                   "contract_frames_validated": True,
                   "per_episode_original_source_compilations": 0, "per_episode_source_hashes": 0,
                   "per_episode_native_hash_audit": False,
                   "control_probe_loaded": args.arm == "actual_native", "rankable": False}
        return {"seed": value["seed"], "frames": frames,
                "payload": [blobs, retained, rngs, [Order._order_id_counter, Message._Message__message_id_counter],
                            summary_aliases(kernel), depth, retained_logs(kernel),
                            [agent.kernel is kernel for agent in state["agents"]], witness_consumers(kernel)],
                "details": details, "scheduler_witness": witness}
    finally:
        Kernel.write_summary_log = original_summary
        observer.finish_episode()


def main():
    if OUTPUT.exists(): raise ValueError("semantic attempt already exists")
    OUTPUT.mkdir(parents=True)
    values = [run(scenario(seed, latency, protocol)) for seed, latency, protocol in (
        (81009, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}, False),
        (82009, {"model": "deterministic", "params": {"mean_ns": 0}}, False),
        (83009, {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}, True),
        (84009, None, False))]
    data = pickle.dumps(values, protocol=4)
    (OUTPUT / "SEMANTIC_VALUES.pkl").write_bytes(data)
    receipt = {"schema": "t3-native-transaction-v2-semantic-worker", "arm": args.arm,
               "timing_claim": False, "rankable": False, "json_domain_admitted_all": True,
               "values_sha256": hashlib.sha256(data).hexdigest(), "source_mapping_spec_sha256":
                   hashlib.sha256(Path(__file__).with_name("SOURCE_MAPPING_SPEC.json").read_bytes()).hexdigest(),
               "cases": [{"seed": row["seed"], "trace_rows": len(row["frames"][0]),
                          "message_rows": len(row["frames"][1]), "details": row["details"],
                          "scheduler_witness": row["scheduler_witness"]} for row in values]}
    (OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__": main()
