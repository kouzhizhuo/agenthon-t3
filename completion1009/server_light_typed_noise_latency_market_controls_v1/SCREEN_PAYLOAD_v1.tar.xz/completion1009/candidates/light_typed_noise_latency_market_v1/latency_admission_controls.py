"""Future genuine cold latency selection/no-draw/migration-rollback controls."""
import argparse
import json
from pathlib import Path
from cleanup_errors import attach, detail

HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh genuine latency admission evidence required")
    from production_cli import activate_paths
    activate_paths(args.runtime)
    from native_loader import load
    native = load(args.build, args.runtime)["dynamic_arena_chain"]
    import numpy as np
    from latency_admission import acquire_initialized
    from latency_control_fixture import fixture, cleanup
    from noise_admission import acquire_initialized as acquire_noise
    from noise_expression_controls import pin, state, observed
    from control_graph import graph
    from state_mapper import control_migrate_failure
    def roots(values):
        kernel = values["kernel"]
        from abides_core.message import Message
        from abides_markets.orders import Order
        import observer
        return {"agents": kernel.agents, "oracle": kernel.oracle, "latency": values["model"],
            "kernel_rng": kernel.random_state, "global_state": np.random.get_state(),
            "queue": kernel.messages.queue, "ledger": kernel._msg_ledger, "observer": observer.STATE,
            "current_time": kernel.current_time, "agent_current_times": kernel.agent_current_times,
            "agent_delays": kernel.agent_computation_delays, "ttl": kernel.ttl_messages,
            "deliver_seq": kernel._deliver_seq, "deliver_seq_by_key": kernel._deliver_seq_by_key,
            "causal": kernel._current_causal_uid, "message_counter": Message._Message__message_id_counter,
            "order_counter": Order._order_id_counter}
    modes = ("unique-no-draw", "shared-Noise", "shared-other-actor", "shared-kernel", "shared-global",
             "shared-oracle", "default-model", "absent-model", "foreign-model", "unsupported-fields",
             "foreign-clip", "foreign-log", "foreign-zeros", "foreign-get-latency",
             "migration-preflight-actors", "migration-preflight-scheduler", "migration-roster",
             "migration-model-retirement", "migration-actor-binding")
    result = {"schema": "t3-light-typed-noise-latency-genuine-cold-admission-controls-v1", "all_passed": False,
        "cases": [], "build_receipt": pin(args.build / "BUILD_RECEIPT.json"),
        "source_receipt": pin(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"),
        "rankable": False, "speed_claim": False, "market_runner_executed": False,
        "arbitrary_external_alias_contract": False}
    try:
        for mode in modes:
            values = fixture(native, np, False)
            kernel, model, rng = (values[name] for name in ("kernel", "model", "rng"))
            acquisition = noise = None
            restore = None
            active_error = None
            foreign_calls = [0]
            def foreign(*args, **kwargs):
                foreign_calls[0] += 1
                raise RuntimeError("foreign numeric/source body must not run")
            try:
                if mode.startswith("shared-"):
                    if mode == "shared-Noise":
                        from abides_fork.agents import NoiseTrader
                        target = next(actor for actor in kernel.agents if type(actor) is NoiseTrader).random_state
                    elif mode == "shared-other-actor": target = kernel.agents[0].random_state
                    elif mode == "shared-kernel": target = kernel.random_state
                    elif mode == "shared-global": target = np.random.mtrand._rand
                    else: target = next(iter(kernel.oracle.symbols.values()))["random_state"]
                    model.random_state = target
                    values["rng"] = target
                elif mode in ("default-model", "absent-model", "foreign-model"):
                    if mode == "default-model":
                        from abides_core.latency_model import LatencyModel
                        model = LatencyModel(rng, np.zeros((len(kernel.agents), len(kernel.agents))), "deterministic")
                    elif mode == "absent-model": model = None
                    else:
                        class ForeignLatency:
                            pass
                        model = ForeignLatency()
                    kernel.agent_latency_model = model
                    values["model"] = model
                elif mode == "unsupported-fields": model._min_ns = np.float64(0.0)
                elif mode.startswith("foreign-"):
                    if mode == "foreign-get-latency":
                        from abides_fork.config import ScenarioLatencyModel
                        restore = (ScenarioLatencyModel, "get_latency", ScenarioLatencyModel.get_latency)
                    else:
                        name = mode.split("-", 1)[1]
                        restore = (np, name, getattr(np, name))
                import observer
                retained = {"roster": kernel.agents, "actors": tuple(kernel.agents),
                    "actor_dicts": tuple(actor.__dict__ for actor in kernel.agents),
                    "books": tuple(kernel.agents[0].order_books.values()),
                    "book_dicts": tuple(book.__dict__ for book in kernel.agents[0].order_books.values()),
                    "queue": kernel.messages, "queue_storage": kernel.messages.queue, "ledger": kernel._msg_ledger,
                    "latency_dict": None if model is None else object.__getattribute__(model, "__dict__"),
                    "episode": observer.STATE, "inference": observer.STATE.inference, "contract": observer.STATE.contract}
                before = graph(roots(values), np)
                before_state = state(values["rng"].get_state())
                if restore is not None:
                    setattr(restore[0], restore[1], foreign)
                if mode.startswith("migration-"):
                    phase = modes.index(mode) - modes.index("migration-preflight-actors") + 1
                    outcome = observed(lambda: control_migrate_failure(kernel, native, phase))
                    expected_message = ("finite migration preflight failure after actor owners",
                        "finite migration preflight failure after scheduler", "finite migration commit failure after roster",
                        "finite migration commit failure after latency retirement", "finite migration commit failure after actor binding")[phase - 1]
                    require(outcome["returned"] is False and outcome["type"] == "builtins.RuntimeError"
                        and outcome["message"] == expected_message and outcome["warnings"] == [],
                        "actual migration injected phase was not reached exactly")
                    after = graph(roots(values), np)
                    require(after == before and kernel.__dict__["agent_latency_model"] is values["model"],
                            "actual migration rollback changed original graph or latency slot")
                    require(not any(name in kernel.__dict__ for name in ("_chain_scheduler", "_chain_migration", "_noise_boundary", "_chain_episode_boundary", "_latency_acquisition")),
                            "failed migration retained private authority fields")
                    identity_checks = {"roster": kernel.agents is retained["roster"],
                        "actors": len(kernel.agents) == len(retained["actors"]) and all(a is b for a, b in zip(kernel.agents, retained["actors"])),
                        "actor_dicts": all(actor.__dict__ is raw for actor, raw in zip(retained["actors"], retained["actor_dicts"])),
                        "books": all(book.__dict__ is raw for book, raw in zip(retained["books"], retained["book_dicts"])),
                        "queue": kernel.messages is retained["queue"] and kernel.messages.queue is retained["queue_storage"],
                        "ledger": kernel._msg_ledger is retained["ledger"],
                        "latency_dict": object.__getattribute__(model, "__dict__") is retained["latency_dict"],
                        "episode": observer.STATE is retained["episode"] and observer.STATE.inference is retained["inference"]
                            and observer.STATE.contract is retained["contract"]}
                    require(all(identity_checks.values()), "actual migration rollback lost original dictionary/roster/queue/observer identities")
                    selection = None
                else:
                    identity_checks = None
                    def acquire():
                        nonlocal acquisition
                        acquisition = acquire_initialized(kernel, native, args.runtime, model)
                        return acquisition.owner is not None
                    outcome = observed(acquire)
                    if restore is not None:
                        # Public get_state may allocate np.zeros. Capture the
                        # refusal while patched, then restore before raw state
                        # observation so the foreign body is never invoked.
                        setattr(restore[0], restore[1], restore[2])
                        restore = None
                    after = graph(roots(values), np)
                    require(before == after, "cold latency acquisition changed original raw graph")
                    if mode == "unique-no-draw":
                        require(outcome["returned"] and outcome["result"]["value"] is True,
                                "genuine unique configured latency owner was not selected")
                        require(state(acquisition.owner.control_private_state()) == before_state,
                                "no-draw latency acquisition changed full624 state")
                    elif mode in ("foreign-clip", "foreign-log", "foreign-zeros", "foreign-get-latency"):
                        require(outcome["returned"] is False and foreign_calls[0] == 0,
                                "foreign source/numeric replacement was invoked or accepted")
                    else:
                        require(acquisition is not None and acquisition.owner is None,
                                "shared/default/foreign/unsupported model must decline whole latency ownership")
                        if mode == "shared-Noise":
                            noise = acquire_noise(kernel, native, args.runtime)
                            require(not any(entry[2] is values["rng"] for entry in noise.entries),
                                    "shared latency/Noise stream acquired two owners")
                    selection = None if acquisition is None else {"declined_reason": acquisition.declined_reason,
                        "owner_selected": acquisition.owner is not None}
                result["cases"].append({"case": mode, "before_graph": before, "after_graph": after,
                    "before_actual_state": before_state, "after_actual_state": state(values["rng"].get_state()),
                    "outcome": outcome, "selection": selection, "rollback_identity_checks": identity_checks, "foreign_body_calls": foreign_calls[0], "passed": True})
            except BaseException as error:
                active_error = error
                raise
            finally:
                failures = []
                if restore is not None:
                    try: setattr(restore[0], restore[1], restore[2])
                    except BaseException as error: failures.append(detail(error))
                for owner in (() if acquisition is None or acquisition.owner is None else (acquisition.owner,)):
                    try: owner.export_to_original()
                    except BaseException as error: failures.append(detail(error))
                if noise is not None:
                    try: noise.export_all()
                    except BaseException as error: failures.append(detail(error))
                try: cleanup(values, active_error)
                except BaseException as error: failures.append(detail(error))
                if failures:
                    if active_error is not None: attach(active_error, "finite_admission_cleanup_failures", failures)
                    else: raise RuntimeError("finite admission cleanup incomplete")
        result["all_passed"] = True
    except BaseException as error:
        result["failure"] = detail(error)
        raise
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+"\n")
    require(result["all_passed"], "actual latency admission controls failed")


if __name__ == "__main__": main()
