"""Explicit read-only representation mapping for untimed scheduler controls.

Only the declared Kernel/heap/ledger representation is mapped. Every other
business attribute remains in the graph. The separate actual Cython probe
must establish the native private owner/list aliases before mapping is used.
"""
import _thread
from collections import deque
from datetime import datetime, timedelta
import types

import numpy as np
import pandas as pd
from abides_core.kernel import Kernel
from abides_markets.orders import Side

_engine = None
_arm = None
_owner_probe = None
_audited = {}


def configure(engine, arm, owner_probe=None):
    global _engine, _arm, _owner_probe
    if arm not in ("original_canonical", "matching_python", "actual_native"):
        raise ValueError("unknown mapping arm")
    if (arm == "actual_native") != (owner_probe is not None):
        raise ValueError("native mapping requires the actual control probe")
    _engine, _arm, _owner_probe = engine, arm, owner_probe
    _audited.clear()


def audit_kernel(kernel, end_state):
    if _engine is None or type(kernel) is not _engine.CanonicalKernel:
        raise ValueError("mapping kernel has the wrong concrete owner")
    heap, ledger = kernel.messages, kernel._msg_ledger
    if type(heap) is not _engine.FlatHeap or type(ledger) is not _engine.ColumnLedger:
        raise ValueError("mapping heap/ledger owner differs")
    if set(vars(heap)) != {"queue"} or type(heap.queue) is not list:
        raise ValueError("mapping heap has undeclared attributes")
    columns = ledger.columns
    if type(columns) is not tuple or len(columns) != 9 or not all(type(v) is list for v in columns):
        raise ValueError("mapping ledger requires the original nine lists")
    if len({id(v) for v in columns}) != 9 or ledger.columns is not columns:
        raise ValueError("ledger column identities differ")
    if not all(len(v) == len(columns[0]) for v in columns) or len(ledger) != len(columns[0]):
        raise ValueError("ledger column lengths differ")
    native_private = None
    if _arm == "original_canonical":
        if set(vars(ledger)) != {"columns"} or "_canonical_scheduler" in vars(kernel):
            raise ValueError("original representation has unexpected fields")
    elif _arm == "matching_python":
        if set(vars(ledger)) != {"columns", *("c" + str(i) for i in range(9))}:
            raise ValueError("matching ledger has undeclared fields")
        if any(getattr(ledger, "c" + str(i)) is not columns[i] for i in range(9)):
            raise ValueError("matching private column aliases differ")
        scheduler = kernel._canonical_scheduler
        if type(scheduler) is not _engine.CanonicalScheduler or set(vars(scheduler)) != {"kernel"} or scheduler.kernel is not kernel:
            raise ValueError("matching scheduler owner/fields differ")
    else:
        if set(vars(ledger)) != {"columns"}:
            raise ValueError("native ledger dynamic fields differ")
        scheduler = kernel._canonical_scheduler
        if type(scheduler) is not _engine.CanonicalScheduler:
            raise ValueError("native scheduler concrete owner differs")
        native_private = _owner_probe.audit_owner(kernel)
        # The loader/source receipt binds the actual probe and its assertions;
        # any private alias failure raises before the mapping is permitted.
        if type(native_private) is not dict or not native_private:
            raise ValueError("actual native private-owner witness is missing")
        if (native_private.get("column_list_aliases") != [True] * 9
                or native_private.get("columns_tuple_shape") != 9
                or not all(native_private.get(key) is True for key in
                    ("native_ledger_owner_checked", "column_lists_distinct", "control_only",
                     "native_scheduler_owner_checked", "scheduler_kernel_identity"))
                or native_private.get("mutation_performed") is not False):
            raise ValueError("native private-owner assertions did not pass")
    if end_state["agents"] is not kernel.agents or end_state["message_ledger"] is not ledger or end_state["deliver_seq_by_key"] is not kernel._deliver_seq_by_key:
        raise ValueError("end-state kernel/ledger/map aliases differ")
    if not all(agent.kernel is kernel for agent in kernel.agents):
        raise ValueError("agent kernel aliases differ")
    _audited[id(kernel)] = kernel
    _audited[id(ledger)] = ledger
    _audited[id(heap)] = heap
    return {"mapping_version": "t3-scheduler-representation-v1", "arm": _arm,
            "exact_kernel_heap_ledger_types": True, "heap_queue_original_list": True,
            "columns_tuple_retained": True, "nine_distinct_exact_list_aliases": True,
            "ledger_rows": len(ledger), "end_state_aliases": [True, True, True],
            "all_agent_kernel_aliases": True,
            "scheduler_owner_verified": _arm != "original_canonical",
            "original_has_no_scheduler": _arm == "original_canonical",
            "native_private_witness": native_private}


def kernel_fields(kernel):
    if _audited.get(id(kernel)) is not kernel:
        raise ValueError("kernel mapping was not audited")
    omitted = {"kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir", "agents", "gym_agents", "custom_state"}
    if _arm != "original_canonical":
        omitted.add("_canonical_scheduler")
    return {key: value for key, value in vars(kernel).items() if key not in omitted}


def encode(value):
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is bytes: return ["bytes", value.hex()]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, pd.Timestamp): return ["Timestamp", value.isoformat()]
    if type(value) is datetime: return ["datetime", value.isoformat()]
    if type(value) is timedelta: return ["timedelta", value.days, value.seconds, value.microseconds]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.ndarray): return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if isinstance(value, dict): return ["dict", [(encode(k), encode(v)) for k, v in value.items()]]
    if type(value) in (list, tuple, deque): return [type(value).__name__, [encode(v) for v in value]]
    if type(value) is Side: return ["Side", value.value]
    if hasattr(value, "__dict__"): return [type(value).__module__, type(value).__name__, encode(vars(value))]
    raise TypeError("unsupported semantic scalar value: " + type(value).__name__)


def graph(value, seen=None, kernel_telemetry=False):
    seen = {} if seen is None else seen
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is bytes: return ["bytes", value.hex()]
    if type(value) is float: return ["float", value.hex()]
    if type(value) is datetime: return ["datetime", value.isoformat()]
    if type(value) is timedelta: return ["timedelta", value.days, value.seconds, value.microseconds]
    if isinstance(value, np.generic): return [type(value).__name__, graph(value.item(), seen)]
    if type(value) is Side: return ["Side", value.value]
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType,
                          types.BuiltinFunctionType, types.BuiltinMethodType, type)):
        for name in ("CanonicalKernel", "FlatHeap", "ColumnLedger"):
            if value is getattr(_engine, name): return ["binding", "t3_scheduler_mapping", name]
        return ["binding", getattr(value, "__module__", ""), getattr(value, "__qualname__", getattr(value, "__name__", ""))]
    if type(value) is _thread.LockType: return ["thread_lock", value.locked()]
    if id(value) in seen: return ["ref", seen[id(value)][0]]
    serial = len(seen)
    seen[id(value)] = (serial, value)
    if isinstance(value, np.random.RandomState): return ["RandomState", serial, encode(value.get_state())]
    if isinstance(value, np.ndarray): return ["ndarray", serial, str(value.dtype), list(value.shape),
        graph(value.tolist(), seen) if value.dtype.hasobject else value.tobytes().hex()]
    if isinstance(value, dict):
        return ["dict", serial, [(graph(k, seen), graph(v, seen)) for k, v in value.items()
            if not (kernel_telemetry and type(k) is str and k == "kernel_event_queue_elapsed_wallclock")]]
    if type(value) in (list, tuple, deque): return [type(value).__name__, serial, [graph(v, seen) for v in value]]
    if type(value) in (set, frozenset): return [type(value).__name__, serial, sorted([encode(v) for v in value], key=repr)]
    if isinstance(value, (pd.DataFrame, pd.Series)): return [type(value).__name__, serial, str(value.dtypes), encode(value.to_dict())]
    if isinstance(value, pd.Timestamp): return ["Timestamp", serial, value.isoformat()]
    if _engine is None:
        raise ValueError("unconfigured representation mapping")
    if type(value) in (_engine.CanonicalKernel, _engine.FlatHeap, _engine.ColumnLedger):
        if _audited.get(id(value)) is not value:
            raise ValueError("undeclared unaudited native representation")
        if type(value) is _engine.ColumnLedger:
            return ["t3_scheduler_mapping", "ColumnLedger", serial, [("columns", graph(value.columns, seen))]]
        if type(value) is _engine.FlatHeap:
            return ["t3_scheduler_mapping", "FlatHeap", serial, [("queue", graph(value.queue, seen))]]
        attrs = [(key, child) for key, child in vars(value).items()
                 if key not in ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir", "_canonical_scheduler")]
        return ["t3_scheduler_mapping", "CanonicalKernel", serial,
                [(key, graph(child, seen, key == "custom_state")) for key, child in attrs]]
    if hasattr(value, "__dict__"):
        attrs = [(key, child) for key, child in vars(value).items()
                 if not (isinstance(value, Kernel) and key in ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir"))]
        return [type(value).__module__, type(value).__name__, serial,
                [(key, graph(child, seen, isinstance(value, Kernel) and key == "custom_state")) for key, child in attrs]]
    raise TypeError("unsupported business graph value: " + type(value).__name__)
