"""Source-bound three-arm Linux scheduler screen; no official score or ranking claim."""
import argparse
import ast
import calendar
from datetime import datetime
import math
import statistics
import struct
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import sys
import uuid
from common import (BASE, BATCH, CANDIDATE, RUNTIME_OWNER, ARMS, IMAGE_CANDIDATE, IMAGE_RUNTIME,
                    MARKER, SINGLES, TIMING_SCOPE, RUNTIME_PINS_SHA256, arm_order,
                    BUILD_SCHEMA, DEPLOYMENT_SCHEMA, ENTRY_SCHEMA, SCREEN_SCHEMA,
                    SOURCE_RECEIPT_SHA256, CONTROL_SOURCE_RECEIPT_SHA256,
                    MARKET_SEEDS, inventory, safe_name, sha, verify_payload, write)

PAYLOAD = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public


class StrictCommands(linux.DockerCommands):
    """Add finite process/file ulimits while keeping original launch checks."""
    def call(self, arguments, label, seconds=30, cleanup=False):
        if arguments and arguments[0] == "create":
            arguments = [arguments[0], "--ulimit", "nproc=256:256", "--ulimit",
                         "fsize=268435456:268435456", *arguments[1:]]
        return super().call(arguments, label, seconds, cleanup)

    def inspect(self, name, cleanup=False, seconds=30):
        info, command = super().inspect(name, cleanup, seconds)
        if info is not None and not cleanup and '--mode' in info.get('Config', {}).get('Cmd', []) and info.get('Config', {}).get('Entrypoint') != ['/usr/local/bin/python', '-B', '/opt/scheduler-screen/entry.py']:
            raise ValueError('actual screen entrypoint differs')
        if info is not None and not cleanup and info.get("Config", {}).get("Entrypoint") == ["/usr/local/bin/python", "-B", "/opt/scheduler-screen/entry.py"]:
            host = info["HostConfig"]
            limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
            expected = {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
            if any(limits.get(name) != value for name, value in expected.items()):
                raise ValueError("actual complete proof ulimits differ")
            mounts = info.get("Mounts", [])
            binds = [row for row in mounts if row.get("Destination") != "/tmp"]
            if (len(binds) != 2 or {row.get("Destination") for row in binds} != {"/input", "/output"}
                    or any(row.get("Type") != "bind" for row in binds)
                    or any(row.get("Type") != "tmpfs" for row in mounts if row.get("Destination") == "/tmp")):
                raise ValueError("proof mounts differ from input/output-only contract")
        return info, command


linux.DockerCommands = StrictCommands


def execute(args, command, prefix, seconds):
    row = linux.run_command(command, prefix, seconds, args.log_cap_bytes)
    write(prefix.with_name(prefix.name + ".json"), row)
    if not row["succeeded"]:
        raise RuntimeError("failed bounded command; diagnostics: " + str(prefix))
    return row


def image(args, requested, folder):
    folder.mkdir(parents=True)
    return linux.image_metadata(args, requested, folder)


def validate_build(plan, copied, runtime, controls):
    source = PAYLOAD / CANDIDATE
    source_receipt = "SOURCE_PREPARATION_RECEIPT_v3.json"
    if (sha(source / source_receipt) != plan["source_receipt_sha256"]
            or sha(copied / source_receipt) != plan["source_receipt_sha256"]):
        raise ValueError("actual installed scheduler freeze receipt differs")
    frozen = public.read_json(source / source_receipt)
    if (frozen.get("schema") != "t3-native-canonical-scheduler-ledger-source-preparation-v3"
            or frozen.get("source_file_count") != 20 or len(frozen.get("files", [])) != 20
            or frozen.get("files") != plan["source_files"]):
        raise ValueError("exact20 installed source files and preparation schema required")
    expected_sources = {row["path"]: row["sha256"] for row in plan["source_files"]}
    for row in plan["source_files"]:
        path = copied / safe_name(row["path"])
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("actual installed scheduler frozen source differs")
    pins = public.read_json(source / "RUNTIME_PINS.json")
    runtime_expected = {row["path"]: {k: row[k] for k in ("bytes", "sha256")} for row in pins["files"]}
    if (len(runtime_expected) != 64 or inventory(runtime) != runtime_expected
            or sha(copied / "RUNTIME_PINS.json") != plan["runtime_pins_sha256"]):
        raise ValueError("actual scheduler runtime bytes differ")
    for row in plan["image_control_files"]:
        path = controls / safe_name(row["path"])
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("actual complete root control source differs")
    spec = public.read_json(source / "compile_spec.json")
    build = copied / "artifacts/build_v3"
    receipt = public.read_json(build / "BUILD_RECEIPT.json")
    if (receipt.get("schema") != BUILD_SCHEMA or receipt.get("build_succeeded") is not True
            or receipt.get("candidate") != Path(CANDIDATE).name or receipt.get("candidate_sources") != expected_sources
            or receipt.get("source_receipt_sha256") != plan["source_receipt_sha256"]
            or receipt.get("compile_spec_sha256") != sha(source / "compile_spec.json")
            or receipt.get("runtime") != {"files": 64, "runtime_pins_sha256": plan["runtime_pins_sha256"]}
            or receipt.get("dependencies") != spec["dependencies"] or receipt.get("cython") != "3.1.3"
            or receipt.get("compile_flags") != spec["compile_flags"] or receipt.get("directives") != spec["directives"]
            or receipt.get("compiler_configuration") != {"CC": "gcc", "CCSHARED": "-fPIC",
                "CFLAGS": "-Wsign-compare -DNDEBUG -g -fwrapv -O3 -Wall", "CXX": "g++", "LDSHARED": "gcc -shared"}
            or receipt.get("build_invocations") != 1 or receipt.get("extension_build_count") != 2
            or receipt.get("production_extension_owners") != 1 or receipt.get("control_probe_extensions") != 1
            or receipt.get("pyx_sha256") != sha(source / "native_canonical_schedule.pyx")
            or receipt.get("pxd_sha256") != sha(source / "native_canonical_schedule.pxd")
            or receipt.get("control_probe_source_sha256") != sha(source / "scheduler_owner_probe.pyx")
            or receipt.get("ambient_flags") != {"CFLAGS": "", "CPPFLAGS": "", "LDFLAGS": ""}
            or receipt.get("candidate_imported") is not False or receipt.get("market_executed") is not False
            or receipt.get("timing_claim") is not False):
        raise ValueError("actual scheduler build receipt/source proof differs")
    abi = receipt["abi"]
    if (abi.get("implementation") != "cpython" or abi.get("version") != [3, 11, 17]
            or abi.get("platform") != "linux" or abi.get("machine") != "x86_64"
            or abi.get("pointer_bits") != 64 or abi.get("byteorder") != "little"
            or abi.get("cache_tag") != "cpython-311" or "cpython-311" not in abi.get("soabi", "")
            or "x86_64" not in abi.get("ext_suffix", "") or not abi.get("ext_suffix", "").endswith(".so")):
        raise ValueError("actual scheduler ABI differs from pinned Linux CPython")
    extensions = {}
    for key, module in (("extension", "native_canonical_schedule"), ("control_probe", "scheduler_owner_probe")):
        record = receipt[key]
        path = build / safe_name(record["path"])
        data = path.read_bytes()
        if (record["path"] != "native/" + module + abi["ext_suffix"]
                or path.stat().st_size != record["bytes"] or sha(path) != record["sha256"]
                or data[:7] != b"\x7fELF\x02\x01\x01" or struct.unpack_from("<HH", data, 16) != (3, 62)
                or path.name != module + abi["ext_suffix"] or ("PyInit_" + module).encode() not in data
                or (key == "control_probe" and record.get("control_only") is not True)):
            raise ValueError("actual scheduler/probe ELF differs")
        extensions[key] = record
    generated = receipt.get("generated_c", {})
    if (len(generated) != 2 or any(sha(build / safe_name(name)) != digest
            or "Generated by Cython 3.1.3" not in (build / safe_name(name)).read_text()
            for name, digest in generated.items())):
        raise ValueError("actual generated C bytes differ")
    text = "\n".join((build / safe_name(name)).read_text() for name in generated)
    if any("PyInit_" + name not in text for name in ("native_canonical_schedule", "scheduler_owner_probe")):
        raise ValueError("both generated module entrypoints required")
    deployment = public.read_json(copied / "DEPLOYMENT.json")
    if (deployment.get("schema") != DEPLOYMENT_SCHEMA or deployment.get("candidate") != Path(CANDIDATE).name
            or deployment.get("abi") != abi or deployment.get("build_receipt_sha256") != sha(build / "BUILD_RECEIPT.json")
            or deployment.get("source_receipt_sha256") != plan["source_receipt_sha256"]
            or deployment.get("runtime_pins_sha256") != plan["runtime_pins_sha256"]
            or deployment.get("compile_spec_sha256") != sha(source / "compile_spec.json")
            or deployment.get("extension_build_count") != 2 or deployment.get("build_invocations") != 1
            or deployment.get("production_extension_owners") != 1 or deployment.get("control_probe_extensions") != 1
            or deployment.get("candidate_imported") is not False or deployment.get("market_executed") is not False
            or deployment.get("timing_claim") is not False
            or deployment.get("pyx_sha256") != receipt["pyx_sha256"]
            or deployment.get("pxd_sha256") != receipt["pxd_sha256"]
            or deployment.get("control_probe_source_sha256") != receipt["control_probe_source_sha256"]):
        raise ValueError("actual scheduler deployment binding differs")
    for key, record in extensions.items():
        deployed = ({"path": deployment["extension_path"], "bytes": deployment["extension_bytes"],
                     "sha256": deployment["extension_sha256"]} if key == "extension" else deployment["control_probe"])
        path = copied / safe_name(deployed["path"])
        if (deployed["path"] != record["path"]
                or deployed["sha256"] != record["sha256"] or deployed["bytes"] != record["bytes"]
                or path.stat().st_size != record["bytes"] or sha(path) != record["sha256"]
                or (key == "control_probe" and deployed.get("control_only") is not True)):
            raise ValueError("deployed scheduler/probe bytes differ")
    proof = {"passed": True, "candidate": CANDIDATE, "candidate_sources": expected_sources,
        "extension": {"path": deployment["extension_path"], "bytes": deployment["extension_bytes"],
                      "sha256": deployment["extension_sha256"]}, "control_probe": deployment["control_probe"],
        "build_receipt_sha256": sha(build / "BUILD_RECEIPT.json"), "deployment": deployment,
        "deployment_sha256": sha(copied / "DEPLOYMENT.json"), "abi": abi, "generated_c": generated,
        "rankable": False, "timing_claim": False}
    write(copied / "BUILD_PROVENANCE.json", proof)
    return proof

def build(args, plan):
    evidence = args.evidence
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("real Linux amd64 host required")
    anonymous = evidence / "anonymous-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        execute(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], evidence / "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    write(evidence / "BASE.json", image(args, BASE, evidence / "base"))
    context = evidence / "build-context"
    context.mkdir()
    shutil.copytree(PAYLOAD / "completion1009", context / "completion1009")
    (context / "control").mkdir()
    for row in plan["image_control_files"]:
        shutil.copyfile(PAYLOAD / "control" / row["path"], context / "control" / row["path"])
    shutil.copyfile(PAYLOAD / "control/Dockerfile", context / "Dockerfile")
    iid = evidence / "native.image-id"
    execute(args, [args.docker, "build", "--platform", "linux/amd64", "--iidfile", str(iid),
        "-t", "t3-native-canonical-scheduler-screen:v3", "-f", str(context / "Dockerfile"), str(context)], evidence / "native-build", 1200)
    metadata = image(args, iid.read_text().strip(), evidence / "image")
    config = metadata["inspection"]["Config"]
    image_env = dict(value.split("=", 1) for value in config.get("Env", []))
    if (config.get("Entrypoint") != ["/usr/local/bin/python", "-B", "/opt/scheduler-screen/entry.py"]
            or config.get("User") != "65534:65534" or config.get("WorkingDir") != "/output"
            or image_env.get("T3_SCHEDULER_RUNTIME") != IMAGE_RUNTIME
            or image_env.get("T3_SCHEDULER_CANDIDATE") != IMAGE_CANDIDATE):
        raise ValueError("actual participant image entry/nonroot/working-directory/runtime pins differ")
    write(evidence / "IMAGE.json", metadata)
    token = uuid.uuid4().hex
    name = "t3-native-receipt-" + token[:12]
    commands = StrictCommands(args.docker, evidence / "receipt-commands", args.log_cap_bytes)
    commands.folder.mkdir(parents=True)
    created = commands.call(["create", "--name", name, "--label", linux.OWNER_LABEL + "=" + token,
        "--pull", "never", "--entrypoint", "/usr/local/bin/python", metadata["id"], "--help"], "create")
    try:
        if not created["succeeded"]:
            raise RuntimeError("never-started receipt container creation failed")
        info, _ = commands.inspect(name)
        linux.require_owned(info, name, token, metadata["id"])
        target = evidence / "actual-candidates"
        target.mkdir()
        copied_paths = {}
        for label, prefix in (("candidate", CANDIDATE), ("runtime", RUNTIME_OWNER)):
            destination = target / label
            copied = commands.call(["cp", name + ":/opt/scheduler-screen/" + prefix, str(destination)],
                "copy-" + label, 120)
            if not copied["succeeded"]:
                raise ValueError("actual image source/runtime/native bytes unavailable")
            copied_paths[label] = destination
        controls = target / "root-control"
        controls.mkdir()
        for row in plan["image_control_files"]:
            destination = controls / row["path"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            copied = commands.call(["cp", name + ":/opt/scheduler-screen/" + row["path"], str(destination)],
                "copy-control-" + Path(row["path"]).stem, 120)
            if not copied["succeeded"]:
                raise ValueError("actual root control source unavailable")
        validate_build(plan, copied_paths["candidate"], copied_paths["runtime"], controls)
    finally:
        settled = linux.settle_container(commands, name, token, metadata["id"], creation_uncertain=not created["succeeded"])
        write(evidence / "RECEIPT_CLEANUP.json", {"cleanup": settled, "commands": commands.rows})
        if not settled["settled"] or not settled["final_absent"] or settled["errors"]:
            raise RuntimeError("owned receipt container not settled")
    write(evidence / "BUILD_READY.json", {"passed": True, "image_id": metadata["id"],
        "build_count": 1, "rankable": False, "timing_claim": False})


def duration_ns(state):
    def parse(value):
        base, fraction = value.rstrip('Z').split('.', 1)
        return calendar.timegm(datetime.strptime(base, '%Y-%m-%dT%H:%M:%S').timetuple()) * 10**9 + int(fraction.ljust(9, '0'))
    return (parse(state['FinishedAt']) - parse(state['StartedAt'])) / 10**9


def expected_native_receipt(provenance):
    return {"extension_path": IMAGE_CANDIDATE + "/" + provenance["extension"]["path"],
        "extension_sha256": provenance["extension"]["sha256"],
        "build_receipt_sha256": provenance["build_receipt_sha256"],
        "source_receipt_sha256": provenance["deployment"]["source_receipt_sha256"],
        "runtime_pins_sha256": provenance["deployment"]["runtime_pins_sha256"],
        "abi": provenance["abi"], "native_load_count": 1,
        "runtime_provenance": "external_build_and_host_receipt",
        "runtime_source_compilation": False, "per_episode_native_hash_audit": False}


def require_episode_witness(episode, arm, provenance, semantic=False):
    if (episode.get("scheduler_arm") != arm or episode.get("native_active") is not (arm == "actual_native")
            or episode.get("fallback_used") is not False or type(episode.get("json_domain_admitted")) is not bool
            or semantic and episode["json_domain_admitted"] is not True
            or type(episode.get("complete_trace_rows")) is not int or episode["complete_trace_rows"] <= 0
            or type(episode.get("message_rows")) is not int or episode["message_rows"] <= 0
            or episode.get("installation_restored") is not True
            or episode.get("control_probe_loaded") is not (semantic and arm == "actual_native")
            or episode.get("rankable") is not False
            or episode.get("runtime_source_compilation") is not False
            or episode.get("per_episode_native_hash_audit") is not False):
        raise ValueError("actual scheduler episode path/admission/row/probe witness differs")
    if arm == "actual_native":
        if episode.get("native_receipt") != expected_native_receipt(provenance):
            raise ValueError("actual native scheduler lacks externally bound receipt")
    elif episode.get("native_receipt") is not None:
        raise ValueError("Python scheduler arm carries native receipt")


def require_probe(execution, arm, expected, provenance):
    lines = Path(execution["attach"]["stdout"]["path"]).read_text().splitlines()
    values = [json.loads(line[len(MARKER):]) for line in lines if line.startswith(MARKER)]
    if len(values) != 1:
        raise ValueError("one actual scheduler entry marker required")
    value = values[0]
    if (value.get("schema") != ENTRY_SCHEMA or value.get("arm") != arm
            or value.get("cli_source") != "/opt/scheduler-screen/production_cli.py"
            or value.get("entry_source") != "/opt/scheduler-screen/entry.py"
            or value.get("timing_scope") != TIMING_SCOPE or value.get("rankable") is not False
            or type(value.get("episodes")) is not list or len(value["episodes"]) != expected):
        raise ValueError("actual scheduler entry origin/arm/episode roster differs")
    for episode in value["episodes"]:
        require_episode_witness(episode, arm, provenance)
    return value

def run_one(args, metadata, provenance, arm, item, folder, suffix, reference=True):
    execution, output = linux.run_container(args, metadata['id'], arm, item, folder, args.owner, suffix)
    row = {'arm': arm, 'unit': item['unit'], 'execution': execution, 'output': str(output),
        'passed': False, 'rankable': False, 'timing_included': False}
    try:
        if not execution['succeeded'] or any(sha(Path(value['staged'])) != value['sha256'] for value in execution['staged_inputs']):
            raise ValueError('strict run or original staged input failed')
        row['output_inventory'] = inventory(output)
        row['probe'] = require_probe(execution, arm, len(item['subs']) if item['shape'] == 'batch' else 1, provenance)
        events = public.read_json(output / ('events.json' if item['shape'] == 'single' else 'batch_events.json'))
        if events != row['probe']['events']:
            raise ValueError('probe/actual sidecar differs')
        if item['shape'] == 'batch' and [r['sub'] for r in events.get('per_scenario', [])] != sorted(r['sub'] for r in item['subs']):
            raise ValueError('actual batch episode order differs from original CLI sorted input order')
        if reference:
            row['reference_checks'] = public.verify_outputs(args.reference_root / item['unit'], output, item)
            row['developer_verifier'] = linux.gate(args, args.reference_root / item['unit'], output, folder)
            if not row['reference_checks']['passed'] or row['developer_verifier'].get('admissible') is not True:
                raise ValueError('original reference or unchanged official verifier failed')
        else:
            scenario = public.read_json(item['scenario_paths'][0])
            frames = [public.compare_frame(output / name, Path(item['isolated_reference']) / name) for name in public.SUB_FILES[:2]]
            checked = public.verify_events(output, scenario, frames[0].get('candidate_rows', 0))
            tree = public.check_tree(output, set(public.SUB_FILES))
            if not all(r['passed'] for r in frames) or not checked['passed'] or not tree['passed']:
                raise ValueError('isolated original reference/sidecar/tree failed')
            row['reference_checks'] = {'passed': True, 'frames': frames, 'sidecar': checked, 'tree': tree,
                'actual_events': frames[0]['candidate_rows']}
        actual = row['reference_checks']['actual_events']
        if events.get('n_events', events.get('total_events')) != actual:
            raise ValueError('actual Parquet rows differ from sidecar/probe')
        frames = row['reference_checks']['frames']
        if len(frames) != 2 * len(row['probe']['episodes']):
            raise ValueError('actual frame/episode roster differs')
        by_path = {Path(frame['candidate']).relative_to(output).as_posix(): frame for frame in frames}
        episode_paths = ([""] if item['shape'] == 'single' else
                         [sub['sub'] + '/' for sub in sorted(item['subs'], key=lambda value: value['sub'])])
        for prefix, episode in zip(episode_paths, row['probe']['episodes']):
            if (episode['complete_trace_rows'] != by_path[prefix + 'trace.parquet']['candidate_rows']
                    or episode['message_rows'] != by_path[prefix + 'message_trace.parquet']['candidate_rows']):
                raise ValueError('episode witnesses differ from both actual Parquet row counts')
        row.update(actual_events=actual,
            cli_wall_sec=events['wall_clock_sec'], settled_container_runtime_sec=duration_ns(execution['state']))
        if any(not math.isfinite(value) or value <= 0 for value in
                (row['cli_wall_sec'], row['settled_container_runtime_sec'], execution['host_wall_sec'])):
            raise ValueError('actual measured wall clocks must be positive and finite')
        row['cli_events_per_sec'] = row['actual_events'] / row['cli_wall_sec']
        row['host_events_per_sec'] = row['actual_events'] / execution['host_wall_sec']
        row['daemon_events_per_sec'] = row['actual_events'] / row['settled_container_runtime_sec']
        row['passed'] = True
    except BaseException as error:
        row['failure'] = type(error).__name__ + ': ' + str(error)
    write(folder / 'RUN_RESULT.json', row)
    print(arm, item['unit'], 'PASS' if row['passed'] else 'FAIL', flush=True)
    return row


def pair(output, other, item):
    frames = list(public.SUB_FILES[:2]) if item['shape'] == 'single' else [sub['sub'] + '/' + name for sub in item['subs'] for name in public.SUB_FILES[:2]]
    results = [public.compare_frame(output / name, other / name) for name in frames]
    sidecars = ['events.json'] if item['shape'] == 'single' else [sub['sub'] + '/events.json' for sub in item['subs']] + ['batch_events.json']
    stable = []
    for name in sidecars:
        a, b = public.read_json(output / name), public.read_json(other / name)
        for value in (a, b):
            for key in ('wall_clock_sec', 'events_per_sec', 'peak_memory_bytes', 'gpu_seconds'):
                value.pop(key, None)
        stable.append({'path': name, 'candidate': a, 'baseline': b, 'passed': a == b})
    return {'passed': all(r['passed'] and r.get('byte_equal') for r in results) and all(r['passed'] for r in stable),
        'frames': results, 'stable_sidecars': stable}


def validate_controls(output, provenance, plan):
    boundary = public.read_json(output / "BOUNDARY_RESULT.json")
    markets = public.read_json(output / "markets/RESULT.json")
    outer = public.read_json(output / "RESULT.json")
    control_plan = public.read_json(PAYLOAD / CANDIDATE / "CONTROL_PLAN.json")
    if (boundary.get("schema") != "t3-native-canonical-scheduler-ledger-boundary-controls-v3"
            or boundary.get("all_passed") is not True or boundary.get("failures") != []
            or [row["name"] for row in boundary["cases"]] != [row["name"] for row in control_plan["cases"]]
            or len(boundary["cases"]) != 41 or any(row.get("passed") is not True for row in boundary["cases"])
            or boundary.get("extension") != IMAGE_CANDIDATE + "/" + provenance["extension"]["path"]
            or boundary.get("runtime_files") != 64 or boundary.get("scheduler_arms") != ARMS
            or boundary.get("plan_category_counts") != {"queue": 10, "ledger": 4, "scheduler": 20, "guard": 2, "integration": 5}
            or boundary.get("expected_scheduler_variants") != 33 or boundary.get("scheduler_variant_count") != 33
            or boundary.get("expected_scheduler_arm_executions") != 99 or boundary.get("scheduler_arm_executions") != 99
            or boundary.get("control_probe_only") is not True
            or boundary.get("production_extension_owners") != 1 or boundary.get("control_probe_extensions") != 1
            or boundary.get("rankable") is not False or boundary.get("timing_claim") is not False):
        raise ValueError("actual41 boundary controls failed or roster differs")
    fixtures = ast.parse((PAYLOAD / CANDIDATE / "scheduler_fixtures.py").read_text())
    variants = next(ast.literal_eval(node.value) for node in fixtures.body
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "VARIANTS"
            for target in node.targets))
    variant_count = guard_count = integration_count = 0
    for expected, actual in zip(control_plan["cases"], boundary["cases"]):
        name, category = expected["name"], expected["category"]
        if category == "scheduler":
            witnesses = actual.get("variant_witnesses", [])
            if ([row.get("variant") for row in witnesses] != list(variants.get(name, ("ordinary",)))
                    or any(row.get("arms") != 3 or row.get("outcome_guard_checked") is not True
                        or row.get("native_private_owner_probe_checked") is not True
                        or row.get("native_column_list_aliases_checked") != 9
                        or type(row.get("state_sha256")) is not str or len(row["state_sha256"]) != 64
                        or any(c not in "0123456789abcdef" for c in row["state_sha256"]) for row in witnesses)):
                raise ValueError("scheduler exact variant/return/private-alias witness differs")
            variant_count += len(witnesses)
        elif category == "guard":
            witnesses = actual.get("guard_witnesses", [])
            expected_guard = ([{"name": "valid_void_return", "accepted": True},
                {"name": "same_late_throw_after_enqueue", "rejected": True},
                {"name": "captured_assertion_must_fail", "rejected": True},
                {"name": "wrong_void_return", "rejected": True}]
                if name == "guard_rejects_unexpected_late_throw" else [record
                for case, variant in [("receive_callback_raises", "ordinary"),
                    ("wakeup_result_custom_equality", "raises"), ("set_wakeup_default_equal_past", "past"),
                    *( ("send_callback_raises", variant) for variant in ("order", "type", "order_id"))]
                for record in ({"name": case + ":" + variant, "accepted": True},
                    {"name": case + ":" + variant + ":wrong_args", "rejected": True},
                    {"name": case + ":" + variant + ":missing_throw", "rejected": True})])
            if witnesses != expected_guard:
                raise ValueError("exact22 outcome guard subchecks differ")
            guard_count += len(witnesses)
        elif category == "integration":
            witnesses = actual.get("integration_witnesses", [])
            if len(witnesses) != 1:
                raise ValueError("one fresh child per integration case required")
            witness = witnesses[0]
            required = {"case": name, "passed": True,
                "extension_sha256": provenance["extension"]["sha256"],
                "kernel_binding_restored": True, "latency_binding_restored": True}
            if name == "loader_exec_failure_restore":
                required.update(actual_extension_loader_calls=1,
                    actual_extension_exec_completed_before_controlled_failure=True,
                    controlled_failure_is_success=False, context_body_entered=False,
                    native_sys_modules_removed=True, loader_cache_clear=True)
            else:
                required.update(fresh_process=True, actual_extension_loader="ExtensionFileLoader",
                    native_load_count=1, original_kernel_owner=True,
                    build_receipt_sha256=provenance["build_receipt_sha256"],
                    source_receipt_sha256=plan["source_receipt_sha256"])
            if witness != required:
                raise ValueError("actual fresh integration loader/restoration witness differs")
            integration_count += 1
    if (variant_count, guard_count, integration_count) != (33, 22, 5):
        raise ValueError("complete scheduler/guard/integration cardinalities required")
    if (outer.get("schema") != "t3-native-canonical-scheduler-v3-controls"
            or outer.get("all_passed") is not True or outer.get("failures") != []
            or outer.get("boundary") != boundary or outer.get("markets") != markets
            or outer.get("arms") != ARMS or outer.get("boundary_cases") != 41
            or outer.get("scheduler_variants") != 33 or outer.get("scheduler_variant_arm_runs") != 99
            or outer.get("full_market_cases") != 4
            or outer.get("market_records") != 12 or outer.get("control_parquets") != 24
            or outer.get("rankable") is not False or outer.get("timing_claim") is not False
            or outer.get("official_gate") is not False):
        raise ValueError("actual outer scheduler controls differs")
    if (markets.get("schema") != "t3-native-canonical-scheduler-v3-market-controls"
            or markets.get("all_passed") is not True or markets.get("failures") != []
            or len(markets.get("cases", [])) != 4 or markets.get("arms") != ARMS
            or markets.get("market_records") != 12 or markets.get("control_parquet_blobs") != 24
            or markets.get("market_seed_cases") != 4 or markets.get("worker_roots") != 3
            or markets.get("nine_payload_components") is not True
            or markets.get("source_mapping_spec_sha256") != plan["source_mapping_spec_sha256"]
            or markets.get("controls_source_sha256") != next(row["sha256"] for row in plan["root_control_files"] if row["path"] == "market_controls.py")
            or markets.get("literal_unmapped_representation_equality_claimed") is not False
            or markets.get("rankable") is not False or markets.get("timing_claim") is not False
            or markets.get("official_gate") is not False
            or [row.get("seed") for row in markets["cases"]] != MARKET_SEEDS):
        raise ValueError("actual three-arm complete market controls differs")
    if plan.get("market_control_contract_ready") is not True:
        raise ValueError("pending root mapping-aware market control contract")
    if any(set(markets.get(key, {})) != set(ARMS) for key in ("workers", "data_sha256", "worker_receipt_sha256")):
        raise ValueError("all3 worker/data/receipt hash anchors required")
    expected_control_files = {"BOUNDARY_RESULT.json", "boundary.log", "markets.log", "RESULT.json",
        "markets/RESULT.json", *("markets/" + arm + ".log" for arm in ARMS),
        *("markets/" + arm + "/" + name for arm in ARMS
            for name in ("WORKER_RECEIPT.json", "SEMANTIC_VALUES.pkl")),
        *("markets/" + arm + "/" + str(seed) + "/" + name for arm in ARMS
            for seed in MARKET_SEEDS for name in public.SUB_FILES[:2])}
    if set(inventory(output)) != expected_control_files:
        raise ValueError("complete regular controls output roster differs")
    workers = {}
    parquet_records = []
    for arm in ARMS:
        folder = output / "markets" / arm
        worker = public.read_json(folder / "WORKER_RECEIPT.json")
        if (worker.get("schema") != "t3-native-canonical-scheduler-v3-semantic-worker" or worker.get("arm") != arm
                or worker.get("rankable") is not False or worker.get("timing_claim") is not False
                or worker.get("json_domain_admitted_all") is not True
                or worker.get("source_mapping_spec_sha256") != plan["source_mapping_spec_sha256"]
                or worker.get("values_sha256") != sha(folder / "SEMANTIC_VALUES.pkl")
                or markets["data_sha256"][arm] != worker["values_sha256"]
                or markets["worker_receipt_sha256"][arm] != sha(folder / "WORKER_RECEIPT.json")
                or markets["workers"][arm] != worker
                or [row.get("seed") for row in worker.get("cases", [])] != MARKET_SEEDS):
            raise ValueError("actual market worker schema/source/receipt/data hash differs")
        expected_files = {"WORKER_RECEIPT.json", "SEMANTIC_VALUES.pkl",
            *(str(seed) + "/" + name for seed in MARKET_SEEDS for name in public.SUB_FILES[:2])}
        if set(inventory(folder)) != expected_files:
            raise ValueError("exact8 retained Parquets and2 worker files per arm required")
        for index, seed in enumerate(MARKET_SEEDS):
            case, row = markets["cases"][index], worker["cases"][index]
            if (case.get("passed") is not True or case.get("three_way_complete_equal") is not True
                    or type(case.get("trace_rows")) is not int or case["trace_rows"] <= 0
                    or type(case.get("message_rows")) is not int or case["message_rows"] <= 0
                    or row.get("trace_rows") != case["trace_rows"] or row.get("message_rows") != case["message_rows"]
                    or row.get("details") != case.get("details") or set(case.get("witnesses", {})) != set(ARMS)):
                raise ValueError("complete market case/row/details/arm witness differs")
            witness = row["scheduler_witness"]
            if case["witnesses"][arm] != witness:
                raise ValueError("market case and saved worker witness differ")
            require_episode_witness(witness, arm, provenance, semantic=True)
            if witness["complete_trace_rows"] != case["trace_rows"] or witness["message_rows"] != case["message_rows"]:
                raise ValueError("market row witnesses differ")
            mapped = witness.get("mapping", {})
            if (mapped.get("arm") != arm or mapped.get("mapping_version") != "t3-scheduler-representation-v1"
                    or type(mapped.get("ledger_rows")) is not int or mapped["ledger_rows"] <= 0
                    or mapped.get("end_state_aliases") != [True, True, True]
                    or mapped.get("scheduler_owner_verified") is not (arm != "original_canonical")
                    or mapped.get("original_has_no_scheduler") is not (arm == "original_canonical")
                    or any(mapped.get(key) is not True for key in ("exact_kernel_heap_ledger_types",
                        "heap_queue_original_list", "columns_tuple_retained", "nine_distinct_exact_list_aliases", "all_agent_kernel_aliases"))):
                raise ValueError("complete mapping owner/list/end-state contract differs")
            private = mapped.get("native_private_witness")
            expected_private = {"native_ledger_owner_checked": True, "columns_tuple_shape": 9,
                "column_list_aliases": [True] * 9, "column_lists_distinct": True, "control_only": True,
                "mutation_performed": False, "native_scheduler_owner_checked": True, "scheduler_kernel_identity": True}
            if private != (expected_private if arm == "actual_native" else None):
                raise ValueError("actual Cython private scheduler/ledger witness differs")
            for name, count in (("trace.parquet", case["trace_rows"]), ("message_trace.parquet", case["message_rows"])):
                compared = public.compare_frame(folder / str(seed) / name, output / "markets" / ARMS[0] / str(seed) / name)
                if (compared.get("passed") is not True or compared.get("byte_equal") is not True
                        or compared.get("candidate_rows") != count):
                    raise ValueError("actual retained full-market Parquet bytes/values/dtypes/rows differ")
                parquet_records.append({"arm": arm, "seed": seed, "path": name, **compared})
        workers[arm] = worker
    if len(parquet_records) != 24:
        raise ValueError("exact24 retained complete market Parquets required")
    return {"boundary": boundary, "markets": markets, "workers": workers,
            "guard_subchecks": guard_count, "fresh_integration_children": integration_count,
            "retained_parquet_records": parquet_records, "retained_semantic_pickle_deserialized_by_controller": False,
            "saved_inert_full_payload_audit_required": True}


def screen(args, plan):
    args.owner = uuid.uuid4().hex
    args.timeout = 300
    metadata = public.read_json(args.evidence / 'IMAGE.json')
    provenance = validate_build(plan, args.evidence / "actual-candidates/candidate",
        args.evidence / "actual-candidates/runtime", args.evidence / "actual-candidates/root-control")
    before_image = image(args, metadata['id'], args.evidence / 'image-before-screen')
    if before_image['inspection'] != metadata['inspection']:
        raise ValueError('actual image changed before screen')
    roster = public.collect_plan(args.reference_root, SINGLES + [BATCH])
    write(args.evidence / 'REFERENCE_PLAN.json', roster)
    items = {value['unit']: value for value in roster['units']}
    if len(items[BATCH]['subs']) != 5:
        raise ValueError('original full five-member batch required')
    rows, failure, first, serial = [], None, {}, 0
    try:
        controls_input = args.evidence / 'fixed-control-input.json'
        write(controls_input, {'proof_command': 'scheduler-v3-boundary41-variants33-markets12-parquet24'})
        controls_item = {'shape': 'single', 'scenario_paths': [str(controls_input)]}
        args.timeout = 1800
        execution, output = linux.run_container(args, metadata['id'], 'controls', controls_item,
            args.evidence / 'controls', args.owner, 'controls')
        args.timeout = 300
        if not execution['succeeded'] or any(sha(Path(r['staged'])) != r['sha256'] for r in execution['staged_inputs']):
            raise ValueError('strict controls container or fixed input failed')
        audited_controls = validate_controls(output / 'controls', provenance, plan)
        write(args.evidence / 'CONTROL_RESULT.json', {'passed': True, 'execution': execution, **audited_controls})
        for stage, repeats in (('smoke', [0]), ('screen', [-1, 0, 1, 2])):
            units = [SINGLES[0], SINGLES[1], BATCH] if stage == 'smoke' else SINGLES + [BATCH]
            for repeat in repeats:
                for index, unit in enumerate(units):
                    order = arm_order(index, repeat)
                    group = {}
                    for arm in order:
                        serial += 1
                        folder = args.evidence / stage / ('warmup' if repeat < 0 else 'repeat-' + str(repeat)) / unit / arm
                        row = run_one(args, metadata, provenance, arm, items[unit], folder, '%04d' % serial)
                        row.update(stage=stage, repeat=repeat, warmup=repeat < 0, order=order,
                            timing_included=stage == 'screen' and repeat >= 0)
                        rows.append(row); group[arm] = row
                        write(args.evidence / 'RAW_RESULTS.json', rows)
                        if not row['passed']:
                            raise ValueError('screen stopped at failed run')
                    for arm, row in group.items():
                        output = Path(row['output'])
                        row['same_round_pair'] = pair(output, Path(group['original_canonical']['output']), items[unit])
                        key = (stage, unit, arm)
                        previous = first.setdefault(key, output)
                        row['same_arm_repeat_pair'] = pair(output, previous, items[unit])
                        row['passed'] &= row['same_round_pair']['passed'] and row['same_arm_repeat_pair']['passed']
                        write(output.parent / 'RUN_RESULT.json', row)
                        write(args.evidence / 'RAW_RESULTS.json', rows)
                        if not row['passed']:
                            raise ValueError('paired or repeat output differs')
                    write(args.evidence / 'RAW_RESULTS.json', rows)
        batch = items[BATCH]
        for arm in ARMS:
            full = next(r for r in reversed(rows) if r['unit'] == BATCH and r['arm'] == arm)
            for sub in batch['subs']:
                serial += 1
                item = {'unit': BATCH + '/' + sub['sub'], 'shape': 'single', 'subs': [],
                    'scenario_paths': [str(args.reference_root / BATCH / sub['scenario_file'])],
                    'isolated_reference': str(args.reference_root / BATCH / 'checks/reference_data' / sub['sub'])}
                folder = args.evidence / 'isolation' / arm / sub['sub']
                row = run_one(args, metadata, provenance, arm, item, folder, '%04d' % serial, reference=False)
                row.update(stage='isolation')
                rows.append(row)
                write(args.evidence / 'RAW_RESULTS.json', rows)
                row.update(stage='isolation', isolation_pair=pair(Path(row['output']), Path(full['output']) / sub['sub'], item))
                row['passed'] &= row['isolation_pair']['passed']
                write(folder / 'RUN_RESULT.json', row); write(args.evidence / 'RAW_RESULTS.json', rows)
                if not row['passed']:
                    raise ValueError('fresh batch isolation failed')
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
    unchanged = all(sha(args.reference_root / item['unit'] / name) == digest for item in roster['units']
        for mapping in (item['input_sha256'], item['reference_sha256']) for name, digest in mapping.items())
    try:
        after_image = image(args, metadata['id'], args.evidence / 'image-after-screen')
        immutable = after_image['inspection'] == before_image['inspection']
        verify_payload(PAYLOAD)
        validate_build(plan, args.evidence / "actual-candidates/candidate",
            args.evidence / "actual-candidates/runtime", args.evidence / "actual-candidates/root-control")
        if not immutable:
            raise ValueError('actual image changed during screen')
    except BaseException as error:
        immutable = False
        failure = failure or type(error).__name__ + ': ' + str(error)
    measured = [r for r in rows if r.get('timing_included')]
    official_runs = sum('developer_verifier' in r for r in rows)
    official_gate_passes = sum(
        gate.get('passed') is True
        for row in rows for gate in (row.get('developer_verifier', {}).get('verdict') or {}).get('gate_results', {}).values())
    comparisons = []
    for arm, baseline in (('actual_native', 'original_canonical'), ('actual_native', 'matching_python'), ('matching_python', 'original_canonical')):
        rates = []
        for unit in SINGLES + [BATCH]:
            a = [r for r in measured if r['arm'] == baseline and r['unit'] == unit and r['passed']]
            b = [r for r in measured if r['arm'] == arm and r['unit'] == unit and r['passed']]
            if len(a) != 3 or len(b) != 3:
                continue
            rates.append({'unit': unit, **{name: statistics.median(r[key] if key != 'host_wall_sec' else r['execution'][key] for r in a)
                / statistics.median(r[key] if key != 'host_wall_sec' else r['execution'][key] for r in b)
                for name, key in (('cli_ratio', 'cli_wall_sec'), ('host_ratio', 'host_wall_sec'), ('daemon_ratio', 'settled_container_runtime_sec'))}})
        comparisons.append({'arm': arm, 'baseline': baseline, 'per_unit': rates,
            **{key: statistics.mean(r[key] for r in rates) if len(rates) == 5 else None for key in ('cli_ratio', 'host_ratio', 'daemon_ratio')}})
    summary = {'schema': SCREEN_SCHEMA, 'all_passed': failure is None and len(rows) == 84
        and len(measured) == 45 and official_runs == 69 and official_gate_passes == 276
        and all(r['passed'] for r in rows) and unchanged and immutable,
        'runs': len(rows), 'planned_runs': 84, 'control_invocations': 1, 'measured_runs': len(measured),
        'failure': failure, 'comparisons': comparisons, 'original_inputs_references_unchanged': unchanged,
        'image_source_provenance_unchanged': immutable, 'total_execution_containers': len(rows) + 1,
        'official_verifier_runs': official_runs, 'official_gate_passes': official_gate_passes,
        'rankable': False, 'official_score': None, 'publication': False, 'competition_upload': False}
    write(args.evidence / 'SUMMARY.json', summary)
    if not summary['all_passed']:
        raise RuntimeError('native scheduler screen incomplete or failed')


def archive_evidence(args):
    if args.artifact.exists():
        raise ValueError("new artifact directory required")
    args.artifact.mkdir(parents=True)
    success = (args.evidence / 'SUMMARY.json').is_file() and public.read_json(args.evidence / 'SUMMARY.json').get('all_passed') is True
    omitted = {}
    for source in sorted(args.evidence.rglob("*")):
        if source.name.startswith("._") or "__pycache__" in source.parts or not source.is_file() or source.is_symlink():
            continue
        relative = source.relative_to(args.evidence)
        # Omit ordinary successful run bytes only after every gate passed.
        # Always retain controls outputs and complete failed/unknown run bytes.
        compact_run = success and relative.parts[0] in ('smoke', 'screen', 'isolation') and any(p in ('input', 'output') for p in relative.parts)
        if relative.parts[0] in ('build-context', 'anonymous-config') or compact_run:
            omitted[relative.as_posix()] = {'bytes': source.stat().st_size, 'sha256': sha(source),
                'reason': 'successful ordinary run bytes' if compact_run else 'duplicate build context or empty anonymous configuration'}
            continue
        target = args.artifact / "evidence" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    write(args.artifact / 'OMITTED_FILES.json', {'all_runs_passed': success, 'files': omitted})
    shutil.copyfile(args.archive, args.artifact / "SCREEN_PAYLOAD.tar.xz")
    write(args.artifact / "ARTIFACT.json", {"archive_sha256": sha(args.archive),
        "compact_success_outputs_omitted_full_failures_retained": True, 'successful_runs_compacted': success,
        'controls_outputs_retained': True, "rankable": False, "timing_claim": False,
        "files": inventory(args.artifact)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("build", "screen", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--reference-root", type=Path)
    parser.add_argument("--gate-kit", type=Path)
    parser.add_argument("--gate-python", default=sys.executable)
    parser.add_argument("--docker", default="docker")
    parser.add_argument("--timeout", type=float, default=900)
    parser.add_argument("--log-cap-bytes", type=int, default=4 * 1024 ** 2)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--artifact", type=Path)
    args = parser.parse_args()
    signal.signal(signal.SIGINT, linux.cancellation)
    signal.signal(signal.SIGTERM, linux.cancellation)
    args.evidence = args.evidence.resolve()
    args.evidence.mkdir(parents=True, exist_ok=True)
    if args.stage == "artifact":
        archive_evidence(args)
        return
    verify_payload(PAYLOAD)
    plan = public.read_json(PAYLOAD / "SCREEN_PLAN.json")
    required = {"base": BASE, "candidate": CANDIDATE, "runtime_owner": RUNTIME_OWNER,
        "schema": "t3-native-canonical-scheduler-v3-screen-plan",
        "source_receipt_sha256": SOURCE_RECEIPT_SHA256,
        "runtime_pins_sha256": RUNTIME_PINS_SHA256,
        "root_control_source_receipt_sha256": CONTROL_SOURCE_RECEIPT_SHA256,
        "single_units": SINGLES, "batch_unit": BATCH, "arms": ARMS, "boundary_cases": 41,
        "scheduler_variants": 33, "scheduler_variant_arm_runs": 99, "market_cases": 4,
        "full_market_episodes": 12, "control_parquets": 24, "planned_runs": 84,
        "measured_runs": 45, "control_invocations": 1, "total_execution_containers": 85,
        "official_verifier_runs": 69, "official_gate_passes": 276, "full_five_member_batch": True,
        "no_performance_early_stop": True, "warmups": 1, "measured_repeats": 3,
        "build_count": 1, "extension_builds": 2, "rankable": False,
        "production_extension_owners": 1, "control_probe_extensions": 1,
        "market_control_contract_ready": True, "controls_first": True,
        "build_time_bytecode_factor": False, "arm_order": "three_fresh_rotating_positions_unit_parity_reversal"}
    if any(plan.get(key) != value for key, value in required.items()):
        raise ValueError("fixed scheduler screen plan differs")
    final_control_path = PAYLOAD / "control/FINAL_ROOT_CONTROL_SOURCE_RECEIPT_v1.json"
    final_control = public.read_json(final_control_path)
    if (sha(final_control_path) != CONTROL_SOURCE_RECEIPT_SHA256
            or final_control.get("schema") != "t3-native-canonical-scheduler-v3-final-root-control-source-receipt"
            or final_control.get("files") != plan["root_control_files"] or final_control.get("file_count") != 5
            or final_control.get("market_control_contract_ready") is not True
            or final_control.get("runtime_sources_unchanged") is not True
            or final_control.get("actual_execution") is not False
            or len(plan["image_control_files"]) != 6
            or set(row["path"] for row in plan["image_control_files"]) != {"entry.py",
                "production_cli.py", "market_controls.py", "semantic_worker.py", "semantic_mapping.py", "SOURCE_MAPPING_SPEC.json"}
            or plan["source_mapping_spec_sha256"] != sha(PAYLOAD / "control/SOURCE_MAPPING_SPEC.json")):
        raise ValueError("final root mapping/control freeze and exact6 image control files required")
    wrapper_receipt_path = PAYLOAD / "control/SOURCE_PREPARATION_RECEIPT_v1.json"
    wrapper = public.read_json(wrapper_receipt_path)
    if (sha(wrapper_receipt_path) != plan["wrapper_source_receipt_sha256"]
            or wrapper.get("schema") != "t3-native-canonical-scheduler-v3-wrapper-source-preparation-v1"
            or wrapper.get("source_file_count") != 8 or len(wrapper.get("files", [])) != 8
            or wrapper.get("files") != plan["wrapper_source_files"]):
        raise ValueError("prepared wrapper source receipt differs")
    for row in wrapper["files"]:
        path = PAYLOAD / "control" / safe_name(row["path"])
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("prepared wrapper source bytes differ")
    if args.stage == "build":
        build(args, plan)
    else:
        if not args.reference_root or not args.gate_kit:
            raise ValueError("original host references and official toolkit required")
        screen(args, plan)


if __name__ == "__main__":
    main()
