"""Freeze-check and materialize source bytes only after both owners are final."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import (BASE, BATCH, CANDIDATE, RUNTIME_OWNER, ARMS, MAX_BYTES, MAX_FILES, SINGLES,
    SOURCE_RECEIPT_SHA256, RUNTIME_PINS_SHA256, CONTROL_SOURCE_RECEIPT_SHA256,
    inventory, safe_name, sha, write)

HERE = Path(__file__).resolve().parent
COMPLETION = HERE.parent


def copy(source, destination):
    if source.is_symlink() or not source.is_file():
        raise ValueError("ordinary source file required")
    if source.suffix == ".py":
        ast.parse(source.read_text(), filename=str(source))
    if source.suffix == ".json":
        json.loads(source.read_text())
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    destination.chmod(0o644)
    if sha(source) != sha(destination):
        raise ValueError("source copy differs")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.archive.exists():
        raise ValueError("new staging directory and archive required")
    if len(SOURCE_RECEIPT_SHA256) != 64 or len(CONTROL_SOURCE_RECEIPT_SHA256) != 64:
        raise ValueError("candidate and root control sources must be frozen before staging")
    candidate = COMPLETION / Path(CANDIDATE).relative_to("completion1009")
    runtime = COMPLETION / Path(RUNTIME_OWNER).relative_to("completion1009")
    receipt_path = candidate / "SOURCE_PREPARATION_RECEIPT_v3.json"
    control_receipt_path = HERE / "FINAL_ROOT_CONTROL_SOURCE_RECEIPT_v1.json"
    wrapper_receipt_path = HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"
    if sha(receipt_path) != SOURCE_RECEIPT_SHA256 or sha(control_receipt_path) != CONTROL_SOURCE_RECEIPT_SHA256:
        raise ValueError("frozen candidate/root control receipt differs")
    receipt = json.loads(receipt_path.read_text())
    control_receipt = json.loads(control_receipt_path.read_text())
    wrapper_receipt = json.loads(wrapper_receipt_path.read_text())
    wrapper_names = {"common.py", "materialize.py", "entry.py", "controller.py", "stage.py",
                     "Dockerfile", "README.md", "workflow.yml"}
    if (wrapper_receipt.get("schema") != "t3-native-canonical-scheduler-v3-wrapper-source-preparation-v1"
            or wrapper_receipt.get("source_file_count") != 8
            or set(row["path"] for row in wrapper_receipt.get("files", [])) != wrapper_names
            or len(wrapper_receipt["files"]) != 8 or wrapper_receipt.get("source_only") is not True
            or wrapper_receipt.get("candidate_imported") is not False
            or wrapper_receipt.get("native_build_executed") is not False
            or wrapper_receipt.get("market_executed") is not False):
        raise ValueError("source-only wrapper preparation receipt required")
    for row in wrapper_receipt["files"]:
        path = HERE / safe_name(row["path"])
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("prepared wrapper source changed")
    if (receipt.get("schema") != "t3-native-canonical-scheduler-ledger-source-preparation-v3"
            or receipt.get("source_file_count") != 20 or len(receipt.get("files", [])) != 20):
        raise ValueError("exact20 frozen scheduler source files required")
    plan_controls = json.loads((candidate / "CONTROL_PLAN.json").read_text())
    if (len(plan_controls["cases"]) != 41 or len({row["name"] for row in plan_controls["cases"]}) != 41
            or plan_controls.get("scheduler_fixture_variants") != 33):
        raise ValueError("fixed41 boundary/33scheduler variant plan required")
    pins_path = candidate / "RUNTIME_PINS.json"
    pins = json.loads(pins_path.read_text())
    if sha(pins_path) != RUNTIME_PINS_SHA256 or len(pins["files"]) != 64:
        raise ValueError("exact64-file runtime pins required")
    expected_runtime = {row["path"]: {k: row[k] for k in ("bytes", "sha256")} for row in pins["files"]}
    if inventory(runtime) != expected_runtime:
        raise ValueError("complete runtime differs from frozen pins")
    root_controls = control_receipt["files"]
    required_root_files = {"production_cli.py", "market_controls.py", "semantic_worker.py",
                           "semantic_mapping.py", "SOURCE_MAPPING_SPEC.json"}
    if (set(row["path"] for row in root_controls) != required_root_files
            or control_receipt.get("schema") != "t3-native-canonical-scheduler-v3-final-root-control-source-receipt"
            or len(root_controls) != 5 or control_receipt.get("file_count") != 5
            or control_receipt.get("runtime_sources_unchanged") is not True
            or control_receipt.get("actual_execution") is not False
            or control_receipt.get("market_control_contract_ready") is not True):
        raise ValueError("complete root mapping-aware source contract pending")
    args.out.mkdir(parents=True)
    for row in receipt["files"]:
        name = safe_name(row["path"])
        source = candidate / name
        if source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]:
            raise ValueError("candidate frozen source differs")
        copy(source, args.out / CANDIDATE / name)
    copy(receipt_path, args.out / CANDIDATE / receipt_path.name)
    for row in pins["files"]:
        copy(runtime / row["path"], args.out / RUNTIME_OWNER / row["path"])
    for row in root_controls:
        source = HERE / row["path"]
        if source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]:
            raise ValueError("root mapping/control source differs")
        copy(source, args.out / "control" / row["path"])
    copy(control_receipt_path, args.out / "control" / control_receipt_path.name)
    for name in ("verify_linux.py", "verify_public.py", "fetch_evaluation.py"):
        copy(COMPLETION / name, args.out / "host" / name)
    for name in sorted(wrapper_names):
        copy(HERE / name, args.out / "control" / name)
    copy(wrapper_receipt_path, args.out / "control" / wrapper_receipt_path.name)
    image_control_files = [{"path": "entry.py", "bytes": (HERE / "entry.py").stat().st_size,
                            "sha256": sha(HERE / "entry.py")}, *root_controls]
    plan = {"schema": "t3-native-canonical-scheduler-v3-screen-plan", "base": BASE,
        "candidate": CANDIDATE, "runtime_owner": RUNTIME_OWNER, "arms": ARMS,
        "source_receipt_sha256": SOURCE_RECEIPT_SHA256, "source_files": receipt["files"],
        "runtime_pins_sha256": RUNTIME_PINS_SHA256, "runtime_files": pins["files"],
        "root_control_source_receipt_sha256": CONTROL_SOURCE_RECEIPT_SHA256,
        "wrapper_source_receipt_sha256": sha(wrapper_receipt_path), "wrapper_source_files": wrapper_receipt["files"],
        "root_control_files": root_controls, "image_control_files": image_control_files,
        "source_mapping_spec_sha256": sha(HERE / "SOURCE_MAPPING_SPEC.json"),
        "market_control_contract_ready": True, "single_units": SINGLES, "batch_unit": BATCH,
        "boundary_cases": 41, "scheduler_variants": 33, "scheduler_variant_arm_runs": 99,
        "market_cases": 4, "full_market_episodes": 12, "control_parquets": 24,
        "controls_first": True, "build_count": 1, "extension_builds": 2,
        "production_extension_owners": 1, "control_probe_extensions": 1,
        "warmups": 1, "measured_repeats": 3, "planned_runs": 84, "control_invocations": 1,
        "total_execution_containers": 85, "measured_runs": 45, "official_verifier_runs": 69,
        "official_gate_passes": 276, "no_performance_early_stop": True,
        "arm_order": "three_fresh_rotating_positions_unit_parity_reversal",
        "build_time_bytecode_factor": False, "proof_only": True, "timing_claim": False,
        "rankable": False, "official_submission": False, "full_five_member_batch": True}
    write(args.out / "SCREEN_PLAN.json", plan)
    files = inventory(args.out)
    if len(files) + 1 > MAX_FILES or sum(row["bytes"] for row in files.values()) > MAX_BYTES:
        raise ValueError("finite source payload bound exceeded")
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-native-canonical-scheduler-v3-screen-payload", "files": files})
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.archive, "w:xz", preset=6) as archive:
        for name in sorted(inventory(args.out)):
            data = (args.out / name).read_bytes()
            member = tarfile.TarInfo(safe_name(name))
            member.size, member.mode, member.mtime = len(data), 0o644, 0
            member.uid = member.gid = 0
            archive.addfile(member, io.BytesIO(data))
    write(args.archive.with_suffix(args.archive.suffix + ".json"), {
        "archive": str(args.archive), "sha256": sha(args.archive), "bytes": args.archive.stat().st_size,
        "regular_members": len(files) + 1, "source_only": True, "candidate_imported": False,
        "native_build_executed": False, "market_executed": False, "workflow_dispatched": False})


if __name__ == "__main__":
    main()
