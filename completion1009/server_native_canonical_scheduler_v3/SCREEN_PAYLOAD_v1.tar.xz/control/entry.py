"""Three actual scheduler entry arms and sequential boundary/full-market controls."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path("/opt/scheduler-screen")
CANDIDATE = ROOT / "completion1009/candidates/native_canonical_scheduler_ledger_v3"
RUNTIME = ROOT / "completion1009/candidates/lean_production_native_projection_v1/runtime"
ARMS = ("original_canonical", "matching_python", "actual_native")
MARKER = "T3_NATIVE_CANONICAL_SCHEDULER_V3_SCREEN="


def controls():
    output = Path("/output/controls")
    if output.exists():
        raise ValueError("fresh controls output required")
    output.mkdir()
    deployment = json.loads((CANDIDATE / "DEPLOYMENT.json").read_text())
    extension = CANDIDATE / deployment["extension_path"]
    report = {"schema": "t3-native-canonical-scheduler-v3-controls", "all_passed": False,
        "failures": [], "rankable": False, "timing_claim": False, "official_gate": False}
    def launch(source, arguments, log):
        with log.open("xb") as stream:
            result = subprocess.run([sys.executable, "-B", str(source), *arguments],
                stdout=stream, stderr=subprocess.STDOUT, cwd=str(source.parent),
                env=dict(os.environ), timeout=1200)
        if result.returncode:
            raise ValueError("actual fresh control worker failed: " + str(log))
    try:
        launch(CANDIDATE / "boundary_controls.py", ["--runtime", str(RUNTIME),
            "--extension", str(extension), "--out", str(output / "BOUNDARY_RESULT.json")],
            output / "boundary.log")
        boundary = json.loads((output / "BOUNDARY_RESULT.json").read_text())
        if (boundary.get("schema") != "t3-native-canonical-scheduler-ledger-boundary-controls-v3"
                or boundary.get("all_passed") is not True or len(boundary.get("cases", [])) != 41
                or boundary.get("failures") != [] or boundary.get("scheduler_variant_count") != 33
                or boundary.get("scheduler_arm_executions") != 99
                or boundary.get("rankable") is not False or boundary.get("timing_claim") is not False):
            raise ValueError("all41 actual boundary controls required")
        launch(ROOT / "market_controls.py", ["--runtime", str(RUNTIME), "--candidate", str(CANDIDATE),
            "--out", str(output / "markets")], output / "markets.log")
        markets = json.loads((output / "markets/RESULT.json").read_text())
        if (markets.get("schema") != "t3-native-canonical-scheduler-v3-market-controls"
                or markets.get("all_passed") is not True or markets.get("failures") != []
                or len(markets.get("cases", [])) != 4 or markets.get("market_records") != 12
                or markets.get("control_parquet_blobs") != 24 or markets.get("market_seed_cases") != 4
                or markets.get("worker_roots") != 3 or markets.get("nine_payload_components") is not True
                or markets.get("arms") != list(ARMS) or markets.get("rankable") is not False
                or markets.get("timing_claim") is not False or markets.get("official_gate") is not False):
            raise ValueError("all4 three-arm complete market controls required")
        report.update(all_passed=True, boundary=boundary, markets=markets,
            boundary_cases=41, scheduler_variants=33, scheduler_variant_arm_runs=99,
            full_market_cases=4, market_records=12, control_parquets=24, arms=list(ARMS))
    except BaseException as error:
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    (output / "RESULT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return 0 if report["all_passed"] else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("simulate", "simulate-batch"))
    parser.add_argument("--config")
    parser.add_argument("--out")
    parser.add_argument("--batch-dir")
    parser.add_argument("--out-dir")
    parser.add_argument("--mode", choices=(*ARMS, "controls"), required=True)
    args = parser.parse_args()
    if args.mode == "controls":
        if (args.verb != "simulate" or args.config != "/input/scenario.json"
                or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir
                or json.loads(Path(args.config).read_text()) != {"proof_command": "scheduler-v3-boundary41-variants33-markets12-parquet24"}):
            raise ValueError("fixed scheduler controls input required")
        raise SystemExit(controls())
    single = args.verb == "simulate"
    if single:
        if args.config != "/input/scenario.json" or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir:
            raise ValueError("fixed single paths required")
    elif args.batch_dir != "/input/scenarios" or args.out_dir != "/output" or args.config or args.out:
        raise ValueError("fixed batch paths required")
    import production_cli as cli
    cli.reset_probes()
    result = (cli.simulate(args.config, args.out, args.mode, started=cli.ENTRY_STARTED) if single
        else cli.simulate_batch(args.batch_dir, args.out_dir, args.mode, started=cli.ENTRY_STARTED))
    episodes = cli.episode_probes()
    if len(episodes) != (1 if single else result["n_scenarios"]):
        raise ValueError("actual scheduler episode roster differs")
    for witness in episodes:
        if (witness.get("scheduler_arm") != args.mode or witness.get("native_active") is not (args.mode == "actual_native")
                or witness.get("fallback_used") is not False
                or type(witness.get("json_domain_admitted")) is not bool
                or type(witness.get("complete_trace_rows")) is not int or witness["complete_trace_rows"] <= 0
                or type(witness.get("message_rows")) is not int or witness["message_rows"] <= 0
                or witness.get("installation_restored") is not True
                or witness.get("control_probe_loaded") is not False or witness.get("rankable") is not False
                or witness.get("runtime_source_compilation") is not False
                or witness.get("per_episode_native_hash_audit") is not False):
            raise ValueError("actual requested scheduler path not observed")
        if args.mode == "actual_native" and type(witness.get("native_receipt")) is not dict:
            raise ValueError("actual native scheduler receipt absent")
        if args.mode != "actual_native" and witness.get("native_receipt") is not None:
            raise ValueError("Python arm carries a native scheduler receipt")
    print(MARKER + json.dumps({"schema": "t3-native-canonical-scheduler-v3-entry", "arm": args.mode,
        "events": result, "episodes": episodes, "cli_source": str(ROOT / "production_cli.py"),
        "entry_source": str(Path(__file__).resolve()), "rankable": False,
        "timing_scope": "CLI ENTRY_STARTED through Parquet/hash; unchanged sidecar cutoff; marker serialization outside CLI timer"},
        sort_keys=True, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
