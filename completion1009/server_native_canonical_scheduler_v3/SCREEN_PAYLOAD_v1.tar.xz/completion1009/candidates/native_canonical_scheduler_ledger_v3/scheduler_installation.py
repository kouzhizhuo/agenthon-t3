"""Serial context for one explicit arm, restoring every original binding."""
from contextlib import contextmanager


@contextmanager
def enabled(arm="native"):
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_fork import trace
    from abides_fork.config import ScenarioLatencyModel
    from column_trace import make_extractor
    from optimizations import scalar_latency
    if arm == "native":
        from scheduler_loader import load_scheduler
        engine = load_scheduler()
    elif arm == "matching_python":
        import matching_python_schedule as engine
    elif arm == "original_canonical":
        import original_canonical_engine as engine
    else:
        raise ValueError("unknown scheduler arm: " + arm)
    if (engine.IncumbentKernel is not Kernel or not issubclass(engine.CanonicalKernel, Kernel)
            or engine.CanonicalKernel.initialize is not Kernel.initialize
            or engine.CanonicalKernel.terminate is not Kernel.terminate):
        raise ValueError("scheduler arm incumbent owner differs")
    extractor = make_extractor(engine.ColumnLedger, trace.extract_message_trace,
                               trace.MESSAGE_TRACE_COLUMNS, trace._MSG_DTYPES)
    old_kernel, old_latency = abides.Kernel, ScenarioLatencyModel.get_latency
    abides.Kernel, ScenarioLatencyModel.get_latency = engine.CanonicalKernel, scalar_latency
    try:
        yield extractor
    finally:
        abides.Kernel, ScenarioLatencyModel.get_latency = old_kernel, old_latency
