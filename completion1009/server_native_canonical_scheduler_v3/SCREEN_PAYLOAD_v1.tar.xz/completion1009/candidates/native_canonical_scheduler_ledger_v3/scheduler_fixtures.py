"""Actual three-arm callback fixtures, prepared as source and never run by author.

The incumbent and matching-Python engines are independent executable oracles.
Assertions check original boundary behavior before their state witnesses are
compared with the actual native extension. No synthetic timing is scored.
"""
import contextlib
from datetime import datetime
import hashlib
import io
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from outcome_guards import assert_outcome


def typed(value, labels):
    """Encode value/type and registered object identity without executing payloads."""
    if id(value) in labels:
        return {"reference": labels[id(value)]}
    name = type(value).__module__ + "." + type(value).__qualname__
    if value is None or type(value) in (bool, int, float, str):
        return {"type": name, "value": value}
    if type(value) in (tuple, list):
        return {"type": name, "items": [typed(item, labels) for item in value]}
    if type(value) is dict:
        return {"type": name, "items": [[typed(k, labels), typed(v, labels)]
                                           for k, v in value.items()]}
    if type(value).__module__.startswith("numpy"):
        if hasattr(value, "shape") and value.shape != ():
            return {"type": name, "dtype": str(value.dtype), "shape": list(value.shape),
                    "value": value.tolist()}
        return {"type": name, "dtype": str(value.dtype), "value": value.item()}
    raise AssertionError("unregistered fixture object: " + name)


def make_agent_class(Agent):
    class FixtureAgent(Agent):
        def __init__(self, id, np, events):
            super().__init__(id, name="fixture_" + str(id), type="FixtureAgent",
                             random_state=np.random.RandomState(400 + id),
                             log_events=True, log_to_file=False)
            self.events = events
            self.receive_hook = None
            self.wakeup_hook = None
            self.raw_state = {"value": 23}

        def point(self, kind, message=None):
            k = self.kernel
            self.events.append((kind, self.id, k.current_time,
                k.agent_current_times[self.id], k.current_agent_additional_delay,
                k._current_causal_uid, k._deliver_seq,
                tuple(k._deliver_seq_by_key.items()), len(k._msg_ledger), message))

        def kernel_initializing(self, kernel):
            super().kernel_initializing(kernel)
            self.events.append(("initializing", self.id))

        def kernel_starting(self, start_time):
            self.events.append(("starting", self.id, start_time))
            super().kernel_starting(start_time)

        def receive_message(self, current_time, sender_id, message):
            super().receive_message(current_time, sender_id, message)
            self.point("receive", message)
            if self.receive_hook is not None:
                return self.receive_hook(current_time, sender_id, message)

        def wakeup(self, current_time):
            super().wakeup(current_time)
            self.point("wakeup")
            if self.wakeup_hook is not None:
                return self.wakeup_hook(current_time)

        def apply_actions(self, actions):
            self.events.append(("actions", self.id, actions))

        def update_raw_state(self):
            self.events.append(("update_raw_state", self.id))

        def get_raw_state(self):
            self.events.append(("get_raw_state", self.id))
            return self.raw_state

        def kernel_stopping(self):
            self.events.append(("stopping", self.id))
            super().kernel_stopping()

        def kernel_terminating(self):
            self.events.append(("terminating", self.id))
            super().kernel_terminating()
    return FixtureAgent


class RecordingNoise:
    def __init__(self, np, events):
        self.random_state = np.random.RandomState(712)
        self.events = events

    def choice(self, size, p):
        self.events.append(("choice", size, p))
        return self.random_state.choice(size, p=p)

    def get_state(self):
        return self.random_state.get_state()


class RecordingLatency:
    def __init__(self, np, events, kernel):
        self.np, self.events, self.kernel = np, events, kernel

    def get_latency(self, sender_id, recipient_id):
        self.events.append(("model_latency", sender_id, recipient_id,
                            self.kernel.current_time))
        return self.np.float64(self.kernel.random_state.uniform(2, 6))


def run_variant(case, variant, engine, np, native_probe=None):
    import heapq
    import pandas as pd
    from abides_core.agent import Agent
    from abides_core.kernel import Kernel
    from abides_core.message import Message, MessageBatch, WakeupMsg
    from abides_markets.orders import Order
    import observer

    observer.finish_episode()
    setattr(Message, "_Message__message_id_counter", 1)
    Order._order_id_counter = 0
    events, labels, objects = [], {}, {}

    def register(name, value):
        assert name not in objects and id(value) not in labels
        objects[name] = value
        labels[id(value)] = name
        return value

    AgentType = make_agent_class(Agent)
    if case == "actions_gym_and_termination":
        class CoreGymAgent(AgentType):
            pass
        class FixtureGymAgent(CoreGymAgent):
            pass
        agents = [FixtureGymAgent(0, np, events), AgentType(1, np, events)]
    else:
        agents = [AgentType(0, np, events), AgentType(1, np, events)]
    for agent in agents:
        register("agent" + str(agent.id), agent)
    kernel = engine.CanonicalKernel(agents, start_time=1, stop_time=100,
        default_computation_delay=2, default_latency=0, latency_noise=[1.0],
        random_state=np.random.RandomState(712), seed=712, skip_log=True,
        log_dir="fixture")
    for agent in agents:
        agent.kernel = kernel
    register("ledger_initial", kernel._msg_ledger)
    column_aliases = kernel._msg_ledger.columns
    column_list_aliases = tuple(column_aliases)
    queue_alias = kernel.messages.queue
    scheduler_alias = getattr(kernel, "_canonical_scheduler", None)
    agent_times_alias = kernel.agent_current_times
    compute_alias = kernel.agent_computation_delays
    delivery_map_alias = kernel._deliver_seq_by_key
    agents_alias = kernel.agents
    agent_log_aliases = tuple(agent.log for agent in agents)
    kernel.ttl_messages = 1
    kernel.event_queue_wall_clock_start = datetime(2000, 1, 1)
    outcome, extra = None, {}

    def enqueue(time, sender, recipient, message):
        heapq.heappush(kernel.messages.queue, (time, sender, recipient, message))

    def message(name):
        return register(name, Message())

    def callbacks(kind):
        return [row for row in events if row[0] == kind]

    def call(function):
        nonlocal outcome
        try:
            outcome = ("returned", function())
        except Exception as error:
            outcome = ("raised", type(error).__module__ + "." + type(error).__qualname__,
                       error.args)

    if case.startswith("receive_"):
        first, second = message("first"), message("second")
        if case == "receive_single_body_order":
            time = np.int64(10)
            kernel.agent_computation_delays[1] = np.int64(2)
            agents[1].receive_hook = lambda *args: setattr(kernel, "current_agent_additional_delay", 3)
            enqueue(time, 0, 1, first)
        elif case == "receive_callback_raises":
            def fail(*args):
                kernel.current_agent_additional_delay = 7
                raise RuntimeError("fixture receive failed")
            agents[1].receive_hook = fail
            enqueue(10, 0, 1, first)
            enqueue(20, 0, 1, second)
        else:
            batch = register("batch", MessageBatch([] if case == "receive_empty_batch" else [first, second]))
            if case == "receive_callback_mutates_batch":
                third = message("third")
                def mutate(current_time, sender_id, value):
                    if value is first:
                        if variant == "append":
                            batch.messages.append(third)
                        else:
                            batch.messages.remove(second)
                    kernel.current_agent_additional_delay = 3
                agents[1].receive_hook = mutate
            elif case == "receive_batch_order":
                agents[1].receive_hook = lambda *args: setattr(kernel, "current_agent_additional_delay", 3)
            enqueue(10, 0, 1, batch)
        call(kernel.runner)
        received = callbacks("receive")
        if case == "receive_empty_batch":
            assert not received and kernel._deliver_seq == 0
            assert kernel.agent_current_times[1] == 10 and len(kernel._msg_ledger) == 0
        else:
            assert received[0][3:9] == (12, 0, first.message_id, 1,
                                         (((first.message_id, 1), 0),), 0)
            assert received[0][-1] is first
            if case == "receive_single_body_order":
                assert len(received) == 1 and type(kernel.agent_current_times[1]) is np.int64
            elif case == "receive_callback_raises":
                assert outcome == ("raised", "builtins.RuntimeError", ("fixture receive failed",))
                assert kernel.agent_current_times[1] == 12 and kernel.current_agent_additional_delay == 7
                assert kernel.messages.queue[0][3] is second and len(received) == 1
            else:
                expected = ([first, second] if case == "receive_batch_order" else
                            [first, second, third] if variant == "append" else [first])
                assert [row[-1] for row in received] == expected
                assert all(row[-1] is value for row, value in zip(received, expected))
                assert [row[3] for row in received] == [12, 17, 22][:len(expected)]
                assert kernel._deliver_seq == len(expected)
        assert kernel._msg_ledger.columns is column_aliases

    elif case.startswith("wakeup_"):
        wake = register("wake", WakeupMsg())
        enqueue(10, 1, 1, wake)
        if case == "wakeup_callback_and_ledger":
            def change_delay(current_time):
                kernel.current_agent_additional_delay = 3
                kernel.agent_computation_delays[1] = 4
            agents[1].wakeup_hook = change_delay
        elif case == "wakeup_result_false_nonnull":
            agents[1].wakeup_hook = lambda current_time: False
            enqueue(20, 0, 1, message("pending"))
        else:
            class Result:
                def __ne__(self, other):
                    assert other is None
                    events.append(("result_ne", other))
                    if variant == "raises":
                        raise RuntimeError("fixture wakeup inequality failed")
                    return variant == "nonnull"
            result = register("wakeup_result", Result())
            agents[1].wakeup_hook = lambda current_time: result
        call(kernel.runner)
        awakened = callbacks("wakeup")
        assert len(awakened) == 1
        assert awakened[0][3:9] == (10, 0, wake.message_id, 1,
                                      (((wake.message_id, 1), 0),), 1)
        assert [column[0] for column in kernel._msg_ledger.columns] == [
            wake.message_id, 1, 1, None, 10, 0, "AGENT_WAKEUP", None, None]
        if case == "wakeup_callback_and_ledger":
            assert kernel.agent_current_times[1] == 17
        elif case == "wakeup_result_false_nonnull":
            assert outcome == ("returned", {"done": False, "result": False})
            assert len(kernel.messages.queue) == 1
        else:
            assert callbacks("result_ne") == [("result_ne", None)]
            assert kernel.agent_current_times[1] == 12
            if variant == "raises":
                assert outcome == ("raised", "builtins.RuntimeError",
                                   ("fixture wakeup inequality failed",))
            elif variant == "nonnull":
                assert outcome[1]["done"] is False and outcome[1]["result"] is result
            else:
                assert outcome == ("returned", {"done": True, "result": None})

    elif case in ("future_message_requeue", "future_wakeup_requeue"):
        value = register("future", WakeupMsg()) if case == "future_wakeup_requeue" else message("future")
        kernel.stop_time = 5
        kernel.agent_current_times[1] = 20
        kernel.current_agent_additional_delay = 9
        enqueue(10, 0, 1, value)
        call(kernel.runner)
        assert kernel.messages.queue == [(20, 0, 1, value)]
        assert kernel.messages.queue[0][3] is value
        assert not events and len(kernel._msg_ledger) == kernel._deliver_seq == 0
        assert kernel.current_time == 10 and kernel.ttl_messages == 2
        assert kernel.current_agent_additional_delay == 0

    elif case == "stop_time_overshoot":
        first, second = message("first"), message("second")
        kernel.stop_time = 10
        enqueue(11, 0, 1, first)
        enqueue(12, 0, 1, second)
        call(kernel.runner)
        assert len(callbacks("receive")) == 1 and callbacks("receive")[0][-1] is first
        assert kernel.current_time == 11 and kernel.messages.queue[0][3] is second
        assert outcome == ("returned", {"done": True, "result": None})

    elif case == "clock_zero_truthiness":
        kernel.current_time = 0 if variant == "zero" else None
        first = message("first")
        enqueue(10, 0, 1, first)
        call(kernel.runner)
        assert not events and kernel.messages.queue[0][3] is first
        assert kernel.ttl_messages == 1 and kernel._deliver_seq == 0
        assert outcome == ("returned", {"done": True, "result": None})

    elif case == "send_single_snapshot":
        kernel.current_time = 1 << 100
        kernel.current_agent_additional_delay = 3
        kernel._current_causal_uid = register("causal_before", object())
        causal_after = register("causal_after", object())
        order = register("order", SimpleNamespace(order_id=np.int64(45)))
        new_ledger = register("ledger_replacement", engine.ColumnLedger())
        class SendMessage(Message):
            @property
            def order(self):
                events.append(("order_get", len(kernel.messages.queue), len(kernel._msg_ledger)))
                kernel._msg_ledger = new_ledger
                return order

            def type(self):
                events.append(("type_get", self.message_id, len(kernel.messages.queue)))
                self.message_id += 100
                kernel._current_causal_uid = causal_after
                return "SEND_SNAPSHOT"
        value = register("single", SendMessage())
        original_id = value.message_id
        call(lambda: kernel.send_message(0, 1, value, delay=4))
        sent_time = (1 << 100) + 9
        assert events[:2] == [("order_get", 1, 0), ("type_get", original_id, 1)]
        assert kernel.messages.queue == [(sent_time, 0, 1, value)]
        assert kernel.messages.queue[0][3] is value
        row = [column[0] for column in new_ledger.columns]
        assert row == [original_id, 0, 1, sent_time, sent_time, 0,
                       "SEND_SNAPSHOT", order.order_id, causal_after]
        assert row[7] is order.order_id and row[8] is causal_after
        assert len(objects["ledger_initial"]) == 0

    elif case == "send_batch_and_duplicate_refs":
        first, second = message("first"), message("second")
        batch = register("batch", MessageBatch([first, second, first]))
        kernel.current_time = np.int64(10)
        call(lambda: kernel.send_message(0, 1, batch, delay=np.int32(3)))
        assert kernel.messages.queue[0][3] is batch
        assert kernel._msg_ledger.columns[0] == [first.message_id, second.message_id, first.message_id]
        assert len(kernel._msg_ledger) == 3 and batch.messages[0] is batch.messages[2]
        assert all(type(value) is np.int64 for value in kernel._msg_ledger.columns[3])

    elif case == "send_callback_mutates_batch":
        first, second, third = message("first"), message("second"), message("third")
        original_id = first.message_id
        class MutatingMessage(Message):
            @property
            def order(self):
                events.append(("order_get", "mutator", len(kernel.messages.queue), len(kernel._msg_ledger)))
                return None

            def type(self):
                events.append(("type_get", "mutator", len(kernel.messages.queue), len(kernel._msg_ledger)))
                if variant == "append":
                    live_messages.append(third)
                elif variant == "remove":
                    live_messages.remove(second)
                elif variant == "clear":
                    live_messages.clear()
                elif variant == "replace":
                    batch.messages = replacement_messages
                else:
                    raise AssertionError("unknown send mutation variant")
                return "SEND_MUTATOR"
        mutator = register("mutator", MutatingMessage())
        batch = register("batch", MessageBatch([mutator, second]))
        live_messages = register("live_messages", batch.messages)
        replacement_messages = register("replacement_messages", [third])
        kernel.current_time = np.int64(10)
        call(lambda: kernel.send_message(0, 1, batch, delay=np.int32(3)))
        expected = ([mutator, second, third] if variant == "append" else
                    [mutator, second] if variant == "replace" else [mutator])
        assert kernel.messages.queue[0][3] is batch and len(kernel.messages.queue) == 1
        assert kernel._msg_ledger.columns[0] == [value.message_id for value in expected]
        assert kernel._msg_ledger.columns[6] == ["SEND_MUTATOR"] + ["Message"] * (len(expected) - 1)
        assert len(kernel._msg_ledger) == len(expected)
        assert events == [("order_get", "mutator", 1, 0), ("type_get", "mutator", 1, 0)]
        if variant == "replace":
            assert batch.messages is replacement_messages and live_messages == [mutator, second]
        else:
            assert batch.messages is live_messages
            assert live_messages == ([mutator, second, third] if variant == "append" else
                                     [mutator] if variant == "remove" else [])
        assert type(kernel._msg_ledger.columns[3][0]) is np.int64
        assert first.message_id == original_id

    elif case == "send_callback_raises":
        first, second = message("first"), message("second")
        class FailingOrder:
            @property
            def order_id(self):
                events.append(("order_id_get", len(kernel.messages.queue), len(kernel._msg_ledger)))
                raise RuntimeError("fixture send order_id failed")
        order = register("failing_order", FailingOrder())
        class FailingMessage(Message):
            @property
            def order(self):
                events.append(("order_get", len(kernel.messages.queue), len(kernel._msg_ledger)))
                if variant == "order":
                    raise RuntimeError("fixture send order failed")
                return order if variant == "order_id" else None

            def type(self):
                events.append(("type_get", len(kernel.messages.queue), len(kernel._msg_ledger)))
                if variant == "type":
                    raise RuntimeError("fixture send type failed")
                return "SEND_FAILING"
        failing = register("failing", FailingMessage())
        batch = register("batch", MessageBatch([first, failing, second]))
        kernel.current_time = np.int64(10)
        call(lambda: kernel.send_message(0, 1, batch, delay=np.int32(3)))
        assert kernel.messages.queue[0][3] is batch and len(kernel.messages.queue) == 1
        assert batch.messages == [first, failing, second]
        assert len(kernel._msg_ledger) == 1 and kernel._msg_ledger.columns[0] == [first.message_id]
        assert kernel._msg_ledger.columns[6] == ["Message"]
        expected_events = [("order_get", 1, 1)]
        if variant != "order":
            expected_events.append(("type_get", 1, 1))
        if variant == "order_id":
            expected_events.append(("order_id_get", 1, 1))
        assert events == expected_events
        assert kernel._deliver_seq == 0 and not kernel._deliver_seq_by_key

    elif case == "send_latency_model_rng":
        value = message("single")
        kernel.current_time = np.int64(10)
        kernel.agent_computation_delays[0] = np.int64(2)
        kernel.current_agent_additional_delay = np.int64(3)
        kernel.agent_latency_model = RecordingLatency(np, events, kernel)
        expected_rng = np.random.RandomState(712)
        latency = np.float64(expected_rng.uniform(2, 6))
        call(lambda: kernel.send_message(0, 1, value, delay=np.int32(4)))
        assert events == [("model_latency", 0, 1, np.int64(10))]
        assert kernel.messages.queue[0][0] == np.int64(19) + int(latency)
        assert typed(kernel.random_state.get_state(), labels) == typed(expected_rng.get_state(), labels)
        assert type(kernel._msg_ledger.columns[3][0]) is np.int64

    elif case == "send_legacy_rng_noise":
        kernel.random_state = RecordingNoise(np, events)
        kernel.latency_noise = [0.2, 0.3, 0.5]
        kernel.agent_latency = [[0, np.float64(1.75)], [0, 0]]
        values = [message("message" + str(index)) for index in range(3)]
        expected_rng = np.random.RandomState(712)
        noise = [expected_rng.choice(3, p=kernel.latency_noise) for _ in values]
        def send_all():
            for value in values:
                kernel.send_message(0, 1, value)
        call(send_all)
        assert events == [("choice", 3, kernel.latency_noise)] * 3
        assert kernel._msg_ledger.columns[4] == [3 + int(np.float64(1.75) + n) for n in noise]
        assert typed(kernel.random_state.get_state(), labels) == typed(expected_rng.get_state(), labels)
        assert len(kernel._msg_ledger) == 3

    elif case == "set_wakeup_default_equal_past":
        kernel.current_time = 0 if variant == "zero_past" else 10
        requested = {"default": None, "equal": np.int64(10), "past": 9,
                     "zero_past": -1, "large": 1 << 100}[variant]
        call(lambda: kernel.set_wakeup(1, requested))
        if variant == "past":
            assert not kernel.messages.queue and getattr(Message, "_Message__message_id_counter") == 1
        else:
            expected = 11 if requested is None else requested
            row = kernel.messages.queue[0]
            assert row[0] == expected and type(row[0]) is type(expected)
            assert row[1:3] == (1, 1) and type(row[3]) is WakeupMsg and row[3].message_id == 1
            register("scheduled_wakeup", row[3])
            assert getattr(Message, "_Message__message_id_counter") == 2
        assert len(kernel._msg_ledger) == kernel._deliver_seq == 0

    elif case == "actions_gym_and_termination":
        assert engine.CanonicalKernel.initialize is Kernel.initialize
        assert engine.CanonicalKernel.terminate is Kernel.terminate
        assert engine.CanonicalKernel.run is Kernel.run
        assert kernel.gym_agents == [agents[0]]
        kernel.start_time = kernel.current_time = 10
        kernel.agent_current_times[:] = [10, 10]
        actions = [{"action": "fixture", "quantity": np.int64(7)}]
        with TemporaryDirectory(prefix="t3-scheduler-controls-") as directory:
            old_directory = Path.cwd()
            try:
                os.chdir(directory)
                kernel.initialize()
                for _, _, _, value in kernel.messages.queue:
                    register("lifecycle_wakeup" + str(value.message_id), value)
                call(lambda: kernel.runner((agents[0], actions)))
                end_state = kernel.terminate()
                summary = Path("log/fixture/summary_log.bz2")
                assert summary.is_file()
                summary_frame = pd.read_pickle(summary, compression="bz2")
                extra["summary_file_columns"] = list(summary_frame.columns)
                extra["summary_file_records"] = summary_frame.to_dict("records")
            finally:
                os.chdir(old_directory)
        assert [row[0] for row in events] == ["initializing", "initializing",
            "starting", "starting", "actions", "wakeup", "wakeup",
            "update_raw_state", "get_raw_state", "stopping", "stopping",
            "terminating", "terminating"]
        assert events[4][2] is actions
        assert outcome[1]["done"] is True and outcome[1]["result"] is agents[0].raw_state
        assert end_state["agents"] is kernel.agents
        assert end_state["message_ledger"] is kernel._msg_ledger
        assert end_state["deliver_seq_by_key"] is kernel._deliver_seq_by_key
        assert kernel._msg_ledger.columns is column_aliases
        assert all(agent.kernel is kernel for agent in agents)
        assert end_state["kernel_slowest_agent_finish_time"] == 12
        assert set(end_state) == {"agents", "message_ledger", "deliver_seq_by_key",
            "kernel_slowest_agent_finish_time", "kernel_event_queue_elapsed_wallclock"}
        extra["end_state_aliases"] = [True, True, True, True]
        extra["slowest_finish"] = end_state["kernel_slowest_agent_finish_time"]
    else:
        raise AssertionError("missing concrete scheduler case: " + case)

    # Captured participant exceptions are checked after the callback capture;
    # a failing fixture assertion can never be relabeled as an expected throw.
    assert_outcome(case, variant, outcome)
    assert kernel.messages.queue is queue_alias
    assert kernel.agent_current_times is agent_times_alias
    assert kernel.agent_computation_delays is compute_alias
    assert kernel._deliver_seq_by_key is delivery_map_alias
    assert kernel.agents is agents_alias and all(a is b for a, b in zip(kernel.agents, agents))
    assert all(agent.log is alias for agent, alias in zip(agents, agent_log_aliases))
    assert objects["ledger_initial"].columns is column_aliases
    assert all(a is b for a, b in zip(objects["ledger_initial"].columns, column_list_aliases))
    if scheduler_alias is not None:
        assert kernel._canonical_scheduler is scheduler_alias
        if native_probe is not None:
            extra["private_native_owner"] = native_probe.audit_owner(kernel)
            # Keep comparable oracle state separate from native-only evidence.
            assert extra["private_native_owner"]["scheduler_kernel_identity"] is True
            extra.pop("private_native_owner")
        else:
            assert scheduler_alias.kernel is kernel
    extra["live_aliases"] = {"queue": True, "agent_times": True, "compute": True,
        "delivery_map": True, "agents": True, "agent_logs": [True] * len(agents),
        "initial_columns_tuple": True, "initial_column_lists": [True] * 9}
    for name, value in list(objects.items()):
        if isinstance(value, Message):
            extra["message:" + name] = {"id": value.message_id,
                "type": type(value).__module__ + "." + type(value).__qualname__,
                "batch": value.messages if isinstance(value, MessageBatch) else None}
    for name, value in list(objects.items()):
        if name.startswith("ledger_"):
            if native_probe is not None:
                witness = native_probe.audit_ledger(value)
                assert witness["column_list_aliases"] == [True] * 9
            elif scheduler_alias is not None:
                assert tuple(getattr(value, "c" + str(i)) for i in range(9)) == value.columns
                assert all(getattr(value, "c" + str(i)) is value.columns[i] for i in range(9))
            else:
                assert type(value.columns) is tuple and len(value.columns) == 9
                assert all(type(column) is list for column in value.columns)
                assert len({id(column) for column in value.columns}) == 9
            extra[name + ":columns"] = value.columns
    snapshot = {"outcome": outcome, "events": events, "clock": kernel.current_time,
        "agent_times": kernel.agent_current_times, "compute": kernel.agent_computation_delays,
        "additional": kernel.current_agent_additional_delay, "ttl": kernel.ttl_messages,
        "causal": kernel._current_causal_uid, "deliver_seq": kernel._deliver_seq,
        "delivery_map": kernel._deliver_seq_by_key, "queue": kernel.messages.queue,
        "ledger": kernel._msg_ledger.columns, "summary": kernel.summary_log,
        "agent_logs": [agent.log for agent in agents],
        "agent_current_time": [agent.current_time for agent in agents],
        "rng": kernel.random_state.get_state(),
        "message_counter": getattr(Message, "_Message__message_id_counter"),
        "order_counter": Order._order_id_counter, "extra": extra}
    return typed(snapshot, labels)


VARIANTS = {
    "receive_callback_mutates_batch": ("append", "remove"),
    "wakeup_result_custom_equality": ("nonnull", "equal_none", "raises"),
    "clock_zero_truthiness": ("zero", "none"),
    "set_wakeup_default_equal_past": ("default", "equal", "past", "zero_past", "large"),
    "send_callback_mutates_batch": ("append", "remove", "clear", "replace"),
    "send_callback_raises": ("order", "type", "order_id"),
}


def scheduler_probe(case, native, np):
    import original_canonical_engine as original
    import matching_python_schedule as matching
    from abides_core.kernel import logger
    from owner_probe_loader import load_owner_probe
    native_probe = load_owner_probe(native)
    witnesses = []
    prior_disabled = logger.disabled
    logger.disabled = True
    try:
        for variant in VARIANTS.get(case, ("ordinary",)):
            states = []
            for owner in (original, matching, native):
                output = io.StringIO()
                with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
                    state = run_variant(case, variant, owner, np,
                                        native_probe if owner is native else None)
                states.append({"state": state, "stdout": output.getvalue()})
            assert states[0] == states[1] == states[2], (case, variant, "three-arm state mismatch")
            encoded = json.dumps(states[0], sort_keys=True, separators=(",", ":"))
            witnesses.append({"variant": variant, "arms": 3,
                              "state_sha256": hashlib.sha256(encoded.encode()).hexdigest(),
                              "outcome_guard_checked": True,
                              "native_private_owner_probe_checked": True,
                              "native_column_list_aliases_checked": 9})
    finally:
        logger.disabled = prior_disabled
    return witnesses
