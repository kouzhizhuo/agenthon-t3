"""Control-only private ownership witness; never loaded by production CLI."""
from native_canonical_schedule cimport ColumnLedger, CanonicalScheduler
import native_canonical_schedule as owner


def bind_owner(native):
    assert owner is native
    return True


def audit_ledger(value):
    cdef ColumnLedger ledger
    cdef tuple columns
    assert type(value) is owner.ColumnLedger
    ledger = value
    columns = ledger.columns
    assert type(columns) is tuple and len(columns) == 9
    assert all(type(column) is list for column in columns)
    assert len({id(column) for column in columns}) == 9
    assert ledger.c0 is columns[0]
    assert ledger.c1 is columns[1]
    assert ledger.c2 is columns[2]
    assert ledger.c3 is columns[3]
    assert ledger.c4 is columns[4]
    assert ledger.c5 is columns[5]
    assert ledger.c6 is columns[6]
    assert ledger.c7 is columns[7]
    assert ledger.c8 is columns[8]
    return {"native_ledger_owner_checked": True, "columns_tuple_shape": 9,
        "column_list_aliases": [True] * 9, "column_lists_distinct": True,
        "control_only": True, "mutation_performed": False}


def audit_owner(kernel):
    cdef CanonicalScheduler scheduler
    assert type(kernel) is owner.CanonicalKernel
    assert type(kernel._canonical_scheduler) is owner.CanonicalScheduler
    scheduler = kernel._canonical_scheduler
    assert scheduler.kernel is kernel
    witness = audit_ledger(kernel._msg_ledger)
    witness.update(native_scheduler_owner_checked=True, scheduler_kernel_identity=True)
    return witness
