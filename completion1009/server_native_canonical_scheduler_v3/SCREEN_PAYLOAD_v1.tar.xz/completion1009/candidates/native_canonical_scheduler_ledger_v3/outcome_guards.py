"""Control-only outcome oracle; all assertions run outside captured callbacks."""


def expected_exception(case, variant):
    if case == "receive_callback_raises":
        return ("builtins.RuntimeError", ("fixture receive failed",))
    if case == "wakeup_result_custom_equality" and variant == "raises":
        return ("builtins.RuntimeError", ("fixture wakeup inequality failed",))
    if case == "set_wakeup_default_equal_past" and variant == "past":
        return ("builtins.ValueError", ("set_wakeup() called with requested time not in future",
            "current_time:", 10, "requested_time:", 9))
    if case == "send_callback_raises":
        return ("builtins.RuntimeError", ("fixture send " + variant + " failed",))
    return None


def assert_outcome(case, variant, outcome):
    """Reject a late throw even when all state changes already match three arms."""
    expected = expected_exception(case, variant)
    if expected is not None:
        assert outcome == ("raised", expected[0], expected[1]), (case, variant, "exact exception differs", outcome)
    else:
        assert type(outcome) is tuple and len(outcome) == 2 and outcome[0] == "returned", (
            case, variant, "unexpected exception or missing return", outcome)
        if case.startswith("send_") or case == "set_wakeup_default_equal_past":
            assert outcome[1] is None, (case, variant, "original void return differs", outcome)
        elif (case.startswith("receive_") or case in (
                "wakeup_callback_and_ledger", "future_message_requeue", "future_wakeup_requeue",
                "stop_time_overshoot", "clock_zero_truthiness")
                or case == "wakeup_result_custom_equality" and variant == "equal_none"):
            assert outcome[1] == {"done": True, "result": None}, (case, variant, "normal completion differs", outcome)


def guard_probe(case):
    """Future controls execute this oracle; source preparation never calls it."""
    checks = []

    def rejected(name, target_case, variant, outcome):
        try:
            assert_outcome(target_case, variant, outcome)
        except AssertionError:
            checks.append({"name": name, "rejected": True})
        else:
            raise AssertionError("malformed outcome was accepted: " + name)

    if case == "guard_rejects_unexpected_late_throw":
        assert_outcome("set_wakeup_default_equal_past", "equal", ("returned", None))
        checks.append({"name": "valid_void_return", "accepted": True})
        rejected("same_late_throw_after_enqueue", "set_wakeup_default_equal_past", "equal",
                 ("raised", "builtins.RuntimeError", ("same late throw after enqueue",)))
        rejected("captured_assertion_must_fail", "receive_single_body_order", "ordinary",
                 ("raised", "builtins.AssertionError", ("callback assertion failed",)))
        rejected("wrong_void_return", "send_single_snapshot", "ordinary", ("returned", False))
    elif case == "guard_exact_expected_exception_args":
        targets = [("receive_callback_raises", "ordinary"),
                   ("wakeup_result_custom_equality", "raises"),
                   ("set_wakeup_default_equal_past", "past")]
        targets += [("send_callback_raises", variant) for variant in ("order", "type", "order_id")]
        for target_case, variant in targets:
            error_type, args = expected_exception(target_case, variant)
            assert_outcome(target_case, variant, ("raised", error_type, args))
            checks.append({"name": target_case + ":" + variant, "accepted": True})
            rejected(target_case + ":" + variant + ":wrong_args", target_case, variant,
                     ("raised", error_type, args + ("extra",)))
            rejected(target_case + ":" + variant + ":missing_throw", target_case, variant,
                     ("returned", None))
    else:
        raise AssertionError("missing concrete outcome-guard case: " + case)
    return checks
