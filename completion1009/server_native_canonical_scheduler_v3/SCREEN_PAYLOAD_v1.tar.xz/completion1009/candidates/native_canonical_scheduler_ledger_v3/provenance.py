"""Build/deployment-only byte and ABI receipts; never import a candidate module."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import sysconfig

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def abi():
    return {"implementation": sys.implementation.name, "version": list(sys.version_info[:3]),
        "cache_tag": sys.implementation.cache_tag, "soabi": sysconfig.get_config_var("SOABI"),
        "ext_suffix": sysconfig.get_config_var("EXT_SUFFIX"), "platform": sys.platform,
        "machine": platform.machine(), "byteorder": sys.byteorder,
        "pointer_bits": 64 if sys.maxsize > 2**32 else 32}


def verify_sources():
    receipt = json.loads((HERE / "SOURCE_PREPARATION_RECEIPT_v3.json").read_text())
    for row in receipt["files"]:
        path = HERE / row["path"]
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("scheduler frozen source differs: " + row["path"])
    return {row["path"]: row["sha256"] for row in receipt["files"]}


def verify_runtime(runtime):
    runtime = Path(runtime).resolve()
    pins = json.loads((HERE / "RUNTIME_PINS.json").read_text())
    for row in pins["files"]:
        path = runtime / row["path"]
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("scheduler frozen runtime differs: " + row["path"])
    return {"files": len(pins["files"]), "runtime_pins_sha256": sha(HERE / "RUNTIME_PINS.json")}


def dependencies(spec):
    actual = {name: importlib.metadata.version(name) for name in spec["dependencies"]}
    if actual != spec["dependencies"]:
        raise ValueError("scheduler dependency versions differ: " + repr(actual))
    return actual
