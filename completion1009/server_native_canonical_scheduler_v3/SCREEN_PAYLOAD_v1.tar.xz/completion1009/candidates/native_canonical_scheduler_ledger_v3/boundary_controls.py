"""41 concrete boundary cases with explicit returns, exceptions and ownership.

Prepared source only. Runtime PASS requires loading the real extension and
executing every fixture; author source checks never call main or these probes.
"""
import argparse
import hashlib
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def load_native(path):
    # Future control-only real import. Source preparation never calls this.
    name = "native_canonical_schedule"
    spec = importlib.util.spec_from_file_location(name, path)
    if (spec is None or not isinstance(spec.loader, importlib.machinery.ExtensionFileLoader)
            or name in sys.modules):
        raise ValueError("actual fresh extension owner required")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
        if Path(module.__file__).resolve() != Path(path).resolve():
            raise ValueError("actual extension origin differs")
    except BaseException:
        sys.modules.pop(name, None)
        raise
    return module


def queue_probe(case, engine, np, Message):
    import heapq
    import queue
    original = queue.PriorityQueue()
    actual = engine.FlatHeap()
    first, second = Message(), Message()
    second.message_id = first.message_id + 1
    equal = Message()
    equal.message_id = first.message_id
    rows = {
        "heap_time_primary": [(2, 0, 0, first), (1, 0, 0, second)],
        "heap_sender_secondary": [(1, 2, 0, first), (1, 1, 9, second)],
        "heap_recipient_tertiary": [(1, 0, 2, first), (1, 0, 1, second)],
        "heap_message_id_tie": [(1, 0, 0, second), (1, 0, 0, first)],
        "heap_same_message_identity": [(1, 0, 0, first), (1, 0, 0, first)],
        "heap_equal_dataclass_messages": [(1, 0, 0, first), (1, 0, 0, equal)],
        "heap_arbitrary_precision_time": [(1 << 100, 0, 0, first), (-(1 << 100), 0, 0, second)],
        "heap_numpy_integer_keys": [(np.int64(10), np.int32(0), np.int32(1), first),
                                    (np.int64(9), np.int32(2), np.int32(0), second)],
        "heap_bool_float_keys": [(True, 0, 0, first), (.5, 0, 0, second)],
    }
    if case == "heap_comparison_exception_residue":
        class Raises:
            def __eq__(self, other): return False
            def __lt__(self, other): raise RuntimeError("original comparator failed")
        left, right = Raises(), Raises()
        def outcome(heap):
            heapq.heappush(heap, (left, 0, 0, first))
            try: heapq.heappush(heap, (right, 0, 0, second))
            except Exception as error: return type(error).__name__, str(error), list(heap)
            raise AssertionError("exception missing")
        before = outcome([])
        after = outcome(actual.queue)
        assert before[:2] == after[:2]
        assert len(before[2]) == len(after[2])
        assert all(a is b for x, y in zip(before[2], after[2]) for a, b in zip(x, y))
        return
    for row in rows[case]:
        t, sender, recipient, message = row
        original.put((t, (sender, recipient, message)))
        heapq.heappush(actual.queue, row)
    result = []
    while not original.empty():
        t, (sender, recipient, message) = original.get()
        got = heapq.heappop(actual.queue)
        assert (t, sender, recipient, message) == got
        assert all(type(a) is type(b) for a, b in zip((t, sender, recipient, message), got))
        assert got[3] is message
        result.append(got)
    assert actual.empty() and actual.qsize() == 0


def ledger_probe(case, engine, np):
    from original_canonical_engine import ColumnLedger as OriginalLedger
    before, after = OriginalLedger(), engine.ColumnLedger()
    sentinel = object()
    values = {
        "ledger_nine_columns_order": (1, 2, 3, 4, 5, 6, "MSG", 7, 8),
        "ledger_nullable_fields": (1 << 100, -2, 3, None, -(1 << 90), 0, "MSG", None, None),
        "ledger_numpy_and_custom_objects": (np.int64(1), np.int32(2), 3, None, np.int64(5),
                                            6, "MSG", sentinel, sentinel),
        "ledger_columns_aliases": (1, 2, 3, None, 5, 6, "MSG", sentinel, sentinel),
    }[case]
    columns = after.columns
    before.append_values(*values)
    after.append_values(*values)
    assert len(before) == len(after) == 1 and len(columns) == 9
    assert after.columns is columns
    for source, actual, value in zip(before.columns, columns, values):
        assert len(source) == len(actual) == 1
        assert source[0] is actual[0] is value
        assert type(source[0]) is type(actual[0])
    from owner_probe_loader import load_owner_probe
    witness = load_owner_probe(engine).audit_ledger(after)
    assert witness["column_list_aliases"] == [True] * 9 and witness["column_lists_distinct"] is True


def scheduler_probe(case, engine, np):
    from scheduler_fixtures import scheduler_probe as actual_fixture
    return actual_fixture(case, engine, np)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--extension", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists(): raise ValueError("fresh control result required")
    pins = json.loads((HERE / "RUNTIME_PINS.json").read_text())
    for row in pins["files"]:
        data = (args.runtime / row["path"]).read_bytes()
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            raise ValueError("boundary fixture frozen runtime differs")
    sys.path.insert(0, str(args.runtime.resolve()))
    from bootstrap import activate
    activate()
    import numpy as np
    from abides_core.message import Message
    engine = load_native(args.extension.resolve())
    plan = json.loads((HERE / "CONTROL_PLAN.json").read_text())
    report = {"schema": "t3-native-canonical-scheduler-ledger-boundary-controls-v3",
        "cases": [], "failures": [], "rankable": False, "timing_claim": False,
        "extension": str(args.extension.resolve()), "runtime_files": len(pins["files"]),
        "scheduler_arms": ["original_canonical", "matching_python", "actual_native"],
        "plan_category_counts": {"queue": 10, "ledger": 4, "scheduler": 20, "guard": 2, "integration": 5},
        "expected_scheduler_variants": 33, "expected_scheduler_arm_executions": 99,
        "control_probe_only": True, "production_extension_owners": 1, "control_probe_extensions": 1}
    for case in plan["cases"]:
        try:
            if case["category"] == "queue": queue_probe(case["name"], engine, np, Message)
            elif case["category"] == "ledger": ledger_probe(case["name"], engine, np)
            elif case["category"] == "scheduler":
                witnesses = scheduler_probe(case["name"], engine, np)
                report["cases"].append({"name": case["name"], "passed": True,
                                        "variant_witnesses": witnesses})
                continue
            elif case["category"] == "guard":
                from outcome_guards import guard_probe
                witnesses = guard_probe(case["name"])
                report["cases"].append({"name": case["name"], "passed": True,
                                        "guard_witnesses": witnesses})
                continue
            elif case["category"] == "integration":
                from integration_fixtures import integration_probe
                witnesses = integration_probe(case["name"], engine, np, args.extension, args.runtime)
                report["cases"].append({"name": case["name"], "passed": True,
                                        "integration_witnesses": witnesses})
                continue
            else:
                raise AssertionError("unknown boundary category")
            report["cases"].append({"name": case["name"], "passed": True})
        except Exception as error:
            report["failures"].append({"name": case["name"], "type": type(error).__name__, "message": str(error)})
    report["scheduler_variant_count"] = sum(len(row.get("variant_witnesses", [])) for row in report["cases"])
    report["scheduler_arm_executions"] = report["scheduler_variant_count"] * 3
    report["all_passed"] = (len(report["cases"]) == plan["case_count"] == 41
                            and report["scheduler_variant_count"] == 33 and not report["failures"])
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__": raise SystemExit(main())
