cdef class FlatHeap:
    cdef dict __dict__

cdef class ColumnLedger:
    cdef dict __dict__
    cdef list c0, c1, c2, c3, c4, c5, c6, c7, c8
    cdef void _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                     latency_ns, msg_type, order_id, causal_parent) except *

cdef class CanonicalScheduler:
    cdef object kernel
    cdef object _run(self, agent_actions)
    cdef object _send(self, sender_id, recipient_id, message, delay)
    cdef object _set_wakeup(self, sender_id, requested_time)
    cdef object _receive(self, kernel, sender_id, recipient_id, message)
    cdef object _record_send(self, kernel, message, sender_id, recipient_id,
                             sent_time, deliver_at)
