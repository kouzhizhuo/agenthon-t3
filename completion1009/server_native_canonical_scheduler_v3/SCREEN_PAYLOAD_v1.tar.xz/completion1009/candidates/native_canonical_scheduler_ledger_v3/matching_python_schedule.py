"""Original heapq/Python arithmetic scheduler with direct cdef object-list ledger.

Source-only prototype. No synthetic envelopes, fixed-width event arithmetic,
changed callback/RNG path, native-book integration, or runtime source audits.
"""
import heapq
from datetime import datetime
from abides_core.kernel import Kernel as IncumbentKernel, logger, fmt_ts
from abides_core.message import Message, MessageBatch, WakeupMsg

class FlatHeap:

    def __init__(self):
        self.queue = []

    def empty(self):
        return not self.queue

    def qsize(self):
        return len(self.queue)

class ColumnLedger:

    def __init__(self):
        self.c0, self.c1, self.c2 = [], [], []
        self.c3, self.c4, self.c5 = [], [], []
        self.c6, self.c7, self.c8 = [], [], []
        self.columns = (self.c0, self.c1, self.c2, self.c3, self.c4,
                        self.c5, self.c6, self.c7, self.c8)

    def __len__(self):
        return len(self.c0)

    def _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                     latency_ns, msg_type, order_id, causal_parent):
        self.c0.append(message_id)
        self.c1.append(src_id)
        self.c2.append(dst_id)
        self.c3.append(t_send_ns)
        self.c4.append(t_recv_ns)
        self.c5.append(latency_ns)
        self.c6.append(msg_type)
        self.c7.append(order_id)
        self.c8.append(causal_parent)

    def append_values(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                      latency_ns, msg_type, order_id, causal_parent):
        self._append(message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                     latency_ns, msg_type, order_id, causal_parent)

class CanonicalScheduler:

    def __init__(self, kernel):
        self.kernel = kernel

    def run(self, agent_actions=None):
        return self._run(agent_actions)

    def send(self, sender_id, recipient_id, message, delay=0):
        return self._send(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        return self._set_wakeup(sender_id, requested_time)

    def _receive(self, kernel, sender_id, recipient_id, message):
        kernel.agent_current_times[recipient_id] += kernel.agent_computation_delays[recipient_id] + kernel.current_agent_additional_delay
        if kernel.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('After receive_message return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
        kernel._current_causal_uid = message.message_id
        kernel._deliver_seq_by_key[message.message_id, recipient_id] = kernel._deliver_seq
        kernel._deliver_seq += 1
        kernel.agents[recipient_id].receive_message(kernel.current_time, sender_id, message)

    def _record_send(self, kernel, message, sender_id, recipient_id,
                             sent_time, deliver_at):
        order = getattr(message, 'order', None)
        ledger = kernel._msg_ledger
        ledger._append(message.message_id, sender_id, recipient_id, sent_time,
            deliver_at, deliver_at - sent_time, message.type(),
            getattr(order, 'order_id', None), kernel._current_causal_uid)

    def _run(self, agent_actions):
        kernel = self.kernel
        """
        Start the simulation and processing of the message queue.
        Possibility to add the optional argument agent_actions. It is a list of dictionaries corresponding
        to actions to be performed by the experimental agent (Gym Agent).

        Arguments:
            agent_actions: A list of the different actions to be performed represented in a dictionary per action.

        Returns:
          - it is a dictionnary composed of two elements:
            - "done": boolean True if the simulation is done, else False. It is true when simulation reaches end_time or when the message queue is empty.
            - "results": it is the raw_state returned by the gym experimental agent, contains data that will be formated in the gym environement to formulate state, reward, info etc.. If
               there is no gym experimental agent, then it is None.
        """
        if agent_actions is not None:
            exp_agent, action_list = agent_actions
            exp_agent.apply_actions(action_list)
        while not kernel.messages.empty() and kernel.current_time and (kernel.current_time <= kernel.stop_time):
            kernel.current_time, sender_id, recipient_id, message = heapq.heappop(kernel.messages.queue)
            assert kernel.current_time is not None
            if kernel.ttl_messages % 100000 == 0:
                if logger.isEnabledFor(20):
                    logger.info('--- Simulation time: {}, messages processed: {:,}, wallclock elapsed: {:.2f}s ---'.format(fmt_ts(kernel.current_time), kernel.ttl_messages, (datetime.now() - kernel.event_queue_wall_clock_start).total_seconds()))
            if kernel.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('--- Kernel Event Queue pop ---')
                if logger.isEnabledFor(10):
                    logger.debug('Kernel handling {} message for agent {} at time {}'.format(message.type(), recipient_id, kernel.current_time))
            kernel.ttl_messages += 1
            kernel.current_agent_additional_delay = 0
            if isinstance(message, WakeupMsg):
                if kernel.agent_current_times[recipient_id] > kernel.current_time:
                    heapq.heappush(kernel.messages.queue, (kernel.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if kernel.show_trace_messages:
                        if logger.isEnabledFor(10):
                            logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
                    continue
                kernel.agent_current_times[recipient_id] = kernel.current_time
                kernel._current_causal_uid = message.message_id
                kernel._deliver_seq_by_key[message.message_id, recipient_id] = kernel._deliver_seq
                kernel._deliver_seq += 1
                ledger = kernel._msg_ledger
                ledger._append(message.message_id, recipient_id, recipient_id, None, kernel.current_time, 0, 'AGENT_WAKEUP', None, None)
                wakeup_result = kernel.agents[recipient_id].wakeup(kernel.current_time)
                kernel.agent_current_times[recipient_id] += kernel.agent_computation_delays[recipient_id] + kernel.current_agent_additional_delay
                if kernel.show_trace_messages:
                    if logger.isEnabledFor(10):
                        logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
                if wakeup_result != None:
                    return {'done': False, 'result': wakeup_result}
            else:
                if kernel.agent_current_times[recipient_id] > kernel.current_time:
                    heapq.heappush(kernel.messages.queue, (kernel.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if kernel.show_trace_messages:
                        if logger.isEnabledFor(10):
                            logger.debug('Agent in future: message requeued for {}'.format(fmt_ts(kernel.agent_current_times[recipient_id])))
                    continue
                kernel.agent_current_times[recipient_id] = kernel.current_time
                if isinstance(message, MessageBatch):
                    messages = message.messages
                    for message in messages:
                        self._receive(kernel, sender_id, recipient_id, message)
                else:
                    self._receive(kernel, sender_id, recipient_id, message)
        if kernel.messages.empty():
            if logger.isEnabledFor(10):
                logger.debug('--- Kernel Event Queue empty ---')
        if kernel.current_time and kernel.current_time > kernel.stop_time:
            if logger.isEnabledFor(10):
                logger.debug('--- Kernel Stop Time surpassed ---')
        if len(kernel.gym_agents) > 0:
            kernel.gym_agents[0].update_raw_state()
            return {'done': True, 'result': kernel.gym_agents[0].get_raw_state()}
        else:
            return {'done': True, 'result': None}

    def _send(self, sender_id, recipient_id, message, delay):
        kernel = self.kernel
        """
        Called by an agent to send a message to another agent.

        The kernel supplies its own current_time (i.e. "now") to prevent possible abuse
        by agents. The kernel will handle computational delay penalties and/or network
        latency.

        Arguments:
            sender_id: ID of the agent sending the message.
            recipient_id: ID of the agent receiving the message.
            message: The ``Message`` class instance to send.
            delay: Represents an agent's request for ADDITIONAL delay (beyond the
                Kernel's mandatory computation + latency delays). Represents parallel
                pipeline processing delays (that should delay the transmission of
                messages but do not make the agent "busy" and unable to respond to new
                messages)
        """
        sent_time = kernel.current_time + kernel.agent_computation_delays[sender_id] + kernel.current_agent_additional_delay + delay
        if kernel.agent_latency_model is not None:
            latency: float = kernel.agent_latency_model.get_latency(sender_id=sender_id, recipient_id=recipient_id)
            deliver_at = sent_time + int(latency)
            if kernel.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('Kernel applied latency {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, kernel.current_agent_additional_delay, delay, kernel.agents[sender_id].name, kernel.agents[recipient_id].name, fmt_ts(deliver_at)))
        else:
            latency = kernel.agent_latency[sender_id][recipient_id]
            noise = kernel.random_state.choice(len(kernel.latency_noise), p=kernel.latency_noise)
            deliver_at = sent_time + int(latency + noise)
            if kernel.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('Kernel applied latency {}, noise {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, noise, kernel.current_agent_additional_delay, delay, kernel.agents[sender_id].name, kernel.agents[recipient_id].name, fmt_ts(deliver_at)))
        heapq.heappush(kernel.messages.queue, (deliver_at, sender_id, recipient_id, message))
        if isinstance(message, MessageBatch):
            _ledger_msgs = message.messages
            for _lm in _ledger_msgs:
                self._record_send(kernel, _lm, sender_id, recipient_id, sent_time, deliver_at)
        else:
            self._record_send(kernel, message, sender_id, recipient_id, sent_time, deliver_at)
        if kernel.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('Sent time: {}, current time {}, computation delay {}'.format(sent_time, fmt_ts(kernel.current_time), kernel.agent_computation_delays[sender_id]))
            if logger.isEnabledFor(10):
                logger.debug('Message queued: {}'.format(message))

    def _set_wakeup(self, sender_id, requested_time):
        kernel = self.kernel
        """
        Called by an agent to receive a "wakeup call" from the kernel at some requested
        future time.

        NOTE: The agent is responsible for maintaining any required state; the kernel
        will not supply any parameters to the ``wakeup()`` call.

        Arguments:
            sender_id: The ID of the agent making the call.
            requested_time: Defaults to the next possible timestamp.  Wakeup time cannot
            be the current time or a past time.
        """
        if requested_time is None:
            requested_time = kernel.current_time + 1
        if kernel.current_time and requested_time < kernel.current_time:
            raise ValueError('set_wakeup() called with requested time not in future', 'current_time:', kernel.current_time, 'requested_time:', requested_time)
        if kernel.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('Kernel adding wakeup for agent {} at time {}'.format(sender_id, fmt_ts(requested_time)))
        heapq.heappush(kernel.messages.queue, (requested_time, sender_id, sender_id, WakeupMsg()))

class CanonicalKernel(IncumbentKernel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.messages = FlatHeap()
        self._msg_ledger = ColumnLedger()
        self._canonical_scheduler = CanonicalScheduler(self)

    def runner(self, agent_actions=None):
        return self._canonical_scheduler.run(agent_actions)

    def send_message(self, sender_id, recipient_id, message, delay=0):
        return self._canonical_scheduler.send(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        return self._canonical_scheduler.set_wakeup(sender_id, requested_time)
