"""Five fresh-process integration controls using the actual bound extension.

Prepared source only. These controls do not run a market or claim timing. Each
child owns a fresh loader cache; no counterfeit successful native module is used.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent
CASES = (
    "install_context_normal_restore",
    "install_context_exception_restore",
    "install_nested_arm_restore",
    "loader_actual_load_once",
    "loader_exec_failure_restore",
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def child_control(case, extension_path, runtime_path):
    if case not in CASES:
        raise ValueError("unknown integration case: " + case)
    sys.path.insert(0, str(runtime_path.resolve()))
    from bootstrap import activate
    activate()
    import importlib.machinery
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_fork.config import ScenarioLatencyModel
    import original_canonical_engine as original
    import matching_python_schedule as matching
    import scheduler_loader as loader
    import scheduler_installation as installation
    from optimizations import scalar_latency

    extension_path = extension_path.resolve()
    deployment_path = HERE / "DEPLOYMENT.json"
    deployment = json.loads(deployment_path.read_text())
    bound_path = (HERE / deployment["extension_path"]).resolve()
    assert extension_path == bound_path and extension_path.is_file()
    assert sha(extension_path) == deployment["extension_sha256"]
    assert extension_path.stat().st_size == deployment["extension_bytes"]
    assert loader._module is None and loader._receipt is None and loader._load_count == 0
    assert "native_canonical_schedule" not in sys.modules
    old_kernel, old_latency = abides.Kernel, ScenarioLatencyModel.get_latency
    assert old_kernel is Kernel

    def restored():
        assert abides.Kernel is old_kernel
        assert ScenarioLatencyModel.get_latency is old_latency

    if case == "loader_exec_failure_restore":
        class NativeExecFailure(BaseException):
            pass
        original_exec = importlib.machinery.ExtensionFileLoader.exec_module
        calls = []

        def failing_exec(self, module):
            assert isinstance(self, importlib.machinery.ExtensionFileLoader)
            assert self.name == "native_canonical_schedule"
            assert Path(self.path).resolve() == extension_path
            assert Path(module.__file__).resolve() == extension_path
            original_exec(self, module)
            calls.append((self.name, str(Path(self.path).resolve()), type(self).__name__))
            raise NativeExecFailure("integration actual extension exec failed")

        importlib.machinery.ExtensionFileLoader.exec_module = failing_exec
        try:
            try:
                with installation.enabled("native"):
                    raise AssertionError("failed loader must not enter context body")
            except NativeExecFailure as error:
                assert error.args == ("integration actual extension exec failed",)
            else:
                raise AssertionError("actual native exec failure missing")
        finally:
            importlib.machinery.ExtensionFileLoader.exec_module = original_exec
        assert len(calls) == 1
        assert "native_canonical_schedule" not in sys.modules
        assert loader._module is None and loader._receipt is None and loader._load_count == 0
        restored()
        return {"case": case, "passed": True, "actual_extension_loader_calls": 1,
            "actual_extension_exec_completed_before_controlled_failure": True,
            "controlled_failure_is_success": False, "context_body_entered": False,
            "native_sys_modules_removed": True, "loader_cache_clear": True,
            "kernel_binding_restored": True, "latency_binding_restored": True,
            "extension_sha256": deployment["extension_sha256"]}

    native = loader.load_scheduler()
    assert sys.modules["native_canonical_schedule"] is native
    assert Path(native.__file__).resolve() == extension_path
    assert isinstance(native.__spec__.loader, importlib.machinery.ExtensionFileLoader)
    assert native.IncumbentKernel is original.IncumbentKernel is matching.IncumbentKernel is Kernel
    receipt_before = loader.native_receipt()
    assert receipt_before["native_load_count"] == 1
    assert receipt_before["extension_path"] == str(extension_path)
    assert receipt_before["extension_sha256"] == deployment["extension_sha256"]
    assert receipt_before["source_receipt_sha256"] == deployment["source_receipt_sha256"]
    assert receipt_before["build_receipt_sha256"] == deployment["build_receipt_sha256"]
    assert receipt_before["runtime_pins_sha256"] == deployment["runtime_pins_sha256"]
    assert receipt_before["abi"] == deployment["abi"]
    assert receipt_before["runtime_source_compilation"] is False
    assert receipt_before["per_episode_native_hash_audit"] is False

    if case == "loader_actual_load_once":
        assert loader.load_scheduler() is native
        assert loader.load_scheduler() is native
        assert loader.native_receipt() == receipt_before
        copied = loader.native_receipt()
        copied["native_load_count"] = -1
        assert loader.native_receipt() == receipt_before
        restored()
    elif case == "install_context_normal_restore":
        with installation.enabled("native") as extractor:
            assert callable(extractor)
            assert abides.Kernel is native.CanonicalKernel
            assert ScenarioLatencyModel.get_latency is scalar_latency
        restored()
    elif case == "install_context_exception_restore":
        class BodyFailure(BaseException):
            pass
        try:
            with installation.enabled("native"):
                assert abides.Kernel is native.CanonicalKernel
                assert ScenarioLatencyModel.get_latency is scalar_latency
                raise BodyFailure("integration body failed", 17)
        except BodyFailure as error:
            assert error.args == ("integration body failed", 17)
        else:
            raise AssertionError("context body failure missing")
        restored()
    elif case == "install_nested_arm_restore":
        with installation.enabled("native"):
            assert abides.Kernel is native.CanonicalKernel
            assert ScenarioLatencyModel.get_latency is scalar_latency
            with installation.enabled("matching_python"):
                assert abides.Kernel is matching.CanonicalKernel
                with installation.enabled("original_canonical"):
                    assert abides.Kernel is original.CanonicalKernel
                    assert ScenarioLatencyModel.get_latency is scalar_latency
                assert abides.Kernel is matching.CanonicalKernel
            assert abides.Kernel is native.CanonicalKernel
            assert ScenarioLatencyModel.get_latency is scalar_latency
        restored()
    else:
        raise AssertionError("unimplemented integration case")
    assert loader.native_receipt() == receipt_before
    assert loader._module is native and loader._load_count == 1
    return {"case": case, "passed": True, "fresh_process": True,
        "actual_extension_loader": type(native.__spec__.loader).__name__,
        "native_load_count": 1, "original_kernel_owner": True,
        "kernel_binding_restored": True, "latency_binding_restored": True,
        "extension_sha256": deployment["extension_sha256"],
        "build_receipt_sha256": deployment["build_receipt_sha256"],
        "source_receipt_sha256": deployment["source_receipt_sha256"]}


def integration_probe(case, native, np, extension_path, runtime_path):
    """Native/np are parent controls' owners; child deliberately starts afresh."""
    if case not in CASES:
        raise ValueError("unknown integration case: " + case)
    extension_path, runtime_path = Path(extension_path).resolve(), Path(runtime_path).resolve()
    assert Path(native.__file__).resolve() == extension_path
    source_before = sha(__file__)
    with TemporaryDirectory(prefix="t3-scheduler-integration-") as directory:
        result_path = Path(directory) / "RESULT.json"
        argv = [sys.executable, "-B", str(Path(__file__).resolve()),
            "--integration-child", case, "--extension", str(extension_path),
            "--runtime", str(runtime_path), "--out", str(result_path)]
        completed = subprocess.run(argv, capture_output=True, text=True, timeout=60)
        if completed.returncode != 0:
            raise AssertionError("fresh integration child failed: " + case + ": " +
                                 completed.stderr[-4000:])
        assert completed.stdout == "" and result_path.is_file()
        report = json.loads(result_path.read_text())
        assert report["schema"] == "t3-native-canonical-scheduler-integration-child-v3"
        assert report["case"] == case and report["passed"] is True
        assert report["candidate_source_sha256"] == source_before
        assert report["candidate_executed_market"] is False
        witness = report["witness"]
        assert witness["case"] == case and witness["passed"] is True
    assert sha(__file__) == source_before
    return [witness]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--integration-child", choices=CASES, required=True)
    parser.add_argument("--extension", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("fresh integration child output required")
    before = sha(__file__)
    witness = child_control(args.integration_child, args.extension, args.runtime)
    assert sha(__file__) == before
    report = {"schema": "t3-native-canonical-scheduler-integration-child-v3",
        "case": args.integration_child, "passed": True, "witness": witness,
        "candidate_source_sha256": before, "candidate_executed_market": False,
        "timing_claim": False}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
