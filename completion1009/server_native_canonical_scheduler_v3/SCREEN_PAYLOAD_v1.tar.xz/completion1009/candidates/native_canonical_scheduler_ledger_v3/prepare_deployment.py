"""Build-only copy/ABI binding. No native import or simulation occurs here."""
import argparse
import json
from pathlib import Path
import shutil

from provenance import HERE, abi, sha, verify_runtime, verify_sources


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    args = parser.parse_args()
    if (HERE / "native").exists() or (HERE / "DEPLOYMENT.json").exists():
        raise ValueError("fresh scheduler deployment destination required")
    sources = verify_sources()
    runtime = verify_runtime(args.runtime)
    receipt_path = args.build.resolve() / "BUILD_RECEIPT.json"
    build = json.loads(receipt_path.read_text())
    if (build.get("schema") != "t3-native-canonical-scheduler-ledger-build-v3"
            or build.get("candidate") != HERE.name or build.get("build_succeeded") is not True
            or build.get("abi") != abi() or build.get("candidate_sources") != sources
            or build.get("runtime") != runtime
            or build.get("source_receipt_sha256") != sha(HERE / "SOURCE_PREPARATION_RECEIPT_v3.json")
            or build.get("compile_spec_sha256") != sha(HERE / "compile_spec.json")
            or build.get("pyx_sha256") != sha(HERE / "native_canonical_schedule.pyx")
            or build.get("pxd_sha256") != sha(HERE / "native_canonical_schedule.pxd")
            or build.get("control_probe_source_sha256") != sha(HERE / "scheduler_owner_probe.pyx")
            or build.get("extension_build_count") != 2 or build.get("build_invocations") != 1
            or build.get("production_extension_owners") != 1 or build.get("control_probe_extensions") != 1):
        raise ValueError("scheduler build/source/runtime/ABI binding differs")
    expected_name = "native_canonical_schedule" + build["abi"]["ext_suffix"]
    relative = Path(build["extension"]["path"])
    if relative != Path("native") / expected_name:
        raise ValueError("scheduler extension path differs")
    extension = args.build.resolve() / relative
    if extension.stat().st_size != build["extension"]["bytes"] or sha(extension) != build["extension"]["sha256"]:
        raise ValueError("scheduler built extension bytes differ")
    expected_probe = "scheduler_owner_probe" + build["abi"]["ext_suffix"]
    probe_row = build.get("control_probe")
    if (type(probe_row) is not dict or probe_row.get("control_only") is not True
            or Path(probe_row.get("path", "")) != Path("native") / expected_probe):
        raise ValueError("scheduler control-only probe path differs")
    probe = args.build.resolve() / probe_row["path"]
    if probe.stat().st_size != probe_row["bytes"] or sha(probe) != probe_row["sha256"]:
        raise ValueError("scheduler built control probe bytes differ")
    generated = build.get("generated_c")
    if type(generated) is not dict or len(generated) != 2:
        raise ValueError("scheduler generated-C receipt missing")
    for path, digest in generated.items():
        relative_c = Path(path)
        if relative_c.is_absolute() or ".." in relative_c.parts or relative_c.suffix != ".c":
            raise ValueError("scheduler generated-C receipt path differs")
        if sha(args.build.resolve() / relative_c) != digest:
            raise ValueError("scheduler generated C differs")
    (HERE / "native").mkdir()
    destination = HERE / "native" / expected_name
    shutil.copyfile(extension, destination)
    if sha(destination) != build["extension"]["sha256"]:
        raise ValueError("scheduler deployed extension bytes differ")
    probe_destination = HERE / "native" / expected_probe
    shutil.copyfile(probe, probe_destination)
    if sha(probe_destination) != probe_row["sha256"]:
        raise ValueError("scheduler deployed control probe bytes differ")
    deployment = {"schema": "t3-native-canonical-scheduler-ledger-deployment-v3",
        "candidate": HERE.name, "abi": build["abi"], "extension_path": "native/" + expected_name,
        "extension_sha256": sha(destination), "extension_bytes": destination.stat().st_size,
        "control_probe": {"path": "native/" + expected_probe, "bytes": probe_destination.stat().st_size,
                          "sha256": sha(probe_destination), "control_only": True},
        "extension_build_count": 2, "build_invocations": 1,
        "production_extension_owners": 1, "control_probe_extensions": 1,
        "control_probe_source_sha256": build["control_probe_source_sha256"],
        "build_receipt_sha256": sha(receipt_path),
        "source_receipt_sha256": sha(HERE / "SOURCE_PREPARATION_RECEIPT_v3.json"),
        "runtime_pins_sha256": runtime["runtime_pins_sha256"],
        "compile_spec_sha256": sha(HERE / "compile_spec.json"),
        "pyx_sha256": build["pyx_sha256"], "pxd_sha256": build["pxd_sha256"],
        "candidate_imported": False, "market_executed": False, "timing_claim": False}
    (HERE / "DEPLOYMENT.json").write_text(json.dumps(deployment, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
