"""Linux-only latency equality, complete MT624 and fallback controls."""
import struct
import tempfile
from pathlib import Path
from types import MethodType
import numpy as np
from abides_fork.config import ScenarioLatencyModel
from exact_latency import select_latency, scalar_latency


def state_bytes(rng):
    name, keys, position, has_gauss, gauss = rng.get_state()
    return (name, keys.tobytes(), position, has_gauss, struct.pack('!d', gauss))


def run_controls(engine=None):
    rows = []
    specs = [
        ('deterministic_half_even', {'model':'deterministic','params':{'mean_ns':1.5}}, {}),
        ('deterministic_negative', {'model':'deterministic','params':{'mean_ns':-1.5,'min_ns':-3}}, {}),
        ('unknown_constant', {'model':'unknown','params':{'mean_ns':2.5}}, {}),
        ('uniform', {'model':'uniform','params':{'min_ns':0,'max_ns':2000}}, {}),
        ('uniform_equal_still_draws', {'model':'uniform','params':{'min_ns':5,'max_ns':5}}, {}),
        ('lognormal', {'model':'log_normal','params':{'mean_ns':500,'sigma':1.2,'max_ns':2000}}, {}),
        ('lognormal_zero_sigma_still_draws', {'model':'log_normal','params':{'mean_ns':3,'sigma':0}}, {}),
        ('pareto', {'model':'pareto','params':{'min_ns':1,'max_ns':2000,'alpha':1.5}}, {}),
        ('pareto_zero_base', {'model':'pareto','params':{'min_ns':0,'max_ns':2000}}, {}),
        ('lognormal_overflow', {'model':'log_normal','params':{'mean_ns':1,'sigma':1}}, {'_mu':710.0}),
        ('pareto_overflow', {'model':'pareto','params':{'min_ns':1,'max_ns':2000,'alpha':1e-300}}, {}),
    ]
    for name, spec, changed in specs:
        for position in (622,623,624):
            for cached in (None,0.0,-0.0,-1.2345):
                originals = []
                for _ in range(3 if engine is not None else 2):
                    rng=np.random.RandomState(307)
                    state=list(rng.get_state()); state[2]=position
                    if cached is not None: state[3]=1;state[4]=cached
                    rng.set_state(tuple(state))
                    model=ScenarioLatencyModel(3,spec,rng)
                    for field,value in changed.items():setattr(model,field,value)
                    originals.append(model)
                left,right=originals[:2]
                if engine is not None:
                    from types import SimpleNamespace
                    compiled=engine.ChainScheduler(SimpleNamespace(agent_latency_model=originals[2]),engine.ColumnLedger()).control_exact_latency
                selected=select_latency(right)
                assert selected.__func__ is scalar_latency
                if engine is not None:
                    before_native=state_bytes(originals[2].random_state)
                    assert compiled(1,1)==0
                    assert state_bytes(originals[2].random_state)==before_native
                before=state_bytes(right.random_state)
                assert selected(1,1)==left.get_latency(1,1)==0
                assert state_bytes(right.random_state)==before
                for i in range(700):
                    left_value=left.get_latency(i%3,(i+1)%3)
                    assert left_value==selected(i%3,(i+1)%3)
                    if engine is not None:
                        assert compiled(i%3,(i+1)%3)==left_value
                        assert state_bytes(originals[2].random_state)==state_bytes(left.random_state)
                    assert state_bytes(left.random_state)==state_bytes(right.random_state)
                rows.append({'case':name+':'+str(position)+':'+repr(cached),'calls':700,'passed':True})
    def model():
        return ScenarioLatencyModel(3,{'model':'uniform','params':{'min_ns':0,'max_ns':3}},np.random.RandomState(307))
    unsupported = [('_min_ns',None),('_min_ns',np.float64(0)),('_min_ns',np.array([0.])),
        ('_min_ns',float('nan')),('_max_ns',float('inf')),('_min_ns',5.0)]
    for field,value in unsupported:
        current=model();setattr(current,field,value)
        before=state_bytes(current.random_state);chosen=select_latency(current)
        assert chosen.__func__ is ScenarioLatencyModel.get_latency
        assert state_bytes(current.random_state)==before
        rows.append({'case':'refuse:'+field+':'+type(value).__name__+':'+repr(value),'passed':True})
    for distribution,field,value in (('log_normal','_sigma',-1.0),('pareto','_alpha',0.0)):
        current=model();current._model=distribution;setattr(current,field,value)
        assert select_latency(current).__func__ is ScenarioLatencyModel.get_latency
        rows.append({'case':'refuse:'+distribution+field,'passed':True})
    current=model();current.get_latency=MethodType(lambda self,sender_id,recipient_id:17,current)
    assert select_latency(current).__func__ is current.get_latency.__func__
    assert select_latency(current)(0,1)==17
    rows.append({'case':'preserve_custom_instance_callback','passed':True})
    class Custom(ScenarioLatencyModel):
        pass
    current=Custom(3,{},np.random.RandomState(307))
    assert select_latency(current).__func__ is ScenarioLatencyModel.get_latency
    rows.append({'case':'preserve_custom_class','passed':True})
    import abides_fork.config as config_module
    callback=ScenarioLatencyModel.get_latency
    def refusal(name,obj,field,value):
        old=getattr(obj,field)
        current=model()
        try:
            setattr(obj,field,value)
            before=state_bytes(current.random_state)
            chosen=select_latency(current)
            assert chosen.__func__ is current.get_latency.__func__
            assert state_bytes(current.random_state)==before
        finally:
            setattr(obj,field,old)
        assert select_latency(model()).__func__ is scalar_latency
        rows.append({'case':name,'passed':True})
    refusal('changed_latency_code',callback,'__code__',(lambda self,sender_id,recipient_id:17).__code__)
    refusal('changed_latency_defaults',callback,'__defaults__',(None,))
    refusal('changed_latency_keyword_defaults',callback,'__kwdefaults__',{'unexpected':1})
    class ChangedConstructor:
        def __init__(self):
            return __class__
    refusal('changed_constructor_code',ScenarioLatencyModel.__init__,'__code__',ChangedConstructor.__init__.__code__)
    refusal('changed_constructor_defaults',ScenarioLatencyModel.__init__,'__defaults__',(None,))
    refusal('changed_config_numpy_binding',config_module,'np',object())
    refusal('changed_config_class_export',config_module,'ScenarioLatencyModel',type('Foreign',(),{}))
    refusal('malformed_constructor',ScenarioLatencyModel,'__init__',object())
    assert len(rows)==150
    return {'schema':'t3-classic-scalar-latency-controls-v1','all_passed':True,'cases':rows,
        'full_MT624_each_draw':True,'per_case_random_calls':700,'compiled_scalar_path_tested':engine is not None,'market_executed':False,
        'model_mutated':False,'rankable':False,'speed_claim':False}


def run_source_controls():
    import types
    import observer
    import observer_domain as domain
    import contracts
    from abides_fork import agents
    rows=[]
    assert domain.authenticate_loaded()
    def restored_case(name,obj,field,value):
        old=getattr(obj,field)
        try:
            setattr(obj,field,value)
            assert not domain.authenticate_loaded()
        finally:
            setattr(obj,field,old)
        assert domain.authenticate_loaded()
        rows.append({'case':name,'passed':True})
    restored_case('changed_module_source_path',contracts,'__file__',str(Path(contracts.__file__).with_name('wrong.py')))
    restored_case('nonstring_module_source_path',contracts,'__file__',Path(contracts.__file__))
    restored_case('changed_function_code',contracts.validate_scenario,'__code__',(lambda x:None).__code__)
    restored_case('changed_function_defaults',contracts.validate_scenario,'__defaults__',(None,))
    restored_case('replaced_strategy_export',agents,'NoiseTrader',type('NoiseTrader',(),{}))
    registry=agents.AGENT_REGISTRY
    restored_case('replaced_registry',agents,'AGENT_REGISTRY',{})
    assert agents.AGENT_REGISTRY is registry
    original_root=observer.__file__
    with tempfile.TemporaryDirectory(dir='/output') as scratch:
        scratch=Path(scratch)
        p=scratch/'contracts.py';data=Path(contracts.__file__).read_bytes();p.write_bytes(data)
        fake=types.SimpleNamespace(__file__=str(p))
        try:
            observer.__file__=str(scratch/'observer.py')
            images={};first=domain._source_image(fake,images)
            assert domain._source_image(fake,images) is first
            p.write_bytes(data.replace(b'Deterministic',b'DeterministiC',1))
            assert len(p.read_bytes())==len(data) and p.read_bytes()!=data
            try:domain._source_image(fake,{})
            except ValueError:pass
            else:raise AssertionError('fresh same-length mutation was accepted')
            p.write_bytes(data)
            assert domain._source_image(fake,{}) is first
            rows.append({'case':'fresh_same_length_mutation_detected','passed':True})
            fake.__file__=str(scratch/'wrong.py')
            try:domain._source_image(fake,images)
            except ValueError:pass
            else:raise AssertionError('changed string reused stale resolved path')
            rows.append({'case':'same_call_changed_path_rechecked','passed':True})
        finally:
            observer.__file__=original_root
    assert domain.authenticate_loaded() and len(rows)==8
    return {'all_passed':True,'cases':rows,'market_executed':False,'bindings_restored':True,'rankable':False}


def run_send_controls(engine):
    from types import SimpleNamespace
    from queue import PriorityQueue
    from abides_core.kernel import Kernel
    from abides_core.message import Message
    from abides_markets.messages.market import MarketHoursMsg
    rows=[]
    old_counter=Message._Message__message_id_counter
    try:
        specs=[('deterministic',{'mean_ns':1.5}),('uniform',{'min_ns':100,'max_ns':2000}),
            ('log_normal',{'mean_ns':500,'sigma':1.2,'max_ns':2000}),
            ('pareto',{'min_ns':1,'max_ns':2000,'alpha':1.5}),
            ('unknown',{'mean_ns':2.5}),('uniform',{'min_ns':5,'max_ns':5}),
            ('log_normal',{'mean_ns':3,'sigma':0})]
        for index,(name,params) in enumerate(specs):
            for clock in (1612517400000000123,np.int64(1612517400000000123)):
                a=ScenarioLatencyModel(3,{'model':name,'params':params},np.random.RandomState(991))
                b=ScenarioLatencyModel(3,{'model':name,'params':params},np.random.RandomState(991))
                def kernel(model):
                    return SimpleNamespace(agent_latency_model=model,current_time=clock,
                        agent_computation_delays=[0,1,2],current_agent_additional_delay=3,
                        show_trace_messages=False,_current_causal_uid=11,_msg_ledger=[],messages=PriorityQueue())
                original,native=kernel(a),kernel(b)
                ledger=engine.ColumnLedger();scheduler=engine.ChainScheduler(native,ledger)
                for i in range(80):
                    src,dst=i%3,(i+1)%3 if i%7 else i%3
                    message=MarketHoursMsg(10,20)
                    handle=scheduler.control_new_hours(message.message_id,10,20)
                    try:
                        Kernel.send_message(original,src,dst,message,delay=i%4)
                        scheduler.send(src,dst,handle,delay=i%4)
                    finally:
                        scheduler.control_release_message(handle)
                    assert state_bytes(a.random_state)==state_bytes(b.random_state)
                expected=[tuple(row[key] for key in ('message_id','src_id','dst_id','t_send_ns','t_recv_ns',
                    'latency_ns','msg_type','order_id','causal_parent')) for row in original._msg_ledger]
                assert list(zip(*ledger.columns))==expected
                queue=list(original.messages.queue)
                native_rows=scheduler.heap.cold_rows({})
                assert [(t,src,dst,msg.message_id) for t,(src,dst,msg) in queue]==[(t,src,dst,msg.message_id) for t,src,dst,msg in native_rows]
                assert all(type(t) is type(clock) for t,*_ in native_rows)
                rows.append({'case':str(index)+':'+name+':'+type(clock).__name__,'sends':80,'passed':True})
    finally:
        Message._Message__message_id_counter=old_counter
    assert len(rows)==14
    return {'all_passed':True,'cases':rows,'full_MT624_each_send':True,'bindings_restored':True,
        'market_executed':False,'rankable':False,'speed_claim':False}
