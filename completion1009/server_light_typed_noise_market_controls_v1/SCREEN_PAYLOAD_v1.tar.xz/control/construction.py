"""Actual Docker construction driver; retain all partial failure outputs."""
import json
import os
from pathlib import Path
import subprocess
import sys
from common import IMAGE_ROOT, CANDIDATE, GENERATOR, sha, inventory, write
ROOT = Path(IMAGE_ROOT)


def main():
    candidate = ROOT / CANDIDATE
    output = ROOT / "construction"; output.mkdir()
    result = {"schema": "t3-light-typed-noise-market-real-construction-v1", "all_passed": False,
        "build_stage_resources_are_not_official_timing": True, "commands": [],
        "participant_imported": False, "market_executed": False, "rankable": False}
    commands = (("compiler-version", ["gcc", "--version"], 30),
        ("compiler-target", ["gcc", "-dumpmachine"], 30),
        ("libc-version", ["ldd", "--version"], 30),
        ("translation", [sys.executable, "-B", str(candidate / "translate_native_preflight.py"),
            "--runtime", str(candidate / "runtime"), "--out", str(candidate / "translation")], 900),
        ("native-build", [sys.executable, "-B", str(candidate / "build_native.py"),
            "--runtime", str(candidate / "runtime"), "--out", str(candidate / "build")], 1200),
        ("schema-build", [sys.executable, "-B", str(ROOT / "control/prepare_build_schema_v1.py"),
            "--runtime", str(candidate / "runtime"), "--generator", str(ROOT / GENERATOR),
            "--receipt-dir", str(ROOT / "schema-build")], 180))
    try:
        for label, command, timeout in commands:
            path = output / (label + ".log")
            with path.open("xb") as log:
                try:
                    process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
                    row = {"label": label, "command": command, "returncode": process.returncode, "timed_out": False}
                except BaseException as error:
                    row = {"label": label, "command": command, "returncode": None,
                        "timed_out": isinstance(error, subprocess.TimeoutExpired), "failure": {"type": type(error).__name__, "message": str(error)}}
            row["log"] = {"bytes": path.stat().st_size, "sha256": sha(path)}
            result["commands"].append(row)
            if row["returncode"] != 0: raise RuntimeError("actual construction command failed: " + label)
        result["all_passed"] = True
    except BaseException as error:
        result["failure"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        result["native_partial_inventory"] = {name: inventory(candidate / name) if (candidate / name).exists() else {} for name in ("translation", "build")}
        result["ambient_flags"] = {name: os.environ.get(name, "") for name in ("CFLAGS", "CPPFLAGS", "LDFLAGS")}
        write(output / "CONSTRUCTION_RESULT.json", result)
    # The construction stage deliberately succeeds as a data carrier, so the
    # host can retain failed translation/C/object/ELF/log files and reject them.
    # Only host inspection of exact receipts can mark BUILD_READY.


if __name__ == "__main__": main()
