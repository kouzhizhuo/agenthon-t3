"""Same-process pristine source routing; untimed controls in separate children."""
import argparse
import json
from pathlib import Path
import runpy
import subprocess
import sys
from common import IMAGE_ROOT, CANDIDATE, BASELINE, ARMS, sha, write
ROOT = Path(IMAGE_ROOT)


def control(config):
    bundle = json.loads(Path(config).read_bytes())
    if (bundle.get("proof_command") != "light-typed-noise-market-six-children-and-owned-Noise-v1"
            or type(bundle.get("scenario")) is not dict or len(bundle.get("admission_scenarios", [])) != 9):
        raise ValueError("exact finite controls plus original nine-market admission roster required")
    out = Path("/output/controls"); out.mkdir()
    scenario = out / "scenario.json"; write(scenario, bundle["scenario"])
    candidate = ROOT / CANDIDATE; runtime = candidate / "runtime"
    sys.path.insert(0, str(candidate))
    from source_provenance import verify_sources, verify_runtime
    verify_sources(); verify_runtime(runtime)
    from production_cli import activate_paths
    activate_paths(runtime)
    from observer_domain import authenticate_loaded
    from arena_admission import admit
    from native_loader import load
    authenticated = authenticate_loaded()
    if not authenticated: raise ValueError("actual loaded light typed Noise market source authentication refused")
    load(candidate / "build", runtime)
    admissions = []
    for row in bundle["admission_scenarios"]:
        passed = admit(row["scenario"], runtime)
        admissions.append({"unit": row["unit"], "scenario_sha256": row["scenario_sha256"],
            "source_authenticated": authenticated, "native_admitted": passed})
    write(out / "ADMISSION.json", {"actual_loaded_sources_and_native_ELF_checked": True, "cases": admissions,
        "all_passed": all(row["native_admitted"] for row in admissions), "market_executed": False, "rankable": False})
    if not all(row["native_admitted"] for row in admissions):
        raise ValueError("one original official market outside native admission domain")
    completed = subprocess.run([sys.executable, "-B", str(candidate / "controls/controls.py"),
        "--baseline-runtime", str(ROOT / BASELINE), "--runtime", str(runtime), "--build", str(candidate / "build"),
        "--config", str(scenario), "--out", str(out / "children")], timeout=3600)
    raise SystemExit(completed.returncode)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("simulate", "simulate-batch"))
    parser.add_argument("--config"); parser.add_argument("--out")
    parser.add_argument("--batch-dir"); parser.add_argument("--out-dir")
    parser.add_argument("--mode", choices=(*ARMS, "controls"), required=True)
    args = parser.parse_args()
    if args.verb == "simulate":
        if args.config != "/input/scenario.json" or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir:
            raise ValueError("fixed single paths required")
        options = ["--config", args.config, "--out", args.out]
    else:
        if args.batch_dir != "/input/scenarios" or args.out_dir != "/output" or args.config or args.out:
            raise ValueError("fixed batch paths required")
        options = ["--batch-dir", args.batch_dir, "--out-dir", args.out_dir]
    if args.mode == "controls":
        if args.verb != "simulate": raise ValueError("single fixed control bundle required")
        control(args.config)
    if args.mode == "baseline":
        runtime = ROOT / BASELINE; source = runtime / "agent.py"
        sys.path.insert(0, str(runtime)); actual = [str(source), args.verb, *options, "--mode", "optimized"]
    else:
        source = ROOT / CANDIDATE / "production_cli.py"
        sys.path.insert(0, str(source.parent)); actual = [str(source), args.verb, *options, "--arm", args.mode]
    sys.argv = actual
    runpy.run_path(str(source), run_name="__main__")


if __name__ == "__main__": main()
