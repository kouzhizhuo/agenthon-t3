# Light V4 + typed V2.1 + owned Noise V1.1 finite Linux wrapper

This fresh wrapper uses the frozen candidate's exact source receipt, original64 baseline and the serial Linux screen infrastructure of the cold output wrapper. It is source-only preparation: no build, native import, RNG draw, market, dispatch, upload or submission occurs locally.

The Docker construction stage records translation/generated C, exact linked scalar C/header, compiler objects, ELF and schema metadata. The host verifies the installed source/build and keeps partial failures. One control container checks nine original scenario admission domains, then typed28 and three same-ELF Noise child suites (16/1565 expressions plus10 registry modes,22 cold admission cases,9 actual native lifecycle modes), then six independent ordinary/native/repeat/output-fallback markets. Only complete results permit60 serial diagnostic runs over four single units and one heterogeneous batch, with one warmup and two measured repeats for each of three arms. The settled Docker StartedAt→FinishedAt window determines throughput.

The owner lifecycle suite deliberately does not run its queue; actual full migration/property boundaries are finite checks. Direct scheduler errors/termination/partial continuation/postdraw send failures/migration error injection remain explicit untested edges. The wrapper is not full71 coverage, official submission readiness,230000 EPS or ranking evidence. The final archive requires an independent complete candidate and wrapper source review before sealing; no former ELF is reused.

This wrapper targets fresh V1.1, which fixes the original V1 seed-wrapper origin rejection. Frozen V1 and its source review are retained with a reached-scope blocker addendum; no V1 Linux PASS is claimed.
