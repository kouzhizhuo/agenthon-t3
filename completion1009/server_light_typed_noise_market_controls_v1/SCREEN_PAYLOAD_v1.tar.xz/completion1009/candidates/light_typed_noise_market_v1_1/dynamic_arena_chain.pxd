
from libc.stdint cimport uint32_t, uint64_t
from cpython.ref cimport PyObject

cdef extern from "owned_legacy.h":
    ctypedef struct t3_owned_state:
        uint32_t key[624]
        int pos
        int has_gauss
        double gauss
        int wide_high_first
        uint64_t words_consumed
        uint64_t twists
        uint64_t normal_rejections
        uint64_t integer_rejections
    double t3_legacy_normal(t3_owned_state *, double, double)
    uint64_t t3_default_int64_fill_one(t3_owned_state *, uint64_t, uint64_t)
    int t3_signbit(double)

cdef class NoiseRNGOwner:
    cdef object original_rng, original_normal, original_randint, original_get_state
    cdef object original_set_state, original_asarray, original_uint32
    cdef t3_owned_state state
    cdef bint owned
    cdef unsigned long normal_calls
    cdef unsigned long randint_calls
    cdef unsigned long handoffs
    cdef object export_failures, control_trace
    cdef object _state(self)
    cdef void _export(self) except *
    cdef object _normal(self, object mean, object scale)
    cdef object _randint(self, object high)
    cdef object _draw(self, object mean, object scale, object offset_ticks)

cdef struct OrderSlot:
    uint32_t generation
    uint32_t next_free
    uint32_t references
    PyObject *fields[13]

cdef struct MessageSlot:
    uint32_t generation
    uint32_t next_free
    uint32_t references
    unsigned int kind
    uint64_t order_handle
    PyObject *fields[7]

cdef class OrderArena:
    cdef OrderSlot **_chunks
    cdef size_t _chunks_n, _directory_n
    cdef uint32_t _slots_n, _free_head
    cdef size_t _live_n, _clones_n
    cdef OrderSlot *_index(self, uint32_t i) noexcept
    cdef void _grow(self) except *
    cdef OrderSlot *_lookup(self, object handle) except NULL
    cdef object _allocate(self)
    cdef object _get(self, object handle, unsigned int field)
    cdef void _set(self, object handle, unsigned int field, object value) except *
    cdef void _retain(self, object handle) except *
    cdef void _release(self, object handle) except *
    cdef object _new_limit(self, agent_id, time_placed, symbol, quantity, side, limit_price, order_id=*, is_hidden=*, is_price_to_comply=*, insert_by_id=*, is_post_only=*, tag=*)
    cdef object _clone(self, object handle)
    cdef object _format(self, object handle)

    cdef uint64_t _checked_handle(self, object handle) except? 0
    cdef OrderSlot *_lookup_u(self, uint64_t handle) except NULL
    cdef uint64_t _allocate_u(self) except? 0
    cdef object _get_u(self, uint64_t handle, unsigned int field)
    cdef void _set_u(self, uint64_t handle, unsigned int field, object value) except *
    cdef void _retain_u(self, uint64_t handle) except *
    cdef void _release_u(self, uint64_t handle) except *
    cdef uint64_t _new_limit_u(self, agent_id,time_placed,symbol,quantity,side,limit_price,order_id=*,is_hidden=*,is_price_to_comply=*,insert_by_id=*,is_post_only=*,tag=*) except? 0
    cdef uint64_t _clone_u(self, uint64_t handle) except? 0
    cdef object _format_u(self, uint64_t handle)

cdef class MessageArena:
    cdef MessageSlot **_chunks
    cdef size_t _chunks_n, _directory_n
    cdef uint32_t _slots_n, _free_head
    cdef size_t _live_n, _created_n
    cdef public OrderArena orders
    cdef MessageSlot *_index(self, uint32_t i) noexcept
    cdef void _grow(self) except *
    cdef MessageSlot *_lookup(self, object handle) except NULL
    cdef object _get(self, object handle, unsigned int field)
    cdef unsigned int _kind(self, object handle) except? 0
    cdef object _id(self, object handle)
    cdef uint64_t _order_u(self, object handle) except? 0
    cdef object _order(self, object handle)
    cdef object _name(self, object handle)
    cdef object _new_u(self, unsigned int kind, uint64_t order=*,a=*,b=*,c=*,d=*,e=*,f=*,message_id=*)
    cdef object _new(self, unsigned int kind, order=*, a=*,b=*,c=*,d=*,e=*,f=*,message_id=*)
    cdef void _retain(self, object handle) except *
    cdef void _release(self, object handle) except *

cdef struct DeliveryRow:
    PyObject *keys[4]
    uint64_t handle

cdef class DeliveryHeap:
    cdef public MessageArena arena
    cdef DeliveryRow *_rows
    cdef size_t _size, _capacity
    cdef bint _before(self, DeliveryRow *left, DeliveryRow *right) except *
    cdef void _push(self,when,src,dst,handle) except *
    cdef object _pop(self)

cdef void _observe_order(object owner, object event, OrderArena arena, uint64_t handle) except *

cdef class FlatHeap:
    cdef public object queue
cdef class ColumnLedger:
    cdef list c0, c1, c2, c3, c4, c5, c6, c7, c8
    cdef public object columns
    cdef void _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns, latency_ns, msg_type, order_id, causal_parent) except *
cdef class ChainScheduler:
    cdef object _noise_boundary
    cdef public OrderArena orders
    cdef public MessageArena messages
    cdef public DeliveryHeap heap
    cdef object kernel
    cdef ColumnLedger ledger
    cdef object _deliver_wakeup(self, recipient, current_time)
    cdef object _deliver_message(self, recipient, current_time, sender_id, message)
    cdef object _run(self, agent_actions=*)
    cdef object _send(self, sender_id, recipient_id, message, delay=*)
    cdef object _set_wakeup(self, sender_id, requested_time=*)

cdef class NativeTrader:
    cdef NoiseRNGOwner _noise_rng
    cdef NoiseRNGOwner _noise_record
    cdef object _noise_boundary
    cdef void _export_noise(self) except *
    cdef OrderArena _orders
    cdef MessageArena _messages
    cdef ChainScheduler _scheduler
    cdef object _slot_MKT_BUY
    cdef object _slot_MKT_SELL
    cdef object _slot__mid_history
    cdef object _slot_basket_size
    cdef object _slot_book
    cdef object _slot_current_time
    cdef object _slot_daily_close_price
    cdef object _slot_depth_levels
    cdef object _slot_exchange_id
    cdef object _slot_exchange_ts
    cdef object _slot_executed_orders
    cdef object _slot_first_wake
    cdef object _slot_holdings
    cdef object _slot_id
    cdef object _slot_interval_ns
    cdef object _slot_kernel
    cdef object _slot_known_asks
    cdef object _slot_known_bids
    cdef object _slot_last_trade
    cdef object _slot_log
    cdef object _slot_log_events
    cdef object _slot_log_orders
    cdef object _slot_log_to_file
    cdef object _slot_lookback
    cdef object _slot_mkt_close
    cdef object _slot_mkt_closed
    cdef object _slot_mkt_open
    cdef object _slot_name
    cdef object _slot_nav_diff
    cdef object _slot_oracle
    cdef object _slot_order_size_mean
    cdef object _slot_order_size_std
    cdef object _slot_orders
    cdef object _slot_price_offset_ticks
    cdef object _slot_random_state
    cdef object _slot_reference_price
    cdef object _slot_sigma_n
    cdef object _slot_size_per_level
    cdef object _slot_spread_ticks
    cdef object _slot_starting_cash
    cdef object _slot_state
    cdef object _slot_stream_history
    cdef object _slot_symbol
    cdef object _slot_threshold_ticks
    cdef object _slot_transacted_volume
    cdef object _slot_type
    cdef object _origin_class
    cdef object _strategy_name
    cdef object _source_agent
    cdef object _missing
    cdef bint _bound
    cdef bint _prepared
    cdef object _require_bound(self)
    cdef object _act(self)
    cdef object _base_wakeup(self, current_time)
    cdef object _base_receive_message(self, current_time, sender_id, message)
    cdef object _base_kernel_stopping(self)
    cdef object _kernel_terminating(self)
    cdef object _logEvent(self, event_type, event=*, append_summary_log=*, deepcopy_event=*)
    cdef object _send_message(self, recipient_id, message, delay=*)
    cdef object _send_message_batch(self, recipient_id, messages, delay=*)
    cdef object _set_wakeup(self, requested_time)
    cdef object _get_computation_delay(self)
    cdef object _set_computation_delay(self, requested_delay)
    cdef object _delay(self, additional_delay)
    cdef object _write_log(self, df_log, filename=*)
    cdef object _update_agent_state(self, state)
    cdef object _dollarize(self, cents)
    cdef object _trading_wakeup(self, current_time)
    cdef object _trading_receive_message(self, current_time, sender_id, message)
    cdef object _kernel_stopping(self)
    cdef object _wakeup(self, current_time)
    cdef object _receive_message(self, current_time, sender_id, message)
    cdef object _request_data_subscription(self, subscription_message)
    cdef object _cancel_data_subscription(self, subscription_message)
    cdef object _get_last_trade(self, symbol)
    cdef object _get_current_spread(self, symbol, depth=*)
    cdef object _get_order_stream(self, symbol, length=*)
    cdef object _get_transacted_volume(self, symbol, lookback_period=*)
    cdef uint64_t _create_limit_order(self, symbol, quantity, side, limit_price, order_id=*, is_hidden=*, is_price_to_comply=*, insert_by_id=*, is_post_only=*, ignore_risk=*, tag=*) except? 0
    cdef object _place_limit_order(self, symbol, quantity, side, limit_price, order_id=*, is_hidden=*, is_price_to_comply=*, insert_by_id=*, is_post_only=*, ignore_risk=*, tag=*)
    cdef object _place_market_order(self, symbol, quantity, side, order_id=*, ignore_risk=*, tag=*)
    cdef object _place_multiple_orders(self, orders)
    cdef object _cancel_order(self, uint64_t order, tag=*, metadata=*)
    cdef object _cancel_all_orders(self)
    cdef object _partial_cancel_order(self, order, quantity, tag=*, metadata=*)
    cdef object _modify_order(self, order, new_order)
    cdef object _replace_order(self, order, new_order)
    cdef object _order_executed(self, uint64_t order)
    cdef object _order_accepted(self, uint64_t order)
    cdef object _order_cancelled(self, uint64_t order)
    cdef object _order_partial_cancelled(self, order)
    cdef object _order_modified(self, order)
    cdef object _order_replaced(self, old_order, new_order)
    cdef object _market_closed(self)
    cdef object _query_last_trade(self, symbol, price)
    cdef object _query_spread(self, symbol, price, bids, asks, book)
    cdef object _handle_market_data(self, message)
    cdef object _query_order_stream(self, symbol, orders)
    cdef object _query_transacted_volume(self, symbol, bid_volume, ask_volume)
    cdef object _get_known_bid_ask(self, symbol, best=*)
    cdef object _get_known_liquidity(self, symbol, within=*)
    cdef object _get_book_liquidity(self, book, within)
    cdef object _mark_to_market(self, holdings, use_midpoint=*)
    cdef object _get_holdings(self, symbol)
    cdef object _get_known_bid_ask_midpoint(self, symbol)
    cdef object _get_average_transaction_price(self)
    cdef object _fmt_holdings(self, holdings)
    cdef object _get_wake_frequency(self)
    cdef object _act_NoiseTrader(self)
    cdef object _act_MarketMaker(self)
    cdef object _act_ValueTrader(self)
    cdef object _act_MomentumTrader(self)

cdef class NativeExchange:
    cdef OrderArena _orders
    cdef MessageArena _messages
    cdef ChainScheduler _scheduler
    cdef object _source, _missing
    cdef bint _prepared, _bound
    cdef object _slot_book_log_depth
    cdef object _slot_book_logging
    cdef object _slot_computation_delay
    cdef object _slot_current_time
    cdef object _slot_data_subscriptions
    cdef object _slot_id
    cdef object _slot_kernel
    cdef object _slot_log
    cdef object _slot_log_events
    cdef object _slot_log_orders
    cdef object _slot_log_to_file
    cdef object _slot_market_close_price_subscriptions
    cdef object _slot_metric_trackers
    cdef object _slot_mkt_close
    cdef object _slot_mkt_open
    cdef object _slot_name
    cdef object _slot_oracle
    cdef object _slot_order_books
    cdef object _slot_pipeline_delay
    cdef object _slot_random_state
    cdef object _slot_reschedule
    cdef object _slot_stp_policy
    cdef object _slot_stream_history
    cdef object _slot_symbols
    cdef object _slot_total_exchanged_volume
    cdef object _slot_type
    cdef object _kernel_terminating(self)
    cdef object _wakeup(self, current_time)
    cdef object _receive_message(self, current_time, sender_id, message)
    cdef object _publish_order_book_data(self)
    cdef object _handle_frequency_based_data_subscription(self, symbol, data_sub)
    cdef object _handle_event_based_data_subscription(self, symbol, data_sub)
    cdef object _logL2style(self, symbol)
    cdef object _send_message(self, recipient_id, message)
    cdef object _analyse_order_book(self, symbol)
    cdef object __original_time_dropout(self, book, symbol)
    cdef object _get_time_dropout(self, book, symbol)
    cdef object _base_wakeup(self, current_time)
    cdef object _base_receive_message(self, current_time, sender_id, message)
    cdef object _base_kernel_terminating(self)
    cdef object _logEvent(self, event_type, event=*, append_summary_log=*, deepcopy_event=*)
    cdef object _set_wakeup(self, requested_time)
    cdef object _set_computation_delay(self, requested_delay)
    cdef object _write_log(self, df_log, filename=*)
    cdef object _kernel_stopping(self)

cdef class NativeLevel:
    cdef OrderArena _orders
    cdef MessageArena _messages
    cdef object _slot_hidden_orders
    cdef object _slot_price
    cdef object _slot_side
    cdef object _slot_visible_orders
    cdef object _missing
    cdef object _add_order(self, uint64_t order, metadata=*)
    cdef object _update_order_quantity(self, order_id, new_quantity)
    cdef object _remove_order(self, order_id)
    cdef object _peek(self)
    cdef object _pop(self)
    cdef object _order_is_match(self, uint64_t order)
    cdef object _order_has_better_price(self, uint64_t order)
    cdef object _order_has_worse_price(self, uint64_t order)
    cdef object _order_has_equal_price(self, uint64_t order)
    cdef object _total_quantity(self)
    cdef object _is_empty(self)

cdef class NativeBook:
    cdef OrderArena _orders
    cdef MessageArena _messages
    cdef object _slot_asks
    cdef object _slot_bids
    cdef object _slot_book_log2
    cdef object _slot_buy_transactions
    cdef object _slot_history
    cdef object _slot_last_trade
    cdef object _slot_last_update_ts
    cdef object _slot_owner
    cdef object _slot_quotes_seen
    cdef object _slot_sell_transactions
    cdef object _slot_symbol
    cdef object _missing
    cdef ChainScheduler _scheduler
    cdef NativeExchange _owner
    cdef object _handle_limit_order(self, uint64_t order, quiet=*)
    cdef object _handle_market_order(self, order)
    cdef uint64_t _execute_order(self, uint64_t order) except? 0
    cdef object _enter_order(self, uint64_t order, metadata=*, quiet=*)
    cdef object _cancel_order(self, uint64_t order, tag=*, cancellation_metadata=*, quiet=*)
    cdef object _modify_order(self, order, new_order)
    cdef object _partial_cancel_order(self, order, quantity, tag=*, cancellation_metadata=*)
    cdef object _replace_order(self, agent_id, old_order, new_order)
    cdef object _append_book_log2(self)
    cdef object _get_l1_bid_data(self)
    cdef object _get_l1_ask_data(self)
    cdef object _get_l2_bid_data(self, depth=*)
    cdef object _get_l2_ask_data(self, depth=*)
    cdef object _get_l3_bid_data(self, depth=*)
    cdef object _get_l3_ask_data(self, depth=*)
    cdef object _get_transacted_volume(self, lookback_period=*)
    cdef object _get_imbalance(self)
    cdef object _get_L1_snapshots(self)
    cdef object _bids_padding(self, book, nlevels)
    cdef object _asks_padding(self, book, nlevels)
    cdef object _get_L2_snapshots(self, nlevels)
    cdef object _get_l3_itch(self)
    cdef object _pretty_print(self, silent=*)
    cdef object _send(self, recipient_id, message)

cdef void _observe_quote(object owner, object event, object symbol, object price, object quantity) except *
cdef void _observe_diagnostic(object owner, object event, object value) except *
cdef bint _observe_log(object owner, object event_type, object event, object append_summary_log, object deepcopy_event) except *
