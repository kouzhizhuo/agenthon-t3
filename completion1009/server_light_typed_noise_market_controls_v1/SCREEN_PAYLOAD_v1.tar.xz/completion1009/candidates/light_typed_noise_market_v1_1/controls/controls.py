"""Future original/light canonical/light dynamic/repeat full-market finite controls."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--baseline-runtime", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True); parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True); parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists(): raise ValueError("fresh composite control evidence required")
    args.out.mkdir(parents=True)
    root = Path(__file__).resolve().parents[1]
    rows = []; report = {"schema": "t3-light-typed-noise-market-real-controls-v1", "all_passed": False,
        "rankable": False, "speed_claim": False, "source_only": False, "cases": []}
    try:
        typed_out = args.out / "TYPED_HANDLE_CONTROLS.json"
        typed_command = [sys.executable, "-B", str(root / "typed_handle_control.py"), "--runtime", str(args.runtime),
            "--build", str(args.build), "--out", str(typed_out)]
        with (args.out / "typed-handle.log").open("xb") as log:
            typed_result = subprocess.run(typed_command, stdout=log, stderr=subprocess.STDOUT, timeout=300)
        if typed_result.returncode:
            raise RuntimeError("same-source typed handle controls failed; no wholemarket arm run")
        typed = json.loads(typed_out.read_bytes())
        if typed.get("all_passed") is not True or len(typed.get("cases", [])) != 28:
            raise ValueError("complete typed28 cases required before markets")
        report["typed_same_build_controls"] = {"result": typed, "command": typed_command,
            "bytes": typed_out.stat().st_size, "sha256": hashlib.sha256(typed_out.read_bytes()).hexdigest()}
        report["build_receipt"] = {"bytes": (args.build / "BUILD_RECEIPT.json").stat().st_size,
            "sha256": hashlib.sha256((args.build / "BUILD_RECEIPT.json").read_bytes()).hexdigest()}
        for script, filename, timeout in (("noise_expression_controls.py", "NOISE_EXPRESSION_CONTROLS.json", 600),
                ("noise_admission_controls.py", "NOISE_ADMISSION_CONTROLS.json", 600),
                ("noise_native_lifecycle_controls.py", "NOISE_NATIVE_LIFECYCLE_CONTROLS.json", 600)):
            evidence = args.out / filename
            command = [sys.executable, "-B", str(root / script), "--runtime", str(args.runtime),
                       "--build", str(args.build), "--out", str(evidence)]
            if script == "noise_admission_controls.py":
                command += ["--config", str(args.config)]
            with (args.out / (Path(script).stem + ".log")).open("xb") as log:
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            if result.returncode:
                raise RuntimeError("same-ELF Noise control failed; no wholemarket arm run: " + script)
            value = json.loads(evidence.read_bytes())
            if value.get("all_passed") is not True:
                raise ValueError("complete same-ELF Noise control PASS required: " + script)
            report[script] = {"result_path": evidence.name, "command": command,
                "bytes": evidence.stat().st_size, "sha256": hashlib.sha256(evidence.read_bytes()).hexdigest(),
                "all_passed": True}
        for name, arm, decline in (("original", "original", "none"), ("light_canonical", "light_canonical", "none"),
                ("light_dynamic", "light_dynamic", "none"), ("light_dynamic_repeat", "light_dynamic", "none"),
                ("decline_trace", "light_dynamic", "trace"), ("decline_message_trace", "light_dynamic", "message_trace")):
            out = args.out / name; out.mkdir()
            command = [sys.executable, "-B", str(root / "controls/control_child.py"), "--config", str(args.config),
                "--out", str(out / "trace.parquet"), "--runtime", str(args.baseline_runtime if arm == "original" else args.runtime), "--arm", arm]
            if arm != "original": command += ["--build", str(args.build)]
            if decline != "none": command += ["--projector-decline", decline]
            with (out / "child.log").open("xb") as log:
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if result.returncode: raise RuntimeError("actual composite arm failed: " + name)
            rows.append(out)
        selections = [json.loads((out / "ARM_SELECTION.json").read_bytes()) for out in rows]
        report["cases"].append({"case": "actual_required_owner_selection", "selections": selections, "passed": all(row["passed"] for row in selections)})
        for filename in ("trace.parquet", "message_trace.parquet", "STATE.json"):
            data = [(out / filename).read_bytes() for out in rows]
            report["cases"].append({"case": filename, "all_six_actual_bytes_equal": all(item == data[0] for item in data),
                "passed": all(item == data[0] for item in data)})
        counts = [json.loads((out / "events.json").read_bytes())["n_events"] for out in rows]
        report["cases"].append({"case": "complete_actual_event_counts", "counts": counts, "passed": len(set(counts)) == 1})
        arenas = [json.loads((out / "ARENA_DIAGNOSTICS.json").read_bytes()) for out in rows[2:]]
        arena_passed = (all(item == arenas[0] for item in arenas)
            and arenas[0]["orders"].get("order_clones", 0) > 0 and arenas[0]["orders"].get("order_slots", 0) > 0
            and arenas[0]["messages"].get("message_slots", 0) > 0)
        report["cases"].append({"case": "actual_positive_repeated_arena_diagnostics", "diagnostics": arenas, "passed": arena_passed})
        noises = [json.loads((out / "NOISE_DIAGNOSTICS.json").read_bytes()) for out in rows[2:]]
        noise_passed = (all(item == noises[0] for item in noises) and len(noises[0]["owners"]) > 0
            and all(row["diagnostics"]["normal_calls"] > 0 and row["diagnostics"]["randint_calls"] > 0
                    and row["diagnostics"]["words_consumed"] > 0 and row["diagnostics"]["handoffs"] == 1
                    and row["diagnostics"]["owned"] is False and row["diagnostics"]["export_failures"] == []
                    for row in noises[0]["owners"])
            and noises[0]["closed"] is True and noises[0]["cleanup_failures"] == []
            and noises[0]["actual_original_rng_exported"] is True and noises[0]["one_same_extension"] is True)
        report["cases"].append({"case": "actual_positive_repeated_owned_Noise_diagnostics", "diagnostics": noises,
            "passed": noise_passed})
        witnesses = [json.loads((out / "OUTPUT_WITNESS.json").read_bytes()) for out in rows[1:4]]
        fallback_witnesses = [json.loads((out / "OUTPUT_WITNESS.json").read_bytes()) for out in rows[4:]]
        children = [json.loads((out / "CONTROL_CHILD.json").read_bytes()) for out in rows]
        passed = all(row["projectors_admitted"] is True and row["source_authenticated"] is True
            and row["observer_admitted"] is True and row["declines"] == {} and row["output_mode"] == "canonical-arrow-buffers"
            and row["market_rerun"] is False for row in witnesses)
        passed = passed and all(row["actual_markets"] == 1 and row["graph_output_readonly"] and row["bindings_restored"] and row["observer_finished"] for row in children)
        report["cases"].append({"case": "cold_readonly_output_and_binding_controls", "witnesses": witnesses, "children": children, "passed": passed})
        fallback_passed = all(row["projectors_admitted"] is False and row["source_authenticated"] is True
            and row["observer_admitted"] is True and row["native_admitted"] is True
            and row["output_mode"] == "legacy-pandas" and row["market_rerun"] is False
            and row["declines"] == {name: "control-forced-projector-decline"}
            for name, row in zip(("trace", "message_trace"), fallback_witnesses))
        report["cases"].append({"case": "each_projector_complete_pair_fallback_without_rerun",
            "control_only_function_code_intervention": True, "witnesses": fallback_witnesses, "passed": fallback_passed})
        report["all_passed"] = all(row["passed"] for row in report["cases"])
        if not report["all_passed"]: raise ValueError("actual composite graph/output differs")
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (args.out / "CONTROLS.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__": main()
