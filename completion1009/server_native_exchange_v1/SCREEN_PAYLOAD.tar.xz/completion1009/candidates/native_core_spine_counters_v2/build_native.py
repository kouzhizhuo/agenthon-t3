#!/usr/bin/env python3
"""Explicit build step; does not execute a market or claim a native control PASS."""
import argparse
import json
import os
from pathlib import Path
import sys
import sysconfig
from provenance import HERE, sha, abi, dependencies, candidate_sources

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(HERE / "artifacts/build_v1"))
    args = parser.parse_args()
    output = Path(args.out).resolve()
    if output.exists():
        raise ValueError("build output exists; preserve prior build or failure")
    spec = json.loads((HERE / "compile_spec.json").read_text())
    if sys.implementation.name != spec["implementation"] or list(sys.version_info[:2]) != spec["python"]:
        raise ValueError("native spine requires CPython 3.11")
    import Cython
    if Cython.__version__ != spec["cython"]:
        raise ValueError("native spine requires Cython 3.1.3")
    installed = dependencies(spec)
    # Refuse externally supplied arithmetic-changing flags as well.
    flags = " ".join(os.environ.get(name, "") for name in ("CFLAGS", "CPPFLAGS", "LDFLAGS"))
    if any(flag in flags for flag in ("-ffast-math", "-Ofast", "-funsafe-math-optimizations", "-ffinite-math-only")):
        raise ValueError("unsafe ambient compiler flags")
    before = candidate_sources()
    for name in ("PINNED_RUNTIME.json", "SOURCE_BINDINGS.json"):
        if not (HERE / name).is_file():
            raise ValueError("run isolated snapshot and offline source preflight first: " + name)
    output.mkdir(parents=True)
    receipt_path = output / "BUILD_RECEIPT.json"
    receipt = {"schema": "t3-native-core-spine-counters-build-v2", "candidate": "native_core_spine_counters_v2", "build_succeeded": False,
        "candidate_sources": before, "abi": abi(), "dependencies": installed,
        "cython": Cython.__version__, "compile_spec_sha256": sha(HERE / "compile_spec.json"),
        "runtime_pins_sha256": sha(HERE / "PINNED_RUNTIME.json"),
        "source_bindings_sha256": sha(HERE / "SOURCE_BINDINGS.json"),
        "compiler_configuration": {name: sysconfig.get_config_var(name) for name in
            ("CC", "CXX", "CFLAGS", "CCSHARED", "LDSHARED")},
        "ambient_flags": flags, "compile_flags": spec["compile_flags"],
        "directives": spec["directives"], "market_execution": False, "timing_claim": False}
    try:
        from Cython.Build import cythonize
        from setuptools import Extension
        from setuptools.dist import Distribution
        extensions = cythonize([Extension(spec["module"], [str(HERE / spec["source"])],
            extra_compile_args=spec["compile_flags"])], build_dir=str(output / "generated"),
            compiler_directives=spec["directives"], force=True, annotate=False)
        distribution = Distribution({"name": "t3-native-core-spine-counters-proof", "ext_modules": extensions})
        command = distribution.get_command_obj("build_ext")
        command.build_lib = str(output / "native")
        command.build_temp = str(output / "objects")
        command.inplace = False
        command.ensure_finalized()
        command.run()
        extension = output / "native" / (spec["module"] + sysconfig.get_config_var("EXT_SUFFIX"))
        if not extension.is_file() or candidate_sources() != before:
            raise ValueError("extension missing or source changed during build")
        generated = {str(path.relative_to(output)): sha(path) for path in sorted((output / "generated").rglob("*.c"))}
        if not generated:
            raise ValueError("generated C receipt missing")
        receipt.update(build_succeeded=True, extension={"path": str(extension.relative_to(output)),
            "bytes": extension.stat().st_size, "sha256": sha(extension)}, generated_c=generated)
    except Exception as error:
        receipt["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")

if __name__ == "__main__":
    main()
