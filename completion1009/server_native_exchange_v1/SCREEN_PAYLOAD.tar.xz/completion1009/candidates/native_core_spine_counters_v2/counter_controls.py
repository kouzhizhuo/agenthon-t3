"""Source-prepared finite controls for actual compiled proof-counter operations.

Imported by finite_controls only after native provenance admission. No compiled
extension, market, or counter operation is executed when reading this source.
"""
from copy import deepcopy
import warnings

KEYS = ("pop", "requeue", "wake", "receive", "act", "exchange_query",
    "exchange_book_bridge", "raw_strategy_bridge", "send", "oracle_bridge")
MAX64 = (1 << 64) - 1


def run_cases(finite):
    from abides_core.message import MessageBatch
    from abides_markets.orders import LimitOrder, Side
    from abides_markets.messages.market import MarketClosePriceMsg, MarketClosePriceRequestMsg
    from abides_markets.messages.query import QuerySpreadResponseMsg
    from abides_markets.messages.order import LimitOrderMsg
    from abides_markets.messages.orderbook import OrderModifiedMsg, OrderCancelledMsg
    from admission import load_native, native_receipt
    from installed import capture_episode, reset_episode_probes, episode_probes

    results = []

    def counts(kernel):
        value = kernel.path_witness()["counts"]
        assert tuple(value) == KEYS and all(type(x) is int and x >= 0 for x in value.values())
        return value

    def snapshot(kernel, agent):
        value = finite.snapshot(kernel, agent)
        exchange = kernel.agents[0]
        # Include exchange/book fields absent from the inherited agent fixture.
        value["exchange"] = finite.encode({key: item for key, item in vars(exchange).items()
            if key not in ("kernel", "order_books")})
        value["books"] = finite.encode({symbol: {key: item for key, item in vars(book).items()
            if key != "owner"} for symbol, book in exchange.order_books.items()})
        return value

    def prepare(key):
        kernel, agent = finite.setup(3 if key == "oracle_bridge" else 1, True,
            bids=[(99, 3)], asks=[(101, 4)])
        if key in ("pop", "requeue"):
            for index in range(3):
                kernel.send_message(0, 1, MarketClosePriceMsg({"ABM": 111 + index}), delay=index)
            if key == "requeue":
                kernel.agent_current_times[1] = 10000
        if key == "raw_strategy_bridge":
            order = LimitOrder(1, 110, "ABM", 7, Side.BID, 100)
            agent.orders[order.order_id] = deepcopy(order)
        return kernel, agent

    def operation(kernel, agent, key, index):
        if key in ("pop", "requeue"):
            kernel.run_one_pop()
        elif key == "send":
            kernel.send_message(0, 1, MarketClosePriceMsg({"ABM": 111 + index}))
        elif key == "wake":
            kernel.transition_wake(1)
        elif key == "receive":
            kernel.transition_receive(1, 0, MarketClosePriceMsg({"ABM": 111 + index}))
        elif key in ("act", "oracle_bridge"):
            agent.state = "AWAITING_SPREAD"
            kernel.transition_receive(1, 0, QuerySpreadResponseMsg("ABM", False, 1,
                [(99, 3)], [(101, 4)], 100))
        elif key == "raw_strategy_bridge":
            order = deepcopy(next(iter(agent.orders.values())))
            kernel.transition_receive(1, 0, OrderModifiedMsg(order))
        elif key in ("exchange_query", "exchange_book_bridge"):
            message = MarketClosePriceRequestMsg() if key == "exchange_query" else LimitOrderMsg(
                LimitOrder(1, 110, "ABM", 7, Side.BID, 99))
            target = counts(kernel)[key] + 1
            kernel.send_message(1, 0, message)
            for _ in range(50):
                if counts(kernel)[key] == target:
                    break
                kernel.run_one_pop()
            else:
                raise AssertionError("exchange event not reached")
        else:
            raise AssertionError("unknown counter operation")

    for key in KEYS:
        unseeded = []
        kernel, agent = prepare(key)
        initial = counts(kernel)
        for index in range(3):
            operation(kernel, agent, key, index)
            unseeded.append((snapshot(kernel, agent), counts(kernel)))
        assert [item[1][key] - initial[key] for item in unseeded] == [1, 2, 3], key
        for seed in (MAX64 - 1, 10 ** 400):
            kernel, agent = prepare(key)
            seeds = counts(kernel)
            seeds[key] = seed
            kernel._seed_proof_counters(seeds)
            assert kernel.path_witness()["proof_counters_seeded"] is True
            for index in range(3):
                operation(kernel, agent, key, index)
                actual = counts(kernel)
                expected = {name: seeds[name] + unseeded[index][1][name] - initial[name] for name in KEYS}
                assert actual == expected, (key, seed, index)
                assert snapshot(kernel, agent) == unseeded[index][0], (key, seed, "business state")
            results.append({"name": "counter_" + key + ("_cross_uint64_real_operations" if seed == MAX64 - 1 else "_huge_pylong_real_operations"), "passed": True})

    kernel, agent = prepare("receive")
    before = counts(kernel)
    invalid = [None, [], {**before, "unknown": 0}, {k: v for k, v in before.items() if k != "pop"},
        {**before, "pop": -1}, {**before, "pop": True}]
    import numpy as np
    invalid.append({**before, "pop": np.int64(1)})
    class IntegerSubclass(int):
        pass
    invalid.append({**before, "pop": IntegerSubclass(1)})
    class DictSubclass(dict):
        pass
    invalid.append(DictSubclass(before))
    class StringSubclass(str):
        pass
    invalid.append({(StringSubclass(key) if key == "pop" else key): value for key, value in before.items()})
    for value in invalid:
        try:
            kernel._seed_proof_counters(value)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid proof counter seed accepted")
        assert counts(kernel) == before and kernel.path_witness()["proof_counters_seeded"] is False
    results.append({"name": "counter_seed_invalid_inputs_atomic_and_unmarked", "passed": True})

    kernel._seed_proof_counters({**before, "receive": 10 ** 400})
    spilled = counts(kernel)
    try:
        kernel._seed_proof_counters({**spilled, "act": -1})
    except ValueError:
        pass
    else:
        raise AssertionError("invalid seed accepted on spilled core")
    assert counts(kernel) == spilled and kernel.path_witness()["proof_counters_seeded"] is True
    results.append({"name": "counter_invalid_seed_preserves_existing_spill_and_mark", "passed": True})

    kernel, agent = prepare("receive")
    witness = kernel.path_witness()
    witness["counts"]["pop"] = 999
    assert counts(kernel) == before
    seeds = dict(reversed(list(before.items())))
    kernel._seed_proof_counters(seeds)
    assert tuple(counts(kernel)) == KEYS
    kernel._seed_proof_counters(before)
    assert kernel.path_witness()["proof_counters_seeded"] is True
    results.append({"name": "counter_fresh_ordered_snapshot_and_sticky_seed_mark", "passed": True})

    observed = []
    for seeded in (False, True):
        kernel, agent = prepare("act")
        initial = counts(kernel)
        if seeded:
            seeds = dict(initial); seeds["receive"] = seeds["act"] = MAX64
            kernel._seed_proof_counters(seeds)
        rows = []
        for index in range(2):
            operation(kernel, agent, "act", index)
            rows.append((snapshot(kernel, agent), counts(kernel)))
        observed.append((initial, rows))
    for index in range(2):
        assert observed[0][1][index][0] == observed[1][1][index][0]
        expected = dict(observed[0][1][index][1])
        for key in ("receive", "act"):
            expected[key] = MAX64 + expected[key] - observed[0][0][key]
        assert observed[1][1][index][1] == expected
    results.append({"name": "counter_two_slots_spill_through_shared_storage", "passed": True})

    # Preserve counter placement when an already-admitted test hook raises.
    for phase, key in (("pop", "pop"), ("requeue", "requeue")):
        observed = []
        for seed in (None, MAX64):
            kernel, agent = prepare(key)
            initial = counts(kernel)
            if seed is not None:
                values = dict(initial); values[key] = seed
                kernel._seed_proof_counters(values)
            def fail(at, current, envelope, message):
                if at == phase:
                    raise RuntimeError("counter residue hook")
            kernel.set_debug_hook(fail)
            try:
                kernel.run_one_pop()
            except RuntimeError as error:
                assert str(error) == "counter residue hook"
            else:
                raise AssertionError("debug hook did not raise")
            finally:
                kernel.set_debug_hook(None)
            observed.append((snapshot(kernel, agent), counts(kernel), initial))
        assert observed[0][0] == observed[1][0]
        expected = dict(observed[0][1]); expected[key] = MAX64 + observed[0][1][key] - observed[0][2][key]
        assert observed[1][1] == expected
        results.append({"name": "counter_" + phase + "_commit_before_debug_exception", "passed": True})

    # A malformed submessage is deliberately test-only. It proves the send
    # increment after successful push and before the original ledger failure.
    observed = []
    for seed in (None, MAX64):
        kernel, agent = prepare("send")
        initial = counts(kernel)
        if seed is not None:
            values = dict(initial); values["send"] = seed
            kernel._seed_proof_counters(values)
        batch = MessageBatch([None])
        try:
            kernel.send_message(0, 1, batch)
        except AttributeError as error:
            error_text = str(error)
        else:
            raise AssertionError("malformed ledger submessage did not raise")
        observed.append((snapshot(kernel, agent), counts(kernel), initial, error_text))
    assert observed[0][0] == observed[1][0] and observed[0][3] == observed[1][3]
    expected = dict(observed[0][1]); expected["send"] = MAX64 + 1
    assert observed[1][1] == expected
    results.append({"name": "counter_send_commit_before_test_only_ledger_exception", "passed": True})

    observed = []
    for seed in (None, MAX64):
        kernel, agent = prepare("receive")
        initial = counts(kernel)
        if seed is not None:
            values = dict(initial); values["receive"] = seed
            kernel._seed_proof_counters(values)
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            order = LimitOrder(1, 110, "ABM", 7, Side.BID, 100)
            try:
                kernel.transition_receive(1, 0, OrderCancelledMsg(order))
            except UserWarning as error:
                error_text = str(error)
            else:
                raise AssertionError("missing-order warning did not raise")
        observed.append((snapshot(kernel, agent), counts(kernel), error_text))
    assert observed[0][0] == observed[1][0] and observed[0][2] == observed[1][2]
    expected = dict(observed[0][1]); expected["receive"] = MAX64 + 1
    assert observed[1][1] == expected
    results.append({"name": "counter_receive_commit_before_promoted_warning", "passed": True})

    reset_episode_probes()
    kernel, agent = prepare("receive")
    kernel._seed_proof_counters(counts(kernel))
    try:
        capture_episode(kernel)
    except ValueError:
        pass
    else:
        raise AssertionError("seeded production witness accepted")
    assert episode_probes() == []
    reset_episode_probes()
    results.append({"name": "counter_seeded_production_capture_refused", "passed": True})

    # The inherited token captures the test seed method along with other
    # compiled exports, so test instrumentation cannot evade loaded admission.
    original = finite.NATIVE.NativeSpineKernel._seed_proof_counters
    finite.NATIVE.NativeSpineKernel._seed_proof_counters = lambda self, values: None
    try:
        try:
            load_native(native_receipt()["receipt_path"])
        except ValueError:
            pass
        else:
            raise AssertionError("replaced compiled seed facade admitted")
    finally:
        finite.NATIVE.NativeSpineKernel._seed_proof_counters = original
    load_native(native_receipt()["receipt_path"])
    results.append({"name": "counter_seed_export_replacement_refused", "passed": True})
    return results
