#!/usr/bin/env python3
"""Materialize an independent frozen source snapshot; no native generation/run."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    target = HERE / "runtime"
    destination = HERE / "PINNED_RUNTIME.json"
    if target.exists() or destination.exists():
        raise ValueError("snapshot exists; preserve prior materialization")
    manifest_path = ROOT / "RUNTIME_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    records = []
    # Validate every member before writing the isolated snapshot.
    staged = []
    for item in manifest["files"]:
        relative = Path(item["path"]).relative_to("runtime")
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("unsafe frozen manifest member")
        data = (ROOT / "runtime" / relative).read_bytes()
        if len(data) != item["bytes"] or sha(data) != item["sha256"]:
            raise ValueError("frozen source differs: " + str(relative))
        staged.append((relative, data))
    if len(staged) != 62:
        raise ValueError("frozen runtime count differs")
    for relative, data in staged:
        path = target / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        records.append({"path": str(relative), "bytes": len(data), "sha256": sha(data)})
    sources = {item["path"]: item["sha256"] for item in records if item["path"].endswith(".py")}
    destination.write_text(json.dumps({"schema": "t3-native-spine-frozen-source-pins-v1",
        "runtime_files": records, "python_sources": sources,
        "frozen_manifest_sha256": sha(manifest_path.read_bytes()),
        "runtime_source_changes": 0, "native_generation_or_execution": False}, indent=2) + "\n")

if __name__ == "__main__":
    main()
