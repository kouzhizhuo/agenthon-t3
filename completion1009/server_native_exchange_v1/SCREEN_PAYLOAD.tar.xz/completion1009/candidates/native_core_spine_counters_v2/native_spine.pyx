# cython: language_level=3, annotation_typing=False, infer_types=False
"""Typed continuous scheduler/strategy proof spine; performance is unproved.

The original Python kernel and agents are the sole mutable business owners.
This module owns only typed envelope handles, native sift loops, immutable
strategy-kind metadata and direct compiled strategy transitions. Matching,
RandomState/oracle, logs, actual Message/Order objects and numeric operations
remain exact Python bridges. No source implementation is an execution fallback.

Only the ten private proof counters differ from native_core_spine_v1: typed
uint64 slots use checked, per-slot arbitrary-precision Python overflow spill.
"""
from libc.stdint cimport uint64_t, uint16_t, UINT64_MAX
from copy import deepcopy
import warnings

from abides_core.message import Message, MessageBatch, WakeupMsg
from abides_core.kernel import logger
from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
from abides_markets.agents.exchange_agent import ExchangeAgent
from abides_markets.agents.trading_agent import TradingAgent
from abides_markets.orders import LimitOrder, Side
from abides_markets.messages.market import (MarketHoursRequestMsg, MarketHoursMsg,
    MarketClosePriceRequestMsg, MarketClosePriceMsg, MarketClosedMsg)
from abides_markets.messages.query import (QuerySpreadMsg, QuerySpreadResponseMsg,
    QueryLastTradeResponseMsg, QueryOrderStreamResponseMsg, QueryTransactedVolResponseMsg)
from abides_markets.messages.order import LimitOrderMsg, CancelOrderMsg
from abides_markets.messages.orderbook import (OrderAcceptedMsg, OrderExecutedMsg,
    OrderCancelledMsg, OrderPartialCancelledMsg, OrderModifiedMsg, OrderReplacedMsg)
from t3_canonical_engine import CanonicalKernel

STRATEGIES = {NoiseTrader: 1, MarketMaker: 2, ValueTrader: 3, MomentumTrader: 4}
DEFAULT_CANCEL_METADATA = TradingAgent.cancel_order.__defaults__[-1]
PROOF_COUNTER_KEYS = ("pop", "requeue", "wake", "receive", "act", "exchange_query",
    "exchange_book_bridge", "raw_strategy_bridge", "send", "oracle_bridge")

cdef enum CounterSlot:
    C_POP = 0
    C_REQUEUE = 1
    C_WAKE = 2
    C_RECEIVE = 3
    C_ACT = 4
    C_EXCHANGE_QUERY = 5
    C_EXCHANGE_BOOK_BRIDGE = 6
    C_RAW_STRATEGY_BRIDGE = 7
    C_SEND = 8
    C_ORACLE_BRIDGE = 9
    C_COUNT = 10

cdef class Envelope:
    """One owned raw-message reference per envelope; no UID reconstruction."""
    cdef object time
    cdef Py_ssize_t sender, recipient
    cdef object message

    def __init__(self, time, Py_ssize_t sender, Py_ssize_t recipient, message):
        self.time = time
        self.sender = sender
        self.recipient = recipient
        self.message = message

    def logical(self):
        return (self.time, self.sender, self.recipient, self.message)


cdef bint before(Envelope left, Envelope right) except -1:
    # Original tuple equality precedes rich less-than on each component.
    # In particular, compare the actual raw Message; replacing it with cached
    # UID would need a stronger producer/alias contract. Time stays PyObject,
    # preserving NumPy scalar comparisons and Python integer range.
    if left.time is not right.time and not (left.time == right.time):
        return left.time < right.time
    if left.sender != right.sender:
        return left.sender < right.sender
    if left.recipient != right.recipient:
        return left.recipient < right.recipient
    if left.message is right.message or left.message == right.message:
        return False
    return left.message < right.message


cdef class TypedCalendar:
    """CPython heapq sift order, using typed envelopes/indexes and raw refs."""
    cdef list heap

    def __init__(self):
        self.heap = []

    cdef void swap(self, Py_ssize_t left, Py_ssize_t right) except *:
        cdef Envelope first = self.heap[left]
        cdef Envelope second = self.heap[right]
        self.heap[left], self.heap[right] = second, first

    cdef void down(self, Py_ssize_t start, Py_ssize_t position) except *:
        cdef Py_ssize_t size = len(self.heap)
        cdef Py_ssize_t parent
        cdef bint comparison
        # CPython 3.11's C heapq swaps after each successful comparison.
        # Preserve its comparison-exception residue and size-change check.
        while position > start:
            parent = (position - 1) >> 1
            comparison = before(self.heap[position], self.heap[parent])
            if size != len(self.heap):
                raise RuntimeError("list changed size during iteration")
            if not comparison:
                break
            self.swap(position, parent)
            position = parent

    cdef void up(self, Py_ssize_t position) except *:
        cdef Py_ssize_t start = position
        cdef Py_ssize_t size = len(self.heap)
        cdef Py_ssize_t limit = size >> 1
        cdef Py_ssize_t child
        cdef bint comparison
        while position < limit:
            child = position * 2 + 1
            if child + 1 < size:
                comparison = before(self.heap[child], self.heap[child + 1])
                if not comparison:
                    child += 1
                if size != len(self.heap):
                    raise RuntimeError("list changed size during iteration")
            self.swap(position, child)
            position = child
        self.down(start, position)

    cdef void push_event(self, Envelope item) except *:
        self.heap.append(item)
        self.down(0, len(self.heap) - 1)

    cdef Envelope pop_event(self):
        cdef Py_ssize_t size = len(self.heap)
        cdef Envelope result, last
        if size == 0:
            raise IndexError("index out of range")
        last = self.heap.pop()
        if size == 1:
            return last
        result = self.heap[0]
        self.heap[0] = last
        self.up(0)
        return result

    def empty(self):
        return not self.heap

    def qsize(self):
        return len(self.heap)

    def logical_queue(self):
        return [(<Envelope>item).logical() for item in self.heap]

    @property
    def queue(self):
        # Read-only diagnostic snapshot. Arbitrary queue mutation is outside
        # this proof prototype's admitted fixed producer domain.
        return self.logical_queue()

    def push(self, time, sender, recipient, message):
        self.push_event(Envelope(time, sender, recipient, message))

    def pop(self):
        return self.pop_event().logical()


cdef class NativeCore:
    """One continuous cdef region; mutable business state stays authoritative."""
    cdef object kernel
    cdef TypedCalendar calendar
    cdef list kinds
    cdef uint64_t counter_values[10]
    cdef uint16_t counter_spilled
    cdef object counter_spill
    cdef bint proof_counters_seeded
    cdef object debug_hook

    def __init__(self, kernel):
        cdef int slot
        self.kernel = kernel
        self.calendar = TypedCalendar()
        self.kinds = [0] + [STRATEGIES[type(a)] for a in kernel.agents[1:]]
        for slot in range(C_COUNT):
            self.counter_values[slot] = 0
        self.counter_spilled = 0
        self.counter_spill = None
        self.proof_counters_seeded = False
        self.debug_hook = None

    cdef inline void increment(self, int slot) except *:
        cdef uint16_t bit = <uint16_t>(1 << slot)
        cdef object spill, next_value
        if self.counter_spilled & bit:
            # An active slot stays arbitrary-precision Python arithmetic.
            # Compute before assignment so an exception retains the old value.
            next_value = self.counter_spill[slot] + 1
            self.counter_spill[slot] = next_value
        elif self.counter_values[slot] != UINT64_MAX:
            self.counter_values[slot] += 1
        else:
            # Allocate and box before publishing either the spill or active bit.
            # Never wrap/saturate a diagnostic count or narrow its Python value.
            spill = [None] * C_COUNT if self.counter_spill is None else self.counter_spill
            next_value = self.counter_values[slot]
            next_value = next_value + 1
            spill[slot] = next_value
            self.counter_spill = spill
            self.counter_spilled |= bit

    cdef dict counter_snapshot(self):
        cdef int slot
        cdef object value
        cdef dict result = {}
        for slot in range(C_COUNT):
            value = self.counter_spill[slot] if self.counter_spilled & (<uint16_t>(1 << slot)) else int(self.counter_values[slot])
            result[PROOF_COUNTER_KEYS[slot]] = value
        return result

    def _seed_proof_counters(self, values):
        """Test-only exact seed; all seeded witnesses remain visibly marked.

        Validate the complete builtin dict/integers before altering a slot.
        Production host/market controls explicitly reject marked witnesses.
        """
        cdef int slot
        cdef object value
        cdef list staged
        cdef uint64_t staged_values[10]
        cdef uint16_t staged_mask = 0
        cdef object staged_spill = None
        if type(values) is not dict or any(type(key) is not str for key in values) or set(values) != set(PROOF_COUNTER_KEYS):
            raise ValueError("counter seed requires the exact ten-key builtin dictionary")
        staged = [values[key] for key in PROOF_COUNTER_KEYS]
        if any(type(item) is not int or item < 0 for item in staged):
            raise ValueError("counter seed requires exact nonnegative builtin integers")
        for slot in range(C_COUNT):
            value = staged[slot]
            if value > int(UINT64_MAX):
                if staged_spill is None:
                    staged_spill = [None] * C_COUNT
                staged_spill[slot] = value
                staged_values[slot] = 0
                staged_mask |= <uint16_t>(1 << slot)
            else:
                staged_values[slot] = value
        # No Python allocation or comparison occurs after commit starts.
        for slot in range(C_COUNT):
            self.counter_values[slot] = staged_values[slot]
        self.counter_spill = staged_spill
        self.counter_spilled = staged_mask
        self.proof_counters_seeded = True

    def get_calendar(self):
        return self.calendar

    def path_witness(self):
        return {"candidate": "native_core_spine_counters_v2", "native_core_type": type(self).__name__,
            "native_active": True, "fallback_used": False, "proof_only": True,
            "counts": self.counter_snapshot(), "calendar_pending": self.calendar.qsize(),
            "proof_counter_storage": "uint64_checked_python_spill",
            "proof_counters_seeded": bool(self.proof_counters_seeded),
            "authoritative_agent_state": "original_python_owners", "compact_arena": False}

    def set_debug_hook(self, hook):
        # Test-only callback receives actual raw objects. Production leaves None.
        self.debug_hook = hook

    cdef void signal(self, object phase, Envelope event, object message) except *:
        if self.debug_hook is not None:
            self.debug_hook(phase, self.kernel, event.logical(), message)

    cdef void schedule(self, object sender, object recipient, object message, object delay) except *:
        cdef object k = self.kernel
        cdef object sent, latency, receive, order, item
        sent = k.current_time + k.agent_computation_delays[sender] + k.current_agent_additional_delay + delay
        if k.agent_latency_model is not None:
            latency = k.agent_latency_model.get_latency(sender_id=sender, recipient_id=recipient)
            receive = sent + int(latency)
        else:
            latency = k.agent_latency[sender][recipient]
            noise = k.random_state.choice(len(k.latency_noise), p=k.latency_noise)
            receive = sent + int(latency + noise)
        self.calendar.push_event(Envelope(receive, sender, recipient, message))
        self.increment(C_SEND)
        # Bind the batch's actual list once at send, and never flatten/copy it.
        items = message.messages if isinstance(message, MessageBatch) else [message]
        for item in items:
            order = getattr(item, "order", None)
            k._msg_ledger.append_values(item.message_id, sender, recipient, sent, receive,
                receive - sent, item.type(), getattr(order, "order_id", None), k._current_causal_uid)

    def send_message(self, sender_id, recipient_id, message, delay=0):
        self.schedule(sender_id, recipient_id, message, delay)

    cdef void wakeup(self, object sender, object requested) except *:
        cdef object k = self.kernel
        if requested is None:
            requested = k.current_time + 1
        if k.current_time and requested < k.current_time:
            raise ValueError("set_wakeup() called with requested time not in future",
                "current_time:", k.current_time, "requested_time:", requested)
        # Original constructor increments the UID exactly once, including unsent
        # messages elsewhere. Each envelope retains its own strong raw reference.
        self.calendar.push_event(Envelope(requested, sender, sender, WakeupMsg()))

    def set_wakeup(self, sender_id, requested_time=None):
        self.wakeup(sender_id, requested_time)

    cdef object wake(self, object a):
        cdef object k = self.kernel
        self.increment(C_WAKE)
        a.current_time = k.current_time
        if a.first_wake:
            a.logEvent("HOLDINGS_UPDATED", a.holdings)
            a.first_wake = False
            self.schedule(a.id, a.exchange_id, MarketClosePriceRequestMsg(), 0)
        if a.mkt_open is None:
            self.schedule(a.id, a.exchange_id, MarketHoursRequestMsg(), 0)
        if not a.mkt_open or not a.mkt_close or a.mkt_closed:
            return None
        self.wakeup(a.id, k.current_time + a.interval_ns)
        self.schedule(a.id, a.exchange_id, QuerySpreadMsg(a.symbol, 1), 0)
        a.state = "AWAITING_SPREAD"
        return None

    cdef void last_trade(self, object a, object symbol, object price) except *:
        a.last_trade[symbol] = price
        if a.mkt_closed:
            a.daily_close_price[symbol] = price

    cdef void receive(self, object a, object sender, object message, int kind) except *:
        cdef object k = self.kernel
        cdef object order, quantity, symbol, original, bids, asks
        cdef bint had_hours = a.mkt_open is not None and a.mkt_close is not None
        cdef bint have_hours
        self.increment(C_RECEIVE)
        a.current_time = k.current_time
        if isinstance(message, MarketHoursMsg):
            a.mkt_open, a.mkt_close = message.mkt_open, message.mkt_close
        elif isinstance(message, MarketClosePriceMsg):
            for symbol, price in message.close_prices.items():
                a.last_trade[symbol] = price
        elif isinstance(message, MarketClosedMsg):
            a.logEvent("MKT_CLOSED")
            a.mkt_closed = True
        elif isinstance(message, (OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg)):
            order = message.order
            if a.log_orders:
                a.logEvent("ORDER_EXECUTED" if isinstance(message, OrderExecutedMsg)
                    else ("ORDER_ACCEPTED" if isinstance(message, OrderAcceptedMsg) else "ORDER_CANCELLED"),
                    order.to_dict(), deepcopy_event=False)
            if isinstance(message, OrderExecutedMsg):
                quantity = order.quantity if order.side.is_bid() else -1 * order.quantity
                symbol = order.symbol
                if symbol in a.holdings:
                    a.holdings[symbol] += quantity
                else:
                    a.holdings[symbol] = quantity
                if a.holdings[symbol] == 0:
                    del a.holdings[symbol]
                a.holdings["CASH"] -= quantity * order.fill_price
                if order.order_id in a.orders:
                    original = a.orders[order.order_id]
                    if order.quantity >= original.quantity:
                        del a.orders[order.order_id]
                    else:
                        original.quantity -= order.quantity
                else:
                    warnings.warn(f"Execution received for order not in orders list: {order}")
                a.logEvent("HOLDINGS_UPDATED", a.holdings)
            elif isinstance(message, OrderCancelledMsg):
                if order.order_id in a.orders:
                    del a.orders[order.order_id]
                else:
                    warnings.warn(f"Cancellation received for order not in orders list: {order}")
        elif isinstance(message, QuerySpreadResponseMsg):
            symbol = message.symbol
            if message.mkt_closed:
                a.mkt_closed = True
            self.last_trade(a, symbol, message.last_trade)
            bids, asks = message.bids, message.asks
            a.known_bids[symbol], a.known_asks[symbol] = bids, asks
            a.logEvent("BID_DEPTH", bids)
            a.logEvent("ASK_DEPTH", asks)
            a.logEvent("IMBALANCE", [sum([x[1] for x in bids]), sum([x[1] for x in asks])])
            a.book = ""
        elif isinstance(message, QueryLastTradeResponseMsg):
            if message.mkt_closed:
                a.mkt_closed = True
            self.last_trade(a, message.symbol, message.last_trade)
        elif isinstance(message, QueryOrderStreamResponseMsg):
            if message.mkt_closed:
                a.mkt_closed = True
            a.stream_history[message.symbol] = message.orders
        elif isinstance(message, QueryTransactedVolResponseMsg):
            if message.mkt_closed:
                a.mkt_closed = True
            a.transacted_volume[message.symbol] = (message.bid_volume, message.ask_volume)
        else:
            # Original business owner is current; no shadow-state synchronization.
            self.increment(C_RAW_STRATEGY_BRIDGE)
            TradingAgent.receive_message(a, k.current_time, sender, message)
            had_hours = True
        have_hours = a.mkt_open is not None and a.mkt_close is not None
        if have_hours and not had_hours:
            self.wakeup(a.id, a.mkt_open + 0)
        if a.state == "AWAITING_SPREAD" and isinstance(message, QuerySpreadResponseMsg):
            if not a.mkt_closed:
                self.act(a, kind)
            a.state = "AWAITING_WAKEUP"

    cdef void place(self, object a, object quantity, object side, object price) except *:
        cdef object order = LimitOrder(a.id, self.kernel.current_time, a.symbol, quantity, side, price)
        cdef object new_holdings, q
        if quantity <= 0:
            warnings.warn(f"TradingAgent ignored limit order of quantity zero: {order}")
            return
        # Keep original create_limit_order's numeric lane even though its plain
        # local dictionary is discarded with ignore_risk=True. This preserves
        # NumPy overflow/warnings and unusual exact numeric boundary behavior.
        new_holdings = a.holdings.copy()
        q = order.quantity if order.side.is_bid() else -order.quantity
        if order.symbol in new_holdings:
            new_holdings[order.symbol] += q
        else:
            new_holdings[order.symbol] = q
        a.orders[order.order_id] = deepcopy(order)
        self.schedule(a.id, a.exchange_id, LimitOrderMsg(order), 0)
        if a.log_orders:
            a.logEvent("ORDER_SUBMITTED", order.to_dict(), deepcopy_event=False)

    cdef void act(self, object a, int kind) except *:
        cdef object bid, ask, size, buy, offset, anchor, mid, half, level, order, fundamental, past
        cdef object bids = a.known_bids[a.symbol]
        cdef object asks = a.known_asks[a.symbol]
        self.increment(C_ACT)
        bid = bids[0][0] if bids else None
        ask = asks[0][0] if asks else None
        # Original get_known_bid_ask reads both quantity cells as well.
        if bids:
            bids[0][1]
        if asks:
            asks[0][1]
        if kind == 1:
            size = int(max(1, round(a.random_state.normal(a.order_size_mean, a.order_size_std))))
            buy = bool(a.random_state.randint(0, 2))
            offset = int(a.random_state.randint(0, a.price_offset_ticks + 1))
            if buy:
                anchor = int(ask) if ask else (int(bid) if bid else a.reference_price)
                self.place(a, size, Side.BID, anchor + offset)
            else:
                anchor = int(bid) if bid else (int(ask) if ask else a.reference_price)
                self.place(a, size, Side.ASK, anchor - offset)
        elif kind == 2:
            mid = int((bid + ask) // 2) if bid and ask else a.reference_price
            for order in a.orders.values():
                if isinstance(order, LimitOrder):
                    self.schedule(a.id, a.exchange_id, CancelOrderMsg(order, None, DEFAULT_CANCEL_METADATA), 0)
                    if a.log_orders:
                        a.logEvent("CANCEL_SUBMITTED", order.to_dict(), deepcopy_event=False)
            half = a.spread_ticks // 2
            for level in range(a.depth_levels):
                self.place(a, a.size_per_level, Side.BID, mid - half - level)
                self.place(a, a.size_per_level, Side.ASK, mid + half + level)
        else:
            if bid and ask:
                mid = (int(bid) + int(ask)) / 2.0
            elif bid:
                mid = float(bid)
            elif ask:
                mid = float(ask)
            else:
                return
            if kind == 3:
                self.increment(C_ORACLE_BRIDGE)
                fundamental = int(a.oracle.observe_price(a.symbol, self.kernel.current_time, a.random_state, sigma_n=a.sigma_n))
                size = int(max(1, round(a.order_size_mean)))
                if mid < fundamental - a.threshold_ticks and ask:
                    self.place(a, size, Side.BID, int(ask))
                elif mid > fundamental + a.threshold_ticks and bid:
                    self.place(a, size, Side.ASK, int(bid))
            elif kind == 4:
                a._mid_history.append(mid)
                if len(a._mid_history) > a.lookback + 1:
                    a._mid_history.pop(0)
                if len(a._mid_history) <= a.lookback:
                    return
                past = a._mid_history[0]
                size = int(max(1, round(a.order_size_mean)))
                if mid > past + a.threshold_ticks and ask:
                    self.place(a, size, Side.BID, int(ask))
                elif mid < past - a.threshold_ticks and bid:
                    self.place(a, size, Side.ASK, int(bid))

    cdef void exchange(self, object sender, object message) except *:
        cdef object k = self.kernel
        cdef object a = k.agents[0]
        cdef object book, symbol
        a.current_time = k.current_time
        if isinstance(message, (MarketHoursRequestMsg, MarketClosePriceRequestMsg, QuerySpreadMsg)) and k.current_time <= a.mkt_close:
            self.increment(C_EXCHANGE_QUERY)
            k.set_agent_compute_delay(0, a.computation_delay)
            a.logEvent(message.type(), message)
            if isinstance(message, MarketHoursRequestMsg):
                k.set_agent_compute_delay(0, 0)
                self.schedule(0, sender, MarketHoursMsg(a.mkt_open, a.mkt_close), 0)
            elif isinstance(message, MarketClosePriceRequestMsg):
                a.market_close_price_subscriptions.append(sender)
            else:
                symbol = message.symbol
                if symbol not in a.order_books:
                    warnings.warn(f"Bid-ask spread request discarded. Unknown symbol: {symbol}")
                else:
                    book = a.order_books[symbol]
                    self.schedule(0, sender, QuerySpreadResponseMsg(symbol=symbol,
                        mkt_closed=k.current_time > a.mkt_close, depth=message.depth,
                        bids=book.get_l2_bid_data(message.depth), asks=book.get_l2_ask_data(message.depth),
                        last_trade=book.last_trade), 0)
        else:
            self.increment(C_EXCHANGE_BOOK_BRIDGE)
            a.receive_message(k.current_time, sender, message)

    cdef void deliver(self, Envelope event, object message) except *:
        cdef object k = self.kernel
        cdef int kind = self.kinds[event.recipient]
        k.agent_current_times[event.recipient] += k.agent_computation_delays[event.recipient] + k.current_agent_additional_delay
        k._current_causal_uid = message.message_id
        k._deliver_seq_by_key[message.message_id, event.recipient] = k._deliver_seq
        k._deliver_seq += 1
        self.signal("before_receive", event, message)
        if kind == 0:
            self.exchange(event.sender, message)
        else:
            self.receive(k.agents[event.recipient], event.sender, message, kind)
        self.signal("after_receive", event, message)

    def run(self, agent_actions=None, max_pops=None):
        cdef object k = self.kernel
        cdef Envelope event
        cdef object message, result, messages
        cdef object popped = 0
        if agent_actions is not None:
            raise ValueError("native proof spine refuses Gym actions")
        while not self.calendar.empty() and k.current_time and k.current_time <= k.stop_time:
            if max_pops is not None and popped >= max_pops:
                return {"done": False, "result": None}
            event = self.calendar.pop_event()
            popped += 1
            k.current_time = event.time
            k.ttl_messages += 1
            self.increment(C_POP)
            k.current_agent_additional_delay = 0
            self.signal("pop", event, event.message)
            if k.agent_current_times[event.recipient] > k.current_time:
                event.time = k.agent_current_times[event.recipient]
                self.calendar.push_event(event)
                self.increment(C_REQUEUE)
                self.signal("requeue", event, event.message)
                continue
            k.agent_current_times[event.recipient] = k.current_time
            message = event.message
            if isinstance(message, WakeupMsg):
                k._current_causal_uid = message.message_id
                k._deliver_seq_by_key[message.message_id, event.recipient] = k._deliver_seq
                k._deliver_seq += 1
                k._msg_ledger.append_values(message.message_id, event.recipient, event.recipient,
                    None, k.current_time, 0, "AGENT_WAKEUP", None, None)
                self.signal("before_wake", event, message)
                if self.kinds[event.recipient] == 0:
                    result = k.agents[event.recipient].wakeup(k.current_time)
                else:
                    result = self.wake(k.agents[event.recipient])
                k.agent_current_times[event.recipient] += k.agent_computation_delays[event.recipient] + k.current_agent_additional_delay
                self.signal("after_wake", event, message)
                if result is not None:
                    return {"done": False, "result": result}
            else:
                messages = message.messages if isinstance(message, MessageBatch) else [message]
                for message in messages:
                    self.deliver(event, message)
        return {"done": True, "result": None}

    def transition_wake(self, recipient):
        return self.wake(self.kernel.agents[recipient])

    def transition_receive(self, recipient, sender, message):
        self.receive(self.kernel.agents[recipient], sender, message, self.kinds[recipient])


class NativeSpineKernel(CanonicalKernel):
    """Python-compatible facade around a real compiled continuous core."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.agents or type(self.agents[0]) is not ExchangeAgent:
            raise ValueError("native spine requires the pinned exchange first")
        if any(type(a) not in STRATEGIES for a in self.agents[1:]):
            raise ValueError("native spine refuses unknown strategies")
        if [a.id for a in self.agents] != list(range(len(self.agents))):
            raise ValueError("native spine requires canonical dense IDs")
        if any(type(a.id) is not int for a in self.agents):
            raise ValueError("native spine requires builtin integer IDs")
        if self.gym_agents or logger.isEnabledFor(10) or self.show_trace_messages:
            raise ValueError("native spine refuses Gym/debug mode")
        from admission import admit_episode
        admit_episode(self)
        self._native_core = NativeCore(self)
        self.messages = self._native_core.get_calendar()

    def send_message(self, sender_id, recipient_id, message, delay=0):
        self._native_core.send_message(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        self._native_core.set_wakeup(sender_id, requested_time)

    def runner(self, agent_actions=None):
        return self._native_core.run(agent_actions)

    def terminate(self):
        result = super().terminate()
        from installed import capture_episode
        capture_episode(self)
        return result

    def logical_calendar(self):
        return self.messages.logical_queue()

    def path_witness(self):
        return self._native_core.path_witness()

    def _seed_proof_counters(self, values):
        return self._native_core._seed_proof_counters(values)

    def set_debug_hook(self, hook):
        self._native_core.set_debug_hook(hook)

    def run_one_pop(self):
        return self._native_core.run(max_pops=1)

    def transition_wake(self, recipient):
        return self._native_core.transition_wake(recipient)

    def transition_receive(self, recipient, sender, message):
        self._native_core.transition_receive(recipient, sender, message)
