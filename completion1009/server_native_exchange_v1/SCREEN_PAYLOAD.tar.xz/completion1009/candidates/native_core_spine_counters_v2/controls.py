#!/usr/bin/env python3
"""Serial finite/full-market proof controller; keep every failure artifact."""
import argparse
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys
from provenance import HERE, sha, candidate_sources

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    output = Path(args.out).resolve()
    if output.exists():
        raise ValueError("control evidence exists; preserve prior attempt")
    output.mkdir(parents=True)
    before = candidate_sources()
    result = {"all_passed": False, "proof_only": True, "rankable": False, "official_gate": False,
        "timing_claim": False, "candidate_sources": before, "cases": [], "failures": []}
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    def launch(script, arguments, log):
        with log.open("w") as stream:
            command = [sys.executable, str(HERE / script), *arguments]
            completed = subprocess.run(command, cwd=HERE, env=environment, stdout=stream,
                stderr=subprocess.STDOUT, timeout=180)
        if completed.returncode:
            raise ValueError("control failed; see " + str(log))
    try:
        launch("finite_controls.py", ["--out", str(output / "FINITE_RESULT.json")], output / "finite.log")
        finite = json.loads((output / "FINITE_RESULT.json").read_text())
        if finite.get("all_passed") is not True or not finite.get("native_receipt"):
            raise ValueError("finite controls lack successful actual native receipt")
        for arm in ("canonical", "native"):
            directory = output / arm
            directory.mkdir()
            launch("control_worker.py", ["--arm", arm, "--out", str(directory)], directory / "run.log")
        import pandas as pd
        values = [pickle.loads((output / arm / "VALUES.pkl").read_bytes()) for arm in ("canonical", "native")]
        original_values, native_values = values
        if len(original_values) != 4 or len(native_values) != 4:
            raise ValueError("full-market roster incomplete")
        for original, native in zip(original_values, native_values):
            assert original["seed"] == native["seed"]
            assert original["stats"]["ttl_messages"] == native["stats"]["ttl_messages"]
            for a, b in zip(original["frames"], native["frames"]):
                pd.testing.assert_frame_equal(a, b, check_exact=True, check_dtype=True, rtol=0, atol=0)
            for label, a, b in zip(("Parquet bytes", "business graph and aliases", "RNG", "IDs", "warnings"), original["payload"], native["payload"]):
                assert a == b, label + " differs: " + str(original["seed"])
            witness = native["stats"]["native_witness"]
            assert witness["native_active"] is True and witness["fallback_used"] is False
            assert witness["extension_sha256"] == finite["native_receipt"]["extension_sha256"]
            result["cases"].append({"seed": native["seed"], "passed": True, **native["stats"]})
        assert candidate_sources() == before, "candidate source changed during controls"
        result.update(all_passed=True, finite_cases=len(finite["cases"]),
            sources_unchanged=True, native_receipt=finite["native_receipt"])
    except Exception as error:
        result["failures"].append({"type": type(error).__name__, "message": str(error)})
    result["controls_sha256"] = sha(__file__)
    (output / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
    return 0 if result["all_passed"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
