"""Source-prepared original/native exchange controls; no module import runs cases.

The native arm uses production sends and pops, with only the inherited test hook
observing after_receive. The reference arm uses the original handler through
the inherited one-pop fixture. These are finite proof cases, not timed markets.
"""
from copy import deepcopy
from collections import defaultdict
import logging
import types
import warnings


def business_graph(value, kernel, finite, seen=None):
    """One shared alias graph over original owners and actual raw references.

    Queue cells are structural records in both arms: synthetic Python tuples,
    native envelopes and calendar storage are private representations. Each
    record still descends into the actual message, preserving its graph aliases.
    """
    seen = {} if seen is None else seen
    def descend(item):
        return business_graph(item, kernel, finite, seen)
    np = finite.np
    if value is None or type(value) in (int, str, bool):
        return [type(value).__name__, value]
    if type(value) is float:
        return ["float", value.hex()]
    if isinstance(value, np.generic):
        return [type(value).__name__, descend(value.item())]
    if type(value) is finite.Side:
        return ["Side", value.value]
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)):
        return ["binding", getattr(value, "__module__", ""),
            getattr(value, "__qualname__", getattr(value, "__name__", ""))]
    if id(value) in seen:
        return ["ref", seen[id(value)]]
    serial = len(seen)
    seen[id(value)] = serial
    if isinstance(value, np.random.RandomState):
        return ["RandomState", serial, finite.encode(value.get_state())]
    if isinstance(value, np.ndarray):
        return ["ndarray", serial, str(value.dtype), list(value.shape), value.tobytes().hex()]
    if value is kernel:
        excluded = {"messages", "_native_core", "kernel_wall_clock_start",
            "event_queue_wall_clock_start", "log_dir"}
        fields = [(name, descend(item)) for name, item in vars(value).items() if name not in excluded]
        rows = kernel.logical_calendar() if hasattr(kernel, "logical_calendar") else kernel.messages.queue
        records = [[descend(time), descend(sender), descend(recipient), descend(message)]
            for time, sender, recipient, message in rows]
        fields.append(("logical_calendar_records", records))
        return ["logical_kernel", serial, fields]
    if isinstance(value, dict):
        items = [(descend(key), descend(item)) for key, item in value.items()
            if not (value is kernel.custom_state and key == "kernel_event_queue_elapsed_wallclock")]
        if type(value) is defaultdict:
            return ["defaultdict", serial, descend(value.default_factory), items]
        if type(value) is not dict:
            raise TypeError("uncovered dictionary owner: " + type(value).__name__)
        return ["dict", serial, items]
    if type(value) in (list, tuple):
        return [type(value).__name__, serial, [descend(item) for item in value]]
    if type(value) in (set, frozenset):
        return [type(value).__name__, serial, sorted([finite.encode(item) for item in value], key=repr)]
    if hasattr(value, "__dict__"):
        return [type(value).__module__, type(value).__name__, serial,
            [(name, descend(item)) for name, item in vars(value).items()]]
    raise TypeError("uncovered exchange graph value: " + type(value).__name__)


def run_cases(finite):
    from abides_core.message import Message, MessageBatch
    from abides_fork.config import ScenarioLatencyModel, build_config
    from abides_markets.orders import Order, LimitOrder, MarketOrder, Side
    from abides_markets.messages.order import (LimitOrderMsg, CancelOrderMsg,
        MarketOrderMsg, ModifyOrderMsg, PartialCancelOrderMsg, ReplaceOrderMsg)
    from abides_markets.messages.orderbook import OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg
    from abides_markets.messages.market import MarketClosedMsg
    from abides_markets.messages.marketdata import L1DataMsg
    from abides_markets.agents.exchange_agent import logger as exchange_logger
    from abides_core.agent import logger as agent_logger

    class LimitSubclass(LimitOrderMsg):
        pass
    class CancelSubclass(CancelOrderMsg):
        pass

    results = []

    def prepare(native, spec):
        kernel, agent = finite.setup(1, native)
        exchange = kernel.agents[0]
        kernel.agent_latency_model = ScenarioLatencyModel(2,
            {"model": "deterministic", "params": {"mean_ns": 0}}, finite.np.random.RandomState(33009))
        kernel.current_time = spec.get("time", 120)
        exchange.log_orders = spec.get("log_orders", True)
        exchange.log_events = spec.get("log_events", True)
        exchange.pipeline_delay = spec.get("pipeline", 0)
        exchange.computation_delay = spec.get("compute", 0)
        exchange.stp_policy = spec.get("stp")
        exchange.log.clear()
        kernel.agent_computation_delays[:] = [0, 0]
        exchange.order_books["ABM"].last_trade = 100
        if spec.get("subscription"):
            exchange.data_subscriptions["ABM"].append(exchange.L1DataSubscription(1, 100, 0))
        if spec.get("publish_error"):
            # Test-only malformed subscription: the original publication method
            # must raise after any book/ack/history/input-log work has committed.
            exchange.data_subscriptions["ABM"].append({"invalid_subscription": True})
        refs = {"orders": [], "metadata": {"quantity": 7, "price": 99, "nested": [1]}, "messages": []}
        def limit(quantity=7, side=Side.BID, price=99, symbol="ABM", owner=1, **kwargs):
            order = LimitOrder(owner, 110, symbol, quantity, side, price, **kwargs)
            refs["orders"].append(order)
            if owner == 1:
                agent.orders[order.order_id] = deepcopy(order)
            return order
        label = spec["operation"]
        if label.startswith("cross") or label.startswith("stp") or label == "post_only":
            resting = limit(5, Side.ASK, 100)
            quantity = {"cross_partial": 2, "cross_full": 5, "cross_residual": 9}.get(label, 7)
            incoming = limit(quantity, Side.BID, 100,
                tag="MR_preprocess_ADD" if label == "post_only" else None)
            messages = [LimitOrderMsg(resting), LimitOrderMsg(incoming)]
        elif label.startswith("cancel") or label in ("modify", "partial_cancel", "replace"):
            side = Side.ASK if label == "cancel_ask" else Side.BID
            original = limit(side=side)
            request = deepcopy(original)
            refs["orders"].append(request)
            if label == "cancel_missing":
                request.order_id += 500
            if label == "cancel_wrong_price":
                request.limit_price += 1
            cancel_type = CancelSubclass if label == "cancel_subclass" else CancelOrderMsg
            cancel = cancel_type(request, "auctionFill" if label == "cancel_auction" else None,
                refs["metadata"] if label in ("cancel_auction", "cancel_subclass") else None)
            messages = [] if label in ("cancel_missing", "cancel_closed", "cancel_unknown") else [LimitOrderMsg(original)]
            if label == "cancel_unknown":
                request.symbol = "UNKNOWN"
            if label == "modify":
                changed = deepcopy(request); changed.quantity = 3
                refs["orders"].append(changed)
                messages.append(ModifyOrderMsg(request, changed))
            elif label == "partial_cancel":
                messages.append(PartialCancelOrderMsg(request, 2, "auctionFill", refs["metadata"]))
            elif label == "replace":
                replacement = limit(3, Side.BID, 98)
                messages.append(ReplaceOrderMsg(1, request, replacement))
            else:
                messages.append(cancel)
        elif label == "market":
            resting = limit(5, Side.ASK, 100)
            incoming = MarketOrder(1, 110, "ABM", 2, Side.BID)
            refs["orders"].append(incoming)
            agent.orders[incoming.order_id] = deepcopy(incoming)
            messages = [LimitOrderMsg(resting), MarketOrderMsg(incoming)]
        else:
            options = {"quantity": spec.get("quantity", 7), "price": spec.get("price", 99),
                "symbol": spec.get("symbol", "ABM"), "owner": spec.get("owner", 1)}
            if label == "hidden":
                options["is_hidden"] = True
            if label == "price_to_comply":
                options["is_price_to_comply"] = True
            if label == "mutable_tag":
                options["tag"] = refs["metadata"]
            order = limit(**options)
            if label == "dynamic_attribute":
                order.extra_dynamic = refs["metadata"]
            messages = [(LimitSubclass if label == "limit_subclass" else LimitOrderMsg)(order)]
        refs["messages"] = messages
        batch = MessageBatch(messages)
        refs["batch"] = batch
        assert batch.messages is messages
        return kernel, agent, exchange, refs

    def snapshot(kernel, refs, observed, records):
        ids = [Order._order_id_counter, Message._Message__message_id_counter]
        state = business_graph([kernel.agents, kernel, refs], kernel, finite)
        assert ids == [Order._order_id_counter, Message._Message__message_id_counter]
        return {"business_graph": state, "global_rng": finite.encode(finite.np.random.get_state()),
            "ids": ids, "warnings": [(item.category.__name__, str(item.message)) for item in observed],
            "debug_records": list(records)}

    def execute(native, spec):
        kernel, agent, exchange, refs = prepare(native, spec)
        phases, records = [], []
        current_log = agent_logger if spec.get("base_debug") else exchange_logger
        class Capture(logging.Handler):
            def emit(self, record):
                records.append(record.getMessage())
                if spec.get("debug_changes_kernel_clock"):
                    kernel.current_time = 1001
        handler = Capture()
        saved = (current_log.level, current_log.propagate, current_log.disabled)
        if spec.get("debug") or spec.get("base_debug"):
            current_log.setLevel(logging.DEBUG)
            current_log.propagate = False
            current_log.disabled = False
            current_log.addHandler(handler)
        error = None
        try:
            with warnings.catch_warnings(record=True) as observed:
                warnings.simplefilter("error" if spec.get("warning_error") else "always")
                def after(phase, current, event, message):
                    if phase == "after_receive":
                        if spec.get("additional_delay") and len(phases) == 0:
                            current.current_agent_additional_delay += spec["additional_delay"]
                        phases.append(snapshot(current, refs, observed, records))
                if native:
                    kernel.set_debug_hook(after)
                kernel.send_message(spec.get("sender", 1), 0, refs["batch"])
                try:
                    kernel.run_one_pop() if native else finite.reference_one_pop(kernel, after)
                except Exception as failure:
                    error = (type(failure).__name__, str(failure))
                finally:
                    if native:
                        kernel.set_debug_hook(None)
                final = snapshot(kernel, refs, observed, records)
                if spec["operation"] == "cancel_auction" and error is None:
                    assert exchange.order_books["ABM"].history[-1]["metadata"] is refs["metadata"]
                    refs["metadata"]["nested"].append(2)
                    phases.append(snapshot(kernel, refs, observed, records))
            if spec.get("warning_error"):
                assert error is not None and error[0] == "UserWarning"
            elif spec.get("publish_error"):
                assert error == ("Exception", "Got invalid data subscription object")
            elif spec.get("expected_error"):
                assert error is not None and error[0] == spec["expected_error"]
            else:
                assert error is None, (spec["name"], error)
            if spec.get("debug") or spec.get("base_debug"):
                assert records and any("received" in text for text in records), spec["name"]
            if spec.get("debug_changes_kernel_clock"):
                assert kernel.current_time == 1001 and exchange.current_time == spec.get("time", 120)
                assert exchange.order_books["ABM"].history[0]["time"] == spec.get("time", 120)
            if native:
                witness = kernel.path_witness()
                expected = {"limit": any(type(message) is LimitOrderMsg for message in refs["messages"]),
                    "cancel": any(type(message) is CancelOrderMsg for message in refs["messages"])}
                # A publish/warning exception may stop a batch before a later
                # direct message. These error cases have exactly one message.
                assert witness["exchange_direct_observed"] == expected
                assert witness["exchange_receive_implementation"] == "cdef_limit_cancel_python_book_owner"
                assert witness["counts"]["exchange_book_bridge"] == len(phases) - (1 if spec["operation"] == "cancel_auction" and error is None else 0) + (error is not None)
                assert witness["counts"]["pop"] == kernel.ttl_messages == 1
            if spec.get("time", 120) > exchange.mkt_close and error is None:
                rows = kernel.logical_calendar() if native else kernel.messages.queue
                replies = [row for row in rows if isinstance(row[3], MarketClosedMsg)]
                assert len(replies) == len(refs["messages"])
                assert all(row[2] == spec.get("sender", 1) for row in replies)
                assert all(row[0] == spec.get("time", 120) + spec.get("compute", 0) for row in replies)
                assert not exchange.order_books["ABM"].history and not exchange.log
            if spec.get("subscription") and error is None:
                rows = kernel.logical_calendar() if native else kernel.messages.queue
                assert any(isinstance(row[3], L1DataMsg) for row in rows), spec["name"]
            if spec["name"] == "resting_ack_owner_differs_sender":
                rows = kernel.logical_calendar() if native else kernel.messages.queue
                accepted = [row for row in rows if isinstance(row[3], OrderAcceptedMsg)]
                assert len(accepted) == 1 and accepted[0][2] == 1
            if spec.get("additional_delay") and error is None:
                rows = kernel.logical_calendar() if native else kernel.messages.queue
                accepted = [row for row in rows if isinstance(row[3], OrderAcceptedMsg)]
                cancelled = [row for row in rows if isinstance(row[3], OrderCancelledMsg)]
                assert len(accepted) == len(cancelled) == 1
                assert accepted[0][0] == spec.get("time", 120) + spec["compute"] + spec["pipeline"]
                assert cancelled[0][0] == accepted[0][0] + spec["additional_delay"]
                assert all(row[2] == 1 for row in accepted + cancelled)
            return {"phases": phases, "final": final, "error": error}
        finally:
            if spec.get("debug") or spec.get("base_debug"):
                current_log.removeHandler(handler)
                current_log.setLevel(saved[0])
                current_log.propagate, current_log.disabled = saved[1:]

    specs = [
        {"name": "resting_default", "operation": "limit", "log_orders": False},
        {"name": "resting_log_none", "operation": "limit", "log_orders": None},
        {"name": "resting_order_logs", "operation": "limit"},
        {"name": "resting_ack_owner_differs_sender", "operation": "limit", "sender": 0},
        {"name": "resting_log_events_false", "operation": "limit", "log_events": False},
        {"name": "preopen_allowed", "operation": "limit", "time": 50},
        {"name": "at_close_allowed", "operation": "limit", "time": 1000},
        {"name": "after_close_rejected", "operation": "limit", "time": 1001},
        {"name": "after_close_unknown_no_warning", "operation": "limit", "time": 1001, "symbol": "UNKNOWN"},
        {"name": "after_close_cancel_reply_sender", "operation": "cancel_closed", "time": 1001, "sender": 0},
        {"name": "after_close_limit_compute_without_pipeline_debug", "operation": "limit", "time": 1001,
            "sender": 0, "compute": 700, "pipeline": 3000, "debug": True},
        {"name": "after_close_cancel_compute_without_pipeline", "operation": "cancel_closed", "time": 1001,
            "sender": 0, "compute": 700, "pipeline": 3000},
        {"name": "cross_partial", "operation": "cross_partial"},
        {"name": "cross_full", "operation": "cross_full"},
        {"name": "cross_residual", "operation": "cross_residual"},
        {"name": "cancel_bid", "operation": "cancel_bid"},
        {"name": "cancel_ask", "operation": "cancel_ask"},
        {"name": "cancel_missing", "operation": "cancel_missing"},
        {"name": "cancel_wrong_price", "operation": "cancel_wrong_price"},
        {"name": "cancel_auction_metadata_live_alias", "operation": "cancel_auction"},
        {"name": "unknown_limit", "operation": "limit", "symbol": "UNKNOWN"},
        {"name": "unknown_cancel", "operation": "cancel_unknown"},
        {"name": "zero_quantity", "operation": "limit", "quantity": 0},
        {"name": "noninteger_quantity", "operation": "limit", "quantity": 2.5},
        {"name": "negative_price", "operation": "limit", "price": -1},
        {"name": "noninteger_price", "operation": "limit", "price": 99.5},
        {"name": "unknown_warning_exception_residue", "operation": "limit", "symbol": "UNKNOWN", "warning_error": True},
        {"name": "unknown_cancel_warning_exception_residue", "operation": "cancel_unknown", "warning_error": True},
        {"name": "invalid_warning_exception_residue", "operation": "limit", "quantity": 0, "warning_error": True},
        {"name": "nan_quantity_conversion_exception_residue", "operation": "limit", "quantity": float("nan"), "expected_error": "ValueError"},
        {"name": "publish_exception_after_accepted_residue", "operation": "limit", "publish_error": True},
        {"name": "publish_exception_after_invalid_residue", "operation": "limit", "quantity": 0, "publish_error": True},
        {"name": "publish_exception_after_missing_cancel_residue", "operation": "cancel_missing", "publish_error": True},
        {"name": "stp_cancel_newest", "operation": "stp_newest", "stp": "cancel_newest"},
        {"name": "stp_cancel_oldest", "operation": "stp_oldest", "stp": "cancel_oldest"},
        {"name": "ack_compute_additional_batch_delay", "operation": "cancel_bid", "pipeline": 3000, "compute": 700, "additional_delay": 37},
        {"name": "l1_publication_valid", "operation": "limit", "subscription": True},
        {"name": "l1_publication_invalid", "operation": "limit", "quantity": 0, "subscription": True},
        {"name": "l1_publication_missing_cancel", "operation": "cancel_missing", "subscription": True},
        {"name": "hidden_limit", "operation": "hidden"},
        {"name": "price_to_comply_limit", "operation": "price_to_comply"},
        {"name": "post_only_tag", "operation": "post_only"},
        {"name": "limit_subclass_original_handler", "operation": "limit_subclass"},
        {"name": "cancel_subclass_original_handler", "operation": "cancel_subclass"},
        {"name": "market_original_handler", "operation": "market"},
        {"name": "modify_original_handler", "operation": "modify"},
        {"name": "partial_cancel_original_handler", "operation": "partial_cancel"},
        {"name": "replace_original_handler", "operation": "replace"},
        {"name": "exchange_debug_retained", "operation": "limit", "debug": True},
        {"name": "base_debug_retained", "operation": "limit", "base_debug": True},
        {"name": "base_debug_argument_clock_retained", "operation": "limit", "base_debug": True, "debug_changes_kernel_clock": True},
        {"name": "cancel_logs_false", "operation": "cancel_bid", "log_orders": False},
        {"name": "cancel_log_events_false", "operation": "cancel_bid", "log_events": False},
        {"name": "dynamic_order_attribute_copy_omission", "operation": "dynamic_attribute"},
        {"name": "mutable_tag_copy_and_graph", "operation": "mutable_tag"},
    ]
    for spec in specs:
        canonical, native = execute(False, spec), execute(True, spec)
        assert canonical == native, "exchange original/native mismatch: " + spec["name"]
        results.append({"name": "exchange_" + spec["name"], "passed": True})

    # Validate the official opt-in configuration knobs with the real original
    # builder, without running a market. Both cases are after native admission.
    for enabled in (False, True):
        finite.reset()
        config = build_config({"scenario_id": "exchange-protocol-builder", "seed": 39009,
            "horizon_ns": 2000, "exchange_config": {"symbol": "ABM",
                "protocol_enforcement": enabled, "stp_policy": "cancel_oldest",
                "ack_delay_ns": 3000, "compute_delay_ns": 700},
            "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100,
                "kappa": .05, "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}},
            "latency_config": {"model": "deterministic", "params": {"mean_ns": 0}},
            "agent_configs": [{"agent_type": "NoiseTrader", "count": 1, "params": {}}]})
        exchange = config["agents"][0]
        assert (exchange.stp_policy, exchange.pipeline_delay, exchange.computation_delay) == (
            ("cancel_oldest", 3000, 700) if enabled else (None, 0, 0))
        results.append({"name": "exchange_official_protocol_" + ("enabled" if enabled else "disabled") + "_builder_knobs", "passed": True})
    return results
