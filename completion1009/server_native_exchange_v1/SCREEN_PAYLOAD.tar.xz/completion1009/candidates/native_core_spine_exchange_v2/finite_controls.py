#!/usr/bin/env python3
"""Untimed source-prepared finite controls; native receipt is mandatory."""
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "runtime"))
from bootstrap import activate
activate()
import argparse
from copy import deepcopy
import heapq
import json
import warnings
import numpy as np
from abides_core import abides
from abides_core.message import Message, MessageBatch, WakeupMsg
from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
from abides_fork.config import ScenarioLatencyModel
from abides_markets.agents.exchange_agent import ExchangeAgent
from abides_markets.orders import Order, LimitOrder, Side
from abides_markets.oracles.sparse_mean_reverting_oracle import SparseMeanRevertingOracle
from abides_markets.messages.market import MarketHoursMsg, MarketClosePriceMsg
from abides_markets.messages.query import QuerySpreadResponseMsg
from abides_markets.messages.orderbook import OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg
from t3_canonical_engine import CanonicalKernel
from installed import authenticate, ensure_native_admission, enabled
from provenance import sha, candidate_sources

NATIVE = None

def encode(value):
    if value is None or type(value) in (int, str, bool):
        return [type(value).__name__, value]
    if type(value) is float:
        return ["float", value.hex()]
    if isinstance(value, np.generic):
        return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.random.RandomState):
        return ["RandomState", encode(value.get_state())]
    if isinstance(value, np.ndarray):
        return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if type(value) is Side:
        return ["Side", value.value]
    if type(value) in (list, tuple):
        return [type(value).__name__, [encode(item) for item in value]]
    if isinstance(value, dict):
        return ["dict", [[encode(key), encode(item)] for key, item in value.items()]]
    if hasattr(value, "__dict__"):
        return [type(value).__name__, encode({key: item for key, item in vars(value).items() if key != "kernel"})]
    return [type(value).__name__, str(value)]

def reset():
    Order._order_id_counter = 0
    Message._Message__message_id_counter = 1

def oracle():
    return SparseMeanRevertingOracle(100, 2000, {"ABM": {"r_bar": 100, "kappa": .01,
        "fund_vol": .01, "megashock_lambda_a": .01, "megashock_mean": 0,
        "megashock_var": 0, "random_state": np.random.RandomState(35009)}})

def setup(kind, native, ready=True, closed=False, bids=None, asks=None):
    reset()
    np.random.seed(36009)
    cls = (NoiseTrader, MarketMaker, ValueTrader, MomentumTrader)[kind - 1]
    agent = cls(id=1, name="CTRL", type=cls.__name__, symbol="ABM", starting_cash=10000,
        random_state=np.random.RandomState(31009), interval_ns=100)
    exchange = ExchangeAgent(0, 100, 1000, ["ABM"], random_state=np.random.RandomState(32009), log_orders=None)
    latency = ScenarioLatencyModel(2, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 7}},
        np.random.RandomState(33009))
    with enabled(native):
        kernel = abides.Kernel([exchange, agent], start_time=1, stop_time=2000,
            random_state=np.random.RandomState(34009), agent_latency_model=latency,
            custom_properties={"oracle": oracle()})
    exchange.kernel = agent.kernel = kernel
    agent.exchange_id = 0
    agent.oracle = kernel.oracle
    agent.mkt_open, agent.mkt_close = (100, 1000) if ready else (None, None)
    agent.mkt_closed = closed
    agent.current_time = kernel.current_time = 120
    kernel.ttl_messages = 0
    agent.known_bids["ABM"], agent.known_asks["ABM"] = bids or [], asks or []
    if kind == 4:
        agent._mid_history.extend([98., 99., 99., 100., 100.])
    return kernel, agent

def snapshot(kernel, agent):
    queue = kernel.logical_calendar() if hasattr(kernel, "logical_calendar") else kernel.messages.queue
    return {"agent": encode({key: item for key, item in vars(agent).items() if key != "kernel"}),
        "queue": encode(queue), "ledger": encode(kernel._msg_ledger.columns),
        "latency_rng": encode(kernel.agent_latency_model.random_state.get_state()),
        "ids": [Order._order_id_counter, Message._Message__message_id_counter],
        "global_rng": encode(np.random.get_state()), "oracle": encode(vars(kernel.oracle)),
        "kernel_times": encode([kernel.current_time, kernel.ttl_messages, kernel.agent_current_times,
            kernel.agent_computation_delays, kernel.current_agent_additional_delay,
            kernel._deliver_seq, kernel._deliver_seq_by_key, kernel._current_causal_uid])}

def calendar_cases():
    result = []
    for label, times in (("builtin_huge", [10**400, 10**400, -2, 8]),
                         ("numpy_scalar", [np.int64(8), np.int64(8), np.int64(-2), np.int64(9)])):
        reset()
        calendar, ref = NATIVE.TypedCalendar(), []
        first = WakeupMsg()
        messages = [first, first, WakeupMsg(), WakeupMsg()]
        for time, message in zip(times, messages):
            heapq.heappush(ref, (time, 1, 1, message))
            calendar.push(time, 1, 1, message)
        while ref:
            expected, actual = heapq.heappop(ref), calendar.pop()
            assert encode(expected) == encode(actual) and expected[3] is actual[3]
        result.append({"name": "calendar_" + label + "_shared_raw_identity", "passed": True})
    # Dataclass equality is not reducible to the UID alone. Equal payloads and
    # same UID/different payloads must both follow actual tuple rich comparison.
    reset()
    calendar, ref = NATIVE.TypedCalendar(), []
    first, second, third = MarketClosePriceMsg({"ABM": 1}), MarketClosePriceMsg({"ABM": 1}), MarketClosePriceMsg({"ABM": 2})
    second.message_id = third.message_id = first.message_id
    for message in (first, second, third, first):
        heapq.heappush(ref, (1, 1, 1, message))
        calendar.push(1, 1, 1, message)
    while ref:
        assert heapq.heappop(ref)[3] is calendar.pop()[3]
    result.append({"name": "calendar_actual_dataclass_equality_sameuid_and_broadcast", "passed": True})
    return result

def transition_cases():
    results = []
    for kind in (1, 2, 3, 4):
        for operation, ready, closed, bids, asks in (
            ("wake_initial", False, False, [], []), ("wake_open", True, False, [(99, 3)], [(101, 4)]),
            ("wake_closed", True, True, [(99, 3)], [(101, 4)]), ("spread_empty", True, False, [], []),
            ("spread_bid", True, False, [(99, 3)], []), ("spread_ask", True, False, [], [(101, 4)]),
            ("spread_both", True, False, [(99, 3)], [(101, 4)]), ("spread_closed", True, True, [(99, 3)], [(101, 4)])):
            values = []
            for native in (False, True):
                kernel, agent = setup(kind, native, ready, closed, bids, asks)
                if operation.startswith("wake"):
                    kernel.transition_wake(1) if native else agent.wakeup(120)
                else:
                    agent.state = "AWAITING_SPREAD"
                    message = QuerySpreadResponseMsg("ABM", closed, 1, bids, asks, 100)
                    kernel.transition_receive(1, 0, message) if native else agent.receive_message(120, 0, message)
                values.append(snapshot(kernel, agent))
            assert values[0] == values[1], "transition mismatch: " + str(kind) + "/" + operation
            results.append({"name": "strategy_" + str(kind) + "_" + operation, "passed": True})
    return results

def notification_cases():
    result = []
    for kind in (1, 2, 3, 4):
        for cls, quantity, side, owned in ((OrderAcceptedMsg, 7, Side.BID, True),
            (OrderExecutedMsg, 2, Side.BID, True), (OrderExecutedMsg, 7, Side.ASK, True),
            (OrderExecutedMsg, 9, Side.BID, False), (OrderCancelledMsg, 7, Side.BID, True),
            (OrderCancelledMsg, 7, Side.ASK, False)):
            values = []
            for native in (False, True):
                kernel, agent = setup(kind, native, bids=[(99, 3)], asks=[(101, 4)])
                order = LimitOrder(1, 110, "ABM", 7, side, 100)
                if owned:
                    agent.orders[order.order_id] = deepcopy(order)
                report = deepcopy(order)
                report.quantity, report.fill_price = quantity, 101
                message = cls(report)
                with warnings.catch_warnings(record=True) as observed:
                    warnings.simplefilter("always")
                    kernel.transition_receive(1, 0, message) if native else agent.receive_message(120, 0, message)
                values.append([snapshot(kernel, agent), [(item.category.__name__, str(item.message)) for item in observed]])
            assert values[0] == values[1], "notification mismatch: " + cls.__name__
            result.append({"name": "strategy_" + str(kind) + "_" + cls.__name__ + "_" + str(quantity) + "_" + str(owned), "passed": True})
    return result

def reference_one_pop(kernel, hook=None):
    """Test-only original scheduler fixture; native arm uses production run."""
    if kernel.messages.empty() or not kernel.current_time or kernel.current_time > kernel.stop_time:
        return
    kernel.current_time, sender, recipient, message = heapq.heappop(kernel.messages.queue)
    kernel.ttl_messages += 1
    kernel.current_agent_additional_delay = 0
    if kernel.agent_current_times[recipient] > kernel.current_time:
        heapq.heappush(kernel.messages.queue, (kernel.agent_current_times[recipient], sender, recipient, message))
        return
    kernel.agent_current_times[recipient] = kernel.current_time
    if isinstance(message, WakeupMsg):
        kernel._current_causal_uid = message.message_id
        kernel._deliver_seq_by_key[message.message_id, recipient] = kernel._deliver_seq
        kernel._deliver_seq += 1
        kernel._msg_ledger.append_values(message.message_id, recipient, recipient, None, kernel.current_time,
            0, "AGENT_WAKEUP", None, None)
        kernel.agents[recipient].wakeup(kernel.current_time)
        kernel.agent_current_times[recipient] += kernel.agent_computation_delays[recipient] + kernel.current_agent_additional_delay
    else:
        messages = message.messages if isinstance(message, MessageBatch) else [message]
        for sub in messages:
            kernel.agent_current_times[recipient] += kernel.agent_computation_delays[recipient] + kernel.current_agent_additional_delay
            kernel._current_causal_uid = sub.message_id
            kernel._deliver_seq_by_key[sub.message_id, recipient] = kernel._deliver_seq
            kernel._deliver_seq += 1
            kernel.agents[recipient].receive_message(kernel.current_time, sender, sub)
            if hook is not None:
                hook("after_receive", kernel, (kernel.current_time, sender, recipient, message), sub)

def runner_cases():
    results = []
    for label, stop, busy, batch in (("batch_subuids", 140, 0, True),
                                   ("previous_clock_stop", 121, 0, False), ("busy_requeue", 200, 130, False)):
        values = []
        for native in (False, True):
            kernel, agent = setup(1, native, bids=[(99, 3)], asks=[(101, 4)])
            kernel.stop_time = stop
            kernel.agent_current_times[1] = busy
            kernel.agent_latency_model = ScenarioLatencyModel(2, {"model": "deterministic", "params": {"mean_ns": 0}}, np.random.RandomState(33009))
            if batch:
                message = MessageBatch([MarketHoursMsg(100, 1000), MarketClosePriceMsg({"ABM": 111})])
                kernel.send_message(0, 1, message)
            else:
                kernel.send_message(0, 1, MarketClosePriceMsg({"ABM": 111}), delay=-45 if busy else 0)
                kernel.send_message(0, 1, MarketClosePriceMsg({"ABM": 112}), delay=20)
            per_pop = []
            for _ in range(5):
                if native:
                    kernel.run_one_pop()
                else:
                    reference_one_pop(kernel)
                per_pop.append(snapshot(kernel, agent))
            values.append(per_pop)
        assert values[0] == values[1], "runner mismatch: " + label
        results.append({"name": "runner_per_pop_" + label, "passed": True})
    return results

def live_batch_case():
    values = []
    for native in (False, True):
        kernel, agent = setup(1, native, bids=[(99, 3)], asks=[(101, 4)])
        kernel.agent_latency_model = ScenarioLatencyModel(2, {"model": "deterministic", "params": {"mean_ns": 0}}, np.random.RandomState(33009))
        first = MarketClosePriceMsg({"ABM": 111})
        later = MarketClosePriceMsg({"ABM": 112})
        replacement = MarketClosePriceMsg({"ABM": 999})
        raw_list = [first]
        batch = MessageBatch(raw_list)
        kernel.send_message(0, 1, batch)
        witness = []
        def hook(phase, current, envelope, sub):
            if phase == "after_receive":
                witness.append((sub.message_id, current._current_causal_uid,
                    encode(current.agent_current_times[1]), encode(current.current_agent_additional_delay)))
                if sub is first:
                    raw_list.append(later)
                    batch.messages = [replacement]
                    current.current_agent_additional_delay += 7
                    current.agent_computation_delays[1] = 13
        if native:
            kernel.set_debug_hook(hook)
            kernel.run_one_pop()
            kernel.set_debug_hook(None)
        else:
            reference_one_pop(kernel, hook)
        assert agent.last_trade["ABM"] == 112 and batch.messages[0] is replacement
        assert len(witness) == 2 and witness[0][0] == first.message_id and witness[1][0] == later.message_id
        values.append([snapshot(kernel, agent), witness,
            raw_list[0] is first and raw_list[1] is later])
    assert values[0] == values[1], "live batch bound-list/delay mutation mismatch"
    return [{"name": "runner_live_batch_bound_list_rebind_per_subcallback_delay_and_uid", "passed": True}]

def mutation_cases():
    from admission import load_native, native_receipt
    from abides_markets.agents.trading_agent import TradingAgent
    result = []
    original = TradingAgent.cancel_order.__defaults__
    TradingAgent.cancel_order.__defaults__ = ("changed", {})
    try:
        try:
            load_native(native_receipt()["receipt_path"])
        except ValueError:
            pass
        else:
            raise AssertionError("mutated defaults admitted")
    finally:
        TradingAgent.cancel_order.__defaults__ = original
    result.append({"name": "admission_original_default_mutation_refused", "passed": True})
    original = NATIVE.TypedCalendar
    NATIVE.TypedCalendar = object
    try:
        try:
            load_native(native_receipt()["receipt_path"])
        except ValueError:
            pass
        else:
            raise AssertionError("replaced compiled export admitted")
    finally:
        NATIVE.TypedCalendar = original
    result.append({"name": "admission_compiled_export_replacement_refused", "passed": True})
    return result

def main():
    global NATIVE
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    destination = Path(args.out)
    if destination.exists():
        raise ValueError("finite evidence exists; preserve previous result")
    result = {"all_passed": False, "proof_only": True, "rankable": False, "timing_claim": False, "cases": [], "failures": []}
    before = candidate_sources()
    try:
        authenticate()
        NATIVE = ensure_native_admission()
        from admission import native_receipt
        result["native_receipt"] = native_receipt()
        result["cases"] = calendar_cases() + transition_cases() + notification_cases() + runner_cases() + live_batch_case() + mutation_cases()
        from counter_controls import run_cases
        result["cases"] += run_cases(sys.modules[__name__])
        from exchange_controls import run_cases as exchange_cases
        result["cases"] += exchange_cases(sys.modules[__name__])
        assert candidate_sources() == before, "candidate source changed during controls"
        result.update(all_passed=True, sources_unchanged=True)
    except Exception as error:
        result["failures"].append({"type": type(error).__name__, "message": str(error)})
    result["controls_sha256"] = sha(__file__)
    destination.write_text(json.dumps(result, indent=2) + "\n")
    return 0 if result["all_passed"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
