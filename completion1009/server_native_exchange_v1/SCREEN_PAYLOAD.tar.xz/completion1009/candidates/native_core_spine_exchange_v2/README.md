This v2 candidate preserves the failed v1 source separately and fixes only the two counter array bounds from the named enum value to the literal capacity 10. Cython 3.1.3 rejected the named bounds; the enum values, loops, increment positions and exact overflow behavior are unchanged. Full build and market checks are still pending.

This independent, unbuilt and untested candidate derives from the frozen `native_core_spine_counters_v2`, whose source preparation receipt is `85c0b984af7716c15b0e724c38f969e6100ee52183fb4aabb7bd284e173a4531`. It compiles the exact original ExchangeAgent receive dispatch for the two official LimitOrderMsg and CancelOrderMsg classes. The parent candidate and canonical runtime are untouched. Original Python agents, kernel and books remain sole business-state owners; matching, order copies, RNG, oracle, logs, subscriptions and output projection are preserved. The parent task alone schedules builds, simulations and timing. This candidate has no measured speed, rank or 230000 claim.

The inherited ten counters use uint64 slots and checked per-slot spill to Python arbitrary-precision integers. The common increment does not touch a Python dictionary. A slot at UINT64_MAX is boxed before Python `+ 1`, and its spill flag is published only after successful allocation/assignment; subsequent updates stay Python integer arithmetic. `path_witness` constructs a fresh dictionary with the original key order and builtin integer values. No original business integer, UID, timestamp, RNG or output value is narrowed. Increment positions are unchanged. The otherwise unused production `popped` integer is intentionally left unchanged to retain the parent scheduler scope.

The private `_seed_proof_counters` API is finite-test instrumentation: it validates the entire exact builtin dictionary and nonnegative builtin integers before committing, and permanently marks the core's witness as seeded. Production `capture_episode`, host probe and full-market controls reject marked witnesses. Tests use real scheduler/strategy operations across UINT64_MAX and 10**400; they do not claim passing merely by reading source.

## Scope and ownership

The new `cdef exchange_order` helper calls the exact inherited FinancialAgent/Agent base receive method, sets the original computation delay, rejects only times strictly after close before incoming order logging, then follows the original Limit/Cancel debug, unknown-symbol warning, order deepcopy, book call and publication order. Cancel tag and metadata are read at their original positions; metadata remains raw. The original outgoing exchange method still applies pipeline delay before acknowledgement logging. Unsupported message classes and subclasses use the original handler; the inherited query path is unchanged. This is compiled receive dispatch with Python-owned matching, not native matching.

Two sticky native bool fields mark direct limit/cancel dispatch entry, including rejected or failing receives. They are observational witnesses rather than success counts. The ten inherited counter meanings and increment positions stay intact; `exchange_book_bridge` still counts each non-query exchange dispatch because book work remains a Python bridge. `path_witness` labels the implementation `cdef_limit_cancel_python_book_owner`. Independently enabled base-agent and exchange debug log calls are retained.

`NativeSpineKernel` is a Python-compatible facade around the extension's `cdef NativeCore`. `TypedCalendar` holds typed envelope references and CPython-style heap sifts. An envelope strongly owns the actual original Message object; shared broadcasts, delayed cancellation orders and MessageBatch lists stay live. There is no compact arena, reconstruction UID, copied AgentState, clock mirror or synchronization phase.

Positions, dense builtin integer IDs, immutable strategy-kind metadata and checked private counter slots use native integer fields. Timestamp and business arithmetic stay Python objects, including NumPy scalar types, PyLong range, original operation association, normal warnings and exceptions. The core retains original raw Message/LimitOrder constructors and deepcopy calls. The initial exact `create_limit_order` local holdings calculation is preserved even when the original default skips its risk check.

Admission is strict for the whole episode. It requires frozen original sources and actual loaded Python callback/default/global/class bindings; exact original classes and no instance callback overrides; exchange first; four known strategies; dense builtin integer IDs; original dictionary owners, plain initial limit orders, matching/oracle/latency owners; no Gym, kernel DEBUG or trace-message mode. It refuses unsupported input before `initialize`. This prototype has no midstream fallback. Canonical is a separate explicit arm.

The admitted producer domain is the official validated fixed scenario configuration and original callbacks. Arbitrary external scheduler calls with custom sender/recipient scalars, hostile numeric/message subclasses, arbitrary private heap mutation or comparison-triggered reentrant mutation are outside this proof scope. Deepcopy/pickle of the entire agent→kernel→native-core graph is also outside the current controls. Actual dataclass equality and shared raw identity are retained and prepared for testing. `TypedCalendar.queue` is a diagnostic logical snapshot; mutation of that private representation is excluded. Logical queue values, message types/IDs and raw reference aliases remain observable controls.

## Native provenance

An optimized arm can load only an actual `ExtensionFileLoader` image named `native_spine`, compiled for the current CPython 3.11 ABI with Cython 3.1.3. The successful build receipt binds the candidate source inventory, frozen snapshot and source-binding evidence, generated C hashes, native extension bytes/hash, exact ABI, package version pins, compiler configuration, directives and flags. Native export identity/default/constant mutations and original callback/default/constant mutations are checked. Package metadata versions are pins; they are not a claim that third-party NumPy/SciPy native image bytes were independently audited.

The frozen 62-file runtime is copied by `prepare_snapshot.py` only after its full manifest passes, and its Python modules remain source modules for this proof. No existing direct-v2, canonical runtime or previous Linux screen is changed. `preflight.py` prepares independent source/default/binding pins; native provenance is checked separately and never treats a Python `FunctionType` fixture as compiled evidence.

## Explicit Linux preparation and controls

The parent task stages this entire directory beside the unchanged `completion1009/RUNTIME_MANIFEST.json` and `completion1009/runtime`. In a fresh CPython 3.11 Linux environment with the versions in `compile_spec.json` and Cython 3.1.3, the scheduled commands are:

```sh
python3.11 prepare_snapshot.py
python3.11 preflight.py
python3.11 build_native.py --out artifacts/build_v1
export NATIVE_SPINE_BUILD_RECEIPT="$PWD/artifacts/build_v1/BUILD_RECEIPT.json"
python3.11 controls.py --out controls/attempt_v1
```

These are prepared recipes, not executed receipts. Every output directory is new; existing results or failed builds are refused and preserved. Build runs generate into `artifacts/build_v1/generated`, `objects`, and `native`; no inplace extension or generated C is written into the frozen runtime. Arithmetic flags are `-O2 -fPIC -fno-fast-math -ffp-contract=off`; semantic checks and `infer_types=False`, `annotation_typing=False`, `cdivision=False` remain enabled.

`controls.py` first requires actual native finite controls, then runs canonical/native full markets in separate serial processes. It compares exact trace/message DataFrames, dtypes and Parquet bytes, complete logical business graph and aliases, all RNG states, ID counters, warnings and actual event-pop totals. It requires native strategy, original book-bridge and actual direct Limit/Cancel dispatch witnesses. The 57 new exchange finite cases compare one shared alias graph of original owners, raw messages, orders and metadata, with queue representation projected as structural records. Error controls retain state committed before warnings or publication failures. No finite PASS, package build or local projection alone satisfies official submission validation.

## CLI and additive host probe

`cli.py` exposes the official single/batch CLI contract using the unchanged output validators and projection. Native loading happens before simulation; `installed.enabled` restores the Kernel binding on every exit and does not replace latency methods. Both proof arms use the same named summary-file IO suppression. The original authoritative business logs remain intact.

`host_probe.py` loads the real candidate CLI as module `agent`, invokes `simulate`/`simulate_batch` directly with `started=entry.ENTRY_STARTED` for both baseline and optimized arms, and receives one production `terminate` witness per actual episode. This timer includes entry imports, native admission, simulation and Parquet output, unlike the older v1 direct finite-proof timer. The inherited CLI captures wall time before writing its events sidecar; the outer host/daemon window includes sidecar writing. Additive probe serialization is outside the entry timer. `installed.reset_episode_probes()` and `installed.episode_probes()` expose the retained list without wrapping callbacks. It never wraps source-authenticated `enabled`, `abides.run` or class callbacks. Example after scheduled successful controls:

```sh
python3.11 host_probe.py --config scenario.json --out probe/native/trace.parquet --mode optimized --probe probe/native/receipt.json
python3.11 cli.py simulate-batch --batch-dir scenarios --out-dir outputs --mode optimized
```

The probe is diagnostic. Its measured rate is not rankable until the parent task validates the official environment, complete workload, resource accounting and comparison procedure.

## Known cost and next gates

The cdef region still bridges Python message constructors, exact numeric operations, RNG, oracle, matching, logs and final projection. The new receive helper shortens the official Python branch chain; all matching, notification and publication costs remain. Base/debug gates, bool observations and Python book calls still have cost. The whole-window benefit remains unmeasured. This scheduler/strategy spine cannot establish the required speedup by architecture alone. No target-speed claim is warranted without scheduled complete Linux evidence.

The immediate gates are source review, real Cython compilation, 65 inherited plus 30 counter plus 57 exchange finite cases (152 total) and four full-market exactness checks, negative-admission controls, then paired Linux performance measurement against frozen counters parent with matching full entry timing. Failed evidence stays intact. Only later evidence can justify expanding the native region to matching/notifications/output columns or spending a formal submission.
