#!/usr/bin/env python3
"""Additive host CLI probe; never wrap authenticated callbacks or entry aliases."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config")
    parser.add_argument("--out")
    parser.add_argument("--batch-dir")
    parser.add_argument("--out-dir")
    parser.add_argument("--mode", choices=("baseline", "optimized"), default="optimized")
    parser.add_argument("--probe", required=True)
    args = parser.parse_args()
    single = args.config is not None and args.out is not None and args.batch_dir is None and args.out_dir is None
    batch = args.batch_dir is not None and args.out_dir is not None and args.config is None and args.out is None
    if not (single or batch):
        parser.error("supply --config/--out or --batch-dir/--out-dir")
    spec = importlib.util.spec_from_file_location("agent", HERE / "cli.py")
    entry = importlib.util.module_from_spec(spec)
    sys.modules["agent"] = entry
    spec.loader.exec_module(entry)
    # Invoke the real CLI directly. The production termination hook stores the
    # witness; all source-authenticated enabled/abides aliases stay untouched.
    from installed import reset_episode_probes, episode_probes
    reset_episode_probes()
    result = entry.simulate(args.config, args.out, args.mode, started=entry.ENTRY_STARTED) if single else entry.simulate_batch(args.batch_dir, args.out_dir, args.mode, started=entry.ENTRY_STARTED)
    witnesses = episode_probes()
    expected = 1 if single else result["n_scenarios"]
    if args.mode == "optimized" and (len(witnesses) != expected or any(witness.get("native_active") is not True or witness.get("fallback_used") is not False or witness.get("proof_counters_seeded") is not False
        or witness.get("candidate") != "native_core_spine_exchange_v2"
        or witness.get("exchange_receive_implementation") != "cdef_limit_cancel_python_book_owner"
        or type(witness.get("exchange_direct_observed")) is not dict
        or tuple(witness["exchange_direct_observed"]) != ("limit", "cancel")
        or any(type(value) is not bool for value in witness["exchange_direct_observed"].values())
        for witness in witnesses)):
        raise ValueError("host probe did not observe actual native episode")
    Path(args.probe).write_text(json.dumps({"events": result, "episodes": witnesses,
        "timing_scope": "entry ENTRY_STARTED includes import/native admission/simulation/Parquet output; inherited sidecar cutoff and additive probe serialization excluded",
        "cli_source": str(HERE / "cli.py"), "rankable": False}, indent=2) + "\n")

if __name__ == "__main__":
    main()
