"""Common full-entry timing probe for two exact native-exchange screen arms."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/opt/exchange-screen/completion1009/candidates')
NAMES = {'native_reference': 'native_core_spine_counters_v2',
    'native_exchange': 'native_core_spine_exchange_v2'}
MARKER = 'T3_NATIVE_EXCHANGE_SCREEN='


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('verb', choices=('simulate', 'simulate-batch'))
    parser.add_argument('--config')
    parser.add_argument('--out')
    parser.add_argument('--batch-dir')
    parser.add_argument('--out-dir')
    parser.add_argument('--mode', choices=(*NAMES, 'controls'), required=True)
    args = parser.parse_args()
    name = NAMES.get(args.mode, 'native_core_spine_exchange_v2')
    candidate = ROOT / name
    os.environ['NATIVE_SPINE_BUILD_RECEIPT'] = str(candidate / 'artifacts/build_v1/BUILD_RECEIPT.json')
    sys.path.insert(0, str(candidate))
    if args.mode == 'controls':
        if (args.verb != 'simulate' or args.config != '/input/scenario.json'
                or args.out != '/output/trace.parquet' or args.batch_dir or args.out_dir
                or json.loads(Path(args.config).read_text()) != {'proof_command': 'native-exchange-152-and-four-markets-v1'}):
            raise ValueError('fixed controls input required')
        completed = subprocess.run([sys.executable, '-B', str(candidate / 'controls.py'),
            '--out', '/output/controls'], cwd='/output', timeout=840)
        raise SystemExit(completed.returncode)
    single = args.verb == 'simulate'
    if single:
        if args.config != '/input/scenario.json' or args.out != '/output/trace.parquet' or args.batch_dir or args.out_dir:
            raise ValueError('fixed single paths required')
    elif args.batch_dir != '/input/scenarios' or args.out_dir != '/output' or args.config or args.out:
        raise ValueError('fixed batch paths required')
    spec = importlib.util.spec_from_file_location('agent', candidate / 'cli.py')
    entry = importlib.util.module_from_spec(spec)
    sys.modules['agent'] = entry
    spec.loader.exec_module(entry)
    from installed import reset_episode_probes, episode_probes
    reset_episode_probes()
    mode = 'optimized'
    result = (entry.simulate(args.config, args.out, mode, started=entry.ENTRY_STARTED) if single
        else entry.simulate_batch(args.batch_dir, args.out_dir, mode, started=entry.ENTRY_STARTED))
    episodes = episode_probes()
    expected = 1 if single else result['n_scenarios']
    if (len(episodes) != expected or any(value.get('native_active') is not True
            or value.get('fallback_used') is not False or value.get('candidate') != name
            or value.get('proof_counters_seeded') is not False
            or value.get('proof_counter_storage') != 'uint64_checked_python_spill' for value in episodes)):
        raise ValueError('actual native episode witness differs')
    if args.mode == 'native_exchange' and any(
            value.get('exchange_receive_implementation') != 'cdef_limit_cancel_python_book_owner'
            or type(value.get('exchange_direct_observed')) is not dict
            or set(value['exchange_direct_observed']) != {'limit', 'cancel'}
            or any(type(flag) is not bool for flag in value['exchange_direct_observed'].values())
            for value in episodes):
        raise ValueError('actual exchange dispatch witness differs')
    print(MARKER + json.dumps({'schema': 't3-native-exchange-entry-v1', 'arm': args.mode,
        'events': result, 'episodes': episodes, 'cli_source': str(candidate / 'cli.py'),
        'entry_source': str(Path(__file__).resolve()), 'rankable': False,
        'timing_scope': 'CLI ENTRY_STARTED through Parquet/hash; unchanged sidecar cutoff; marker serialization outside CLI timer'},
        sort_keys=True, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()
