This development screen compares the repaired checked-counter native parent with a successor that compiles the original Limit/Cancel receive dispatch. Both retain original Python market owners and required outputs. One image holds two separately compiled extensions, and 57 fresh serial containers check exactness before comparing shared full-entry times. This screen does not submit a competition entry, establish 230000 events/sec or a ranking. Candidate source receipts must be frozen before staging.

The first counter draft failed pinned Cython 3.1.3 generation at two array dimensions even though C_COUNT was already a named enum. Independent v2 candidates use literal [10] only for these declarations; enum slots, loops, checked overflow, Python integer spill and seed rejection remain unchanged. Source/build identities distinguish the repairs, and the failed v1 evidence is preserved.

## Fixed execution plan

The arms are native_reference (native_core_spine_counters_v2) and native_exchange (native_core_spine_exchange_v2). Each loads its own extension from a separate candidate directory in a fresh process. Both use this common entry wrapper, unchanged cli.py, numeric dependencies, original latency and source-authentication boundaries. Arm order alternates between rounds and units; execution is serial.

| Stage | Containers | Purpose |
|---|---:|---|
| Controls | 1 | 152 finite cases and four full-market state, RNG and alias comparisons |
| Smoke | 6 | S001, AS06 and full heterogeneous batch, both arms |
| Paired screen | 40 | Five units, one warmup and three measured repeats, both arms |
| Fresh batch isolation | 10 | All five batch members separately, both arms |
| Total | 57 | 56 ordinary runs, 30 measured runs, 46 official verifiers and 184 gates |

The five units are S001 price-time priority, AS06 throughput, MP01 self-trade prevention, RA01 fundamental shock and the original full five-member heterogeneous batch. The host requires the original public roster to contain 71 units. This screen cannot replace full-roster validation. There is no performance early stop or partial promotion; correctness failures stop with evidence preserved.

Every ordinary run checks actual Parquet rows, exact reference frame values/dtypes, sidecars, input hashes, complete output-tree limits and resources. The 46 smoke/screen runs invoke the unchanged official developer verifier. Cross-arm/repeat pairs require identical Parquet bytes and stable sidecars. Fresh isolation compares original isolated references, its own full-batch outputs and matching batch counters. Batch marker order must equal the original CLI's sorted input order before mapping episodes to members.

Both native arms require exactly ten nonnegative builtin-integer counters, pop equal to ttl_messages, uint64_checked_python_spill storage and unseeded execution. Parent and successor counters must agree per episode. The exchange arm requires cdef_limit_cancel_python_book_owner implementation and exact builtin-bool limit/cancel observations. Ordinary scenarios can omit either operation; both four-market control flags must be true. Sticky flags mark real dispatch entry, including rejection/failure, rather than success counts or event-rate numerators.

## Ownership and timing

Compiled receive preserves base Agent receive/debug, computation delay, close checks, order logging, deepcopy, Python book calls and publication order. Matching, STP, order/message owners, subscriptions, history, RandomState and sparse oracle remain Python operations. This is compiled exchange dispatch with Python-owned matching.

The wrapper imports helpers, parses arguments and selects an arm before cli.py captures ENTRY_STARTED. CLI timing includes runtime imports, actual enabled authentication/admission, market execution, frame validation, both Parquet writes and trace hashing; it stops before unchanged sidecar serialization. Direct simulate calls bypass cli.main's redundant initial admission while enabled still performs it. Both arms share this boundary. Final marker serialization is outside CLI timing.

Host timing covers create through attached execution and terminal inspect, excluding cleanup. Daemon timing uses actual StartedAt through FinishedAt, including wrapper startup/marker emission. Cleanup is separate. All clocks must be positive and finite, with numerators from actual emitted Parquet rows. Per-unit reference median time divided by successor median across three repeats forms each ratio; the arithmetic mean of five ratios is reported for CLI/host/daemon. A ratio above one means faster within this protocol. Prior proof clocks, other machines and saved baseline runs are not interchangeable.

## Resources, provenance and evidence

One multi-stage image build compiles both native sources with CPython 3.11.17, Cython 3.1.3, pinned original packages and -O2 -fPIC -fno-fast-math -ffp-contract=off. Actual build receipts, generated C and ELF bytes are extracted from a never-started owned receipt container. Both source trees including STATUS are frozen. Their 62 original runtime files and PINNED_RUNTIME.json must match exactly. Build receipts require exact candidate identity and respective v2 schemas.

Participant runs use Linux amd64/runc, 4 CPU quota, 16 GiB memory/swap, UID/GID 65534, network none, read-only root, dropped capabilities and no new privileges. PID/nproc limits are 256, descriptors 1024, /tmp a 64 MiB noexec tmpfs, and file/complete ordinary output limits 256 MiB. Only fixed input/output binds are permitted. Actual entrypoint, limits and mounts are inspected; bounded logs and owned cleanup are saved. Both official simulation verbs run.

Stage copies/parses frozen sources without importing the participant, compiling or running a market. Materialization requires an exact-hash bounded archive of unique regular files. Workflow permissions are read-only and the existing Linux concurrency group keeps execution serial. The source-bound original evaluator/references are fetched; the image builds once, controls run first and evidence is uploaded without publishing or competition submission.

Evidence retains actual installed source/runtime/generated C/ELF files, receipts, all command/resource/input/reference logs and per-run comparisons. Image, complete payload and extracted native files are revalidated before/after. Pair updates persist per-run and RAW_RESULTS before failure exit; isolation records its attempt before pair validation. Successful ordinary input/output bytes may be compacted only after whole-screen PASS with exact hash/size/reason inventory. All control and failed/unknown ordinary outputs remain. Independent downloaded audit must distinguish saved comparisons from fresh comparison of omitted Parquet bytes.

Formal submission still requires compiled controls, measured selection/composition benefit, independent audit, full71 and repeats, anonymous image pull, official descriptor/seal and the official two-member ZIP. The 230000 events/sec aspiration remains unverified.
