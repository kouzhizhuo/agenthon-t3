"""Source-bound two-arm Linux exchange screen; no official score or ranking claim."""
import argparse
import calendar
from datetime import datetime
import math
import statistics
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import sys
import uuid
from common import (BASE, BATCH, CANDIDATE, PARENT, ARMS, ARM_CANDIDATES, IMAGE_CANDIDATE, MARKER, SINGLES,
                    COUNTER_KEYS, TIMING_SCOPE, finite_names, inventory, safe_name, sha, verify_payload, write)

PAYLOAD = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public


class StrictCommands(linux.DockerCommands):
    """Add finite process/file ulimits while keeping original launch checks."""
    def call(self, arguments, label, seconds=30, cleanup=False):
        if arguments and arguments[0] == "create":
            arguments = [arguments[0], "--ulimit", "nproc=256:256", "--ulimit",
                         "fsize=268435456:268435456", *arguments[1:]]
        return super().call(arguments, label, seconds, cleanup)

    def inspect(self, name, cleanup=False, seconds=30):
        info, command = super().inspect(name, cleanup, seconds)
        if info is not None and not cleanup and '--mode' in info.get('Config', {}).get('Cmd', []) and info.get('Config', {}).get('Entrypoint') != ['/usr/local/bin/python', '-B', '/opt/exchange-screen/entry.py']:
            raise ValueError('actual screen entrypoint differs')
        if info is not None and not cleanup and info.get("Config", {}).get("Entrypoint") == ["/usr/local/bin/python", "-B", "/opt/exchange-screen/entry.py"]:
            host = info["HostConfig"]
            limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
            expected = {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
            if any(limits.get(name) != value for name, value in expected.items()):
                raise ValueError("actual complete proof ulimits differ")
            mounts = info.get("Mounts", [])
            binds = [row for row in mounts if row.get("Destination") != "/tmp"]
            if (len(binds) != 2 or {row.get("Destination") for row in binds} != {"/input", "/output"}
                    or any(row.get("Type") != "bind" for row in binds)
                    or any(row.get("Type") != "tmpfs" for row in mounts if row.get("Destination") == "/tmp")):
                raise ValueError("proof mounts differ from input/output-only contract")
        return info, command


linux.DockerCommands = StrictCommands


def execute(args, command, prefix, seconds):
    row = linux.run_command(command, prefix, seconds, args.log_cap_bytes)
    write(prefix.with_name(prefix.name + ".json"), row)
    if not row["succeeded"]:
        raise RuntimeError("failed bounded command; diagnostics: " + str(prefix))
    return row


def image(args, requested, folder):
    folder.mkdir(parents=True)
    return linux.image_metadata(args, requested, folder)


def validate_build(plan, copied, candidate):
    source = PAYLOAD / candidate
    source_receipt = source / 'SOURCE_PREPARATION_RECEIPT.json'
    source_records = plan['parent_source_files' if candidate == PARENT else 'source_files']
    receipt_digest = plan['parent_source_receipt_sha256' if candidate == PARENT else 'source_receipt_sha256']
    if sha(source_receipt) != receipt_digest or sha(copied / source_receipt.name) != receipt_digest:
        raise ValueError('actual installed source freeze receipt differs')
    for record in source_records:
        installed = copied / safe_name(record['path'])
        if {'bytes': installed.stat().st_size, 'sha256': sha(installed)} != {k: record[k] for k in ('bytes', 'sha256')}:
            raise ValueError('actual complete source freeze differs: ' + record['path'])
    receipt = public.read_json(copied / "artifacts/build_v1/BUILD_RECEIPT.json")
    spec = public.read_json(source / "compile_spec.json")
    bindings = public.read_json(copied / "SOURCE_BINDINGS.json")
    expected_sources = {path.name: sha(path) for path in source.iterdir()
        if path.is_file() and not path.name.startswith("._")
        and (path.suffix in (".py", ".pyx", ".md") or path.name == "compile_spec.json")}
    if (receipt.get("schema") != ("t3-native-core-spine-counters-build-v2" if candidate == PARENT else "t3-native-core-spine-exchange-build-v2") or receipt.get("build_succeeded") is not True
            or receipt.get('candidate') != Path(candidate).name
            or receipt.get("candidate_sources") != expected_sources or receipt.get("cython") != spec["cython"]
            or receipt.get("dependencies") != spec["dependencies"]
            or receipt.get("compile_flags") != spec["compile_flags"] or receipt.get("directives") != spec["directives"]
            or receipt.get("compile_spec_sha256") != sha(source / "compile_spec.json")
            or receipt.get("runtime_pins_sha256") != plan["runtime_pins_sha256"]
            or receipt.get("source_bindings_sha256") != sha(copied / "SOURCE_BINDINGS.json")
            or receipt.get("market_execution") is not False or receipt.get("timing_claim") is not False):
        raise ValueError("actual native build receipt differs from frozen source recipe")
    abi = receipt["abi"]
    if (abi.get("implementation") != "cpython" or abi.get("version") != [3, 11, 17]
            or abi.get("platform") != "linux" or abi.get("machine") not in ("x86_64", "AMD64")
            or abi.get("pointer_bits") != 64 or abi.get("byteorder") != "little"
            or abi.get("cache_tag") != "cpython-311" or not abi.get("ext_suffix", "").endswith(".so")):
        raise ValueError("actual native ABI is not pinned Linux amd64 CPython 3.11")
    expected_python = {name: digest for name, digest in expected_sources.items() if name.endswith(".py")}
    if (bindings.get("schema") != "t3-native-spine-source-bindings-v1"
            or bindings.get("candidate_python_sources") != expected_python
            or bindings.get("runtime_pins_sha256") != plan["runtime_pins_sha256"]
            or bindings.get("native_execution") is not False):
        raise ValueError("actual source binding receipt differs")
    build = copied / "artifacts/build_v1"
    extension_record = receipt["extension"]
    extension = build / safe_name(extension_record["path"])
    if extension.stat().st_size != extension_record["bytes"] or sha(extension) != extension_record["sha256"]:
        raise ValueError("actual extracted extension bytes differ")
    generated = receipt.get("generated_c", {})
    if not generated or any(sha(build / safe_name(name)) != digest for name, digest in generated.items()):
        raise ValueError("actual extracted generated C differs")
    for name in expected_sources:
        if sha(copied / name) != expected_sources[name]:
            raise ValueError("actual installed candidate source differs: " + name)
    pins = public.read_json(source / "PINNED_RUNTIME.json")
    expected_runtime = {row["path"]: {"bytes": row["bytes"], "sha256": row["sha256"]} for row in pins["runtime_files"]}
    if inventory(copied / "runtime") != expected_runtime or sha(copied / "PINNED_RUNTIME.json") != plan["runtime_pins_sha256"]:
        raise ValueError("actual installed runtime snapshot differs")
    proof = {"passed": True, "candidate": candidate, "build_receipt_sha256": sha(build / "BUILD_RECEIPT.json"),
        "source_bindings_sha256": sha(copied / "SOURCE_BINDINGS.json"), "extension": extension_record,
        "abi": abi, "generated_c": generated, 'candidate_sources': expected_sources,
        "rankable": False, "timing_claim": False}
    write(copied / "BUILD_PROVENANCE.json", proof)
    return proof


def build(args, plan):
    evidence = args.evidence
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("real Linux amd64 host required")
    anonymous = evidence / "anonymous-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        execute(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], evidence / "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    write(evidence / "BASE.json", image(args, BASE, evidence / "base"))
    context = evidence / "build-context"
    context.mkdir()
    shutil.copytree(PAYLOAD / "completion1009", context / "completion1009")
    (context / "control").mkdir()
    shutil.copyfile(PAYLOAD / "control/entry.py", context / "control/entry.py")
    shutil.copyfile(PAYLOAD / "control/Dockerfile", context / "Dockerfile")
    iid = evidence / "native.image-id"
    execute(args, [args.docker, "build", "--platform", "linux/amd64", "--iidfile", str(iid),
        "-t", "t3-native-exchange-screen:v1", "-f", str(context / "Dockerfile"), str(context)], evidence / "native-build", 1200)
    metadata = image(args, iid.read_text().strip(), evidence / "image")
    write(evidence / "IMAGE.json", metadata)
    token = uuid.uuid4().hex
    name = "t3-native-receipt-" + token[:12]
    commands = StrictCommands(args.docker, evidence / "receipt-commands", args.log_cap_bytes)
    commands.folder.mkdir(parents=True)
    created = commands.call(["create", "--name", name, "--label", linux.OWNER_LABEL + "=" + token,
        "--pull", "never", "--entrypoint", "/usr/local/bin/python", metadata["id"], "--help"], "create")
    try:
        if not created["succeeded"]:
            raise RuntimeError("never-started receipt container creation failed")
        info, _ = commands.inspect(name)
        linux.require_owned(info, name, token, metadata["id"])
        target = evidence / "actual-candidates"
        target.mkdir()
        for candidate in (PARENT, CANDIDATE):
            destination = target / Path(candidate).name
            copied = commands.call(["cp", name + ":/opt/exchange-screen/" + candidate, str(destination)],
                "copy-" + Path(candidate).name, 120)
            if not copied["succeeded"]:
                raise ValueError("actual image receipt/source/native bytes unavailable")
            validate_build(plan, destination, candidate)
    finally:
        settled = linux.settle_container(commands, name, token, metadata["id"], creation_uncertain=not created["succeeded"])
        write(evidence / "RECEIPT_CLEANUP.json", {"cleanup": settled, "commands": commands.rows})
        if not settled["settled"] or not settled["final_absent"] or settled["errors"]:
            raise RuntimeError("owned receipt container not settled")
    write(evidence / "BUILD_READY.json", {"passed": True, "image_id": metadata["id"],
        "build_count": 1, "rankable": False, "timing_claim": False})


def duration_ns(state):
    def parse(value):
        base, fraction = value.rstrip('Z').split('.', 1)
        return calendar.timegm(datetime.strptime(base, '%Y-%m-%dT%H:%M:%S').timetuple()) * 10**9 + int(fraction.ljust(9, '0'))
    return (parse(state['FinishedAt']) - parse(state['StartedAt'])) / 10**9


def require_probe(execution, arm, expected, provenance):
    lines = Path(execution['attach']['stdout']['path']).read_text().splitlines()
    values = [json.loads(line[len(MARKER):]) for line in lines if line.startswith(MARKER)]
    if len(values) != 1:
        raise ValueError('one actual common entry marker required')
    value = values[0]
    candidate = ARM_CANDIDATES[arm]
    if (value.get('schema') != 't3-native-exchange-entry-v1' or value.get('arm') != arm
            or value.get('cli_source') != '/opt/exchange-screen/' + candidate + '/cli.py'
            or value.get('entry_source') != '/opt/exchange-screen/entry.py'
            or value.get('timing_scope') != TIMING_SCOPE or value.get('rankable') is not False):
        raise ValueError('actual entry origin/arm differs')
    if len(value['episodes']) != expected:
        raise ValueError('native episode roster incomplete')
    proof = provenance[candidate]
    for episode in value['episodes']:
        if (episode.get('candidate') != Path(candidate).name or episode.get('native_active') is not True
                    or episode.get('fallback_used') is not False or episode.get('proof_only') is not True
                    or episode.get('extension_sha256') != proof['extension']['sha256']
                    or episode.get('receipt_sha256') != proof['build_receipt_sha256']
                    or episode.get('abi') != proof['abi']
                    or episode.get('extension_path') != '/opt/exchange-screen/' + candidate + '/artifacts/build_v1/' + proof['extension']['path']
                    or episode.get('receipt_path') != '/opt/exchange-screen/' + candidate + '/artifacts/build_v1/BUILD_RECEIPT.json'
                    or set(episode.get('counts', {})) != set(COUNTER_KEYS)
                    or not all(type(x) is int and x >= 0 for x in episode.get('counts', {}).values())
                    or episode['counts'].get('pop') != episode.get('ttl_messages')
                    or any(episode['counts'].get(name, 0) <= 0 for name in ('pop', 'wake', 'act', 'exchange_book_bridge'))):
            raise ValueError('native path lacks exact receipt-bound execution')
        if (episode.get('proof_counters_seeded') is not False
                or episode.get('proof_counter_storage') != 'uint64_checked_python_spill'):
            raise ValueError('checked counter production path differs')
        if arm == 'native_exchange' and (
                episode.get('exchange_receive_implementation') != 'cdef_limit_cancel_python_book_owner'
                or type(episode.get('exchange_direct_observed')) is not dict
                or set(episode['exchange_direct_observed']) != {'limit', 'cancel'}
                or not all(type(flag) is bool for flag in episode['exchange_direct_observed'].values())):
            raise ValueError('actual exact exchange dispatch proof differs')
    return value


def run_one(args, metadata, provenance, arm, item, folder, suffix, reference=True):
    execution, output = linux.run_container(args, metadata['id'], arm, item, folder, args.owner, suffix)
    row = {'arm': arm, 'unit': item['unit'], 'execution': execution, 'output': str(output),
        'passed': False, 'rankable': False, 'timing_included': False}
    try:
        if not execution['succeeded'] or any(sha(Path(value['staged'])) != value['sha256'] for value in execution['staged_inputs']):
            raise ValueError('strict run or original staged input failed')
        row['output_inventory'] = inventory(output)
        row['probe'] = require_probe(execution, arm, len(item['subs']) if item['shape'] == 'batch' else 1, provenance)
        events = public.read_json(output / ('events.json' if item['shape'] == 'single' else 'batch_events.json'))
        if events != row['probe']['events']:
            raise ValueError('probe/actual sidecar differs')
        if item['shape'] == 'batch' and [r['sub'] for r in events.get('per_scenario', [])] != sorted(r['sub'] for r in item['subs']):
            raise ValueError('actual batch episode order differs from original CLI sorted input order')
        if reference:
            row['reference_checks'] = public.verify_outputs(args.reference_root / item['unit'], output, item)
            row['developer_verifier'] = linux.gate(args, args.reference_root / item['unit'], output, folder)
            if not row['reference_checks']['passed'] or row['developer_verifier'].get('admissible') is not True:
                raise ValueError('original reference or unchanged official verifier failed')
        else:
            scenario = public.read_json(item['scenario_paths'][0])
            frames = [public.compare_frame(output / name, Path(item['isolated_reference']) / name) for name in public.SUB_FILES[:2]]
            checked = public.verify_events(output, scenario, frames[0].get('candidate_rows', 0))
            tree = public.check_tree(output, set(public.SUB_FILES))
            if not all(r['passed'] for r in frames) or not checked['passed'] or not tree['passed']:
                raise ValueError('isolated original reference/sidecar/tree failed')
            row['reference_checks'] = {'passed': True, 'frames': frames, 'sidecar': checked, 'tree': tree,
                'actual_events': frames[0]['candidate_rows']}
        actual = row['reference_checks']['actual_events']
        if events.get('n_events', events.get('total_events')) != actual:
            raise ValueError('actual Parquet rows differ from sidecar/probe')
        row.update(actual_events=actual,
            cli_wall_sec=events['wall_clock_sec'], settled_container_runtime_sec=duration_ns(execution['state']))
        if any(not math.isfinite(value) or value <= 0 for value in
                (row['cli_wall_sec'], row['settled_container_runtime_sec'], execution['host_wall_sec'])):
            raise ValueError('actual measured wall clocks must be positive and finite')
        row['cli_events_per_sec'] = row['actual_events'] / row['cli_wall_sec']
        row['host_events_per_sec'] = row['actual_events'] / execution['host_wall_sec']
        row['daemon_events_per_sec'] = row['actual_events'] / row['settled_container_runtime_sec']
        row['passed'] = True
    except BaseException as error:
        row['failure'] = type(error).__name__ + ': ' + str(error)
    write(folder / 'RUN_RESULT.json', row)
    print(arm, item['unit'], 'PASS' if row['passed'] else 'FAIL', flush=True)
    return row


def pair(output, other, item):
    frames = list(public.SUB_FILES[:2]) if item['shape'] == 'single' else [sub['sub'] + '/' + name for sub in item['subs'] for name in public.SUB_FILES[:2]]
    results = [public.compare_frame(output / name, other / name) for name in frames]
    sidecars = ['events.json'] if item['shape'] == 'single' else [sub['sub'] + '/events.json' for sub in item['subs']] + ['batch_events.json']
    stable = []
    for name in sidecars:
        a, b = public.read_json(output / name), public.read_json(other / name)
        for value in (a, b):
            for key in ('wall_clock_sec', 'events_per_sec', 'peak_memory_bytes', 'gpu_seconds'):
                value.pop(key, None)
        stable.append({'path': name, 'candidate': a, 'baseline': b, 'passed': a == b})
    return {'passed': all(r['passed'] and r.get('byte_equal') for r in results) and all(r['passed'] for r in stable),
        'frames': results, 'stable_sidecars': stable}


def validate_controls(finite, result, provenance):
    proof = provenance[CANDIDATE]
    expected_receipt = {'receipt_path': '/opt/exchange-screen/' + CANDIDATE + '/artifacts/build_v1/BUILD_RECEIPT.json',
        'receipt_sha256': proof['build_receipt_sha256'],
        'extension_path': '/opt/exchange-screen/' + CANDIDATE + '/artifacts/build_v1/' + proof['extension']['path'],
        'extension_sha256': proof['extension']['sha256'], 'abi': proof['abi']}
    if (finite.get('all_passed') is not True or result.get('all_passed') is not True
            or [r['name'] for r in finite['cases']] != finite_names() or len(finite['cases']) != 152
            or not all(r.get('passed') is True for r in finite['cases'])
            or finite.get('sources_unchanged') is not True or result.get('sources_unchanged') is not True
            or finite.get('failures') != [] or result.get('failures') != []
            or result.get('finite_cases') != 152 or result.get('candidate_sources') != proof['candidate_sources']
            or [r['seed'] for r in result['cases']] != [81009, 82009, 83009, 84009]
            or finite.get('controls_sha256') != proof['candidate_sources']['finite_controls.py']
            or result.get('controls_sha256') != proof['candidate_sources']['controls.py']):
        raise ValueError('actual finite/full-market controls roster/source proof differs')
    for document in (finite, result):
        if document.get('native_receipt') != expected_receipt or document.get('proof_only') is not True or document.get('rankable') is not False:
            raise ValueError('actual controls full native receipt differs')
    for case in result['cases']:
        witness = case['native_witness']
        if (case.get('passed') is not True or case['trace_rows'] <= 0 or case['message_rows'] <= 0
                or any(witness.get(k) != v for k, v in expected_receipt.items())
                or witness.get('candidate') != Path(CANDIDATE).name
                or witness.get('native_active') is not True or witness.get('fallback_used') is not False
                or witness.get('proof_counters_seeded') is not False
                or witness.get('proof_counter_storage') != 'uint64_checked_python_spill'
                or witness.get('exchange_receive_implementation') != 'cdef_limit_cancel_python_book_owner'
                or witness.get('exchange_direct_observed') != {'limit': True, 'cancel': True}
                or not all(type(flag) is bool for flag in witness.get('exchange_direct_observed', {}).values())
                or set(witness.get('counts', {})) != set(COUNTER_KEYS)
                or not all(type(v) is int and v >= 0 for v in witness['counts'].values())
                or witness['counts']['pop'] != case['ttl_messages']
                or any(witness['counts'][key] <= 0 for key in ('pop', 'act', 'exchange_book_bridge'))):
            raise ValueError('actual full-market native exchange witness differs')


def screen(args, plan):
    args.owner = uuid.uuid4().hex
    args.timeout = 300
    metadata = public.read_json(args.evidence / 'IMAGE.json')
    provenance = {candidate: validate_build(plan, args.evidence / 'actual-candidates' / Path(candidate).name, candidate)
        for candidate in (PARENT, CANDIDATE)}
    if provenance[PARENT]['extension']['sha256'] == provenance[CANDIDATE]['extension']['sha256']:
        raise ValueError('two separate native implementations must have different extension hashes')
    before_image = image(args, metadata['id'], args.evidence / 'image-before-screen')
    if before_image['inspection'] != metadata['inspection']:
        raise ValueError('actual image changed before screen')
    roster = public.collect_plan(args.reference_root, SINGLES + [BATCH])
    write(args.evidence / 'REFERENCE_PLAN.json', roster)
    items = {value['unit']: value for value in roster['units']}
    if len(items[BATCH]['subs']) != 5:
        raise ValueError('original full five-member batch required')
    rows, failure, first, serial = [], None, {}, 0
    try:
        controls_input = args.evidence / 'fixed-control-input.json'
        write(controls_input, {'proof_command': 'native-exchange-152-and-four-markets-v1'})
        controls_item = {'shape': 'single', 'scenario_paths': [str(controls_input)]}
        args.timeout = 900
        execution, output = linux.run_container(args, metadata['id'], 'controls', controls_item,
            args.evidence / 'controls', args.owner, 'controls')
        args.timeout = 300
        finite = public.read_json(output / 'controls/FINITE_RESULT.json')
        result = public.read_json(output / 'controls/RESULT.json')
        if not execution['succeeded'] or any(sha(Path(r['staged'])) != r['sha256'] for r in execution['staged_inputs']):
            raise ValueError('strict controls container or fixed input failed')
        validate_controls(finite, result, provenance)
        write(args.evidence / 'CONTROL_RESULT.json', {'passed': True, 'execution': execution, 'finite': finite, 'markets': result})
        for stage, repeats in (('smoke', [0]), ('screen', [-1, 0, 1, 2])):
            units = [SINGLES[0], SINGLES[1], BATCH] if stage == 'smoke' else SINGLES + [BATCH]
            for repeat in repeats:
                for index, unit in enumerate(units):
                    order = list(ARMS)
                    if (repeat + 1 + index) % 2:
                        order.reverse()
                    group = {}
                    for arm in order:
                        serial += 1
                        folder = args.evidence / stage / ('warmup' if repeat < 0 else 'repeat-' + str(repeat)) / unit / arm
                        row = run_one(args, metadata, provenance, arm, items[unit], folder, '%04d' % serial)
                        row.update(stage=stage, repeat=repeat, warmup=repeat < 0, order=order,
                            timing_included=stage == 'screen' and repeat >= 0)
                        rows.append(row); group[arm] = row
                        write(args.evidence / 'RAW_RESULTS.json', rows)
                        if not row['passed']:
                            raise ValueError('screen stopped at failed run')
                    for arm, row in group.items():
                        output = Path(row['output'])
                        row['same_round_pair'] = pair(output, Path(group['native_reference']['output']), items[unit])
                        key = (stage, unit, arm)
                        previous = first.setdefault(key, output)
                        row['same_arm_repeat_pair'] = pair(output, previous, items[unit])
                        row['same_round_counts'] = [e['counts'] for e in row['probe']['episodes']]
                        row['same_round_counts_passed'] = row['same_round_counts'] == [e['counts'] for e in group['native_reference']['probe']['episodes']]
                        row['passed'] &= row['same_round_counts_passed']
                        row['passed'] &= row['same_round_pair']['passed'] and row['same_arm_repeat_pair']['passed']
                        write(output.parent / 'RUN_RESULT.json', row)
                        write(args.evidence / 'RAW_RESULTS.json', rows)
                        if not row['passed']:
                            raise ValueError('paired or repeat output differs')
                    write(args.evidence / 'RAW_RESULTS.json', rows)
        batch = items[BATCH]
        for arm in ARMS:
            full = next(r for r in reversed(rows) if r['unit'] == BATCH and r['arm'] == arm)
            for sub in batch['subs']:
                serial += 1
                item = {'unit': BATCH + '/' + sub['sub'], 'shape': 'single', 'subs': [],
                    'scenario_paths': [str(args.reference_root / BATCH / sub['scenario_file'])],
                    'isolated_reference': str(args.reference_root / BATCH / 'checks/reference_data' / sub['sub'])}
                folder = args.evidence / 'isolation' / arm / sub['sub']
                row = run_one(args, metadata, provenance, arm, item, folder, '%04d' % serial, reference=False)
                row.update(stage='isolation')
                rows.append(row)
                write(args.evidence / 'RAW_RESULTS.json', rows)
                row.update(stage='isolation', isolation_pair=pair(Path(row['output']), Path(full['output']) / sub['sub'], item))
                row['passed'] &= row['isolation_pair']['passed']
                if row.get('probe'):
                    names = [r['sub'] for r in full['probe']['events']['per_scenario']]
                    expected_counts = full['probe']['episodes'][names.index(sub['sub'])]['counts']
                    row['isolation_counts'] = {'candidate': row['probe']['episodes'][0]['counts'], 'batch': expected_counts,
                        'passed': row['probe']['episodes'][0]['counts'] == expected_counts}
                    row['passed'] &= row['isolation_counts']['passed']
                write(folder / 'RUN_RESULT.json', row); write(args.evidence / 'RAW_RESULTS.json', rows)
                if not row['passed']:
                    raise ValueError('fresh batch isolation failed')
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
    unchanged = all(sha(args.reference_root / item['unit'] / name) == digest for item in roster['units']
        for mapping in (item['input_sha256'], item['reference_sha256']) for name, digest in mapping.items())
    try:
        after_image = image(args, metadata['id'], args.evidence / 'image-after-screen')
        immutable = after_image['inspection'] == before_image['inspection']
        verify_payload(PAYLOAD)
        for candidate in (PARENT, CANDIDATE):
            validate_build(plan, args.evidence / 'actual-candidates' / Path(candidate).name, candidate)
        if not immutable:
            raise ValueError('actual image changed during screen')
    except BaseException as error:
        immutable = False
        failure = failure or type(error).__name__ + ': ' + str(error)
    measured = [r for r in rows if r.get('timing_included')]
    official_runs = sum('developer_verifier' in r for r in rows)
    official_gate_passes = sum(
        gate.get('passed') is True
        for row in rows for gate in (row.get('developer_verifier', {}).get('verdict') or {}).get('gate_results', {}).values())
    comparisons = []
    for arm, baseline in (('native_exchange', 'native_reference'),):
        rates = []
        for unit in SINGLES + [BATCH]:
            a = [r for r in measured if r['arm'] == baseline and r['unit'] == unit and r['passed']]
            b = [r for r in measured if r['arm'] == arm and r['unit'] == unit and r['passed']]
            if len(a) != 3 or len(b) != 3:
                continue
            rates.append({'unit': unit, **{name: statistics.median(r[key] if key != 'host_wall_sec' else r['execution'][key] for r in a)
                / statistics.median(r[key] if key != 'host_wall_sec' else r['execution'][key] for r in b)
                for name, key in (('cli_ratio', 'cli_wall_sec'), ('host_ratio', 'host_wall_sec'), ('daemon_ratio', 'settled_container_runtime_sec'))}})
        comparisons.append({'arm': arm, 'baseline': baseline, 'per_unit': rates,
            **{key: statistics.mean(r[key] for r in rates) if len(rates) == 5 else None for key in ('cli_ratio', 'host_ratio', 'daemon_ratio')}})
    summary = {'schema': 't3-native-exchange-screen-result-v1', 'all_passed': failure is None and len(rows) == 56
        and len(measured) == 30 and official_runs == 46 and official_gate_passes == 184
        and all(r['passed'] for r in rows) and unchanged and immutable,
        'runs': len(rows), 'planned_runs': 56, 'control_invocations': 1, 'measured_runs': len(measured),
        'failure': failure, 'comparisons': comparisons, 'original_inputs_references_unchanged': unchanged,
        'image_source_provenance_unchanged': immutable, 'total_execution_containers': len(rows) + 1,
        'official_verifier_runs': official_runs, 'official_gate_passes': official_gate_passes,
        'rankable': False, 'official_score': None, 'publication': False, 'competition_upload': False}
    write(args.evidence / 'SUMMARY.json', summary)
    if not summary['all_passed']:
        raise RuntimeError('native exchange screen incomplete or failed')


def archive_evidence(args):
    if args.artifact.exists():
        raise ValueError("new artifact directory required")
    args.artifact.mkdir(parents=True)
    success = (args.evidence / 'SUMMARY.json').is_file() and public.read_json(args.evidence / 'SUMMARY.json').get('all_passed') is True
    omitted = {}
    for source in sorted(args.evidence.rglob("*")):
        if not source.is_file() or source.is_symlink():
            continue
        relative = source.relative_to(args.evidence)
        # Omit ordinary successful run bytes only after every gate passed.
        # Always retain controls outputs and complete failed/unknown run bytes.
        compact_run = success and relative.parts[0] in ('smoke', 'screen', 'isolation') and any(p in ('input', 'output') for p in relative.parts)
        if relative.parts[0] in ('build-context', 'anonymous-config') or compact_run:
            omitted[relative.as_posix()] = {'bytes': source.stat().st_size, 'sha256': sha(source),
                'reason': 'successful ordinary run bytes' if compact_run else 'duplicate build context or empty anonymous configuration'}
            continue
        target = args.artifact / "evidence" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    write(args.artifact / 'OMITTED_FILES.json', {'all_runs_passed': success, 'files': omitted})
    shutil.copyfile(args.archive, args.artifact / "SCREEN_PAYLOAD.tar.xz")
    write(args.artifact / "ARTIFACT.json", {"archive_sha256": sha(args.archive),
        "compact_success_outputs_omitted_full_failures_retained": True, 'successful_runs_compacted': success,
        'controls_outputs_retained': True, "rankable": False, "timing_claim": False,
        "files": inventory(args.artifact)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("build", "screen", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--reference-root", type=Path)
    parser.add_argument("--gate-kit", type=Path)
    parser.add_argument("--gate-python", default=sys.executable)
    parser.add_argument("--docker", default="docker")
    parser.add_argument("--timeout", type=float, default=900)
    parser.add_argument("--log-cap-bytes", type=int, default=4 * 1024 ** 2)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--artifact", type=Path)
    args = parser.parse_args()
    signal.signal(signal.SIGINT, linux.cancellation)
    signal.signal(signal.SIGTERM, linux.cancellation)
    args.evidence = args.evidence.resolve()
    args.evidence.mkdir(parents=True, exist_ok=True)
    if args.stage == "artifact":
        archive_evidence(args)
        return
    verify_payload(PAYLOAD)
    plan = public.read_json(PAYLOAD / "SCREEN_PLAN.json")
    if (plan.get("base") != BASE or plan.get("candidate") != CANDIDATE or plan.get("parent") != PARENT
            or plan.get("single_units") != SINGLES or plan.get("batch_unit") != BATCH
            or plan.get("arms") != ARMS or plan.get("finite_cases") != 152 or plan.get("market_cases") != 4
            or plan.get("planned_runs") != 56 or plan.get("measured_runs") != 30
            or plan.get('control_invocations') != 1 or plan.get('total_execution_containers') != 57
            or plan.get('official_verifier_runs') != 46 or plan.get('full_five_member_batch') is not True
            or plan.get('official_gate_passes') != 184 or plan.get('no_performance_early_stop') is not True
            or plan.get("warmups") != 1 or plan.get("measured_repeats") != 3
            or plan.get("build_count") != 1 or plan.get("extension_builds") != 2
            or plan.get("rankable") is not False):
        raise ValueError("fixed native exchange screen plan differs")
    if args.stage == "build":
        build(args, plan)
    else:
        if not args.reference_root or not args.gate_kit:
            raise ValueError("original host references and official toolkit required")
        screen(args, plan)


if __name__ == "__main__":
    main()
