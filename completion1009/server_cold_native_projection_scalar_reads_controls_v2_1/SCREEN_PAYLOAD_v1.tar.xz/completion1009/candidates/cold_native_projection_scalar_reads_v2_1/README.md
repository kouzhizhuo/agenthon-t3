This fresh candidate repairs the expected sequence order in an additive serializer fixture. All simulator, native scalar, output, runtime and gate code remains byte-identical to V2. V2 built successfully but its original fixture stopped before native fixtures or markets. This version has no new performance evidence yet.

# Scalar reads V2.1

Only `signed_message_boundaries` expected rows are sorted by their explicit sequence key. Added NumPy rows previously appeared after INT64_MAX; the original projector correctly sorts them before it. Original market/scorer inputs and checks are unchanged.
