"""Source-bound three-arm Linux whole-market finite diagnostic, no score claim."""
import argparse
import ast
import calendar
from datetime import datetime
import json
import math
import os
from pathlib import Path
import platform
import shutil
import signal
import statistics
import subprocess
import sys
import time
import uuid
from common import (BASE, CANDIDATE, BASELINE, GENERATOR, ENTRYPOINT, ARMS, CONTROL_ARMS, COLD_EMPTY,
    SINGLES, BATCH, IMAGE_ROOT, sha, inventory, verify_payload, write, arm_order)
PAYLOAD = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public


def call(args, command, label, seconds=60, allow_failure=False):
    path = args.evidence / (label + ".log")
    started = time.monotonic()
    result = None
    failure = None
    timed_out = False
    with path.open("xb") as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=seconds)
        except subprocess.TimeoutExpired as error:
            timed_out = True
            failure = {"type": type(error).__name__, "message": str(error)}
        except OSError as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    record = {"command": command, "returncode": None if result is None else result.returncode,
              "timed_out": timed_out, "failure": failure, "host_elapsed_sec": time.monotonic() - started,
              "log": {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}}
    write(args.evidence / (label + ".json"), record)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual bounded command failed: " + label)
    return record

def inspect(args, name, label):
    call(args, [args.docker, "inspect", name], label)
    value = json.loads((args.evidence / (label + ".log")).read_text())
    if type(value) is not list or len(value) != 1:
        raise ValueError("one actual inspected object required")
    return value[0]

def build(args, plan):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("actual Linux amd64 host required")
    verify_payload(PAYLOAD)
    args.evidence.mkdir(parents=True, exist_ok=True)
    anonymous = args.evidence / "anonymous-docker-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        call(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    base = inspect(args, BASE, "base-inspect")
    if "sha256:5a190afe0bdfe7685e64cbf1aec30d39885199c85f688a971b8d4a0ab8d217eb" not in " ".join(base.get("RepoDigests", [])):
        raise ValueError("actual base digest differs")
    tag = "t3-cold-native-projection-scalar-reads-controls-v2-1:" + uuid.uuid4().hex
    call(args, [args.docker, "build", "--platform", "linux/amd64", "--pull=false", "--progress=plain", "-t", tag,
                "-f", str(PAYLOAD / "control/Dockerfile"), str(PAYLOAD)], "image-build", 2400)
    image = inspect(args, tag, "image-inspect")
    if image["Config"]["Entrypoint"] != ENTRYPOINT or image["Config"]["User"] != "65534:65534":
        raise ValueError("actual cold native output image entry/user differs")
    evidence_owner = uuid.uuid4().hex
    evidence_name = "t3-lightweight-source-" + uuid.uuid4().hex
    evidence_commands = linux.DockerCommands(args.docker, args.evidence / "source-copy-commands", args.log_cap_bytes)
    copied = args.evidence / "installed"
    copied_ok = False
    cleanup = None
    try:
        made = evidence_commands.call(["create", "--name", evidence_name,
            "--label", linux.OWNER_LABEL + "=" + evidence_owner, "--pull", "never", image["Id"]], "create", 30)
        if not made["succeeded"]:
            raise RuntimeError("source evidence container create failed")
        info, _ = evidence_commands.inspect(evidence_name, cleanup=True)
        if info is None:
            raise ValueError("source evidence container absent")
        linux.require_owned(info, evidence_name, evidence_owner, image["Id"])
        copied_ok = evidence_commands.call(["cp", evidence_name + ":/opt/cold-native-projection-scalar-reads-controls-v2-1", str(copied)], "installed-copy", 60)["succeeded"]
    finally:
        cleanup = linux.settle_container(evidence_commands, evidence_name, evidence_owner, image["Id"], creation_uncertain=True)
        write(args.evidence / "SOURCE_COPY_EXECUTION.json", {"name": evidence_name, "owner": evidence_owner,
            "image_id": image["Id"], "commands": evidence_commands.rows, "cleanup": cleanup, "rankable": False})
    if (not copied_ok or cleanup["settled"] is not True or cleanup["removed"] is not True
            or cleanup["final_absent"] is not True or cleanup["errors"] != []):
        raise ValueError("actual source-copy cleanup/exact absence failed")
    # Frozen sources, generated metadata and pin are inspected after the actual
    # build rather than accepted from Dockerfile text or claimed receipt flags.
    for row in plan["candidate_sources"]:
        actual = copied / CANDIDATE / row["path"]
        if actual.stat().st_size != row["bytes"] or sha(actual) != row["sha256"]:
            raise ValueError("installed candidate source differs")
    if inventory(copied / BASELINE) != plan["baseline_sources"]:
        raise ValueError("installed baseline source differs")
    if sha(copied / GENERATOR) != plan["generator_sha256"]:
        raise ValueError("installed exact schema generator differs")
    metadata = copied / CANDIDATE / "runtime/schema_metadata_v1.json"
    pin = copied / CANDIDATE / "runtime/schema_metadata_pin_v1.py"
    deployed = json.loads((copied / "schema-build/DEPLOYED_SCHEMA_PIN_RECEIPT_v1.json").read_text())
    if (deployed["metadata"]["sha256"] != sha(metadata) or deployed["metadata"]["bytes"] != metadata.stat().st_size
            or deployed["source_pin"]["sha256"] != sha(pin) or deployed["source_pin"]["bytes"] != pin.stat().st_size):
        raise ValueError("actual generated metadata/pin binding differs")
    pin_tree = ast.parse(pin.read_bytes())
    pin_value = ast.literal_eval(next(node.value for node in pin_tree.body if isinstance(node, ast.Assign)
        and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "SCHEMA_METADATA_SHA256"))
    baseline_schema = json.loads((copied / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json").read_text())
    if (pin_value != sha(metadata) or baseline_schema.get("versions") != {"numpy": "1.26.4", "pandas": "1.5.3", "pyarrow": "15.0.2"}
            or baseline_schema.get("metadata", {}).get("sha256") != sha(metadata)
            or baseline_schema.get("generator", {}).get("sha256") != plan["generator_sha256"]
            or deployed.get("baseline_receipt_sha256") != sha(copied / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json")):
        raise ValueError("actual pinned schema generator/receipt/source constant differs")
    expected_runtime = {row["path"][len("runtime/"):]: {"bytes": row["bytes"], "sha256": row["sha256"]}
        for row in plan["candidate_sources"] if row["path"].startswith("runtime/")}
    actual_runtime = inventory(copied / CANDIDATE / "runtime")
    for name in ("schema_metadata_v1.json", "schema_metadata_pin_v1.py"):
        if name not in actual_runtime:
            raise ValueError("actual generated schema runtime file absent")
        actual_runtime.pop(name)
    if actual_runtime != expected_runtime:
        raise ValueError("actual runtime contains changed or extra ordinary sources")
    for name, expected in plan["control_sources"].items():
        actual = copied / "control" / name
        if actual.stat().st_size != expected["bytes"] or sha(actual) != expected["sha256"]:
            raise ValueError("actual installed cold native output control source differs")
    write(args.evidence / "ACTUAL_BUILD_INVENTORY_v1.json", {"schema": "t3-cold-native-projection-buffers-build-inventory-v1",
        "base_image": base["Id"], "screen_image": image["Id"], "installed_files": inventory(copied),
        "generated_metadata_sha256": sha(metadata), "generated_pin_sha256": sha(pin),
        "candidate_source_receipt_sha256": plan["candidate_source_receipt_sha256"],
        "candidate_imported_during_build": False, "kernel_or_market_run": False, "Cython_and_C_compile_performed": True, "build_stage_resources_not_official_timing": True, "rankable": False})
    for key, runtime in (("baseline", copied / BASELINE), ("light_canonical", copied / CANDIDATE), ("light_dynamic", copied / CANDIDATE)):
        if sha(runtime / ("agent.py" if key == "baseline" else "production_cli.py")) != plan["actual_entry_sources"][key]["sha256"]:
            raise ValueError("actual deployed entry differs")
    verify_native_construction(copied, plan, args.evidence)
    write(args.evidence / "BUILD_READY.json", {"image_id": image["Id"], "base_id": base["Id"], "passed": True, "rankable": False})

class StrictCommands(linux.DockerCommands):
    def call(self, arguments, label, seconds=30, cleanup=False):
        if arguments and arguments[0] == "create":
            arguments = [arguments[0], "--env", "PYTHONHASHSEED=0", "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456", *arguments[1:]]
        return super().call(arguments, label, seconds, cleanup)

    def inspect(self, name, cleanup=False, seconds=30):
        info, record = super().inspect(name, cleanup, seconds)
        if info is not None and not cleanup:
            if info["Config"]["Entrypoint"] != ENTRYPOINT: raise ValueError("actual market screen entrypoint differs")
            environment = dict(value.split("=", 1) for value in info["Config"].get("Env", []) if "=" in value)
            expected_environment = {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
                "NUMEXPR_NUM_THREADS": "1", "PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1"}
            if any(environment.get(name) != value for name, value in expected_environment.items()):
                raise ValueError("actual strict scientific/hash/bytecode environment differs")
            host = info["HostConfig"]
            limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
            if limits != {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}:
                raise ValueError("actual full finite screen ulimits differ")
            binds = [row for row in info["Mounts"] if row["Type"] == "bind"]
            if len(binds) != 2 or {row["Destination"]: row["RW"] for row in binds} != {"/input": False, "/output": True}:
                raise ValueError("actual input/output-only bind envelope differs")
        return info, record

def duration_ns(state):
    def parse(value):
        base, fraction = value.rstrip("Z").split(".", 1)
        return calendar.timegm(datetime.strptime(base, "%Y-%m-%dT%H:%M:%S").timetuple()) * 10 ** 9 + int(fraction.ljust(9, "0"))
    return (parse(state["FinishedAt"]) - parse(state["StartedAt"])) / 10 ** 9

def pair(output, other, item):
    paths = list(public.SUB_FILES[:2]) if item["shape"] == "single" else [sub["sub"] + "/" + name for sub in item["subs"] for name in public.SUB_FILES[:2]]
    frames = [public.compare_frame(output / name, other / name) for name in paths]
    sidecars = ["events.json"] if item["shape"] == "single" else [sub["sub"] + "/events.json" for sub in item["subs"]] + ["batch_events.json"]
    stable = []
    for name in sidecars:
        a, b = public.read_json(output / name), public.read_json(other / name)
        for value in (a, b):
            for key in ("wall_clock_sec", "events_per_sec", "peak_memory_bytes", "gpu_seconds"): value.pop(key, None)
        stable.append({"path": name, "passed": a == b, "baseline": b, "candidate": a})
    return {"passed": all(row["passed"] and row.get("byte_equal") for row in frames) and all(row["passed"] for row in stable), "frames": frames, "stable_sidecars": stable}

def run_one(args, image_id, arm, item, folder, suffix, reference=True):
    execution, output = linux.run_container(args, image_id, arm, item, folder, args.owner, suffix)
    row = {"arm": arm, "unit": item["unit"], "execution": execution, "output": str(output), "passed": False,
           "rankable": False, "timing_included": False}
    try:
        if not execution["succeeded"] or any(sha(Path(value["staged"])) != value["sha256"] for value in execution["staged_inputs"]):
            raise ValueError("actual strict run or original staged input failed")
        inspected = execution["effective_config"]["Config"]
        if inspected["Entrypoint"] != ENTRYPOINT or inspected["Cmd"][-2:] != ["--mode", arm]:
            raise ValueError("actual exact-source CLI route differs")
        row["output_inventory"] = inventory(output)
        events = public.read_json(output / ("events.json" if item["shape"] == "single" else "batch_events.json"))
        if reference:
            row["reference_checks"] = public.verify_outputs(args.reference_root / item["unit"], output, item)
            row["developer_verifier"] = linux.gate(args, args.reference_root / item["unit"], output, folder)
            if not row["reference_checks"]["passed"] or row["developer_verifier"]["admissible"] is not True:
                raise ValueError("actual official reference or unchanged verifier failed")
        else:
            frames = [public.compare_frame(output / name, Path(item["isolated_reference"]) / name) for name in public.SUB_FILES[:2]]
            checked = public.verify_events(output, public.read_json(item["scenario_paths"][0]), frames[0].get("candidate_rows", 0))
            tree = public.check_tree(output, set(public.SUB_FILES))
            if not all(value["passed"] for value in frames) or not checked["passed"] or not tree["passed"]:
                raise ValueError("actual isolated member reference/sidecar/output tree failed")
            row["reference_checks"] = {"passed": True, "actual_events": frames[0]["candidate_rows"], "frames": frames, "sidecar": checked, "tree": tree}
        actual = row["reference_checks"]["actual_events"]
        if events.get("n_events", events.get("total_events")) != actual: raise ValueError("actual trace rows/sidecar differ")
        if item["shape"] == "batch" and [r["sub"] for r in events["per_scenario"]] != sorted(r["sub"] for r in item["subs"]):
            raise ValueError("actual batch source CLI sorted order differs")
        row.update(actual_events=actual, cli_wall_sec=events["wall_clock_sec"], settled_container_runtime_sec=duration_ns(execution["state"]),
                   daemon_started_at=execution["state"]["StartedAt"], daemon_finished_at=execution["state"]["FinishedAt"])
        if any(not math.isfinite(value) or value <= 0 for value in (row["cli_wall_sec"], row["settled_container_runtime_sec"], execution["host_wall_sec"])):
            raise ValueError("actual positive finite daemon/host/CLI times required")
        row["passed"] = True
    except BaseException as error:
        row["failure"] = {"type": type(error).__name__, "message": str(error)}
    write(folder / "RUN_RESULT.json", row)
    print(arm, item["unit"], "PASS" if row["passed"] else "FAIL", flush=True)
    return row

def archive(args):
    if args.artifact is None or args.artifact.exists(): raise ValueError("fresh artifact required")
    args.artifact.mkdir(parents=True)
    if args.evidence.exists(): shutil.copytree(args.evidence, args.artifact / "evidence", ignore=shutil.ignore_patterns("anonymous-docker-config"))
    shutil.copytree(PAYLOAD, args.artifact / "payload")
    write(args.artifact / "ARTIFACT.json", {"all_actual_output_bytes_retained": True, "files": inventory(args.artifact), "rankable": False})

linux.DockerCommands = StrictCommands


def verify_native_construction(copied, plan, evidence):
    candidate = copied / CANDIDATE
    result = public.read_json(copied / "construction/CONSTRUCTION_RESULT.json")
    if (result.get("schema") != "t3-cold-native-projection-buffers-real-construction-v1" or result.get("all_passed") is not True
            or "failure" in result or result.get("participant_imported") is not False
            or result.get("market_executed") is not False or result.get("rankable") is not False):
        raise ValueError("actual construction failed; partial source/C/object/ELF logs retained")
    expected_commands = ("compiler-version", "compiler-target", "libc-version", "translation", "native-build", "schema-build")
    if tuple(row["label"] for row in result["commands"]) != expected_commands:
        raise ValueError("actual complete construction command roster differs")
    for row in result["commands"]:
        log = copied / "construction" / (row["label"] + ".log")
        if row["returncode"] != 0 or row["timed_out"] or row["log"] != {"bytes": log.stat().st_size, "sha256": sha(log)}:
            raise ValueError("actual construction command/log failed")
    spec = public.read_json(candidate / "compile_spec.json")
    translation = public.read_json(candidate / "translation/TRANSLATION_RECEIPT.json")
    build = public.read_json(candidate / "build/BUILD_RECEIPT.json")
    pins = {"source_receipt_sha256": plan["candidate_source_receipt_sha256"],
        "runtime_pins_sha256": sha(candidate / "RUNTIME_PINS.json"), "compile_spec_sha256": sha(candidate / "compile_spec.json")}
    for receipt in (translation, build):
        if any(receipt.get(name) != value for name, value in pins.items()) or receipt.get("dependencies") != spec["dependencies"]:
            raise ValueError("actual translation/build exact source/ABI dependency pins differ")
        if receipt.get("participant_imported") is not False or receipt.get("market_executed") is not False:
            raise ValueError("construction imported participant or ran market")
    unsafe = ("-ffast-math", "-Ofast", "-funsafe-math-optimizations", "-ffinite-math-only",
        "-freciprocal-math", "-fassociative-math")
    ambient = build.get("ambient_flags", {})
    if (ambient != result.get("ambient_flags") or set(ambient) != {"CFLAGS", "CPPFLAGS", "LDFLAGS"}
            or any(flag in value for value in ambient.values() for flag in unsafe)
            or spec.get("compile_flags") != ["-O2", "-fPIC", "-fno-fast-math", "-ffp-contract=off"]):
        raise ValueError("actual native compiler numeric flags differ")
    if (translation.get("translation_succeeded") is not True or translation.get("C_compiler_run") is not False
            or translation.get("ELF_built") is not False or build.get("build_succeeded") is not True
            or build.get("extension_build_count") != 1 or len(build.get("extensions", [])) != 1
            or build["ABI"] != {"python": [3, 11, 17], "implementation": "cpython", "platform": "linux",
                "machine": "x86_64", "pointer_bits": 64, "byteorder": "little",
                "extension_suffix": ".cpython-311-x86_64-linux-gnu.so"}):
        raise ValueError("actual pinned native construction receipts differ")
    if "x86_64" not in (copied / "construction/compiler-target.log").read_text():
        raise ValueError("actual compiler target is not x86_64")
    generated = translation["generated_C"]
    if len(generated) != 1 or generated[0]["module"] != "dynamic_arena_chain":
        raise ValueError("actual translation module roster differs")
    for root, rows in ((candidate / "translation", generated), (candidate / "build", build["extensions"])):
        for row in rows:
            path = root / row["path"]
            if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
                raise ValueError("actual generated C/native ELF differs")
    native = build["extensions"][0]
    if native["module"] != "dynamic_arena_chain" or native["path"] != "native/dynamic_arena_chain.cpython-311-x86_64-linux-gnu.so":
        raise ValueError("actual deployment native path differs")
    elf = (candidate / "build" / native["path"]).read_bytes()
    if len(elf) < 20 or elf[:6] != b"\x7fELF\x02\x01" or int.from_bytes(elf[18:20], "little") != 62:
        raise ValueError("actual little-endian ELF64 x86_64 artifact required")
    if not inventory(candidate / "build/objects") or not inventory(candidate / "build/generated"):
        raise ValueError("actual generated build C and compiler objects absent")
    build_c = [path for path in (candidate / "build/generated").rglob("*.c")
        if not any(part.startswith("._") for part in path.parts)]
    translation_c = candidate / "translation" / generated[0]["path"]
    if len(build_c) != 1 or build_c[0].name != "dynamic_arena_chain.c" or build_c[0].read_bytes() != translation_c.read_bytes():
        raise ValueError("actual full translation C differs from build-generated C")
    for name in ("translation", "build"):
        if inventory(candidate / name) != result["native_partial_inventory"][name]:
            raise ValueError("actual postconstruction C/object/ELF inventory differs")
    write(evidence / "ACTUAL_NATIVE_CONSTRUCTION.json", {"all_passed": True, "construction": result,
        "translation": translation, "build": build, "actual_ELF64_x86_64_header_checked": True,
        "translation_C_equal_build_C": True, "actual_full_generated_C_sha256": sha(build_c[0]),
        "source_C_objects_ELF_retained": True, "construction_resources_not_official_timing": True, "rankable": False})


def validate_native_output_fixtures(root):
    report = public.read_json(root / "NATIVE_OUTPUT_FIXTURES.json")
    if (report.get("schema") != "t3-cold-native-projection-buffer-fixture-controller-v1"
            or report.get("all_passed") is not True or "failure" in report
            or report.get("market_executed") is not False or report.get("rankable") is not False
            or report.get("actual_parquet_bytes_equal") is not True
            or report.get("actual_independent_pandas_readback_equal") is not True):
        raise ValueError("actual separate original/native serializer controls failed")
    expected_cases = ("stable_cross_owner_ties", "exact_timestamp_side_normalization", "signed_trace_boundaries")
    records = []
    for arm in ("original", "native"):
        child = public.read_json(root / arm / "FIXTURE_RECEIPT.json")
        if (report["children"][arm] != child or child.get("schema") != "t3-cold-native-projection-buffer-fixtures-v1"
                or child.get("arm") != arm or child.get("market_executed") is not False
                or child.get("native_fixture_owners_initialized") is not False
                or tuple(row["trace_case"] for row in child["cases"]) != expected_cases):
            raise ValueError("actual complete native output fixture receipt differs")
        expected_files = {label + "/" + name for label in expected_cases for name in ("trace.parquet", "message_trace.parquet")}
        if arm == "native":
            expected_files.update("retained_after_owner_destruction/" + name for name in ("trace.parquet", "message_trace.parquet"))
        if ({row["path"] for row in child["files"]} != expected_files
                or set(inventory(root / arm)) != expected_files | {"FIXTURE_RECEIPT.json"}):
            raise ValueError("actual native/original complete fixture file roster differs")
        if child["versions"] != ({"numpy": "1.26.4", "pyarrow": "15.0.2", "pandas": "1.5.3"} if arm == "original" else {"numpy": "1.26.4", "pyarrow": "15.0.2"}):
            raise ValueError("actual fixture dependency versions differ")
        if arm == "native" and (child.get("forbidden_import_attempts") != [] or set(child["boundary_cases"]) != {
                "nonstring_endstate_keys_decline_without_callbacks", "ledger_alias_and_hostile_map",
                "message_bool_range_and_string_declines", "trace_signed53_bool_side_unknown_event_declines",
                "sealed_immutable_native_descriptor_authority", "immutable_buffers_survive_graph_owner_destruction"}):
            raise ValueError("actual native scalar/key/null/lifetime controls incomplete")
        for row in child["files"]:
            path = root / arm / row["path"]
            if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
                raise ValueError("actual native output fixture file changed")
    if report["children"]["original"]["cases"] != report["children"]["native"]["cases"]:
        raise ValueError("actual independent original/native expected fixture values differ")
    import pyarrow.parquet as pq
    for case in report["children"]["original"]["cases"]:
        label = case["trace_case"]
        for name, expected in (("trace.parquet", case["expected_trace"]), ("message_trace.parquet", case["expected_messages"])):
            old, new = root / "original" / label / name, root / "native" / label / name
            compared = public.compare_frame(new, old)
            if not compared["passed"] or not compared["byte_equal"]:
                raise ValueError("actual native/original full serializer files differ")
            table = pq.read_table(new)
            if table.to_pydict() != expected:
                raise ValueError("actual native serializer expected full rows differ")
            records.append({"case": label, "file": name, "actual_all_columns_readback_equal": True, **compared})
    for name in ("trace.parquet", "message_trace.parquet"):
        original = root / "native/signed_trace_boundaries" / name
        retained = root / "native/retained_after_owner_destruction" / name
        if retained.read_bytes() != original.read_bytes():
            raise ValueError("actual immutable output buffers failed owner destruction lifetime")
    return {"all_passed": True, "report": report, "actual_readback_records": records,
        "six_full_original_native_files_byte_equal": True, "owner_destruction_bytes_retained": True,
        "market_executed": False, "rankable": False}


def validate_controls(output, plan, bundle):
    admission = public.read_json(output / "ADMISSION.json")
    if (admission.get("all_passed") is not True or admission.get("actual_loaded_sources_and_native_ELF_checked") is not True
            or admission.get("market_executed") is not False or admission.get("rankable") is not False
            or len(admission.get("cases", [])) != 9):
        raise ValueError("actual nine original markets native admission prerequisite failed")
    for actual, expected in zip(admission["cases"], bundle["admission_scenarios"]):
        if actual != {"unit": expected["unit"], "scenario_sha256": expected["scenario_sha256"],
                "source_authenticated": True, "native_admitted": True}:
            raise ValueError("actual original scenario native admission identity differs")
    if public.read_json(output / "scenario.json") != bundle["scenario"]:
        raise ValueError("actual six-child scenario source differs")
    children = output / "children"
    report = public.read_json(children / "CONTROLS.json")
    if (report.get("schema") != "t3-cold-native-projection-buffers-real-controls-v1"
            or report.get("all_passed") is not True or "failure" in report
            or report.get("rankable") is not False or report.get("source_only") is not False):
        raise ValueError("actual six-child whole-market controls failed")
    expected_cases = ("actual_required_owner_selection", "trace.parquet", "message_trace.parquet", "STATE.json",
        "complete_actual_event_counts", "cold_readonly_output_and_binding_controls",
        "positive_actual_native_arena_and_repeat_equivalence", "each_projector_complete_pair_fallback_without_rerun")
    if tuple(row["case"] for row in report["cases"]) != expected_cases or not all(row["passed"] for row in report["cases"]):
        raise ValueError("actual finite control result roster failed")
    records, counts = [], []
    baseline = children / "original"
    expected_paths = {"ADMISSION.json", "scenario.json", "children/CONTROLS.json"}
    fixtures = validate_native_output_fixtures(output / "native-fixtures")
    expected_paths.update("native-fixtures/" + path for path in inventory(output / "native-fixtures"))
    for name in CONTROL_ARMS:
        arm = children / name
        selection = public.read_json(arm / "ARM_SELECTION.json")
        native = name not in ("original", "light_canonical")
        kernel = "NativeOwnerKernel" if native else "CanonicalKernel"
        if selection.get("selected_kernel") != kernel or selection.get("native_authority") is not native or selection.get("passed") is not True:
            raise ValueError("actual native/canonical kernel selection differs")
        status = public.read_json(arm / "CONTROL_CHILD.json")
        declined = {"decline_trace": "trace", "decline_message_trace": "message_trace"}.get(name, "none")
        if (status.get("actual_markets") != 1 or status.get("graph_output_readonly") is not True
                or status.get("bindings_restored") is not True or status.get("observer_finished") is not True
                or status.get("forced_projector_decline") != declined or status.get("production_import_attempts") != []):
            raise ValueError("actual one-market/control restoration or cold import differs")
        cold = status["cold_import_status"]
        if name != "original" and cold != {"pandas_loaded": declined != "none", "scipy_loaded": False,
                "stock_cli_loaded": False, "unused_stock_loaded": False}:
            raise ValueError("actual normal/pair-fallback dependency boundary differs")
        events = public.read_json(arm / "events.json")
        counts.append(events["n_events"])
        for filename in ("trace.parquet", "message_trace.parquet"):
            compared = public.compare_frame(arm / filename, baseline / filename)
            if not compared["passed"] or not compared.get("byte_equal"):
                raise ValueError("actual complete whole-market Parquet bytes/dtypes differ")
            if filename == "trace.parquet" and compared["candidate_rows"] != events["n_events"]:
                raise ValueError("actual control event count differs")
            records.append({"arm": name, "file": filename, **compared})
        if (arm / "STATE.json").read_bytes() != (baseline / "STATE.json").read_bytes():
            raise ValueError("actual complete state graph bytes differ")
        files = ("ARM_SELECTION.json", "CONTROL_CHILD.json", "events.json", "STATE.json", "trace.parquet", "message_trace.parquet", "child.log")
        expected_paths.update("children/" + name + "/" + path for path in files)
        if name != "original":
            witness = public.read_json(arm / "OUTPUT_WITNESS.json")
            if (witness.get("source_authenticated") is not True or witness.get("observer_admitted") is not True
                    or witness.get("market_rerun") is not False or witness.get("actual_trace_sha256") != sha(arm / "trace.parquet")
                    or witness.get("selected_kernel") != kernel or witness.get("native_admitted") is not native
                    or witness.get("projectors_admitted") is not (declined == "none")
                    or witness.get("output_mode") != ("legacy-pandas" if declined != "none" else "native-canonical-arrow-buffers" if native else "canonical-arrow-buffers")
                    or witness.get("native_output_pair") is not (native and declined == "none")
                    or witness.get("declines") != ({} if declined == "none" else {declined: "control-forced-projector-decline"})):
                raise ValueError("actual projector admission or complete-pair fallback differs")
            expected_paths.add("children/" + name + "/OUTPUT_WITNESS.json")
        if native:
            diag = public.read_json(arm / "ARENA_DIAGNOSTICS.json")
            if (diag.get("rankable") is not False or diag.get("speed_claim") is not False
                    or diag["messages"]["constructed_messages"] <= 0 or diag["orders"]["order_slots"] <= 0):
                raise ValueError("actual arena diagnostics scope differs")
            expected_paths.add("children/" + name + "/ARENA_DIAGNOSTICS.json")
    if public.read_json(children / "light_dynamic/ARENA_DIAGNOSTICS.json") != public.read_json(children / "light_dynamic_repeat/ARENA_DIAGNOSTICS.json"):
        raise ValueError("actual dynamic/repeat arena diagnostics differ")
    if len(set(counts)) != 1 or counts[0] <= 0 or len(records) != 12 or set(inventory(output)) != expected_paths:
        raise ValueError("actual complete six-child output/count/file roster differs")
    return {"report": report, "admission": admission, "native_output_fixtures": fixtures, "actual_parquet_records": records,
        "full_actual_STATE_bytes_equal": True, "six_independent_markets": True, "rankable": False}


def screen(args, plan):
    args.owner = uuid.uuid4().hex; args.timeout = 300
    ready = public.read_json(args.evidence / "BUILD_READY.json"); image_id = ready["image_id"]
    before = linux.image_metadata(args, image_id, args.evidence / "image-before-screen")
    actual_installed = args.evidence / "installed"
    expected_build = public.read_json(args.evidence / "ACTUAL_BUILD_INVENTORY_v1.json")
    if (before["inspection"]["Config"]["Entrypoint"] != ENTRYPOINT
            or inventory(actual_installed) != expected_build["installed_files"] or expected_build["screen_image"] != image_id):
        raise ValueError("actual immutable build/entry/source inventory changed before screen")
    roster = public.collect_plan(args.reference_root, list(SINGLES) + [BATCH]); write(args.evidence / "REFERENCE_PLAN.json", roster)
    items = {value["unit"]: value for value in roster["units"]}
    if len(items[BATCH]["subs"]) != 5: raise ValueError("actual original five-member batch required")
    admissions = []
    for item in roster["units"]:
        for path in item["scenario_paths"]:
            original = Path(path)
            admissions.append({"unit": item["unit"] + ("/" + original.stem if item["shape"] == "batch" else ""),
                "scenario_sha256": sha(original), "scenario": public.read_json(original)})
    bundle = {"proof_command": "cold-native-projection-buffers-six-children-and-fixtures-v1",
        "scenario": public.read_json(PAYLOAD / "control/control_scenario.json"), "admission_scenarios": admissions}
    if len(admissions) != 9: raise ValueError("nine declared official admission scenarios required")
    rows, failure, first, serial, controls_execution_count = [], None, {}, 0, 0
    try:
        control_input = args.evidence / "fixed-control-input.json"; write(control_input, bundle)
        args.timeout = 3600
        execution, output = linux.run_container(args, image_id, "controls", {"shape": "single", "scenario_paths": [str(control_input)]},
            args.evidence / "controls", args.owner, "controls")
        controls_execution_count = 1; args.timeout = 300
        if not execution["succeeded"]: raise ValueError("actual complete native controls container failed")
        controls = validate_controls(output / "controls", plan, bundle)
        write(args.evidence / "CONTROL_RESULT.json", {"passed": True, "execution": execution, **controls})
        for repeat in (-1, 0, 1):
            for index, unit in enumerate(list(SINGLES) + [BATCH]):
                order = arm_order(index, repeat); group = {}
                for arm in order:
                    serial += 1
                    folder = args.evidence / "screen" / ("warmup" if repeat < 0 else "repeat-" + str(repeat)) / unit / arm
                    row = run_one(args, image_id, arm, items[unit], folder, "%04d" % serial)
                    row.update(stage="screen", repeat=repeat, warmup=repeat < 0, order=order, timing_included=repeat >= 0)
                    rows.append(row); group[arm] = row; write(args.evidence / "RAW_RESULTS.json", rows)
                    if not row["passed"]: raise ValueError("actual finite screen stopped at failed run")
                for arm, row in group.items():
                    current = Path(row["output"]); previous = first.setdefault((unit, arm), current)
                    row["same_round_pair"] = pair(current, Path(group["baseline"]["output"]), items[unit])
                    row["same_arm_repeat_pair"] = pair(current, previous, items[unit])
                    row["passed"] &= row["same_round_pair"]["passed"] and row["same_arm_repeat_pair"]["passed"]
                    write(current.parent / "RUN_RESULT.json", row); write(args.evidence / "RAW_RESULTS.json", rows)
                    if not row["passed"]: raise ValueError("actual pair/repeat output differs")
        for arm in ARMS:
            full = next(row for row in reversed(rows) if row["unit"] == BATCH and row["arm"] == arm)
            for sub in items[BATCH]["subs"]:
                serial += 1
                item = {"unit": BATCH + "/" + sub["sub"], "shape": "single", "subs": [],
                    "scenario_paths": [str(args.reference_root / BATCH / sub["scenario_file"])],
                    "isolated_reference": str(args.reference_root / BATCH / "checks/reference_data" / sub["sub"])}
                folder = args.evidence / "isolation" / arm / sub["sub"]
                row = run_one(args, image_id, arm, item, folder, "%04d" % serial, reference=False)
                row.update(stage="isolation", timing_included=False)
                row["isolation_pair"] = pair(Path(row["output"]), Path(full["output"]) / sub["sub"], item)
                row["passed"] &= row["isolation_pair"]["passed"]; rows.append(row)
                write(folder / "RUN_RESULT.json", row); write(args.evidence / "RAW_RESULTS.json", rows)
                if not row["passed"]: raise ValueError("actual batch fresh isolation differs")
    except BaseException as error:
        failure = {"type": type(error).__name__, "message": str(error)}
    unchanged = all(sha(args.reference_root / item["unit"] / name) == value for item in roster["units"]
        for mapping in (item["input_sha256"], item["reference_sha256"]) for name, value in mapping.items())
    immutable = False
    try:
        after = linux.image_metadata(args, image_id, args.evidence / "image-after-screen")
        immutable = before["inspection"] == after["inspection"]
        verify_payload(PAYLOAD)
        if inventory(actual_installed) != expected_build["installed_files"] or not immutable:
            raise ValueError("actual image or installed build sources changed during screen")
    except BaseException as error:
        failure = failure or {"type": type(error).__name__, "message": str(error)}
    measured = [row for row in rows if row.get("timing_included")]
    official = sum("developer_verifier" in row for row in rows)
    gates = sum(gate.get("passed") is True for row in rows for gate in
        (row.get("developer_verifier", {}).get("verdict") or {}).get("gate_results", {}).values())
    rates = []
    for index, unit in enumerate(list(SINGLES) + [BATCH]):
        unit_rows = {}
        for arm in ARMS:
            group = [row for row in measured if row["arm"] == arm and row["unit"] == unit and row["passed"]]
            if len(group) != 2: break
            if any(row["order"] != arm_order(index, row["repeat"]) for row in group):
                raise ValueError("actual measured orders not paired rotation/reversal")
            samples = [{"repeat": row["repeat"], "N": row["actual_events"], "T": row["settled_container_runtime_sec"],
                "events_per_sec": row["actual_events"] / row["settled_container_runtime_sec"],
                "cli_wall_sec": row["cli_wall_sec"], "cli_events_per_sec": row["actual_events"] / row["cli_wall_sec"]} for row in group]
            unit_rows[arm] = {"samples": samples, "N_over_T_median": statistics.median(v["events_per_sec"] for v in samples),
                "N_over_T_mean": statistics.mean(v["events_per_sec"] for v in samples)}
        if len(unit_rows) == 3:
            rates.append({"unit": unit, "arms": unit_rows,
                "dynamic_vs_baseline_N_over_T_median_ratio": unit_rows["light_dynamic"]["N_over_T_median"] / unit_rows["baseline"]["N_over_T_median"],
                "dynamic_vs_light_N_over_T_median_ratio": unit_rows["light_dynamic"]["N_over_T_median"] / unit_rows["light_canonical"]["N_over_T_median"]})
    score_surrogate = {arm: statistics.mean(row["arms"][arm]["N_over_T_median"] for row in rates) for arm in ARMS} if len(rates) == 5 else None
    summary = {"schema": "t3-cold-native-projection-buffers-market-real-diagnostic-v1",
        "all_passed": failure is None and len(rows) == 60 and len(measured) == 30 and official == 45 and gates == 180
            and len(rates) == 5 and all(row["passed"] for row in rows) and unchanged and immutable,
        "failure": failure, "ordinary_runs": len(rows), "planned_ordinary_runs": 60, "measured_runs": len(measured),
        "execution_containers": len(rows) + controls_execution_count, "planned_execution_containers": 61,
        "official_verifier_calls": official, "official_gate_passes": gates,
        "original_inputs_references_unchanged": unchanged, "image_unchanged": immutable,
        "per_unit_actual_N_over_T": rates, "five_unit_mean_of_per_unit_median_N_over_T": score_surrogate,
        "benefit_evidence": "Per actual run N divided by settled Docker StartedAt/FinishedAt T; per-unit median and mean kept separately.",
        "rankable": False, "diagnostic_only": True, "full71": False, "formal_repeats": False,
        "official_score": None, "submission_ready": False, "actual_entry_sources": plan["actual_entry_sources"],
        "heavy_witness_in_measured_production": False, "phase_runs": 0, "planned_market_episodes": 102}
    summary["native_output_fixture_children"] = 2
    summary["third_arm_definition"] = "light_dynamic runs frozen cold native trace/message primitive buffers"
    summary["native_output_fixture_controls_required"] = True
    write(args.evidence / "SUMMARY.json", summary)
    if not summary["all_passed"]: raise RuntimeError("actual cold native output finite diagnostic incomplete or failed")


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("stage", choices=("build", "screen", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True); parser.add_argument("--reference-root", type=Path)
    parser.add_argument("--gate-kit", type=Path); parser.add_argument("--gate-python", default=sys.executable)
    parser.add_argument("--docker", default="docker"); parser.add_argument("--artifact", type=Path)
    parser.add_argument("--log-cap-bytes", type=int, default=16 * 1024 ** 2)
    args = parser.parse_args(); args.evidence = args.evidence.resolve(); args.evidence.mkdir(parents=True, exist_ok=True)
    signal.signal(signal.SIGINT, linux.cancellation); signal.signal(signal.SIGTERM, linux.cancellation)
    if args.stage == "artifact": archive(args); return
    try:
        plan = verify_payload(PAYLOAD)
        if args.stage == "build": build(args, plan)
        else: screen(args, plan)
    except BaseException as error:
        write(args.evidence / "FAILURE_v1.json", {"type": type(error).__name__, "message": str(error), "rankable": False})
        raise


if __name__ == "__main__": main()
