# T3 task and rules index — checked 2026-10-09

## Executive summary

Track 3 asks for a faster market simulator that preserves the organizer's market behavior. A submission is a Linux/amd64 Docker image implementing both `simulate` and `simulate-batch`. Correctness comes first: every declared market must pass its semantic and message-ledger checks, and its event count must equal the reference. The current Development service measures one run on a shared host; planned Final timing measures repeated runs on a dedicated host. Use the current official toolkit, truthful timing sidecars, reproducible Parquet outputs, and the official two-file submission ZIP. Older local documents describe rules that have since changed.

## 依据、版本与范围

核对日期：**2026-10-09，Asia/Shanghai**。本文根据当天读取的公开 upstream 编写。原始文件、URL、抓取时间、SHA-256 保存在本目录的 `evidence/`；这是项目规范证据，不含私人归档、密钥、封闭场景或答案。

同日 `git ls-remote` 观察到 Track 3 main 为 `bffb57227f796f9fa769a23d01fc364bee14a119`，shared toolkit main 为 `6fe0fe79f638759891fc0a097d0a57eaff9fe772`，v2.5.1 tag ref 为 `bca9c350f08b473afb790aec47250d0f454aaa9b`。文件下载使用 main/tag URL，原始字节另外固定 SHA-256；这些 ref 是抓取后的观察，不伪称原始请求内带 commit provenance。

规则优先级：现行 Track 3 README / CLI 与实际 scorer、现行 shared toolkit schema / parser / pack 命令、官方 unit card；历史本地说明仅用于追踪旧实验。**不修改任务 unit、参考输出、评分门禁来让候选通过。**

现行 Track 3 要求安装 **qfbench2-common v2.5.1**。其 scorer 至少要求 v2.4.4 的 `digest_members` / `stable_output_binding`；本地 v2.3.1 文档已过时。v2.5.1 内部的 descriptor guide 示例仍写 v2.4.4，但当天 Track 3 README / AGENTS / CI 明确 pin v2.5.1，应采用后者。scorer / toolkit 用 Python 3.13；ABIDES baseline 使用独立 Python 3.11 环境。

```bash
pip install "qfbench2-common[data] @ git+https://github.com/Agenthon-2026/Agenthon2026-public.git@v2.5.1#subdirectory=common"
```

不可复制或另写共享评分公式；应导入官方 toolkit。若对 task kit 本身贡献代码，遵守其 CI 的 Ruff 0.4.7、Mypy 1.13.0 strict、行为修改测试与 manifest/firewall 检查；这些是贡献 task kit 的规范，并非要求 participant image 必须包含 linters。Track 3 AGENTS 要求每份文档以财务学生能理解的 plain-English executive summary 开头。

## 任务本身：优化什么

目标是 **离散事件市场仿真**：`abides-core` kernel、`abides-markets` exchange / agents / order book；`abides-gym` 不在范围。允许 Cython、Numba、Rust/PyO3、C++、NumPy 等内部实现，只要 CLI、输出、市场语义保持。GPU 使用可选。

从任务出发，优先优化事件队列、消息构建/复制、延迟采样、订单簿更新和 Parquet 输出；独立 batch markets 可并行，但每个 market 的 agent / RNG / book / order-id 状态必须隔离。单场景同价同时间事件的顺序、随机抽样调用顺序、matching 顺序不能随意改变。

现行公开 roster 为 **71 units = 65 single + 6 batch**，6 batch 合计 30 subs（3、4、4、5、6、8）。原 `t3-EXAMPLE-vectorized-matching` 已移至 `examples/`，属于文档示例，**不在计分 roster**。本地旧快照有 72 cards 不代表现行 roster。batch 名称来自输入 JSON 文件 stem，不能合成 `sub_NN`；`agent_configs` 为输入的权威 agent 配置，不能只依赖部分场景才有的 `agent_mix`。

## 输入与接口

镜像构建为 `linux/amd64`，必须带：

```dockerfile
LABEL qfbench2.interface_version="2.0"
```

两个 verb 均必须接受：

```text
simulate       --config /input/scenario.json --out /output/trace.parquet
simulate-batch --batch-dir /input/scenarios  --out-dir /output
```

verb 是 image 后的第一参数。可以无 ENTRYPOINT、将两个 executable 放入 PATH，也可由 ENTRYPOINT parser 接受 leading positional verb；成功必须 exit 0。Final 镜像不能声明 Docker `VOLUME`，包括 base image 继承的 VOLUME。

CLI 描述 unit-dir mount，但本地 `throughput/run_unit.py` 只 stage `scenario.json` 或 `scenarios/*.json`。实现必须能仅依赖这些仿真输入运行，不依赖 `/input/card.toml`、`manifest.json`、`batch.json`、参考 traces 是否被挂载。评分器从 organizer unit card 的 `[scoring.params]` 读取容差与 ledger 要求；scenario 内 `tolerance` 只是文档，不是 scorer 的 policy 来源。

## 输出与正确性

| 形状 | 契约产物 |
|---|---|
| single | `trace.parquet`、`events.json`；需要时 `message_trace.parquet`；可选 `profile.json` |
| batch | 根 `batch_events.json`；每个 declared sub 的 `trace.parquet`、`events.json`、`message_trace.parquet`；各 sub 可选 `profile.json` |

当前 official Development / Final **不会仅因出现非契约文件而拒绝整个输出树**，但这些文件计入文件数与字节上限；本地 harness 仍按 `limits.py` closed allowlist 拒绝额外文件。日志写 stdout/stderr，产物保持上表便可兼容两者。`profile.json` 当前已进入 allowlist，是可选诊断信息，不影响排名或 admissibility。

`trace.parquet` 为 Snappy compressed、无 index 的确定性行序；7 列遵守官方 registry：

| 列 | dtype |
|---|---|
| `t_ns` | int64 |
| `agent_id` | int32 |
| `msg_type` | string |
| `side` | string (`BID` / `ASK` / null) |
| `price` | int64 |
| `size` | int64 |
| `order_id` | int64 |

事件词表固定：`ORDER_SUBMITTED`、`ORDER_ACCEPTED`、`ORDER_FILLED`、`PARTIAL_FILL`、`ORDER_CANCELLED`、`ORDER_REPLACED`、`QUOTE_UPDATE`。不得删除 PARTIAL_FILL。保留 canonical adapter 对无对应值/订单的表示，不自行增加自定义事件。

`events.json` 六个核心必填：`scenario_id`、`seed`、`n_events`、`wall_clock_sec`、`events_per_sec`、`trace_sha256`。必须满足：scenario_id / seed 与输入相同；n_events 等于实际 trace 行数；rate 等于 count / real wall clock，容差 5%；trace_sha256 是文件关闭后计算的 candidate 文件 SHA-256。可加 `peak_memory_bytes` / `gpu_seconds`，如实填写资源测量。

**不要伪造恒定耗时来让 sidecar 重复字节相同。** 当前 repeat policy 区分 stable Parquet 和 volatile sidecars。字段 `wall_clock_sec`、`events_per_sec`、`peak_memory_bytes`、`gpu_seconds` 可随运行变化；trace、ledger 和 event count 必须重复一致。

`batch_events.json` 按 README 契约包含 `n_scenarios`、`total_events`、`wall_clock_sec`、`events_per_sec`、`per_scenario`。n_scenarios 应为输入 subs 数量；per_scenario 精确覆盖 declared subs，无重复无额外项，每项 n_events 等于对应 Parquet 行数，其和等于 total_events，aggregate rate 算术一致。**当前 batch.py 的 check_aggregate 未单独检查 n_scenarios**，这不是省略该契约字段的理由。

语义门禁按 unit card 决定，全部 unit 都必须通过，无多数票或 80% 通关规则：

| 门禁 | 要求 |
|---|---|
| 全部 units 的事件数 | trace 行数精确等于 deterministic reference；**Tier B 也必须相等** |
| Tier A | fills 的 order_id / price / size 按位置与顺序相同；fill t_ns 默认误差 ≤ 1,000 ns；全事件 multiset 双向覆盖一致；whole-sequence Kendall tau ≥ 0.999 |
| Tier B | mid-price log-return KS ≤ 0.08；mean spread 偏差 ≤ 10 bps |
| Family 5 stylized facts | KS ≤ 0.08，ACF abs RMS ≤ 0.12，Hill abs error ≤ 1.5，depth JS ≤ 0.10，四项全部通过 |
| batch isolation | 每 sub 对应 isolated reference，任一 sub 失败即整个 batch 失败 |

注意：官方 `trace_sha256` 对 candidate 自身重算，Tier A 并不以 candidate Parquet 必须与 reference 文件 SHA 完全相同作为唯一/额外语义判断。与本地 baseline 字节相同是有力差分证据；正式跨重复 stable artifacts 字节一致则是明确要求。不要把前者误报为独立官方门禁。

message ledger 的 10 列：`seq,t_recv_ns,t_send_ns,latency_ns,src_id,dst_id,message_id,msg_type,order_id,causal_parent`。59 / 65 single cards 要求 ledger，所有 6 batch 都要求每 sub ledger，合计 65 / 71 units。batch card false 不能豁免。六个 `t3-gb-*` single 可以不写 ledger；一般实现始终写完整 ledger 最容易覆盖必需场景，但大场景应同时核对总产物字节。

ledger 自一致要求：非空；seq 为完整 `0..N-1` permutation；`(message_id,dst_id)` 唯一（广播 message_id 本身可重复）；sent rows `recv-send == latency >= 0`；causal parent 先送达 sender、child 后发送；AGENT_WAKEUP self-address、zero latency、null send time。参考比较要求 sent-message coverage ≥ reference 的 90%、latency KS ≤ 0.08、wakeup count 相对偏差 ≤ 5%。exchange-protocol family 还检查 execution-report 子序列 fidelity。

## 当前资源与计时

| 项 | Development 当前服务 | Planned Final |
|---|---|---|
| runtime | runc | runc |
| CPU / memory | 4 CPU quota；16 GiB；swap disabled | card 4 CPU / 16G |
| network | none；无 House/model allocation | none |
| 单 run 时间上限 | 无 card timeout 时 1,800 s，包含 create / required pull | 300 s，timeout/crash/OOM 记该 unit 0 |
| worker / timing | shared queue，single run，rankable=false | same pinned otherwise-idle instance，顺序 launch |
| score 时间窗口 | create 到 remove，含 startup / teardown | Docker State.StartedAt 到 FinishedAt，含 runtime/GPU startup，排除 create/inspect/remove |
| 聚合 | 练习反馈 | 每 unit 重复 rates 的 median，再对完整 evaluation roster 求 arithmetic mean，降序 |

Dev ingestion stage 独立上限 43,200 s（12h），units sequential；queue wait 在 stage clock 外，scoring 有自己的 clock。`disk="10G"` 不是现行 launcher 的 writable workspace 承诺。

当前 Development 额外限制：uid 65534 non-root、read-only root、cap-drop ALL/no-new-privileges、256 PID/threads、1024 fd/process、`/tmp` 为 64 MiB tmpfs，noexec/nosuid/nodev。需要写缓存时在允许目录安排；不要在运行时安装依赖、不能依赖 `/tmp` 执行新编译文件。

**2026-10-07 Track 3 更新**将 Dev 和 Final 的单文件及完整输出树提高为 **256 MiB**；tmp 仍 64 MiB。v2.5.1 tag 内 general runtime guide 的 64 MiB 表格较旧，现行 shared main guide 与 Track 3 README / limits.py 已明确 T3 override。另有限制：≤256 files、≤4096 tree entries、无 symlink/hardlink/special file/unsafe bits、无非法/大小写或 Unicode 冲突路径、无过度 sparse 文件，不能留下空输出。按契约产物仅根与 sub 两层即可。

官方硬件说明是 NVIDIA B200、sm_100；GPU 可选，CUDA 12.x images 可运行。依赖在 image build 时固定并完整打包。旧本地“gVisor syscall/IPC tax”实验不是当前 runc 服务的性能约束，不应用来拒绝可行的实现或声称当前性能。

Final 重复：当前 README 写 five runs；官方 C1 fixture 是 `repeats=5,warmup_discarded=1,every_repeat_must_pass=true`。**实际比赛仍以 organizer 预提交 C1 plan 的重复数及 warmup policy 为权威，不能将只有两个 fixture handles 的 golden fixture 当比赛 roster。**包括 discarded warmup 在内每一轮都必须成功，stable Parquet / count 与评分轮相同。repeat producer 与 consumer 的 `t3-stable-output-v1` 协调发布仍是官方 Final release 条件；本地测试不能宣称已证明其部署。

本地 Final 演练可固定 5 次、丢 1 次并设 `QFB2_T3_RUN_TIMEOUT_SEC=300`；rate 用外部 wall clock / actual counts。历史 3 repeats、native Mac 配额/专属机器、自定义 1.05x 或 geometric ratio 晋级门禁不是官方必需条件；保留作为本地诊断，不阻止合规提交，也不冒充正式评分。正式同分按更早 Final upload 打破，CI lower bound 不决定同分。

## 提交物与打包

按 immutable digest 提交镜像；当前支持 anonymous-pullable public image，或 **organizer 已确认可用**的 private mirror。`image_access=organizer_mirror` 字符串不会自动转存或授权 backend。普通登录状态 docker pull 不证明匿名可拉；使用官方 anonymous registry check。

descriptor 用现行 C5 fixture 起步，12 required closed-vocabulary fields：

```text
schema_version interface_version competition_id team_id track phase category
image image_access models license descriptor_digest
```

本 task 的值为 schema_version `1.1.0`、interface_version `2.0`、track `simulation`、category `simulator`、无模型 `models: []`；Dev competition_id `agenthon2026-simulation-dev`、phase `dev`。Final 遵循其 phase-specific descriptor。image 是 registry / repository / `sha256:<64hex>` digest 对象。license 如实声明自己代码许可证。禁止旧字段 image_digest / model_disclosure / house_endpoint_only / open_weights / api_domains。descriptor digest 用官方 JCS seal 和 `SubmissionDescriptor.from_mapping` 验证，不能只做 jsonschema 或自写 canonicalization shim。

team_id 是网站 team number 与 Team Key 派生，不是旧示例任意 team alias。官方 pack 使用 hidden prompt 或 mode600 `--team-key-file`，不通过命令行 key、日志或 ZIP 保存密钥。最终 ZIP **只有根的 submission.json 和 team-claim.json**；claim schema_version `2.0` 包含 team number、descriptor exact bytes hash 与 proof。任何 key 不进入 source、image、ZIP、日志或用户可下载证据。

```bash
qfbench2 submission pack --descriptor submission.json --team-number <N> --out submission.zip
```

此命令只本地打包、不消耗次数。实际上传到团队指定 CodaBench account 的 T3 competition page。Dev 5/day、20 total；held/cancelled uploads 也计数，平台 Failed 不消耗 attempt。Dev 到 2026-10-12 23:59 AoE（北京时间 10-13 19:59），Final+Verification 到 10-25 23:59 AoE（北京时间 10-26 19:59）；Final 每团队每 track 仅一份，不需另交 participant verification submission。

## 完成前验证路径

1. 使用当前 toolkit 及 track scorer，先确认 71-unit roster、reference LFS material、schema/manifest，不把旧 Mac resource gates 或 exemplar 当官方 roster。
2. 对支持两个 verb 的最终镜像在 runc、4CPU/16GiB、offline、non-root/RO root/tmp限制下运行 65 single + 6 batch；每个必须 exit0、写完整契约文件、计数与参考一致。
3. 导入官方 `semantics/scoring/batch/limits` 并运行 unchanged developer gates；公开 regression runner 覆盖65 single，batch单独用 scorer isolation/aggregate 与单独运行差分验证，不以 regression runner 代替 batch 检查。
4. 验证最终 build 的5轮 deterministic Parquet/count，300s Final演练；保持真实可变 sidecar。将本地 wall-clock / Developer score 与正式 C2 ranking 分开描述。
5. 检查 Docker architecture / LABEL / 无 VOLUME / anonymous pull，current descriptor parser + seal，官方 pack，两ZIP成员及无secret；随后执行已获授权的上传，记录真正 submission ID/status/反馈，不将只pack或git commit写成比赛提交完成。

## 来源索引

| 来源 | 用途 | 本地证据 |
|---|---|---|
| [Track 3 current README](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/README.md) | roster、Dev/Final、输出、时间、依赖、日程 | `evidence/current_upstream/README.md` |
| [Track 3 current CLI](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/SUBMISSION_CLI.md) | verb、extra outputs、VOLUME、ZIP/claim、上传 | `evidence/current_upstream/SUBMISSION_CLI.md` |
| [Track 3 current AGENTS](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/AGENTS.md) | 文档/代码/firewall、scorer ownership、资源 | `evidence/current_upstream/AGENTS.md` |
| [Current scoring.py](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/qfbench2_track_simulation/scoring.py) | gate chain、exact counts、Dev C2 elapsed | `evidence/current_upstream/qfbench2_track_simulation/scoring.py` |
| [Current semantics.py](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/qfbench2_track_simulation/semantics.py) | Tier A/B、ledger、protocol | `evidence/current_upstream/semantics.py` |
| [Current batch.py](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/qfbench2_track_simulation/batch.py) | aggregate/isolation、n_scenarios实现边界 | `evidence/current_upstream/qfbench2_track_simulation/batch.py` |
| [Current limits.py](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/qfbench2_track_simulation/limits.py) | allowlist、profile、256MiB、stable/volatile政策 | `evidence/current_upstream/qfbench2_track_simulation/limits.py` |
| [Current telemetry.py](https://github.com/Agenthon-2026/track3-simulation-public/blob/main/qfbench2_track_simulation/telemetry.py) | stable-output evidence、所有轮sidecar验证 | `evidence/current_upstream/qfbench2_track_simulation/telemetry.py` |
| [Current runtime guide](https://github.com/Agenthon-2026/Agenthon2026-public/blob/main/docs/DEVELOPMENT-RUNTIME.md) | T3 10月7日256MiB override、runc/进程/temp | `evidence/toolkit_main_DEVELOPMENT-RUNTIME.md` |
| [v2.5.1 descriptor guide](https://github.com/Agenthon-2026/Agenthon2026-public/blob/v2.5.1/starter-packs/track3/SUBMISSION-DESCRIPTOR.md) | 12字段、models=[]、JCS、双文件ZIP | `evidence/toolkit_v2.5.1/starter-packs/track3/SUBMISSION-DESCRIPTOR.md` |
| [v2.5.1 team claim guide](https://github.com/Agenthon-2026/Agenthon2026-public/blob/v2.5.1/starter-packs/track3/TEAM-CLAIM.md) | alias/key/proof/account/pack | `evidence/toolkit_v2.5.1/starter-packs/track3/TEAM-CLAIM.md` |
| [v2.5.1 image guide](https://github.com/Agenthon-2026/Agenthon2026-public/blob/v2.5.1/docs/IMAGE-SUBMISSIONS.md) | anonymous pull与已确认private route | `evidence/toolkit_v2.5.1/docs/IMAGE-SUBMISSIONS.md` |
| [v2.5.1 C1 simulation fixture](https://github.com/Agenthon-2026/Agenthon2026-public/blob/v2.5.1/common/qfbench2_common/contracts/fixtures/c1/simulation_final.expanded.json) | 示例5轮/丢1/每轮过，非实际roster | `evidence/toolkit_v2.5.1/common/qfbench2_common/contracts/fixtures/c1/simulation_final.expanded.json` |
| [v2.5.1 C5 simulation fixture](https://github.com/Agenthon-2026/Agenthon2026-public/blob/v2.5.1/common/qfbench2_common/contracts/fixtures/c5/simulation_dev.json) | descriptor起点 | `evidence/toolkit_v2.5.1/common/qfbench2_common/contracts/fixtures/c5/simulation_dev.json` |

抓取 inventory：`evidence/current_upstream/FETCH_METADATA.json`、`evidence/toolkit_v2.5.1/FETCH_METADATA.json`、`evidence/MAIN_FOLLOWUP_FETCH_METADATA.json`；refs 记录 `evidence/UPSTREAM_REFS.json`。公开 GitHub commit API 本次 rate-limited，后续用只读 `git ls-remote` 取得上述 ref；原始响应字节用 SHA-256 固定。本文仅为规范审查，未执行候选、未修改官方 units / reference / scorer、未使用远程算力。
