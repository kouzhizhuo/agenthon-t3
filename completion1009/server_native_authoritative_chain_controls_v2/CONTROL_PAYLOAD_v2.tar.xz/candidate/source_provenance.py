"""Stdlib source/ABI binding for future authorized build and controls."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE_RECEIPT = "SOURCE_PREPARATION_RECEIPT_v1.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean_path(relative):
    parts = Path(relative).parts
    return bool(parts) and not Path(relative).is_absolute() and all(
        item not in (".", "..", "__pycache__") and not item.startswith("._") for item in parts)


def verify_sources():
    receipt = json.loads((HERE / SOURCE_RECEIPT).read_bytes())
    if receipt.get("frozen_build_input") is not True or receipt.get("unfrozen") is not False:
        raise ValueError("current frozen build-input receipt required")
    rows = receipt["files"]
    if len({row["path"] for row in rows}) != len(rows):
        raise ValueError("duplicate candidate source pins")
    for row in rows:
        path = HERE / row["path"]
        if not clean_path(row["path"]) or len(path.read_bytes()) != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("frozen candidate source changed")
    return receipt


def verify_runtime(runtime):
    runtime = Path(runtime).resolve()
    pins = json.loads((HERE / "RUNTIME_PINS.json").read_bytes())
    for row in pins["files"]:
        path = runtime / row["path"]
        if not clean_path(row["path"]) or len(path.read_bytes()) != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("frozen original runtime changed")
    return pins
