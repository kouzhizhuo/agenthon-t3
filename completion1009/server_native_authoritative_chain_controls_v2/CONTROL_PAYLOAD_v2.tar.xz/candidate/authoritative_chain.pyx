# cython: language_level=3, annotation_typing=False, infer_types=False
"""Typed-slot authoritative trader; original numeric/object semantics retained.

Generated from pinned original AST, no participant body is invoked on an
incompatible extension instance. Original initialization must complete first.
"""
import logging
import sys
import warnings
from copy import deepcopy
import numpy as np
import pandas as pd
import observer as _observer
from abides_core.agent import logger as agent_logger
from abides_core.utils import fmt_ts
from abides_core.message import MessageBatch
from abides_markets.agents.trading_agent import TradingAgent, logger as trading_logger
from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
from abides_markets.messages.market import MarketClosePriceRequestMsg, MarketClosePriceMsg, MarketClosedMsg, MarketHoursRequestMsg, MarketHoursMsg
from abides_markets.messages.marketdata import MarketDataMsg, L2DataMsg
from abides_markets.messages.order import LimitOrderMsg, MarketOrderMsg, PartialCancelOrderMsg, CancelOrderMsg, ModifyOrderMsg, ReplaceOrderMsg
from abides_markets.messages.orderbook import OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg, OrderPartialCancelledMsg, OrderModifiedMsg, OrderReplacedMsg
from abides_markets.messages.query import QueryLastTradeMsg, QueryLastTradeResponseMsg, QuerySpreadMsg, QuerySpreadResponseMsg, QueryOrderStreamMsg, QueryOrderStreamResponseMsg, QueryTransactedVolMsg, QueryTransactedVolResponseMsg
from abides_markets.orders import LimitOrder, MarketOrder, Order, Side
from abides_markets.utils import dollarize

DEFAULT_CANCEL_TAG, DEFAULT_CANCEL_METADATA = TradingAgent.cancel_order.__defaults__
DEFAULT_PARTIAL_CANCEL_TAG, DEFAULT_PARTIAL_CANCEL_METADATA = TradingAgent.partial_cancel_order.__defaults__
_MISSING = object()
FIELDS = ('MKT_BUY', 'MKT_SELL', '_mid_history', 'basket_size', 'book', 'current_time', 'daily_close_price', 'depth_levels', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'lookback', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'order_size_std', 'orders', 'price_offset_ticks', 'random_state', 'reference_price', 'sigma_n', 'size_per_level', 'spread_ticks', 'starting_cash', 'state', 'stream_history', 'symbol', 'threshold_ticks', 'transacted_volume', 'type')
REQUIRED_FIELDS = {'NoiseTrader': ('MKT_BUY', 'MKT_SELL', 'basket_size', 'current_time', 'daily_close_price', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'order_size_std', 'orders', 'price_offset_ticks', 'random_state', 'reference_price', 'starting_cash', 'state', 'stream_history', 'symbol', 'transacted_volume', 'type'), 'MarketMaker': ('MKT_BUY', 'MKT_SELL', 'basket_size', 'current_time', 'daily_close_price', 'depth_levels', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'orders', 'random_state', 'reference_price', 'size_per_level', 'spread_ticks', 'starting_cash', 'state', 'stream_history', 'symbol', 'transacted_volume', 'type'), 'ValueTrader': ('MKT_BUY', 'MKT_SELL', 'basket_size', 'current_time', 'daily_close_price', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'orders', 'random_state', 'sigma_n', 'starting_cash', 'state', 'stream_history', 'symbol', 'threshold_ticks', 'transacted_volume', 'type'), 'MomentumTrader': ('MKT_BUY', 'MKT_SELL', '_mid_history', 'basket_size', 'current_time', 'daily_close_price', 'exchange_id', 'exchange_ts', 'executed_orders', 'first_wake', 'holdings', 'id', 'interval_ns', 'kernel', 'known_asks', 'known_bids', 'last_trade', 'log', 'log_events', 'log_orders', 'log_to_file', 'lookback', 'mkt_close', 'mkt_closed', 'mkt_open', 'name', 'nav_diff', 'oracle', 'order_size_mean', 'orders', 'random_state', 'starting_cash', 'state', 'stream_history', 'symbol', 'threshold_ticks', 'transacted_volume', 'type')}
ORIGINAL_CLASSES = {"NoiseTrader": NoiseTrader, "MarketMaker": MarketMaker,
                    "ValueTrader": ValueTrader, "MomentumTrader": MomentumTrader}


def exact_original_class(value):
    for name, klass in ORIGINAL_CLASSES.items():
        if type(value) is klass:
            return name
    raise ValueError("typed trader requires exact declared original strategy")


import heapq
from datetime import datetime
from abides_core.kernel import Kernel as IncumbentKernel, logger as kernel_logger
from abides_core.message import WakeupMsg
from abides_core.utils import str_to_ns, ns_date
from abides_markets.order_book import logger as book_logger
from abides_markets.agents.exchange_agent import ExchangeAgent, logger as exchange_logger
from abides_markets.messages.marketdata import BookImbalanceDataMsg, L1SubReqMsg, L2SubReqMsg, L3SubReqMsg, TransactedVolSubReqMsg, MarketDataSubReqMsg, L1DataMsg, L2DataMsg, L3DataMsg, TransactedVolDataMsg, BookImbalanceSubReqMsg, MarketDataEventMsg
from abides_markets.messages.order import OrderMsg
from abides_markets.messages.query import QueryMsg
from abides_markets.price_level import PriceLevel
import sys
def _positive_row(row):
    return row[1] > 0

cdef class NativeTrader:
    def __cinit__(self):
        self._prepared = False
        self._bound = False

    def __init__(self, source_agent):
        if self._prepared:
            raise ValueError("native trader construction is one-shot")
        self._prepared = True
        self._scheduler = None
        self._missing = _MISSING
        self._bound = False
        self._strategy_name = exact_original_class(source_agent)
        self._origin_class = type(source_agent)
        self._source_agent = source_agent
        values = source_agent.__dict__
        if type(values) is not dict or set(values) != set(REQUIRED_FIELDS[self._strategy_name]):
            raise ValueError("original initialized strategy field roster differs")
        if values["kernel"] is None or values["oracle"] is not values["kernel"].oracle:
            raise ValueError("original initialization and oracle owner required")
        if type(values["id"]) is not int or values["id"] <= 0:
            raise ValueError("original dense trader identity required")
        self._slot_MKT_BUY = _MISSING
        self._slot_MKT_SELL = _MISSING
        self._slot__mid_history = _MISSING
        self._slot_basket_size = _MISSING
        self._slot_book = _MISSING
        self._slot_current_time = _MISSING
        self._slot_daily_close_price = _MISSING
        self._slot_depth_levels = _MISSING
        self._slot_exchange_id = _MISSING
        self._slot_exchange_ts = _MISSING
        self._slot_executed_orders = _MISSING
        self._slot_first_wake = _MISSING
        self._slot_holdings = _MISSING
        self._slot_id = _MISSING
        self._slot_interval_ns = _MISSING
        self._slot_kernel = _MISSING
        self._slot_known_asks = _MISSING
        self._slot_known_bids = _MISSING
        self._slot_last_trade = _MISSING
        self._slot_log = _MISSING
        self._slot_log_events = _MISSING
        self._slot_log_orders = _MISSING
        self._slot_log_to_file = _MISSING
        self._slot_lookback = _MISSING
        self._slot_mkt_close = _MISSING
        self._slot_mkt_closed = _MISSING
        self._slot_mkt_open = _MISSING
        self._slot_name = _MISSING
        self._slot_nav_diff = _MISSING
        self._slot_oracle = _MISSING
        self._slot_order_size_mean = _MISSING
        self._slot_order_size_std = _MISSING
        self._slot_orders = _MISSING
        self._slot_price_offset_ticks = _MISSING
        self._slot_random_state = _MISSING
        self._slot_reference_price = _MISSING
        self._slot_sigma_n = _MISSING
        self._slot_size_per_level = _MISSING
        self._slot_spread_ticks = _MISSING
        self._slot_starting_cash = _MISSING
        self._slot_state = _MISSING
        self._slot_stream_history = _MISSING
        self._slot_symbol = _MISSING
        self._slot_threshold_ticks = _MISSING
        self._slot_transacted_volume = _MISSING
        self._slot_type = _MISSING
        if 'MKT_BUY' in values:
            self._slot_MKT_BUY = values['MKT_BUY']
        if 'MKT_SELL' in values:
            self._slot_MKT_SELL = values['MKT_SELL']
        if '_mid_history' in values:
            self._slot__mid_history = values['_mid_history']
        if 'basket_size' in values:
            self._slot_basket_size = values['basket_size']
        if 'book' in values:
            self._slot_book = values['book']
        if 'current_time' in values:
            self._slot_current_time = values['current_time']
        if 'daily_close_price' in values:
            self._slot_daily_close_price = values['daily_close_price']
        if 'depth_levels' in values:
            self._slot_depth_levels = values['depth_levels']
        if 'exchange_id' in values:
            self._slot_exchange_id = values['exchange_id']
        if 'exchange_ts' in values:
            self._slot_exchange_ts = values['exchange_ts']
        if 'executed_orders' in values:
            self._slot_executed_orders = values['executed_orders']
        if 'first_wake' in values:
            self._slot_first_wake = values['first_wake']
        if 'holdings' in values:
            self._slot_holdings = values['holdings']
        if 'id' in values:
            self._slot_id = values['id']
        if 'interval_ns' in values:
            self._slot_interval_ns = values['interval_ns']
        if 'kernel' in values:
            self._slot_kernel = values['kernel']
        if 'known_asks' in values:
            self._slot_known_asks = values['known_asks']
        if 'known_bids' in values:
            self._slot_known_bids = values['known_bids']
        if 'last_trade' in values:
            self._slot_last_trade = values['last_trade']
        if 'log' in values:
            self._slot_log = values['log']
        if 'log_events' in values:
            self._slot_log_events = values['log_events']
        if 'log_orders' in values:
            self._slot_log_orders = values['log_orders']
        if 'log_to_file' in values:
            self._slot_log_to_file = values['log_to_file']
        if 'lookback' in values:
            self._slot_lookback = values['lookback']
        if 'mkt_close' in values:
            self._slot_mkt_close = values['mkt_close']
        if 'mkt_closed' in values:
            self._slot_mkt_closed = values['mkt_closed']
        if 'mkt_open' in values:
            self._slot_mkt_open = values['mkt_open']
        if 'name' in values:
            self._slot_name = values['name']
        if 'nav_diff' in values:
            self._slot_nav_diff = values['nav_diff']
        if 'oracle' in values:
            self._slot_oracle = values['oracle']
        if 'order_size_mean' in values:
            self._slot_order_size_mean = values['order_size_mean']
        if 'order_size_std' in values:
            self._slot_order_size_std = values['order_size_std']
        if 'orders' in values:
            self._slot_orders = values['orders']
        if 'price_offset_ticks' in values:
            self._slot_price_offset_ticks = values['price_offset_ticks']
        if 'random_state' in values:
            self._slot_random_state = values['random_state']
        if 'reference_price' in values:
            self._slot_reference_price = values['reference_price']
        if 'sigma_n' in values:
            self._slot_sigma_n = values['sigma_n']
        if 'size_per_level' in values:
            self._slot_size_per_level = values['size_per_level']
        if 'spread_ticks' in values:
            self._slot_spread_ticks = values['spread_ticks']
        if 'starting_cash' in values:
            self._slot_starting_cash = values['starting_cash']
        if 'state' in values:
            self._slot_state = values['state']
        if 'stream_history' in values:
            self._slot_stream_history = values['stream_history']
        if 'symbol' in values:
            self._slot_symbol = values['symbol']
        if 'threshold_ticks' in values:
            self._slot_threshold_ticks = values['threshold_ticks']
        if 'transacted_volume' in values:
            self._slot_transacted_volume = values['transacted_volume']
        if 'type' in values:
            self._slot_type = values['type']

    def bind_scheduler(self, scheduler):
        cdef ChainScheduler typed
        if type(scheduler) is not ChainScheduler:
            raise ValueError("same-extension trader scheduler required")
        typed = scheduler
        if typed.kernel is not self._slot_kernel:
            raise ValueError("trader scheduler/kernel identity differs")
        if self._scheduler is not None and self._scheduler is not typed:
            raise ValueError("trader scheduler already bound")
        self._scheduler = typed

    def bind_after_source_retired(self):
        # Coordinator retires the original raw object only after all owners,
        # kernel list slots and observer key changes are preflighted together.
        if self._bound:
            raise ValueError("native trader already authoritative")
        if self._source_agent.__dict__ != {"_native_moved_to": id(self)}:
            raise ValueError("source raw agent retains a shadow state")
        if self._slot_kernel.ttl_messages != 0 or self._slot_kernel._deliver_seq != 0:
            raise ValueError("authority migration requires no runner delivery")
        if self._scheduler is None:
            raise ValueError("trader scheduler unbound")
        self._bound = True

    def abort_before_first_delivery(self):
        if self._slot_kernel.ttl_messages != 0 or self._slot_kernel._deliver_seq != 0:
            raise ValueError("cannot roll back an owner after runner delivery")
        self._bound = False

    def origin_class(self):
        return self._origin_class

    def strategy_name(self):
        return self._strategy_name

    def authority_bound(self):
        return bool(self._bound)

    cdef object _require_bound(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")

    def snapshot_fields(self):
        # Cold control/output mapping only. The event path never exports or
        # synchronizes this dict back into the retired source object.
        result = {}
        if self._slot_MKT_BUY is not self._missing:
            result['MKT_BUY'] = self._slot_MKT_BUY
        if self._slot_MKT_SELL is not self._missing:
            result['MKT_SELL'] = self._slot_MKT_SELL
        if self._slot__mid_history is not self._missing:
            result['_mid_history'] = self._slot__mid_history
        if self._slot_basket_size is not self._missing:
            result['basket_size'] = self._slot_basket_size
        if self._slot_book is not self._missing:
            result['book'] = self._slot_book
        if self._slot_current_time is not self._missing:
            result['current_time'] = self._slot_current_time
        if self._slot_daily_close_price is not self._missing:
            result['daily_close_price'] = self._slot_daily_close_price
        if self._slot_depth_levels is not self._missing:
            result['depth_levels'] = self._slot_depth_levels
        if self._slot_exchange_id is not self._missing:
            result['exchange_id'] = self._slot_exchange_id
        if self._slot_exchange_ts is not self._missing:
            result['exchange_ts'] = self._slot_exchange_ts
        if self._slot_executed_orders is not self._missing:
            result['executed_orders'] = self._slot_executed_orders
        if self._slot_first_wake is not self._missing:
            result['first_wake'] = self._slot_first_wake
        if self._slot_holdings is not self._missing:
            result['holdings'] = self._slot_holdings
        if self._slot_id is not self._missing:
            result['id'] = self._slot_id
        if self._slot_interval_ns is not self._missing:
            result['interval_ns'] = self._slot_interval_ns
        if self._slot_kernel is not self._missing:
            result['kernel'] = self._slot_kernel
        if self._slot_known_asks is not self._missing:
            result['known_asks'] = self._slot_known_asks
        if self._slot_known_bids is not self._missing:
            result['known_bids'] = self._slot_known_bids
        if self._slot_last_trade is not self._missing:
            result['last_trade'] = self._slot_last_trade
        if self._slot_log is not self._missing:
            result['log'] = self._slot_log
        if self._slot_log_events is not self._missing:
            result['log_events'] = self._slot_log_events
        if self._slot_log_orders is not self._missing:
            result['log_orders'] = self._slot_log_orders
        if self._slot_log_to_file is not self._missing:
            result['log_to_file'] = self._slot_log_to_file
        if self._slot_lookback is not self._missing:
            result['lookback'] = self._slot_lookback
        if self._slot_mkt_close is not self._missing:
            result['mkt_close'] = self._slot_mkt_close
        if self._slot_mkt_closed is not self._missing:
            result['mkt_closed'] = self._slot_mkt_closed
        if self._slot_mkt_open is not self._missing:
            result['mkt_open'] = self._slot_mkt_open
        if self._slot_name is not self._missing:
            result['name'] = self._slot_name
        if self._slot_nav_diff is not self._missing:
            result['nav_diff'] = self._slot_nav_diff
        if self._slot_oracle is not self._missing:
            result['oracle'] = self._slot_oracle
        if self._slot_order_size_mean is not self._missing:
            result['order_size_mean'] = self._slot_order_size_mean
        if self._slot_order_size_std is not self._missing:
            result['order_size_std'] = self._slot_order_size_std
        if self._slot_orders is not self._missing:
            result['orders'] = self._slot_orders
        if self._slot_price_offset_ticks is not self._missing:
            result['price_offset_ticks'] = self._slot_price_offset_ticks
        if self._slot_random_state is not self._missing:
            result['random_state'] = self._slot_random_state
        if self._slot_reference_price is not self._missing:
            result['reference_price'] = self._slot_reference_price
        if self._slot_sigma_n is not self._missing:
            result['sigma_n'] = self._slot_sigma_n
        if self._slot_size_per_level is not self._missing:
            result['size_per_level'] = self._slot_size_per_level
        if self._slot_spread_ticks is not self._missing:
            result['spread_ticks'] = self._slot_spread_ticks
        if self._slot_starting_cash is not self._missing:
            result['starting_cash'] = self._slot_starting_cash
        if self._slot_state is not self._missing:
            result['state'] = self._slot_state
        if self._slot_stream_history is not self._missing:
            result['stream_history'] = self._slot_stream_history
        if self._slot_symbol is not self._missing:
            result['symbol'] = self._slot_symbol
        if self._slot_threshold_ticks is not self._missing:
            result['threshold_ticks'] = self._slot_threshold_ticks
        if self._slot_transacted_volume is not self._missing:
            result['transacted_volume'] = self._slot_transacted_volume
        if self._slot_type is not self._missing:
            result['type'] = self._slot_type
        return result

    def source_identity(self):
        return self._source_agent

    def __lt__(self, other):
        return f'{self.id}' < f'{other.id}'

    def __hash__(self):
        # Primitive observer uses identity-keyed dictionaries; rich comparison
        # support must never accidentally suppress extension identity hashing.
        return object.__hash__(self)

    def wakeup(self, current_time):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._wakeup(current_time)

    def receive_message(self, current_time, sender_id, message):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._receive_message(current_time, sender_id, message)

    def act(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._act()

    def kernel_stopping(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._kernel_stopping()

    def kernel_terminating(self):
        if not self._bound:
            raise ValueError("native trader authority has not been committed")
        return self._kernel_terminating()

    cdef object _act(self):
        if self._strategy_name == 'NoiseTrader':
            return self._act_NoiseTrader()
        elif self._strategy_name == 'MarketMaker':
            return self._act_MarketMaker()
        elif self._strategy_name == 'ValueTrader':
            return self._act_ValueTrader()
        elif self._strategy_name == 'MomentumTrader':
            return self._act_MomentumTrader()
        raise ValueError('typed trader has unknown admitted strategy')




    property MKT_BUY:
        def __get__(self):
            if self._slot_MKT_BUY is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_BUY'")
            return self._slot_MKT_BUY

        def __set__(self, value):
            self._slot_MKT_BUY = value

        def __del__(self):
            if self._slot_MKT_BUY is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_BUY'")
            self._slot_MKT_BUY = self._missing

    property MKT_SELL:
        def __get__(self):
            if self._slot_MKT_SELL is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_SELL'")
            return self._slot_MKT_SELL

        def __set__(self, value):
            self._slot_MKT_SELL = value

        def __del__(self):
            if self._slot_MKT_SELL is self._missing:
                raise AttributeError("native owner has no initialized attribute 'MKT_SELL'")
            self._slot_MKT_SELL = self._missing

    property _mid_history:
        def __get__(self):
            if self._slot__mid_history is self._missing:
                raise AttributeError("native owner has no initialized attribute '_mid_history'")
            return self._slot__mid_history

        def __set__(self, value):
            self._slot__mid_history = value

        def __del__(self):
            if self._slot__mid_history is self._missing:
                raise AttributeError("native owner has no initialized attribute '_mid_history'")
            self._slot__mid_history = self._missing

    property basket_size:
        def __get__(self):
            if self._slot_basket_size is self._missing:
                raise AttributeError("native owner has no initialized attribute 'basket_size'")
            return self._slot_basket_size

        def __set__(self, value):
            self._slot_basket_size = value

        def __del__(self):
            if self._slot_basket_size is self._missing:
                raise AttributeError("native owner has no initialized attribute 'basket_size'")
            self._slot_basket_size = self._missing

    property book:
        def __get__(self):
            if self._slot_book is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book'")
            return self._slot_book

        def __set__(self, value):
            self._slot_book = value

        def __del__(self):
            if self._slot_book is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book'")
            self._slot_book = self._missing

    property current_time:
        def __get__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            return self._slot_current_time

        def __set__(self, value):
            self._slot_current_time = value

        def __del__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            self._slot_current_time = self._missing

    property daily_close_price:
        def __get__(self):
            if self._slot_daily_close_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'daily_close_price'")
            return self._slot_daily_close_price

        def __set__(self, value):
            self._slot_daily_close_price = value

        def __del__(self):
            if self._slot_daily_close_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'daily_close_price'")
            self._slot_daily_close_price = self._missing

    property depth_levels:
        def __get__(self):
            if self._slot_depth_levels is self._missing:
                raise AttributeError("native owner has no initialized attribute 'depth_levels'")
            return self._slot_depth_levels

        def __set__(self, value):
            self._slot_depth_levels = value

        def __del__(self):
            if self._slot_depth_levels is self._missing:
                raise AttributeError("native owner has no initialized attribute 'depth_levels'")
            self._slot_depth_levels = self._missing

    property exchange_id:
        def __get__(self):
            if self._slot_exchange_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_id'")
            return self._slot_exchange_id

        def __set__(self, value):
            self._slot_exchange_id = value

        def __del__(self):
            if self._slot_exchange_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_id'")
            self._slot_exchange_id = self._missing

    property exchange_ts:
        def __get__(self):
            if self._slot_exchange_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_ts'")
            return self._slot_exchange_ts

        def __set__(self, value):
            self._slot_exchange_ts = value

        def __del__(self):
            if self._slot_exchange_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'exchange_ts'")
            self._slot_exchange_ts = self._missing

    property executed_orders:
        def __get__(self):
            if self._slot_executed_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'executed_orders'")
            return self._slot_executed_orders

        def __set__(self, value):
            self._slot_executed_orders = value

        def __del__(self):
            if self._slot_executed_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'executed_orders'")
            self._slot_executed_orders = self._missing

    property first_wake:
        def __get__(self):
            if self._slot_first_wake is self._missing:
                raise AttributeError("native owner has no initialized attribute 'first_wake'")
            return self._slot_first_wake

        def __set__(self, value):
            self._slot_first_wake = value

        def __del__(self):
            if self._slot_first_wake is self._missing:
                raise AttributeError("native owner has no initialized attribute 'first_wake'")
            self._slot_first_wake = self._missing

    property holdings:
        def __get__(self):
            if self._slot_holdings is self._missing:
                raise AttributeError("native owner has no initialized attribute 'holdings'")
            return self._slot_holdings

        def __set__(self, value):
            self._slot_holdings = value

        def __del__(self):
            if self._slot_holdings is self._missing:
                raise AttributeError("native owner has no initialized attribute 'holdings'")
            self._slot_holdings = self._missing

    property id:
        def __get__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            return self._slot_id

        def __set__(self, value):
            self._slot_id = value

        def __del__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            self._slot_id = self._missing

    property interval_ns:
        def __get__(self):
            if self._slot_interval_ns is self._missing:
                raise AttributeError("native owner has no initialized attribute 'interval_ns'")
            return self._slot_interval_ns

        def __set__(self, value):
            self._slot_interval_ns = value

        def __del__(self):
            if self._slot_interval_ns is self._missing:
                raise AttributeError("native owner has no initialized attribute 'interval_ns'")
            self._slot_interval_ns = self._missing

    property kernel:
        def __get__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            return self._slot_kernel

        def __set__(self, value):
            self._slot_kernel = value

        def __del__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            self._slot_kernel = self._missing

    property known_asks:
        def __get__(self):
            if self._slot_known_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_asks'")
            return self._slot_known_asks

        def __set__(self, value):
            self._slot_known_asks = value

        def __del__(self):
            if self._slot_known_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_asks'")
            self._slot_known_asks = self._missing

    property known_bids:
        def __get__(self):
            if self._slot_known_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_bids'")
            return self._slot_known_bids

        def __set__(self, value):
            self._slot_known_bids = value

        def __del__(self):
            if self._slot_known_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'known_bids'")
            self._slot_known_bids = self._missing

    property last_trade:
        def __get__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            return self._slot_last_trade

        def __set__(self, value):
            self._slot_last_trade = value

        def __del__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            self._slot_last_trade = self._missing

    property log:
        def __get__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            return self._slot_log

        def __set__(self, value):
            self._slot_log = value

        def __del__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            self._slot_log = self._missing

    property log_events:
        def __get__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            return self._slot_log_events

        def __set__(self, value):
            self._slot_log_events = value

        def __del__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            self._slot_log_events = self._missing

    property log_orders:
        def __get__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            return self._slot_log_orders

        def __set__(self, value):
            self._slot_log_orders = value

        def __del__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            self._slot_log_orders = self._missing

    property log_to_file:
        def __get__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            return self._slot_log_to_file

        def __set__(self, value):
            self._slot_log_to_file = value

        def __del__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            self._slot_log_to_file = self._missing

    property lookback:
        def __get__(self):
            if self._slot_lookback is self._missing:
                raise AttributeError("native owner has no initialized attribute 'lookback'")
            return self._slot_lookback

        def __set__(self, value):
            self._slot_lookback = value

        def __del__(self):
            if self._slot_lookback is self._missing:
                raise AttributeError("native owner has no initialized attribute 'lookback'")
            self._slot_lookback = self._missing

    property mkt_close:
        def __get__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            return self._slot_mkt_close

        def __set__(self, value):
            self._slot_mkt_close = value

        def __del__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            self._slot_mkt_close = self._missing

    property mkt_closed:
        def __get__(self):
            if self._slot_mkt_closed is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_closed'")
            return self._slot_mkt_closed

        def __set__(self, value):
            self._slot_mkt_closed = value

        def __del__(self):
            if self._slot_mkt_closed is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_closed'")
            self._slot_mkt_closed = self._missing

    property mkt_open:
        def __get__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            return self._slot_mkt_open

        def __set__(self, value):
            self._slot_mkt_open = value

        def __del__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            self._slot_mkt_open = self._missing

    property name:
        def __get__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            return self._slot_name

        def __set__(self, value):
            self._slot_name = value

        def __del__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            self._slot_name = self._missing

    property nav_diff:
        def __get__(self):
            if self._slot_nav_diff is self._missing:
                raise AttributeError("native owner has no initialized attribute 'nav_diff'")
            return self._slot_nav_diff

        def __set__(self, value):
            self._slot_nav_diff = value

        def __del__(self):
            if self._slot_nav_diff is self._missing:
                raise AttributeError("native owner has no initialized attribute 'nav_diff'")
            self._slot_nav_diff = self._missing

    property oracle:
        def __get__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            return self._slot_oracle

        def __set__(self, value):
            self._slot_oracle = value

        def __del__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            self._slot_oracle = self._missing

    property order_size_mean:
        def __get__(self):
            if self._slot_order_size_mean is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_mean'")
            return self._slot_order_size_mean

        def __set__(self, value):
            self._slot_order_size_mean = value

        def __del__(self):
            if self._slot_order_size_mean is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_mean'")
            self._slot_order_size_mean = self._missing

    property order_size_std:
        def __get__(self):
            if self._slot_order_size_std is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_std'")
            return self._slot_order_size_std

        def __set__(self, value):
            self._slot_order_size_std = value

        def __del__(self):
            if self._slot_order_size_std is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_size_std'")
            self._slot_order_size_std = self._missing

    property orders:
        def __get__(self):
            if self._slot_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'orders'")
            return self._slot_orders

        def __set__(self, value):
            self._slot_orders = value

        def __del__(self):
            if self._slot_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'orders'")
            self._slot_orders = self._missing

    property price_offset_ticks:
        def __get__(self):
            if self._slot_price_offset_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price_offset_ticks'")
            return self._slot_price_offset_ticks

        def __set__(self, value):
            self._slot_price_offset_ticks = value

        def __del__(self):
            if self._slot_price_offset_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price_offset_ticks'")
            self._slot_price_offset_ticks = self._missing

    property random_state:
        def __get__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            return self._slot_random_state

        def __set__(self, value):
            self._slot_random_state = value

        def __del__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            self._slot_random_state = self._missing

    property reference_price:
        def __get__(self):
            if self._slot_reference_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reference_price'")
            return self._slot_reference_price

        def __set__(self, value):
            self._slot_reference_price = value

        def __del__(self):
            if self._slot_reference_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reference_price'")
            self._slot_reference_price = self._missing

    property sigma_n:
        def __get__(self):
            if self._slot_sigma_n is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sigma_n'")
            return self._slot_sigma_n

        def __set__(self, value):
            self._slot_sigma_n = value

        def __del__(self):
            if self._slot_sigma_n is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sigma_n'")
            self._slot_sigma_n = self._missing

    property size_per_level:
        def __get__(self):
            if self._slot_size_per_level is self._missing:
                raise AttributeError("native owner has no initialized attribute 'size_per_level'")
            return self._slot_size_per_level

        def __set__(self, value):
            self._slot_size_per_level = value

        def __del__(self):
            if self._slot_size_per_level is self._missing:
                raise AttributeError("native owner has no initialized attribute 'size_per_level'")
            self._slot_size_per_level = self._missing

    property spread_ticks:
        def __get__(self):
            if self._slot_spread_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'spread_ticks'")
            return self._slot_spread_ticks

        def __set__(self, value):
            self._slot_spread_ticks = value

        def __del__(self):
            if self._slot_spread_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'spread_ticks'")
            self._slot_spread_ticks = self._missing

    property starting_cash:
        def __get__(self):
            if self._slot_starting_cash is self._missing:
                raise AttributeError("native owner has no initialized attribute 'starting_cash'")
            return self._slot_starting_cash

        def __set__(self, value):
            self._slot_starting_cash = value

        def __del__(self):
            if self._slot_starting_cash is self._missing:
                raise AttributeError("native owner has no initialized attribute 'starting_cash'")
            self._slot_starting_cash = self._missing

    property state:
        def __get__(self):
            if self._slot_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'state'")
            return self._slot_state

        def __set__(self, value):
            self._slot_state = value

        def __del__(self):
            if self._slot_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'state'")
            self._slot_state = self._missing

    property stream_history:
        def __get__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            return self._slot_stream_history

        def __set__(self, value):
            self._slot_stream_history = value

        def __del__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            self._slot_stream_history = self._missing

    property symbol:
        def __get__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            return self._slot_symbol

        def __set__(self, value):
            self._slot_symbol = value

        def __del__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            self._slot_symbol = self._missing

    property threshold_ticks:
        def __get__(self):
            if self._slot_threshold_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'threshold_ticks'")
            return self._slot_threshold_ticks

        def __set__(self, value):
            self._slot_threshold_ticks = value

        def __del__(self):
            if self._slot_threshold_ticks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'threshold_ticks'")
            self._slot_threshold_ticks = self._missing

    property transacted_volume:
        def __get__(self):
            if self._slot_transacted_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'transacted_volume'")
            return self._slot_transacted_volume

        def __set__(self, value):
            self._slot_transacted_volume = value

        def __del__(self):
            if self._slot_transacted_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'transacted_volume'")
            self._slot_transacted_volume = self._missing

    property type:
        def __get__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            return self._slot_type

        def __set__(self, value):
            self._slot_type = value

        def __del__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            self._slot_type = self._missing

    def request_data_subscription(self, subscription_message):
        self._require_bound()
        return self._request_data_subscription(subscription_message)

    def cancel_data_subscription(self, subscription_message):
        self._require_bound()
        return self._cancel_data_subscription(subscription_message)

    def get_last_trade(self, symbol):
        self._require_bound()
        return self._get_last_trade(symbol)

    def get_current_spread(self, symbol, depth=1):
        self._require_bound()
        return self._get_current_spread(symbol, depth)

    def get_order_stream(self, symbol, length=1):
        self._require_bound()
        return self._get_order_stream(symbol, length)

    def get_transacted_volume(self, symbol, lookback_period='10min'):
        self._require_bound()
        return self._get_transacted_volume(symbol, lookback_period)

    def create_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None):
        self._require_bound()
        return self._create_limit_order(symbol, quantity, side, limit_price, order_id, is_hidden, is_price_to_comply, insert_by_id, is_post_only, ignore_risk, tag)

    def place_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None):
        self._require_bound()
        return self._place_limit_order(symbol, quantity, side, limit_price, order_id, is_hidden, is_price_to_comply, insert_by_id, is_post_only, ignore_risk, tag)

    def place_market_order(self, symbol, quantity, side, order_id=None, ignore_risk=True, tag=None):
        self._require_bound()
        return self._place_market_order(symbol, quantity, side, order_id, ignore_risk, tag)

    def place_multiple_orders(self, orders):
        self._require_bound()
        return self._place_multiple_orders(orders)

    def cancel_order(self, order, tag=DEFAULT_CANCEL_TAG, metadata=DEFAULT_CANCEL_METADATA):
        self._require_bound()
        return self._cancel_order(order, tag, metadata)

    def cancel_all_orders(self):
        self._require_bound()
        return self._cancel_all_orders()

    def partial_cancel_order(self, order, quantity, tag=DEFAULT_PARTIAL_CANCEL_TAG, metadata=DEFAULT_PARTIAL_CANCEL_METADATA):
        self._require_bound()
        return self._partial_cancel_order(order, quantity, tag, metadata)

    def modify_order(self, order, new_order):
        self._require_bound()
        return self._modify_order(order, new_order)

    def replace_order(self, order, new_order):
        self._require_bound()
        return self._replace_order(order, new_order)

    def order_executed(self, order):
        self._require_bound()
        return self._order_executed(order)

    def order_accepted(self, order):
        self._require_bound()
        return self._order_accepted(order)

    def order_cancelled(self, order):
        self._require_bound()
        return self._order_cancelled(order)

    def order_partial_cancelled(self, order):
        self._require_bound()
        return self._order_partial_cancelled(order)

    def order_modified(self, order):
        self._require_bound()
        return self._order_modified(order)

    def order_replaced(self, old_order, new_order):
        self._require_bound()
        return self._order_replaced(old_order, new_order)

    def market_closed(self):
        self._require_bound()
        return self._market_closed()

    def query_last_trade(self, symbol, price):
        self._require_bound()
        return self._query_last_trade(symbol, price)

    def query_spread(self, symbol, price, bids, asks, book):
        self._require_bound()
        return self._query_spread(symbol, price, bids, asks, book)

    def handle_market_data(self, message):
        self._require_bound()
        return self._handle_market_data(message)

    def query_order_stream(self, symbol, orders):
        self._require_bound()
        return self._query_order_stream(symbol, orders)

    def query_transacted_volume(self, symbol, bid_volume, ask_volume):
        self._require_bound()
        return self._query_transacted_volume(symbol, bid_volume, ask_volume)

    def get_known_bid_ask(self, symbol, best=True):
        self._require_bound()
        return self._get_known_bid_ask(symbol, best)

    def get_known_liquidity(self, symbol, within=0.0):
        self._require_bound()
        return self._get_known_liquidity(symbol, within)

    def get_book_liquidity(self, book, within):
        self._require_bound()
        return self._get_book_liquidity(book, within)

    def mark_to_market(self, holdings, use_midpoint=False):
        self._require_bound()
        return self._mark_to_market(holdings, use_midpoint)

    def get_holdings(self, symbol):
        self._require_bound()
        return self._get_holdings(symbol)

    def get_known_bid_ask_midpoint(self, symbol):
        self._require_bound()
        return self._get_known_bid_ask_midpoint(symbol)

    def get_average_transaction_price(self):
        self._require_bound()
        return self._get_average_transaction_price()

    def fmt_holdings(self, holdings):
        self._require_bound()
        return self._fmt_holdings(holdings)

    def logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        self._require_bound()
        return self._logEvent(event_type, event, append_summary_log, deepcopy_event)

    def send_message(self, recipient_id, message, delay=0):
        self._require_bound()
        return self._send_message(recipient_id, message, delay)

    def send_message_batch(self, recipient_id, messages, delay=0):
        self._require_bound()
        return self._send_message_batch(recipient_id, messages, delay)

    def set_wakeup(self, requested_time):
        self._require_bound()
        return self._set_wakeup(requested_time)

    def get_computation_delay(self):
        self._require_bound()
        return self._get_computation_delay()

    def set_computation_delay(self, requested_delay):
        self._require_bound()
        return self._set_computation_delay(requested_delay)

    def delay(self, additional_delay):
        self._require_bound()
        return self._delay(additional_delay)

    def write_log(self, df_log, filename=None):
        self._require_bound()
        return self._write_log(df_log, filename)

    def update_agent_state(self, state):
        self._require_bound()
        return self._update_agent_state(state)

    def dollarize(self, cents):
        self._require_bound()
        return self._dollarize(cents)

    def get_wake_frequency(self):
        self._require_bound()
        return self._get_wake_frequency()

    cdef object _base_wakeup(self, current_time):
        '\n        Agents can request a wakeup call at a future simulation time using\n        ``Agent.set_wakeup()``.\n\n        This is the method called when the wakeup time arrives.\n\n        Arguments:\n            current_time: The simulation time at which the kernel is delivering this\n                message -- the agent should treat this as "now".\n        '
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received wakeup.'.format(fmt_ts(current_time), self._slot_id, self._slot_name))

    cdef object _base_receive_message(self, current_time, sender_id, message):
        '\n        Called each time a message destined for this agent reaches the front of the\n        kernel\'s priority queue.\n\n        Arguments:\n            current_time: The simulation time at which the kernel is delivering this\n                message -- the agent should treat this as "now".\n            sender_id: The ID of the agent who sent the message.\n            message: An object guaranteed to inherit from the message.Message class.\n        '
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received: {}'.format(fmt_ts(current_time), self._slot_id, self._slot_name, message))

    cdef object _base_kernel_stopping(self):
        '\n        Called by the kernel one time before simulationTerminating.\n\n        All other agents are guaranteed to exist at this time.\n        '
        pass

    cdef object _kernel_terminating(self):
        '\n        Called by the kernel one time when simulation terminates.\n\n        No other agents are guaranteed to exist at this time.\n        '
        if _observer.skip_termination(self):
            return
        if self._slot_log and self._slot_log_to_file:
            df_log = pd.DataFrame(self._slot_log, columns=('EventTime', 'EventType', 'Event'))
            df_log.set_index('EventTime', inplace=True)
            self._write_log(df_log, None)

    cdef object _logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        "\n        Adds an event to this agent's log.\n\n        The deepcopy of the Event field, often an object, ensures later state\n        changes to the object will not retroactively update the logged event.\n\n        Arguments:\n            event_type: label of the event (e.g., Order submitted, order accepted last trade etc....)\n            event: actual event to be logged\n            append_summary_log:\n            deepcopy_event: Set to False to skip deepcopying the event object.\n        "
        if _observer.record_log(self, event_type, event, append_summary_log, deepcopy_event):
            return
        if not self._slot_log_events:
            return
        if deepcopy_event:
            if type(event) is dict and _primitive_event(event):
                event = event.copy()
            else:
                event = deepcopy(event)
        self._slot_log.append((self._slot_current_time, event_type, event))
        if append_summary_log:
            assert self._slot_kernel is not None
            self._slot_kernel.append_summary_log(self._slot_id, event_type, event)

    cdef object _send_message(self, recipient_id, message, delay=0):
        '\n        Sends a message to another Agent.\n\n        Arguments:\n            recipient_id: ID of the agent receiving the message.\n            message: The ``Message`` class instance to send.\n            delay: Represents an agent\'s request for ADDITIONAL delay (beyond the\n                Kernel\'s mandatory computation + latency delays). Represents parallel\n                pipeline processing delays (that should delay the transmission of\n                messages but do not make the agent "busy" and unable to respond to new\n                messages)\n        '
        assert self._slot_kernel is not None
        self._scheduler._send(self._slot_id, recipient_id, message, delay)

    cdef object _send_message_batch(self, recipient_id, messages, delay=0):
        '\n        Sends a batch of messages to another Agent.\n\n        Arguments:\n            recipient_id: ID of the agent receiving the messages.\n            messages: A list of ``Message`` class instances to send.\n            delay: Represents an agent\'s request for ADDITIONAL delay (beyond the\n            Kernel\'s mandatory computation + latency delays). Represents parallel\n            pipeline processing delays (that should delay the transmission of messages\n            but do not make the agent "busy" and unable to respond to new messages)\n        '
        assert self._slot_kernel is not None
        self._scheduler._send(self._slot_id, recipient_id, MessageBatch(messages), delay)

    cdef object _set_wakeup(self, requested_time):
        '\n        Called to receive a "wakeup call" from the kernel at some requested future time.\n\n        Arguments:\n            requested_time: Defaults to the next possible timestamp. Wakeup time cannot\n                be the current time or a past time.\n        '
        assert self._slot_kernel is not None
        self._scheduler._set_wakeup(self._slot_id, requested_time)

    cdef object _get_computation_delay(self):
        "Queries thr agent's current computation delay from the kernel."
        return self._slot_kernel.get_agent_compute_delay(sender_id=self._slot_id)

    cdef object _set_computation_delay(self, requested_delay):
        '\n        Calls the kernel to update the agent\'s computation delay.\n\n        This does not initiate a global delay, nor an immediate delay for the agent.\n        Rather it sets the new default delay for the calling agent. The delay will be\n        applied upon every return from wakeup or recvMsg.\n\n        Note that this delay IS applied to any messages sent by the agent during the\n        current wake cycle (simulating the messages popping out at the end of its\n        "thinking" time).\n\n        Also note that we DO permit a computation delay of zero, but this should really\n        only be used for special or massively parallel agents.\n\n        Arguments:\n            requested_delay: delay given in nanoseconds.\n        '
        assert self._slot_kernel is not None
        self._slot_kernel.set_agent_compute_delay(sender_id=self._slot_id, requested_delay=requested_delay)

    cdef object _delay(self, additional_delay):
        "\n        Accumulates a temporary delay for the current wake cycle for this agent.\n\n        This will apply the total delay (at time of send_message) to each message, and\n        will modify the agent's next available time slot.  These happen on top of the\n        agent's compute delay BUT DO NOT ALTER IT.  (i.e. effects are transient). Mostly\n        useful for staggering outbound messages.\n\n        Arguments:\n            additional_delay: additional delay given in nanoseconds.\n        "
        assert self._slot_kernel is not None
        self._slot_kernel.delay_agent(sender_id=self._slot_id, additional_delay=additional_delay)

    cdef object _write_log(self, df_log, filename=None):
        '\n        Called by the agent, usually at the very end of the simulation just before\n        kernel shutdown, to write to disk any log dataframe it has been accumulating\n        during simulation.\n\n        The format can be decided by the agent, although changes will require a special\n        tool to read and parse the logs.  The Kernel places the log in a unique\n        directory per run, with one filename per agent, also decided by the Kernel using\n        agent type, id, etc.\n\n        If filename is None the Kernel will construct a filename based on the name of\n        the Agent requesting log archival.\n\n        Arguments:\n            df_log: dataframe that contains all the logged events during the simulation\n            filename: Location on disk to write the log to.\n        '
        assert self._slot_kernel is not None
        self._slot_kernel.write_log(self._slot_id, df_log, filename)

    cdef object _update_agent_state(self, state):
        '\n        Agents should use this method to replace their custom state in the dictionary\n        the Kernel will return to the experimental config file at the end of the\n        simulation.\n\n        This is intended to be write-only, and agents should not use it to store\n        information for their own later use.\n\n        Arguments:\n            state: The new state.\n        '
        assert self._slot_kernel is not None
        self._slot_kernel.update_agent_state(self._slot_id, state)

    cdef object _dollarize(self, cents):
        '\n        Used by any subclass to dollarize an int-cents price for printing.\n        '
        return dollarize(cents)

    cdef object _trading_wakeup(self, current_time):
        '\n        Arguments:\n            current_time: The time that this agent was woken up by the kernel.\n\n        Returns:\n            For the sake of subclasses, TradingAgent now returns a boolean\n            indicating whether the agent is "ready to trade" -- has it received\n            the market open and closed times, and is the market not already closed.\n        '
        self._base_wakeup(current_time)
        if self._slot_first_wake:
            self._logEvent('HOLDINGS_UPDATED', self._slot_holdings, False, True)
            self._slot_first_wake = False
            self._send_message(self._slot_exchange_id, MarketClosePriceRequestMsg(), 0)
        if self._slot_mkt_open is None:
            self._send_message(self._slot_exchange_id, MarketHoursRequestMsg(), 0)
        return (self._slot_mkt_open and self._slot_mkt_close) and (not self._slot_mkt_closed)

    cdef object _trading_receive_message(self, current_time, sender_id, message):
        '\n        Arguments:\n            current_time: The time that this agent received the message.\n            sender_id: The ID of the agent who sent the message.\n            message: The message contents.\n        '
        assert self._slot_kernel is not None
        self._base_receive_message(current_time, sender_id, message)
        had_mkt_hours = self._slot_mkt_open is not None and self._slot_mkt_close is not None
        if isinstance(message, MarketHoursMsg):
            self._slot_mkt_open = message.mkt_open
            self._slot_mkt_close = message.mkt_close
            if trading_logger.isEnabledFor(10):
                trading_logger.debug('Recorded market open: {}'.format(fmt_ts(self._slot_mkt_open)))
            if trading_logger.isEnabledFor(10):
                trading_logger.debug('Recorded market close: {}'.format(fmt_ts(self._slot_mkt_close)))
        elif isinstance(message, MarketClosePriceMsg):
            for (symbol, close_price) in message.close_prices.items():
                self._slot_last_trade[symbol] = close_price
        elif isinstance(message, MarketClosedMsg):
            self._market_closed()
        elif isinstance(message, OrderExecutedMsg):
            self._order_executed(message.order)
        elif isinstance(message, OrderAcceptedMsg):
            self._order_accepted(message.order)
        elif isinstance(message, OrderCancelledMsg):
            self._order_cancelled(message.order)
        elif isinstance(message, OrderPartialCancelledMsg):
            self._order_partial_cancelled(message.new_order)
        elif isinstance(message, OrderModifiedMsg):
            self._order_modified(message.new_order)
        elif isinstance(message, OrderReplacedMsg):
            self._order_replaced(message.old_order, message.new_order)
        elif isinstance(message, QueryLastTradeResponseMsg):
            if message.mkt_closed:
                self._slot_mkt_closed = True
            self._query_last_trade(message.symbol, message.last_trade)
        elif isinstance(message, QuerySpreadResponseMsg):
            if message.mkt_closed:
                self._slot_mkt_closed = True
            self._query_spread(message.symbol, message.last_trade, message.bids, message.asks, '')
        elif isinstance(message, QueryOrderStreamResponseMsg):
            if message.mkt_closed:
                self._slot_mkt_closed = True
            self._query_order_stream(message.symbol, message.orders)
        elif isinstance(message, QueryTransactedVolResponseMsg):
            if message.mkt_closed:
                self._slot_mkt_closed = True
            self._query_transacted_volume(message.symbol, message.bid_volume, message.ask_volume)
        elif isinstance(message, MarketDataMsg):
            self._handle_market_data(message)
        have_mkt_hours = self._slot_mkt_open is not None and self._slot_mkt_close is not None
        if have_mkt_hours and (not had_mkt_hours):
            ns_offset = self._get_wake_frequency()
            self._set_wakeup(self._slot_mkt_open + ns_offset)

    cdef object _kernel_stopping(self):
        self._base_kernel_stopping()
        assert self._slot_kernel is not None
        self._logEvent('FINAL_HOLDINGS', self._fmt_holdings(self._slot_holdings), False, False)
        self._logEvent('FINAL_CASH_POSITION', self._slot_holdings['CASH'], True, True)
        cash = self._mark_to_market(self._slot_holdings, False)
        self._logEvent('ENDING_CASH', cash, True, True)
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Final holdings for {}: {}. Marked to market: {}'.format(self._slot_name, self._fmt_holdings(self._slot_holdings), cash))
        mytype = self._slot_type
        gain = cash - self._slot_starting_cash
        if mytype in self._slot_kernel.mean_result_by_agent_type:
            self._slot_kernel.mean_result_by_agent_type[mytype] += gain
            self._slot_kernel.agent_count_by_type[mytype] += 1
        else:
            self._slot_kernel.mean_result_by_agent_type[mytype] = gain
            self._slot_kernel.agent_count_by_type[mytype] = 1

    cdef object _wakeup(self, current_time):
        self._trading_wakeup(current_time)
        if not self._slot_mkt_open or not self._slot_mkt_close or self._slot_mkt_closed:
            return
        self._set_wakeup(current_time + self._slot_interval_ns)
        self._get_current_spread(self._slot_symbol, 1)
        self._slot_state = 'AWAITING_SPREAD'

    cdef object _receive_message(self, current_time, sender_id, message):
        self._trading_receive_message(current_time, sender_id, message)
        if self._slot_state == 'AWAITING_SPREAD' and isinstance(message, QuerySpreadResponseMsg):
            if not self._slot_mkt_closed:
                self._act()
            self._slot_state = 'AWAITING_WAKEUP'

    cdef object _request_data_subscription(self, subscription_message):
        '\n        Used by any Trading Agent subclass to create a subscription to market data from\n        the Exchange Agent.\n\n        Arguments:\n            subscription_message: An instance of a MarketDataSubReqMessage.\n        '
        subscription_message.cancel = False
        self._send_message(self._slot_exchange_id, subscription_message, 0)

    cdef object _cancel_data_subscription(self, subscription_message):
        '\n        Used by any Trading Agent subclass to cancel subscription to market data from\n        the Exchange Agent.\n\n        Arguments:\n            subscription_message: An instance of a MarketDataSubReqMessage.\n        '
        subscription_message.cancel = True
        self._send_message(self._slot_exchange_id, subscription_message, 0)

    cdef object _get_last_trade(self, symbol):
        '\n        Used by any Trading Agent subclass to query the last trade price for a symbol.\n\n        This activity is not logged.\n\n        Arguments:\n            symbol: The symbol to query.\n        '
        self._send_message(self._slot_exchange_id, QueryLastTradeMsg(symbol), 0)

    cdef object _get_current_spread(self, symbol, depth=1):
        '\n        Used by any Trading Agent subclass to query the current spread for a symbol.\n\n        This activity is not logged.\n\n        Arguments:\n            symbol: The symbol to query.\n            depth:\n        '
        self._send_message(self._slot_exchange_id, QuerySpreadMsg(symbol, depth), 0)

    cdef object _get_order_stream(self, symbol, length=1):
        '\n        Used by any Trading Agent subclass to query the recent order s  tream for a symbol.\n\n        Arguments:\n            symbol: The symbol to query.\n            length:\n        '
        self._send_message(self._slot_exchange_id, QueryOrderStreamMsg(symbol, length), 0)

    cdef object _get_transacted_volume(self, symbol, lookback_period='10min'):
        '\n        Used by any trading agent subclass to query the total transacted volume in a\n        given lookback period.\n\n        Arguments:\n            symbol: The symbol to query.\n            lookback_period: The length of time to consider when calculating the volume.\n        '
        self._send_message(self._slot_exchange_id, QueryTransactedVolMsg(symbol, lookback_period), 0)

    cdef object _create_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None):
        '\n        Used by any Trading Agent subclass to create a limit order.\n\n        Arguments:\n            symbol: A valid symbol.\n            quantity: Positive share quantity.\n            side: Side.BID or Side.ASK.\n            limit_price: Price in cents.\n            order_id: An optional order id (otherwise global autoincrement is used).\n            is_hidden:\n            is_price_to_comply:\n            insert_by_id:\n            is_post_only:\n            ignore_risk: Whether cash or risk limits should be enforced or ignored for\n                the order.\n            tag:\n        '
        order = LimitOrder(agent_id=self._slot_id, time_placed=self._slot_current_time, symbol=symbol, quantity=quantity, side=side, limit_price=limit_price, is_hidden=is_hidden, is_price_to_comply=is_price_to_comply, insert_by_id=insert_by_id, is_post_only=is_post_only, order_id=order_id, tag=tag)
        if quantity > 0:
            new_holdings = self._slot_holdings.copy()
            q = order.quantity if order.side.is_bid() else -order.quantity
            if order.symbol in new_holdings:
                new_holdings[order.symbol] += q
            else:
                new_holdings[order.symbol] = q
            if not ignore_risk:
                at_risk = self._mark_to_market(self._slot_holdings, False) - self._slot_holdings['CASH']
                new_at_risk = self._mark_to_market(new_holdings, False) - new_holdings['CASH']
                if new_at_risk > at_risk and new_at_risk > self._slot_starting_cash:
                    if trading_logger.isEnabledFor(10):
                        trading_logger.debug('TradingAgent ignored limit order due to at-risk constraints: {}\n{}'.format(order, self._fmt_holdings(self._slot_holdings)))
                    return
            return order
        else:
            warnings.warn(f'TradingAgent ignored limit order of quantity zero: {order}')

    cdef object _place_limit_order(self, symbol, quantity, side, limit_price, order_id=None, is_hidden=False, is_price_to_comply=False, insert_by_id=False, is_post_only=False, ignore_risk=True, tag=None):
        '\n        Used by any Trading Agent subclass to place a limit order.\n\n        Arguments:\n            symbol: A valid symbol.\n            quantity: Positive share quantity.\n            side: Side.BID or Side.ASK.\n            limit_price: Price in cents.\n            order_id: An optional order id (otherwise global autoincrement is used).\n            is_hidden:\n            is_price_to_comply:\n            insert_by_id:\n            is_post_only:\n            ignore_risk: Whether cash or risk limits should be enforced or ignored for\n                the order.\n            tag:\n        '
        order = self._create_limit_order(symbol, quantity, side, limit_price, order_id, is_hidden, is_price_to_comply, insert_by_id, is_post_only, ignore_risk, tag)
        if order is not None:
            self._slot_orders[order.order_id] = deepcopy(order)
            self._send_message(self._slot_exchange_id, LimitOrderMsg(order), 0)
            if self._slot_log_orders:
                _observer.order(self, 'ORDER_SUBMITTED', order, deepcopy_event=False)

    cdef object _place_market_order(self, symbol, quantity, side, order_id=None, ignore_risk=True, tag=None):
        '\n        Used by any Trading Agent subclass to place a market order.\n\n        The market order is created as multiple limit orders crossing the spread\n        walking the book until all the quantities are matched.\n\n        Arguments:\n            symbol: Name of the stock traded.\n            quantity: Order quantity.\n            side: Side.BID or Side.ASK.\n            order_id: Order ID for market replay.\n            ignore_risk: Whether cash or risk limits should be enforced or ignored for\n                the order.\n            tag:\n        '
        order = MarketOrder(self._slot_id, self._slot_current_time, symbol, quantity, side, order_id, tag)
        if quantity > 0:
            new_holdings = self._slot_holdings.copy()
            q = order.quantity if order.side.is_bid() else -order.quantity
            if order.symbol in new_holdings:
                new_holdings[order.symbol] += q
            else:
                new_holdings[order.symbol] = q
            if not ignore_risk:
                at_risk = self._mark_to_market(self._slot_holdings, False) - self._slot_holdings['CASH']
                new_at_risk = self._mark_to_market(new_holdings, False) - new_holdings['CASH']
                if new_at_risk > at_risk and new_at_risk > self._slot_starting_cash:
                    if trading_logger.isEnabledFor(10):
                        trading_logger.debug('TradingAgent ignored market order due to at-risk constraints: {}\n{}'.format(order, self._fmt_holdings(self._slot_holdings)))
                    return
            self._slot_orders[order.order_id] = deepcopy(order)
            self._send_message(self._slot_exchange_id, MarketOrderMsg(order), 0)
            if self._slot_log_orders:
                _observer.order(self, 'ORDER_SUBMITTED', order, deepcopy_event=False)
        else:
            warnings.warn('TradingAgent ignored market order of quantity zero: {}', order)

    cdef object _place_multiple_orders(self, orders):
        '\n        Used by any Trading Agent subclass to place multiple orders at the same time.\n\n        Arguments:\n            orders: A list of Orders to place with the exchange as a single batch.\n        '
        messages = []
        for order in orders:
            if isinstance(order, LimitOrder):
                messages.append(LimitOrderMsg(order))
            elif isinstance(order, MarketOrder):
                messages.append(MarketOrderMsg(order))
            else:
                raise Exception('Expected LimitOrder or MarketOrder')
            self._slot_orders[order.order_id] = deepcopy(order)
            if self._slot_log_orders:
                _observer.order(self, 'ORDER_SUBMITTED', order, deepcopy_event=False)
        if len(messages) > 0:
            self._send_message_batch(self._slot_exchange_id, messages, 0)

    cdef object _cancel_order(self, order, tag=DEFAULT_CANCEL_TAG, metadata=DEFAULT_CANCEL_METADATA):
        "\n        Used by derived classes of TradingAgent to cancel a limit order.\n\n        The order must currently appear in the agent's open orders list.\n\n        Arguments:\n            order: The limit order to cancel.\n            tag:\n            metadata:\n        "
        if isinstance(order, LimitOrder):
            self._send_message(self._slot_exchange_id, CancelOrderMsg(order, tag, metadata), 0)
            if self._slot_log_orders:
                _observer.order(self, 'CANCEL_SUBMITTED', order, deepcopy_event=False)
        else:
            warnings.warn(f'Order {order} of type, {type(order)} cannot be cancelled')

    cdef object _cancel_all_orders(self):
        '\n        Cancels all current limit orders held by this agent.\n        '
        for order in self._slot_orders.values():
            if isinstance(order, LimitOrder):
                self._cancel_order(order, DEFAULT_CANCEL_TAG, DEFAULT_CANCEL_METADATA)

    cdef object _partial_cancel_order(self, order, quantity, tag=DEFAULT_PARTIAL_CANCEL_TAG, metadata=DEFAULT_PARTIAL_CANCEL_METADATA):
        "\n        Used by any Trading Agent subclass to modify any existing limit order.\n\n        The order must currently appear in the agent's open orders list.\n        Arguments:\n            order: The limit order to partially cancel.\n            quantity:\n            tag:\n            metadata:\n        "
        self._send_message(self._slot_exchange_id, PartialCancelOrderMsg(order, quantity, tag, metadata), 0)
        if self._slot_log_orders:
            _observer.order(self, 'CANCEL_PARTIAL_ORDER', order, deepcopy_event=False)

    cdef object _modify_order(self, order, new_order):
        "\n        Used by any Trading Agent subclass to modify any existing limit order.\n\n        The order must currently appear in the agent's open orders list.  Some\n        additional tests might be useful here to ensure the old and new orders are\n        the same in some way.\n\n        Arguments:\n            order: The existing limit order.\n            new_order: The limit order to update the existing order with.\n        "
        self._send_message(self._slot_exchange_id, ModifyOrderMsg(order, new_order), 0)
        if self._slot_log_orders:
            _observer.order(self, 'MODIFY_ORDER', order, deepcopy_event=False)

    cdef object _replace_order(self, order, new_order):
        "\n        Used by any Trading Agent subclass to replace any existing limit order.\n\n        The order must currently appear in the agent's open orders list.  Some\n        additional tests might be useful here to ensure the old and new orders are\n        the same in some way.\n\n        Arguments:\n            order: The existing limit order.\n            new_order: The new limit order to replace the existing order with.\n        "
        self._send_message(self._slot_exchange_id, ReplaceOrderMsg(self._slot_id, order, new_order), 0)
        if self._slot_log_orders:
            _observer.order(self, 'REPLACE_ORDER', order, deepcopy_event=False)

    cdef object _order_executed(self, order):
        '\n        Handles OrderExecuted messages from an exchange agent.\n\n        Subclasses may wish to extend, but should still call parent method for basic\n        portfolio/returns tracking.\n\n        Arguments:\n            order: The order that has been executed by the exchange.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of execution for: {order}')
        if self._slot_log_orders:
            _observer.order(self, 'ORDER_EXECUTED', order, deepcopy_event=False)
        qty = order.quantity if order.side.is_bid() else -1 * order.quantity
        sym = order.symbol
        if sym in self._slot_holdings:
            self._slot_holdings[sym] += qty
        else:
            self._slot_holdings[sym] = qty
        if self._slot_holdings[sym] == 0:
            del self._slot_holdings[sym]
        self._slot_holdings['CASH'] -= qty * order.fill_price
        if order.order_id in self._slot_orders:
            o = self._slot_orders[order.order_id]
            if order.quantity >= o.quantity:
                del self._slot_orders[order.order_id]
            else:
                o.quantity -= order.quantity
        else:
            warnings.warn(f'Execution received for order not in orders list: {order}')
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'After order execution, agent open orders: {self._slot_orders}')
        self._logEvent('HOLDINGS_UPDATED', self._slot_holdings, False, True)

    cdef object _order_accepted(self, order):
        '\n        Handles OrderAccepted messages from an exchange agent.\n\n        Subclasses may wish to extend.\n\n        Arguments:\n            order: The order that has been accepted from the exchange.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of acceptance for: {order}')
        if self._slot_log_orders:
            _observer.order(self, 'ORDER_ACCEPTED', order, deepcopy_event=False)

    cdef object _order_cancelled(self, order):
        '\n        Handles OrderCancelled messages from an exchange agent.\n\n        Subclasses may wish to extend.\n\n        Arguments:\n            order: The order that has been cancelled by the exchange.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of cancellation for: {order}')
        if self._slot_log_orders:
            _observer.order(self, 'ORDER_CANCELLED', order, deepcopy_event=False)
        if order.order_id in self._slot_orders:
            del self._slot_orders[order.order_id]
        else:
            warnings.warn(f'Cancellation received for order not in orders list: {order}')

    cdef object _order_partial_cancelled(self, order):
        '\n        Handles OrderCancelled messages from an exchange agent.\n\n        Subclasses may wish to extend.\n\n        Arguments:\n            order: The order that has been partially cancelled by the exchange.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of partial cancellation for: {order}')
        if self._slot_log_orders:
            _observer.order(self, 'PARTIAL_CANCELLED', order)
        if order.order_id in self._slot_orders:
            self._slot_orders[order.order_id] = order
        else:
            warnings.warn(f'partial cancellation received for order not in orders list: {order}')
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'After order partial cancellation, agent open orders: {self._slot_orders}')
        self._logEvent('HOLDINGS_UPDATED', self._slot_holdings, False, True)

    cdef object _order_modified(self, order):
        '\n        Handles OrderModified messages from an exchange agent.\n\n        Subclasses may wish to extend.\n\n        Arguments:\n            order: The order that has been modified at the exchange.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of modification for: {order}')
        if self._slot_log_orders:
            _observer.order(self, 'ORDER_MODIFIED', order)
        if order.order_id in self._slot_orders:
            self._slot_orders[order.order_id] = order
        else:
            warnings.warn('Execution received for order not in orders list: {order}')
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'After order modification, agent open orders: {self._slot_orders}')
        self._logEvent('HOLDINGS_UPDATED', self._slot_holdings, False, True)

    cdef object _order_replaced(self, old_order, new_order):
        '\n        Handles OrderReplaced messages from an exchange agent.\n\n        Subclasses may wish to extend.\n\n        Arguments:\n            order: The order that has been modified at the exchange.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'Received notification of replacement for: {old_order}')
        if self._slot_log_orders:
            _observer.order(self, 'ORDER_REPLACED', old_order)
        if old_order.order_id in self._slot_orders:
            del self._slot_orders[old_order.order_id]
        else:
            warnings.warn(f'Execution received for order not in orders list: {old_order}')
        self._slot_orders[new_order.order_id] = new_order
        if trading_logger.isEnabledFor(10):
            trading_logger.debug(f'After order replacement, agent open orders: {self._slot_orders}')
        self._logEvent('HOLDINGS_UPDATED', self._slot_holdings, False, True)

    cdef object _market_closed(self):
        '\n        Handles MarketClosedMsg messages from an exchange agent.\n\n        Subclasses may wish to extend.\n        '
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Received notification of market closure.')
        self._logEvent('MKT_CLOSED', '', False, True)
        self._slot_mkt_closed = True

    cdef object _query_last_trade(self, symbol, price):
        '\n        Handles QueryLastTradeResponseMsg messages from an exchange agent.\n\n        Arguments:\n            symbol: The symbol that was queried.\n            price: The price at which the last trade executed at.\n        '
        self._slot_last_trade[symbol] = price
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Received last trade price of {} for {}.'.format(self._slot_last_trade[symbol], symbol))
        if self._slot_mkt_closed:
            self._slot_daily_close_price[symbol] = self._slot_last_trade[symbol]
            if trading_logger.isEnabledFor(10):
                trading_logger.debug('Received daily close price of {} for {}.'.format(self._slot_last_trade[symbol], symbol))

    cdef object _query_spread(self, symbol, price, bids, asks, book):
        '\n        Handles QuerySpreadResponseMsg messages from an exchange agent.\n\n        Arguments:\n            symbol: The symbol that was queried.\n            price:\n            bids:\n            asks:\n            book:\n        '
        self._query_last_trade(symbol, price)
        self._slot_known_bids[symbol] = bids
        self._slot_known_asks[symbol] = asks
        if bids:
            (best_bid, best_bid_qty) = (bids[0][0], bids[0][1])
        else:
            (best_bid, best_bid_qty) = ('No bids', 0)
        if asks:
            (best_ask, best_ask_qty) = (asks[0][0], asks[0][1])
        else:
            (best_ask, best_ask_qty) = ('No asks', 0)
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Received spread of {} @ {} / {} @ {} for {}'.format(best_bid_qty, best_bid, best_ask_qty, best_ask, symbol))
        _observer.diagnostic(self, 'BID_DEPTH', bids)
        _observer.diagnostic(self, 'ASK_DEPTH', asks)
        _observer.imbalance(self, bids, asks)
        self._slot_book = book

    cdef object _handle_market_data(self, message):
        '\n        Handles Market Data messages for agents using subscription mechanism.\n\n        Arguments:\n            message: The market data message,\n        '
        if isinstance(message, L2DataMsg):
            symbol = message.symbol
            self._slot_known_asks[symbol] = message.asks
            self._slot_known_bids[symbol] = message.bids
            self._slot_last_trade[symbol] = message.last_transaction
            self._slot_exchange_ts[symbol] = message.exchange_ts

    cdef object _query_order_stream(self, symbol, orders):
        '\n        Handles QueryOrderStreamResponseMsg messages from an exchange agent.\n\n        It is up to the requesting agent to do something with the data, which is a list\n        of dictionaries keyed by order id. The list index is 0 for orders since the most\n        recent trade, 1 for orders that led up to the most recent trade, and so on.\n        Agents are not given index 0 (orders more recent than the last trade).\n\n        Arguments:\n            symbol: The symbol that was queried.\n            orders:\n        '
        self._slot_stream_history[symbol] = orders

    cdef object _query_transacted_volume(self, symbol, bid_volume, ask_volume):
        '\n        Handles the QueryTransactedVolResponseMsg messages from the exchange agent.\n\n        Arguments:\n            symbol: The symbol that was queried.\n            bid_vol: The volume that has transacted on the bid side for the queried period.\n            ask_vol: The volume that has transacted on the ask side for the queried period.\n        '
        self._slot_transacted_volume[symbol] = (bid_volume, ask_volume)

    cdef object _get_known_bid_ask(self, symbol, best=True):
        '\n        Extract the current known bid and asks.\n\n        This does NOT request new information.\n\n        Arguments:\n            symbol: The symbol to query.\n            best:\n        '
        if best:
            bid = self._slot_known_bids[symbol][0][0] if self._slot_known_bids[symbol] else None
            ask = self._slot_known_asks[symbol][0][0] if self._slot_known_asks[symbol] else None
            bid_vol = self._slot_known_bids[symbol][0][1] if self._slot_known_bids[symbol] else 0
            ask_vol = self._slot_known_asks[symbol][0][1] if self._slot_known_asks[symbol] else 0
            return (bid, bid_vol, ask, ask_vol)
        else:
            bids = self._slot_known_bids[symbol] if self._slot_known_bids[symbol] else None
            asks = self._slot_known_asks[symbol] if self._slot_known_asks[symbol] else None
            return (bids, asks)

    cdef object _get_known_liquidity(self, symbol, within=0.0):
        '\n        Extract the current bid and ask liquidity within a certain proportion of the\n        inside bid and ask.  (i.e. within=0.01 means to report total BID shares\n        within 1% of the best bid price, and total ASK shares within 1% of the best\n        ask price)\n\n        Arguments:\n            symbol: The symbol to query.\n            within:\n\n        Returns:\n            (bid_liquidity, ask_liquidity).  Note that this is from the order book\n            perspective, not the agent perspective.  (The agent would be selling into\n            the bid liquidity, etc.)\n        '
        bid_liq = self._get_book_liquidity(self._slot_known_bids[symbol], within)
        ask_liq = self._get_book_liquidity(self._slot_known_asks[symbol], within)
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Bid/ask liq: {}, {}'.format(bid_liq, ask_liq))
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Known bids: {}'.format(self._slot_known_bids[self._slot_symbol]))
        if trading_logger.isEnabledFor(10):
            trading_logger.debug('Known asks: {}'.format(self._slot_known_asks[self._slot_symbol]))
        return (bid_liq, ask_liq)

    cdef object _get_book_liquidity(self, book, within):
        '\n        Helper function for the above.  Checks one side of the known order book.\n\n        Arguments:\n            book:\n            within:\n        '
        liq = 0
        for (i, (price, shares)) in enumerate(book):
            if i == 0:
                best = price
            if abs(best - price) <= int(round(best * within)):
                if trading_logger.isEnabledFor(10):
                    trading_logger.debug('Within {} of {}: {} with {} shares'.format(within, best, price, shares))
                liq += shares
        return liq

    cdef object _mark_to_market(self, holdings, use_midpoint=False):
        '\n        Marks holdings to market (including cash).\n\n        Arguments:\n            holdings:\n            use_midpoint:\n        '
        cash = holdings['CASH']
        cash += self._slot_basket_size * self._slot_nav_diff
        for (symbol, shares) in holdings.items():
            if symbol == 'CASH':
                continue
            if use_midpoint:
                (bid, ask, midpoint) = self._get_known_bid_ask_midpoint(symbol)
                if bid is None or ask is None or midpoint is None:
                    value = self._slot_last_trade[symbol] * shares
                else:
                    value = midpoint * shares
            else:
                value = self._slot_last_trade[symbol] * shares
            cash += value
            self._logEvent('MARK_TO_MARKET', '{} {} @ {} == {}'.format(shares, symbol, self._slot_last_trade[symbol], value), False, True)
        self._logEvent('MARKED_TO_MARKET', cash, False, True)
        return cash

    cdef object _get_holdings(self, symbol):
        '\n        Gets holdings.  Returns zero for any symbol not held.\n\n        Arguments:\n            symbol: The symbol to query.\n        '
        return self._slot_holdings[symbol] if symbol in self._slot_holdings else 0

    cdef object _get_known_bid_ask_midpoint(self, symbol):
        '\n        Get the known best bid, ask, and bid/ask midpoint from cached data. No volume.\n\n        Arguments:\n            symbol: The symbol to query.\n        '
        bid = self._slot_known_bids[symbol][0][0] if self._slot_known_bids[symbol] else None
        ask = self._slot_known_asks[symbol][0][0] if self._slot_known_asks[symbol] else None
        midpoint = int(round((bid + ask) / 2)) if bid is not None and ask is not None else None
        return (bid, ask, midpoint)

    cdef object _get_average_transaction_price(self):
        'Calculates the average price paid (weighted by the order size).'
        return _average_transaction_price(self._slot_executed_orders)

    cdef object _fmt_holdings(self, holdings):
        '\n        Prints holdings.\n\n        Standard dictionary->string representation is almost fine, but it is less\n        confusing to see the CASH holdings in dollars and cents, instead of just integer\n        cents.  We could change to a Holdings object that knows to print CASH "special".\n\n        Arguments:\n            holdings:\n        '
        h = ''
        for (k, v) in sorted(holdings.items()):
            if k == 'CASH':
                continue
            h += '{}: {}, '.format(k, v)
        h += '{}: {}'.format('CASH', holdings['CASH'])
        h = '{ ' + h + ' }'
        return h

    cdef object _get_wake_frequency(self):
        'Offset (ns) for the parent-scheduled first wakeup; 0 = at market open.'
        return 0

    cdef object _act_NoiseTrader(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        size = int(max(1, round(self._slot_random_state.normal(self._slot_order_size_mean, self._slot_order_size_std))))
        buy = bool(self._slot_random_state.randint(0, 2))
        offset = int(self._slot_random_state.randint(0, self._slot_price_offset_ticks + 1))
        if buy:
            anchor = int(ask) if ask else int(bid) if bid else self._slot_reference_price
            self._place_limit_order(self._slot_symbol, size, Side.BID, anchor + offset, None, False, False, False, False, True, None)
        else:
            anchor = int(bid) if bid else int(ask) if ask else self._slot_reference_price
            self._place_limit_order(self._slot_symbol, size, Side.ASK, anchor - offset, None, False, False, False, False, True, None)

    cdef object _act_MarketMaker(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        mid = int((bid + ask) // 2) if bid and ask else self._slot_reference_price
        self._cancel_all_orders()
        half = self._slot_spread_ticks // 2
        for lvl in range(self._slot_depth_levels):
            self._place_limit_order(self._slot_symbol, self._slot_size_per_level, Side.BID, mid - half - lvl, None, False, False, False, False, True, None)
            self._place_limit_order(self._slot_symbol, self._slot_size_per_level, Side.ASK, mid + half + lvl, None, False, False, False, False, True, None)

    cdef object _act_ValueTrader(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        if bid and ask:
            mid = (int(bid) + int(ask)) / 2.0
        elif bid:
            mid = float(bid)
        elif ask:
            mid = float(ask)
        else:
            return
        fundamental = int(self._slot_oracle.observe_price(self._slot_symbol, self._slot_current_time, self._slot_random_state, sigma_n=self._slot_sigma_n))
        size = int(max(1, round(self._slot_order_size_mean)))
        if mid < fundamental - self._slot_threshold_ticks and ask:
            self._place_limit_order(self._slot_symbol, size, Side.BID, int(ask), None, False, False, False, False, True, None)
        elif mid > fundamental + self._slot_threshold_ticks and bid:
            self._place_limit_order(self._slot_symbol, size, Side.ASK, int(bid), None, False, False, False, False, True, None)

    cdef object _act_MomentumTrader(self):
        (bid, _, ask, _) = self._get_known_bid_ask(self._slot_symbol, True)
        if bid and ask:
            mid = (int(bid) + int(ask)) / 2.0
        elif bid:
            mid = float(bid)
        elif ask:
            mid = float(ask)
        else:
            return
        self._slot__mid_history.append(mid)
        if len(self._slot__mid_history) > self._slot_lookback + 1:
            self._slot__mid_history.pop(0)
        if len(self._slot__mid_history) <= self._slot_lookback:
            return
        past = self._slot__mid_history[0]
        size = int(max(1, round(self._slot_order_size_mean)))
        if mid > past + self._slot_threshold_ticks and ask:
            self._place_limit_order(self._slot_symbol, size, Side.BID, int(ask), None, False, False, False, False, True, None)
        elif mid < past - self._slot_threshold_ticks and bid:
            self._place_limit_order(self._slot_symbol, size, Side.ASK, int(bid), None, False, False, False, False, True, None)

EXCHANGE_FIELDS = ('book_log_depth', 'book_logging', 'computation_delay', 'current_time', 'data_subscriptions', 'id', 'kernel', 'log', 'log_events', 'log_orders', 'log_to_file', 'market_close_price_subscriptions', 'metric_trackers', 'mkt_close', 'mkt_open', 'name', 'oracle', 'order_books', 'pipeline_delay', 'random_state', 'reschedule', 'stp_policy', 'stream_history', 'symbols', 'total_exchanged_volume', 'type')

cdef class NativeExchange:
    def __cinit__(self):
        self._prepared = False
        self._bound = False

    def __init__(self, source):
        if self._prepared or type(source) is not ExchangeAgent:
            raise ValueError("one-shot exact original exchange required")
        self._prepared = True
        self._missing = _MISSING
        self._source = source
        self._scheduler = None
        values = source.__dict__
        if type(values) is not dict or set(values) - set(EXCHANGE_FIELDS):
            raise ValueError("exchange initialized field domain differs")
        self._slot_book_log_depth = _MISSING
        self._slot_book_logging = _MISSING
        self._slot_computation_delay = _MISSING
        self._slot_current_time = _MISSING
        self._slot_data_subscriptions = _MISSING
        self._slot_id = _MISSING
        self._slot_kernel = _MISSING
        self._slot_log = _MISSING
        self._slot_log_events = _MISSING
        self._slot_log_orders = _MISSING
        self._slot_log_to_file = _MISSING
        self._slot_market_close_price_subscriptions = _MISSING
        self._slot_metric_trackers = _MISSING
        self._slot_mkt_close = _MISSING
        self._slot_mkt_open = _MISSING
        self._slot_name = _MISSING
        self._slot_oracle = _MISSING
        self._slot_order_books = _MISSING
        self._slot_pipeline_delay = _MISSING
        self._slot_random_state = _MISSING
        self._slot_reschedule = _MISSING
        self._slot_stp_policy = _MISSING
        self._slot_stream_history = _MISSING
        self._slot_symbols = _MISSING
        self._slot_total_exchanged_volume = _MISSING
        self._slot_type = _MISSING
        if 'book_log_depth' in values:
            self._slot_book_log_depth = values['book_log_depth']
        if 'book_logging' in values:
            self._slot_book_logging = values['book_logging']
        if 'computation_delay' in values:
            self._slot_computation_delay = values['computation_delay']
        if 'current_time' in values:
            self._slot_current_time = values['current_time']
        if 'data_subscriptions' in values:
            self._slot_data_subscriptions = values['data_subscriptions']
        if 'id' in values:
            self._slot_id = values['id']
        if 'kernel' in values:
            self._slot_kernel = values['kernel']
        if 'log' in values:
            self._slot_log = values['log']
        if 'log_events' in values:
            self._slot_log_events = values['log_events']
        if 'log_orders' in values:
            self._slot_log_orders = values['log_orders']
        if 'log_to_file' in values:
            self._slot_log_to_file = values['log_to_file']
        if 'market_close_price_subscriptions' in values:
            self._slot_market_close_price_subscriptions = values['market_close_price_subscriptions']
        if 'metric_trackers' in values:
            self._slot_metric_trackers = values['metric_trackers']
        if 'mkt_close' in values:
            self._slot_mkt_close = values['mkt_close']
        if 'mkt_open' in values:
            self._slot_mkt_open = values['mkt_open']
        if 'name' in values:
            self._slot_name = values['name']
        if 'oracle' in values:
            self._slot_oracle = values['oracle']
        if 'order_books' in values:
            self._slot_order_books = values['order_books']
        if 'pipeline_delay' in values:
            self._slot_pipeline_delay = values['pipeline_delay']
        if 'random_state' in values:
            self._slot_random_state = values['random_state']
        if 'reschedule' in values:
            self._slot_reschedule = values['reschedule']
        if 'stp_policy' in values:
            self._slot_stp_policy = values['stp_policy']
        if 'stream_history' in values:
            self._slot_stream_history = values['stream_history']
        if 'symbols' in values:
            self._slot_symbols = values['symbols']
        if 'total_exchanged_volume' in values:
            self._slot_total_exchanged_volume = values['total_exchanged_volume']
        if 'type' in values:
            self._slot_type = values['type']

    def bind_scheduler(self, scheduler):
        cdef ChainScheduler typed
        if type(scheduler) is not ChainScheduler:
            raise ValueError("same-extension exchange scheduler required")
        typed = scheduler
        if typed.kernel is not self._slot_kernel:
            raise ValueError("exchange scheduler/kernel differs")
        if self._scheduler is not None and self._scheduler is not typed:
            raise ValueError("exchange scheduler already bound")
        self._scheduler = typed

    def bind_after_source_retired(self):
        if self._bound or self._scheduler is None or self._source.__dict__ != {"_native_moved_to": id(self)}:
            raise ValueError("exchange retirement or binding differs")
        self._bound = True

    def abort_before_first_delivery(self):
        if self._slot_kernel.ttl_messages or self._slot_kernel._deliver_seq:
            raise ValueError("cannot abort exchange after delivery")
        self._bound = False

    def authority_bound(self):
        return bool(self._bound)

    def source_identity(self):
        return self._source

    def snapshot_fields(self):
        result = {}
        if self._slot_book_log_depth is not self._missing:
            result['book_log_depth'] = self._slot_book_log_depth
        if self._slot_book_logging is not self._missing:
            result['book_logging'] = self._slot_book_logging
        if self._slot_computation_delay is not self._missing:
            result['computation_delay'] = self._slot_computation_delay
        if self._slot_current_time is not self._missing:
            result['current_time'] = self._slot_current_time
        if self._slot_data_subscriptions is not self._missing:
            result['data_subscriptions'] = self._slot_data_subscriptions
        if self._slot_id is not self._missing:
            result['id'] = self._slot_id
        if self._slot_kernel is not self._missing:
            result['kernel'] = self._slot_kernel
        if self._slot_log is not self._missing:
            result['log'] = self._slot_log
        if self._slot_log_events is not self._missing:
            result['log_events'] = self._slot_log_events
        if self._slot_log_orders is not self._missing:
            result['log_orders'] = self._slot_log_orders
        if self._slot_log_to_file is not self._missing:
            result['log_to_file'] = self._slot_log_to_file
        if self._slot_market_close_price_subscriptions is not self._missing:
            result['market_close_price_subscriptions'] = self._slot_market_close_price_subscriptions
        if self._slot_metric_trackers is not self._missing:
            result['metric_trackers'] = self._slot_metric_trackers
        if self._slot_mkt_close is not self._missing:
            result['mkt_close'] = self._slot_mkt_close
        if self._slot_mkt_open is not self._missing:
            result['mkt_open'] = self._slot_mkt_open
        if self._slot_name is not self._missing:
            result['name'] = self._slot_name
        if self._slot_oracle is not self._missing:
            result['oracle'] = self._slot_oracle
        if self._slot_order_books is not self._missing:
            result['order_books'] = self._slot_order_books
        if self._slot_pipeline_delay is not self._missing:
            result['pipeline_delay'] = self._slot_pipeline_delay
        if self._slot_random_state is not self._missing:
            result['random_state'] = self._slot_random_state
        if self._slot_reschedule is not self._missing:
            result['reschedule'] = self._slot_reschedule
        if self._slot_stp_policy is not self._missing:
            result['stp_policy'] = self._slot_stp_policy
        if self._slot_stream_history is not self._missing:
            result['stream_history'] = self._slot_stream_history
        if self._slot_symbols is not self._missing:
            result['symbols'] = self._slot_symbols
        if self._slot_total_exchanged_volume is not self._missing:
            result['total_exchanged_volume'] = self._slot_total_exchanged_volume
        if self._slot_type is not self._missing:
            result['type'] = self._slot_type
        return result

    def __hash__(self):
        return object.__hash__(self)


    property book_log_depth:
        def __get__(self):
            if self._slot_book_log_depth is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log_depth'")
            return self._slot_book_log_depth

        def __set__(self, value):
            self._slot_book_log_depth = value

        def __del__(self):
            if self._slot_book_log_depth is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log_depth'")
            self._slot_book_log_depth = self._missing

    property book_logging:
        def __get__(self):
            if self._slot_book_logging is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_logging'")
            return self._slot_book_logging

        def __set__(self, value):
            self._slot_book_logging = value

        def __del__(self):
            if self._slot_book_logging is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_logging'")
            self._slot_book_logging = self._missing

    property computation_delay:
        def __get__(self):
            if self._slot_computation_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'computation_delay'")
            return self._slot_computation_delay

        def __set__(self, value):
            self._slot_computation_delay = value

        def __del__(self):
            if self._slot_computation_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'computation_delay'")
            self._slot_computation_delay = self._missing

    property current_time:
        def __get__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            return self._slot_current_time

        def __set__(self, value):
            self._slot_current_time = value

        def __del__(self):
            if self._slot_current_time is self._missing:
                raise AttributeError("native owner has no initialized attribute 'current_time'")
            self._slot_current_time = self._missing

    property data_subscriptions:
        def __get__(self):
            if self._slot_data_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'data_subscriptions'")
            return self._slot_data_subscriptions

        def __set__(self, value):
            self._slot_data_subscriptions = value

        def __del__(self):
            if self._slot_data_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'data_subscriptions'")
            self._slot_data_subscriptions = self._missing

    property id:
        def __get__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            return self._slot_id

        def __set__(self, value):
            self._slot_id = value

        def __del__(self):
            if self._slot_id is self._missing:
                raise AttributeError("native owner has no initialized attribute 'id'")
            self._slot_id = self._missing

    property kernel:
        def __get__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            return self._slot_kernel

        def __set__(self, value):
            self._slot_kernel = value

        def __del__(self):
            if self._slot_kernel is self._missing:
                raise AttributeError("native owner has no initialized attribute 'kernel'")
            self._slot_kernel = self._missing

    property log:
        def __get__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            return self._slot_log

        def __set__(self, value):
            self._slot_log = value

        def __del__(self):
            if self._slot_log is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log'")
            self._slot_log = self._missing

    property log_events:
        def __get__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            return self._slot_log_events

        def __set__(self, value):
            self._slot_log_events = value

        def __del__(self):
            if self._slot_log_events is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_events'")
            self._slot_log_events = self._missing

    property log_orders:
        def __get__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            return self._slot_log_orders

        def __set__(self, value):
            self._slot_log_orders = value

        def __del__(self):
            if self._slot_log_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_orders'")
            self._slot_log_orders = self._missing

    property log_to_file:
        def __get__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            return self._slot_log_to_file

        def __set__(self, value):
            self._slot_log_to_file = value

        def __del__(self):
            if self._slot_log_to_file is self._missing:
                raise AttributeError("native owner has no initialized attribute 'log_to_file'")
            self._slot_log_to_file = self._missing

    property market_close_price_subscriptions:
        def __get__(self):
            if self._slot_market_close_price_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'market_close_price_subscriptions'")
            return self._slot_market_close_price_subscriptions

        def __set__(self, value):
            self._slot_market_close_price_subscriptions = value

        def __del__(self):
            if self._slot_market_close_price_subscriptions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'market_close_price_subscriptions'")
            self._slot_market_close_price_subscriptions = self._missing

    property metric_trackers:
        def __get__(self):
            if self._slot_metric_trackers is self._missing:
                raise AttributeError("native owner has no initialized attribute 'metric_trackers'")
            return self._slot_metric_trackers

        def __set__(self, value):
            self._slot_metric_trackers = value

        def __del__(self):
            if self._slot_metric_trackers is self._missing:
                raise AttributeError("native owner has no initialized attribute 'metric_trackers'")
            self._slot_metric_trackers = self._missing

    property mkt_close:
        def __get__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            return self._slot_mkt_close

        def __set__(self, value):
            self._slot_mkt_close = value

        def __del__(self):
            if self._slot_mkt_close is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_close'")
            self._slot_mkt_close = self._missing

    property mkt_open:
        def __get__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            return self._slot_mkt_open

        def __set__(self, value):
            self._slot_mkt_open = value

        def __del__(self):
            if self._slot_mkt_open is self._missing:
                raise AttributeError("native owner has no initialized attribute 'mkt_open'")
            self._slot_mkt_open = self._missing

    property name:
        def __get__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            return self._slot_name

        def __set__(self, value):
            self._slot_name = value

        def __del__(self):
            if self._slot_name is self._missing:
                raise AttributeError("native owner has no initialized attribute 'name'")
            self._slot_name = self._missing

    property oracle:
        def __get__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            return self._slot_oracle

        def __set__(self, value):
            self._slot_oracle = value

        def __del__(self):
            if self._slot_oracle is self._missing:
                raise AttributeError("native owner has no initialized attribute 'oracle'")
            self._slot_oracle = self._missing

    property order_books:
        def __get__(self):
            if self._slot_order_books is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_books'")
            return self._slot_order_books

        def __set__(self, value):
            self._slot_order_books = value

        def __del__(self):
            if self._slot_order_books is self._missing:
                raise AttributeError("native owner has no initialized attribute 'order_books'")
            self._slot_order_books = self._missing

    property pipeline_delay:
        def __get__(self):
            if self._slot_pipeline_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'pipeline_delay'")
            return self._slot_pipeline_delay

        def __set__(self, value):
            self._slot_pipeline_delay = value

        def __del__(self):
            if self._slot_pipeline_delay is self._missing:
                raise AttributeError("native owner has no initialized attribute 'pipeline_delay'")
            self._slot_pipeline_delay = self._missing

    property random_state:
        def __get__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            return self._slot_random_state

        def __set__(self, value):
            self._slot_random_state = value

        def __del__(self):
            if self._slot_random_state is self._missing:
                raise AttributeError("native owner has no initialized attribute 'random_state'")
            self._slot_random_state = self._missing

    property reschedule:
        def __get__(self):
            if self._slot_reschedule is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reschedule'")
            return self._slot_reschedule

        def __set__(self, value):
            self._slot_reschedule = value

        def __del__(self):
            if self._slot_reschedule is self._missing:
                raise AttributeError("native owner has no initialized attribute 'reschedule'")
            self._slot_reschedule = self._missing

    property stp_policy:
        def __get__(self):
            if self._slot_stp_policy is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stp_policy'")
            return self._slot_stp_policy

        def __set__(self, value):
            self._slot_stp_policy = value

        def __del__(self):
            if self._slot_stp_policy is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stp_policy'")
            self._slot_stp_policy = self._missing

    property stream_history:
        def __get__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            return self._slot_stream_history

        def __set__(self, value):
            self._slot_stream_history = value

        def __del__(self):
            if self._slot_stream_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'stream_history'")
            self._slot_stream_history = self._missing

    property symbols:
        def __get__(self):
            if self._slot_symbols is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbols'")
            return self._slot_symbols

        def __set__(self, value):
            self._slot_symbols = value

        def __del__(self):
            if self._slot_symbols is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbols'")
            self._slot_symbols = self._missing

    property total_exchanged_volume:
        def __get__(self):
            if self._slot_total_exchanged_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'total_exchanged_volume'")
            return self._slot_total_exchanged_volume

        def __set__(self, value):
            self._slot_total_exchanged_volume = value

        def __del__(self):
            if self._slot_total_exchanged_volume is self._missing:
                raise AttributeError("native owner has no initialized attribute 'total_exchanged_volume'")
            self._slot_total_exchanged_volume = self._missing

    property type:
        def __get__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            return self._slot_type

        def __set__(self, value):
            self._slot_type = value

        def __del__(self):
            if self._slot_type is self._missing:
                raise AttributeError("native owner has no initialized attribute 'type'")
            self._slot_type = self._missing

    def kernel_terminating(self):
        return self._kernel_terminating()

    def wakeup(self, current_time):
        return self._wakeup(current_time)

    def receive_message(self, current_time, sender_id, message):
        return self._receive_message(current_time, sender_id, message)

    def publish_order_book_data(self):
        return self._publish_order_book_data()

    def handle_frequency_based_data_subscription(self, symbol, data_sub):
        return self._handle_frequency_based_data_subscription(symbol, data_sub)

    def handle_event_based_data_subscription(self, symbol, data_sub):
        return self._handle_event_based_data_subscription(symbol, data_sub)

    def logL2style(self, symbol):
        return self._logL2style(symbol)

    def send_message(self, recipient_id, message):
        return self._send_message(recipient_id, message)

    def analyse_order_book(self, symbol):
        return self._analyse_order_book(symbol)

    def _original_time_dropout(self, book, symbol):
        return self.__original_time_dropout(book, symbol)

    def get_time_dropout(self, book, symbol):
        return self._get_time_dropout(book, symbol)

    def logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        return self._logEvent(event_type, event, append_summary_log, deepcopy_event)

    def set_wakeup(self, requested_time):
        return self._set_wakeup(requested_time)

    def set_computation_delay(self, requested_delay):
        return self._set_computation_delay(requested_delay)

    def write_log(self, df_log, filename=None):
        return self._write_log(df_log, filename)

    def kernel_stopping(self):
        return self._kernel_stopping()

    cdef object _kernel_terminating(self):
        self._base_kernel_terminating()
        (bid_volume, ask_volume) = (<NativeBook>self._slot_order_books['ABM'])._get_transacted_volume(self._slot_current_time - self._slot_mkt_open)
        self._slot_total_exchanged_volume = bid_volume + ask_volume
        for symbol in self._slot_symbols:
            self._analyse_order_book(symbol)
        for symbol in self._slot_symbols:
            (bid_volume, ask_volume) = (<NativeBook>self._slot_order_books[symbol])._get_transacted_volume(self._slot_current_time - self._slot_mkt_open)
            self._slot_metric_trackers[symbol].total_exchanged_volume = bid_volume + ask_volume
            self._slot_metric_trackers[symbol].last_trade = (<NativeBook>self._slot_order_books[symbol])._slot_last_trade
        if self._slot_log_orders == None:
            return
        if hasattr(self._slot_oracle, 'f_log'):
            for symbol in self._slot_oracle.f_log:
                dfFund = pd.DataFrame(self._slot_oracle.f_log[symbol])
                if not dfFund.empty:
                    dfFund.set_index('FundamentalTime', inplace=True)
                    self._write_log(dfFund, 'fundamental_{}'.format(symbol))
                    if exchange_logger.isEnabledFor(10):
                        exchange_logger.debug('Fundamental archival complete.')

    cdef object _wakeup(self, current_time):
        cdef NativeBook book
        self._base_wakeup(current_time)
        if current_time >= self._slot_mkt_close:
            message = MarketClosePriceMsg({symbol: book._slot_last_trade for (symbol, book) in self._slot_order_books.items()})
            for agent in self._slot_market_close_price_subscriptions:
                self._send_message(agent, message)

    cdef object _receive_message(self, current_time, sender_id, message):
        self._base_receive_message(current_time, sender_id, message)
        self._set_computation_delay(self._slot_computation_delay)
        if current_time > self._slot_mkt_close:
            if isinstance(message, OrderMsg):
                if isinstance(message, ModifyOrderMsg):
                    if exchange_logger.isEnabledFor(10):
                        exchange_logger.debug('{} received {}: OLD: {} NEW: {}'.format(self._slot_name, message.type(), message.old_order, message.new_order))
                elif exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received {}: {}'.format(self._slot_name, message.type(), message.order))
                self._send_message(sender_id, MarketClosedMsg())
                return
            elif isinstance(message, QueryMsg):
                pass
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received {}, discarded: market is closed.'.format(self._slot_name, message.type()))
                self._send_message(sender_id, MarketClosedMsg())
                return
        if isinstance(message, OrderMsg):
            if self._slot_log_orders:
                if isinstance(message, (ModifyOrderMsg, ReplaceOrderMsg)):
                    _observer.order(self, message.type(), message.new_order, deepcopy_event=False)
                else:
                    _observer.order(self, message.type(), message.order, deepcopy_event=False)
        else:
            _observer.diagnostic(self, message.type(), message)
        if isinstance(message, MarketDataSubReqMsg):
            if message.symbol not in self._slot_order_books:
                return
            if message.cancel == True:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received MarketDataSubscriptionCancellation request from agent {}'.format(self._slot_name, sender_id))
                for data_sub in self._slot_data_subscriptions[message.symbol]:
                    if data_sub.agent_id == sender_id and data_sub.freq == message.freq and (data_sub.depth == message.depth) and (data_sub.__class__ == message.__class__):
                        self._slot_data_subscriptions[message.symbol].remove(data_sub)
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received MarketDataSubscriptionRequest request from agent {}'.format(self._slot_name, sender_id))
                if isinstance(message, L1SubReqMsg):
                    sub = ExchangeAgent.L1DataSubscription(sender_id, current_time, message.freq)
                elif isinstance(message, L2SubReqMsg):
                    sub = ExchangeAgent.L2DataSubscription(sender_id, current_time, message.freq, message.depth)
                elif isinstance(message, L3SubReqMsg):
                    sub = ExchangeAgent.L3DataSubscription(sender_id, current_time, message.freq, message.depth)
                elif isinstance(message, TransactedVolSubReqMsg):
                    sub = ExchangeAgent.TransactedVolDataSubscription(sender_id, current_time, message.freq, message.lookback)
                elif isinstance(message, BookImbalanceSubReqMsg):
                    sub = ExchangeAgent.BookImbalanceDataSubscription(sender_id, current_time, False, message.min_imbalance)
                else:
                    raise Exception
                self._slot_data_subscriptions[message.symbol].append(sub)
        if isinstance(message, MarketHoursRequestMsg):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received market hours request from agent {}'.format(self._slot_name, sender_id))
            self._set_computation_delay(0)
            self._send_message(sender_id, MarketHoursMsg(self._slot_mkt_open, self._slot_mkt_close))
        elif isinstance(message, MarketClosePriceRequestMsg):
            self._slot_market_close_price_subscriptions.append(sender_id)
        elif isinstance(message, QueryLastTradeMsg):
            symbol = message.symbol
            if symbol not in self._slot_order_books:
                warnings.warn(f'Last trade request discarded. Unknown symbol: {symbol}')
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received QUERY_LAST_TRADE ({}) request from agent {}'.format(self._slot_name, symbol, sender_id))
                self._send_message(sender_id, QueryLastTradeResponseMsg(symbol=symbol, last_trade=(<NativeBook>self._slot_order_books[symbol])._slot_last_trade, mkt_closed=current_time > self._slot_mkt_close))
        elif isinstance(message, QuerySpreadMsg):
            symbol = message.symbol
            depth = message.depth
            if symbol not in self._slot_order_books:
                warnings.warn(f'Bid-ask spread request discarded. Unknown symbol: {symbol}')
            else:
                if exchange_logger.isEnabledFor(10):
                    exchange_logger.debug('{} received QUERY_SPREAD ({}:{}) request from agent {}'.format(self._slot_name, symbol, depth, sender_id))
                self._send_message(sender_id, QuerySpreadResponseMsg(symbol=symbol, depth=depth, bids=(<NativeBook>self._slot_order_books[symbol])._get_l2_bid_data(depth), asks=(<NativeBook>self._slot_order_books[symbol])._get_l2_ask_data(depth), last_trade=(<NativeBook>self._slot_order_books[symbol])._slot_last_trade, mkt_closed=current_time > self._slot_mkt_close))
        elif isinstance(message, QueryOrderStreamMsg):
            symbol = message.symbol
            length = message.length
            if symbol not in self._slot_order_books:
                warnings.warn(f'Order stream request discarded. Unknown symbol: {symbol}')
            elif exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received QUERY_ORDER_STREAM ({}:{}) request from agent {}'.format(self._slot_name, symbol, length, sender_id))
            self._send_message(sender_id, QueryOrderStreamResponseMsg(symbol=symbol, length=length, orders=(<NativeBook>self._slot_order_books[symbol])._slot_history[1:length + 1], mkt_closed=current_time > self._slot_mkt_close))
        elif isinstance(message, QueryTransactedVolMsg):
            symbol = message.symbol
            lookback_period = message.lookback_period
            if symbol not in self._slot_order_books:
                warnings.warn(f'Order stream request discarded. Unknown symbol: {symbol}')
            elif exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received QUERY_TRANSACTED_VOLUME ({}:{}) request from agent {}'.format(self._slot_name, symbol, lookback_period, sender_id))
            (bid_volume, ask_volume) = (<NativeBook>self._slot_order_books[symbol])._get_transacted_volume(lookback_period)
            self._send_message(sender_id, QueryTransactedVolResponseMsg(symbol=symbol, bid_volume=bid_volume, ask_volume=ask_volume, mkt_closed=current_time > self._slot_mkt_close))
        elif isinstance(message, LimitOrderMsg):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received LIMIT_ORDER: {}'.format(self._slot_name, message.order))
            if message.order.symbol not in self._slot_order_books:
                warnings.warn(f'Limit Order discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>self._slot_order_books[message.order.symbol])._handle_limit_order(deepcopy(message.order), False)
                self._publish_order_book_data()
        elif isinstance(message, MarketOrderMsg):
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received MARKET_ORDER: {}'.format(self._slot_name, message.order))
            if message.order.symbol not in self._slot_order_books:
                warnings.warn(f'Market Order discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>self._slot_order_books[message.order.symbol])._handle_market_order(deepcopy(message.order))
                self._publish_order_book_data()
        elif isinstance(message, CancelOrderMsg):
            tag = message.tag
            metadata = message.metadata
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received CANCEL_ORDER: {}'.format(self._slot_name, message.order))
            if message.order.symbol not in self._slot_order_books:
                warnings.warn(f'Cancellation request discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>self._slot_order_books[message.order.symbol])._cancel_order(deepcopy(message.order), tag, metadata, False)
                self._publish_order_book_data()
        elif isinstance(message, PartialCancelOrderMsg):
            tag = message.tag
            metadata = message.metadata
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received PARTIAL_CANCEL_ORDER: {}, new order: {}'.format(self._slot_name, message.order, message.quantity))
            if message.order.symbol not in self._slot_order_books:
                warnings.warn(f'Modification request discarded. Unknown symbol: {message.order.symbol}')
            else:
                (<NativeBook>self._slot_order_books[message.order.symbol])._partial_cancel_order(deepcopy(message.order), message.quantity, tag, metadata)
                self._publish_order_book_data()
        elif isinstance(message, ModifyOrderMsg):
            old_order = message.old_order
            new_order = message.new_order
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received MODIFY_ORDER: {}, new order: {}'.format(self._slot_name, old_order, new_order))
            if old_order.symbol not in self._slot_order_books:
                warnings.warn(f'Modification request discarded. Unknown symbol: {old_order.symbol}')
            else:
                (<NativeBook>self._slot_order_books[old_order.symbol])._modify_order(deepcopy(old_order), deepcopy(new_order))
                self._publish_order_book_data()
        elif isinstance(message, ReplaceOrderMsg):
            agent_id = message.agent_id
            order = message.old_order
            new_order = message.new_order
            if exchange_logger.isEnabledFor(10):
                exchange_logger.debug('{} received REPLACE_ORDER: {}, new order: {}'.format(self._slot_name, order, new_order))
            if order.symbol not in self._slot_order_books:
                warnings.warn(f'Replacement request discarded. Unknown symbol: {order.symbol}')
            else:
                (<NativeBook>self._slot_order_books[order.symbol])._replace_order(agent_id, deepcopy(order), deepcopy(new_order))
                self._publish_order_book_data()

    cdef object _publish_order_book_data(self):
        cdef NativeBook book
        for (symbol, data_subs) in self._slot_data_subscriptions.items():
            book = self._slot_order_books[symbol]
            for data_sub in data_subs:
                if isinstance(data_sub, ExchangeAgent.FrequencyBasedSubscription):
                    messages = self._handle_frequency_based_data_subscription(symbol, data_sub)
                elif isinstance(data_sub, ExchangeAgent.EventBasedSubscription):
                    messages = self._handle_event_based_data_subscription(symbol, data_sub)
                else:
                    raise Exception('Got invalid data subscription object')
                for message in messages:
                    self._send_message(data_sub.agent_id, message)
                if len(messages) > 0:
                    data_sub.last_update_ts = book._slot_last_update_ts

    cdef object _handle_frequency_based_data_subscription(self, symbol, data_sub):
        cdef NativeBook book
        book = self._slot_order_books[symbol]
        if book._slot_last_update_ts - data_sub.last_update_ts < data_sub.freq:
            return []
        messages = []
        if isinstance(data_sub, ExchangeAgent.L1DataSubscription):
            bid = book._get_l1_bid_data()
            ask = book._get_l1_ask_data()
            messages.append(L1DataMsg(symbol, book._slot_last_trade, self._slot_current_time, bid, ask))
        elif isinstance(data_sub, ExchangeAgent.L2DataSubscription):
            bids = book._get_l2_bid_data(data_sub.depth)
            asks = book._get_l2_ask_data(data_sub.depth)
            messages.append(L2DataMsg(symbol, book._slot_last_trade, self._slot_current_time, bids, asks))
        elif isinstance(data_sub, ExchangeAgent.L3DataSubscription):
            bids = book._get_l3_bid_data(data_sub.depth)
            asks = book._get_l3_ask_data(data_sub.depth)
            messages.append(L3DataMsg(symbol, book._slot_last_trade, self._slot_current_time, bids, asks))
        elif isinstance(data_sub, ExchangeAgent.L3DataSubscription):
            bids = book._get_l3_bid_data(data_sub.depth)
            asks = book._get_l3_ask_data(data_sub.depth)
            messages.append(L3DataMsg(symbol, book._slot_last_trade, self._slot_current_time, bids, asks))
        elif isinstance(data_sub, ExchangeAgent.TransactedVolDataSubscription):
            (bid_volume, ask_volume) = book._get_transacted_volume(data_sub.lookback)
            messages.append(TransactedVolDataMsg(symbol, book._slot_last_trade, self._slot_current_time, bid_volume, ask_volume))
        else:
            raise Exception('Got invalid data subscription object')
        return messages

    cdef object _handle_event_based_data_subscription(self, symbol, data_sub):
        cdef NativeBook book
        book = self._slot_order_books[symbol]
        messages = []
        if isinstance(data_sub, ExchangeAgent.BookImbalanceDataSubscription):
            (imbalance, side) = book._get_imbalance()
            event_in_progress = imbalance > data_sub.min_imbalance
            if data_sub.event_in_progress and event_in_progress:
                if side != data_sub.side:
                    messages.append(BookImbalanceDataMsg(symbol, book._slot_last_trade, self._slot_current_time, MarketDataEventMsg.Stage.FINISH, data_sub.imbalance, data_sub.side))
                    data_sub.event_in_progress = True
                    data_sub.side = side
                    data_sub.imbalance = imbalance
                    messages.append(BookImbalanceDataMsg(symbol, book._slot_last_trade, self._slot_current_time, MarketDataEventMsg.Stage.START, imbalance, side))
            elif data_sub.event_in_progress and (not event_in_progress):
                data_sub.event_in_progress = False
                data_sub.side = None
                data_sub.imbalance = None
                messages.append(BookImbalanceDataMsg(symbol, book._slot_last_trade, self._slot_current_time, MarketDataEventMsg.Stage.FINISH, imbalance, side))
            elif not data_sub.event_in_progress and event_in_progress:
                data_sub.event_in_progress = True
                data_sub.side = side
                data_sub.imbalance = imbalance
                messages.append(BookImbalanceDataMsg(symbol, book._slot_last_trade, self._slot_current_time, MarketDataEventMsg.Stage.START, imbalance, side))
            elif not data_sub.event_in_progress and (not event_in_progress):
                pass
        else:
            raise Exception('Got invalid data subscription object')
        return messages

    cdef object _logL2style(self, symbol):
        cdef NativeBook book
        book = self._slot_order_books[symbol]
        if not book._slot_book_log2:
            return None
        tmp = book._slot_book_log2
        times = []
        booktop = []
        for t in tmp:
            times.append(t['QuoteTime'])
            booktop.append([t['bids'], t['asks']])
        return (times, booktop)

    cdef object _send_message(self, recipient_id, message):
        if isinstance(message, (OrderAcceptedMsg, OrderCancelledMsg, OrderExecutedMsg)):
            self._scheduler._send(self._slot_id, recipient_id, message, self._slot_pipeline_delay)
            if self._slot_log_orders:
                _observer.order(self, message.type(), message.order)
        else:
            self._scheduler._send(self._slot_id, recipient_id, message, 0)

    cdef object _analyse_order_book(self, symbol):
        book = (<NativeBook>self._slot_order_books[symbol])._slot_book_log2
        self._get_time_dropout(book, symbol)

    cdef object __original_time_dropout(self, book, symbol):
        if len(book) == 0:
            return
        df = pd.DataFrame(book)
        total_time = df['QuoteTime'].iloc[-1] - df['QuoteTime'].iloc[0]
        is_null_bids = False
        t_null_bids_first = 0
        T_null_bids = 0
        is_null_asks = False
        t_null_asks_first = 0
        T_null_asks = 0
        for (_, row) in df.iterrows():
            if (len(row['bids']) == 0) & (is_null_bids == False):
                t_null_bids_first = row['QuoteTime']
                is_null_bids = True
            elif (len(row['bids']) != 0) & (is_null_bids == True):
                T_null_bids += row['QuoteTime'] - t_null_bids_first
                is_null_bids = False
            if (len(row['asks']) == 0) & (is_null_asks == False):
                t_null_asks_first = row['QuoteTime']
                is_null_asks = True
            elif (len(row['asks']) != 0) & (is_null_asks == True):
                T_null_asks += row['QuoteTime'] - t_null_asks_first
                is_null_asks = False
        self._slot_metric_trackers[symbol] = ExchangeAgent.MetricTracker(total_time_no_liquidity_asks=T_null_asks / 1000000000.0, total_time_no_liquidity_bids=T_null_bids / 1000000000.0, pct_time_no_liquidity_asks=100 * T_null_asks / total_time, pct_time_no_liquidity_bids=100 * T_null_bids / total_time)

    cdef object _get_time_dropout(self, book, symbol):
        if not book:
            return
        limits = np.iinfo(np.int64)
        if _dropout_invalid(book, limits):
            return self.__original_time_dropout(book, symbol)
        total_time = np.int64(book[-1]['QuoteTime']) - np.int64(book[0]['QuoteTime'])
        is_null_bids = is_null_asks = False
        first_bid = first_ask = bid_time = ask_time = 0
        for row in book:
            timestamp = int(row['QuoteTime'])
            if len(row['bids']) == 0 and (not is_null_bids):
                (first_bid, is_null_bids) = (timestamp, True)
            elif len(row['bids']) != 0 and is_null_bids:
                bid_time += timestamp - first_bid
                is_null_bids = False
            if len(row['asks']) == 0 and (not is_null_asks):
                (first_ask, is_null_asks) = (timestamp, True)
            elif len(row['asks']) != 0 and is_null_asks:
                ask_time += timestamp - first_ask
                is_null_asks = False
        self._slot_metric_trackers[symbol] = ExchangeAgent.MetricTracker(total_time_no_liquidity_asks=ask_time / 1000000000.0, total_time_no_liquidity_bids=bid_time / 1000000000.0, pct_time_no_liquidity_asks=100 * ask_time / total_time, pct_time_no_liquidity_bids=100 * bid_time / total_time)

    cdef object _base_wakeup(self, current_time):
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received wakeup.'.format(fmt_ts(current_time), self._slot_id, self._slot_name))

    cdef object _base_receive_message(self, current_time, sender_id, message):
        assert self._slot_kernel is not None
        self._slot_current_time = current_time
        if agent_logger.isEnabledFor(logging.DEBUG):
            if agent_logger.isEnabledFor(10):
                agent_logger.debug('At {}, agent {} ({}) received: {}'.format(fmt_ts(current_time), self._slot_id, self._slot_name, message))

    cdef object _base_kernel_terminating(self):
        if _observer.skip_termination(self):
            return
        if self._slot_log and self._slot_log_to_file:
            df_log = pd.DataFrame(self._slot_log, columns=('EventTime', 'EventType', 'Event'))
            df_log.set_index('EventTime', inplace=True)
            self._write_log(df_log, None)

    cdef object _logEvent(self, event_type, event='', append_summary_log=False, deepcopy_event=True):
        if _observer.record_log(self, event_type, event, append_summary_log, deepcopy_event):
            return
        if not self._slot_log_events:
            return
        if deepcopy_event:
            if type(event) is dict and _primitive_event(event):
                event = event.copy()
            else:
                event = deepcopy(event)
        self._slot_log.append((self._slot_current_time, event_type, event))
        if append_summary_log:
            assert self._slot_kernel is not None
            self._slot_kernel.append_summary_log(self._slot_id, event_type, event)

    cdef object _set_wakeup(self, requested_time):
        assert self._slot_kernel is not None
        self._scheduler._set_wakeup(self._slot_id, requested_time)

    cdef object _set_computation_delay(self, requested_delay):
        assert self._slot_kernel is not None
        self._slot_kernel.set_agent_compute_delay(sender_id=self._slot_id, requested_delay=requested_delay)

    cdef object _write_log(self, df_log, filename=None):
        assert self._slot_kernel is not None
        self._slot_kernel.write_log(self._slot_id, df_log, filename)

    cdef object _kernel_stopping(self):
        pass

cdef class NativeLevel:

    property hidden_orders:
        def __get__(self):
            if self._slot_hidden_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'hidden_orders'")
            return self._slot_hidden_orders

        def __set__(self, value):
            self._slot_hidden_orders = value

        def __del__(self):
            if self._slot_hidden_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'hidden_orders'")
            self._slot_hidden_orders = self._missing

    property price:
        def __get__(self):
            if self._slot_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price'")
            return self._slot_price

        def __set__(self, value):
            self._slot_price = value

        def __del__(self):
            if self._slot_price is self._missing:
                raise AttributeError("native owner has no initialized attribute 'price'")
            self._slot_price = self._missing

    property side:
        def __get__(self):
            if self._slot_side is self._missing:
                raise AttributeError("native owner has no initialized attribute 'side'")
            return self._slot_side

        def __set__(self, value):
            self._slot_side = value

        def __del__(self):
            if self._slot_side is self._missing:
                raise AttributeError("native owner has no initialized attribute 'side'")
            self._slot_side = self._missing

    property visible_orders:
        def __get__(self):
            if self._slot_visible_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'visible_orders'")
            return self._slot_visible_orders

        def __set__(self, value):
            self._slot_visible_orders = value

        def __del__(self):
            if self._slot_visible_orders is self._missing:
                raise AttributeError("native owner has no initialized attribute 'visible_orders'")
            self._slot_visible_orders = self._missing

    property total_quantity:
        def __get__(self):
            return self._total_quantity()

    property is_empty:
        def __get__(self):
            return self._is_empty()

    def add_order(self, order, metadata=None):
        return self._add_order(order, metadata)

    def update_order_quantity(self, order_id, new_quantity):
        return self._update_order_quantity(order_id, new_quantity)

    def remove_order(self, order_id):
        return self._remove_order(order_id)

    def peek(self):
        return self._peek()

    def pop(self):
        return self._pop()

    def order_is_match(self, order):
        return self._order_is_match(order)

    def order_has_better_price(self, order):
        return self._order_has_better_price(order)

    def order_has_worse_price(self, order):
        return self._order_has_worse_price(order)

    def order_has_equal_price(self, order):
        return self._order_has_equal_price(order)

    def __init__(self, orders):
        self._missing = _MISSING
        if len(orders) == 0:
            raise ValueError('At least one LimitOrder must be given when initialising a PriceLevel.')
        self._slot_visible_orders = []
        self._slot_hidden_orders = []
        self._slot_price = orders[0][0].limit_price
        self._slot_side = orders[0][0].side
        for (order, metadata) in orders:
            self._add_order(order, metadata)

    cdef object _add_order(self, order, metadata=None):
        if order.is_hidden:
            self._slot_hidden_orders.append((order, metadata or {}))
        elif order.insert_by_id:
            insert_index = 0
            for (order2, _) in self._slot_visible_orders:
                if order2.order_id > order.order_id:
                    break
                insert_index += 1
            self._slot_visible_orders.insert(insert_index, (order, metadata or {}))
        else:
            self._slot_visible_orders.append((order, metadata or {}))

    cdef object _update_order_quantity(self, order_id, new_quantity):
        if new_quantity == 0:
            return False
        for (i, (order, metadata)) in enumerate(self._slot_visible_orders):
            if order.order_id == order_id:
                if new_quantity <= order.quantity:
                    order.quantity = new_quantity
                else:
                    self._slot_visible_orders.pop(i)
                    order.quantity = new_quantity
                    self._slot_visible_orders.append((order, metadata))
                return True
        for (i, (order, metadata)) in enumerate(self._slot_hidden_orders):
            if order.order_id == order_id:
                if new_quantity <= order.quantity:
                    order.quantity = new_quantity
                else:
                    self._slot_hidden_orders.pop(i)
                    order.quantity = new_quantity
                    self._slot_hidden_orders.append((order, metadata))
                return True
        return False

    cdef object _remove_order(self, order_id):
        for (i, (book_order, _)) in enumerate(self._slot_visible_orders):
            if book_order.order_id == order_id:
                return self._slot_visible_orders.pop(i)
        for (i, (book_order, _)) in enumerate(self._slot_hidden_orders):
            if book_order.order_id == order_id:
                return self._slot_hidden_orders.pop(i)
        return None

    cdef object _peek(self):
        if len(self._slot_visible_orders) > 0:
            return self._slot_visible_orders[0]
        elif len(self._slot_hidden_orders) > 0:
            return self._slot_hidden_orders[0]
        else:
            raise ValueError("Can't peek at LimitOrder in PriceLevel as it contains no orders")

    cdef object _pop(self):
        if len(self._slot_visible_orders) > 0:
            return self._slot_visible_orders.pop(0)
        elif len(self._slot_hidden_orders) > 0:
            return self._slot_hidden_orders.pop(0)
        else:
            raise ValueError("Can't pop LimitOrder from PriceLevel as it contains no orders")

    cdef object _order_is_match(self, order):
        if order.side == self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if order.side.is_bid() and order.limit_price >= self._slot_price and (not (order.is_post_only and self._total_quantity() == 0)):
            return True
        if order.side.is_ask() and order.limit_price <= self._slot_price and (not (order.is_post_only and self._total_quantity() == 0)):
            return True
        return False

    cdef object _order_has_better_price(self, order):
        if order.side != self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if order.side.is_bid() and order.limit_price > self._slot_price:
            return True
        if order.side.is_ask() and order.limit_price < self._slot_price:
            return True
        return False

    cdef object _order_has_worse_price(self, order):
        if order.side != self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        if order.side.is_bid() and order.limit_price < self._slot_price:
            return True
        if order.side.is_ask() and order.limit_price > self._slot_price:
            return True
        return False

    cdef object _order_has_equal_price(self, order):
        if order.side != self._slot_side:
            raise ValueError('Attempted to compare order on wrong side of book')
        return order.limit_price == self._slot_price

    cdef object _total_quantity(self):
        quantities = []
        for (order, _) in self._slot_visible_orders:
            quantities.append(order.quantity)
        return sum(quantities)

    cdef object _is_empty(self):
        return len(self._slot_visible_orders) == 0 and len(self._slot_hidden_orders) == 0

    def __eq__(self, other):
        if not isinstance(other, NativeLevel):
            raise NotImplementedError
        return self._slot_visible_orders == other.visible_orders and self._slot_hidden_orders == other.hidden_orders

cdef class NativeBook:

    property asks:
        def __get__(self):
            if self._slot_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'asks'")
            return self._slot_asks

        def __set__(self, value):
            self._slot_asks = value

        def __del__(self):
            if self._slot_asks is self._missing:
                raise AttributeError("native owner has no initialized attribute 'asks'")
            self._slot_asks = self._missing

    property bids:
        def __get__(self):
            if self._slot_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'bids'")
            return self._slot_bids

        def __set__(self, value):
            self._slot_bids = value

        def __del__(self):
            if self._slot_bids is self._missing:
                raise AttributeError("native owner has no initialized attribute 'bids'")
            self._slot_bids = self._missing

    property book_log2:
        def __get__(self):
            if self._slot_book_log2 is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log2'")
            return self._slot_book_log2

        def __set__(self, value):
            self._slot_book_log2 = value

        def __del__(self):
            if self._slot_book_log2 is self._missing:
                raise AttributeError("native owner has no initialized attribute 'book_log2'")
            self._slot_book_log2 = self._missing

    property buy_transactions:
        def __get__(self):
            if self._slot_buy_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'buy_transactions'")
            return self._slot_buy_transactions

        def __set__(self, value):
            self._slot_buy_transactions = value

        def __del__(self):
            if self._slot_buy_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'buy_transactions'")
            self._slot_buy_transactions = self._missing

    property history:
        def __get__(self):
            if self._slot_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'history'")
            return self._slot_history

        def __set__(self, value):
            self._slot_history = value

        def __del__(self):
            if self._slot_history is self._missing:
                raise AttributeError("native owner has no initialized attribute 'history'")
            self._slot_history = self._missing

    property last_trade:
        def __get__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            return self._slot_last_trade

        def __set__(self, value):
            self._slot_last_trade = value

        def __del__(self):
            if self._slot_last_trade is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_trade'")
            self._slot_last_trade = self._missing

    property last_update_ts:
        def __get__(self):
            if self._slot_last_update_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_update_ts'")
            return self._slot_last_update_ts

        def __set__(self, value):
            self._slot_last_update_ts = value

        def __del__(self):
            if self._slot_last_update_ts is self._missing:
                raise AttributeError("native owner has no initialized attribute 'last_update_ts'")
            self._slot_last_update_ts = self._missing

    property owner:
        def __get__(self):
            if self._slot_owner is self._missing:
                raise AttributeError("native owner has no initialized attribute 'owner'")
            return self._slot_owner

        def __set__(self, value):
            self._slot_owner = value

        def __del__(self):
            if self._slot_owner is self._missing:
                raise AttributeError("native owner has no initialized attribute 'owner'")
            self._slot_owner = self._missing

    property quotes_seen:
        def __get__(self):
            if self._slot_quotes_seen is self._missing:
                raise AttributeError("native owner has no initialized attribute 'quotes_seen'")
            return self._slot_quotes_seen

        def __set__(self, value):
            self._slot_quotes_seen = value

        def __del__(self):
            if self._slot_quotes_seen is self._missing:
                raise AttributeError("native owner has no initialized attribute 'quotes_seen'")
            self._slot_quotes_seen = self._missing

    property sell_transactions:
        def __get__(self):
            if self._slot_sell_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sell_transactions'")
            return self._slot_sell_transactions

        def __set__(self, value):
            self._slot_sell_transactions = value

        def __del__(self):
            if self._slot_sell_transactions is self._missing:
                raise AttributeError("native owner has no initialized attribute 'sell_transactions'")
            self._slot_sell_transactions = self._missing

    property symbol:
        def __get__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            return self._slot_symbol

        def __set__(self, value):
            self._slot_symbol = value

        def __del__(self):
            if self._slot_symbol is self._missing:
                raise AttributeError("native owner has no initialized attribute 'symbol'")
            self._slot_symbol = self._missing

    def handle_limit_order(self, order, quiet=False):
        return self._handle_limit_order(order, quiet)

    def handle_market_order(self, order):
        return self._handle_market_order(order)

    def execute_order(self, order):
        return self._execute_order(order)

    def enter_order(self, order, metadata=None, quiet=False):
        return self._enter_order(order, metadata, quiet)

    def cancel_order(self, order, tag=None, cancellation_metadata=None, quiet=False):
        return self._cancel_order(order, tag, cancellation_metadata, quiet)

    def modify_order(self, order, new_order):
        return self._modify_order(order, new_order)

    def partial_cancel_order(self, order, quantity, tag=None, cancellation_metadata=None):
        return self._partial_cancel_order(order, quantity, tag, cancellation_metadata)

    def replace_order(self, agent_id, old_order, new_order):
        return self._replace_order(agent_id, old_order, new_order)

    def append_book_log2(self):
        return self._append_book_log2()

    def get_l1_bid_data(self):
        return self._get_l1_bid_data()

    def get_l1_ask_data(self):
        return self._get_l1_ask_data()

    def get_l2_bid_data(self, depth=sys.maxsize):
        return self._get_l2_bid_data(depth)

    def get_l2_ask_data(self, depth=sys.maxsize):
        return self._get_l2_ask_data(depth)

    def get_l3_bid_data(self, depth=sys.maxsize):
        return self._get_l3_bid_data(depth)

    def get_l3_ask_data(self, depth=sys.maxsize):
        return self._get_l3_ask_data(depth)

    def get_transacted_volume(self, lookback_period='10min'):
        return self._get_transacted_volume(lookback_period)

    def get_imbalance(self):
        return self._get_imbalance()

    def get_L1_snapshots(self):
        return self._get_L1_snapshots()

    def bids_padding(self, book, nlevels):
        return self._bids_padding(book, nlevels)

    def asks_padding(self, book, nlevels):
        return self._asks_padding(book, nlevels)

    def get_L2_snapshots(self, nlevels):
        return self._get_L2_snapshots(nlevels)

    def get_l3_itch(self):
        return self._get_l3_itch()

    def pretty_print(self, silent=True):
        return self._pretty_print(silent)

    def __init__(self, owner, symbol):
        self._scheduler = None
        self._missing = _MISSING
        self._slot_owner = owner
        self._owner = owner
        self._slot_symbol = symbol
        self._slot_bids = []
        self._slot_asks = []
        self._slot_last_trade = None
        self._slot_book_log2 = []
        self._slot_quotes_seen = set()
        self._slot_history = []
        self._slot_last_update_ts = self._owner._slot_mkt_open
        self._slot_buy_transactions = []
        self._slot_sell_transactions = []

    cdef object _handle_limit_order(self, order, quiet=False):
        if order.symbol != self._slot_symbol:
            warnings.warn(f'{order.symbol} order discarded. Does not match OrderBook symbol: {self._slot_symbol}')
            return
        if order.quantity <= 0 or int(order.quantity) != order.quantity:
            warnings.warn(f'{order.symbol} order discarded. Quantity ({order.quantity}) must be a positive integer.')
            return
        if order.limit_price < 0 or int(order.limit_price) != order.limit_price:
            warnings.warn(f'{order.symbol} order discarded. Limit price ({order.limit_price}) must be a positive integer.')
            return
        executed = []
        while True:
            stp_policy = self._owner._slot_stp_policy
            if stp_policy:
                opp = self._slot_asks if order.side.is_bid() else self._slot_bids
                if opp and (<NativeLevel>opp[0])._order_is_match(order):
                    resting = (<NativeLevel>opp[0])._peek()[0]
                    if resting.agent_id == order.agent_id:
                        if stp_policy == 'cancel_oldest' and self._cancel_order(resting, None, None, quiet):
                            continue
                        if stp_policy != 'cancel_oldest':
                            if not quiet:
                                self._send(order.agent_id, OrderCancelledMsg(deepcopy(order)))
                            break
            matched_order = self._execute_order(order)
            if matched_order is not None:
                assert matched_order.fill_price is not None
                executed.append((matched_order.quantity, matched_order.fill_price))
                if order.quantity <= 0:
                    break
            else:
                self._enter_order(deepcopy(order), None, quiet)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('ACCEPTED: new order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order acceptance to agent {} for order {}', order.agent_id, order.order_id)
                if not quiet:
                    self._send(order.agent_id, OrderAcceptedMsg(order))
                break
        if self._slot_bids:
            _observer.quote(self._slot_owner, 'BEST_BID', self._slot_symbol, (<NativeLevel>self._slot_bids[0])._slot_price, (<NativeLevel>self._slot_bids[0])._total_quantity())
        if self._slot_asks:
            _observer.quote(self._slot_owner, 'BEST_ASK', self._slot_symbol, (<NativeLevel>self._slot_asks[0])._slot_price, (<NativeLevel>self._slot_asks[0])._total_quantity())
        if len(executed) > 0:
            trade_qty = 0
            trade_price = 0
            for (q, p) in executed:
                if book_logger.isEnabledFor(10):
                    book_logger.debug('Executed: {} @ {}', q, p)
                trade_qty += q
                trade_price += p * q
            avg_price = int(round(trade_price / trade_qty))
            if book_logger.isEnabledFor(10):
                book_logger.debug(f'Avg: {trade_qty} @ ${avg_price:0.4f}')
            self._owner._logEvent('LAST_TRADE', f'{trade_qty},${avg_price:0.4f}', False, True)
            self._slot_last_trade = avg_price

    cdef object _handle_market_order(self, order):
        if order.symbol != self._slot_symbol:
            warnings.warn(f'{order.symbol} order discarded. Does not match OrderBook symbol: {self._slot_symbol}')
            return
        if order.quantity <= 0 or int(order.quantity) != order.quantity:
            warnings.warn(f'{order.symbol} order discarded.  Quantity ({order.quantity}) must be a positive integer.')
            return
        order = deepcopy(order)
        while order.quantity > 0:
            stp_policy = self._owner._slot_stp_policy
            if stp_policy:
                opp = self._slot_asks if order.side.is_bid() else self._slot_bids
                if opp and (<NativeLevel>opp[0])._peek()[0].agent_id == order.agent_id:
                    if stp_policy == 'cancel_oldest' and self._cancel_order((<NativeLevel>opp[0])._peek()[0], None, None, False):
                        continue
                    if stp_policy != 'cancel_oldest':
                        self._send(order.agent_id, OrderCancelledMsg(deepcopy(order)))
                        break
            if self._execute_order(order) is None:
                break

    cdef object _execute_order(self, order):
        book = self._slot_asks if order.side.is_bid() else self._slot_bids
        if len(book) == 0:
            return None
        elif isinstance(order, LimitOrder) and (not (<NativeLevel>book[0])._order_is_match(order)):
            return None
        elif order.tag in ['MR_preprocess_ADD', 'MR_preprocess_REPLACE']:
            self._owner._logEvent(order.tag + '_POST_ONLY', {'order_id': order.order_id}, False, True)
            return None
        else:
            is_ptc_exec = False
            if order.quantity >= (<NativeLevel>book[0])._peek()[0].quantity:
                (matched_order, matched_order_metadata) = (<NativeLevel>book[0])._pop()
                if matched_order.is_price_to_comply:
                    is_ptc_exec = True
                    if matched_order_metadata['ptc_hidden'] == False:
                        raise Exception('Should not be executing on the visible half of a price to comply order!')
                    assert (<NativeLevel>book[1])._remove_order(matched_order.order_id) is not None
                    if (<NativeLevel>book[1])._is_empty():
                        del book[1]
                if (<NativeLevel>book[0])._is_empty():
                    del book[0]
            else:
                (book_order, book_order_metadata) = (<NativeLevel>book[0])._peek()
                matched_order = deepcopy(book_order)
                matched_order.quantity = order.quantity
                book_order.quantity -= matched_order.quantity
                if book_order.is_price_to_comply:
                    is_ptc_exec = True
                    if book_order_metadata['ptc_hidden'] == False:
                        raise Exception('Should not be executing on the visible half of a price to comply order!')
                    book_order_metadata['ptc_other_half'].quantity -= matched_order.quantity
            matched_order.fill_price = matched_order.limit_price
            if order.side.is_bid():
                self._slot_buy_transactions.append((self._owner._slot_current_time, matched_order.quantity))
            else:
                self._slot_sell_transactions.append((self._owner._slot_current_time, matched_order.quantity))
            self._slot_history.append(dict(time=self._owner._slot_current_time, type='EXEC', order_id=matched_order.order_id, agent_id=matched_order.agent_id, oppos_order_id=order.order_id, oppos_agent_id=order.agent_id, side='SELL' if order.side.is_bid() else 'BUY', quantity=matched_order.quantity, price=matched_order.limit_price if is_ptc_exec else None))
            filled_order = deepcopy(order)
            filled_order.quantity = matched_order.quantity
            filled_order.fill_price = matched_order.fill_price
            order.quantity -= filled_order.quantity
            if book_logger.isEnabledFor(10):
                book_logger.debug('MATCHED: new order {} vs old order {}', filled_order, matched_order)
            if book_logger.isEnabledFor(10):
                book_logger.debug('SENT: notifications of order execution to agents {} and {} for orders {} and {}', filled_order.agent_id, matched_order.agent_id, filled_order.order_id, matched_order.order_id)
            self._send(matched_order.agent_id, OrderExecutedMsg(matched_order))
            self._send(order.agent_id, OrderExecutedMsg(filled_order))
            if self._owner._slot_book_logging == True:
                self._append_book_log2()
            return matched_order

    cdef object _enter_order(self, order, metadata=None, quiet=False):
        cdef NativeLevel price_level
        if order.is_price_to_comply and (metadata is None or metadata == {} or 'ptc_hidden' not in metadata):
            hidden_order = deepcopy(order)
            visible_order = deepcopy(order)
            hidden_order.is_hidden = True
            hidden_order.limit_price += 1 if order.side.is_bid() else -1
            hidden_order_metadata = dict(ptc_hidden=True, ptc_other_half=visible_order)
            visible_order_metadata = dict(ptc_hidden=False, ptc_other_half=hidden_order)
            self._enter_order(hidden_order, hidden_order_metadata, True)
            self._enter_order(visible_order, visible_order_metadata, quiet)
            return
        book = self._slot_bids if order.side.is_bid() else self._slot_asks
        if len(book) == 0:
            book.append(NativeLevel([(order, metadata or {})]))
        elif (<NativeLevel>book[-1])._order_has_worse_price(order):
            book.append(NativeLevel([(order, metadata or {})]))
        else:
            for (i, price_level) in enumerate(book):
                if price_level._order_has_better_price(order):
                    book.insert(i, NativeLevel([(order, metadata or {})]))
                    break
                elif price_level._order_has_equal_price(order):
                    (<NativeLevel>book[i])._add_order(order, metadata or {})
                    break
        if quiet == False:
            self._slot_history.append(dict(time=self._owner._slot_current_time, type='LIMIT', order_id=order.order_id, agent_id=order.agent_id, side=order.side.value, quantity=order.quantity, price=order.limit_price))
        if self._owner._slot_book_logging == True and quiet == False:
            self._append_book_log2()

    cdef object _cancel_order(self, order, tag=None, cancellation_metadata=None, quiet=False):
        cdef NativeLevel price_level
        book = self._slot_bids if order.side.is_bid() else self._slot_asks
        if not book:
            return False
        for (i, price_level) in enumerate(book):
            if not price_level._order_has_equal_price(order):
                continue
            cancelled_order_result = price_level._remove_order(order.order_id)
            if cancelled_order_result is not None:
                (cancelled_order, metadata) = cancelled_order_result
                if price_level._is_empty():
                    del book[i]
                if book_logger.isEnabledFor(10):
                    book_logger.debug('CANCELLED: order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order cancellation to agent {} for order {}', cancelled_order.agent_id, cancelled_order.order_id)
                if cancelled_order.is_price_to_comply:
                    self._cancel_order(metadata['ptc_other_half'], None, None, True)
                if not quiet:
                    self._slot_history.append(dict(time=self._owner._slot_current_time, type='CANCEL', order_id=cancelled_order.order_id, tag=tag, metadata=cancellation_metadata if tag == 'auctionFill' else None))
                    self._send(order.agent_id, OrderCancelledMsg(cancelled_order))
                self._slot_last_update_ts = self._owner._slot_current_time
                if self._owner._slot_book_logging == True and quiet == False:
                    self._append_book_log2()
                return True
        return False

    cdef object _modify_order(self, order, new_order):
        cdef NativeLevel price_level
        if order.order_id != new_order.order_id:
            return
        book = self._slot_bids if order.side.is_bid() else self._slot_asks
        for price_level in book:
            if not price_level._order_has_equal_price(order):
                continue
            if price_level._update_order_quantity(order.order_id, new_order.quantity):
                self._slot_history.append(dict(time=self._owner._slot_current_time, type='MODIFY', order_id=order.order_id, new_side=order.side.value, new_quantity=new_order.quantity))
                if book_logger.isEnabledFor(10):
                    book_logger.debug('MODIFIED: order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order modification to agent {} for order {}', new_order.agent_id, new_order.order_id)
                self._send(order.agent_id, OrderModifiedMsg(new_order))
                self._slot_last_update_ts = self._owner._slot_current_time
                if self._owner._slot_book_logging == True is not None:
                    self._append_book_log2()

    cdef object _partial_cancel_order(self, order, quantity, tag=None, cancellation_metadata=None):
        cdef NativeLevel price_level
        if order.order_id == 19653081:
            print('inside OB partialCancel')
        book = self._slot_bids if order.side.is_bid() else self._slot_asks
        new_order = deepcopy(order)
        new_order.quantity -= quantity
        for price_level in book:
            if not price_level._order_has_equal_price(order):
                continue
            if price_level._update_order_quantity(order.order_id, new_order.quantity):
                self._slot_history.append(dict(time=self._owner._slot_current_time, type='CANCEL_PARTIAL', order_id=order.order_id, quantity=quantity, tag=tag, metadata=cancellation_metadata if tag == 'auctionFill' else None))
                if book_logger.isEnabledFor(10):
                    book_logger.debug('CANCEL_PARTIAL: order {}', order)
                if book_logger.isEnabledFor(10):
                    book_logger.debug('SENT: notifications of order partial cancellation to agent {} for order {}', new_order.agent_id, quantity)
                self._send(order.agent_id, OrderPartialCancelledMsg(new_order))
                self._slot_last_update_ts = self._owner._slot_current_time
                if self._owner._slot_book_logging == True:
                    self._append_book_log2()

    cdef object _replace_order(self, agent_id, old_order, new_order):
        if self._cancel_order(old_order, None, None, True) == True:
            self._slot_history.append(dict(time=self._owner._slot_current_time, type='REPLACE', old_order_id=old_order.order_id, new_order_id=new_order.order_id, quantity=new_order.quantity, price=new_order.limit_price))
            self._handle_limit_order(new_order, True)
            if book_logger.isEnabledFor(10):
                book_logger.debug('SENT: notifications of order replacement to agent {agent_id} for old order {old_order.order_id}, new order {new_order.order_id}')
            self._send(agent_id, OrderReplacedMsg(old_order, new_order))
        if self._owner._slot_book_logging == True:
            self._append_book_log2()

    cdef object _append_book_log2(self):
        cdef NativeLevel level
        if _observer.STATE is None:
            row = {'QuoteTime': self._owner._slot_current_time, 'bids': np.array(self._get_l2_bid_data(self._owner._slot_book_log_depth)), 'asks': np.array(self._get_l2_ask_data(self._owner._slot_book_log_depth))}
            self._slot_book_log2.append(row)
            return
        depth = self._owner._slot_book_log_depth
        bids = []
        for level in self._slot_bids[:depth]:
            if level._total_quantity() > 0:
                bids = [None]
                break
        asks = []
        for level in self._slot_asks[:depth]:
            if level._total_quantity() > 0:
                asks = [None]
                break
        self._slot_book_log2.append({'QuoteTime': self._owner._slot_current_time, 'bids': bids, 'asks': asks})

    cdef object _get_l1_bid_data(self):
        if len(self._slot_bids) == 0:
            return None
        index = 0
        while not (<NativeLevel>self._slot_bids[index])._total_quantity() > 0:
            index += 1
        return ((<NativeLevel>self._slot_bids[0])._slot_price, (<NativeLevel>self._slot_bids[0])._total_quantity())

    cdef object _get_l1_ask_data(self):
        if len(self._slot_asks) == 0:
            return None
        index = 0
        while not (<NativeLevel>self._slot_asks[index])._total_quantity() > 0:
            index += 1
        return ((<NativeLevel>self._slot_asks[index])._slot_price, (<NativeLevel>self._slot_asks[index])._total_quantity())

    cdef object _get_l2_bid_data(self, depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_bids[:depth]:
            rows.append((price_level._slot_price, price_level._total_quantity()))
        return list(filter(_positive_row, rows))

    cdef object _get_l2_ask_data(self, depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_asks[:depth]:
            rows.append((price_level._slot_price, price_level._total_quantity()))
        return list(filter(_positive_row, rows))

    cdef object _get_l3_bid_data(self, depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_bids[:depth]:
            quantities = []
            for (order, _) in price_level._slot_visible_orders:
                quantities.append(order.quantity)
            rows.append((price_level._slot_price, quantities))
        return rows

    cdef object _get_l3_ask_data(self, depth=sys.maxsize):
        cdef NativeLevel price_level
        rows = []
        for price_level in self._slot_asks[:depth]:
            quantities = []
            for (order, _) in price_level._slot_visible_orders:
                quantities.append(order.quantity)
            rows.append((price_level._slot_price, quantities))
        return rows

    cdef object _get_transacted_volume(self, lookback_period='10min'):
        window_start = self._owner._slot_current_time - str_to_ns(lookback_period)
        buy_transacted_volume = 0
        sell_transacted_volume = 0
        for (time, volume) in reversed(self._slot_buy_transactions):
            if time < window_start:
                break
            buy_transacted_volume += volume
        for (time, volume) in reversed(self._slot_sell_transactions):
            if time < window_start:
                break
            sell_transacted_volume += volume
        return (buy_transacted_volume, sell_transacted_volume)

    cdef object _get_imbalance(self):
        cdef NativeLevel price_level
        bid_quantities = []
        for price_level in self._slot_bids:
            bid_quantities.append(price_level._total_quantity())
        bid_vol = sum(bid_quantities)
        ask_quantities = []
        for price_level in self._slot_asks:
            ask_quantities.append(price_level._total_quantity())
        ask_vol = sum(ask_quantities)
        if bid_vol == ask_vol:
            return (0, None)
        elif bid_vol == 0:
            return (1.0, Side.ASK)
        elif ask_vol == 0:
            return (1.0, Side.BID)
        elif bid_vol < ask_vol:
            return (1 - bid_vol / ask_vol, Side.ASK)
        else:
            return (1 - ask_vol / bid_vol, Side.BID)

    cdef object _get_L1_snapshots(self):
        best_bids = []
        best_asks = []
        for d in self._slot_book_log2:
            best_bids.append([d['QuoteTime']] + _safe_first(d['bids']).tolist())
            best_asks.append([d['QuoteTime']] + _safe_first(d['asks']).tolist())
        best_bids = np.array(best_bids)
        best_asks = np.array(best_asks)
        return {'best_bids': best_bids, 'best_asks': best_asks}

    cdef object _bids_padding(self, book, nlevels):
        n = book.shape[0]
        if n == 0:
            return np.zeros((nlevels, 2), dtype=int)
        if n >= nlevels:
            return book[:nlevels, :]
        else:
            lowestprice = book[-1, 0] if len(book.shape) == 2 else book[0]
            npad = nlevels - n
            pad = np.transpose(np.array([-1 + np.arange(lowestprice, lowestprice - npad, -1, dtype=int), np.zeros(npad, dtype=int)]))
            if len(pad.shape) == 1:
                pad = pad.reshape(1, 2)
            return np.concatenate([book, pad])

    cdef object _asks_padding(self, book, nlevels):
        n = book.shape[0]
        if n == 0:
            return np.zeros((nlevels, 2), dtype=int)
        if n >= nlevels:
            return book[:nlevels, :]
        else:
            highestprice = book[-1, 0] if len(book.shape) == 2 else book[0]
            npad = nlevels - n
            pad = np.transpose(np.array([1 + np.arange(highestprice, highestprice + npad, 1, dtype=int), np.zeros(npad, dtype=int)]))
            if len(pad.shape) == 1:
                pad = pad.reshape(1, 2)
            return np.concatenate([book, pad])

    cdef object _get_L2_snapshots(self, nlevels):
        (times, bids, asks) = ([], [], [])
        for x in self._slot_book_log2:
            times.append(x['QuoteTime'])
            bids.append(self.bids_padding(x['bids'], nlevels))
            asks.append(self.asks_padding(x['asks'], nlevels))
        bids = np.array(bids)
        asks = np.array(asks)
        times = np.array(times)
        return {'times': times, 'bids': bids, 'asks': asks}

    cdef object _get_l3_itch(self):
        history_l3 = pd.DataFrame(self._slot_history)
        history_l3.loc[history_l3.tag == 'auctionFill', 'type'] = 'EXEC'
        history_l3.loc[history_l3.tag == 'auctionFill', 'quantity'] = history_l3.loc[history_l3.tag == 'auctionFill', 'metadata'].apply(_itch_quantity)
        history_l3.loc[history_l3.tag == 'auctionFill', 'price'] = history_l3.loc[history_l3.tag == 'auctionFill', 'metadata'].apply(_itch_price)
        history_l3['printable'] = np.nan
        history_l3['stock'] = np.nan
        if not 'REPLACE' in history_l3.type.unique():
            history_l3['new_order_id'] = np.nan
            history_l3['old_order_id'] = np.nan
        history_l3.loc[history_l3.type == 'REPLACE', 'order_id'] = history_l3.loc[history_l3.type == 'REPLACE', 'old_order_id']
        history_l3.loc[history_l3.type == 'EXEC', 'side'] = np.nan
        history_l3['type'] = history_l3['type'].replace({'LIMIT': 'ADD', 'CANCEL_PARTIAL': 'CANCEL', 'CANCEL': 'DELETE', 'EXEC': 'EXECUTE'})
        history_l3['side'] = history_l3['side'].replace({'ASK': 'S', 'BID': 'B'})
        history_l3['time'] = history_l3['time'] - ns_date(history_l3['time'])
        history_l3['price'] = history_l3['price'] * 100
        history_l3 = history_l3[['time', 'stock', 'type', 'order_id', 'side', 'quantity', 'price', 'new_order_id', 'printable']]
        history_l3 = history_l3.rename(columns={'time': 'timestamp', 'order_id': 'reference', 'new_order_id': 'new_reference', 'quantity': 'shares'})
        return history_l3

    cdef object _pretty_print(self, silent=True):
        assert self._slot_last_trade is not None
        book = '{} order book as of {}\n'.format(self._slot_symbol, self._owner._slot_current_time)
        book += 'Last trades: simulated {:d}, historical {:d}\n'.format(self._slot_last_trade, self._owner._slot_oracle.observe_price(self._slot_symbol, self._owner._slot_current_time, sigma_n=0, random_state=self._owner._slot_random_state))
        book += '{:10s}{:10s}{:10s}\n'.format('BID', 'PRICE', 'ASK')
        book += '{:10s}{:10s}{:10s}\n'.format('---', '-----', '---')
        for (quote, volume) in self._get_l2_ask_data(sys.maxsize)[-1::-1]:
            book += '{:10s}{:10s}{:10s}\n'.format('', '{:d}'.format(quote), '{:d}'.format(volume))
        for (quote, volume) in self._get_l2_bid_data(sys.maxsize):
            book += '{:10s}{:10s}{:10s}\n'.format('{:d}'.format(volume), '{:d}'.format(quote), '')
        if silent:
            return book
        else:
            print(book)
            return None

    cdef object _send(self, recipient_id, message):
        if self._scheduler is None:
            return self._owner._send_message(recipient_id, message)
        return self._owner._send_message(recipient_id, message)

    def bind_scheduler(self, scheduler):
        cdef ChainScheduler typed
        if type(scheduler) is not ChainScheduler:
            raise ValueError("same-extension book scheduler required")
        typed = scheduler
        if typed.kernel is not self._owner._slot_kernel:
            raise ValueError("book scheduler/kernel differs")
        if self._scheduler is not None and self._scheduler is not typed:
            raise ValueError("book scheduler already bound")
        self._scheduler = typed


cdef class FlatHeap:
    def __init__(self, queue):
        self.queue = queue
    def empty(self):
        return not self.queue
    def qsize(self):
        return len(self.queue)

cdef class ColumnLedger:
    def __init__(self):
        self.c0, self.c1, self.c2 = [], [], []
        self.c3, self.c4, self.c5 = [], [], []
        self.c6, self.c7, self.c8 = [], [], []
        self.columns = (self.c0, self.c1, self.c2, self.c3, self.c4, self.c5, self.c6, self.c7, self.c8)
    def __len__(self):
        return len(self.c0)
    cdef void _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns, latency_ns, msg_type, order_id, causal_parent) except *:
        self.c0.append(message_id)
        self.c1.append(src_id)
        self.c2.append(dst_id)
        self.c3.append(t_send_ns)
        self.c4.append(t_recv_ns)
        self.c5.append(latency_ns)
        self.c6.append(msg_type)
        self.c7.append(order_id)
        self.c8.append(causal_parent)

cdef class ChainScheduler:
    def __init__(self, kernel, ledger):
        self.kernel = kernel
        self.ledger = ledger
    def run(self, agent_actions=None):
        return self._run(agent_actions)
    def send(self, sender_id, recipient_id, message, delay=0):
        return self._send(sender_id, recipient_id, message, delay)
    def set_wakeup(self, sender_id, requested_time=None):
        return self._set_wakeup(sender_id, requested_time)
    cdef object _deliver_wakeup(self, recipient, current_time):
        cdef NativeTrader trader
        cdef NativeExchange exchange
        if type(recipient) is NativeTrader:
            trader = recipient
            trader._require_bound()
            return trader._wakeup(current_time)
        if type(recipient) is NativeExchange:
            exchange = recipient
            if not exchange._bound:
                raise ValueError("exchange authority unbound")
            return exchange._wakeup(current_time)
        raise ValueError("unadmitted receiver in authoritative roster")
    cdef object _deliver_message(self, recipient, current_time, sender_id, message):
        cdef NativeTrader trader
        cdef NativeExchange exchange
        if type(recipient) is NativeTrader:
            trader = recipient
            trader._require_bound()
            return trader._receive_message(current_time, sender_id, message)
        if type(recipient) is NativeExchange:
            exchange = recipient
            if not exchange._bound:
                raise ValueError("exchange authority unbound")
            return exchange._receive_message(current_time, sender_id, message)
        raise ValueError("unadmitted receiver in authoritative roster")


    cdef object _run(self, agent_actions=None):
        kernel = self.kernel
        if agent_actions is not None:
            (exp_agent, action_list) = agent_actions
            exp_agent.apply_actions(action_list)
        while not kernel.messages.empty() and kernel.current_time and (kernel.current_time <= kernel.stop_time):
            (kernel.current_time, sender_id, recipient_id, message) = heapq.heappop(kernel.messages.queue)
            assert kernel.current_time is not None
            if kernel.ttl_messages % 100000 == 0:
                if kernel_logger.isEnabledFor(20):
                    kernel_logger.info('--- Simulation time: {}, messages processed: {:,}, wallclock elapsed: {:.2f}s ---'.format(fmt_ts(kernel.current_time), kernel.ttl_messages, (datetime.now() - kernel.event_queue_wall_clock_start).total_seconds()))
            if kernel.show_trace_messages:
                if kernel_logger.isEnabledFor(10):
                    kernel_logger.debug('--- Kernel Event Queue pop ---')
                if kernel_logger.isEnabledFor(10):
                    kernel_logger.debug('Kernel handling {} message for agent {} at time {}'.format(message.type(), recipient_id, kernel.current_time))
            kernel.ttl_messages += 1
            kernel.current_agent_additional_delay = 0
            if isinstance(message, WakeupMsg):
                if kernel.agent_current_times[recipient_id] > kernel.current_time:
                    heapq.heappush(kernel.messages.queue, (kernel.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if kernel.show_trace_messages:
                        if kernel_logger.isEnabledFor(10):
                            kernel_logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
                    continue
                kernel.agent_current_times[recipient_id] = kernel.current_time
                kernel._current_causal_uid = message.message_id
                kernel._deliver_seq_by_key[message.message_id, recipient_id] = kernel._deliver_seq
                kernel._deliver_seq += 1
                self.ledger._append(message.message_id, recipient_id, recipient_id, None, kernel.current_time, 0, 'AGENT_WAKEUP', None, None)
                wakeup_result = self._deliver_wakeup(kernel.agents[recipient_id], kernel.current_time)
                kernel.agent_current_times[recipient_id] += kernel.agent_computation_delays[recipient_id] + kernel.current_agent_additional_delay
                if kernel.show_trace_messages:
                    if kernel_logger.isEnabledFor(10):
                        kernel_logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
                if wakeup_result != None:
                    return {'done': False, 'result': wakeup_result}
            else:
                if kernel.agent_current_times[recipient_id] > kernel.current_time:
                    heapq.heappush(kernel.messages.queue, (kernel.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if kernel.show_trace_messages:
                        if kernel_logger.isEnabledFor(10):
                            kernel_logger.debug('Agent in future: message requeued for {}'.format(fmt_ts(kernel.agent_current_times[recipient_id])))
                    continue
                kernel.agent_current_times[recipient_id] = kernel.current_time
                if isinstance(message, MessageBatch):
                    messages = message.messages
                else:
                    messages = [message]
                for message in messages:
                    kernel.agent_current_times[recipient_id] += kernel.agent_computation_delays[recipient_id] + kernel.current_agent_additional_delay
                    if kernel.show_trace_messages:
                        if kernel_logger.isEnabledFor(10):
                            kernel_logger.debug('After receive_message return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(kernel.current_time), fmt_ts(kernel.agent_current_times[recipient_id])))
                    kernel._current_causal_uid = message.message_id
                    kernel._deliver_seq_by_key[message.message_id, recipient_id] = kernel._deliver_seq
                    kernel._deliver_seq += 1
                    self._deliver_message(kernel.agents[recipient_id], kernel.current_time, sender_id, message)
        if kernel.messages.empty():
            if kernel_logger.isEnabledFor(10):
                kernel_logger.debug('--- Kernel Event Queue empty ---')
        if kernel.current_time and kernel.current_time > kernel.stop_time:
            if kernel_logger.isEnabledFor(10):
                kernel_logger.debug('--- Kernel Stop Time surpassed ---')
        if len(kernel.gym_agents) > 0:
            kernel.gym_agents[0].update_raw_state()
            return {'done': True, 'result': kernel.gym_agents[0].get_raw_state()}
        else:
            return {'done': True, 'result': None}

    cdef object _send(self, sender_id, recipient_id, message, delay=0):
        kernel = self.kernel
        sent_time = kernel.current_time + kernel.agent_computation_delays[sender_id] + kernel.current_agent_additional_delay + delay
        if kernel.agent_latency_model is not None:
            latency = kernel.agent_latency_model.get_latency(sender_id=sender_id, recipient_id=recipient_id)
            deliver_at = sent_time + int(latency)
            if kernel.show_trace_messages:
                if kernel_logger.isEnabledFor(10):
                    kernel_logger.debug('Kernel applied latency {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, kernel.current_agent_additional_delay, delay, kernel.agents[sender_id].name, kernel.agents[recipient_id].name, fmt_ts(deliver_at)))
        else:
            latency = kernel.agent_latency[sender_id][recipient_id]
            noise = kernel.random_state.choice(len(kernel.latency_noise), p=kernel.latency_noise)
            deliver_at = sent_time + int(latency + noise)
            if kernel.show_trace_messages:
                if kernel_logger.isEnabledFor(10):
                    kernel_logger.debug('Kernel applied latency {}, noise {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, noise, kernel.current_agent_additional_delay, delay, kernel.agents[sender_id].name, kernel.agents[recipient_id].name, fmt_ts(deliver_at)))
        heapq.heappush(kernel.messages.queue, (deliver_at, sender_id, recipient_id, message))
        _ledger_msgs = message.messages if isinstance(message, MessageBatch) else [message]
        for _lm in _ledger_msgs:
            _ord = getattr(_lm, 'order', None)
            self.ledger._append(_lm.message_id, sender_id, recipient_id, sent_time, deliver_at, deliver_at - sent_time, _lm.type(), getattr(_ord, 'order_id', None), kernel._current_causal_uid)
        if kernel.show_trace_messages:
            if kernel_logger.isEnabledFor(10):
                kernel_logger.debug('Sent time: {}, current time {}, computation delay {}'.format(sent_time, fmt_ts(kernel.current_time), kernel.agent_computation_delays[sender_id]))
            if kernel_logger.isEnabledFor(10):
                kernel_logger.debug('Message queued: {}'.format(message))

    cdef object _set_wakeup(self, sender_id, requested_time=None):
        kernel = self.kernel
        if requested_time is None:
            requested_time = kernel.current_time + 1
        if kernel.current_time and requested_time < kernel.current_time:
            raise ValueError('set_wakeup() called with requested time not in future', 'current_time:', kernel.current_time, 'requested_time:', requested_time)
        if kernel.show_trace_messages:
            if kernel_logger.isEnabledFor(10):
                kernel_logger.debug('Kernel adding wakeup for agent {} at time {}'.format(sender_id, fmt_ts(requested_time)))
        heapq.heappush(kernel.messages.queue, (requested_time, sender_id, sender_id, WakeupMsg()))

def _primitive_event(event):
    return all(type(key) is str and type(value) in (str, int, float, bool, type(None)) for key, value in event.items())
def _average_transaction_price(orders):
    return round(sum(order.quantity * order.fill_price for order in orders) / sum(order.quantity for order in orders), 2)
def _dropout_invalid(book, limits):
    return any(type(row.get('QuoteTime')) not in (int, np.int64) or not limits.min <= row['QuoteTime'] <= limits.max or type(row.get('bids')) not in (list, np.ndarray) or type(row.get('asks')) not in (list, np.ndarray) for row in book)
def _itch_quantity(x):
    return x['quantity']
def _itch_price(x):
    return x['price']
def _safe_first(x):
    return x[0] if len(x) > 0 else np.array([None, None])
