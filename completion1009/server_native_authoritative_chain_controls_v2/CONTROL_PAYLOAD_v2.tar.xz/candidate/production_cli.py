#!/usr/bin/env python3
"""Future JSON -> native authority -> original official-output adapter.

This transition moves initialized traders, exchange, books, queue envelopes and
ledger into one extension while retaining original Message/Order, RNG/oracle
and official output semantics. Source/ELF loading and observer authentication
are cold checks. Both contract verbs use real measured wall time; this source
does not establish a runtime PASS or competitive throughput.
"""
import time
ENTRY_STARTED = time.perf_counter()

import argparse
import json
from pathlib import Path
import resource
import sys


def activate_paths(runtime):
    runtime = Path(runtime).resolve()
    sys.path.insert(0, str(runtime))
    from bootstrap import activate
    activate()
    return runtime


def simulate(config_path, out_path, build_dir, runtime, arm="native_owner", started=None):
    if arm not in ("original", "native_owner"):
        raise ValueError("unknown native-owner arm")
    t0 = time.perf_counter() if started is None else started
    if "trader_probe" in sys.modules:
        raise ValueError("production loaded the control-only probe")
    runtime = activate_paths(runtime)
    from source_provenance import verify_sources, verify_runtime
    verify_sources()
    verify_runtime(runtime)
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_fork.config import build_config
    from abides_fork.simulate import reset_abides_counters
    from abides_fork.trace import extract_trace, extract_message_trace
    from contracts import sha256, validate_scenario, validate_frames
    import observer
    from observer_domain import authenticate_loaded
    scenario = json.loads(Path(config_path).read_bytes())
    validate_scenario(scenario)
    if not authenticate_loaded():
        raise ValueError("original loaded observer/strategy domain differs")
    chosen = Kernel
    if arm == "native_owner":
        from native_loader import load
        load(build_dir, runtime)
        from native_owner_kernel import NativeOwnerKernel
        chosen = NativeOwnerKernel
    original_kernel, summary_writer = abides.Kernel, Kernel.write_summary_log
    try:
        if observer.STATE is not None:
            raise ValueError("previous observer episode still active")
        if not observer.begin_episode(scenario, authenticated=True):
            raise ValueError("scenario outside original four-strategy observer domain")
        reset_abides_counters()
        config = build_config(scenario)
        # suppress only pinned non-contract summary-file IO, equally in both arms
        Kernel.write_summary_log = lambda self: None
        abides.Kernel = chosen
        end_state = abides.run(config)
        kernel = end_state["agents"][0].kernel
        if type(kernel) is not chosen or kernel.agents is not end_state["agents"]:
            raise ValueError("actual selected kernel/roster did not run")
        if arm == "native_owner":
            kernel._chain_migration.assert_authority()
        trace = extract_trace(end_state)
        from ledger_writer import extract as ledger_extract
        from abides_fork.trace import MESSAGE_TRACE_COLUMNS, _MSG_DTYPES
        messages = ledger_extract(end_state, MESSAGE_TRACE_COLUMNS, _MSG_DTYPES) if arm == "native_owner" else extract_message_trace(end_state)
        validate_frames(trace, messages)
    finally:
        abides.Kernel, Kernel.write_summary_log = original_kernel, summary_writer
        observer.finish_episode()
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    trace.to_parquet(out, compression="snappy", index=False)
    messages.to_parquet(out.parent / "message_trace.parquet", compression="snappy", index=False)
    wall = time.perf_counter() - t0
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    result = {"scenario_id": str(scenario["scenario_id"]), "seed": int(scenario["seed"]),
              "n_events": len(trace), "wall_clock_sec": wall, "events_per_sec": len(trace) / wall,
              "trace_sha256": sha256(out), "peak_memory_bytes": int(rss) * 1024, "gpu_seconds": 0.0}
    (out.parent / "events.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    return result


def simulate_batch(batch_dir, out_dir, build_dir, runtime, arm="native_owner", started=None):
    t0 = time.perf_counter() if started is None else started
    paths = sorted(path for path in Path(batch_dir).glob("*.json")
                   if all(part != "__pycache__" and not part.startswith("._") for part in path.parts))
    if not paths:
        raise ValueError("batch directory has no scenarios")
    rows = []
    for path in paths:
        item = simulate(path, Path(out_dir) / path.stem / "trace.parquet", build_dir, runtime, arm)
        rows.append({"sub": path.stem, "n_events": item["n_events"],
                     "scenario_id": item["scenario_id"], "seed": item["seed"]})
    wall = time.perf_counter() - t0
    count = sum(row["n_events"] for row in rows)
    result = {"n_scenarios": len(rows), "total_events": count, "wall_clock_sec": wall,
              "events_per_sec": count / wall, "per_scenario": rows}
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    (Path(out_dir) / "batch_events.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="verb", required=True)
    single = sub.add_parser("simulate")
    single.add_argument("--config", required=True)
    single.add_argument("--out", required=True)
    batch = sub.add_parser("simulate-batch")
    batch.add_argument("--batch-dir", required=True)
    batch.add_argument("--out-dir", required=True)
    for command in (single, batch):
        command.add_argument("--runtime", required=True)
        command.add_argument("--build", required=True)
        command.add_argument("--arm", choices=("original", "native_owner"), default="native_owner")
    args = parser.parse_args()
    result = (simulate(args.config, args.out, args.build, args.runtime, args.arm, ENTRY_STARTED)
              if args.verb == "simulate" else simulate_batch(args.batch_dir, args.out_dir,
                  args.build, args.runtime, args.arm, ENTRY_STARTED))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
