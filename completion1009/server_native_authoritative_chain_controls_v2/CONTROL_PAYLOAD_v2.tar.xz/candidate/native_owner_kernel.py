"""Original constructor/initialize retained; cold authority migration afterward."""
from abides_core.kernel import Kernel as OriginalKernel


class NativeOwnerKernel(OriginalKernel):
    def initialize(self):
        if "_chain_migration" in self.__dict__:
            raise ValueError("chain does not reinitialize a live owner")
        super().initialize()
        import authoritative_chain
        from state_mapper import migrate
        migrate(self, authoritative_chain)

    def runner(self, agent_actions=None):
        return self._chain_scheduler.run(agent_actions)

    def send_message(self, sender_id, recipient_id, message, delay=0):
        if "_chain_scheduler" not in self.__dict__:
            return super().send_message(sender_id, recipient_id, message, delay)
        return self._chain_scheduler.send(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        if "_chain_scheduler" not in self.__dict__:
            return super().set_wakeup(sender_id, requested_time)
        return self._chain_scheduler.set_wakeup(sender_id, requested_time)
