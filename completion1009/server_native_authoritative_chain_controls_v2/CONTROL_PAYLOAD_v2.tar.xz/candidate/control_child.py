"""Future child control capture around actual production CLI function."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--arm", choices=("original", "native_owner"), required=True)
    args = parser.parse_args()
    import production_cli
    production_cli.activate_paths(args.runtime)
    from abides_core import abides
    import numpy as np
    from control_graph import snapshot
    original_run = abides.run
    def captured(config):
        end_state = original_run(config)
        state = snapshot(end_state, np)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        (args.out.parent / "STATE.json").write_text(json.dumps(state, ensure_ascii=True, indent=2) + "\n")
        return end_state
    abides.run = captured
    try:
        result = production_cli.simulate(args.config, args.out, args.build, args.runtime, args.arm, production_cli.ENTRY_STARTED)
        print(json.dumps(result))
    finally:
        abides.run = original_run


if __name__ == "__main__":
    main()
