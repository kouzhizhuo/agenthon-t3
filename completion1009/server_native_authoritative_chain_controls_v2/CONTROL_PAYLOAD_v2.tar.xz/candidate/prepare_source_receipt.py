"""Freeze fresh V2 source-only repair; never compile native or run participants."""
from pathlib import Path
import ast,hashlib,json
HERE=Path(__file__).resolve().parent
TARGET=HERE/"SOURCE_PREPARATION_RECEIPT_v1.json"
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    if TARGET.exists(): raise ValueError("fresh receipt required")
    report=json.loads((HERE/"CDEF_OPTIONAL_CALL_REPAIR_v1.json").read_bytes())
    if report["unresolved"] or sha(HERE/"authoritative_chain.pyx")!=report["v2_pyx_sha256"]: raise ValueError("finite repair binding differs")
    review=json.loads((HERE/"INDEPENDENT_V2_OPTIONAL_CALL_REPAIR_REVIEW_v1.json").read_bytes())
    if review.get("status") != "PASS_SOURCE_ONLY" or review.get("full_normalized_V1_V2_effective_argument_AST_equal") is not True or review.get("all_V2_optional_calls_complete_positional") is not True or review.get("unresolved_source_blockers") != []: raise ValueError("independent finite source review required")
    paths=[p for p in sorted(HERE.rglob("*")) if p.is_file() and not any(x.startswith("._") or x=="__pycache__" for x in p.parts) and not p.name.startswith("SOURCE_PREPARATION_RECEIPT_")]
    python=[]
    for p in paths:
        if p.suffix==".py": ast.parse(p.read_bytes());compile(p.read_bytes(),str(p),"exec",dont_inherit=True);python.append(p.relative_to(HERE).as_posix())
    transcription=json.loads((HERE/"TRANSCRIPTION_v1.json").read_bytes())
    transcription.update(unfrozen=False,frozen_build_input=True)
    (HERE/"TRANSCRIPTION_v1.json").write_text(json.dumps(transcription,indent=2,sort_keys=True)+"\n")
    receipt={"schema":"t3-authoritative-chain-v2-frozen-source-preparation-v1","executive_summary":"Fresh V2 repairs the actual V1 Cython keyword-default omission by explicitly supplying every finite optional cdef argument. Independent source review confirms effective-argument/body equality and complete optional call closure. This is a frozen build input, not proof of Cython compilation, runtime outputs, speed or rank.","source_only":True,"unfrozen":False,"frozen_build_input":True,"source_pass":False,"runtime_pass":False,"participant_imported":False,"native_build_executed":False,"market_executed":False,"speed_claim":False,"python_AST_compile_checked":python,"selected_business_bodies":118,"runtime_pins_checked":64,"static_typed_source_closure":json.loads((HERE/"SOURCE_STATIC_CHECK_v1.json").read_bytes())["closure"],"all_optional_cdef_calls":report["all_optional_cdef_calls"],"rewritten_optional_calls":report["rewritten_optional_calls"],"supersedes":{"path":str(HERE.with_name("native_authoritative_chain_v1")/"SOURCE_PREPARATION_RECEIPT_v3.json"),"sha256":report["baseline_receipt_sha256"],"reason":"actual Linux Cython missing append_summary_log at V1 pyx1391"},"independent_review_sha256":sha(HERE/"INDEPENDENT_V2_OPTIONAL_CALL_REPAIR_REVIEW_v1.json"),"files":[{"path":p.relative_to(HERE).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)} for p in paths],"remaining":["actual Linux Cython compile","original/native/native real JSON complete output/state/RNG/identity controls","measured throughput"]}
    TARGET.write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"path":str(TARGET),"bytes":TARGET.stat().st_size,"sha256":sha(TARGET),"candidate_files":len(paths)}))
if __name__=="__main__":main()
