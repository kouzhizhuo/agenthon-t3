"""Source-closed primitive output observer; no market callbacks are bypassed."""
from types import SimpleNamespace

STATE = None
ORDER_TYPES = frozenset(("ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_EXECUTED",
                         "ORDER_CANCELLED", "ORDER_REPLACED"))
FIELDS = ("ScalarEventValue", "agent_id", "order_id", "side", "quantity",
          "limit_price", "fill_price", "EventTime", "EventType")
ORDER_FIELDS = ("agent_id", "order_id", "side", "quantity", "limit_price", "fill_price")
STRATEGIES = frozenset(("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"))


class Episode:
    def __init__(self):
        self.inference = {}
        self.contract = {}
        self.has_scalar = False
        self.order_rows = 0
        self.quote_rows = 0
        self.private_rows = 0
        self.termination_frames_avoided = 0
        self.range_replays = 0

    def append(self, agent, record, canonical=False, scalar=False):
        self.inference.setdefault(agent, []).append(record)
        if canonical:
            self.contract.setdefault(agent, []).append(record)
        self.has_scalar |= scalar


def begin_episode(scenario, authenticated=True):
    """Decide the whole episode before reset/config/agent construction.

    Static source and actual imported domain bindings are authenticated by the
    CLI/worker. JSON cannot supply callbacks, order flags or custom payloads.
    Numeric ranges are deliberately unrestricted: complete projected inference
    records permit exact frozen pandas replay without abandoning old rows.
    """
    global STATE
    admitted = (authenticated and type(scenario) is dict
        and type(scenario.get("agent_configs")) is list
        and bool(scenario["agent_configs"])
        and all(type(item) is dict and type(item.get("agent_type")) is str
                and item["agent_type"] in STRATEGIES
                and type(item.get("count")) is int and item["count"] >= 0
                for item in scenario["agent_configs"]))
    STATE = Episode() if admitted else None
    return admitted


def finish_episode():
    global STATE
    STATE = None


def record_log(agent, event_type, event, append_summary_log, deepcopy_event):
    """Record every original row's projected inference fields, then narrow logs.

    Summary rows and AGENT_TYPE retain the original logging/copy/alias path.
    Other ordinary scalar diagnostics affect only presence/dtype of the scalar
    column. Fixed CLI AGENT_TYPE is a nonempty string on every agent; therefore
    list/message diagnostics can use a string witness in that object column.
    No diagnostic has a reserved override or an order field in the frozen CLI.
    """
    if STATE is None:
        return False
    if not agent.log_events:
        return True
    scalar = False
    if event is None:
        payload = None
    elif type(event) is dict:
        payload = {key: event[key] for key in FIELDS if key in event}
        scalar = "ScalarEventValue" in event
    elif type(event) in (str, int, float, bool):
        payload, scalar = event, True
    else:
        # Source-authenticated depth lists/query messages carry no relevant
        # numeric fields. They are private diagnostics, never output payloads.
        payload, scalar = "", True
    record = (agent.current_time, event_type, "raw", payload)
    canonical = event_type in ORDER_TYPES or event_type in ("BEST_BID", "BEST_ASK")
    STATE.append(agent, record, canonical, scalar)
    if append_summary_log or event_type == "AGENT_TYPE":
        return False
    STATE.private_rows += not canonical
    return True


def order(agent, event_type, value, deepcopy_event=True):
    if STATE is None:
        return agent.logEvent(event_type, value.to_dict(), deepcopy_event=deepcopy_event)
    if not agent.log_events:
        return
    # Pinned deepcopy/to_dict reconstructs only declared Order fields; the
    # projected parser discards symbol/time_placed/tag/flags in every row.
    fields = (value.agent_id, value.order_id, value.side, value.quantity,
              getattr(value, "limit_price", None), value.fill_price)
    record = (agent.current_time, event_type, "order" if hasattr(value, "limit_price") else "market", fields)
    canonical = event_type in ORDER_TYPES
    STATE.append(agent, record, canonical)
    STATE.order_rows += canonical
    STATE.private_rows += not canonical



def diagnostic(agent, event_type, event):
    """Retain the frozen list/message inference row without diagnostic copying.

    The two depth lists and fixed non-order messages have no reserved numeric
    fields. Keep the original per-agent row position and the same object-column
    scalar witness as record_log; never drop the row during numeric replay.
    Unsupported/inactive episodes execute the original diagnostic call.
    """
    if STATE is None:
        return agent.logEvent(event_type, event)
    if not agent.log_events:
        return
    STATE.append(agent, (agent.current_time, event_type, "raw", ""), False, True)
    STATE.private_rows += 1


def imbalance(agent, bids, asks):
    """Keep the original IMBALANCE inference row without unused sum/list work."""
    if STATE is None:
        return agent.logEvent('IMBALANCE', [sum([x[1] for x in bids]), sum([x[1] for x in asks])])
    return diagnostic(agent, 'IMBALANCE', None)


def quote(agent, event_type, symbol, price, quantity):
    if STATE is None:
        return agent.logEvent(event_type, "{},{},{}".format(symbol, price, quantity))
    if not agent.log_events:
        return
    record = (agent.current_time, event_type, "quote", (symbol, price, quantity))
    STATE.append(agent, record, True, True)
    STATE.quote_rows += 1


def skip_termination(agent):
    # The authenticated CLI uses Kernel(skip_log=True). Custom writers/episodes
    # are refused before construction and take the entire original path.
    if STATE is not None and agent.kernel is not None and agent.kernel.skip_log is True:
        STATE.termination_frames_avoided += 1
        return True
    return False


def _payload(record):
    timestamp, event_type, kind, data = record
    if kind in ("order", "market"):
        data = dict(zip(ORDER_FIELDS, data))
        if kind == "market": del data["limit_price"]
    elif kind == "quote":
        data = "{},{},{}".format(*data)
    return timestamp, event_type, data


def replay_state(end_state):
    """Recreate every row/index and raw numeric inference input on demand."""
    return {"agents": [SimpleNamespace(id=agent.id,
        log=[_payload(record) for record in STATE.inference.get(agent, ())])
        for agent in end_state["agents"]]}


def extract_trace(end_state, original, columns, dtypes, side_to_str):
    if STATE is None:
        return original(end_state)
    import numpy as np
    import pandas as pd
    from abides_markets.orders import Side
    integer_types = (int, np.int64, np.int32)
    def exact_integer(value):
        return type(value) in integer_types and -(1 << 53) <= value <= (1 << 53)
    def replay():
        STATE.range_replays += 1
        return original(replay_state(end_state))
    events, quotes, final_exec = [], {}, {}
    for agent in end_state["agents"]:
        for record in STATE.contract.get(agent, ()):
            timestamp, event_type, kind, data = record
            if isinstance(timestamp, (int, np.int64)) and not -(1 << 63) <= timestamp < (1 << 63):
                return replay()
            if not isinstance(timestamp, (int, np.int64)):
                timestamp = 0
            if kind == "raw":
                # Direct/custom log fixtures retain original field semantics;
                # producer records in the actual four-strategy CLI are typed.
                return replay()
            if kind in ("order", "market"):
                aid, oid, side, quantity, limit_price, fill_price = data
                if oid is None:
                    continue
                if aid is None:
                    aid = agent.id
                price = fill_price if event_type == "ORDER_EXECUTED" else limit_price
                if (not exact_integer(oid) or not exact_integer(aid)
                        or not -(1 << 31) <= aid < (1 << 31)
                        or not exact_integer(quantity)
                        or (price is not None and not exact_integer(price))
                        or type(side) not in (Side, str, type(None))):
                    return replay()
                events.append([int(timestamp), int(aid), event_type, side_to_str(side),
                               0 if price is None else int(price), int(quantity), int(oid)])
            else:
                symbol, price, quantity = data
                # Match the original comma parser, including malformed symbol
                # strings and integer display; source ticker is always ABM.
                if (type(symbol) is not str or "," in symbol
                        or not exact_integer(price) or not exact_integer(quantity)
                        or not exact_integer(agent.id) or not -(1 << 31) <= agent.id < (1 << 31)):
                    return replay()
                side = "BID" if event_type == "BEST_BID" else "ASK"
                timestamp = int(timestamp)
                quotes[(timestamp, side)] = [timestamp, int(agent.id), "QUOTE_UPDATE", side,
                                             int(price), int(quantity), -1]
    if not events or not STATE.has_scalar:
        return replay()
    # Agent iteration and per-agent producer order are the original raw tie
    # index. Sorting only time here preserves it exactly for final-fill lookup.
    events.sort(key=lambda row: row[0])
    for index, row in enumerate(events):
        if row[2] == "ORDER_EXECUTED":
            final_exec[row[6]] = index
    for index, row in enumerate(events):
        if row[2] == "ORDER_EXECUTED":
            row[2] = "ORDER_FILLED" if final_exec[row[6]] == index else "PARTIAL_FILL"
    events.extend(quotes.values())
    events.sort(key=lambda row: (row[0], row[6]))
    materialized = {}
    for index, name in enumerate(columns):
        dtype = dtypes[name]
        if dtype in ("int64", "int32"):
            materialized[name] = np.fromiter((row[index] for row in events), dtype=dtype, count=len(events))
        else:
            materialized[name] = pd.array([row[index] for row in events], dtype="string")
    return pd.DataFrame(materialized, columns=columns)
