"""Install the source-closed canonical event engine for one serial simulation.

The event queue and ledger use the unchanged V8 source. ABIDES still constructs
the same agents, initializes them in the same order, and terminates them through
the incumbent Kernel methods. No event, callback, or random draw is skipped.
"""
from contextlib import contextmanager
import heapq


class HeapQueue:
    """Single-thread heap preserving PriorityQueue's entire tuple comparison key."""
    def __init__(self):
        self.queue = []

    def put(self, item, block=True, timeout=None):
        heapq.heappush(self.queue, item)

    def get(self, block=True, timeout=None):
        return heapq.heappop(self.queue)

    def empty(self):
        return not self.queue

    def qsize(self):
        return len(self.queue)


def scalar_latency(self, sender_id, recipient_id):
    if sender_id == recipient_id:
        return 0
    if self._model == "log_normal":
        value = self.random_state.lognormal(mean=self._mu, sigma=self._sigma)
    elif self._model == "uniform":
        value = self.random_state.uniform(self._min_ns, self._max_ns)
    elif self._model == "pareto":
        base = self._min_ns if self._min_ns > 0 else 1.0
        value = base * (1.0 + self.random_state.pareto(self._alpha))
    else:
        value = self._mean_ns
    # No reduction/reassociation: same scalar draw, bounds, Python float and round.
    if value < self._min_ns:
        value = self._min_ns
    if value > self._max_ns:
        value = self._max_ns
    return int(round(float(value)))


@contextmanager
def enabled(active=True):
    """Yield the matching ledger extractor and restore bindings on every exit.

The CLI and batch driver are deliberately serial: ABIDES has process-global
random-state and ID counters. An installed native t3_canonical_engine extension
uses this same entry point; otherwise Python imports its exact source fallback.
"""
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_fork import trace
    from abides_fork.config import ScenarioLatencyModel

    if not active:
        yield trace.extract_message_trace
        return
    from column_trace import make_extractor
    try:
        import t3_canonical_engine as engine
    except ImportError:
        # An unavailable or incompatible native artifact must not forfeit a unit.
        # The original kernel and dict-ledger extractor remain a coherent pair.
        yield trace.extract_message_trace
        return

    if (getattr(engine, "IncumbentKernel", None) is not Kernel
            or not isinstance(getattr(engine, "CanonicalKernel", None), type)
            or not issubclass(engine.CanonicalKernel, Kernel)
            or not isinstance(getattr(engine, "ColumnLedger", None), type)):
        yield trace.extract_message_trace
        return
    extractor = make_extractor(engine.ColumnLedger, trace.extract_message_trace,
                               trace.MESSAGE_TRACE_COLUMNS, trace._MSG_DTYPES)
    old_kernel, old_latency = abides.Kernel, ScenarioLatencyModel.get_latency
    abides.Kernel = engine.CanonicalKernel
    ScenarioLatencyModel.get_latency = scalar_latency
    try:
        yield extractor
    finally:
        abides.Kernel = old_kernel
        ScenarioLatencyModel.get_latency = old_latency
