"""Cache exact source expectations; recheck actual loaded domain every episode."""
from pathlib import Path
import ast
import abc
import hashlib
import types

# Frozen image source pins are additive to the packaging manifest. No source
# outside this closed relative-path set can supply cached expectations.
_SOURCE_PINS = (('vendor/abides/abides-core/abides_core/agent.py', '56b9e4c50f3448473037ca9a0a0b3ac57ba3b005e9ab4e87b781d39b099f310a'), ('vendor/abides/abides-core/abides_core/kernel.py', 'f4fab71d846c6ba5157addb0cb96fad07c26b60b0e05f34d58fb2e6347e00583'), ('vendor/abides/abides-core/abides_core/message.py', 'c1ddc0f0962d68e8d6750fb00210a2676d7bbdd2dd7f3b021e9fa94287901e48'), ('vendor/abides/abides-markets/abides_markets/orders.py', '50a3c460ca4acd2d98bd08d0637971c9d4652bc9591655fb3634ffc05eb0be0e'), ('vendor/abides/abides-markets/abides_markets/order_book.py', 'b6215683522cdf0e606f226566a55159a245b8cf4cf889eea28a323831be6aae'), ('vendor/abides/abides-markets/abides_markets/price_level.py', 'd448ccf12f49c8078994c6d1d2ca150bfed169dbfa393fcfd4d8bc7e4eb9c1b1'), ('vendor/abides/abides-markets/abides_markets/utils/__init__.py', 'd565f720ea9df373368ba7e38e025c438282f9b3d79928d50d5be59e3e4a3980'), ('vendor/abides/abides-markets/abides_markets/agents/trading_agent.py', '0293867728c4f033e7bed62a1d90d2ceea1543bb86544be257cac4b3f5102d2d'), ('vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py', 'b9a7419cddcf5a92b48bdd2b2536d1d744c1a8f011ed0db2d7833b2dd17f4e33'), ('abides_fork/agents.py', 'f4521ce1e9d0093761df7b92e996e63a879ce909b42d158a03458eef552c636a'), ('abides_fork/config.py', 'a207bc8d5cb48be18cd0b172f182fe37ef50d705f622eae963773b114ea52008'), ('abides_fork/trace.py', '9975fd02d94555f78974eaf0fd355f4f315a38ff12ec4666fc2c52df9b33dc72'), ('observer.py', '98ebe546b9a7d3c3a5066b15512e6b763d16de89fd795632b04efa5a2ccf9556'))
_SOURCE_CACHE = {}
_CACHE_RECEIPTS = {}
_CLASS_EXPORTS = {}
_CACHE_COMPILES = 0
_CACHE_AST_PARSES = 0
CACHE_VERSION = 1


def _source_image(module, images):
    """Read/hash exact image bytes per admission; compile/parse once per digest."""
    global _CACHE_COMPILES, _CACHE_AST_PARSES
    path = Path(module.__file__).resolve()
    import observer
    runtime = Path(observer.__file__).resolve().parent
    relative = str(path.relative_to(runtime))
    expected = dict(_SOURCE_PINS).get(relative)
    if expected is None or path != runtime / relative:
        raise ValueError("unsupported source image path")
    if path in images:
        return images[path]
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != expected:
        raise ValueError("source bytes differ from frozen image: " + relative)
    key = (path, digest)
    image = _SOURCE_CACHE.get(key)
    if image is None:
        if key in _CACHE_RECEIPTS:
            raise ValueError("expected source cache entry disappeared")
        code = compile(data, str(path), "exec", dont_inherit=True)
        tree = ast.parse(data)
        image = {"code": code, "tree": tree, "functions": {}, "defaults": {}}
        _SOURCE_CACHE[key] = image
        _CACHE_RECEIPTS[key] = image
        _CACHE_COMPILES += 1
        _CACHE_AST_PARSES += 1
    if (_CACHE_RECEIPTS.get(key) is not image or type(image) is not dict
            or set(image) != {"code", "tree", "functions", "defaults"}
            or type(image["code"]) is not types.CodeType
            or type(image["tree"]) is not ast.Module
            or type(image["functions"]) is not dict or type(image["defaults"]) is not dict):
        raise ValueError("malformed or replaced source cache entry")
    images[path] = image
    return image


def _code_at(module, class_name, method_name, compiled, first=False):
    image = _source_image(module, compiled)
    key = (class_name, method_name, first)
    if key not in image["functions"]:
        code = image["code"]
        if class_name:
            code = next(c for c in code.co_consts if type(c) is types.CodeType and c.co_name == class_name)
        matches = [c for c in code.co_consts if type(c) is types.CodeType and c.co_name == method_name]
        image["functions"][key] = matches[0] if first else matches[-1]
    return image["functions"][key]


def _defaults_match(function, module, class_name, name, parsed, first=False):
    image = _source_image(module, parsed)
    key = (class_name, name, first)
    if key not in image["defaults"]:
        nodes = image["tree"].body
        if class_name:
            nodes = next(node.body for node in nodes if isinstance(node, ast.ClassDef) and node.name == class_name)
        matches = [node for node in nodes if isinstance(node, ast.FunctionDef) and node.name == name]
        node = matches[0] if first else matches[-1]
        def descriptor(value):
            if (isinstance(value, ast.Attribute) and value.attr == "maxsize"
                    and isinstance(value.value, ast.Name) and value.value.id == "sys"):
                return ("sys.maxsize", None)
            return ("literal", ast.literal_eval(value))
        positional = tuple(descriptor(value) for value in node.args.defaults)
        keywords = tuple((argument.arg, descriptor(value)) for argument, value in zip(node.args.kwonlyargs, node.args.kw_defaults) if value is not None)
        image["defaults"][key] = positional, keywords
    positional, keywords = image["defaults"][key]
    def current_value(value):
        kind, expected = value
        if kind == "sys.maxsize":
            import sys
            if vars(module).get("sys") is not sys:
                raise ValueError("sys.maxsize default has modified owning binding")
            return sys.maxsize
        return expected
    expected_positional = tuple(current_value(value) for value in positional) or None
    expected_keywords = {name: current_value(value) for name, value in keywords} or None
    return function.__defaults__ == expected_positional and function.__kwdefaults__ == expected_keywords


def authenticate_loaded():
    """Return False for an unsupported loaded domain before any agents exist.

    The shipped snapshot is manifest-verified during preparation and packaging.
    This check authenticates producer code, inherited logging/constructors and
    all four mappings as actually imported; no hot-loop checks are installed.
    """
    from abides_core import agent, kernel, message, latency_model
    from abides_markets import orders, order_book, price_level
    import abides_markets.utils as utils
    from abides_markets.agents import trading_agent, exchange_agent
    from abides_fork import agents, config, trace
    import observer
    runtime = Path(observer.__file__).resolve().parent
    checks = (
        (agent, "vendor/abides/abides-core/abides_core/agent.py", "Agent", ("__init__", "logEvent", "kernel_terminating", "write_log")),
        (kernel, "vendor/abides/abides-core/abides_core/kernel.py", "Kernel", ("write_log", "append_summary_log")),
        (orders, "vendor/abides/abides-markets/abides_markets/orders.py", "Order", ("__init__", "to_dict")),
        (orders, "vendor/abides/abides-markets/abides_markets/orders.py", "LimitOrder", ("__init__", "__deepcopy__")),
        (trading_agent, "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py", "TradingAgent", (
            "__init__", "create_limit_order", "place_limit_order", "place_market_order", "place_multiple_orders", "cancel_order", "partial_cancel_order", "modify_order", "replace_order", "order_executed", "order_accepted", "order_cancelled", "order_partial_cancelled", "order_modified", "order_replaced", "kernel_starting", "kernel_stopping", "query_spread")),
        (exchange_agent, "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py", "ExchangeAgent", ("__init__", "receive_message", "send_message", "kernel_terminating", "analyse_order_book", "get_time_dropout", "_original_time_dropout")),
        (order_book, "vendor/abides/abides-markets/abides_markets/order_book.py", "OrderBook", ("handle_limit_order", "execute_order", "enter_order", "append_book_log2", "get_l2_bid_data", "get_l2_ask_data", "get_l3_bid_data", "get_l3_ask_data")),
        (price_level, "vendor/abides/abides-markets/abides_markets/price_level.py", "PriceLevel", ("__init__", "add_order", "total_quantity")),
        (message, "vendor/abides/abides-core/abides_core/message.py", "Message", ("type",)),
        (utils, "vendor/abides/abides-markets/abides_markets/utils/__init__.py", None, ("generate_uniform_random_pairwise_dist_on_line", "generate_latency_model", "meters_to_light_ns", "__getattr__")),
        (config, "abides_fork/config.py", None, ("build_config", "_agent_kwargs")),
        (agents, "abides_fork/agents.py", "ScheduledAgent", ("__init__", "wakeup", "receive_message", "kernel_starting")),
        (trace, "abides_fork/trace.py", None, ("extract_trace", "_parse_trace_logs", "_canonical_trace")),
    )
    try:
        compiled = parsed = {}
        class_exports = {}
        for module, relative, class_name, names in checks:
            if Path(module.__file__).resolve() != runtime / relative:
                return False
            cls = getattr(module, class_name) if class_name else module
            if class_name:
                key = (Path(module.__file__).resolve(), class_name)
                expected_meta = abc.ABCMeta if module is orders and class_name in ("Order", "LimitOrder") else type
                if (type(cls) is not expected_meta or cls.__module__ != module.__name__
                        or (key in _CLASS_EXPORTS and _CLASS_EXPORTS[key] is not cls)):
                    return False
                if expected_meta is abc.ABCMeta and orders.ABC is not abc.ABC:
                    return False
                class_exports[key] = cls
            for name in names:
                function = getattr(cls, name)
                if isinstance(function, property): function = function.fget
                if type(function) is not types.FunctionType or function.__code__ != _code_at(module, class_name, name, compiled):
                    return False
                if (function.__globals__ is not vars(module)
                        or Path(function.__globals__["__file__"]).resolve() != runtime / relative
                        or not _defaults_match(function, module, class_name, name, parsed)):
                    return False
        for name in observer.STRATEGIES:
            cls = getattr(agents, name)
            key = (Path(agents.__file__).resolve(), name)
            if (type(cls) is not type or cls.__module__ != agents.__name__
                    or (key in _CLASS_EXPORTS and _CLASS_EXPORTS[key] is not cls)):
                return False
            class_exports[key] = cls
            if cls.act.__code__ != _code_at(agents, name, "act", compiled):
                return False
            if cls.__init__.__code__ != _code_at(agents, name, "__init__", compiled):
                return False
            if (cls.act.__globals__ is not vars(agents) or cls.__init__.__globals__ is not vars(agents)
                    or not _defaults_match(cls.act, agents, name, "act", parsed)
                    or not _defaults_match(cls.__init__, agents, name, "__init__", parsed)):
                return False
        if agents.AGENT_REGISTRY != {name: getattr(agents, name) for name in observer.STRATEGIES}:
            return False
        if config.AGENT_REGISTRY is not agents.AGENT_REGISTRY:
            return False
        if (config.ExchangeAgent is not exchange_agent.ExchangeAgent
                or agents.TradingAgent is not trading_agent.TradingAgent
                or trading_agent.LimitOrder is not orders.LimitOrder
                or trading_agent.Side is not orders.Side
                or exchange_agent.OrderBook is not order_book.OrderBook):
            return False
        # Combined witness producers and unchanged metric consumers share the
        # actual loaded globals/identities. Lazy import keeps SciPy unloaded
        # until needed; any already-loaded public function must be its SciPy
        # binding. No import is forced merely to perform admission.
        import sys
        import numpy as np
        import pandas as pd
        if (order_book.PriceLevel is not price_level.PriceLevel
                or price_level.LimitOrder is not orders.LimitOrder
                or price_level.Side is not orders.Side
                or config.generate_latency_model is not utils.generate_latency_model
                or utils.LatencyModel is not latency_model.LatencyModel
                or utils.np is not np or utils.pd is not pd
                or order_book.np is not np or exchange_agent.np is not np
                or exchange_agent.pd is not pd):
            return False
        for name in ("pdist", "squareform"):
            if name in vars(utils):
                distance = sys.modules.get("scipy.spatial.distance")
                if distance is None or vars(utils)[name] is not getattr(distance, name, None):
                    return False
        if any(getattr(module, "_observer", None) is not observer
               for module in (agent, trading_agent, exchange_agent, order_book)):
            return False
        for name in ("begin_episode", "finish_episode", "record_log", "order", "quote",
                     "skip_termination", "_payload", "replay_state", "extract_trace", "diagnostic", "imbalance"):
            function = getattr(observer, name)
            if (function.__code__ != _code_at(observer, None, name, compiled)
                    or function.__globals__ is not vars(observer)
                    or not _defaults_match(function, observer, None, name, parsed)):
                return False
        for name in ("__init__", "append"):
            function = getattr(observer.Episode, name)
            if (function.__code__ != _code_at(observer, "Episode", name, compiled)
                    or function.__globals__ is not vars(observer)
                    or not _defaults_match(function, observer, "Episode", name, parsed)):
                return False
        key = (Path(observer.__file__).resolve(), "Episode")
        if (type(observer.Episode) is not type or observer.Episode.__module__ != observer.__name__
                or (key in _CLASS_EXPORTS and _CLASS_EXPORTS[key] is not observer.Episode)):
            return False
        class_exports[key] = observer.Episode
        fallback = trace._extract_trace_observer_original
        if type(fallback) is not types.FunctionType or fallback.__code__ != _code_at(trace, None, "extract_trace", compiled, first=True):
            return False
        if fallback.__globals__ is not vars(trace) or not _defaults_match(fallback, trace, None, "extract_trace", parsed, first=True):
            return False
        if (trace._side_to_str.__code__ != _code_at(trace, None, "_side_to_str", compiled)
                or trace._side_to_str.__globals__ is not vars(trace)
                or trace.Side is not orders.Side):
            return False
        if (observer.ORDER_FIELDS != ("agent_id", "order_id", "side", "quantity", "limit_price", "fill_price")
                or observer.FIELDS != ("ScalarEventValue", "agent_id", "order_id", "side", "quantity", "limit_price", "fill_price", "EventTime", "EventType")
                or observer.STRATEGIES != frozenset(("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"))
                or observer.ORDER_TYPES != frozenset(("ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_EXECUTED", "ORDER_CANCELLED", "ORDER_REPLACED"))):
            return False
        columns = ["t_ns", "agent_id", "msg_type", "side", "price", "size", "order_id"]
        dtypes = {"t_ns": "int64", "agent_id": "int32", "msg_type": "string", "side": "string", "price": "int64", "size": "int64", "order_id": "int64"}
        if (trace.TRACE_COLUMNS != columns or trace._TRACE_DTYPES != dtypes
                or trace._ORDER_EVENT_MAP != {name: name for name in observer.ORDER_TYPES if name != "ORDER_EXECUTED"}):
            return False
        # Plain field defaults are a separate witness from bytecode equality.
        if trading_agent.TradingAgent.place_limit_order.__defaults__ != (None, False, False, False, False, True, None):
            return False
        if orders.LimitOrder.__init__.__defaults__ != (False, False, False, False, None, None):
            return False
        _CLASS_EXPORTS.update(class_exports)
        return True
    except (AttributeError, KeyError, IndexError, StopIteration, TypeError, ValueError, OSError, SyntaxError):
        return False
