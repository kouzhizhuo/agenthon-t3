"""Load this submission's source; dependencies come from its installed environment."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def activate() -> None:
    paths = [ROOT,
             ROOT / "vendor/abides/abides-core",
             ROOT / "vendor/abides/abides-markets"]
    for path in reversed(paths):
        if path.exists():
            location = str(path)
            while location in sys.path:
                sys.path.remove(location)
            sys.path.insert(0, location)
