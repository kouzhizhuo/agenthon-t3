"""Compile this source as t3_canonical_engine. No fixed-width event arithmetic or RNG changes."""
import heapq
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from abides_core import NanosecondTime
from abides_core.agent import Agent
from abides_core.kernel import Kernel as IncumbentKernel, logger, fmt_ts
from abides_core.message import Message, MessageBatch, WakeupMsg


class FlatHeap:
    def __init__(self):
        self.queue = []

    def empty(self):
        return not self.queue

    def qsize(self):
        return len(self.queue)


class ColumnLedger:
    """Nine append-only object columns: exact integers/None and snapshot string values."""
    def __init__(self):
        self.columns = tuple([] for _ in range(9))

    def __len__(self):
        return len(self.columns[0])

    def append_values(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                      latency_ns, msg_type, order_id, causal_parent):
        columns = self.columns
        columns[0].append(message_id)
        columns[1].append(src_id)
        columns[2].append(dst_id)
        columns[3].append(t_send_ns)
        columns[4].append(t_recv_ns)
        columns[5].append(latency_ns)
        columns[6].append(msg_type)
        columns[7].append(order_id)
        columns[8].append(causal_parent)


class CanonicalKernel(IncumbentKernel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.messages = FlatHeap()
        self._msg_ledger = ColumnLedger()

    def runner(self, agent_actions: Optional[Tuple[Agent, List[Dict[str, Any]]]]=None) -> Dict[str, Any]:
        """
        Start the simulation and processing of the message queue.
        Possibility to add the optional argument agent_actions. It is a list of dictionaries corresponding
        to actions to be performed by the experimental agent (Gym Agent).

        Arguments:
            agent_actions: A list of the different actions to be performed represented in a dictionary per action.

        Returns:
          - it is a dictionnary composed of two elements:
            - "done": boolean True if the simulation is done, else False. It is true when simulation reaches end_time or when the message queue is empty.
            - "results": it is the raw_state returned by the gym experimental agent, contains data that will be formated in the gym environement to formulate state, reward, info etc.. If
               there is no gym experimental agent, then it is None.
        """
        if agent_actions is not None:
            exp_agent, action_list = agent_actions
            exp_agent.apply_actions(action_list)
        while not self.messages.empty() and self.current_time and (self.current_time <= self.stop_time):
            self.current_time, sender_id, recipient_id, message = heapq.heappop(self.messages.queue)
            assert self.current_time is not None
            if self.ttl_messages % 100000 == 0:
                if logger.isEnabledFor(20):
                    logger.info('--- Simulation time: {}, messages processed: {:,}, wallclock elapsed: {:.2f}s ---'.format(fmt_ts(self.current_time), self.ttl_messages, (datetime.now() - self.event_queue_wall_clock_start).total_seconds()))
            if self.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('--- Kernel Event Queue pop ---')
                if logger.isEnabledFor(10):
                    logger.debug('Kernel handling {} message for agent {} at time {}'.format(message.type(), recipient_id, self.current_time))
            self.ttl_messages += 1
            self.current_agent_additional_delay = 0
            if isinstance(message, WakeupMsg):
                if self.agent_current_times[recipient_id] > self.current_time:
                    heapq.heappush(self.messages.queue, (self.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if self.show_trace_messages:
                        if logger.isEnabledFor(10):
                            logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(self.current_time), fmt_ts(self.agent_current_times[recipient_id])))
                    continue
                self.agent_current_times[recipient_id] = self.current_time
                self._current_causal_uid = message.message_id
                self._deliver_seq_by_key[message.message_id, recipient_id] = self._deliver_seq
                self._deliver_seq += 1
                self._msg_ledger.append_values(message.message_id, recipient_id, recipient_id, None, self.current_time, 0, 'AGENT_WAKEUP', None, None)
                wakeup_result = self.agents[recipient_id].wakeup(self.current_time)
                self.agent_current_times[recipient_id] += self.agent_computation_delays[recipient_id] + self.current_agent_additional_delay
                if self.show_trace_messages:
                    if logger.isEnabledFor(10):
                        logger.debug('After wakeup return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(self.current_time), fmt_ts(self.agent_current_times[recipient_id])))
                if wakeup_result != None:
                    return {'done': False, 'result': wakeup_result}
            else:
                if self.agent_current_times[recipient_id] > self.current_time:
                    heapq.heappush(self.messages.queue, (self.agent_current_times[recipient_id], sender_id, recipient_id, message))
                    if self.show_trace_messages:
                        if logger.isEnabledFor(10):
                            logger.debug('Agent in future: message requeued for {}'.format(fmt_ts(self.agent_current_times[recipient_id])))
                    continue
                self.agent_current_times[recipient_id] = self.current_time
                if isinstance(message, MessageBatch):
                    messages = message.messages
                else:
                    messages = [message]
                for message in messages:
                    self.agent_current_times[recipient_id] += self.agent_computation_delays[recipient_id] + self.current_agent_additional_delay
                    if self.show_trace_messages:
                        if logger.isEnabledFor(10):
                            logger.debug('After receive_message return, agent {} delayed from {} to {}'.format(recipient_id, fmt_ts(self.current_time), fmt_ts(self.agent_current_times[recipient_id])))
                    self._current_causal_uid = message.message_id
                    self._deliver_seq_by_key[message.message_id, recipient_id] = self._deliver_seq
                    self._deliver_seq += 1
                    self.agents[recipient_id].receive_message(self.current_time, sender_id, message)
        if self.messages.empty():
            if logger.isEnabledFor(10):
                logger.debug('--- Kernel Event Queue empty ---')
        if self.current_time and self.current_time > self.stop_time:
            if logger.isEnabledFor(10):
                logger.debug('--- Kernel Stop Time surpassed ---')
        if len(self.gym_agents) > 0:
            self.gym_agents[0].update_raw_state()
            return {'done': True, 'result': self.gym_agents[0].get_raw_state()}
        else:
            return {'done': True, 'result': None}

    def send_message(self, sender_id: int, recipient_id: int, message: Message, delay: int=0) -> None:
        """
        Called by an agent to send a message to another agent.

        The kernel supplies its own current_time (i.e. "now") to prevent possible abuse
        by agents. The kernel will handle computational delay penalties and/or network
        latency.

        Arguments:
            sender_id: ID of the agent sending the message.
            recipient_id: ID of the agent receiving the message.
            message: The ``Message`` class instance to send.
            delay: Represents an agent's request for ADDITIONAL delay (beyond the
                Kernel's mandatory computation + latency delays). Represents parallel
                pipeline processing delays (that should delay the transmission of
                messages but do not make the agent "busy" and unable to respond to new
                messages)
        """
        sent_time = self.current_time + self.agent_computation_delays[sender_id] + self.current_agent_additional_delay + delay
        if self.agent_latency_model is not None:
            latency: float = self.agent_latency_model.get_latency(sender_id=sender_id, recipient_id=recipient_id)
            deliver_at = sent_time + int(latency)
            if self.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('Kernel applied latency {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, self.current_agent_additional_delay, delay, self.agents[sender_id].name, self.agents[recipient_id].name, fmt_ts(deliver_at)))
        else:
            latency = self.agent_latency[sender_id][recipient_id]
            noise = self.random_state.choice(len(self.latency_noise), p=self.latency_noise)
            deliver_at = sent_time + int(latency + noise)
            if self.show_trace_messages:
                if logger.isEnabledFor(10):
                    logger.debug('Kernel applied latency {}, noise {}, accumulated delay {}, one-time delay {} on send_message from: {} to {}, scheduled for {}'.format(latency, noise, self.current_agent_additional_delay, delay, self.agents[sender_id].name, self.agents[recipient_id].name, fmt_ts(deliver_at)))
        heapq.heappush(self.messages.queue, (deliver_at, sender_id, recipient_id, message))
        _ledger_msgs = message.messages if isinstance(message, MessageBatch) else [message]
        for _lm in _ledger_msgs:
            _ord = getattr(_lm, 'order', None)
            self._msg_ledger.append_values(_lm.message_id, sender_id, recipient_id, sent_time, deliver_at, deliver_at - sent_time, _lm.type(), getattr(_ord, 'order_id', None), self._current_causal_uid)
        if self.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('Sent time: {}, current time {}, computation delay {}'.format(sent_time, fmt_ts(self.current_time), self.agent_computation_delays[sender_id]))
            if logger.isEnabledFor(10):
                logger.debug('Message queued: {}'.format(message))

    def set_wakeup(self, sender_id: int, requested_time: Optional[NanosecondTime]=None) -> None:
        """
        Called by an agent to receive a "wakeup call" from the kernel at some requested
        future time.

        NOTE: The agent is responsible for maintaining any required state; the kernel
        will not supply any parameters to the ``wakeup()`` call.

        Arguments:
            sender_id: The ID of the agent making the call.
            requested_time: Defaults to the next possible timestamp.  Wakeup time cannot
            be the current time or a past time.
        """
        if requested_time is None:
            requested_time = self.current_time + 1
        if self.current_time and requested_time < self.current_time:
            raise ValueError('set_wakeup() called with requested time not in future', 'current_time:', self.current_time, 'requested_time:', requested_time)
        if self.show_trace_messages:
            if logger.isEnabledFor(10):
                logger.debug('Kernel adding wakeup for agent {} at time {}'.format(sender_id, fmt_ts(requested_time)))
        heapq.heappush(self.messages.queue, (requested_time, sender_id, sender_id, WakeupMsg()))
