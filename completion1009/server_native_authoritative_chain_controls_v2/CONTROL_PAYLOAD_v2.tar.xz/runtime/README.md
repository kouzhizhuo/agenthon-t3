This simulator reproduces the organizer-pinned ABIDES market and message traces while reducing event-queue and ledger overhead. It accepts scenario data at runtime and never loads stored answers. The production path uses the unchanged V8 canonical engine and column-ledger projection, with a Python source fallback when no native extension has been built.

The runtime exposes both official Track 3 verbs:

```sh
./simulate --config /input/scenario.json --out /output/trace.parquet
./simulate-batch --batch-dir /input/scenarios --out-dir /output
```

Single runs write `trace.parquet`, `message_trace.parquet`, and `events.json`. Batch runs write these files under each scenario filename stem and the required `batch_events.json` aggregate, including `n_scenarios`. Every sub-run resets global ABIDES IDs and seeds from that scenario before constructing its agents. The batch driver runs serially to preserve isolation.

`--mode optimized` is the default. It installs `CanonicalKernel` only for the current run, preserves the full lexicographic event priority, and projects the append-only message columns with the same delivered-message filtering and stable sequence order. `--mode baseline` keeps the source package's incumbent kernel and extractor for differential checks. Both modes suppress the upstream summary-log file, which is outside the allowed competition output tree. All bindings are restored even if simulation fails.

The canonical files are byte-identical to `research1009_guarded_canonical_event_engine_source_v8_cache`. Event times use Python object integers; agent callbacks, order matching, random draws, and trace ordering remain unchanged. This optimization supports the known scenario schema and the closed source shipped in this image; input validation rejects unfamiliar agent types before construction. An unavailable or incompatible native engine, or one bound to a different incumbent Kernel, falls back to the original kernel and dict-ledger extractor. Cython may compile the same canonical source for the final Linux image. Do not copy a macOS extension into that image. Install `requirements.txt` during image construction; the evaluated runtime has no network access. The upstream ABIDES license and organizer notices remain under `vendor/abides/` and `abides_fork/`.

CLI timing starts before simulator imports. A single run reports elapsed wall time from that entry marker through trace writing and hashing; the batch aggregate uses the same entry marker, while each sub-run measures its own execution. Direct library calls start timing within the called function. These self-reported fields use `time.perf_counter()` and serve consistency checks; organizer host wall time determines ranking.

For a minimal local check, install the pinned requirements in a suitable Python 3.11 environment, run the same public scenario in both modes, and compare both Parquet files exactly:

```sh
python agent.py simulate --config scenario.json --out /tmp/t3-baseline/trace.parquet --mode baseline
python agent.py simulate --config scenario.json --out /tmp/t3-optimized/trace.parquet --mode optimized
python - <<'PY'
from pathlib import Path
import pandas as pd
for name in ("trace.parquet", "message_trace.parquet"):
    baseline = Path("/tmp/t3-baseline") / name
    optimized = Path("/tmp/t3-optimized") / name
    pd.testing.assert_frame_equal(pd.read_parquet(baseline), pd.read_parquet(optimized), check_exact=True)
    assert baseline.read_bytes() == optimized.read_bytes(), name
print("Exact order and message traces match.")
PY
```

Also run every batch sub-scenario alone and compare its two Parquet files with the corresponding batch output. These local checks establish output equality for the tested inputs; official ranking requires the organizer's trusted timing and semantic gates on the final image.
