This candidate reduces cold output scalar conversion costs while preserving the audited NativeColumns simulator and its market behavior. It reads exact NumPy int64/int32 values through the pinned NumPy1.26.4 C API, and converts exact Python integers with overflow checking. It preserves scalar admission, range rejection, stable sorting, immutable output buffers and both official outputs. Performance and correctness remain unverified until the new Linux screen completes.

# Cold native projection scalar reads V2

Parent: cold_native_projection_buffers_v1_1, actual five-unit Linux mean24695.46EPS, not full71. Only cold_output_buffers.pxi, a new NumPy C header, build include paths, source-audit helpers and additive scalar controls change. Market pyx/pxd, runtime68, event/body/owner/RNG/heap/clock logic and production entry retain exact parent bytes. No stat-only hashes, no replay, no new runtime compilation.

Exact Python int, exact np.int64 and exact np.int32 retain the previous accepted signed ranges and optional53bit bound. bool is refused for numeric columns but permitted by original timestamp normalization. Unsupported/custom scalars must decline without __int__/comparison callbacks. Python values beyond signed64 return the original decline; no unchecked narrowing. np scalar reads require exact C API type binding before storage access; initialized against the pinned Linux LP64 ABI at extension import.

The existing serializer fixtures and six full-market controls remain required. Additive scalar cases cover signed boundaries, overflow, exact np types, and hostile subclasses. The extension is built on Linux only. Target232000 remains unmet; source preparation is not a runtime or speed result.
