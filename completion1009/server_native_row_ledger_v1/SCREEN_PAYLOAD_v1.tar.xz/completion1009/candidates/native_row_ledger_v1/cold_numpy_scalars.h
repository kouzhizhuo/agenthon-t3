#ifndef T3_COLD_NUMPY_SCALARS_H
#define T3_COLD_NUMPY_SCALARS_H
#include <Python.h>
#include <stdint.h>
#include <limits.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <numpy/arrayscalars.h>
#if NPY_SIZEOF_LONG != 8 || NPY_SIZEOF_INTP != 8
#error "T3 cold scalar reads require pinned LP64 NumPy ABI"
#endif
typedef char t3_cold_width_check[(sizeof(npy_int64)==8 && sizeof(npy_int32)==4 && sizeof(int64_t)==8) ? 1 : -1];
static int t3_cold_numpy_import(void) { return _import_array(); }
static PyObject *t3_cold_int64_type(void) { return (PyObject *)&PyInt64ArrType_Type; }
static PyObject *t3_cold_int32_type(void) { return (PyObject *)&PyInt32ArrType_Type; }
/* Callers establish exact C API scalar type before reading. */
static int64_t t3_cold_read_int64(PyObject *value) { return (int64_t)PyArrayScalar_VAL(value, Int64); }
static int64_t t3_cold_read_int32(PyObject *value) { return (int64_t)PyArrayScalar_VAL(value, Int32); }
#endif
