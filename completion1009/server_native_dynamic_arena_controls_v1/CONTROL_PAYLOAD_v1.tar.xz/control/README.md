# Dynamic arena one JSON build and correctness controls

This fresh wrapper freezes the complete mutable OrderArena, thirteen-kind MessageArena, native DeliveryHeap, traders, exchange, book and direct observer chain. The original configuration, NumPy RNG/oracle calls and both official output writers remain. It builds one dynamic_arena_chain extension in a separate 1 CPU / 8 GiB container, then mounts the exact ELF readonly for 4 CPU / 16 GiB original/native/native correctness runs. The temporary correctness directory is 64 MiB noexec. Both stages are serial, nonroot, offline, readonly-root and resource-bounded; cleanup and full source/build evidence are retained.

A native arm must actually select NativeOwnerKernel and commit its migration. The test retains full trace.parquet, message_trace.parquet, STATE.json, ARM_SELECTION.json and native ARENA_DIAGNOSTICS.json. Exact mapped alias/RNG/counter graph and output checks are independent from diagnostic counts. The independent source review is limited to one normal whole-episode ownership graph; public-arena independent destruction and exception cleanup remain unverified.

This is source-only preparation for a future Linux build and one finite JSON test. It establishes no runtime, throughput, official gate, submission, 230000 EPS or first-place result.
