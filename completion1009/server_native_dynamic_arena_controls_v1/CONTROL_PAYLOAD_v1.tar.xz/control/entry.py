"""Future separate build or correctness container entry; source-only preparation."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from common import CANDIDATE_RECEIPT, CANDIDATE_SHA256, inventory, safe_name, sha, verify_payload, write

ROOT = Path("/opt/authoritative-chain")
OUT = Path("/output")


def call(command, label, seconds):
    log = OUT / (label + ".log")
    result, failure = None, None
    with log.open("xb") as stream:
        try:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=seconds)
        except BaseException as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    row = {"command": command, "returncode": None if result is None else result.returncode,
        "failure": failure, "log": {"path": log.name, "bytes": log.stat().st_size, "sha256": sha(log)}}
    write(OUT / (label + ".json"), row)
    if result is None or result.returncode:
        raise RuntimeError("actual chain operation failed: " + label)
    return row


def check_build(build):
    receipt = json.loads((build / "BUILD_RECEIPT.json").read_bytes())
    if (receipt.get("build_succeeded") is not True or receipt.get("extension_build_count") != 1
            or receipt["source_receipt_sha256"] != sha(ROOT / "candidate" / CANDIDATE_RECEIPT)
            or receipt["runtime_pins_sha256"] != sha(ROOT / "candidate/RUNTIME_PINS.json")
            or receipt["compile_spec_sha256"] != sha(ROOT / "candidate/compile_spec.json")):
        raise ValueError("actual build source binding differs")
    extensions = receipt["extensions"]
    if len(extensions) != 1 or extensions[0]["module"] != "dynamic_arena_chain":
        raise ValueError("one exact chain extension required")
    extension = build / safe_name(extensions[0]["path"])
    if extension.stat().st_size != extensions[0]["bytes"] or sha(extension) != extensions[0]["sha256"]:
        raise ValueError("actual built ELF bytes differ")
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("build", "controls"))
    args = parser.parse_args()
    report = {"schema": "t3-authoritative-chain-one-json-actual-result-v1", "all_passed": False,
        "rankable": False, "speed_claim": False, "official_gate": False, "full71": False,
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "actual_native_build_invocations": 0,
        "mode": args.verb, "source_before": None, "source_after": None,
        "build_verified": False, "failure": None}
    build = OUT / "build" if args.verb == "build" else Path("/build")
    try:
        verify_payload(ROOT)
        report["source_before"] = inventory(ROOT)
        if args.verb == "build":
            report["actual_native_build_invocations"] += 1
            report["build_command"] = call([sys.executable, "-B", str(ROOT / "candidate/build_native.py"),
                "--runtime", str(ROOT / "runtime"), "--out", str(build)], "native-build", 900)
        report["build_before"] = inventory(build)
        receipt = check_build(build)
        report.update(build_verified=True, build_receipt=receipt)
        if args.verb == "controls":
            controls = OUT / "controls"
            report["controls_command"] = call([sys.executable, "-B", str(ROOT / "candidate/controls.py"),
                "--runtime", str(ROOT / "runtime"), "--build", str(build), "--out", str(controls)], "json-controls", 600)
            actual = json.loads((controls / "CONTROLS.json").read_bytes())
            if actual.get("all_passed") is not True or len(actual["cases"]) != 5:
                raise ValueError("actual finite JSON controls did not all pass")
            selections=[json.loads((controls/name/"ARM_SELECTION.json").read_bytes()) for name in ("original","native1","native2")]
            if not all(row.get("passed") is True for row in selections) or any(row.get("native_authority") is not True for row in selections[1:]):raise ValueError("actual native arena arm selection not established")
            diagnostics=[json.loads((controls/name/"ARENA_DIAGNOSTICS.json").read_bytes()) for name in ("native1","native2")]
            if diagnostics[0]!=diagnostics[1] or any(row.get("control_only") is not True or row["orders"].get("order_slots",0)<=0 or row["messages"].get("constructed_messages",0)<=0 for row in diagnostics):raise ValueError("actual dynamic arena path diagnostics absent or unstable")
            report["actual_arm_selections"]=selections
            report["actual_arena_diagnostics"]=diagnostics
            report["actual_controls"] = actual
        report["build_after"] = inventory(build)
        if report["build_before"] != report["build_after"]:
            raise ValueError("compiled ELF/build inventory changed during controls")
        report["all_passed"] = True
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        try:
            verify_payload(ROOT)
            report["source_after"] = inventory(ROOT)
            if report["source_before"] != report["source_after"]:
                raise ValueError("installed source changed during build/controls")
            if args.verb == "controls" and report.get("build_before") is not None:
                report["build_after"] = inventory(build)
                if report["build_before"] != report["build_after"]:
                    raise ValueError("readonly build changed during failed controls")
        except BaseException as error:
            report["all_passed"] = False
            report["source_failure"] = {"type": type(error).__name__, "message": str(error)}
        # Generated C, object files, ELF, actual BUILD_RECEIPT, partial outputs,
        # both arm logs and STATE snapshots remain under /output on failure.
        report["retained_output_inventory"] = inventory(OUT)
        write(OUT / "ACTUAL_RESULT.json", report)
    if report["all_passed"] is not True:
        raise RuntimeError("actual authoritative chain build/JSON controls failed")


if __name__ == "__main__":
    main()
