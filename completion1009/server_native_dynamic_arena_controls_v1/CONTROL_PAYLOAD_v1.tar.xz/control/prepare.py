"""Prepare reviewed source-only inputs; never import participant or run Docker."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import CANDIDATE_RECEIPT, CANDIDATE_SHA256, inventory, sha, verify_payload, verify_rows, write

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WORKSPACE = ROOT.parents[1]
CANDIDATE = ROOT / "candidates/native_dynamic_arena_chain_v1"
WRAPPER_RECEIPT = "SOURCE_PREPARATION_RECEIPT_v1.json"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.archive.exists():
        raise ValueError("fresh source payload and archive paths required")
    wrapper = json.loads((HERE / WRAPPER_RECEIPT).read_bytes())
    if wrapper.get("frozen") is not True or wrapper.get("candidate_source_receipt_sha256") != CANDIDATE_SHA256:
        raise ValueError("root-reviewed frozen wrapper/source receipt required")
    verify_rows(HERE, wrapper["files"])
    receipt = json.loads((CANDIDATE / CANDIDATE_RECEIPT).read_bytes())
    if sha(CANDIDATE / CANDIDATE_RECEIPT) != CANDIDATE_SHA256:
        raise ValueError("current frozen dynamic arena candidate receipt required")
    verify_rows(CANDIDATE, receipt["files"])
    runtime = json.loads((CANDIDATE / "RUNTIME_PINS.json").read_bytes())
    rules = json.loads((CANDIDATE / "RULE_SOURCE_PINS_v1.json").read_bytes())
    copies = [(CANDIDATE / row["path"], "candidate/" + row["path"]) for row in receipt["files"]]
    copies.append((CANDIDATE / CANDIDATE_RECEIPT, "candidate/" + CANDIDATE_RECEIPT))
    copies += [(Path(runtime["runtime_owner"]) / row["path"], "runtime/" + row["path"]) for row in runtime["files"]]
    copies += [(WORKSPACE / row["path"], "rules/" + row["path"]) for row in rules["files"]]
    copies += [(HERE / row["path"], "control/" + row["path"]) for row in wrapper["files"]]
    copies.append((HERE / WRAPPER_RECEIPT, "source_review/" + WRAPPER_RECEIPT))
    review_path=CANDIDATE/"INDEPENDENT_DYNAMIC_ARENA_SOURCE_REVIEW_v1.json"
    review=json.loads(review_path.read_bytes())
    if sha(review_path)!="eb6f6dc691bef922551438da2859484bd54b177472aece151675842ec785ba0e" or review.get("status")!="PASS_SOURCE_FINITE_NORMAL_OWNERSHIP_ONLY" or review.get("blockers")!=[]:raise ValueError("independent finite dynamic source review required")
    copies.append((review_path,"source_review/INDEPENDENT_DYNAMIC_ARENA_SOURCE_REVIEW.json"))
    delta_path=CANDIDATE/"INDEPENDENT_DYNAMIC_ARENA_CONTROL_DIAGNOSTICS_DELTA_v1.json"
    delta=json.loads(delta_path.read_bytes())
    if sha(delta_path)!="b6928630c9b0febc9b7482d2e1e8d35d8334a41154df1b1dc193bc08a5d69945" or delta.get("status")!="PASS_SOURCE_ONLY" or delta.get("blockers")!=[]:raise ValueError("independent final control child delta review required")
    copies.append((delta_path,"source_review/INDEPENDENT_DYNAMIC_CONTROL_CHILD_FINAL_DELTA_REVIEW.json"))
    args.out.mkdir(parents=True)
    for source, relative in copies:
        target = args.out / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        if target.suffix == ".py":
            ast.parse(target.read_bytes()); compile(target.read_bytes(), str(target), "exec", dont_inherit=True)
    plan = {"schema": "t3-authoritative-chain-one-json-controls-plan-v1", "frozen_source_inputs": True,
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "candidate_sources": len(receipt["files"]),
        "runtime_sources": len(runtime["files"]), "rule_sources": len(rules["files"]),
        "native_builds": 1, "real_JSON_scenarios": 1, "arms": ["original", "native1", "native2"],
        "build_resources": {"cpus": 1, "memory_bytes": 8 * 1024**3, "tmp_bytes": 1024**3},
        "correctness_resources": {"cpus": 4, "memory_bytes": 16 * 1024**3, "tmp_bytes": 64 * 1024**2, "tmp_noexec": True},
        "scenario_sha256": sha(args.out / "candidate/control_scenario.json"),
        "frozen_wrapper_receipt_sha256": sha(HERE / WRAPPER_RECEIPT), "source_only": True,
        "source_pass": False, "runtime_pass": False, "rankable": False, "official_submission": False,
        "speed_claim": False, "finite_dynamic_normal_ownership_source_review": True,
        "independent_dynamic_arena_source_review_sha256": sha(review_path), "independent_control_child_final_delta_review_sha256":sha(delta_path),
        "actual_native_arm_required":True,"arena_diagnostics_required":True}
    write(args.out / "CONTROL_PLAN.json", plan)
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-authoritative-chain-payload-source-manifest-v1", "files": inventory(args.out)})
    verify_payload(args.out)
    with tarfile.open(args.archive, "w:xz") as archive:
        for row in inventory(args.out):
            data = (args.out / row["path"]).read_bytes()
            item = tarfile.TarInfo(row["path"]); item.size = len(data); item.mode = 0o644
            item.mtime = 0; item.uid = item.gid = 0; item.uname = item.gname = ""
            archive.addfile(item, io.BytesIO(data))
    write(args.archive.with_suffix(".receipt.json"), {"source_only": True, "archive_sha256": sha(args.archive),
        "archive_bytes": args.archive.stat().st_size, "payload_files": len(inventory(args.out)),
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "runtime_executed": False})
    print(json.dumps({"archive": str(args.archive), "bytes": args.archive.stat().st_size, "sha256": sha(args.archive)}))


if __name__ == "__main__":
    main()
