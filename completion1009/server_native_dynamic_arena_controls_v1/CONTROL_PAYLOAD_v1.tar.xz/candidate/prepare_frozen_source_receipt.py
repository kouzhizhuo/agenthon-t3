"""Stdlib frozen source receipt writer, never native compile or participant import."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    target=D/"SOURCE_PREPARATION_RECEIPT_v1.json"
    if target.exists():raise ValueError("frozen receipt is immutable")
    review=D/"INDEPENDENT_DYNAMIC_ARENA_SOURCE_REVIEW_v1.json"
    if sha(review)!="eb6f6dc691bef922551438da2859484bd54b177472aece151675842ec785ba0e":raise ValueError("independent reviewed source changed")
    delta=D/"INDEPENDENT_DYNAMIC_ARENA_CONTROL_DIAGNOSTICS_DELTA_v1.json"
    if sha(delta)!="b6928630c9b0febc9b7482d2e1e8d35d8334a41154df1b1dc193bc08a5d69945":raise ValueError("independent diagnostics delta differs")
    rows=[];checked=[]
    for p in sorted(D.iterdir()):
        if not p.is_file() or any(x=="__pycache__" or x.startswith("._") for x in p.parts) or p.name.startswith("UNFROZEN_PROGRESS_RECEIPT_"):continue
        data=p.read_bytes();rows.append({"path":p.name,"bytes":len(data),"sha256":sha(p)})
        if p.suffix==".py":compile(ast.parse(data),str(p),"exec",dont_inherit=True);checked.append(p.name)
    report={"schema":"t3-dynamic-authoritative-arena-frozen-source-receipt-v1","executive_summary":"Frozen source for one future dynamic arena build and actual original/native/native JSON control. Independent finite normal-ownership source review found no unresolved blocker. Exact path-selection witnesses prevent silent original fallback from counting as a native PASS. Actual Cython compilation, pinned-image admission, output/state equality, extended lifetime safety, performance and official gates remain unverified.","source_only":True,"frozen_build_input":True,"unfrozen":False,"source_pass":False,"native_built":False,"participant_imported":False,"market_executed":False,"RNG_draws":0,"runtime_pass":False,"speed_claim":False,"rankable":False,"official_submission":False,"files":rows,"python_AST_compile_checked":checked,"root_freeze_authorized":True,"minimum_message_kinds":13,"independent_source_review":{"path":review.name,"bytes":review.stat().st_size,"sha256":sha(review),"classification":"PASS_SOURCE_FINITE_NORMAL_OWNERSHIP_ONLY","unresolved_source_blockers":[]},"independent_control_diagnostics_delta":{"path":delta.name,"bytes":delta.stat().st_size,"sha256":sha(delta)},"remaining":["actual pinned CPython3.11 admission and native path selection","actual Cython build","actual one JSON original/native/native full Parquet and STATE equality","finite protocol/slot/lifetime stress","measured unprofiled full CLI speed and official gates"]}
    target.write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
    print(json.dumps({"receipt":str(target),"bytes":target.stat().st_size,"sha256":sha(target),"source_files":len(rows)}))
if __name__=="__main__":main()
