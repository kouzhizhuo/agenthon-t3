"""One common full-entry timer for unchanged observer vs native projection."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path("/opt/projection-screen/completion1009/candidates/native_canonical_projection_v2")
ARMS = ("observer_parent", "native_projection")
MARKER = "T3_NATIVE_PROJECTION_SCREEN="


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("simulate", "simulate-batch"))
    parser.add_argument("--config")
    parser.add_argument("--out")
    parser.add_argument("--batch-dir")
    parser.add_argument("--out-dir")
    parser.add_argument("--mode", choices=(*ARMS, "controls"), required=True)
    args = parser.parse_args()
    receipt = ROOT / "artifacts/build_v2/BUILD_RECEIPT.json"
    os.environ["NATIVE_PROJECTION_BUILD_RECEIPT"] = str(receipt)
    sys.path.insert(0, str(ROOT))
    if args.mode == "controls":
        if (args.verb != "simulate" or args.config != "/input/scenario.json"
                or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir
                or json.loads(Path(args.config).read_text()) != {"proof_command": "native-projection-56-and-four-markets-v2"}):
            raise ValueError("fixed controls input required")
        completed = subprocess.run([sys.executable, "-B", str(ROOT / "controls.py"),
            "--receipt", str(receipt), "--out", "/output/controls"], cwd="/output", timeout=900)
        raise SystemExit(completed.returncode)
    single = args.verb == "simulate"
    if single:
        if args.config != "/input/scenario.json" or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir:
            raise ValueError("fixed single paths required")
    elif args.batch_dir != "/input/scenarios" or args.out_dir != "/output" or args.config or args.out:
        raise ValueError("fixed batch paths required")
    os.environ["NATIVE_PROJECTION_ENABLED"] = "1" if args.mode == "native_projection" else "0"
    import cli
    from projection import reset_probes, episode_probes
    reset_probes()
    result = (cli.simulate(args.config, args.out, started=cli.ENTRY_STARTED) if single
        else cli.simulate_batch(args.batch_dir, args.out_dir, started=cli.ENTRY_STARTED))
    episodes = episode_probes()
    if len(episodes) != (1 if single else result["n_scenarios"]):
        raise ValueError("actual projection episode roster differs")
    for witness in episodes:
        if witness.get("candidate") != ROOT.name:
            raise ValueError("actual candidate origin differs")
        if args.mode == "native_projection":
            if (witness.get("native_projection_active") is not True or witness.get("fallback_used") is not False
                    or witness.get("implementation") != "observer_contract_typed_rows_stable_merge_v1"
                    or witness.get("typed_numeric_write_rows") != witness.get("complete_trace_rows")
                    or witness.get("python_sort_key_callbacks") != 0
                    or witness.get("source_derived_live_helper_proof") is not True
                    or witness.get("numeric_side_crossbindings_checked") is not True):
                raise ValueError("actual native projection not observed")
        elif witness.get("native_projection_active") is not False:
            raise ValueError("observer parent used native projection")
    print(MARKER + json.dumps({"schema": "t3-native-projection-entry-v2", "arm": args.mode,
        "events": result, "episodes": episodes, "cli_source": str(ROOT / "cli.py"),
        "entry_source": str(Path(__file__).resolve()), "rankable": False,
        "timing_scope": "CLI ENTRY_STARTED through Parquet/hash; unchanged sidecar cutoff; marker serialization outside CLI timer"},
        sort_keys=True, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
