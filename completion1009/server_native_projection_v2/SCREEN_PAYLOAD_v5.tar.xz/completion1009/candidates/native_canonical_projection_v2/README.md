# Connected exact native canonical projection

This source-prepared candidate derives from frozen selected
`observer_mixed_v2_authcache`. It changes final order-trace projection, leaving
all 64 parent runtime files unchanged. No compilation, finite control,
simulation, official verifier or timing has run for this candidate.

The new extension consumes the parent's original per-agent contract tuples
once. It writes a typed row arena, selects each order's final execution with
the maximum timestamp and last original emission tie, updates quote rows by
last-write while preserving first-insertion order, runs native stable mergesort
on `(time, order_id)`, and fills five integer arrays by typed writes. Pandas
constructs the two exact `string` arrays from canonical shared strings/None.
There are no per-row Python lists, sort-key callbacks, dict final-fill/quote
tables or per-column fromiter generators in the accepted projection path.

The parent retains authoritative agents, books, orders/messages and metadata,
RNG, UID, event horizon, delays/callbacks, logs, observer inference and fallback
replay. The candidate does not replace the parent's observer methods or source
authentication. One separate CLI final extraction call asks the extension to
project; unsupported raw records, callback types, numerical ranges or absent
scalar/lifecycle witnesses use the original observer extractor. The fallback
receives the actual preserved inference records and retains its exceptions.

Order rows keep the original Agent iteration and emission order. Removing the
first timestamp sort is exact because final-execution selection is maximum
`(timestamp, emission index)`, and the final stable sort preserves equal
`(timestamp, order_id)` emission ties. Quote rows enter after lifecycle rows,
including order ID `-1` collisions. A repeated `(timestamp, side)` quote updates
its value but keeps its first insertion position. All integer guards match
the parent's 2^53 representable projection domain; timestamps retain full
int64 and original bool/np.int32 behavior. Custom numeric callbacks go through
original extraction without a callback during native refusal.

The required output schema remains `t_ns:int64, agent_id:int32,
msg_type:string, side:string, price:int64, size:int64, order_id:int64`, including
Pandas StringArray missing sides. The mandatory message trace stays in the
parent's exact ColumnLedger extractor; nullable `t_send_ns`, `order_id` and
`causal_parent` are constructed directly as Pandas `Int64` so nanoseconds never
pass through float inference. Arrow writer, Snappy compression, `index=False`,
CLI paths, frame validators and sidecar timer remain unchanged.

The extension is independently built as `native_projection`, CPython3.11 and
Cython3.1.3, with explicit safe compile flags/directives and pinned dependency
versions. Actual generated C, extension bytes, ABI, complete source and runtime
pins are required by `admission.py`. A Python substitute is refused. Repeated
admission checks the original compiled export identities, defaults, actual
extension origin and current complete pinned source bytes. The source-derived
live helper proof checks code, defaults, builtin overrides and import aliases
from hash-pinned source without executing a second namespace. NumPy empty and
integer types, Pandas array/DataFrame constructor and Side methods/members must
match their canonical installed/source bindings before identities are retained.
The full proof runs before initialization and immediately before projection;
the parent still checks its unchanged observer domain every episode.

`finite_controls.py` prepares 38 adversarial projection cases and 18 actual admission mutation cases. They compare exact original
and candidate values/dtypes/Parquet bytes or original exceptions, input
nonmutation and unchanged UID counters. Cases cover unsorted/tied final fills,
cross-agent emission, quote insertion/overwrite and `-1` collisions, all order
kinds, missing IDs/price/side, numpy types, 2^53/int32/int64 edges, bool and
np.int32 timestamps, repeated keys/rehash/many ties, raw payload overrides and
array exceptions, overflow, malformed quote symbol, missing scalar/empty/quote
only states and original integer-subclass callback behavior. Active cases
require actual typed-write and zero Python sort-callback witnesses. The 18 mutations cover compiled projector/dtype/defaults, helper replacement/code/defaults/kwdefaults/global aliases/proof roster, CLI imports, NumPy empty/int64, Pandas array/defaults/DataFrame, Side value and native NumPy alias. After a clean whole-episode admission, a replaced conversion callback must be refused before any conversion call, with no native fallback. Each restoration must admit the original receipt again.

The finite test harness is not a complete market equivalence test. After it
passes on the exact Linux build, root must compare complete parent/native
markets, both mandatory output frames, all business-state/alias/RNG/UID
records, actual native episode probes and original official verifier gates. The v2 semantic graph includes all Agent.log/kernel attributes and the complete original book_log2 bids/asks payload with shared aliases; it omits only Kernel wall-clock telemetry and its log directory. Consumer-presence witnesses remain extra diagnostics and never replace original book payloads.
Then root schedules common full-CLI timing with alternate arm order, warmup,
three measured repeats and full five-member batch plus isolated submarkets.
`host_probe.py` saves the actual receipt-bound extension/typed-sort/write
witness separately from official output files and refuses a native arm that
fell back. Parent and candidate arms share the same CLI timer and simulation.

Preparation, executed only as source/AST/hash/copy after root review:

```sh
python3 prepare_snapshot.py
```

Under root's explicitly scheduled compile/control slot:

```sh
python3.11 build_native.py --out artifacts/build_v2
python3.11 finite_controls.py --receipt artifacts/build_v2/BUILD_RECEIPT.json --out artifacts/finite_v2.json
```

No native speed follows from architecture. Existing saved
`trace_sort_once_v1` gained only about 1.0183 mean five-unit ratio in Mac evidence
and regressed RA/MP, so it was not integrated. The production package already
compiles trace.py: this candidate must prove an additional connected native
path and actual complete Linux benefit. There is no 230000 events/sec,
full71, official-score or leaderboard-rank claim.
