#!/usr/bin/env python3
"""Read/hash/AST/copy only; never import a parent runtime or native candidate."""
import ast
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "observer_mixed_v2_authcache"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare():
    if (HERE / "runtime").exists() or (HERE / "RUNTIME_PINS.json").exists():
        raise ValueError("new snapshot destination required")
    manifest = json.loads((PARENT / "SNAPSHOT_MANIFEST.json").read_text())
    records = manifest["files"]
    if len(records) != 64:
        raise ValueError("selected observer parent requires 64 frozen runtime members")
    actual = {p.relative_to(PARENT / "runtime").as_posix(): p for p in (PARENT / "runtime").rglob("*")
        if p.is_file() and not p.name.startswith("._") and "__pycache__" not in p.parts}
    if set(actual) != {r["path"] for r in records}:
        raise ValueError("observer parent runtime roster differs")
    result = []
    for row in records:
        source = actual[row["path"]]
        if source.is_symlink() or source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]:
            raise ValueError("observer parent frozen source differs")
        if source.suffix == ".py":
            ast.parse(source.read_text(), filename=str(source))
        target = HERE / "runtime" / row["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        result.append({k: row[k] for k in ("path", "bytes", "sha256")})
    pins = {"schema": "t3-native-canonical-projection-runtime-pins-v2",
        "parent": str(PARENT), "parent_manifest_sha256": sha(PARENT / "SNAPSHOT_MANIFEST.json"),
        "parent_correctness_receipt_sha256": sha(PARENT / "CORRECTNESS_EVIDENCE.json"),
        "files": result, "runtime_source_changes": 0, "source_only": True}
    (HERE / "RUNTIME_PINS.json").write_text(json.dumps(pins, indent=2) + "\n")
    sources = {p.name: sha(p) for p in HERE.iterdir() if p.is_file() and not p.name.startswith("._")
        and (p.suffix in (".py", ".pyx", ".md") or p.name == "compile_spec.json")}
    (HERE / "SOURCE_PINS.json").write_text(json.dumps({"schema": "t3-native-canonical-projection-source-pins-v2",
        "candidate_sources": sources, "runtime_pins_sha256": sha(HERE / "RUNTIME_PINS.json"),
        "source_only": True, "native_execution": False}, indent=2) + "\n")


if __name__ == "__main__":
    prepare()
