"""Final projection only: no parent observer binding or producer is replaced."""
import os
from live_binding import authenticate_helpers

_active = False
_module = None
_episodes = []
_episode_admission = None


def begin_projection(active, authenticated):
    global _active, _module, _episode_admission
    if type(active) is not bool or type(authenticated) is not bool:
        raise ValueError("projection explicit boolean admission required")
    _active = False
    _module = None
    _episode_admission = None
    if active:
        authenticate_helpers()
    _active = active and authenticated
    if _active:
        path = os.environ.get("NATIVE_PROJECTION_BUILD_RECEIPT")
        if not path:
            raise ValueError("explicit projection build receipt required")
        from admission import load_native
        _module = load_native(path)
        _episode_admission = authenticate_helpers(_module)
    return _active


def extract_projection(end_state):
    import observer
    from abides_fork.trace import extract_trace
    from admission import native_receipt
    if not _active or observer.STATE is None:
        witness = {"candidate": "native_canonical_projection_v2", "native_projection_active": False,
            "fallback_used": True, "reason": "whole_episode_not_admitted"}
        _episodes.append(witness)
        return extract_trace(end_state)
    # This is before groups are traversed or any numeric conversion happens.
    # A changed live binding must raise; fallback cannot masquerade as native.
    from admission import check_native
    from observer_domain import authenticate_loaded
    live_proof = authenticate_helpers(_module)
    if _episode_admission is None or check_native() is not _module or not authenticate_loaded():
        raise ValueError("projection whole-episode admission changed")
    if type(end_state) is not dict or type(end_state.get("agents")) is not list or type(observer.STATE.contract) is not dict:
        frame = extract_trace(end_state)
        _episodes.append({"candidate": "native_canonical_projection_v2", "native_projection_active": False,
            "fallback_used": True, "reason": "unsupported_projection_owner"})
        return frame
    # Exact parent records remain owned by its authenticated observer. No copy
    # of a market state, message, order, metadata or RNG enters the native path.
    groups = [(agent.id, observer.STATE.contract.get(agent, [])) for agent in end_state["agents"]]
    frame, witness = _module.project_contract(groups, observer.STATE.has_scalar)
    if frame is None:
        frame = extract_trace(end_state)
    else:
        witness.update(native_receipt())
        witness.update(live_proof)
    witness["candidate"] = "native_canonical_projection_v2"
    witness["complete_trace_rows"] = len(frame)
    witness["proof_only"] = True
    witness["rankable"] = False
    _episodes.append(witness)
    return frame


def reset_probes():
    _episodes.clear()


def episode_probes():
    return [dict(value) for value in _episodes]
