#!/usr/bin/env python3
"""Scheduleable full CLI native-path witness; parent task owns execution."""
import argparse
import json
import os
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--config")
    parser.add_argument("--out")
    parser.add_argument("--batch-dir")
    parser.add_argument("--out-dir")
    parser.add_argument("--arm", choices=("parent", "native"), required=True)
    parser.add_argument("--probe", type=Path, required=True)
    args = parser.parse_args()
    if args.probe.exists() or bool(args.config) != bool(args.out) or bool(args.batch_dir) != bool(args.out_dir) or bool(args.config) == bool(args.batch_dir):
        raise ValueError("new probe and exactly one official single/batch invocation required")
    os.environ["NATIVE_PROJECTION_BUILD_RECEIPT"] = str(Path(args.receipt).resolve())
    os.environ["NATIVE_PROJECTION_ENABLED"] = "1" if args.arm == "native" else "0"
    import cli
    from projection import episode_probes, reset_probes
    reset_probes()
    events = (cli.simulate(args.config, args.out, started=cli.ENTRY_STARTED) if args.config
        else cli.simulate_batch(args.batch_dir, args.out_dir, started=cli.ENTRY_STARTED))
    episodes = episode_probes()
    expected = 1 if args.config else events["n_scenarios"]
    if len(episodes) != expected:
        raise ValueError("projection episode roster missing")
    if args.arm == "native" and any(not value.get("native_projection_active") or value.get("fallback_used")
            or value.get("implementation") != "observer_contract_typed_rows_stable_merge_v1"
            or value.get("typed_numeric_write_rows") != value.get("complete_trace_rows")
            or value.get("python_sort_key_callbacks") != 0 or not value.get("extension_sha256") for value in episodes):
        raise ValueError("actual connected native projection not observed")
    if args.arm == "parent" and any(value.get("native_projection_active") for value in episodes):
        raise ValueError("parent arm used candidate native path")
    args.probe.parent.mkdir(parents=True, exist_ok=True)
    args.probe.write_text(json.dumps({"schema": "t3-native-canonical-projection-entry-probe-v2",
        "arm": args.arm, "events": events, "episodes": episodes, "cli_source": str(Path(cli.__file__).resolve()),
        "timing_scope": "common CLI ENTRY_STARTED through Parquet/hash; marker outside timer",
        "rankable": False, "official_score": None}, indent=2) + "\n")
    print(json.dumps({"events": events, "native_projection_probe": str(args.probe)}))


if __name__ == "__main__":
    main()
