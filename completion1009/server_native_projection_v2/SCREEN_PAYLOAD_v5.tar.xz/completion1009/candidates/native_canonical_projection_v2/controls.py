#!/usr/bin/env python3
"""Scheduled finite and exact parent/native full-market comparisons, untimed."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("new complete control output required")
    args.out.mkdir(parents=True)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[name] = "1"
    from provenance import candidate_sources
    before = candidate_sources()
    def launch(arguments, log):
        with log.open("xb") as stream:
            result = subprocess.run([sys.executable, "-B", *arguments], stdout=stream, stderr=subprocess.STDOUT,
                env=dict(os.environ), cwd=str(HERE), timeout=240)
        if result.returncode:
            raise ValueError("control worker failed: " + str(log))
    report = {"schema": "t3-native-canonical-projection-controls-v2", "cases": [], "failures": [],
        "candidate_sources": before, "proof_only": True, "rankable": False, "timing_claim": False,
        "official_gate": False}
    try:
        launch([str(HERE / "finite_controls.py"), "--receipt", args.receipt, "--out", str(args.out / "FINITE_RESULT.json")], args.out / "finite.log")
        finite = json.loads((args.out / "FINITE_RESULT.json").read_text())
        assert finite["all_passed"] and len(finite["cases"]) == 56
        for arm in ("parent", "native"):
            launch([str(HERE / "semantic_worker.py"), "--runtime", str(HERE / "runtime"), "--receipt", args.receipt,
                "--arm", arm, "--out", str(args.out / arm)], args.out / (arm + ".log"))
        # These workers are deliberately authored source in the exact local
        # control harness. Their raw values are not accepted from submissions.
        values = [pickle.loads((args.out / arm / "SEMANTIC_VALUES.pkl").read_bytes()) for arm in ("parent", "native")]
        sys.path.insert(0, str(HERE / "runtime"))
        from bootstrap import activate
        activate()
        import pandas as pd
        assert len(values[0]) == len(values[1]) == 4
        for index, (a, b) in enumerate(zip(*values)):
            assert a["seed"] == b["seed"] == (81009, 82009, 83009, 84009)[index]
            assert a["details"] == b["details"], "observer/state/pop details differ"
            for x, y in zip(a["frames"], b["frames"]):
                pd.testing.assert_frame_equal(x, y, check_exact=True, check_dtype=True, rtol=0, atol=0)
            assert a["payload"] == b["payload"], "Parquet/state/alias/RNG/ID/depth/metric-witness payload differs"
            witness = b["projection_witness"]
            assert witness["native_projection_active"] and not witness["fallback_used"]
            assert witness["extension_sha256"] == finite["native_receipt"]["extension_sha256"]
            assert witness["complete_trace_rows"] == len(b["frames"][0])
            report["cases"].append({"seed": b["seed"], "passed": True, "trace_rows": len(b["frames"][0]),
                "message_rows": len(b["frames"][1]), "details": b["details"], "native_projection_witness": witness})
        assert candidate_sources() == before, "candidate source changed"
        report.update(all_passed=True, finite_cases=56, full_market_cases=4, sources_unchanged=True,
            native_receipt=finite["native_receipt"])
    except Exception as error:
        report["all_passed"] = False
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    report["controls_source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (args.out / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
