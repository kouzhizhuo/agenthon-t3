#!/usr/bin/env python3
"""Prepared adversarial projection controls; no market or timing claims."""
import argparse
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import sys
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent


def cases(np, Side):
    def order(t, oid, quantity=3, kind="ORDER_EXECUTED", aid=0, side=Side.BID, price=100, fill=101):
        return (t, kind, "order", (aid, oid, side, quantity, price, fill))
    def quote(t, side="BEST_BID", price=99, quantity=4, symbol="ABM"):
        return (t, side, "quote", (symbol, price, quantity))
    yield "basic_lifecycle", [(0, [order(1, 4, kind="ORDER_SUBMITTED"), order(2, 4, kind="ORDER_ACCEPTED"), order(3, 4)])], True, True
    yield "unsorted_max_time_and_tied_final", [(0, [order(20, 4, 1), order(10, 4, 2), order(20, 4, 3)])], True, True
    yield "equal_time_cross_agent_final_emission", [(1, [order(10, 4, 1)]), (0, [order(10, 4, 2)])], True, True
    yield "negative_order_id_quote_collision", [(0, [order(10, -1), quote(10), order(10, -1, 5)])], True, True
    yield "quote_last_write_first_insertion_tie", [(0, [quote(10, "BEST_ASK", 101), order(10, -1), quote(10, price=99), quote(10, "BEST_ASK", 102)])], True, True
    yield "duplicate_quote_across_agents", [(1, [quote(10, price=98), order(11, 4)]), (2, [quote(10, price=99)])], True, True
    yield "mixed_all_order_kinds", [(0, [order(i, 4, kind=k) for i, k in enumerate(("ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_CANCELLED", "ORDER_REPLACED", "ORDER_EXECUTED"))])], True, True
    yield "missing_order_id_skips", [(0, [order(1, None), order(2, 5)])], True, True
    yield "agent_id_none_fallback", [(19, [order(1, 5, aid=None)])], True, True
    yield "market_missing_limit_price", [(0, [(1, "ORDER_SUBMITTED", "market", (0, 4, Side.BID, 3, None, None)), order(2, 4)])], True, True
    yield "missing_fill_price_zero", [(0, [order(1, 4, fill=None)])], True, True
    yield "nullable_side_string_array", [(0, [order(1, 4, side=None), order(2, 5, side="strange")])], True, True
    yield "side_bid_precedence", [(0, [order(1, 4, side="ask-bid"), order(2, 5, side="aSk")])], True, True
    yield "numpy_integral_types", [(np.int32(0), [order(np.int64(1612517400000000001), np.int64(4), np.int32(3), aid=np.int32(0), price=np.int64(100))])], True, True
    yield "int64_timestamp_extremes", [(0, [order(-(1 << 63), 4), order((1 << 63) - 1, 4)])], True, True
    yield "timestamp_npint32_original_zero", [(0, [order(np.int32(123), 4)])], True, True
    yield "bool_timestamp_original_integer", [(0, [order(True, 4)])], True, True
    yield "noninteger_timestamp_original_zero", [(0, [order("123", 4)])], True, True
    yield "integer53_edges", [(0, [order(1, -(1 << 53), quantity=(1 << 53), price=-(1 << 53)), order(2, (1 << 53))])], True, True
    yield "agent_int32_edges", [(-(1 << 31), [order(1, 4, aid=None)]), ((1 << 31) - 1, [order(2, 5, aid=None)])], True, True
    yield "rehash_many_fill_and_quote_keys", [(0, [record for i in range(160) for record in (order(200 - i, i), quote(i), order(200 - i, i, 5))])], True, True
    yield "many_equal_keys_stable", [(0, [order(10, 4, i) for i in range(140)])], True, True
    yield "large_negative_sort_keys", [(0, [order(t, oid) for t, oid in ((-4, -1), (-5, 7), (-4, -9), (-5, -1))])], True, True
    yield "single_row_sort_zero_passes", [(0, [order(1, 4)])], True, True
    yield "raw_field_override_replay", [(0, [(1, "ORDER_EXECUTED", "raw", {"EventTime": 3, "order_id": 4, "agent_id": 0, "side": Side.BID, "quantity": 2, "fill_price": 100})])], True, False
    yield "raw_array_original_exception", [(0, [(1, "ORDER_EXECUTED", "raw", np.array([1, 2]))])], True, False
    yield "out_of_integer53_replay", [(0, [order(1, (1 << 53) + 1)])], True, False
    yield "out_of_int32_agent_replay", [(0, [order(1, 4, aid=(1 << 31))])], True, False
    yield "float_quantity_replay", [(0, [order(1, 4, quantity=3.5)])], True, False
    yield "boolean_quantity_replay", [(0, [order(1, 4, quantity=True)])], True, False
    yield "quote_comma_symbol_replay", [(0, [order(1, 4), quote(2, symbol="A,B")])], True, False
    yield "quote_float_price_replay", [(0, [order(1, 4), quote(2, price=99.)])], True, False
    yield "absent_scalar_inference_replay", [(0, [order(1, 4)])], False, False
    yield "empty_contract_replay", [(0, [])], True, False
    yield "quotes_only_replay", [(0, [quote(1)])], True, False
    yield "huge_timestamp_replay", [(0, [order(1 << 63, 4)])], True, False
    class CallbackInteger(int):
        def __int__(self):
            raise RuntimeError("original timestamp integer callback")
    yield "integer_timestamp_callback_replay", [(0, [order(CallbackInteger(10), 4)])], True, False
    yield "large_uint64_timestamp_original_zero", [(0, [order(np.uint64((1 << 63) + 3), 4)])], True, False


def outcome(operation, pd):
    try:
        frame = operation()
        stream = io.BytesIO()
        frame.to_parquet(stream, compression="snappy", index=False)
        return {"kind": "frame", "frame": frame, "bytes": stream.getvalue()}
    except Exception as error:
        return {"kind": "exception", "type": type(error).__name__, "message": str(error)}


def native_mutation_controls(native, receipt, load_native):
    """Actual admitted module mutations are refused, then restored cleanly."""
    values = []
    original = native.project_contract
    native.project_contract = lambda *args: (None, {})
    try:
        try: load_native(receipt)
        except ValueError: values.append({"name": "admission_compiled_export_replacement_refused", "passed": True})
        else: raise AssertionError("compiled export mutation admitted")
    finally: native.project_contract = original
    load_native(receipt)
    saved = native.TRACE_DTYPES["price"]
    native.TRACE_DTYPES["price"] = "float64"
    try:
        try: load_native(receipt)
        except ValueError: values.append({"name": "admission_mutable_dtype_constant_refused", "passed": True})
        else: raise AssertionError("dtype mutation admitted")
    finally: native.TRACE_DTYPES["price"] = saved
    load_native(receipt)
    return values


def live_mutation_controls(native, receipt, load_native):
    """Refuse real code/default/global/import/numeric changes, then restore.

    The pre-projection control uses an admitted fixture episode and a callable
    spy: refusal must occur before its numeric conversion callback is invoked.
    No simulated agent, native fallback or timing claim is part of this test.
    """
    import os
    import numpy as np
    import pandas as pd
    import admission
    import provenance
    import projection
    import live_binding
    import cli
    import observer
    from abides_markets.orders import Side
    values = []
    def refused(name, owner, attribute, changed):
        original = getattr(owner, attribute)
        setattr(owner, attribute, changed)
        try:
            try:
                load_native(receipt)
            except ValueError:
                values.append({"name": name, "passed": True, "refused_before_native_use": True})
            else:
                raise AssertionError("live mutation admitted: " + name)
        finally:
            setattr(owner, attribute, original)
        load_native(receipt)
    refused("helper_callable_replacement", projection, "extract_projection", lambda state: None)
    refused("helper_code_mutation", provenance.sha, "__code__", (lambda path: "changed").__code__)
    refused("helper_default_mutation", provenance.sha, "__defaults__", (None,))
    refused("helper_kwdefault_mutation", provenance.sha, "__kwdefaults__", {"path": None})
    refused("helper_global_import_alias", admission, "abi", lambda: {})
    refused("helper_proof_roster_mutation", live_binding, "HELPERS", ("provenance",))
    changed = dict(live_binding.DYNAMIC)
    changed["live_binding"] += ("DYNAMIC", "HELPERS", "ENTRIES")
    original_dynamic = live_binding.DYNAMIC
    live_binding.DYNAMIC = changed
    try:
        try:
            load_native(receipt)
        except ValueError:
            values[-1]["dynamic_scope_mutation_also_refused"] = True
        else:
            raise AssertionError("dynamic proof-scope mutation admitted")
    finally:
        live_binding.DYNAMIC = original_dynamic
    load_native(receipt)
    refused("cli_imported_projection_alias", cli, "extract_projection", lambda state: None)
    refused("numpy_empty_callable_replacement", np, "empty", lambda *a, **k: None)
    refused("numpy_int64_alias_replacement", np, "int64", int)
    refused("pandas_array_callable_replacement", pd, "array", lambda *a, **k: None)
    refused("pandas_array_default_mutation", pd.array, "__defaults__", (None, False))
    refused("pandas_dataframe_alias_replacement", pd, "DataFrame", type("ChangedFrame", (), {}))
    refused("side_member_value_mutation", Side.BID, "_value_", "ASK")
    refused("native_numpy_import_alias", native, "np", SimpleNamespace())
    # Cython binding=True publishes defaults; modifying them must be rejected
    # even if the actual exported compiled function identity stays unchanged.
    refused("compiled_projector_default_mutation", native.project_contract, "__defaults__", (None,))
    original = projection._episodes
    projection._episodes = []
    saved_state = observer.STATE
    saved_env = os.environ.get("NATIVE_PROJECTION_BUILD_RECEIPT")
    os.environ["NATIVE_PROJECTION_BUILD_RECEIPT"] = str(Path(receipt).resolve())
    original_array = pd.array
    calls = []
    try:
        projection.begin_projection(True, True)
        observer.STATE = observer.Episode()
        observer.STATE.has_scalar = True
        pd.array = lambda *a, **k: calls.append("converted")
        try:
            projection.extract_projection({"agents": []})
        except ValueError:
            assert calls == [], "changed conversion callback invoked before refusal"
            values.append({"name": "whole_episode_preprojection_numeric_mutation", "passed": True,
                "conversion_callback_calls": 0, "fallback_used": False})
        else:
            raise AssertionError("changed episode numeric callable admitted")
    finally:
        pd.array = original_array
        observer.STATE = saved_state
        projection._episodes = original
        projection.begin_projection(False, True)
        if saved_env is None:
            os.environ.pop("NATIVE_PROJECTION_BUILD_RECEIPT", None)
        else:
            os.environ["NATIVE_PROJECTION_BUILD_RECEIPT"] = saved_env
    load_native(receipt)
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("new finite result path required")
    sys.path.insert(0, str(HERE / "runtime"))
    from bootstrap import activate
    activate()
    import numpy as np
    import pandas as pd
    import observer
    from observer_domain import authenticate_loaded
    from abides_fork import trace
    from abides_markets.orders import Side, Order
    from abides_core.message import Message
    from admission import load_native, native_receipt
    from provenance import candidate_sources
    if not authenticate_loaded():
        raise ValueError("exact parent observer domain refused")
    native = load_native(args.receipt)
    before = candidate_sources()
    result = {"schema": "t3-native-canonical-projection-finite-v2", "cases": [], "failures": [],
        "native_receipt": native_receipt(), "proof_only": True, "rankable": False,
        "market_executed": False, "timing_claim": False}
    for name, groups, has_scalar, active in cases(np, Side):
        state = observer.Episode()
        # SimpleNamespace is unhashable; exact neutral fixture agents carry the
        # same primitive id and no methods/callbacks, as original replay expects.
        agents = [type("FixtureAgent", (), {"id": aid})() for aid, _ in groups]
        for agent, (_, records) in zip(agents, groups):
            state.contract[agent] = records
            state.inference[agent] = [(0, "AGENT_TYPE", "raw", "fixture")] + records if has_scalar else records
        state.has_scalar = has_scalar
        observer.STATE = state
        end_state = {"agents": agents}
        original_state = deepcopy(groups)
        ids_before = (Order._order_id_counter, Message._Message__message_id_counter)
        saved = {}
        def candidate():
            frame, witness = native.project_contract(groups, has_scalar)
            saved["witness"] = witness
            return frame if frame is not None else trace.extract_trace(end_state)
        try:
            expected = outcome(lambda: trace.extract_trace(end_state), pd)
            actual = outcome(candidate, pd)
            if expected["kind"] != actual["kind"]:
                raise AssertionError("frame/exception kind differs")
            if actual["kind"] == "frame":
                pd.testing.assert_frame_equal(expected["frame"], actual["frame"], check_exact=True, check_dtype=True, rtol=0, atol=0)
                assert expected["bytes"] == actual["bytes"], "Parquet bytes differ"
                assert (Order._order_id_counter, Message._Message__message_id_counter) == ids_before, "UID side effect"
            else:
                assert (expected["type"], expected["message"]) == (actual["type"], actual["message"]), "original exception differs"
            assert saved["witness"]["native_projection_active"] is active
            if active:
                assert saved["witness"]["python_sort_key_callbacks"] == 0
                assert saved["witness"]["typed_numeric_write_rows"] == len(actual["frame"])
            # Array payloads use byte comparison to avoid introducing new array
            # equality callbacks during nonmutation verification.
            for (_, before_rows), (_, after_rows) in zip(original_state, groups):
                for a, b in zip(before_rows, after_rows):
                    if isinstance(a[3], np.ndarray): assert a[3].tobytes() == b[3].tobytes()
                    else: assert a == b
            result["cases"].append({"name": name, "passed": True, "kind": actual["kind"], "witness": saved["witness"]})
        except Exception as error:
            result["failures"].append({"name": name, "type": type(error).__name__, "message": str(error)})
        finally:
            observer.STATE = None
    result["sources_unchanged"] = candidate_sources() == before
    try:
        result["cases"].extend(native_mutation_controls(native, args.receipt, load_native))
        result["cases"].extend(live_mutation_controls(native, args.receipt, load_native))
    except Exception as error:
        result["failures"].append({"name": "native_admission_mutations", "type": type(error).__name__, "message": str(error)})
    result["all_passed"] = not result["failures"] and len(result["cases"]) == 56 and result["sources_unchanged"]
    result["controls_source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
