"""Narrow source-derived helper admission; no market and no namespace exec.

Source bytes establish expected code/default/import bindings before identities
are retained. Dynamic episode state is checked by projection/admission, rather
than mistaken for immutable source globals. Checks run at episode boundaries.
"""
import ast
import builtins
import dis
import hashlib
import importlib
import importlib.machinery
import json
from pathlib import Path
import sys
import types

HERE = Path(__file__).resolve().parent
HELPERS = ("provenance", "admission", "projection", "live_binding")
ENTRIES = ("cli", "host_probe", "semantic_worker", "finite_controls")
DYNAMIC = {"admission": ("_module", "_proof", "_exports", "_mutable_exports", "_project_defaults"),
    "projection": ("_active", "_module", "_episodes", "_episode_admission"),
    "live_binding": ("_retained", "_numeric", "_dependency_pins", "_generation"),
    "cli": ("ENTRY_STARTED",), "semantic_worker": ("args", "RUNTIME", "OUTPUT", "observer")}
_retained = None
_numeric = None
_dependency_pins = None
_generation = 0


def _image(path, digest=None):
    path = Path(path).resolve()
    data = path.read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    if digest is not None and actual != digest:
        raise ValueError("projection live source changed: " + path.name)
    # Expectations always come from current hash-verified source bytes. A
    # mutable compiled-code cache cannot become an alternative authority.
    return compile(data, str(path), "exec", dont_inherit=True), ast.parse(data)


def _function(function, module, code, node, label):
    if (type(function) is not types.FunctionType or function.__code__ != code
            or function.__globals__ is not vars(module) or function.__closure__ is not None):
        raise ValueError("projection live callable changed: " + label)
    defaults = tuple(ast.literal_eval(value) for value in node.args.defaults) or None
    keywords = {arg.arg: ast.literal_eval(value) for arg, value in
        zip(node.args.kwonlyargs, node.args.kw_defaults) if value is not None} or None
    if function.__defaults__ != defaults or function.__kwdefaults__ != keywords:
        raise ValueError("projection live defaults changed: " + label)


def _resolve(module_name, names):
    value = importlib.import_module(module_name)
    for name in names:
        value = getattr(value, name)
    return value


def _top_nodes(tree):
    for node in tree.body:
        yield node
        if isinstance(node, (ast.If, ast.Try, ast.With)):
            for child in node.body:
                if isinstance(child, (ast.Import, ast.ImportFrom)):
                    yield child
            if isinstance(node, (ast.If, ast.Try)):
                for child in node.orelse:
                    if isinstance(child, (ast.Import, ast.ImportFrom)):
                        yield child


def _imports(module, tree):
    for node in _top_nodes(tree):
        if isinstance(node, ast.Import):
            for item in node.names:
                alias = item.asname or item.name.split(".")[0]
                expected = importlib.import_module(item.name if item.asname else item.name.split(".")[0])
                if vars(module).get(alias) is not expected:
                    raise ValueError("projection imported module changed: " + module.__name__ + "." + alias)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                raise ValueError("projection helper relative import unsupported")
            for item in node.names:
                if item.name == "*":
                    raise ValueError("projection helper wildcard import unsupported")
                alias = item.asname or item.name
                if vars(module).get(alias) is not _resolve(node.module, (item.name,)):
                    raise ValueError("projection imported alias changed: " + module.__name__ + "." + alias)


def _globals(module, tree, codes):
    owner = Path(module.__file__).stem
    declared = {node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    def names(target):
        if isinstance(target, ast.Name):
            return (target.id,)
        if isinstance(target, (ast.Tuple, ast.List)):
            return tuple(name for child in target.elts for name in names(child))
        return ()
    for node in _top_nodes(tree):
        if isinstance(node, ast.Import):
            declared.update(item.asname or item.name.split(".")[0] for item in node.names)
        elif isinstance(node, ast.ImportFrom):
            declared.update(item.asname or item.name for item in node.names)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else (node.target,)
            for target in targets:
                declared.update(names(target))
                if not isinstance(target, ast.Name):
                    continue
                if target.id in ("HELPERS", "ENTRIES", "DYNAMIC"):
                    if vars(module).get(target.id) != ast.literal_eval(node.value):
                        raise ValueError("projection fixed proof scope changed: " + target.id)
                    continue
                if target.id in DYNAMIC.get(owner, ()):
                    continue
                if target.id in ("HERE", "NATIVE_PROJECT_ROOT"):
                    if vars(module).get(target.id) != HERE:
                        raise ValueError("projection helper owner path changed")
                else:
                    try:
                        expected = ast.literal_eval(node.value)
                    except (ValueError, TypeError):
                        continue
                    if vars(module).get(target.id) != expected:
                        raise ValueError("projection helper constant changed: " + target.id)
    def walk(code):
        for instruction in dis.get_instructions(code):
            if instruction.opname == "LOAD_GLOBAL":
                name = instruction.argval
                if name.startswith("__"):
                    continue
                if name not in declared and name in vars(module):
                    raise ValueError("projection undeclared global override: " + name)
                if name not in declared and hasattr(builtins, name):
                    owner = module.__dict__.get("__builtins__", builtins)
                    actual = owner.get(name) if type(owner) is dict else getattr(owner, name, None)
                    if actual is not getattr(builtins, name):
                        raise ValueError("projection builtin alias changed: " + name)
        for child in code.co_consts:
            if type(child) is types.CodeType:
                walk(child)
    for code in codes:
        walk(code)


def _owned(module, filename, digest):
    if Path(module.__file__).resolve() != HERE / filename:
        raise ValueError("projection helper origin changed: " + filename)
    compiled, tree = _image(HERE / filename, digest)
    codes = {child.co_name: child for child in compiled.co_consts if type(child) is types.CodeType}
    functions = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            function = vars(module).get(node.name)
            _function(function, module, codes[node.name], node, filename + ":" + node.name)
            functions.append((module, node.name, function, function.__code__, function.__defaults__,
                None if function.__kwdefaults__ is None else dict(function.__kwdefaults__)))
    _imports(module, tree)
    _globals(module, tree, codes.values())
    return functions


def _dependency_function(function, module, class_name, name):
    """Check original installed source before taking callable identity pins."""
    compiled, tree = _image(module.__file__)
    if class_name:
        compiled = next(c for c in compiled.co_consts if type(c) is types.CodeType and c.co_name == class_name)
        tree_nodes = next(n.body for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name)
    else:
        tree_nodes = tree.body
    code = next(c for c in compiled.co_consts if type(c) is types.CodeType and c.co_name == name)
    node = next(n for n in tree_nodes if isinstance(n, ast.FunctionDef) and n.name == name)
    _function(function, module, code, node, module.__name__ + "." + name)
    return (function, module, function.__code__, function.__defaults__,
        None if function.__kwdefaults__ is None else dict(function.__kwdefaults__),
        str(Path(module.__file__).resolve()), hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest())


def _numeric_proof(native=None):
    import numpy as np
    import numpy.core._multiarray_umath as multiarray
    import numpy.core.numerictypes as numerictypes
    import pandas as pd
    import pandas.core.construction as construction
    import pandas.core.frame as frame
    from abides_markets import orders
    import enum
    if (type(np.empty) is not types.BuiltinFunctionType or np.empty is not multiarray.empty
            or np.empty.__name__ != "empty" or np.empty.__module__ != "numpy"
            or np.int64 is not numerictypes.sctypeDict["int64"]
            or np.int32 is not numerictypes.sctypeDict["int32"]
            or np.int64.__name__ != "int64" or np.int64.__module__ != "numpy"
            or np.int32.__name__ != "int32" or np.int32.__module__ != "numpy"
            or pd.array is not construction.array or pd.DataFrame is not frame.DataFrame
            or type(pd.DataFrame) is not type or pd.DataFrame.__module__ != frame.__name__):
        raise ValueError("projection numeric canonical alias changed")
    if (Path(np.__file__).resolve().parent not in Path(multiarray.__file__).resolve().parents
            or not any(str(multiarray.__file__).endswith(s) for s in importlib.machinery.EXTENSION_SUFFIXES)
            or Path(pd.__file__).resolve().parent not in Path(construction.__file__).resolve().parents
            or Path(pd.__file__).resolve().parent not in Path(frame.__file__).resolve().parents):
        raise ValueError("projection numeric dependency origin changed")
    global _dependency_pins
    if _dependency_pins is None:
        _dependency_pins = (_dependency_function(pd.array, construction, None, "array"),
            _dependency_function(pd.DataFrame.__init__, frame, "DataFrame", "__init__"))
    else:
        if type(_dependency_pins) is not tuple or len(_dependency_pins) != 2:
            raise ValueError("projection dependency source-proof pins changed")
        for actual, pin in zip((pd.array, pd.DataFrame.__init__), _dependency_pins):
            function, owner, code, defaults, keywords, path, digest = pin
            if (actual is not function or actual.__code__ is not code or actual.__globals__ is not vars(owner)
                    or actual.__closure__ is not None or actual.__defaults__ != defaults or actual.__kwdefaults__ != keywords
                    or Path(owner.__file__).resolve() != Path(path)
                    or hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest):
                raise ValueError("projection dependency callable changed after source proof")
    pins = json.loads((HERE / "RUNTIME_PINS.json").read_text())
    side_pin = next(row for row in pins["files"] if row["path"].endswith("/orders.py"))
    compiled, tree = _image(HERE / "runtime" / side_pin["path"], side_pin["sha256"])
    side = orders.Side
    if (Path(orders.__file__).resolve() != HERE / "runtime" / side_pin["path"]
            or type(side) is not enum.EnumMeta or side.__module__ != orders.__name__
            or side.__bases__ != (enum.Enum,) or tuple(side.__members__) != ("BID", "ASK")
            or side.BID is not side.__members__["BID"] or side.ASK is not side.__members__["ASK"]
            or side.BID.value != "BID" or side.ASK.value != "ASK"):
        raise ValueError("projection Side owner or members changed")
    side_code = next(c for c in compiled.co_consts if type(c) is types.CodeType and c.co_name == "Side")
    side_node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Side")
    for name in ("is_bid", "is_ask"):
        code = next(c for c in side_code.co_consts if type(c) is types.CodeType and c.co_name == name)
        node = next(n for n in side_node.body if isinstance(n, ast.FunctionDef) and n.name == name)
        _function(getattr(side, name), orders, code, node, "Side." + name)
    values = (np, pd, np.empty, np.int64, np.int32, pd.array, pd.DataFrame, pd.DataFrame.__init__,
        side, side.BID, side.ASK)
    global _numeric
    if _numeric is not None and (type(_numeric) is not tuple or len(_numeric) != len(values)
            or any(a is not b for a, b in zip(_numeric, values))):
        raise ValueError("projection numeric binding changed after clean preflight")
    if native is not None and (native.np is not np or native.pd is not pd or native.Side is not side):
        raise ValueError("projection compiled numeric/Side cross-binding changed")
    return values


def authenticate_helpers(native=None):
    """Raise on changed live helpers before initialization or row conversion."""
    global _retained, _numeric, _generation
    pins = json.loads((HERE / "SOURCE_PINS.json").read_text())["candidate_sources"]
    # Authenticate the fixed proof owner before its mutable dispatch roster is
    # consulted. Shortening HELPERS cannot remove its own proof from admission.
    _owned(sys.modules[__name__], "live_binding.py", pins["live_binding.py"])
    modules = [(importlib.import_module(name), name + ".py") for name in HELPERS]
    for name in ENTRIES:
        # Some common screen wrappers load cli.py as 'agent'. File ownership
        # finds every actual alias, including __main__, without assuming its
        # import name is identical to the candidate source filename.
        expected_path = HERE / (name + ".py")
        seen_modules = set()
        for module in tuple(sys.modules.values()):
            if (isinstance(module, types.ModuleType) and getattr(module, "__file__", None)
                    and Path(module.__file__).resolve() == expected_path and id(module) not in seen_modules):
                modules.append((module, name + ".py"))
                seen_modules.add(id(module))
    functions = []
    for module, filename in modules:
        functions.extend(_owned(module, filename, pins[filename]))
    if _retained is not None:
        for module, name, function, code, defaults, keywords in _retained:
            current = vars(module).get(name)
            if (current is not function or current.__code__ is not code
                    or current.__defaults__ != defaults or current.__kwdefaults__ != keywords):
                raise ValueError("projection helper changed after clean preflight: " + name)
    numeric = _numeric_proof(native)
    if _retained is None:
        _retained = tuple(functions)
        _numeric = numeric
    else:
        known = {(id(module), name) for module, name, *_ in _retained}
        _retained += tuple(row for row in functions if (id(row[0]), row[1]) not in known)
    _generation += 1
    return {"live_binding_generation": _generation, "source_derived_live_helper_proof": True,
        "numeric_side_crossbindings_checked": True, "namespace_exec": False}
