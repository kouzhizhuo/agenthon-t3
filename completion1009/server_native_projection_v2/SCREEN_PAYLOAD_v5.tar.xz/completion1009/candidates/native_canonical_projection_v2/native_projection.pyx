# cython: language_level=3
"""Connected exact observer projection; original records stay Python-owned."""
from libc.stdlib cimport calloc, malloc, free
from libc.stdint cimport int64_t, int32_t, uint64_t, uint8_t
from libc.stddef cimport size_t
cimport cython
import numpy as np
import pandas as pd
from abides_markets.orders import Side

PROJECTION_FORMAT = "observer_contract_typed_rows_stable_merge_v1"
TRACE_COLUMNS = ("t_ns", "agent_id", "msg_type", "side", "price", "size", "order_id")
TRACE_DTYPES = {"t_ns": "int64", "agent_id": "int32", "msg_type": "string",
    "side": "string", "price": "int64", "size": "int64", "order_id": "int64"}
cdef tuple MESSAGE_NAMES = ("ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_EXECUTED",
    "ORDER_CANCELLED", "ORDER_REPLACED", "PARTIAL_FILL", "ORDER_FILLED", "QUOTE_UPDATE")
cdef tuple SIDE_NAMES = (None, "BID", "ASK")
cdef object NP_INT64 = np.int64
cdef object NP_INT32 = np.int32
cdef object SIDE_TYPE = Side
cdef Py_ssize_t MAX_INDEX = 9223372036854775807

cdef struct Row:
    int64_t timestamp
    int64_t order_id
    int64_t price
    int64_t quantity
    int32_t agent_id
    uint8_t kind
    uint8_t side

cdef struct Slot:
    int64_t key
    Py_ssize_t row
    uint8_t side
    uint8_t used

cdef uint64_t mix(uint64_t x) noexcept nogil:
    x ^= x >> 30
    x *= <uint64_t>0xbf58476d1ce4e5b9
    x ^= x >> 27
    x *= <uint64_t>0x94d049bb133111eb
    return x ^ (x >> 31)

cdef Py_ssize_t locate(Slot* slots, Py_ssize_t capacity, int64_t key, uint8_t side) noexcept nogil:
    cdef Py_ssize_t position = <Py_ssize_t>(mix(<uint64_t>key ^ (side * <uint64_t>0x9e3779b97f4a7c15)) & <uint64_t>(capacity - 1))
    while slots[position].used and (slots[position].key != key or slots[position].side != side):
        position = (position + 1) & (capacity - 1)
    return position

cdef class Index:
    cdef Slot* slots
    cdef Py_ssize_t capacity
    cdef Py_ssize_t count

    def __cinit__(self):
        self.slots = NULL
        self.capacity = 0
        self.count = 0

    def __dealloc__(self):
        if self.slots != NULL:
            free(self.slots)

    cdef void grow(self) except *:
        cdef Py_ssize_t capacity
        cdef Slot* replacement
        cdef Py_ssize_t i, position
        if self.capacity > MAX_INDEX // 2:
            raise MemoryError("projection index capacity")
        capacity = 64 if self.capacity == 0 else self.capacity * 2
        if capacity <= self.capacity or <size_t>capacity > (<size_t>-1) // sizeof(Slot):
            raise MemoryError("projection index capacity")
        replacement = <Slot*>calloc(<size_t>capacity, sizeof(Slot))
        if replacement == NULL:
            raise MemoryError("projection index allocation")
        for i in range(self.capacity):
            if self.slots[i].used:
                position = locate(replacement, capacity, self.slots[i].key, self.slots[i].side)
                replacement[position] = self.slots[i]
        if self.slots != NULL:
            free(self.slots)
        self.slots = replacement
        self.capacity = capacity

    cdef Py_ssize_t slot(self, int64_t key, uint8_t side, bint create) except -2:
        cdef Py_ssize_t position
        if self.capacity == 0:
            if not create:
                return -1
            self.grow()
        position = locate(self.slots, self.capacity, key, side)
        if self.slots[position].used:
            return position
        if not create:
            return -1
        if self.count >= self.capacity // 2:
            self.grow()
            position = locate(self.slots, self.capacity, key, side)
        self.slots[position].used = 1
        self.slots[position].key = key
        self.slots[position].side = side
        self.slots[position].row = -1
        self.count += 1
        return position

cdef bint integer53(object value):
    return (type(value) is int or type(value) is NP_INT64 or type(value) is NP_INT32) and -(1 << 53) <= value <= (1 << 53)

cdef int kind_code(object value):
    if type(value) is not str:
        return -1
    if value == "ORDER_SUBMITTED": return 0
    if value == "ORDER_ACCEPTED": return 1
    if value == "ORDER_EXECUTED": return 2
    if value == "ORDER_CANCELLED": return 3
    if value == "ORDER_REPLACED": return 4
    return -1

cdef int side_code(object value, dict cache):
    cdef object text, found
    if value is None:
        return 0
    found = cache.get(value)
    if found is not None:
        return found
    if type(value) is SIDE_TYPE:
        text = value.value
        if text == "BID": found = 1
        elif text == "ASK": found = 2
        else: found = 0
    else:
        text = value.upper()
        found = 1 if "BID" in text else (2 if "ASK" in text else 0)
    cache[value] = found
    return found

cdef bint before(Row* rows, Py_ssize_t a, Py_ssize_t b) noexcept nogil:
    return rows[a].timestamp < rows[b].timestamp or (
        rows[a].timestamp == rows[b].timestamp and rows[a].order_id <= rows[b].order_id)

cdef Py_ssize_t stable_merge(Row* rows, Py_ssize_t* permutation, Py_ssize_t* scratch, Py_ssize_t count) noexcept nogil:
    cdef Py_ssize_t width = 1
    cdef Py_ssize_t start, middle, end, left, right, dest, i, passes = 0
    while width < count:
        start = 0
        while start < count:
            middle = start + (width if width < count - start else count - start)
            end = middle + (width if width < count - middle else count - middle)
            left, right, dest = start, middle, start
            while left < middle and right < end:
                if before(rows, permutation[left], permutation[right]):
                    scratch[dest] = permutation[left]
                    left += 1
                else:
                    scratch[dest] = permutation[right]
                    right += 1
                dest += 1
            while left < middle:
                scratch[dest] = permutation[left]
                left += 1
                dest += 1
            while right < end:
                scratch[dest] = permutation[right]
                right += 1
                dest += 1
            start = end
        for i in range(count):
            permutation[i] = scratch[i]
        passes += 1
        if width > count // 2:
            break
        width *= 2
    return passes

cdef object reject(str reason):
    return None, {"native_projection_active": False, "fallback_used": True,
        "implementation": PROJECTION_FORMAT, "reason": reason}

cpdef project_contract(object groups, object has_scalar):
    """Return a typed frame/witness or refuse before the original replay call.

    groups preserve original Agent iteration and each Agent's emission order.
    Exact supported scalars cannot call user methods during the native scan.
    Quotes occupy the tail of one row arena so insertion order is separate from
    order emission order, matching original lifecycle-then-quote concatenation.
    """
    cdef Py_ssize_t capacity = 0, order_count = 0, quote_count = 0, quote_records = 0
    cdef Py_ssize_t i, j, p, row_index, count, passes, final_lookups = 0
    cdef Row* rows = NULL
    cdef Py_ssize_t* permutation = NULL
    cdef Py_ssize_t* scratch = NULL
    cdef Index fills = Index()
    cdef Index quotes = Index()
    cdef dict side_cache = {}
    cdef object group, records, record, timestamp, event_type, kind, data
    cdef object aid, oid, side, quantity, price, fill_price, symbol, agent_id
    cdef int code, scode
    cdef int64_t time_value
    cdef object times, ids, prices, quantities, order_ids, message_types, sides, frame
    cdef int64_t[::1] time_view, price_view, quantity_view, order_view
    cdef int32_t[::1] id_view
    if type(groups) is not list or type(has_scalar) is not bool:
        return reject("unsupported_groups_or_scalar_witness")
    for group in groups:
        if type(group) is not tuple or len(group) != 2 or type(group[1]) is not list:
            return reject("unsupported_group")
        records = group[1]
        if len(records) > MAX_INDEX - capacity:
            raise MemoryError("projection record count")
        capacity += len(records)
    if capacity == 0 or not has_scalar:
        return reject("empty_contract_or_absent_scalar")
    if <size_t>capacity > (<size_t>-1) // sizeof(Row):
        raise MemoryError("projection row capacity")
    rows = <Row*>malloc(<size_t>capacity * sizeof(Row))
    if rows == NULL:
        raise MemoryError("projection row allocation")
    try:
        for group in groups:
            agent_id, records = group
            for record in records:
                if type(record) is not tuple or len(record) != 4:
                    return reject("unsupported_record")
                timestamp, event_type, kind, data = record
                # Parent admits isinstance(int,np.int64) timestamps, including
                # bool; custom integer subclasses retain original callbacks.
                if type(timestamp) is int or type(timestamp) is NP_INT64 or type(timestamp) is bool:
                    if not -(1 << 63) <= timestamp < (1 << 63):
                        return reject("timestamp_outside_int64")
                    time_value = timestamp
                elif type(timestamp) is float or type(timestamp) is str or type(timestamp) is NP_INT32 or timestamp is None:
                    time_value = 0
                else:
                    return reject("timestamp_callback_or_unknown_domain")
                if type(kind) is not str or kind == "raw":
                    return reject("raw_or_custom_contract")
                if kind == "order" or kind == "market":
                    code = kind_code(event_type)
                    if code < 0 or type(data) is not tuple or len(data) != 6:
                        return reject("unsupported_order_record")
                    aid, oid, side, quantity, price, fill_price = data
                    if oid is None:
                        continue
                    if aid is None:
                        aid = agent_id
                    if code == 2:
                        price = fill_price
                    if (not integer53(oid) or not integer53(aid) or not -(1 << 31) <= aid < (1 << 31)
                            or not integer53(quantity) or (price is not None and not integer53(price))
                            or (side is not None and type(side) is not SIDE_TYPE and type(side) is not str)):
                        return reject("order_numeric_or_side_domain")
                    scode = side_code(side, side_cache)
                    row_index = order_count
                    rows[row_index].timestamp = time_value
                    rows[row_index].agent_id = aid
                    rows[row_index].order_id = oid
                    rows[row_index].quantity = quantity
                    rows[row_index].price = 0 if price is None else price
                    rows[row_index].kind = code
                    rows[row_index].side = scode
                    if code == 2:
                        p = fills.slot(rows[row_index].order_id, 0, True)
                        final_lookups += 1
                        if fills.slots[p].row < 0 or time_value >= rows[fills.slots[p].row].timestamp:
                            fills.slots[p].row = row_index
                    order_count += 1
                elif kind == "quote":
                    if type(event_type) is not str or event_type not in ("BEST_BID", "BEST_ASK") or type(data) is not tuple or len(data) != 3:
                        return reject("unsupported_quote_record")
                    symbol, price, quantity = data
                    if (type(symbol) is not str or "," in symbol or not integer53(price) or not integer53(quantity)
                            or not integer53(agent_id) or not -(1 << 31) <= agent_id < (1 << 31)):
                        return reject("quote_numeric_or_symbol_domain")
                    scode = 1 if event_type == "BEST_BID" else 2
                    p = quotes.slot(time_value, scode, True)
                    if quotes.slots[p].row < 0:
                        quotes.slots[p].row = capacity - 1 - quote_count
                        quote_count += 1
                    row_index = quotes.slots[p].row
                    rows[row_index].timestamp = time_value
                    rows[row_index].agent_id = agent_id
                    rows[row_index].order_id = -1
                    rows[row_index].quantity = quantity
                    rows[row_index].price = price
                    rows[row_index].kind = 7
                    rows[row_index].side = scode
                    quote_records += 1
                else:
                    return reject("unknown_record_kind")
        if order_count == 0:
            return reject("absent_lifecycle_rows")
        count = order_count + quote_count
        if <size_t>count > (<size_t>-1) // sizeof(Py_ssize_t):
            raise MemoryError("projection sort capacity")
        permutation = <Py_ssize_t*>malloc(<size_t>count * sizeof(Py_ssize_t))
        scratch = <Py_ssize_t*>malloc(<size_t>count * sizeof(Py_ssize_t))
        if permutation == NULL or scratch == NULL:
            raise MemoryError("projection sort allocation")
        for i in range(order_count):
            if rows[i].kind == 2:
                p = fills.slot(rows[i].order_id, 0, False)
                rows[i].kind = 6 if fills.slots[p].row == i else 5
            permutation[i] = i
        for i in range(quote_count):
            permutation[order_count + i] = capacity - 1 - i
        with nogil:
            passes = stable_merge(rows, permutation, scratch, count)
        times = np.empty(count, dtype=np.int64)
        ids = np.empty(count, dtype=np.int32)
        prices = np.empty(count, dtype=np.int64)
        quantities = np.empty(count, dtype=np.int64)
        order_ids = np.empty(count, dtype=np.int64)
        time_view, id_view = times, ids
        price_view, quantity_view, order_view = prices, quantities, order_ids
        message_types, sides = [None] * count, [None] * count
        for i in range(count):
            j = permutation[i]
            time_view[i] = rows[j].timestamp
            id_view[i] = rows[j].agent_id
            price_view[i] = rows[j].price
            quantity_view[i] = rows[j].quantity
            order_view[i] = rows[j].order_id
            message_types[i] = MESSAGE_NAMES[rows[j].kind]
            sides[i] = SIDE_NAMES[rows[j].side]
        frame = pd.DataFrame({"t_ns": times, "agent_id": ids,
            "msg_type": pd.array(message_types, dtype="string"), "side": pd.array(sides, dtype="string"),
            "price": prices, "size": quantities, "order_id": order_ids}, columns=TRACE_COLUMNS)
        return frame, {"native_projection_active": True, "fallback_used": False,
            "implementation": PROJECTION_FORMAT, "input_contract_records": capacity,
            "lifecycle_rows": order_count, "quote_records": quote_records,
            "unique_quote_rows": quote_count, "final_execution_lookups": final_lookups,
            "stable_sort_rows": count, "stable_merge_passes": passes,
            "typed_numeric_write_rows": count, "distinct_side_values": len(side_cache),
            "python_row_lists_created": 0, "python_sort_key_callbacks": 0}
    finally:
        if scratch != NULL: free(scratch)
        if permutation != NULL: free(permutation)
        if rows != NULL: free(rows)
