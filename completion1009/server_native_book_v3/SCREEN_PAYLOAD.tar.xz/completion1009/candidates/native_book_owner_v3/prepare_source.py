#!/usr/bin/env python3
"""Emit a declared, source-bound Cython owner; never compile or simulate."""
import ast
import copy
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BOOK = ROOT / "runtime/vendor/abides/abides-markets/abides_markets/order_book.py"
LEVEL = ROOT / "runtime/vendor/abides/abides-markets/abides_markets/price_level.py"
EXPECTED = {
    "order_book.py": "12b470bfe815764cf025a5383d7d0d2c2703e802a81be63488d0dd7883c31624",
    "price_level.py": "d448ccf12f49c8078994c6d1d2ca150bfed169dbfa393fcfd4d8bc7e4eb9c1b1",
}
LEVEL_DIRECT = {"add_order", "update_order_quantity", "remove_order", "peek", "pop",
                "order_is_match", "order_has_better_price", "order_has_worse_price",
                "order_has_equal_price", "total_quantity", "is_empty"}
BOOK_DIRECT = {"handle_limit_order", "handle_market_order", "execute_order", "enter_order",
               "cancel_order", "modify_order", "partial_cancel_order", "replace_order",
               "append_book_log2", "get_l1_bid_data", "get_l1_ask_data", "get_l2_bid_data",
               "get_l2_ask_data", "get_l3_bid_data", "get_l3_ask_data",
               "get_transacted_volume", "get_imbalance"}
DECLARATIONS = {
    "handle_limit_order": "cdef NativeLevel level",
    "handle_market_order": "cdef NativeLevel level",
    "execute_order": "cdef NativeLevel level",
    "enter_order": "cdef NativeLevel price_level",
    "cancel_order": "cdef NativeLevel price_level",
    "modify_order": "cdef NativeLevel price_level",
    "partial_cancel_order": "cdef NativeLevel price_level",
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def signature(node, native=False):
    args = copy.deepcopy(node.args)
    for arg in args.posonlyargs + args.args + args.kwonlyargs:
        arg.annotation = None
    text = ast.unparse(args)
    if native:
        # Every semantic scalar stays a Python object; only owner/loop topology
        # is statically typed. Defaults are emitted from the original AST.
        rendered = []
        first_default = len(args.args) - len(args.defaults)
        for i, arg in enumerate(args.args):
            item = arg.arg if i == 0 else "object " + arg.arg
            if i >= first_default:
                item += "=" + ast.unparse(args.defaults[i - first_default])
            rendered.append(item)
        text = ", ".join(rendered)
    return text


def body(node):
    nodes = copy.deepcopy(node.body)
    if nodes and isinstance(nodes[0], ast.Expr) and isinstance(nodes[0].value, ast.Constant) and isinstance(nodes[0].value.value, str):
        nodes = nodes[1:]
    class StripAnnotations(ast.NodeTransformer):
        def visit_AnnAssign(self, child):
            if child.value is None:
                raise ValueError("annotation without assignment is unsupported")
            return ast.copy_location(ast.Assign(targets=[child.target], value=child.value), child)
    tree = StripAnnotations().visit(ast.Module(body=nodes, type_ignores=[]))
    ast.fix_missing_locations(tree)
    return ast.unparse(tree)


def indent(text, spaces=8):
    return "\n".join(" " * spaces + line if line else "" for line in text.splitlines())


def transform_level(node):
    text = body(node)
    for name in LEVEL_DIRECT - {"total_quantity", "is_empty"}:
        text = text.replace("self." + name + "(", "self._" + name + "(")
    text = text.replace("self.total_quantity", "self._total_quantity()")
    if node.name == "total_quantity":
        text = "quantities = []\nfor order, _ in self.visible_orders:\n    quantities.append(order.quantity)\nreturn sum(quantities)"
    return text


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError("source shape differs: " + before)
    return text.replace(before, after, 1)


def transform_book(node):
    text = body(node)
    for name in sorted(BOOK_DIRECT, key=len, reverse=True):
        text = text.replace("self." + name + "(", "self._" + name + "(")
    text = text.replace("PriceLevel([", "NativeLevel([")
    for stem in ("book[0]", "book[1]", "book[-1]", "book[i]", "opp[0]", "self.bids[0]", "self.asks[0]", "self.asks[index]", "self.bids[index]"):
        for name in LEVEL_DIRECT - {"total_quantity", "is_empty"}:
            text = text.replace(stem + "." + name + "(", "(<NativeLevel>" + stem + ")._" + name + "(")
        text = text.replace(stem + ".total_quantity", "(<NativeLevel>" + stem + ")._total_quantity()")
        text = text.replace(stem + ".is_empty", "(<NativeLevel>" + stem + ")._is_empty()")
    for name in LEVEL_DIRECT - {"total_quantity", "is_empty"}:
        text = text.replace("price_level." + name + "(", "price_level._" + name + "(")
    text = text.replace("price_level.total_quantity", "price_level._total_quantity()")
    text = text.replace("price_level.is_empty", "price_level._is_empty()")
    # Cython3.1.3 cdef calls cannot skip earlier optional positions by keyword.
    # Emit the exact original defaults explicitly; these are all None/False.
    text = text.replace("self._cancel_order(resting, quiet=quiet)", "self._cancel_order(resting, None, None, quiet)")
    text = text.replace("self._enter_order(deepcopy(order), quiet=quiet)", "self._enter_order(deepcopy(order), None, quiet)")
    text = text.replace("self._cancel_order(metadata['ptc_other_half'], quiet=True)", "self._cancel_order(metadata['ptc_other_half'], None, None, True)")
    text = text.replace("self._cancel_order(old_order, quiet=True)", "self._cancel_order(old_order, None, None, True)")
    if node.name in ("get_l2_bid_data", "get_l2_ask_data"):
        side = "bids" if node.name == "get_l2_bid_data" else "asks"
        # Slice and compute every row before filtering, as in the original.
        text = f"rows = []\nfor price_level in self.{side}[:depth]:\n    rows.append((price_level.price, price_level._total_quantity()))\nreturn list(filter(_positive_row, rows))"
        DECLARATIONS[node.name] = "cdef NativeLevel price_level"
    elif node.name in ("get_l3_bid_data", "get_l3_ask_data"):
        side = "bids" if node.name == "get_l3_bid_data" else "asks"
        text = f"rows = []\nfor price_level in self.{side}[:depth]:\n    quantities = []\n    for order, _ in price_level.visible_orders:\n        quantities.append(order.quantity)\n    rows.append((price_level.price, quantities))\nreturn rows"
        DECLARATIONS[node.name] = "cdef NativeLevel price_level"
    elif node.name == "get_imbalance":
        text = replace_once(text, "bid_vol = sum((price_level._total_quantity() for price_level in self.bids))", "bid_quantities = []\nfor price_level in self.bids:\n    bid_quantities.append(price_level._total_quantity())\nbid_vol = sum(bid_quantities)")
        text = replace_once(text, "ask_vol = sum((price_level._total_quantity() for price_level in self.asks))", "ask_quantities = []\nfor price_level in self.asks:\n    ask_quantities.append(price_level._total_quantity())\nask_vol = sum(ask_quantities)")
        DECLARATIONS[node.name] = "cdef NativeLevel price_level"
    if node.name in {"execute_order", "cancel_order", "enter_order"}:
        key = {"execute_order": "match", "cancel_order": "cancel", "enter_order": "insert"}[node.name]
        text = f"self._witness['{key}'] += 1\n" + text
    elif node.name.startswith(("get_l1_", "get_l2_", "get_l3_")) or node.name in {"get_transacted_volume", "get_imbalance"}:
        text = "self._witness['read'] += 1\n" + text
    return text


def facade(node, property_method=False):
    args = [arg.arg for arg in node.args.args[1:]]
    prefix = "    @property\n" if property_method else ""
    return prefix + "    def " + node.name + "(" + signature(node) + "):\n" + indent("return self._" + node.name + "(" + ", ".join(args) + ")") + "\n"


def main():
    sources = {}
    for path in (BOOK, LEVEL):
        data = path.read_bytes()
        if sha(data) != EXPECTED[path.name]:
            raise ValueError("frozen original differs: " + path.name)
        sources[path.name] = data.decode()
    book_tree, level_tree = (ast.parse(sources[name]) for name in ("order_book.py", "price_level.py"))
    book_cls = next(n for n in book_tree.body if isinstance(n, ast.ClassDef))
    level_cls = next(n for n in level_tree.body if isinstance(n, ast.ClassDef))
    header = '''# Generated by prepare_source.py from authenticated original ASTs.
# Compilation and simulation are separate root-scheduled operations.
import logging
import sys
import warnings
from copy import deepcopy
import numpy as np
import pandas as pd
from abides_core.utils import str_to_ns, ns_date
from abides_markets.messages.orderbook import OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg, OrderPartialCancelledMsg, OrderModifiedMsg, OrderReplacedMsg
from abides_markets.orders import LimitOrder, MarketOrder, Order, Side
from abides_markets.price_level import PriceLevel as OriginalPriceLevel
from abides_markets.order_book import OrderBook as OriginalOrderBook
from abides_markets.order_book import logger

def _positive_row(row):
    return row[1] > 0

'''
    parts = [header, "cdef class NativeLevel:\n    cdef dict __dict__\n"]
    for node in level_cls.body:
        if not isinstance(node, ast.FunctionDef):
            continue
        if node.name == "__init__":
            text = transform_level(node)
            parts.append("    def __init__(" + signature(node) + "):\n" + indent(text) + "\n")
        elif node.name == "__eq__":
            text = "if not isinstance(other, NativeLevel):\n    raise NotImplementedError\nreturn self.visible_orders == other.visible_orders and self.hidden_orders == other.hidden_orders"
            parts.append("    def __eq__(self, other):\n" + indent(text) + "\n")
        else:
            parts.append(facade(node, bool(node.decorator_list)))
            parts.append("    cdef object _" + node.name + "(" + signature(node, True) + "):\n" + indent(transform_level(node)) + "\n")
    parts.append("\ncdef class NativeBook:\n    cdef dict __dict__\n    cdef object _witness\n")
    for node in book_cls.body:
        if not isinstance(node, ast.FunctionDef):
            continue
        if node.name == "__init__":
            text = "self._witness = {'match': 0, 'cancel': 0, 'insert': 0, 'read': 0}\n" + body(node)
            parts.append("    def __init__(" + signature(node) + "):\n" + indent(text) + "\n")
        elif node.name in BOOK_DIRECT:
            parts.append(facade(node))
            text = transform_book(node)
            declaration = DECLARATIONS.get(node.name)
            if declaration:
                text = declaration + "\n" + text
            parts.append("    cdef object _" + node.name + "(" + signature(node, True) + "):\n" + indent(text) + "\n")
        else:
            parts.append("    def " + node.name + "(" + signature(node) + "):\n" + indent(transform_book(node)) + "\n")
    parts.append("    def proof_counts(self):\n        return dict(self._witness)\n")
    emitted = "\n".join(parts)
    output = HERE / "native_book.pyx"
    if output.exists():
        raise ValueError("generated owner exists; preserve it before preparing another revision")
    output.write_text(emitted)
    record = {"schema": "t3-native-book-owner-source-v1", "candidate": "native_book_owner_v3",
              "original_sources": EXPECTED, "generator_sha256": sha(Path(__file__).read_bytes()),
              "native_source_sha256": sha(output.read_bytes()),
              "level_cdef_methods": sorted(LEVEL_DIRECT), "book_cdef_methods": sorted(BOOK_DIRECT),
              "source_generated": True, "native_compiled": False, "finite_controls_run": False,
              "market_run": False, "timing_claim": False, "rankable": False}
    (HERE / "SOURCE_PREPARATION.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps(record, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
