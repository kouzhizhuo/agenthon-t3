# Configured latency standalone controls V1.5

Fresh source-only control-observation repair of actual V1.4 run 37985994009. Native pyx, owned C/header, setup and NumPy authentication are exact V1.4 bytes; numeric strategy, RNG draws, admission guard and native export are unchanged. Source receipt filename references advance to V1.5.

The two export-helper mutation sample calls run while the helper is patched. Before restoration, the control records zero replacement calls and completed permanent handoff (owned false, handoffs one). Only after finally restoring the helper does it call RandomState.get_state, because the original NumPy1.26.4 MT19937.state getter allocates np.zeros(624,dtype=np.uint32). Full actual624 states are compared, then double release must preserve the prior diagnostics. New raw witnesses expose both phases and must be independently checked.

The original/new/new-repeat 24 models and 4410 calls per arm,96 transforms, constructor errors, class/token/lookup/alias/BaseException controls remain. No participant import, native translation/build, RNG draws, market run, server operation, speed or official submission occurred in this preparation. Fresh independent source review and actual pinned Linux complete raw controls are required.
