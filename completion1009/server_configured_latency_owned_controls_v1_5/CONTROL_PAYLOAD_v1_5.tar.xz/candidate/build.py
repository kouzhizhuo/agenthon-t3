"""Future isolated Linux build with generated-source/compiler/library receipt."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--review", type=Path, required=True)
    parser.add_argument("--review-sha256", required=True)
    args = parser.parse_args()
    if sys.platform != "linux" or platform.machine() != "x86_64" or args.receipt.exists():
        raise ValueError("fresh isolated Linux amd64 receipt required")
    source = HERE / "SOURCE_PREPARATION_RECEIPT_v1_5.json"
    prepared, reviewed = json.loads(source.read_text()), json.loads(args.review.read_text())
    if pin(args.review)["sha256"] != args.review_sha256 or reviewed["status"] != "PASS_SOURCE_ONLY" or reviewed["unresolved_source_blockers"] != []:
        raise ValueError("exact independent source PASS required before build")
    if reviewed["reviewed_source_receipt_sha256"] != pin(source)["sha256"] or reviewed["reviewed_files"] != prepared["files"]:
        raise ValueError("exact independently reviewed source roster required")
    for row in prepared["files"]:
        if pin(HERE / row["path"]) != {k: row[k] for k in ("bytes", "sha256")}:
            raise ValueError("frozen source bytes changed")
    import numpy as np
    import Cython
    import setuptools
    if np.__version__ != "1.26.4" or any(HERE.glob("_latency_owned*.so")) or (HERE / "configured_latency.c").exists():
        raise ValueError("pinned NumPy and fresh unbuilt source checkout required")
    command = [sys.executable, "-B", str(HERE / "setup.py"), "build_ext", "--inplace"]
    log_path = args.receipt.with_suffix(".build.log")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("xb") as log:
        result = subprocess.run(command, cwd=HERE, stdout=log, stderr=subprocess.STDOUT, timeout=600,
                                env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    binaries = list(HERE.glob("_latency_owned*.so"))
    if result.returncode or len(binaries) != 1:
        raise ValueError("actual isolated extension build failed")
    compiler = os.environ.get("CC", "cc")
    compiler_text = subprocess.run([compiler, "--version"], capture_output=True, text=True, check=True).stdout
    linked = subprocess.run(["ldd", str(binaries[0])], capture_output=True, text=True, check=True).stdout
    report = {"schema": "t3-configured-latency-owned-actual-build-v1", "source_receipt_sha256": pin(source)["sha256"],
        "independent_review_sha256": args.review_sha256, "python": sys.version, "platform": platform.platform(),
        "versions": {"numpy": np.__version__, "Cython": Cython.__version__, "setuptools": setuptools.__version__},
        "compiler": compiler_text, "ldd": linked, "generated_c": pin(HERE / "configured_latency.c"),
        "extension": {"path": binaries[0].name, **pin(binaries[0])}, "command": command, "log": pin(log_path),
        "rng_or_market_executed": False, "candidate_imported_during_build": False, "rankable": False,
        "numeric_flags": ["-fno-fast-math", "-ffp-contract=off", "-fno-associative-math", "-fno-unsafe-math-optimizations"],
        "complete_numpy_build_graph_claimed": False}
    args.receipt.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__":
    main()
