# cython: language_level=3, boundscheck=False, wraparound=False, cdivision=True
"""Exclusive configured-latency owner: original object and public RNG identity retained."""
from libc.stdint cimport uint32_t, uint64_t
from libc.string cimport memset
from libc.math cimport isnan, isfinite

cdef extern from "owned_legacy.h":
    ctypedef struct t3_owned_state:
        uint32_t key[624]
        int pos
        int has_gauss
        double gauss
        int wide_high_first
        uint64_t words_consumed
        uint64_t twists
        uint64_t normal_rejections
        uint64_t integer_rejections
    double t3_legacy_lognormal(t3_owned_state *, double, double)
    double t3_legacy_uniform(t3_owned_state *, double, double)
    double t3_legacy_pareto(t3_owned_state *, double)


cdef double _finite_clip(double value, double lower, double upper):
    # First finite comparison domain. Equality/sign-zero receives the exact
    # original NumPy postprocess in the owner before this helper is used.
    if value < lower:
        value = lower
    if value > upper:
        value = upper
    return value


def scalar_postprocess(value, lower, upper, original_clip):
    """Control-only admitted transform exposing exact boxed intermediate value."""
    import math
    if (type(value) is not float or type(lower) is not float or type(upper) is not float
            or not math.isfinite(lower) or not math.isfinite(upper)
            or not 0 <= lower <= upper <= 9007199254740992.0 or math.isnan(value)):
        raise ValueError("finite owned clipping domain required")
    clipped = (float(original_clip(value, lower, upper)) if lower == upper or value == lower or value == upper
               else float(_finite_clip(value, lower, upper)))
    return (clipped, int(round(clipped)))


cdef class ConfiguredLatencyOwner:
    cdef object original_model, original_rng, np, original_method, guard, stamp
    cdef object original_asarray, original_uint32, original_set_state
    cdef t3_owned_state state
    cdef unsigned int kind
    cdef double mean, mu, sigma, lower, upper, alpha
    cdef bint owned
    cdef unsigned long native_calls, self_calls, constant_calls, fallback_calls, handoffs, postprocess_handoffs

    def __init__(self, original_model, np, public_tuple, snapshot, guard, stamp, original_method,
                 original_asarray, original_uint32, original_set_state):
        cdef int i
        self.original_model = original_model
        self.original_rng = original_model.random_state
        self.np, self.guard, self.stamp, self.original_method = np, guard, stamp, original_method
        self.original_asarray, self.original_uint32 = original_asarray, original_uint32
        self.original_set_state = original_set_state
        if (type(public_tuple) is not tuple or len(public_tuple) != 5 or public_tuple[0] != "MT19937"
                or type(public_tuple[1]) is not list or len(public_tuple[1]) != 624
                or type(public_tuple[2]) is not int or not 0 <= public_tuple[2] <= 624
                or type(public_tuple[3]) is not int or public_tuple[3] not in (0, 1)
                or type(public_tuple[4]) is not float or not isfinite(public_tuple[4])):
            raise ValueError("exact full public MT19937 state required")
        memset(&self.state, 0, sizeof(t3_owned_state))
        for i in range(624):
            value = public_tuple[1][i]
            if type(value) is not int or not 0 <= value <= 0xffffffff:
                raise ValueError("uint32 public state word required")
            self.state.key[i] = value
        self.state.pos, self.state.has_gauss, self.state.gauss = public_tuple[2], public_tuple[3], public_tuple[4]
        self.state.wide_high_first = 1
        self.kind = {"log_normal": 1, "uniform": 2, "pareto": 3}.get(snapshot["_model"], 0)
        self.mean, self.mu, self.sigma = snapshot["_mean_ns"], snapshot["_mu"], snapshot["_sigma"]
        self.lower, self.upper, self.alpha = snapshot["_min_ns"], snapshot["_max_ns"], snapshot["_alpha"]
        self.owned = True

    cdef object _state_tuple(self):
        cdef int i
        return ("MT19937", [int(self.state.key[i]) for i in range(624)], int(self.state.pos),
                int(self.state.has_gauss), float(self.state.gauss))

    cdef void _export(self) except *:
        cdef object value
        if self.owned:
            value = self._state_tuple()
            self.original_set_state((value[0], self.original_asarray(value[1], dtype=self.original_uint32), value[2], value[3], value[4]))
            self.owned = False
            self.handoffs += 1

    cdef object _original(self, object sender_id, object recipient_id):
        self._export()
        self.fallback_calls += 1
        return self.original_model.get_latency(sender_id, recipient_id)

    cdef object _sample(self, object sender_id, object recipient_id):
        cdef double value, clipped
        if not self.owned:
            return self._original(sender_id, recipient_id)
        # No custom equality or parameter inspection before whole-method route.
        if type(sender_id) is not int or type(recipient_id) is not int:
            return self._original(sender_id, recipient_id)
        # Guard compares retained token/fields/identities only; source hashing and
        # code/default/global authentication occur once during registry creation.
        if not self.guard(self.original_model, self.original_rng, self.stamp):
            return self._original(sender_id, recipient_id)
        if sender_id == recipient_id:
            self.self_calls += 1
            return 0
        if self.kind == 1:
            value = t3_legacy_lognormal(&self.state, self.mu, self.sigma)
        elif self.kind == 2:
            value = t3_legacy_uniform(&self.state, self.lower, self.upper - self.lower)
        elif self.kind == 3:
            value = (self.lower if self.lower > 0.0 else 1.0) * (1.0 + t3_legacy_pareto(&self.state, self.alpha))
        else:
            value = self.mean
            self.constant_calls += 1
        self.native_calls += 1
        if isnan(value) or self.lower == self.upper or value == self.lower or value == self.upper:
            # NaN and equality/signed-zero operand selection use original
            # postprocessing. Preserve the already-drawn value and state. Full
            # get_latency would draw twice, so only original postprocessing runs.
            self._export()
            self.postprocess_handoffs += 1
            return int(round(float(self.np.clip(float(value), self.lower, self.upper))))
        clipped = _finite_clip(value, self.lower, self.upper)
        return int(round(float(clipped)))

    def sample(self, sender_id, recipient_id):
        try:
            return self._sample(sender_id, recipient_id)
        except BaseException:
            # External observers see the authoritative consumed public state
            # before the original exception escapes this standalone owner.
            self._export()
            raise

    def export_to_original(self):
        self._export()

    def state_tuple(self):
        if not self.owned:
            value = self.original_rng.get_state()
            return (value[0], [int(x) for x in value[1]], value[2], value[3], value[4])
        return self._state_tuple()

    def identities(self):
        return (self.original_model, self.original_rng)

    def diagnostics(self):
        return {"owned": bool(self.owned), "native_calls": int(self.native_calls), "self_calls": int(self.self_calls),
                "constant_calls": int(self.constant_calls), "fallback_calls": int(self.fallback_calls),
                "handoffs": int(self.handoffs), "postprocess_handoffs": int(self.postprocess_handoffs),
                "words_consumed": int(self.state.words_consumed), "twists": int(self.state.twists),
                "normal_rejections": int(self.state.normal_rejections)}
