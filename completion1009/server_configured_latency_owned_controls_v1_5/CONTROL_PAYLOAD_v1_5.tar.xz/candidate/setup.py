"""Build only this finite extension; no NumPy headers/private C API or runtime."""
import sys
from setuptools import Extension, setup
from Cython.Build import cythonize

if sys.platform != "linux" or sys.maxsize != (1 << 63) - 1:
    raise RuntimeError("Linux64 build required")
flags = ["-O3", "-std=c99", "-fno-fast-math", "-ffp-contract=off", "-fno-associative-math", "-fno-unsafe-math-optimizations"]
extension = Extension("_latency_owned", ["configured_latency.pyx", "owned_legacy.c"], libraries=["m"], extra_compile_args=flags)
setup(name="t3-configured-latency-owned-control", version="0.0.1", ext_modules=cythonize([extension],
      compiler_directives={"language_level": 3, "boundscheck": False, "wraparound": False, "cdivision": True}))
