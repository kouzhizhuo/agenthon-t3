"""Stdlib-only recomputation of retained latency outcomes/full states; no candidate import."""
import argparse
import json
import math
from pathlib import Path
import struct
from common import CASE_COUNTS, CASE_SPECS, CALLS_PER_ARM, CANDIDATE_SHA256, sha, write


def require(ok, message):
    if not ok:
        raise ValueError(message)


def scalar_shape(value):
    require(type(value) is dict and type(value.get("type")) is str, "retained scalar shape absent")
    kind = value["type"]
    if kind in ("builtins.float", "numpy.float64"):
        require(set(value) == {"type", "bits"} and type(value["bits"]) is str and len(value["bits"]) == 16,
                "retained float bits absent")
        struct.unpack("!d", bytes.fromhex(value["bits"]))
    elif kind in ("builtins.int", "numpy.int64"):
        require(set(value) == {"type", "value"} and type(value["value"]) is str
                and str(int(value["value"])) == value["value"], "retained integer type/value absent")
    elif kind == "builtins.NoneType":
        require(set(value) == {"type"}, "None record differs")
    elif kind == "builtins.str":
        require(set(value) == {"type", "value"} and type(value["value"]) is str, "string record differs")
    elif kind == "numpy.ndarray":
        require(set(value) == {"type", "dtype", "shape", "bytes"} and type(value["dtype"]) is str
                and type(value["shape"]) is list and all(type(v) is int and v >= 0 for v in value["shape"]), "array record differs")
        bytes.fromhex(value["bytes"])
    else:
        raise ValueError("unretained scalar type")


def outcome_shape(value):
    require(type(value) is dict and type(value.get("returned")) is bool and type(value.get("warnings")) is list,
            "outcome/exception/warnings absent")
    require(all(type(v) is dict and set(v) == {"type", "message"}
                and all(type(v[k]) is str for k in v) for v in value["warnings"]), "warning category/message absent")
    if value["returned"]:
        require(set(value) == {"returned", "result", "warnings"}, "return outcome roster differs")
        scalar_shape(value["result"])
    else:
        require(set(value) == {"returned", "error_type", "message", "warnings"}
                and type(value["error_type"]) is str and type(value["message"]) is str, "exception outcome roster differs")


def state_shape(value):
    require(type(value) is dict and set(value) == {"kind", "words_le_hex", "position", "has_gauss", "gauss_bits"}
            and value["kind"] == "MT19937" and type(value["position"]) is int and 0 <= value["position"] <= 624
            and type(value["has_gauss"]) is int and value["has_gauss"] in (0, 1)
            and type(value["words_le_hex"]) is str and len(value["words_le_hex"]) == 4992
            and type(value["gauss_bits"]) is str and len(value["gauss_bits"]) == 16, "full public624 state absent")
    struct.unpack("<624I", bytes.fromhex(value["words_le_hex"]))
    require(math.isfinite(struct.unpack("!d", bytes.fromhex(value["gauss_bits"]))[0]), "nonfinite public Gaussian cache")


def same_states(values, count=3):
    require(type(values) is list and len(values) == count, "actual state arm roster differs")
    for value in values:
        state_shape(value)
    require(all(value == values[0] for value in values), "actual complete public state differs")


def same_outcomes(values, count=3):
    require(type(values) is list and len(values) == count, "outcome arm roster differs")
    for value in values:
        outcome_shape(value)
    require(all(value == values[0] for value in values), "actual result/error/warning differs")


def check_controls(value, build):
    build = Path(build)
    receipt = build / "BUILD_RECEIPT.json"
    require(value.get("schema") == "t3-configured-latency-standalone-controls-v1-5" and value.get("all_passed") is True
            and "failure" not in value and value.get("source_receipt_sha256") == CANDIDATE_SHA256
            and value.get("build_receipt") == {"bytes": receipt.stat().st_size, "sha256": sha(receipt)}
            and all(value.get(name) is False for name in ("rankable", "market_executed", "arena_modified")),
            "finite latency raw source/build/scope differs")
    transforms = value.get("transforms")
    require(type(transforms) is list and len(transforms) == 96, "fixed96 transforms absent")
    expected_values = [-0.0, 0.0, -1.0, 0.5, 1.5, 2.5, 3.0,
        math.nextafter(0.5, 0.0), math.nextafter(0.5, 1.0), math.nextafter(1.5, 1.0), math.nextafter(1.5, 2.0),
        float(2 ** 52 - 0.5), float(2 ** 52), float(2 ** 53), float("inf"), float("-inf")]
    expected_transforms = [(v, lo, hi) for lo, hi in ((0.0, 3.0), (-0.0, 0.0), (0.0, -0.0), (-0.0, -0.0), (1.5, 1.5), (0.0, float(2 ** 53))) for v in expected_values]
    for row, (original, lower, upper) in zip(transforms, expected_transforms):
        require(set(row) == {"value", "lower", "upper", "baseline_intermediate", "new_intermediate", "baseline_result", "new_result"}, "transform record differs")
        for key, expected in (("value", original), ("lower", lower), ("upper", upper)):
            require(row[key] == {"type": "builtins.float", "bits": struct.pack("!d", expected).hex()}, "actual transform source inputs differ")
        for key in row:
            scalar_shape(row[key])
        require(row["baseline_intermediate"] == row["new_intermediate"] and row["baseline_result"] == row["new_result"], "clip bits/int differ")
        intermediate = struct.unpack("!d", bytes.fromhex(row["baseline_intermediate"]["bits"]))[0]
        require(math.isfinite(intermediate) and lower <= intermediate <= upper
                and row["baseline_result"] == {"type": "builtins.int", "value": str(int(round(intermediate)))}, "retained Python round/int differs")
    models = value.get("models")
    require(type(models) is list and [row.get("name") for row in models] == list(CASE_COUNTS), "fixed24 model cases absent")
    native_calls, normal_rejections, twists, self_calls, retained = 0, 0, 0, 0, 0
    for row, spec in zip(models, CASE_SPECS):
        name, definition, patch, initial_patch, count = spec
        require(row.get("definition") == definition and row.get("initial_state_patch") == initial_patch
                and type(row.get("field_patch")) is dict and set(row["field_patch"]) == set(patch), "original constructor/explicit patch controls differ")
        for record in row["field_patch"].values():
            scalar_shape(record)
        expected_owned = "fallback" not in name
        require(row.get("owners_selected") == [False, expected_owned, expected_owned], "expected native path/fallback absent")
        calls = row.get("calls")
        require(type(calls) is list and len(calls) == count, "complete finite model calls absent")
        previous = None
        for ordinal, call in enumerate(calls):
            ids = (0, 0) if ordinal % 7 == 0 else ((0, 1) if ordinal % 2 else (1, 0))
            require(set(call) == {"ordinal", "sender", "recipient", "outcomes", "before_states", "after_states"}
                    and type(call["ordinal"]) is int and call["ordinal"] == ordinal
                    and (call["sender"], call["recipient"]) == ids, "actual call ordinals/IDs differ")
            same_outcomes(call["outcomes"]); same_states(call["before_states"]); same_states(call["after_states"])
            if previous is not None:
                require(call["before_states"] == previous, "retained model state continuity differs")
            if ids[0] == ids[1]:
                require(call["outcomes"][0] == {"returned": True, "result": {"type": "builtins.int", "value": "0"}, "warnings": []}
                        and call["before_states"] == call["after_states"], "same-ID original behavior differs")
            previous = call["after_states"]
        same_states(row["final_exported_actual_states"])
        require(row["final_exported_actual_states"] == previous, "final actual public export differs from consumed state")
        require(type(row.get("diagnostics")) is list and len(row["diagnostics"]) == 3 and row["diagnostics"][0] is None
                and type(row.get("declines")) is list and len(row["declines"]) == 2, "actual owner diagnostics absent")
        if expected_owned:
            require(row["diagnostics"][1] == row["diagnostics"][2] and row["declines"] == [[], []], "repeat owned diagnostics differ")
            diag = row["diagnostics"][1]
            require(diag.get("owned") is False and diag.get("handoffs") == 1 and diag.get("native_calls", 0) > 0
                    and diag.get("self_calls", 0) > 0, "native branch/one permanent export unexercised")
            native_calls += diag["native_calls"]; self_calls += diag["self_calls"]
            normal_rejections += diag["normal_rejections"]; twists += diag["twists"]
        else:
            require(row["diagnostics"] == [None, None, None] and row["declines"] == [["unproved-method-field-or-numpy-domain"]] * 2, "whole-method decline differs")
        retained += count
    require(retained == CALLS_PER_ARM and native_calls > 0 and normal_rejections > 0 and twists > 0 and self_calls > 0,
            "complete actual native branch coverage absent")
    constructors = value.get("original_constructor_errors")
    require(type(constructors) is list and len(constructors) == 4, "original constructor error cases absent")
    expected_constructors = [{"model": "uniform", "params": {"min_ns": None}}, {"model": "log_normal", "params": {"sigma": None}},
        {"model": "pareto", "params": {"alpha": None}}, {"model": "uniform", "params": {"min_ns": "not-a-number"}}]
    for row, definition in zip(constructors, expected_constructors):
        require(row["definition"] == definition and row.get("no_native_acquisition") is True and len(row["outcomes"]) == 3,
                "constructor source/decline differs")
        require(all(outcome == row["outcomes"][0] for outcome in row["outcomes"]) and row["outcomes"][0].get("returned") is False,
                "original constructor actual errors differ")
        same_states(row["before_states"]); same_states(row["after_states"])
        require(row["before_states"] == row["after_states"], "actual failed constructor consumed RNG")
    default = value["default_fallback"]
    outcome_shape(default["outcome"]); state_shape(default["before"]); state_shape(default["after"])
    require(default["before"] == default["after"] and default["declines"] == ["unknown-or-default-latency-class"], "default original decline differs")
    alias = value["alias_decline"]; state_shape(alias["initial_state"])
    require(alias.get("no_native_acquisition") is True and alias["declines"] == ["nonoriginal-or-shared-randomstate"], "shared active consumer decline differs")
    mutation = value["mutation_fallback"]; same_outcomes(mutation["outcomes"], 2); state_shape(mutation["actual_exported_state"])
    require(mutation["diagnostics"]["owned"] is False and mutation["diagnostics"]["handoffs"] == 1, "field mutation export absent")
    for name in ("patched_callback_fallback", "patched_np_clip_fallback"):
        row = value[name]; state_shape(row["before"])
        require(row["no_acquisition"] is True and row["declines"] == ["unproved-method-field-or-numpy-domain"], "patched authority wrongly acquired")
    require(value.get("forged_token_refused") == {"external_token_parameter_removed": True, "error_type": "builtins.TypeError"}, "external forged token removal absent")
    cold = value.get("cold_export_helper_declines")
    require(type(cold) is list and [row.get("name") for row in cold] == ["asarray", "uint32"]
            and all(row.get("error_type") == "builtins.ValueError" and type(row.get("message")) is str for row in cold), "cold export primitive declines absent")
    exported = value.get("export_helper_mutation_fallbacks")
    require(type(exported) is list and [row.get("name") for row in exported] == ["asarray", "uint32"], "postownership export primitive controls absent")
    for row in exported:
        same_states(row["before"], 2); same_outcomes(row["prelude"], 2); same_states(row["consumed_states"], 2)
        same_outcomes(row["fallback_outcomes"], 2); same_states(row["final_actual_exported_states"], 2)
        require(row["changed_helper_calls"] == 0 and row["diagnostics"]["owned"] is False and row["diagnostics"]["handoffs"] == 1,
                "changed export primitive called or consumed state not exported")
        patched = row.get("diagnostics_while_helper_patched")
        require(type(patched) is dict and patched == row["diagnostics"]
                and patched.get("owned") is False and patched.get("handoffs") == 1
                and type(row.get("changed_helper_calls_while_patched")) is int
                and row["changed_helper_calls_while_patched"] == row["changed_helper_calls"] == 0
                and row.get("public_state_observation_after_helper_restored") is True
                and row.get("helper_restored_before_public_state_observation") is True,
                "patched-phase permanent export and restored-phase public state observation witnesses absent")
    abort = value["guard_baseexception_export"]
    same_outcomes(abort["prelude"], 2); same_states(abort["consumed_states"], 2); state_shape(abort["final_actual_exported_state"])
    require(abort["observed_exception"] == {"type": "ControlAbort", "message": "finite guard abort"}
            and abort["final_actual_exported_state"] == abort["consumed_states"][0]
            and abort["diagnostics"]["owned"] is False and abort["diagnostics"]["handoffs"] == 1, "BaseException authoritative state export absent")
    late = value["late_alias_export"]
    same_states(late["before"], 2); same_outcomes(late["prelude"], 2); same_states(late["consumed_states"], 2)
    state_shape(late["actual_export_after_decline"])
    require(late["actual_export_after_decline"] == late["consumed_states"][0]
            and late["declines"] == ["nonoriginal-or-shared-randomstate"], "late alias predecline actual export differs")
    same_outcomes(late["followup"], 2); same_states(late["final_actual_states"], 2)
    require(late["diagnostics"]["owned"] is False and late["diagnostics"]["handoffs"] == 1, "late alias permanent export absent")
    degenerate = value["degenerate_signedzero_models"]
    require(type(degenerate) is list and len(degenerate) == 4, "fixed4 degenerate signedzero models absent")
    expected_degenerate = [(-0.0, 0.0, -1.0), (0.0, -0.0, -1.0), (-0.0, -0.0, 1.0), (0.0, 0.0, 1.0)]
    for row, (lower, upper, mean) in zip(degenerate, expected_degenerate):
        for name, number in (("lower", lower), ("upper", upper), ("mean", mean)):
            require(row[name] == {"type": "builtins.float", "bits": struct.pack("!d", number).hex()}, "degenerate exact signedzero source inputs differ")
        same_states(row["before_states"]); same_outcomes(row["outcomes"]); same_states(row["final_actual_states"])
        require(row["before_states"] == row["final_actual_states"] and row["diagnostics"][0] is None
                and row["diagnostics"][1] == row["diagnostics"][2]
                and row["diagnostics"][1]["postprocess_handoffs"] == 1 and row["diagnostics"][1]["handoffs"] == 1,
                "degenerate original postprocess/final state differs")
    lookup = value["lookup_mutation_fallbacks"]
    require(type(lookup) is list and [row.get("name") for row in lookup]
            == ["model-string-subclass", "latency-string-subclass", "class-getattribute", "class-getattr", "class-descriptor"], "fixed5 lookup mutation controls absent")
    for row in lookup:
        same_outcomes(row["prelude"], 2); same_states(row["consumed_states"], 2)
        same_outcomes(row["outcomes"], 2); same_states(row["final_actual_states"], 2)
        require(row["diagnostics"]["owned"] is False and row["diagnostics"]["handoffs"] == 1, "lookup mutation permanent export absent")
    ordered = value["guard_lookup_order_fallback"]
    same_outcomes(ordered["outcomes"], 2); same_states(ordered["final_actual_states"], 2)
    require(ordered["outcomes"][0]["returned"] is True and ordered["diagnostics"]["owned"] is False
            and ordered["diagnostics"]["handoffs"] == 1, "guard touched changed RNG lookup before original fallback")
    token_mutations = value["token_mutation_fallbacks"]
    require(type(token_mutations) is list and [row.get("name") for row in token_mutations]
            == ["class-guard", "instance-guard", "class-getattribute", "instance-identities"], "fixed4 token mutation controls absent")
    for row in token_mutations:
        same_outcomes(row["prelude"], 2); same_states(row["consumed_states"], 2)
        same_outcomes(row["outcomes"], 2); same_states(row["final_actual_states"], 2)
        require(row["diagnostics"]["owned"] is False and row["diagnostics"]["handoffs"] == 1, "internal token mutation bypassed permanent export")
    return {"all_passed": True, "model_cases": len(models), "method_calls_per_arm": retained,
        "total_model_calls": retained * 3, "scalar_transforms": len(transforms), "native_calls_per_new_arm": native_calls,
        "normal_rejections_per_new_arm": normal_rejections, "twists_per_new_arm": twists, "self_calls_per_new_arm": self_calls,
        "rankable": False, "market_executed": False, "performance_claimed": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh independent raw recomputation receipt required")
    value = json.loads(args.raw.read_bytes())
    summary = check_controls(value, args.build)
    write(args.out, {"schema": "t3-configured-latency-owned-stdlib-raw-recheck-v1-5", "raw": {"bytes": args.raw.stat().st_size, "sha256": sha(args.raw)},
        "checker_sha256": sha(Path(__file__)), "summary": summary, "participant_imported": False, "scientific_imported": False})


if __name__ == "__main__":
    main()
