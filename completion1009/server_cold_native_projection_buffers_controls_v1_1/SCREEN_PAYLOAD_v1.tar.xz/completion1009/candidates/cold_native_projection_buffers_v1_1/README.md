# Cold native canonical projection buffers V1.1

This source version fixes the output test reader after the first Linux test
successfully built the native extension and wrote a byte-identical first output
pair. The native fixture then failed because its own Parquet reader imported
pandas. The repair reads each ordinary file with `ParquetFile.read` with explicit disabled threads and pandas metadata and preserves
the import trap, all expected values, schemas, full file comparisons and native
buffer lifetime checks. The market simulation and native output implementation
are unchanged.

The parent candidate is frozen cold native projection buffers V1 with receipt
`d9eeab53a9c61604f1ef63ea0579f6884dc14221515caa4b5be0f30b8b12cfc8`.
Its actual Linux run 37992242235 completed construction but stopped in the first
native output fixture at `pq.read_table`, whose dataset/scalar path imported
pandas under the intentionally strict import trap. The independently audited
first native trace/message pair equals the original files byte for byte. This
finite reached result proves neither the remaining fixtures nor whole markets.

Only the fixture's cold saved-file reader changes from `pq.read_table(path)` to
`pq.ParquetFile(path).read(use_threads=False, use_pandas_metadata=False)`. Both original and native fixtures use the same
reader. The exact output writer, qsort/packing module, complete native pyx/pxd,
primitive observer, runtime68, production entry, cold ownership migration,
message/order/RNG/book/scheduler, source/ELF authority and same-market two-output
fallback retain parent V1 bytes. The frozen parent, wrapper and prior evidence
remain immutable.

The prepared controls still require all three paired trace/message cases,
explicit rows, schema/dtype/null/tie/UTF8/signed limits, readonly descriptors,
immutable bytes after owner destruction, hostile-key declines, and six actual
initialized original/light/native/repeat/two-fallback whole markets with full
STATE/output and positive repeated native diagnostics. Launch verbs remain
`simulate` and `simulate-batch`; runtime is offline with the official seven/ten
column Parquet contracts and Snappy output.

This directory is a fresh source preparation. Fresh review, pinned Linux
translation/build and every control must pass before complete-entry timing.
The parent run is evidence about V1 only. No V1.1 runtime success, speed, 230000
score, ranking, full71 or official submission readiness is claimed. Inherited
audit/progress documents retain their parent development dates and claims as
historical source data; the fresh receipt/change map fixes current source status.
