# Coherent native owner transition prototype

## Executive summary

This is a **frozen build-input source prototype**, not a submission and not a runtime PASS. Its production source starts from the original JSON configuration, counters, seeds, RNG, oracle, agents and `Kernel.initialize`. A finite cold migration moves initialized traders, the exchange and empty startup books into one Cython extension. Real callbacks then generate every future order, query, response and wakeup. Original Message and Order objects remain in this transition. Dynamic OrderArena/MessageArena replacement is the next separate experiment; 46 object slots alone cannot establish 230000 EPS.

`authoritative_chain.pyx/.pxd` combine NativeTrader, NativeExchange, NativeBook, NativeLevel, ChainScheduler, FlatHeap and ColumnLedger. Trader 59, book/level 37, exchange/support 19 and kernel 3 selected business bodies derive from the exact 64-file runtime pins, with finite listed remapping and Cython closure helpers. `state_mapper.py` migrates once after original initialization, retains original observer mapping/list identities, transforms existing wakeup queue envelopes without new messages and clears retired raw owner dictionaries and book dictionaries. New messages use same-extension direct cdef send/wakeup/delivery/book paths. `ledger_writer.py` preserves final-key sequence filtering and stable insertion ties; it permits original duplicate sequence values and does not renumber them.

`production_cli.py` implements both official verbs and honest wall time. `SOURCE_PREPARATION_RECEIPT_v3.json` binds the current 118-body input and supersedes historical V1/V2. `build_native.py` is future Linux-only source. No native parser/compiler, participant import, RNG call, simulation or external submission was run while preparing this prototype. Python files have only been parsed/compiled as source; normalized Cython syntax has only been AST-parsed, with typed member and declaration-signature closure checked.

The next gate is a real Linux Cython build and `controls.py`: one four-strategy JSON is run in original/native/native arms. Complete trace/message frames, dtypes, counts, native repeat file bytes and cold RNG/counter/alias snapshots are retained, including first differences. Complete independent 118-body semantic AST review also remains required. Any failure must be repaired in a fresh candidate before rankable timing. The arena plan is [DYNAMIC_AUTHORITATIVE_CHAIN_PLAN_v1.md](../../research/native_v6_roundtrip_source_diagnosis_v1/DYNAMIC_AUTHORITATIVE_CHAIN_PLAN_v1.md).

Run in the pinned Linux CPython 3.11.17 environment with the exact dependencies from `compile_spec.json`, a relocated matching runtime, and fresh output directories:

```sh
python build_native.py --runtime /work/runtime --out /work/chain_build
python controls.py --runtime /work/runtime --build /work/chain_build --out /work/chain_controls
```
