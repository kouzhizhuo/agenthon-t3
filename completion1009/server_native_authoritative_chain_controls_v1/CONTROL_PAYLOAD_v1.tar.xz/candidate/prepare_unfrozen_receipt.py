"""Freeze V3 build inputs with stdlib only; no participant/native execution."""
import ast
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
TARGET = HERE / "SOURCE_PREPARATION_RECEIPT_v3.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize(source):
    lines, index, original = [], 0, source.splitlines()
    while index < len(original):
        line = original[index]
        if re.match(r"^    property \w+:", line):
            index += 1
            while index < len(original) and (not original[index].strip() or original[index].startswith("        ")):
                index += 1
            continue
        line = line.replace("cdef class", "class")
        if re.match(r"\s*cdef (?!class)(?!object \w+\()(?!void \w+\()", line):
            if "=" in line:
                line = re.sub(r"cdef \w+ (\w+)\s*=", r"\1 =", line)
            else:
                index += 1
                continue
        line = re.sub(r"cdef (?:object|void) (\w+)\(", r"def \1(", line)
        line = re.sub(r"\bobject (\w+)", r"\1", line)
        line = line.replace(" except *:", ":")
        line = re.sub(r"\(<(?:NativeLevel|NativeBook|NativeTrader|NativeExchange)>\s*([^\n]*?)\)", r"(\1)", line)
        lines.append(line)
        index += 1
    return ast.parse("\n".join(lines))


def static_members(tree, source, declarations):
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    blocks = {match.group(1): match.group(2) for match in re.finditer(
        r"^cdef class (\w+):\n(.*?)(?=^cdef class |\Z)", declarations, re.M | re.S)}
    if set(classes) != set(blocks):
        raise ValueError("Cython class/declaration roster differs")
    declared, signatures = {}, {}
    for name, klass in classes.items():
        fields = set()
        signatures[name] = {}
        for line in blocks[name].splitlines():
            if "(" not in line:
                match = re.match(r"    cdef (?:public )?\w+ (.*)$", line)
                if match:
                    fields.update(item.strip() for item in match.group(1).split(","))
            else:
                match = re.match(r"    cdef (?:object|void) (\w+)\(([^)]*)\)(?: except \*)?$", line)
                if match:
                    signatures[name][match.group(1)] = tuple(item.strip().split("=")[0].strip() for item in match.group(2).split(","))
        methods = {node.name: node for node in klass.body if isinstance(node, ast.FunctionDef)}
        for method, arguments in signatures[name].items():
            if method not in methods or tuple(arg.arg for arg in methods[method].args.args) != arguments:
                raise ValueError("Cython cdef signature differs: " + name + "." + method)
        start = source.index("cdef class " + name + ":")
        end = source.find("\ncdef class ", start + 1)
        properties = set(re.findall(r"^    property (\w+):", source[start:] if end < 0 else source[start:end], re.M))
        declared[name] = fields | set(methods) | properties
    checked = 0
    for name, klass in classes.items():
        for method in klass.body:
            if not isinstance(method, ast.FunctionDef):
                continue
            for node in ast.walk(method):
                if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "self":
                    checked += 1
                    if node.attr not in declared[name]:
                        raise ValueError("undeclared typed self member: " + name + "." + node.attr)
                if (isinstance(node, ast.Attribute) and isinstance(node.value, ast.Attribute)
                        and isinstance(node.value.value, ast.Name) and node.value.value.id == "self"):
                    target = {"_owner": "NativeExchange", "_scheduler": "ChainScheduler", "ledger": "ColumnLedger"}.get(node.value.attr)
                    if target:
                        checked += 1
                        if node.attr not in declared[target]:
                            raise ValueError("undeclared typed receiver member: " + target + "." + node.attr)
    return {"classes": sorted(classes), "cdef_signatures": sum(len(items) for items in signatures.values()),
        "typed_attribute_references_checked": checked, "missing_members": []}


def check_pins(rows, root):
    for row in rows:
        path = root / row["path"]
        if any(part.startswith("._") or part == "__pycache__" for part in path.parts):
            raise ValueError("unclean pinned source path")
        if len(path.read_bytes()) != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("pinned input differs: " + str(path))


def main():
    if TARGET.exists():
        raise FileExistsError("use a fresh candidate/receipt for frozen repairs")
    transcription = json.loads((HERE / "TRANSCRIPTION_v1.json").read_bytes())
    if transcription.get("unfrozen") is not True:
        raise ValueError("V3 freeze requires the explicitly unfrozen prototype")
    runtime_pins = json.loads((HERE / "RUNTIME_PINS.json").read_bytes())
    check_pins(runtime_pins["files"], Path(runtime_pins["runtime_owner"]))
    check_pins(json.loads((HERE / "RULE_SOURCE_PINS_v1.json").read_bytes())["files"], ROOT)
    check_pins(list(transcription["source_inputs"].values()), Path("/"))
    check_pins(transcription["generated"], Path("/"))
    bodies = transcription["business_bodies"]
    if len(bodies) != 118:
        raise ValueError("selected current business roster differs")
    tree = normalize((HERE / "authoritative_chain.pyx").read_text())
    closure = static_members(tree, (HERE / "authoritative_chain.pyx").read_text(), (HERE / "authoritative_chain.pxd").read_text())
    method_count = 0
    for cls in tree.body:
        if not isinstance(cls, ast.ClassDef):
            continue
        for method in cls.body:
            if not isinstance(method, ast.FunctionDef):
                continue
            method_count += 1
            if any(isinstance(node, (ast.GeneratorExp, ast.Lambda)) for node in ast.walk(method)):
                raise ValueError("unmapped closure remains in class method")
    paths = [path for path in sorted(HERE.rglob("*")) if path.is_file()
        and not any(part.startswith("._") or part == "__pycache__" for part in path.parts)
        and not path.name.startswith("SOURCE_PREPARATION_RECEIPT_") and not path.name.startswith("UNFROZEN_PROGRESS_RECEIPT_")]
    python = []
    for path in paths:
        if path.suffix == ".py":
            ast.parse(path.read_bytes())
            compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
            python.append(str(path.relative_to(HERE)))
    transcription.update(unfrozen=False, frozen_build_input=True,
        executive_summary="Frozen source input for the coherent original-message owner transition. Original initialized agent/book dictionaries are retired once, while original Message/Order objects remain. Typed-source closure and hashes were checked; complete independent AST mapping and actual build/JSON controls remain required. No runtime/output/speed PASS is claimed.")
    (HERE / "TRANSCRIPTION_v1.json").write_text(json.dumps(transcription, sort_keys=True, indent=2) + "\n")
    receipt = {"schema": "t3-authoritative-chain-frozen-source-preparation-v3",
        "supersedes": {"receipt": "SOURCE_PREPARATION_RECEIPT_v2.json", "sha256": sha(HERE / "SOURCE_PREPARATION_RECEIPT_v2.json"), "reason": "V2 predates the _analyse_order_book object receiver, owner logger-prefix repair, Agent logger binding, complete control snapshot files and book tombstones. V3 freezes current 118-body build inputs; V1/V2 remain historical only."},
        "executive_summary": "Frozen build-input manifest for a JSON-driven coherent owner transition retaining original Message/Order objects. Stdlib-only syntax, typed member/signature closure and pinned bytes were checked. Full independent 118-body semantic mapping and actual Linux build/JSON controls remain required. This receipt establishes no runtime, output or speed PASS.",
        "source_only": True, "unfrozen": False, "frozen_build_input": True, "source_pass": False, "runtime_pass": False,
        "participant_imported": False, "native_build_executed": False, "market_executed": False,
        "speed_claim": False, "python_AST_compile_checked": python, "normalized_Cython_class_method_count": method_count,
        "selected_business_bodies": len(bodies), "runtime_pins_checked": len(runtime_pins["files"]),
        "static_typed_source_closure": closure,
        "files": [{"path": str(path.relative_to(HERE)), "bytes": path.stat().st_size, "sha256": sha(path)} for path in paths],
        "remaining": ["complete independent 118-body semantic AST mapping", "root actual Linux Cython build", "root real original/native JSON files and RNG/identity controls", "dynamic OrderArena and MessageArena producer/consumer replacement"]}
    TARGET.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"path": str(TARGET), "bytes": TARGET.stat().st_size, "sha256": sha(TARGET), "source_only": True, "unfrozen": False, "source_pass": False}))


if __name__ == "__main__":
    main()
