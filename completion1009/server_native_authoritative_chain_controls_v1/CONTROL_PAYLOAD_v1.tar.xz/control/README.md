# Authoritative-chain one-JSON Linux controls

## Executive summary

This source-only wrapper prepares one native build of the frozen coherent owner transition and one actual four-strategy JSON run in original/native/native arms. It uses the pinned Linux base and existing compiler dependencies. Compilation happens inside a separate bounded build container so generated C, object files, ELF, the failing build receipt and logs remain in output even when compilation fails. A subsequent correctness container mounts that build read-only and retains all three arm outputs and snapshots. It measures no competitive score and consumes no official submission.

The payload contains the exact 19 candidate source files plus V3 receipt, all 64 original runtime files, eight official rule sources, control sources and hashes. The frozen candidate retains original Order/Message objects and NumPy RNG/oracle; it is the owner-migration control before dynamic order/message handles. Root must review and freeze this wrapper before preparing or uploading its archive.

`prepare.py` only verifies/copies/hashes stdlib sources and makes a deterministic reviewed archive. `controller.py` builds one compiler image, runs two serial offline readonly containers, retains installed sources before execution, waits for each settled exit and preserves image/container inspection plus all outputs. `entry.py build` builds the extension once; `entry.py controls` validates and reuses the frozen ELF and runs `controls.py`. Actual CLI arm subprocesses preserve all emitted files, logs and mapped graph snapshots. The source and build inventories are rechecked afterward.

The build container uses one CPU, 8 GiB RAM and a 1 GiB executable temporary filesystem. The correctness container uses four CPUs, 16 GiB RAM and a 64 MiB temporary filesystem with `noexec`; it mounts the built native artifact read-only. Before/after Docker inspection checks each resource contract, mounts and thread settings. Removal requires each settled container and the exact subsequent Docker `No such object` result.

The result is finite correctness evidence only. The control graph maps typed owners to their original classes, retains mutable alias edges including book.owner, and represents kernel state through explicit roots. Complete independent semantic AST review, broader official controls and end-to-end performance remain separate gates.
