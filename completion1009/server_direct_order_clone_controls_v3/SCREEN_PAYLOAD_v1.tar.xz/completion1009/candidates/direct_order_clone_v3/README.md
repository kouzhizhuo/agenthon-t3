This prototype changes only the native internal order clone field-copy loop and adds untimed clone controls. The original simulation logic, runtime, output, source checks, RNG and official gates remain unchanged. No Linux build or execution has occurred, and no performance is claimed.

# Exact direct clone prototype

Validate both live slots after allocation, copy fields in original order with reference increments, retain original tag deepcopy/counter/error cleanup. Source prototype must complete lexical checks, frozen binding, Linux translation/build and finite controls before market timing. Parent scalar V2.1 is frozen separately and has actual finite Linux evidence.
