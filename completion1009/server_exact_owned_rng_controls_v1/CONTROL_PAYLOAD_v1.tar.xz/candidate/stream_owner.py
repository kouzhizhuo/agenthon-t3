"""Finite, single-thread scalar owner; unsupported calls export then stay original."""
import math

METHODS = ("normal", "lognormal", "uniform", "pareto", "randint")


def plain_scalar(value):
    # Narrow preconverted engine input domain. NumPy wrappers for other inputs
    # remain the original complete route, including all conversion side effects.
    return type(value) is float and math.isfinite(value) or type(value) is int and -(1 << 53) <= value <= (1 << 53)


def public_state(original, np):
    value = original.get_state()
    if type(value) is not tuple or len(value) != 5 or value[0] != "MT19937":
        raise ValueError("public legacy five-element state required")
    words = value[1]
    if type(words) is not np.ndarray or words.dtype != np.dtype("uint32") or words.shape != (624,):
        raise ValueError("exact public624 uint32 state required")
    if type(value[2]) is not int or type(value[3]) is not int or type(value[4]) is not float or not math.isfinite(value[4]):
        raise ValueError("finite public position/cache tuple required")
    return (value[0], [int(x) for x in words], value[2], value[3], value[4])


class StreamOwner:
    """Exclusive stream for the lifetime of a finite source-owned control.

    Original identity remains retained solely for export/fallback. Calling its
    RNG methods directly while migrated violates this single-owner contract.
    This control does not integrate or patch any original agent/oracle object.
    """
    def __init__(self, original, np, native, wide_order):
        if type(original) is not np.random.RandomState or np.__version__ != "1.26.4":
            raise ValueError("exact NumPy1.26.4 RandomState owner required")
        self.original, self.np = original, np
        self.initial_state = public_state(original, np)
        self.native = native.OwnedStream(self.initial_state, wide_order=wide_order)
        self.original_only = False
        self.handoffs = 0

    def export_to_original(self):
        if not self.original_only:
            state = self.native.public_tuple()
            self.original.set_state((state[0], self.np.asarray(state[1], dtype=self.np.uint32), state[2], state[3], state[4]))
            self.original_only = True
            self.native = None
            self.handoffs += 1

    def state_tuple(self):
        return public_state(self.original, self.np) if self.original_only else self.native.public_tuple()

    def diagnostics(self):
        return {"original_only": self.original_only, "handoffs": self.handoffs,
                "native": None if self.native is None else self.native.diagnostics()}

    def call(self, method, *args, **kwargs):
        if self.original_only:
            return getattr(self.original, method)(*args, **kwargs)
        bound = self._admit(method, args, kwargs)
        if bound is None:
            # Export all624words/position/flag/cache before any unsupported draw,
            # validation, user conversion, warning or exception. Never remigrate.
            self.export_to_original()
            return getattr(self.original, method)(*args, **kwargs)
        if method == "uniform":
            low, high = bound
            width = float(high) - float(low)
            if not math.isfinite(width):
                raise OverflowError("Range exceeds valid bounds")
            return self.native.uniform(float(low), width)
        if method == "randint":
            low, high = bound
            if high is None:
                low, high = 0, low
            closed = high - 1
            if low < -(1 << 63):
                raise ValueError("low is out of bounds for int64")
            if closed > (1 << 63) - 1:
                raise ValueError("high is out of bounds for int64")
            if low > closed:
                raise ValueError("high <= 0" if low == 0 else "low >= high")
            return self.native.randint(low, closed)
        return getattr(self.native, method)(*(float(x) for x in bound))

    @staticmethod
    def _admit(method, args, kwargs):
        if method not in METHODS:
            return None
        fields = {"normal": (("loc", "scale"), (0.0, 1.0)), "lognormal": (("mean", "sigma"), (0.0, 1.0)),
                  "uniform": (("low", "high"), (0.0, 1.0)), "pareto": (("a",), (None,)),
                  "randint": (("low", "high"), (None, None))}
        names, defaults = fields[method]
        if len(args) > len(names) or any(k not in names for k in kwargs) or any(names[i] in kwargs for i in range(len(args))):
            return None
        bound = list(defaults)
        for index, value in enumerate(args):
            bound[index] = value
        for key, value in kwargs.items():
            bound[names.index(key)] = value
        if method == "randint":
            if type(bound[0]) is not int or bound[1] is not None and type(bound[1]) is not int:
                return None
            # Outside signed64 convertible bounds use the complete original
            # wrapper before validation, preserving every original error detail.
            if not -(1 << 63) <= bound[0] <= (1 << 63) or bound[1] is not None and not -(1 << 63) <= bound[1] <= (1 << 63):
                return None
        elif any(not plain_scalar(x) for x in bound):
            return None
        return bound


class OwnershipRegistry:
    def __init__(self, *, np, native, wide_order):
        if wide_order not in ("high-first", "low-first"):
            raise ValueError("fixed whole-control wide order required")
        self.np, self.native, self.wide_order, self.owners = np, native, wide_order, {}

    def acquire(self, original):
        identity = id(original)
        if identity in self.owners:
            if self.owners[identity].original is not original:
                raise ValueError("retained RNG identity unexpectedly reused")
            return self.owners[identity]
        owner = StreamOwner(original, self.np, self.native, self.wide_order)
        self.owners[identity] = owner
        return owner

    def release_all(self):
        for owner in self.owners.values():
            owner.export_to_original()
