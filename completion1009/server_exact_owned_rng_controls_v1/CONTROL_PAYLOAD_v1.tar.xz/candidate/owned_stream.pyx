# cython: language_level=3, boundscheck=False, wraparound=False, cdivision=True
"""One public-state owner; plain scalar validation occurs in stream_owner.py."""
from libc.stdint cimport uint32_t, uint64_t
from libc.string cimport memset

cdef extern from "owned_legacy.h":
    ctypedef struct t3_owned_state:
        uint32_t key[624]
        int pos
        int has_gauss
        double gauss
        int wide_high_first
        uint64_t words_consumed
        uint64_t twists
        uint64_t normal_rejections
        uint64_t integer_rejections
    double t3_legacy_normal(t3_owned_state *, double, double)
    double t3_legacy_lognormal(t3_owned_state *, double, double)
    double t3_legacy_uniform(t3_owned_state *, double, double)
    double t3_legacy_pareto(t3_owned_state *, double)
    uint64_t t3_default_int64_fill_one(t3_owned_state *, uint64_t, uint64_t)
    int t3_signbit(double)

cdef class OwnedStream:
    cdef t3_owned_state state

    def __init__(self, public_tuple, *, wide_order):
        cdef int index
        if type(public_tuple) is not tuple or len(public_tuple) != 5 or public_tuple[0] != "MT19937":
            raise ValueError("exact five-element MT19937 public state required")
        if type(public_tuple[1]) is not list or len(public_tuple[1]) != 624:
            raise ValueError("exact624 public uint32 key words required")
        if type(public_tuple[2]) is not int or not 0 <= public_tuple[2] <= 624:
            raise ValueError("public MT position outside0..624")
        if type(public_tuple[3]) is not int or public_tuple[3] not in (0, 1) or type(public_tuple[4]) is not float:
            raise ValueError("exact public Gaussian flag/cache required")
        if wide_order not in ("high-first", "low-first"):
            raise ValueError("fixed whole-control wide-word order required")
        memset(&self.state, 0, sizeof(t3_owned_state))
        for index in range(624):
            value = public_tuple[1][index]
            if type(value) is not int or not 0 <= value <= 0xffffffff:
                raise ValueError("public key word outside uint32")
            self.state.key[index] = value
        self.state.pos = public_tuple[2]
        self.state.has_gauss = public_tuple[3]
        self.state.gauss = public_tuple[4]
        self.state.wide_high_first = wide_order == "high-first"

    def public_tuple(self):
        return ("MT19937", [int(self.state.key[index]) for index in range(624)],
                int(self.state.pos), int(self.state.has_gauss), float(self.state.gauss))

    def diagnostics(self):
        return {"words_consumed": int(self.state.words_consumed), "twists": int(self.state.twists),
                "normal_rejections": int(self.state.normal_rejections), "integer_rejections": int(self.state.integer_rejections)}

    def normal(self, double loc, double scale):
        if t3_signbit(scale):
            raise ValueError("scale < 0")
        return t3_legacy_normal(&self.state, loc, scale)

    def lognormal(self, double mean, double sigma):
        if t3_signbit(sigma):
            raise ValueError("sigma < 0")
        return t3_legacy_lognormal(&self.state, mean, sigma)

    def uniform(self, double lower, double width):
        return t3_legacy_uniform(&self.state, lower, width)

    def pareto(self, double a):
        if a <= 0:
            raise ValueError("a <= 0")
        return t3_legacy_pareto(&self.state, a)

    def randint(self, low, closed_high):
        cdef uint64_t off, width, result
        if type(low) is not int or type(closed_high) is not int or not -(1 << 63) <= low <= closed_high < (1 << 63):
            raise ValueError("validated default-int64 closed bounds required")
        off = low % (1 << 64)
        width = closed_high - low
        result = t3_default_int64_fill_one(&self.state, off, width)
        value = int(result)
        if value >= (1 << 63):
            value -= (1 << 64)
        return value
