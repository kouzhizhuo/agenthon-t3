"""Future after-each-call original/native bits/state tests; never simulate a market."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import warnings

HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def verify_frozen_sources():
    prepared = json.loads((HERE / "SOURCE_PREPARATION_RECEIPT_v1.json").read_text())
    require(prepared["schema"] == "t3-exact-owned-rng-control-source-preparation-v1"
            and prepared["status"] == "PREPARED_SOURCE_ONLY", "frozen source preparation required")
    for row in prepared["files"]:
        require(pin(HERE / row["path"]) == {key: row[key] for key in ("bytes", "sha256")},
                "frozen control source changed after review/build: " + row["path"])


def scalar(value, np):
    if type(value) in (float, np.float64):
        return {"type": type(value).__module__ + "." + type(value).__name__, "bits": struct.pack("!d", value).hex()}
    if type(value) is np.float32:
        return {"type": "numpy.float32", "bits": struct.pack("!f", value).hex()}
    if type(value) is int or isinstance(value, np.integer):
        return {"type": type(value).__module__ + "." + type(value).__name__, "value": str(int(value))}
    if type(value) is bool or type(value) is np.bool_:
        return {"type": type(value).__module__ + "." + type(value).__name__, "value": bool(value)}
    if type(value) is np.ndarray:
        require(not value.dtype.hasobject, "control object-array result refused")
        return {"type": "numpy.ndarray", "dtype": str(value.dtype), "shape": list(value.shape), "bytes": value.tobytes().hex()}
    raise TypeError("unsupported control return type")


def state_record(value):
    # Full624word bytes retained in fixed little-endian form on every call;
    # this is a complete public-state comparison rather than a digest claim.
    return {"kind": value[0], "words_le_hex": struct.pack("<624I", *value[1]).hex(), "position": value[2], "has_gauss": value[3],
            "gauss_bits": struct.pack("!d", value[4]).hex()}


def argument_record(value, np):
    if value is None:
        return {"type": "builtins.NoneType"}
    if type(value) is str:
        return {"type": "builtins.str", "value": value}
    if type(value) in (list, tuple):
        return {"type": type(value).__module__ + "." + type(value).__name__, "values": [argument_record(x, np) for x in value]}
    return scalar(value, np)


def outcome(call, np):
    with warnings.catch_warnings(record=True) as observed:
        warnings.simplefilter("always")
        try:
            value = call()
        except Exception as error:
            result = {"returned": False, "error_type": type(error).__module__ + "." + type(error).__name__, "message": str(error)}
        else:
            # Harness serialization errors must fail the control, never become
            # matching "participant exceptions" in both arms.
            result = {"returned": True, "result": scalar(value, np)}
        result["warnings"] = [{"type": row.category.__module__ + "." + row.category.__name__, "message": str(row.message)} for row in observed]
        return result


def roster(np):
    short = [("normal", (1.5, 2.0), {}), ("normal", (-0.0, 0.0), {}), ("lognormal", (0.5, 1.2), {}),
             ("uniform", (-3.0, 3.0), {}), ("pareto", (1.5,), {}), ("randint", (0, 6), {})]
    cases = [
        ("mixed-scalar-cache", {}, short * 40),
        ("normal-rollover", {"position": 622}, [("normal", (0.0, 1.0), {})] * 400),
        ("uniform-rollover", {"position": 623}, [("uniform", (0.0, 1.0), {})] * 400),
        ("pending-positive-zero-cache", {"has_gauss": 1, "gauss": 0.0}, short * 3),
        ("pending-negative-zero-cache", {"has_gauss": 1, "gauss": -0.0}, short * 3),
        ("pending-nonzero-cache", {"has_gauss": 1, "gauss": -1.2345}, short * 3),
        ("negativezero-and-nonfinite-finite-transform", {}, [("uniform", (0.0, -0.0), {}), ("uniform", (-0.0, -0.0), {}),
            ("normal", (-0.0, 0.0), {}), ("lognormal", (710.0, 1.0), {}), ("lognormal", (-750.0, 0.0), {}),
            ("pareto", (1e-300,), {})] + short * 3),
        ("degenerate-and-invalid", {}, [("uniform", (5.0, 5.0), {}), ("normal", (3.0, 0.0), {}),
            ("normal", (0.0, -0.0), {}), ("lognormal", (1.0, -0.0), {}), ("pareto", (0.0,), {}),
            ("pareto", (-0.0,), {}), ("randint", (7, 8), {}), ("randint", (0, 0), {}),
            ("randint", (2, 2), {}), ("uniform", (-1.7976931348623157e308, 1.7976931348623157e308), {})]),
        ("small32-rejection-and-wide64", {}, [("randint", (0, high), {}) for high in
            (2, 3, 6, 257, 65537, (1 << 31) + 1, (1 << 32), (1 << 32) + 1,
             (1 << 40) + 123, (1 << 63))] * 80 + [("randint", (-(1 << 63), (1 << 63)), {})] * 40),
        ("signed-bound-and-error", {}, [("randint", (-(1 << 63), -(1 << 63) + 1), {}),
            ("randint", ((1 << 63) - 1, 1 << 63), {}), ("randint", (-10, 11), {}),
            ("randint", (-(1 << 63) - 1, 1), {}), ("randint", (0, (1 << 63) + 1), {})]),
        ("unsupported-NaN-original-handoff", {"has_gauss": 1, "gauss": -0.0}, [("normal", (0.0, float("nan")), {})] + short),
        ("unsupported-infinity-original-handoff", {}, [("pareto", (float("inf"),), {})] + short),
        ("unsupported-bool-original-handoff", {}, [("normal", (True, 1.0), {})] + short),
        ("unsupported-numpy-scalar-handoff", {}, [("normal", (np.float64(2.0), np.float64(1.0)), {})] + short),
        ("unsupported-array-original-handoff", {}, [("uniform", ([0.0, 1.0], [1.0, 2.0]), {})] + short),
        ("unsupported-size-original-handoff", {}, [("normal", (0.0, 1.0), {"size": 3})] + short),
        ("unsupported-narrow-dtype-handoff", {}, [("randint", (0, 255), {"dtype": "uint8"})] + short),
        ("unsupported-other-method-handoff", {}, [("random_sample", (), {})] + short),
        ("real-NoiseTrader-act-order", {}, [("normal", (10.0, 2.0), {}), ("randint", (0, 2), {}), ("randint", (0, 6), {})] * 300),
        ("real-uniform-latency", {}, [("uniform", (0.0, 2000.0), {})] * 700),
        ("real-lognormal-latency", {}, [("lognormal", (float(np.log(500.0)), 1.2), {})] * 700),
        ("real-pareto-latency", {}, [("pareto", (1.5,), {})] * 700),
    ]
    return cases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(sys.platform == "linux" and not args.out.exists(), "fresh Linux owned-stream control required")
    verify_frozen_sources()
    import numpy as np
    from stream_owner import OwnershipRegistry, public_state
    require(np.__version__ == "1.26.4" and sys.maxsize == (1 << 63) - 1, "actual legacy Linux64 NumPy required")
    build = json.loads(args.build_receipt.read_text())
    require(build["schema"] == "t3-exact-owned-rng-actual-build-v1" and build["rng_or_market_executed"] is False
            and build["source_receipt_sha256"] == pin(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json")["sha256"], "actual isolated source-bound build required")
    extension = HERE / build["extension"]["path"]
    require(pin(extension) == {k: build["extension"][k] for k in ("bytes", "sha256")}, "actual compiled source binding differs")
    spec = importlib.util.spec_from_file_location("_rng_owned", extension)
    native = importlib.util.module_from_spec(spec); spec.loader.exec_module(native)
    result = {"schema": "t3-exact-owned-rng-after-each-call-controls-v1", "all_passed": False,
        "build_receipt": pin(args.build_receipt), "source_receipt_sha256": build["source_receipt_sha256"],
        "source_control_sha256": pin(Path(__file__))["sha256"], "orders": {}, "rankable": False,
        "market_executed": False, "configuration_or_seeding_replaced": False, "private_numpy_layout_used": False}
    try:
        for wide_order in ("high-first", "low-first"):
            records, failure, diagnostics = [], None, {"twists": 0, "normal_rejections": 0, "integer_rejections": 0, "handoffs": 0}
            for index, (name, patch, calls) in enumerate(roster(np)):
                baseline = np.random.RandomState(81009 + index)
                frozen = baseline.get_state()
                initial = (frozen[0], frozen[1], patch.get("position", frozen[2]), patch.get("has_gauss", frozen[3]), patch.get("gauss", frozen[4]))
                baseline.set_state(initial)
                original = np.random.RandomState(0); original.set_state(initial)
                registry = OwnershipRegistry(np=np, native=native, wide_order=wide_order)
                owner = registry.acquire(original)
                require(registry.acquire(original) is owner, "same RNG identity acquired a shadow owner")
                case = {"name": name, "initial_state": state_record(public_state(baseline, np)), "calls": [], "passed": True}
                for ordinal, (method, positional, keyword) in enumerate(calls):
                    before = state_record(owner.state_tuple())
                    expected = outcome(lambda: getattr(baseline, method)(*positional, **keyword), np)
                    actual = outcome(lambda: owner.call(method, *positional, **keyword), np)
                    base_state, new_state = state_record(public_state(baseline, np)), state_record(owner.state_tuple())
                    passed = expected == actual and base_state == new_state
                    case["calls"].append({"ordinal": ordinal, "method": method, "baseline": expected, "new": actual,
                        "args": [argument_record(x, np) for x in positional], "kwargs": {k: argument_record(v, np) for k, v in keyword.items()},
                        "before_state": before, "baseline_after_state": base_state, "new_after_state": new_state,
                        "passed": passed, "ownership": owner.diagnostics()})
                    if not passed:
                        case["passed"] = False; failure = failure or {"case": name, "ordinal": ordinal, "method": method}
                        break
                old = owner.diagnostics()
                if old["native"]:
                    for key in ("twists", "normal_rejections", "integer_rejections"):
                        diagnostics[key] += old["native"][key]
                registry.release_all()
                diagnostics["handoffs"] += owner.handoffs
                case["termination_state_export_equal"] = state_record(public_state(original, np)) == state_record(public_state(baseline, np))
                if case["passed"]:
                    require(case["termination_state_export_equal"], "termination export changed complete original state")
                records.append(case)
            result["orders"][wide_order] = {"cases": records, "failure": failure, "diagnostics": diagnostics,
                "all_passed": failure is None and all(c["passed"] for c in records)}
        passed = [order for order, row in result["orders"].items() if row["all_passed"]]
        require(len(passed) == 1, "exactly one fixed wide-word order must pass full scalar/state controls")
        selected = result["orders"][passed[0]]
        require(all(selected["diagnostics"][key] > 0 for key in ("twists", "normal_rejections", "integer_rejections", "handoffs")), "rollover/rejection/whole-owner fallback controls not exercised")
        result.update(all_passed=True, selected_fixed_wide_order=passed[0], control_case_count=len(selected["cases"]),
                      calls_compared_after_each=sum(len(c["calls"]) for c in selected["cases"]), full624_state_compared=True,
                      result_types_bits_errors_warnings_equal=True)
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        with args.out.open("x") as stream:
            stream.write(json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
