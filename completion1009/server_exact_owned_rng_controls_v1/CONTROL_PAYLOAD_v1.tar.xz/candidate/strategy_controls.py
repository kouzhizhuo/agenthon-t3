"""Future real source-method probes using unchanged construction/seeding."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
from controls import argument_record, outcome, pin, require, scalar, state_record, verify_frozen_sources

HERE = Path(__file__).resolve().parent


class RecordedBridge:
    def __init__(self, original, np, owner=None):
        self.original, self.np, self.owner, self.calls = original, np, owner, []

    def __getattr__(self, method):
        def call(*args, **kwargs):
            before = self.owner.state_tuple() if self.owner else self._state()
            saved = {}
            def invoke():
                value = self.owner.call(method, *args, **kwargs) if self.owner else getattr(self.original, method)(*args, **kwargs)
                saved["value"] = value
                return value
            result = outcome(invoke, self.np)
            after = self.owner.state_tuple() if self.owner else self._state()
            self.calls.append({"method": method, "args": [argument_record(x, self.np) for x in args],
                "kwargs": {k: argument_record(v, self.np) for k, v in kwargs.items()}, "outcome": result,
                "before": state_record(before), "after": state_record(after)})
            if not result["returned"]:
                raise RuntimeError("source strategy probe draw failed: " + result["message"])
            return saved["value"]
        return call

    def _state(self):
        from stream_owner import public_state
        return public_state(self.original, self.np)


def scenario(seed, model):
    value = {"scenario_id": "owned-rng-real-source-control-" + model, "seed": seed, "horizon_ns": 2000000000,
        "exchange_config": {"symbol": "ABM"}, "oracle_config": {"params": {"initial_price": 100000}},
        "agent_configs": [{"agent_type": "NoiseTrader", "count": 1,
            "params": {"order_size_mean": 10, "order_size_std": 2, "price_offset_ticks": 5}}]}
    if model != "default":
        value["latency_config"] = {"model": model, "params": {"mean_ns": 500, "sigma": 1.2, "min_ns": 0, "max_ns": 2000, "alpha": 1.5}}
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--scalar-pass", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(sys.platform == "linux" and not args.out.exists(), "fresh Linux actual source-control receipt required")
    verify_frozen_sources()
    import numpy as np
    from stream_owner import OwnershipRegistry, public_state
    require(np.__version__ == "1.26.4", "actual NumPy1.26.4 required")
    passed, build = json.loads(args.scalar_pass.read_text()), json.loads(args.build_receipt.read_text())
    require(passed["all_passed"] is True and passed["source_receipt_sha256"] == build["source_receipt_sha256"]
            == pin(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json")["sha256"] and passed["build_receipt"] == pin(args.build_receipt), "actual source-bound scalar PASS required first")
    spec = importlib.util.spec_from_file_location("_rng_owned", HERE / build["extension"]["path"])
    require(pin(HERE / build["extension"]["path"]) == {k: build["extension"][k] for k in ("bytes", "sha256")}, "actual built extension bytes changed")
    native = importlib.util.module_from_spec(spec); spec.loader.exec_module(native)
    runtime = args.runtime.resolve()
    runtime_pins = json.loads((HERE / "STRATEGY_RUNTIME_PINS_v1.json").read_text())
    for name, expected in runtime_pins["files"].items():
        require(pin(runtime / name) == expected, "actual original method/runtime source differs")
    sys.path.insert(0, str(runtime))
    import bootstrap
    bootstrap.activate()
    from abides_fork.config import build_config, ScenarioLatencyModel
    from abides_fork.agents import NoiseTrader
    from abides_fork.simulate import reset_abides_counters
    result = {"schema": "t3-owned-rng-real-source-strategy-controls-v1", "all_passed": False, "cases": [],
        "rankable": False, "market_executed": False, "configuration_seeding_unchanged": True,
        "source_receipt_sha256": build["source_receipt_sha256"], "scalar_pass_sha256": pin(args.scalar_pass)["sha256"],
        "source_control_sha256": pin(Path(__file__))["sha256"], "build_receipt": pin(args.build_receipt),
        "selected_fixed_wide_order": passed["selected_fixed_wide_order"]}
    try:
        for index, model in enumerate(("uniform", "log_normal", "pareto", "deterministic", "default")):
            value = scenario(82009 + index, model)
            reset_abides_counters(); baseline = build_config(value)
            reset_abides_counters(); candidate = build_config(value)
            before = {"agents": [state_record(public_state(a.random_state, np)) for a in baseline["agents"]],
                      "latency": state_record(public_state(baseline["agent_latency_model"].random_state, np))}
            require(before == {"agents": [state_record(public_state(a.random_state, np)) for a in candidate["agents"]],
                               "latency": state_record(public_state(candidate["agent_latency_model"].random_state, np))}, "unchanged original config/seeding produced different state")
            registry = OwnershipRegistry(np=np, native=native, wide_order=passed["selected_fixed_wide_order"])
            base_noise, new_noise = baseline["agents"][1], candidate["agents"][1]
            require(type(base_noise) is type(new_noise) is NoiseTrader, "actual source NoiseTrader required")
            old_noise_rng, new_noise_rng = base_noise.random_state, new_noise.random_state
            a = RecordedBridge(old_noise_rng, np); b = RecordedBridge(new_noise_rng, np, registry.acquire(new_noise_rng))
            base_noise.random_state, new_noise.random_state = a, b
            orders = {"baseline": [], "new": []}
            for agent, arm in ((base_noise, "baseline"), (new_noise, "new")):
                agent.get_known_bid_ask = lambda symbol: (99998, 10, 100002, 10)
                agent.place_limit_order = lambda *args, label=arm: orders[label].append([str(x) for x in args])
            try:
                for _ in range(100):
                    NoiseTrader.act(base_noise); NoiseTrader.act(new_noise)
                require(a.calls == b.calls and orders["baseline"] == orders["new"], "actual NoiseTrader call order/output/aftercall-state differs")
            finally:
                base_noise.random_state, new_noise.random_state = old_noise_rng, new_noise_rng
            latency_a, latency_b = baseline["agent_latency_model"], candidate["agent_latency_model"]
            old_a_rng, old_b_rng = latency_a.random_state, latency_b.random_state
            is_custom = type(latency_a) is type(latency_b) is ScenarioLatencyModel
            la = RecordedBridge(old_a_rng, np)
            lb = RecordedBridge(old_b_rng, np, registry.acquire(old_b_rng) if is_custom else None)
            latency_a.random_state, latency_b.random_state = la, lb
            outcomes_a, outcomes_b = [], []
            try:
                for sender, receiver in ((0, 0), (0, 1), (1, 0), (1, 1)) * 200:
                    outcomes_a.append(scalar(latency_a.get_latency(sender, receiver), np))
                    outcomes_b.append(scalar(latency_b.get_latency(sender, receiver), np))
                require(la.calls == lb.calls and outcomes_a == outcomes_b, "actual source latency sequence/output/aftercall-state differs")
            finally:
                latency_a.random_state, latency_b.random_state = old_a_rng, old_b_rng
            registry.release_all()
            require(state_record(public_state(old_noise_rng, np)) == state_record(public_state(new_noise_rng, np))
                    and state_record(public_state(old_a_rng, np)) == state_record(public_state(old_b_rng, np)), "actual original identities terminal state export differs")
            result["cases"].append({"model": model, "initial_config_states": before, "NoiseTrader_calls": a.calls,
                "latency_calls": la.calls, "orders": orders["baseline"], "latency_outputs": outcomes_a,
                "default_latency_retained_original": not is_custom, "full_aftercall_values_states_equal": True})
        result["all_passed"] = True
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        with args.out.open("x") as stream:
            stream.write(json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
