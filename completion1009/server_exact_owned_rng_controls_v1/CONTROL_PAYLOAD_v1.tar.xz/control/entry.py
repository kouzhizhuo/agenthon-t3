"""Future isolated owned-RNG build or after-each-call scalar container entry."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
from common import (CASE_COUNTS, CANDIDATE_RECEIPT, CANDIDATE_REVIEW_SHA256,
    CANDIDATE_SHA256, inventory, safe_name, sha, verify_candidate, verify_payload, write)

ROOT = Path("/opt/exact-owned-rng")
OUT = Path("/output")
FLAGS = ["-fno-fast-math", "-ffp-contract=off", "-fno-associative-math", "-fno-unsafe-math-optimizations"]


def call(command, label, seconds, allow_failure=False):
    log = OUT / (label + ".log")
    result, failure = None, None
    with log.open("xb") as stream:
        try:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=seconds)
        except BaseException as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    row = {"command": command, "returncode": None if result is None else result.returncode,
        "failure": failure, "log": {"path": log.name, "bytes": log.stat().st_size, "sha256": sha(log)}}
    write(OUT / (label + ".json"), row)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual owned-RNG operation failed: " + label)
    return row


def check_build(build):
    verify_candidate(build)
    receipt_path = build / "BUILD_RECEIPT.json"
    receipt = json.loads(receipt_path.read_bytes())
    if (receipt.get("schema") != "t3-exact-owned-rng-actual-build-v1" or receipt.get("source_receipt_sha256") != CANDIDATE_SHA256
            or receipt.get("independent_review_sha256") != CANDIDATE_REVIEW_SHA256
            or receipt.get("rng_or_market_executed") is not False or receipt.get("candidate_imported_during_build") is not False
            or receipt.get("rankable") is not False or receipt.get("numeric_flags") != FLAGS
            or receipt.get("versions", {}).get("numpy") != "1.26.4" or receipt.get("versions", {}).get("Cython") != "3.1.3"):
        raise ValueError("actual isolated build source/version/flags binding differs")
    binaries = list(build.glob("_rng_owned*.so"))
    path = safe_name(receipt["extension"]["path"])
    if len(binaries) != 1 or len(path.parts) != 1 or binaries[0] != build / path:
        raise ValueError("one exact owned-RNG extension required")
    for actual_path, pin in ((binaries[0], receipt["extension"]), (build / "owned_stream.c", receipt["generated_c"]),
            (receipt_path.with_suffix(".build.log"), receipt["log"])):
        if actual_path.stat().st_size != pin["bytes"] or sha(actual_path) != pin["sha256"]:
            raise ValueError("actual generated/build bytes differ")
    with binaries[0].open("rb") as stream:
        if stream.read(4) != b"\x7fELF":
            raise ValueError("actual Linux ELF header required")
    if receipt.get("command") != [sys.executable, "-B", str(build / "setup.py"), "build_ext", "--inplace"]:
        # The controls bind mount changes only the absolute scratch directory;
        # the retained build command is checked against its original build path.
        if receipt.get("command") != [sys.executable, "-B", "/output/build/setup.py", "build_ext", "--inplace"]:
            raise ValueError("actual single setup build command differs")
    return receipt


def state_shape(value):
    if (type(value) is not dict or set(value) != {"kind", "words_le_hex", "position", "has_gauss", "gauss_bits"}
            or value["kind"] != "MT19937" or type(value["position"]) is not int or not 0 <= value["position"] <= 624
            or value["has_gauss"] not in (0, 1) or type(value["words_le_hex"]) is not str
            or len(value["words_le_hex"]) != 4992 or type(value["gauss_bits"]) is not str or len(value["gauss_bits"]) != 16):
        raise ValueError("complete retained public-state shape differs")
    bytes.fromhex(value["words_le_hex"]); bytes.fromhex(value["gauss_bits"])


def summarize_controls(value):
    orders = value.get("orders", {})
    return {"all_passed": value.get("all_passed"), "selected_fixed_wide_order": value.get("selected_fixed_wide_order"),
        "control_case_count": value.get("control_case_count"), "calls_compared_after_each": value.get("calls_compared_after_each"),
        "orders": {name: {"all_passed": row.get("all_passed"), "failure": row.get("failure"),
            "diagnostics": row.get("diagnostics"), "case_count": len(row.get("cases", [])),
            "retained_calls": sum(len(case.get("calls", [])) for case in row.get("cases", []))}
            for name, row in orders.items()}}


def check_controls(value, build):
    if (value.get("schema") != "t3-exact-owned-rng-after-each-call-controls-v1" or value.get("all_passed") is not True
            or value.get("source_receipt_sha256") != CANDIDATE_SHA256
            or value.get("source_control_sha256") != sha(build / "controls.py")
            or value.get("build_receipt") != {"bytes": (build / "BUILD_RECEIPT.json").stat().st_size, "sha256": sha(build / "BUILD_RECEIPT.json")}
            or value.get("control_case_count") != 22 or value.get("calls_compared_after_each") != 5029
            or value.get("full624_state_compared") is not True or value.get("result_types_bits_errors_warnings_equal") is not True
            or any(value.get(name) is not False for name in ("rankable", "market_executed", "configuration_or_seeding_replaced", "private_numpy_layout_used"))
            or set(value.get("orders", {})) != {"high-first", "low-first"}):
        raise ValueError("actual scalar result/fullstate/error/warning source contract differs")
    selected = [name for name, row in value["orders"].items() if row.get("all_passed") is True]
    if len(selected) != 1 or value.get("selected_fixed_wide_order") != selected[0]:
        raise ValueError("exactly one whole fixed wide-word order must pass")
    for name, row in value["orders"].items():
        cases = row["cases"]
        if [case["name"] for case in cases] != list(CASE_COUNTS):
            raise ValueError("both complete fixed arms must retain all22 cases in order")
        for case in cases:
            state_shape(case["initial_state"])
            if not 1 <= len(case["calls"]) <= CASE_COUNTS[case["name"]]:
                raise ValueError("finite retained case count differs")
            if name == selected[0] and (case.get("passed") is not True or case.get("termination_state_export_equal") is not True
                    or len(case["calls"]) != CASE_COUNTS[case["name"]]):
                raise ValueError("selected complete arm case/state export differs")
            for ordinal, call_row in enumerate(case["calls"]):
                if call_row["ordinal"] != ordinal:
                    raise ValueError("after-each-call ordinals differ")
                for field in ("before_state", "baseline_after_state", "new_after_state"):
                    state_shape(call_row[field])
                for outcome in (call_row["baseline"], call_row["new"]):
                    if type(outcome.get("returned")) is not bool or type(outcome.get("warnings")) is not list:
                        raise ValueError("retained return/exception/warning outcome missing")
                    if outcome["returned"]:
                        if type(outcome.get("result")) is not dict or "type" not in outcome["result"]:
                            raise ValueError("retained result type/bits/value missing")
                    elif not all(type(outcome.get(field)) is str for field in ("error_type", "message")):
                        raise ValueError("retained actual exception type/message missing")
                equal = call_row["baseline"] == call_row["new"] and call_row["baseline_after_state"] == call_row["new_after_state"]
                if call_row.get("passed") is not equal or (name == selected[0] and not equal):
                    raise ValueError("saved scalar/state equality recompute differs")
        if name == selected[0] and (row.get("failure") is not None
                or any(type(row["diagnostics"].get(key)) is not int or row["diagnostics"][key] <= 0
                    for key in ("twists", "normal_rejections", "integer_rejections", "handoffs"))):
            raise ValueError("selected arm did not exercise required branches")
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("build", "controls"))
    args = parser.parse_args()
    report = {"schema": "t3-exact-owned-rng-scalar-actual-result-v1", "all_passed": False,
        "rankable": False, "speed_claim": False, "official_gate": False, "full71": False,
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "actual_native_build_invocations": 0,
        "mode": args.verb, "source_before": None, "source_after": None,
        "build_verified": False, "failure": None}
    build = OUT / "build" if args.verb == "build" else Path("/build")
    try:
        verify_payload(ROOT)
        report["source_before"] = inventory(ROOT)
        if args.verb == "build":
            if build.exists():
                raise ValueError("fresh writable build scratch required")
            shutil.copytree(ROOT / "candidate", build)
            verify_candidate(build)
            report["actual_native_build_invocations"] += 1
            report["build_command"] = call([sys.executable, "-B", str(build / "build.py"),
                "--receipt", str(build / "BUILD_RECEIPT.json"), "--review", str(ROOT / "source_review/INDEPENDENT_CANDIDATE_REVIEW.json"),
                "--review-sha256", CANDIDATE_REVIEW_SHA256], "native-build", 900)
        report["build_before"] = inventory(build)
        receipt = check_build(build)
        report.update(build_verified=True, build_receipt=receipt)
        if args.verb == "controls":
            actual_path = OUT / "SCALAR_RESULT.json"
            operation = call([sys.executable, "-B", str(build / "controls.py"),
                "--build-receipt", str(build / "BUILD_RECEIPT.json"), "--out", str(actual_path)], "scalar-controls", 600, allow_failure=True)
            report["controls_command"] = operation
            if actual_path.is_file():
                actual = json.loads(actual_path.read_bytes())
                report["actual_controls_summary"] = summarize_controls(actual)
                report["actual_controls_file"] = {"path": actual_path.name, "bytes": actual_path.stat().st_size, "sha256": sha(actual_path)}
                check_controls(actual, build)
            else:
                raise ValueError("actual scalar result missing; see retained logs")
            if operation["returncode"] != 0 or operation["failure"] is not None:
                raise ValueError("actual scalar control process failed")
        report["build_after"] = inventory(build)
        if report["build_before"] != report["build_after"]:
            raise ValueError("compiled scratch/build bytes changed during controls")
        report["all_passed"] = True
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        try:
            verify_payload(ROOT)
            report["source_after"] = inventory(ROOT)
            if report["source_before"] != report["source_after"]:
                raise ValueError("installed source changed during build/controls")
            if build.exists():
                verify_candidate(build)
            if args.verb == "controls" and report.get("build_before") is not None:
                report["build_after"] = inventory(build)
                if report["build_before"] != report["build_after"]:
                    raise ValueError("readonly build changed during failed controls")
        except BaseException as error:
            report["all_passed"] = False
            report["source_failure"] = {"type": type(error).__name__, "message": str(error)}
        # Full scalar states, partial results, generated C, objects, ELF and both
        # build/control logs remain under /output even on a failed stage.
        report["retained_output_inventory"] = inventory(OUT)
        write(OUT / "ACTUAL_RESULT.json", report)
    if report["all_passed"] is not True:
        raise RuntimeError("actual owned-RNG scalar build/controls failed")


if __name__ == "__main__":
    main()
