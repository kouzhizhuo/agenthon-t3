"""Stdlib-only source packaging; an exact independent wrapper review must seal."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import (CANDIDATE_RECEIPT, CANDIDATE_REVIEW_SHA256, CANDIDATE_SHA256,
    WRAPPER_RECEIPT, inventory, sha, verify_candidate, verify_payload, verify_rows, write)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CANDIDATE = ROOT / "candidates/exact_owned_rng_control_v1"
CANDIDATE_REVIEW = ROOT / "research/continuous_native_boundary_review_v1/INDEPENDENT_EXACT_OWNED_RNG_CONTROL_SOURCE_REVIEW_v1.json"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--wrapper-review", type=Path, required=True)
    parser.add_argument("--wrapper-review-sha256", required=True)
    args = parser.parse_args()
    if args.out.exists() or args.archive.exists():
        raise ValueError("fresh source payload and archive required")
    wrapper_path = HERE / WRAPPER_RECEIPT
    wrapper = json.loads(wrapper_path.read_bytes())
    if (wrapper.get("source_frozen") is not True or wrapper.get("candidate_source_receipt_sha256") != CANDIDATE_SHA256
            or len(wrapper["files"]) != 8):
        raise ValueError("exact frozen eight-file wrapper receipt required")
    verify_rows(HERE, wrapper["files"])
    reviewed = json.loads(args.wrapper_review.read_bytes())
    if (sha(args.wrapper_review) != args.wrapper_review_sha256 or reviewed.get("status") != "PASS_SOURCE_ONLY"
            or reviewed.get("unresolved_source_blockers") != [] or reviewed.get("wrapper_source_receipt_sha256") != sha(wrapper_path)
            or reviewed.get("candidate_source_receipt_sha256") != CANDIDATE_SHA256
            or reviewed.get("reviewed_wrapper_files") != wrapper["files"]):
        raise ValueError("independent exact wrapper source PASS required to seal archive")
    candidate = verify_candidate(CANDIDATE)
    independent = json.loads(CANDIDATE_REVIEW.read_bytes())
    if (sha(CANDIDATE_REVIEW) != CANDIDATE_REVIEW_SHA256 or independent.get("status") != "PASS_SOURCE_ONLY"
            or independent.get("unresolved_source_blockers") != [] or independent.get("reviewed_source_receipt_sha256") != CANDIDATE_SHA256
            or independent.get("reviewed_files") != candidate["files"]):
        raise ValueError("independent exact candidate source PASS required")
    copies = [(CANDIDATE / row["path"], "candidate/" + row["path"]) for row in candidate["files"]]
    copies.append((CANDIDATE / CANDIDATE_RECEIPT, "candidate/" + CANDIDATE_RECEIPT))
    copies += [(HERE / row["path"], "control/" + row["path"]) for row in wrapper["files"]]
    copies += [(CANDIDATE_REVIEW, "source_review/INDEPENDENT_CANDIDATE_REVIEW.json"),
        (wrapper_path, "source_review/" + WRAPPER_RECEIPT),
        (args.wrapper_review, "source_review/INDEPENDENT_WRAPPER_REVIEW.json")]
    args.out.mkdir(parents=True)
    for source, relative in copies:
        target = args.out / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        if target.suffix == ".py":
            ast.parse(target.read_bytes())
            compile(target.read_bytes(), str(target), "exec", dont_inherit=True)
    plan = {"schema": "t3-exact-owned-rng-scalar-only-controls-plan-v1", "frozen_source_inputs": True,
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "candidate_sources": 13,
        "wrapper_source_receipt_sha256": sha(wrapper_path), "independent_wrapper_review_sha256": args.wrapper_review_sha256,
        "independent_candidate_review_sha256": CANDIDATE_REVIEW_SHA256,
        "native_builds": 1, "scalar_cases": 22, "calls_per_complete_arm": 5029,
        "fixed_whole_arm_orders": ["high-first", "low-first"], "selected_rule": "exactly_one_whole_arm_full_PASS",
        "all624_words_after_each_call": True, "result_types_bits_errors_warnings": True,
        "strategy_controls": False, "market_controls": False, "performance_controls": False,
        "minimum_host_free_bytes": 4 * 1024**3, "scalar_fsize_limit_bytes": 1024**3,
        "build_resources": {"cpus": 1, "memory_bytes": 8 * 1024**3, "tmp_bytes": 1024**3},
        "correctness_resources": {"cpus": 4, "memory_bytes": 16 * 1024**3, "tmp_bytes": 64 * 1024**2, "tmp_noexec": True},
        "source_only": True, "runtime_pass": False, "rankable": False, "official_submission": False, "speed_claim": False}
    write(args.out / "CONTROL_PLAN.json", plan)
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-exact-owned-rng-scalar-payload-manifest-v1", "files": inventory(args.out)})
    verify_payload(args.out)
    with tarfile.open(args.archive, "w:xz") as archive:
        for row in inventory(args.out):
            data = (args.out / row["path"]).read_bytes()
            item = tarfile.TarInfo(row["path"])
            item.size = len(data); item.mode = 0o644; item.mtime = 0; item.uid = item.gid = 0; item.uname = item.gname = ""
            archive.addfile(item, io.BytesIO(data))
    write(args.archive.with_suffix(".receipt.json"), {"source_only": True, "archive_sha256": sha(args.archive),
        "archive_bytes": args.archive.stat().st_size, "payload_files": len(inventory(args.out)),
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "runtime_executed": False})
    print(json.dumps({"archive": str(args.archive), "bytes": args.archive.stat().st_size, "sha256": sha(args.archive)}))


if __name__ == "__main__":
    main()
