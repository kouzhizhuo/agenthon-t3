# Control functions are compiled with the extension but never called by the
# production command. Both arms use fresh authoritative arenas; the reference
# arm retains the exact parent scan path via a disabled index token.

def _price_control_book(arena, indexed):
    cdef OrderArena typed_arena = arena
    cdef NativeExchange owner = NativeExchange.__new__(NativeExchange)
    cdef NativeBook book
    owner._missing = _MISSING
    owner._slot_mkt_open = 1
    owner._slot_current_time = 7
    owner._slot_book_logging = False
    owner._slot_log_events = False
    owner._slot_stp_policy = None
    owner._slot_kernel = None
    book = NativeBook(owner, 'ABM')
    book._orders = typed_arena
    if indexed:
        book._activate_fresh_price_index()
    return book


def _price_control_signature(book):
    cdef NativeBook typed = book
    cdef NativeLevel level
    result = []
    for levels in (typed._slot_bids, typed._slot_asks):
        rows = []
        for level in levels:
            visible = [(level._orders._get(h, 5), level._orders._get(h, 3),
                type(level._orders._get(h, 3)).__name__, m) for h, m in level._slot_visible_orders]
            hidden = [(level._orders._get(h, 5), level._orders._get(h, 3),
                type(level._orders._get(h, 3)).__name__, m) for h, m in level._slot_hidden_orders]
            rows.append((level._slot_price, type(level._slot_price).__name__, level._slot_side,
                visible, hidden, level._total_quantity(), level._is_empty()))
        result.append(rows)
    return result


def _price_control_release(book):
    cdef NativeBook typed = book
    cdef NativeLevel level
    for levels in (typed._slot_bids, typed._slot_asks):
        for level in levels:
            for h, m in level._slot_visible_orders + level._slot_hidden_orders:
                typed._orders._release(h)
            level._slot_visible_orders.clear()
            level._slot_hidden_orders.clear()
        levels.clear()
    typed._invalidate_price_index('control-cleanup')


def _price_control_put(book, side, price, order_id, quantity=10, hidden=False, insert_by_id=False):
    cdef NativeBook typed = book
    handle = typed._orders._new_limit(1, 1, 'ABM', quantity, side, price, order_id,
        hidden, False, insert_by_id, False, None)
    typed._enter_order(handle, {'control_id': order_id}, True)


def _price_control_cancel(book, side, price, order_id):
    cdef NativeBook typed = book
    handle = typed._orders._new_limit(1, 2, 'ABM', 10, side, price, order_id)
    try:
        return typed._cancel_order(handle, None, None, True)
    finally:
        typed._orders._release(handle)


class _PriceControlNumber:
    """Record parent fallback comparison counts; no hash must be attempted."""
    def __init__(self, value):
        self.value = value
        self.calls = []
    def __hash__(self):
        self.calls.append('hash')
        raise AssertionError('custom price must not enter the index')
    def __eq__(self, other):
        self.calls.append('eq')
        return self.value == (other.value if type(other) is _PriceControlNumber else other)
    def __lt__(self, other):
        self.calls.append('lt')
        return self.value < (other.value if type(other) is _PriceControlNumber else other)
    def __gt__(self, other):
        self.calls.append('gt')
        return self.value > (other.value if type(other) is _PriceControlNumber else other)


def control_price_index_checks():
    cdef OrderArena indexed_arena = OrderArena()
    cdef OrderArena parent_arena = OrderArena()
    cdef NativeBook indexed = _price_control_book(indexed_arena, True)
    cdef NativeBook parent = _price_control_book(parent_arena, False)
    cdef NativeLevel li, lp, level, removed_i, removed_p
    cdef NativeBook mutant
    cdef object hi, hp
    cdef Py_ssize_t i
    counter = Order._order_id_counter
    old_observer = _observer.STATE
    _observer.STATE = _observer.Episode()
    cases = []
    def record(name, passed):
        cases.append({'case': name, 'passed': bool(passed)})
    def same(name):
        record(name, _price_control_signature(indexed) == _price_control_signature(parent))
    try:
        record('fresh_empty_index_and_same_public_api', indexed.price_index_witness()['enabled']
            and indexed.price_index_witness()['bid_index_levels'] == 0
            and indexed.price_index_witness()['canonical_level_container'] == 'builtins.list')
        for side, prices in ((Side.BID, (99, 101, 100, 97, 103)), (Side.ASK, (109, 107, 108, 110, 106))):
            for price in prices:
                _price_control_put(indexed, side, price, price)
                _price_control_put(parent, side, price, price)
        same('unordered_dynamic_prices_exact_sorted_lists')
        index_identity = True
        for level in indexed._slot_bids:
            if indexed._price_index_token[1].get(level._slot_price) is not level:
                index_identity = False
        for level in indexed._slot_asks:
            if indexed._price_index_token[2].get(level._slot_price) is not level:
                index_identity = False
        record('indexes_have_same_level_objects', index_identity)
        record('delete_best_bid_returns_same', _price_control_cancel(indexed, Side.BID, 103, 103)
            == _price_control_cancel(parent, Side.BID, 103, 103) == True)
        same('delete_best_bid_selects_remaining_max')
        record('best_bid_not_minimum', (<NativeLevel>indexed._slot_bids[0])._slot_price == 101)
        _price_control_cancel(indexed, Side.BID, 97, 97); _price_control_cancel(parent, Side.BID, 97, 97)
        same('delete_minimum_bid_preserves_best')
        _price_control_cancel(indexed, Side.ASK, 106, 106); _price_control_cancel(parent, Side.ASK, 106, 106)
        same('delete_best_ask_selects_remaining_min')
        record('wrong_price_same_id_does_not_cancel', _price_control_cancel(indexed, Side.BID, 102, 101)
            == _price_control_cancel(parent, Side.BID, 102, 101) == False)
        for side, price, ident, qty, hidden, by_id in ((Side.BID, 100, 42, 11, False, False),
            (Side.BID, 100, 42, 12, False, False), (Side.BID, 100, 42, 13, True, False),
            (Side.BID, 99, 42, 14, False, False), (Side.ASK, 109, 42, 15, False, False),
            (Side.BID, 100, 41, 16, False, True), (Side.BID, 100, 42, 17, False, True)):
            _price_control_put(indexed, side, price, ident, qty, hidden, by_id)
            _price_control_put(parent, side, price, ident, qty, hidden, by_id)
        same('same_and_cross_price_duplicate_ids_and_insert_by_id')
        for j in range(3):
            record('duplicate_first_visible_then_hidden_' + str(j),
                _price_control_cancel(indexed, Side.BID, 100, 42) == _price_control_cancel(parent, Side.BID, 100, 42))
            same('duplicate_residual_queue_' + str(j))
        opposite_duplicate = False
        for level in parent._slot_asks:
            for h, m in level._slot_visible_orders:
                if parent_arena._get(h, 5) == 42:
                    opposite_duplicate = True
        record('opposite_side_duplicate_id_retained', opposite_duplicate)
        # One hidden-only level remains a true best level; visible totals are not
        # promoted to depth keys and the original get_l1 oddity is unchanged.
        _price_control_put(indexed, Side.BID, 120, 700, 9, True)
        _price_control_put(parent, Side.BID, 120, 700, 9, True)
        same('hidden_only_best_level_no_roi_or_visible_filter')
        li = indexed._slot_bids[0]; lp = parent._slot_bids[0]
        record('hidden_only_level_visible_quantity_zero', li._total_quantity() == 0 and lp._total_quantity() == 0)
        record('zero_quantity_update_refuses', li._update_order_quantity(700, 0) == lp._update_order_quantity(700, 0) == False)
        li._update_order_quantity(700, np.int64(5)); lp._update_order_quantity(700, np.int64(5))
        same('numpy_int64_decrease_preserves_hidden_position_and_type')
        _price_control_put(indexed, Side.BID, 120, 701, 6, True)
        _price_control_put(parent, Side.BID, 120, 701, 6, True)
        li._update_order_quantity(700, 10); lp._update_order_quantity(700, 10)
        same('increase_moves_to_hidden_tail')
        hi = li._peek()[0]; hp = lp._peek()[0]
        indexed_arena._set(hi, 3, 4); parent_arena._set(hp, 3, 4)
        same('partial_fill_live_handle_alias_not_quantity_cache')
        # Equal int/np.int64 keys share the same original level without coercing
        # price representation; extreme arbitrary Python ints remain valid.
        for side, price, ident in ((Side.ASK, np.int64(107), 800),
            (Side.BID, np.int32(100), 801), (Side.ASK, 0, 804)):
            _price_control_put(indexed, side, price, ident)
            _price_control_put(parent, side, price, ident)
        same('numpy_mixed_keys_and_zero')
        record('old_cancel_reference_wrong_side_preserves', _price_control_cancel(indexed, Side.ASK, 100, 801)
            == _price_control_cancel(parent, Side.ASK, 100, 801) == False)
        # Exercise direct execution deletion helper without message delivery:
        # same canonical list delta, removed level no longer retained by index.
        removed_i = indexed._slot_asks[0]
        removed_p = parent._slot_asks[0]
        indexed._delete_price_level(indexed._slot_asks, 0)
        del parent._slot_asks[0]
        same('execution_empty_level_delete_updates_price_map')
        record('deleted_price_absent_from_index', removed_i._slot_price not in indexed._price_index_token[2])
        for h, m in removed_i._slot_visible_orders + removed_i._slot_hidden_orders:
            indexed_arena._release(h)
        for h, m in removed_p._slot_visible_orders + removed_p._slot_hidden_orders:
            parent_arena._release(h)
        removed_i._slot_visible_orders.clear(); removed_i._slot_hidden_orders.clear()
        removed_p._slot_visible_orders.clear(); removed_p._slot_hidden_orders.clear()
        # Public list exposure invalidates both side maps before external writes.
        exposed = indexed.bids
        record('external_list_exposure_sticky_both_maps_empty', indexed.price_index_witness()['enabled'] == False
            and len(indexed._price_index_token[1]) == len(indexed._price_index_token[2]) == 0)
        record('exposed_list_identity_preserved', exposed is indexed._slot_bids)
        indexed._activate_fresh_price_index()
        record('invalidated_book_cannot_readmit', indexed.price_index_witness()['enabled'] == False)
        _price_control_put(indexed, Side.BID, 98, 900); _price_control_put(parent, Side.BID, 98, 900)
        same('fallback_after_exposure_matches_parent')
        # Mixed exact int/NumPy comparisons near promotion boundaries must
        # preserve parent scans and dictionary key consistency. Values beyond
        # common exact 53-bit domain are never clipped, only algorithm-declined.
        boundary_values = ((1 << 53) - 1, 1 << 53, (1 << 53) + 1,
            (1 << 63) - 1, 1 << 63, (1 << 63) + 1,
            -(1 << 53) - 1, -(1 << 53), -(1 << 63), -(1 << 63) - 1)
        for side in (Side.BID, Side.ASK):
            for large in boundary_values:
                neighbor = min((1 << 63) - 1, max(-(1 << 63), large - 1))
                for order_values in ((large, np.int64(neighbor), np.int32(100)),
                    (np.int64(neighbor), np.int32(100), large), (np.int32(100), large, np.int64(neighbor))):
                    boundary_i = _price_control_book(indexed_arena, True)
                    boundary_p = _price_control_book(parent_arena, False)
                    for ident, price in enumerate(order_values):
                        _price_control_put(boundary_i, side, price, 910 + ident)
                        _price_control_put(boundary_p, side, price, 910 + ident)
                    label = side.value + '_' + str(large) + '_' + type(order_values[0]).__name__
                    record('mixed_price_boundary_insert_' + label,
                        _price_control_signature(boundary_i) == _price_control_signature(boundary_p)
                        and (boundary_i.price_index_witness()['enabled']
                            if all(abs(int(value)) <= (1 << 53) for value in order_values)
                            else not boundary_i.price_index_witness()['enabled']))
                    for ident, price in enumerate(order_values):
                        record('mixed_price_boundary_cancel_' + label + '_' + str(ident),
                            _price_control_cancel(boundary_i, side, price, 910 + ident)
                            == _price_control_cancel(boundary_p, side, price, 910 + ident)
                            and _price_control_signature(boundary_i) == _price_control_signature(boundary_p))
                    _price_control_release(boundary_i); _price_control_release(boundary_p)
        # Custom numerical prices must evaluate exactly the same fallback
        # comparisons; hashing them is an immediate failed control.
        custom_i = _PriceControlNumber(102); custom_p = _PriceControlNumber(102)
        indexed._price_index_exposed = False
        indexed._price_index_started = False
        indexed._price_index_token = [True, {}, {}, 'control-rearm-before-custom-only']
        _price_control_put(indexed, Side.BID, custom_i, 901)
        _price_control_put(parent, Side.BID, custom_p, 901)
        record('custom_price_declines_before_hash_or_changed_comparisons', custom_i.calls == custom_p.calls
            and 'hash' not in custom_i.calls and indexed.price_index_witness()['enabled'] == False)
        # Normalize only the two separate custom instances for comparison.
        custom_i.calls.clear(); custom_p.calls.clear()
        record('custom_fallback_same_sorted_prices', [getattr(x[0], 'value', x[0])
            for x in _price_control_signature(indexed)[0]] == [getattr(x[0], 'value', x[0])
            for x in _price_control_signature(parent)[0]])
        # Direct supported structural PTC path: separate halves preserve
        # side+price and the same ID. Competition whole-input admission still
        # declines unsupported partial PTC execution; this adds no new admission.
        for side in (Side.BID, Side.ASK):
            ptc_i = _price_control_book(indexed_arena, True)
            ptc_p = _price_control_book(parent_arena, False)
            hi = indexed_arena._new_limit(1, 1, 'ABM', 5, side, 100, 920, False, True)
            hp = parent_arena._new_limit(1, 1, 'ABM', 5, side, 100, 920, False, True)
            (<NativeBook>ptc_i)._enter_order(hi, None, True)
            (<NativeBook>ptc_p)._enter_order(hp, None, True)
            indexed_arena._release(hi); parent_arena._release(hp)
            ptc_levels_i = (<NativeBook>ptc_i)._slot_bids if side is Side.BID else (<NativeBook>ptc_i)._slot_asks
            ptc_levels_p = (<NativeBook>ptc_p)._slot_bids if side is Side.BID else (<NativeBook>ptc_p)._slot_asks
            record('PTC_' + side.value + '_two_separate_price_halves', len(ptc_levels_i) == len(ptc_levels_p) == 2
                and (<NativeLevel>ptc_levels_i[0])._slot_price == (101 if side is Side.BID else 99)
                and len((<NativeLevel>ptc_levels_i[0])._slot_hidden_orders) == 1
                and len((<NativeLevel>ptc_levels_i[1])._slot_visible_orders) == 1)
            record('PTC_' + side.value + '_recursive_cancel_both_halves',
                _price_control_cancel(ptc_i, side, 100, 920) == _price_control_cancel(ptc_p, side, 100, 920) == True
                and not ptc_levels_i and not ptc_levels_p)
            record('PTC_' + side.value + '_index_empty_after_cancel',
                not (<NativeBook>ptc_i)._price_index_token[1] and not (<NativeBook>ptc_i)._price_index_token[2])
            _price_control_release(ptc_i); _price_control_release(ptc_p)
        for policy in ('cancel_oldest', 'cancel_newest'):
            stp_i = _price_control_book(indexed_arena, True)
            stp_p = _price_control_book(parent_arena, False)
            _price_control_put(stp_i, Side.ASK, 100, 930)
            _price_control_put(stp_p, Side.ASK, 100, 930)
            (<NativeBook>stp_i)._owner._slot_stp_policy = policy
            (<NativeBook>stp_p)._owner._slot_stp_policy = policy
            hi = indexed_arena._new_limit(1, 1, 'ABM', 5, Side.BID, 100, 931)
            hp = parent_arena._new_limit(1, 1, 'ABM', 5, Side.BID, 100, 931)
            try:
                (<NativeBook>stp_i)._handle_limit_order(hi, True)
                (<NativeBook>stp_p)._handle_limit_order(hp, True)
                record('STP_' + policy + '_exact_structure_and_quantities',
                    _price_control_signature(stp_i) == _price_control_signature(stp_p)
                    and indexed_arena._get(hi, 3) == parent_arena._get(hp, 3) == 5)
            finally:
                indexed_arena._release(hi); parent_arena._release(hp)
                _price_control_release(stp_i); _price_control_release(stp_p)
        # Every public key/queue setter and deletion must disable both maps,
        # including same-object setters: aliases may still be externally held.
        for field in ('price', 'side', 'visible_orders', 'hidden_orders'):
            for operation in ('setter', 'delete'):
                mutant = _price_control_book(indexed_arena, True)
                _price_control_put(mutant, Side.BID, 5, 950)
                _price_control_put(mutant, Side.ASK, 7, 951)
                li = mutant._slot_bids[0]
                value = getattr(li, field)
                if operation == 'setter':
                    setattr(li, field, value)
                else:
                    delattr(li, field)
                record('level_' + field + '_' + operation + '_clears_both_maps',
                    mutant.price_index_witness()['enabled'] == False
                    and len(mutant._price_index_token[1]) == len(mutant._price_index_token[2]) == 0)
                # Restore original field for finite cleanup without re-admission.
                setattr(li, field, value)
                _price_control_release(mutant)
        for field in ('bids', 'asks'):
            for operation in ('setter', 'delete'):
                mutant = _price_control_book(indexed_arena, True)
                _price_control_put(mutant, Side.BID, 5, 952)
                _price_control_put(mutant, Side.ASK, 7, 953)
                # Read via typed fields so the getter is not the tested event.
                value = mutant._slot_bids if field == 'bids' else mutant._slot_asks
                if operation == 'setter':
                    setattr(mutant, field, value)
                else:
                    delattr(mutant, field)
                record('book_' + field + '_' + operation + '_clears_both_maps',
                    mutant.price_index_witness()['enabled'] == False
                    and len(mutant._price_index_token[1]) == len(mutant._price_index_token[2]) == 0)
                setattr(mutant, field, value)
                _price_control_release(mutant)
        # External list append/reorder is legal only on the exact parent scan
        # path. No O(1) side index claims to detect arbitrary mutable list writes.
        for side in (Side.BID, Side.ASK):
            for mutation in ('reverse', 'append'):
                alias_i = _price_control_book(indexed_arena, True)
                alias_p = _price_control_book(parent_arena, False)
                for price, ident in ((10, 970), (20, 971), (30, 972)):
                    _price_control_put(alias_i, side, price, ident)
                    _price_control_put(alias_p, side, price, ident)
                exposed_i = alias_i.bids if side is Side.BID else alias_i.asks
                exposed_p = alias_p.bids if side is Side.BID else alias_p.asks
                if mutation == 'reverse':
                    exposed_i.reverse(); exposed_p.reverse()
                else:
                    hi = indexed_arena._new_limit(1, 1, 'ABM', 7, side, 25, 973)
                    hp = parent_arena._new_limit(1, 1, 'ABM', 7, side, 25, 973)
                    exposed_i.append(NativeLevel([(hi, {'alias': True})], indexed_arena))
                    exposed_p.append(NativeLevel([(hp, {'alias': True})], parent_arena))
                    indexed_arena._release(hi); parent_arena._release(hp)
                record('external_' + side.value + '_' + mutation + '_sticky_parent_semantics',
                    not alias_i.price_index_witness()['enabled']
                    and _price_control_signature(alias_i) == _price_control_signature(alias_p))
                record('external_' + side.value + '_' + mutation + '_cancel_exact',
                    _price_control_cancel(alias_i, side, 20, 971) == _price_control_cancel(alias_p, side, 20, 971))
                _price_control_release(alias_i); _price_control_release(alias_p)
        # Primitive boolean/floating prices accepted by the parent direct API
        # keep its comparisons rather than entering a numeric-index domain.
        for price in (True, 11.0):
            numeric_i = _price_control_book(indexed_arena, True)
            numeric_p = _price_control_book(parent_arena, False)
            _price_control_put(numeric_i, Side.BID, 10, 980)
            _price_control_put(numeric_p, Side.BID, 10, 980)
            _price_control_put(numeric_i, Side.BID, price, 981)
            _price_control_put(numeric_p, Side.BID, price, 981)
            record('nonindex_' + type(price).__name__ + '_price_same_parent_structure',
                not numeric_i.price_index_witness()['enabled']
                and _price_control_signature(numeric_i) == _price_control_signature(numeric_p))
            _price_control_release(numeric_i); _price_control_release(numeric_p)
        empty_i = _price_control_book(indexed_arena, True)
        empty_p = _price_control_book(parent_arena, False)
        record('empty_book_cancel_false', _price_control_cancel(empty_i, Side.BID, 2, 991)
            == _price_control_cancel(empty_p, Side.BID, 2, 991) == False)
        for operation in ('peek', 'pop'):
            hi = indexed_arena._new_limit(1, 1, 'ABM', 1, Side.BID, 2, 992)
            hp = parent_arena._new_limit(1, 1, 'ABM', 1, Side.BID, 2, 992)
            li = NativeLevel([(hi, None)], indexed_arena)
            lp = NativeLevel([(hp, None)], parent_arena)
            li._pop(); lp._pop()
            indexed_arena._release(hi); parent_arena._release(hp)
            indexed_arena._release(hi); parent_arena._release(hp)
            failures = []
            for target in (li, lp):
                try:
                    getattr(target, operation)()
                except ValueError as error:
                    failures.append((type(error).__name__, str(error)))
            record('empty_level_' + operation + '_exception_exact', len(failures) == 2 and failures[0] == failures[1])
        _price_control_release(empty_i); _price_control_release(empty_p)
        # Lifecycle cleanup releases canonical queues exactly once; maps never
        # retain order handles, so stale generations do not survive cancellation.
        _price_control_release(indexed); _price_control_release(parent)
        record('all_canonical_queues_released', indexed_arena.statistics()['live_orders'] == parent_arena.statistics()['live_orders'] == 0)
        fresh_i = indexed_arena._new_limit(1, 1, 'ABM', 1, Side.BID, 2, 1)
        fresh_p = parent_arena._new_limit(1, 1, 'ABM', 1, Side.BID, 2, 1)
        indexed_arena._release(fresh_i); parent_arena._release(fresh_p)
        record('arena_recycling_no_index_reference', indexed_arena.statistics()['live_orders'] == parent_arena.statistics()['live_orders'] == 0)
        return {'schema': 't3-native-price-index-finite-controls-v1', 'cases': cases,
            'all_passed': all(x['passed'] for x in cases), 'market_executed': False,
            'control_only': True, 'native_index_enabled_during_lookup_cases': True,
            'rankable': False, 'speed_claim': False,
            'required_integration_cases': ['PTC-two-half-original-fallback', 'STP-newest-oldest',
                'full-state-alias-RNG-MT624-Gaussian', 'trace-ledger', 'batch', 'both-official-verbs']}
    finally:
        _price_control_release(indexed); _price_control_release(parent)
        Order._order_id_counter = counter
        _observer.STATE = old_observer
