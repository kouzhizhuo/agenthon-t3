"""Linux-only latency equality, complete MT624 and fallback controls."""
import struct
import tempfile
from pathlib import Path
from types import MethodType
import numpy as np
from abides_fork.config import ScenarioLatencyModel
from exact_latency import select_latency, scalar_latency


def state_bytes(rng):
    name, keys, position, has_gauss, gauss = rng.get_state()
    return (name, keys.tobytes(), position, has_gauss, struct.pack('!d', gauss))


def run_controls():
    rows = []
    specs = [
        ('deterministic_half_even', {'model':'deterministic','params':{'mean_ns':1.5}}, {}),
        ('deterministic_negative', {'model':'deterministic','params':{'mean_ns':-1.5,'min_ns':-3}}, {}),
        ('unknown_constant', {'model':'unknown','params':{'mean_ns':2.5}}, {}),
        ('uniform', {'model':'uniform','params':{'min_ns':0,'max_ns':2000}}, {}),
        ('uniform_equal_still_draws', {'model':'uniform','params':{'min_ns':5,'max_ns':5}}, {}),
        ('lognormal', {'model':'log_normal','params':{'mean_ns':500,'sigma':1.2,'max_ns':2000}}, {}),
        ('lognormal_zero_sigma_still_draws', {'model':'log_normal','params':{'mean_ns':3,'sigma':0}}, {}),
        ('pareto', {'model':'pareto','params':{'min_ns':1,'max_ns':2000,'alpha':1.5}}, {}),
        ('pareto_zero_base', {'model':'pareto','params':{'min_ns':0,'max_ns':2000}}, {}),
        ('lognormal_overflow', {'model':'log_normal','params':{'mean_ns':1,'sigma':1}}, {'_mu':710.0}),
        ('pareto_overflow', {'model':'pareto','params':{'min_ns':1,'max_ns':2000,'alpha':1e-300}}, {}),
    ]
    for name, spec, changed in specs:
        for position in (622,623,624):
            for cached in (None,0.0,-0.0,-1.2345):
                originals = []
                for _ in range(2):
                    rng=np.random.RandomState(307)
                    state=list(rng.get_state()); state[2]=position
                    if cached is not None: state[3]=1;state[4]=cached
                    rng.set_state(tuple(state))
                    model=ScenarioLatencyModel(3,spec,rng)
                    for field,value in changed.items():setattr(model,field,value)
                    originals.append(model)
                left,right=originals
                selected=select_latency(right)
                assert selected.__func__ is scalar_latency
                before=state_bytes(right.random_state)
                assert selected(1,1)==left.get_latency(1,1)==0
                assert state_bytes(right.random_state)==before
                for i in range(700):
                    assert left.get_latency(i%3,(i+1)%3)==selected(i%3,(i+1)%3)
                    assert state_bytes(left.random_state)==state_bytes(right.random_state)
                rows.append({'case':name+':'+str(position)+':'+repr(cached),'calls':700,'passed':True})
    def model():
        return ScenarioLatencyModel(3,{'model':'uniform','params':{'min_ns':0,'max_ns':3}},np.random.RandomState(307))
    unsupported = [('_min_ns',None),('_min_ns',np.float64(0)),('_min_ns',np.array([0.])),
        ('_min_ns',float('nan')),('_max_ns',float('inf')),('_min_ns',5.0)]
    for field,value in unsupported:
        current=model();setattr(current,field,value)
        before=state_bytes(current.random_state);chosen=select_latency(current)
        assert chosen.__func__ is ScenarioLatencyModel.get_latency
        assert state_bytes(current.random_state)==before
        rows.append({'case':'refuse:'+field+':'+type(value).__name__+':'+repr(value),'passed':True})
    for distribution,field,value in (('log_normal','_sigma',-1.0),('pareto','_alpha',0.0)):
        current=model();current._model=distribution;setattr(current,field,value)
        assert select_latency(current).__func__ is ScenarioLatencyModel.get_latency
        rows.append({'case':'refuse:'+distribution+field,'passed':True})
    current=model();current.get_latency=MethodType(lambda self,sender_id,recipient_id:17,current)
    assert select_latency(current).__func__ is current.get_latency.__func__
    assert select_latency(current)(0,1)==17
    rows.append({'case':'preserve_custom_instance_callback','passed':True})
    class Custom(ScenarioLatencyModel):
        pass
    current=Custom(3,{},np.random.RandomState(307))
    assert select_latency(current).__func__ is ScenarioLatencyModel.get_latency
    rows.append({'case':'preserve_custom_class','passed':True})
    assert len(rows)==142
    return {'schema':'t3-classic-scalar-latency-controls-v1','all_passed':True,'cases':rows,
        'full_MT624_each_draw':True,'per_case_random_calls':700,'market_executed':False,
        'model_mutated':False,'rankable':False,'speed_claim':False}


def run_source_controls():
    import types
    import observer
    import observer_domain as domain
    import contracts
    from abides_fork import agents
    rows=[]
    assert domain.authenticate_loaded()
    def restored_case(name,obj,field,value):
        old=getattr(obj,field)
        try:
            setattr(obj,field,value)
            assert not domain.authenticate_loaded()
        finally:
            setattr(obj,field,old)
        assert domain.authenticate_loaded()
        rows.append({'case':name,'passed':True})
    restored_case('changed_module_source_path',contracts,'__file__',str(Path(contracts.__file__).with_name('wrong.py')))
    restored_case('nonstring_module_source_path',contracts,'__file__',Path(contracts.__file__))
    restored_case('changed_function_code',contracts.validate_scenario,'__code__',(lambda x:None).__code__)
    restored_case('changed_function_defaults',contracts.validate_scenario,'__defaults__',(None,))
    restored_case('replaced_strategy_export',agents,'NoiseTrader',type('NoiseTrader',(),{}))
    registry=agents.AGENT_REGISTRY
    restored_case('replaced_registry',agents,'AGENT_REGISTRY',{})
    assert agents.AGENT_REGISTRY is registry
    original_root=observer.__file__
    with tempfile.TemporaryDirectory(dir='/output') as scratch:
        scratch=Path(scratch)
        p=scratch/'contracts.py';data=Path(contracts.__file__).read_bytes();p.write_bytes(data)
        fake=types.SimpleNamespace(__file__=str(p))
        # This independent scratch-source control has no build artifact. Keep
        # the parent compile path explicitly isolated and restore live caches.
        saved_context=domain._EXPECTATION_CONTEXT
        saved_cache=domain._SOURCE_CACHE
        saved_receipts=domain._CACHE_RECEIPTS
        saved_counts=(domain._CACHE_COMPILES,domain._CACHE_AST_PARSES)
        try:
            domain._EXPECTATION_CONTEXT=None
            domain._SOURCE_CACHE={}
            domain._CACHE_RECEIPTS={}
            observer.__file__=str(scratch/'observer.py')
            images={};first=domain._source_image(fake,images)
            assert domain._source_image(fake,images) is first
            p.write_bytes(data.replace(b'Deterministic',b'DeterministiC',1))
            assert len(p.read_bytes())==len(data) and p.read_bytes()!=data
            try:domain._source_image(fake,{})
            except ValueError:pass
            else:raise AssertionError('fresh same-length mutation was accepted')
            p.write_bytes(data)
            assert domain._source_image(fake,{}) is first
            rows.append({'case':'fresh_same_length_mutation_detected','passed':True})
            fake.__file__=str(scratch/'wrong.py')
            try:domain._source_image(fake,images)
            except ValueError:pass
            else:raise AssertionError('changed string reused stale resolved path')
            rows.append({'case':'same_call_changed_path_rechecked','passed':True})
        finally:
            observer.__file__=original_root
            domain._EXPECTATION_CONTEXT=saved_context
            domain._SOURCE_CACHE=saved_cache
            domain._CACHE_RECEIPTS=saved_receipts
            domain._CACHE_COMPILES,domain._CACHE_AST_PARSES=saved_counts
    assert domain.authenticate_loaded() and len(rows)==8
    return {'all_passed':True,'cases':rows,'market_executed':False,'bindings_restored':True,'rankable':False}
