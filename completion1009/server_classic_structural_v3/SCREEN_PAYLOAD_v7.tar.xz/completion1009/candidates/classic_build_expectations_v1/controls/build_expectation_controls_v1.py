"""Linux-only warm/cold provenance mutations; this control executes no market."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import types


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True); parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--scratch-child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args(); candidate = Path(__file__).resolve().parents[1]
    if args.out.exists(): raise ValueError("fresh expectation control output required")
    args.out.mkdir(parents=True)
    if not args.scratch_child:
        # Production sources/build mount may be read-only. Mutations are only
        # against a byte-verified source/artifact copy in this control's output.
        copy = args.out / "scratch-candidate"; copy.mkdir()
        receipt_path = candidate / "SOURCE_PREPARATION_RECEIPT_v1.json"
        source_receipt = json.loads(receipt_path.read_bytes())
        for row in source_receipt["files"]:
            source = candidate / row["path"]; target = copy / row["path"]
            data = source.read_bytes()
            if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
                raise ValueError("scratch source differs from frozen candidate")
            target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
        shutil.copyfile(receipt_path, copy / receipt_path.name)
        (copy / "build").mkdir()
        shutil.copyfile(args.build / "BUILD_RECEIPT.json", copy / "build/BUILD_RECEIPT.json")
        shutil.copytree(args.build / "expectations", copy / "build/expectations")
        child_out = args.out / "child-evidence"
        command = [sys.executable, "-B", str(copy / "controls/build_expectation_controls_v1.py"),
            "--runtime", str(copy / "runtime"), "--build", str(copy / "build"),
            "--out", str(child_out), "--scratch-child"]
        with (args.out / "child.log").open("xb") as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
        child_report = child_out / "BUILD_EXPECTATION_CONTROLS.json"
        if child_report.is_file(): shutil.copyfile(child_report, args.out / "BUILD_EXPECTATION_CONTROLS.json")
        if result.returncode: raise RuntimeError("build expectation scratch controls failed")
        print(json.dumps({"all_passed": True, "scratch_source_copy": True, "market_executed": False}))
        return
    sys.path.insert(0, str(candidate))
    from production_cli import activate_paths
    activate_paths(args.runtime)
    import observer_domain as domain
    import build_expectation_loader as loader
    from arena_admission import admit
    import observer
    import contracts
    from abides_fork import agents
    from abides_markets.agents import trading_agent
    from abides_markets import orders, order_book
    from abides_core import abides
    from abides_core.kernel import Kernel
    runtime, build = args.runtime.resolve(), args.build.resolve()
    report = {"schema": "t3-build-expectations-negative-controls-v1", "all_passed": False,
        "market_executed": False, "rankable": False, "speed_claim": False, "cases": []}
    rows = report["cases"]
    scenario = {"agent_configs": [{"agent_type": "NoiseTrader"}]}
    initial_kernel, initial_summary = abides.Kernel, Kernel.write_summary_log
    def positive():
        if not domain.authenticate_loaded() or not admit(scenario, runtime):
            raise AssertionError("restored exact domain refused")
        if observer.STATE is not None or abides.Kernel is not initial_kernel or Kernel.write_summary_log is not initial_summary:
            raise AssertionError("admission mutated episode/global bindings")
    def check(name, test):
        test(); positive(); rows.append({"case": name, "passed": True})
    def patch_rejected(obj, name, value):
        old = getattr(obj, name)
        try:
            setattr(obj, name, value)
            if domain.authenticate_loaded(): raise AssertionError("changed loaded domain accepted")
        finally: setattr(obj, name, old)
    def direct_rejected(call):
        try: call()
        except (ValueError, KeyError, TypeError, OSError): return
        raise AssertionError("changed build authority accepted")
    def mutate_bytes(path, call):
        original = path.read_bytes()
        try:
            changed = bytearray(original); changed[len(changed)//2] ^= 1; path.write_bytes(changed)
            direct_rejected(call)
        finally: path.write_bytes(original)
    try:
        domain.configure_expectations(build, runtime)
        positive()
        cold = domain.expectation_witness()
        if cold["runtime_source_compiles"] != 0 or cold["runtime_ast_parses"] != 0 or cold["build_expectation_loads"] != 22:
            raise AssertionError("cold path failed to use exact22 build images without compile/parse")
        rows.append({"case": "cold_exact22_build_images_without_compile_or_ast", "passed": True, "witness": cold})
        positive(); warm = domain.expectation_witness()
        if warm["build_expectation_loads"] != cold["build_expectation_loads"] or warm["build_expectation_revalidations"] <= cold["build_expectation_revalidations"]:
            raise AssertionError("warm expected structure did not get fresh artifact checks")
        rows.append({"case": "warm_cache_revalidates_and_never_caches_admission", "passed": True, "witness": warm})
        check("changed_method_code_warm", lambda: patch_rejected(contracts.validate_scenario, "__code__", (lambda x: None).__code__))
        check("changed_positional_default_warm", lambda: patch_rejected(contracts.validate_scenario, "__defaults__", (None,)))
        old = trading_agent.TradingAgent.cancel_order.__defaults__
        if type(old) is not tuple or type(old[-1]) is not dict: raise AssertionError("real mutable default fixture absent")
        def mutable_default():
            old[-1]["control"] = 1
            try:
                if domain.authenticate_loaded(): raise AssertionError("in-place mutable default accepted")
            finally: old[-1].pop("control")
        check("inplace_mutable_default_warm", mutable_default)
        check("changed_keyword_defaults_warm", lambda: patch_rejected(contracts.validate_scenario, "__kwdefaults__", {"changed": 1}))
        original = contracts.validate_scenario
        replaced = types.FunctionType(original.__code__, dict(original.__globals__), original.__name__, original.__defaults__)
        check("same_code_different_function_globals", lambda: patch_rejected(contracts, "validate_scenario", replaced))
        check("replaced_strategy_class_export", lambda: patch_rejected(agents, "NoiseTrader", type("NoiseTrader", (), {})))
        check("changed_owning_global_binding", lambda: patch_rejected(trading_agent, "LimitOrder", object()))
        check("changed_sys_maxsize_owner", lambda: patch_rejected(order_book, "sys", types.SimpleNamespace(maxsize=sys.maxsize)))
        check("changed_module_source_path", lambda: patch_rejected(contracts, "__file__", str(runtime / "wrong.py")))
        context = domain._EXPECTATION_CONTEXT
        manifest = loader.fresh_manifest(context)
        contract_row = manifest["contracts.py"]
        source = runtime / "contracts.py"
        def source_mutation():
            original_data = source.read_bytes()
            try:
                # Same-length SHA mutation must be rejected before cache hit.
                changed = bytearray(original_data); changed[changed.index(b"Deterministic")] ^= 32
                source.write_bytes(changed)
                if domain.authenticate_loaded(): raise AssertionError("fresh source mutation accepted from warm cache")
            finally: source.write_bytes(original_data)
        check("same_length_source_mutation_warm", source_mutation)
        for label, path in (("code_blob", build / "expectations" / contract_row["code"]["path"]),
                ("defaults_blob", build / "expectations" / contract_row["defaults"]["path"]),
                ("manifest", build / "expectations/EXPECTATIONS.json"), ("build_receipt", build / "BUILD_RECEIPT.json")):
            check("changed_" + label + "_warm", lambda path=path: mutate_bytes(path, lambda: domain._source_image(contracts, {})))
        extra = build / "expectations/unmanifested-control"
        def unexpected_artifact():
            extra.write_bytes(b"unexpected")
            try: direct_rejected(lambda: loader.fresh_manifest(context))
            finally: extra.unlink()
        check("unmanifested_build_artifact", unexpected_artifact)
        current = loader.current_abi
        for field in ("python", "magic", "cache_tag", "soabi", "extension_suffix", "marshal_version", "optimize"):
            def wrong_abi(field=field):
                changed = current(); changed[field] = [3, 11, 16] if field == "python" else "changed"
                loader.current_abi = lambda: changed
                try: direct_rejected(lambda: loader.fresh_manifest(context))
                finally: loader.current_abi = current
            check("wrong_interpreter_" + field, wrong_abi)
        key = (source.resolve(), hashlib.sha256(source.read_bytes()).hexdigest())
        image = domain._SOURCE_CACHE[key]
        def replaced_cache():
            domain._SOURCE_CACHE[key] = dict(image)
            try:
                if domain.authenticate_loaded(): raise AssertionError("replaced expected image cache accepted")
            finally: domain._SOURCE_CACHE[key] = image
        check("replaced_expected_image_cache", replaced_cache)
        def removed_cache():
            domain._SOURCE_CACHE.pop(key)
            try:
                if domain.authenticate_loaded(): raise AssertionError("removed expected cache accepted")
            finally: domain._SOURCE_CACHE[key] = image
        check("removed_expected_image_cache", removed_cache)
        def changed_expected_code():
            old_code = image["code"]; image["code"] = old_code.replace(co_consts=(None,))
            try:
                if domain.authenticate_loaded(): raise AssertionError("changed expected code accepted")
            finally: image["code"] = old_code
        check("changed_expected_code_object", changed_expected_code)
        def changed_expected_defaults():
            saved = dict(image["defaults"]); image["defaults"].clear()
            try:
                if domain.authenticate_loaded(): raise AssertionError("changed expected defaults cache accepted")
            finally: image["defaults"].update(saved)
        check("changed_expected_defaults_cache", changed_expected_defaults)
        def changed_expected_function():
            saved = dict(image["functions"]); image["functions"].clear()
            try:
                if domain.authenticate_loaded(): raise AssertionError("changed expected function cache accepted")
            finally: image["functions"].update(saved)
        check("changed_expected_function_cache", changed_expected_function)
        with tempfile.TemporaryDirectory(dir=args.out) as scratch:
            def switched_context():
                root = Path(scratch); shutil.copyfile(build / "BUILD_RECEIPT.json", root / "BUILD_RECEIPT.json")
                shutil.copytree(build / "expectations", root / "expectations")
                direct_rejected(lambda: loader.configure(root, runtime, context))
            check("batch_context_switch_refused", switched_context)
        report.update(all_passed=True, final_witness=domain.expectation_witness(),
            bindings_restored=True, observer_finished=True, actual_controls=len(rows))
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (args.out / "BUILD_EXPECTATION_CONTROLS.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"all_passed": True, "actual_controls": len(rows), "market_executed": False}))


if __name__ == "__main__": main()
