"""Fresh artifact/source authority; cache only expected immutable structures."""
import hashlib
import importlib.util
import json
import marshal
from pathlib import Path
import platform
import struct
import sys
import sysconfig
import types
from source_provenance import HERE, SOURCE_RECEIPT, clean_path, sha


def current_abi():
    return {"implementation": sys.implementation.name, "python": list(sys.version_info[:3]),
        "platform": sys.platform, "machine": platform.machine(), "pointer_bits": struct.calcsize("P") * 8,
        "byteorder": sys.byteorder, "magic": importlib.util.MAGIC_NUMBER.hex(),
        "cache_tag": sys.implementation.cache_tag, "soabi": sysconfig.get_config_var("SOABI"),
        "extension_suffix": sysconfig.get_config_var("EXT_SUFFIX"), "marshal_version": marshal.version,
        "optimize": sys.flags.optimize}


def read_pinned(path, row):
    path = Path(path)
    if path.is_symlink(): raise ValueError("expectation artifact symlink refused")
    data = path.read_bytes()
    if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
        raise ValueError("expectation artifact bytes differ")
    return data


def fresh_manifest(context):
    root, runtime, receipt_hash, manifest_hash = context
    receipt_path = root / "BUILD_RECEIPT.json"
    if receipt_path.is_symlink(): raise ValueError("build receipt symlink refused")
    receipt_data = receipt_path.read_bytes()
    if hashlib.sha256(receipt_data).hexdigest() != receipt_hash:
        raise ValueError("build receipt changed after binding")
    receipt = json.loads(receipt_data)
    expected = receipt["expectations"]
    if expected["path"] != "expectations/EXPECTATIONS.json" or expected["sha256"] != manifest_hash:
        raise ValueError("unexpected expectations deployment path")
    manifest = json.loads(read_pinned(root / expected["path"], expected))
    if (receipt.get("build_succeeded") is not True or manifest.get("schema") != "t3-build-expectations-v1"
            or manifest.get("ABI") != current_abi() or expected.get("ABI") != manifest["ABI"]
            or manifest["ABI"]["python"] != [3, 11, 17] or manifest["ABI"]["implementation"] != "cpython"
            or manifest["ABI"]["platform"] != "linux" or manifest["ABI"]["machine"] != "x86_64"
            or manifest["ABI"]["pointer_bits"] != 64 or manifest["ABI"]["byteorder"] != "little"
            or manifest["ABI"]["optimize"] != 0 or manifest.get("admission_cached") is not False
            or manifest.get("participant_imported") is not False or manifest.get("market_executed") is not False):
        raise ValueError("expectation schema or interpreter ABI differs")
    for field, path in (("source_receipt_sha256", HERE / SOURCE_RECEIPT),
            ("runtime_pins_sha256", HERE / "RUNTIME_PINS.json"), ("compile_spec_sha256", HERE / "compile_spec.json")):
        if receipt.get(field) != sha(path) or manifest.get(field) != receipt[field]:
            raise ValueError("expectation source/build pins differ")
    rows = manifest["sources"]
    if len(rows) != 22 or len({row["source"] for row in rows}) != 22:
        raise ValueError("expectation source roster differs")
    artifacts = {"EXPECTATIONS.json"}
    for row in rows:
        if not clean_path(row["source"]): raise ValueError("unsafe expectation source path")
        for field in ("code", "defaults"):
            relative = row[field]["path"]
            if not clean_path(relative) or "/" in relative: raise ValueError("unsafe expectation artifact path")
            if relative in artifacts: raise ValueError("duplicate expectation artifact")
            artifacts.add(relative)
    actual = {path.name for path in (root / "expectations").iterdir()}
    if actual != artifacts: raise ValueError("unmanifested or missing expectation artifact")
    return {row["source"]: row for row in rows}


def configure(build_dir, runtime, old=None):
    root, runtime = Path(build_dir).resolve(), Path(runtime).resolve()
    receipt_path = root / "BUILD_RECEIPT.json"
    if receipt_path.is_symlink(): raise ValueError("build receipt symlink refused")
    data = receipt_path.read_bytes()
    receipt = json.loads(data)
    context = (root, runtime, hashlib.sha256(data).hexdigest(), receipt["expectations"]["sha256"])
    if old is not None and context != old:
        raise ValueError("expectation context changed between batch markets")
    fresh_manifest(context)
    return context


def freeze(value):
    if type(value) is list: return tuple(freeze(item) for item in value)
    if type(value) in (type(None), bool, str): return value
    raise ValueError("unexpected default descriptor JSON value")


def decode_literal(row):
    if type(row) is not tuple or not row or type(row[0]) is not str:
        raise ValueError("malformed exact literal descriptor")
    tag = row[0]
    if tag == "none" and len(row) == 1: return None
    if tag == "ellipsis" and len(row) == 1: return Ellipsis
    if tag == "bool" and len(row) == 2 and type(row[1]) is bool: return row[1]
    if tag == "int" and len(row) == 2: return int(row[1])
    if tag == "float" and len(row) == 2: return float.fromhex(row[1])
    if tag == "complex" and len(row) == 3: return complex(float.fromhex(row[1]), float.fromhex(row[2]))
    if tag == "str" and len(row) == 2 and type(row[1]) is str: return row[1]
    if tag == "bytes" and len(row) == 2: return bytes.fromhex(row[1])
    if tag in ("tuple", "list", "set") and len(row) == 2 and type(row[1]) is tuple:
        values = [decode_literal(item) for item in row[1]]
        return tuple(values) if tag == "tuple" else set(values) if tag == "set" else values
    if tag == "dict" and len(row) == 2 and type(row[1]) is tuple:
        return {decode_literal(pair[0]): decode_literal(pair[1]) for pair in row[1]}
    raise ValueError("unsupported literal default descriptor")


def load_image(context, relative, source_digest, manifest):
    root, runtime, _, _ = context
    row = manifest[relative]
    if source_digest != row["source_sha256"]:
        raise ValueError("fresh source differs from expected artifact authority")
    code_data = read_pinned(root / "expectations" / row["code"]["path"], row["code"])
    default_data = read_pinned(root / "expectations" / row["defaults"]["path"], row["defaults"])
    return row, code_data, default_data


def decode_image(code_data, default_data, relative, source_digest):
    code = marshal.loads(code_data)
    if type(code) is not types.CodeType: raise ValueError("expected exact marshalled code object")
    data = json.loads(default_data)
    if (data.get("schema") != "t3-source-defaults-v1" or data.get("source") != relative
            or data.get("source_sha256") != source_digest):
        raise ValueError("defaults descriptor source differs")
    defaults = {}
    for row in data["functions"]:
        key = row["class"], row["name"], row["first"]
        if (type(key[0]) not in (str, type(None)) or type(key[1]) is not str
                or type(key[2]) is not bool or key in defaults):
            raise ValueError("invalid or duplicate defaults function key")
        defaults[key] = freeze(row["positional"]), freeze(row["keywords"])
    return {"code": code, "tree": None, "functions": {}, "defaults": defaults}
