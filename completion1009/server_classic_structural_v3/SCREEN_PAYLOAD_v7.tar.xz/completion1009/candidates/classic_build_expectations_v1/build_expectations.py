"""Linux build-only code/default expectations; never imports simulator sources."""
import ast
import hashlib
import importlib.util
import json
import marshal
from pathlib import Path
import platform
import struct
import sys
import sysconfig
import types
from source_provenance import HERE, SOURCE_RECEIPT, clean_path, sha, verify_runtime, verify_sources

SCHEMA = "t3-build-expectations-v1"


def abi():
    return {"implementation": sys.implementation.name, "python": list(sys.version_info[:3]),
        "platform": sys.platform, "machine": platform.machine(), "pointer_bits": struct.calcsize("P") * 8,
        "byteorder": sys.byteorder, "magic": importlib.util.MAGIC_NUMBER.hex(),
        "cache_tag": sys.implementation.cache_tag, "soabi": sysconfig.get_config_var("SOABI"),
        "extension_suffix": sysconfig.get_config_var("EXT_SUFFIX"), "marshal_version": marshal.version,
        "optimize": sys.flags.optimize}


def encode_literal(value):
    kind = type(value)
    if kind is type(None): return ["none"]
    if kind is type(Ellipsis): return ["ellipsis"]
    if kind is bool: return ["bool", value]
    if kind is int: return ["int", str(value)]
    if kind is float: return ["float", value.hex()]
    if kind is complex: return ["complex", value.real.hex(), value.imag.hex()]
    if kind is str: return ["str", value]
    if kind is bytes: return ["bytes", value.hex()]
    if kind in (tuple, list, set):
        values = [encode_literal(item) for item in value]
        if kind is set: values.sort(key=lambda row: json.dumps(row, sort_keys=True))
        return [kind.__name__, values]
    if kind is dict:
        return ["dict", [[encode_literal(key), encode_literal(item)] for key, item in value.items()]]
    raise ValueError("unsupported exact literal default type")


def descriptor(node):
    if (isinstance(node, ast.Attribute) and node.attr == "maxsize"
            and isinstance(node.value, ast.Name) and node.value.id == "sys"):
        return ["sys.maxsize"]
    try:
        return ["literal", encode_literal(ast.literal_eval(node))]
    except (ValueError, TypeError):
        # An unrequested arbitrary default expression is not executed at build.
        # Requesting it later declines, just as the parent's literal_eval does.
        return ["unsupported", ast.dump(node, include_attributes=False)]


def default_rows(tree):
    rows = []
    def collect(nodes, owner):
        groups = {}
        for node in nodes:
            if isinstance(node, ast.FunctionDef): groups.setdefault(node.name, []).append(node)
        for name, matches in groups.items():
            for first, node in ((True, matches[0]), (False, matches[-1])):
                rows.append({"class": owner, "name": name, "first": first,
                    "positional": [descriptor(value) for value in node.args.defaults],
                    "keywords": [[argument.arg, descriptor(value)] for argument, value in
                        zip(node.args.kwonlyargs, node.args.kw_defaults) if value is not None]})
    collect(tree.body, None)
    for node in tree.body:
        if isinstance(node, ast.ClassDef): collect(node.body, node.name)
    return rows


def build(runtime, output):
    runtime, output = Path(runtime).resolve(), Path(output).resolve()
    current = abi()
    spec = json.loads((HERE / "compile_spec.json").read_bytes())
    if (current["implementation"] != "cpython" or current["python"] != [3, 11, 17]
            or current["platform"] != "linux" or current["machine"] != "x86_64"
            or current["pointer_bits"] != 64 or current["byteorder"] != "little" or current["optimize"] != 0
            or current["python"] != spec["python"]):
        raise ValueError("pinned unoptimized Linux CPython 3.11.17 required")
    sources, runtime_pins = verify_sources(), verify_runtime(runtime)
    if output.exists(): raise ValueError("fresh build expectations path required")
    output.mkdir(parents=True)
    domain = ast.parse((runtime / "observer_domain.py").read_bytes())
    pin_node = next(node for node in domain.body if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "_SOURCE_PINS" for target in node.targets))
    pins = ast.literal_eval(pin_node.value)
    if len(pins) != 22 or len(dict(pins)) != 22: raise ValueError("exact22 observer source roster required")
    known = {row["path"]: row for row in runtime_pins["files"]}
    rows = []
    for index, (relative, expected) in enumerate(pins):
        if not clean_path(relative) or known[relative]["sha256"] != expected:
            raise ValueError("expectation source not bound to runtime manifest")
        path = runtime / relative
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != expected: raise ValueError("build expectation source changed")
        code = compile(data, str(path), "exec", dont_inherit=True, optimize=0)
        tree = ast.parse(data)
        blob = marshal.dumps(code, marshal.version)
        restored = marshal.loads(blob)
        if type(restored) is not types.CodeType or restored != code:
            raise ValueError("marshal round trip changed expected code")
        defaults = {"schema": "t3-source-defaults-v1", "source": relative, "source_sha256": expected,
            "functions": default_rows(tree)}
        default_data = (json.dumps(defaults, sort_keys=True, separators=(",", ":")) + "\n").encode()
        prefix = f"{index:02d}"
        (output / (prefix + ".marshal")).write_bytes(blob)
        (output / (prefix + ".defaults.json")).write_bytes(default_data)
        rows.append({"source": relative, "source_bytes": len(data), "source_sha256": expected,
            "code": {"path": prefix + ".marshal", "bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest()},
            "defaults": {"path": prefix + ".defaults.json", "bytes": len(default_data), "sha256": hashlib.sha256(default_data).hexdigest()},
            "ast_sha256": hashlib.sha256(ast.dump(tree, include_attributes=True).encode()).hexdigest(),
            "marshal_roundtrip_equal_compile": True, "defaults_extracted_from_same_ast": True})
    if verify_sources() != sources or verify_runtime(runtime) != runtime_pins:
        raise ValueError("source changed during expectation build")
    manifest = {"schema": SCHEMA, "ABI": current, "sources": rows,
        "source_receipt_sha256": sha(HERE / SOURCE_RECEIPT), "runtime_pins_sha256": sha(HERE / "RUNTIME_PINS.json"),
        "compile_spec_sha256": sha(HERE / "compile_spec.json"), "source_only": True,
        "participant_imported": False, "market_executed": False, "admission_cached": False}
    path = output / "EXPECTATIONS.json"
    path.write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    return {"path": "expectations/EXPECTATIONS.json", "bytes": path.stat().st_size, "sha256": sha(path),
        "source_count": len(rows), "artifact_count": 1 + len(rows) * 2, "ABI": current}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(); parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True); args = parser.parse_args()
    print(json.dumps(build(args.runtime, args.out), sort_keys=True))
