This candidate moves code/AST/default expectation preparation into the pinned Linux build. It preserves the retained classic event engine and fresh per-episode source/artifact and loaded-domain checks. Linux build, negative mutations, full-state/output equality and same-run timing remain required before promotion.

# Changes

The source expectations manifest binds22 source files and CPython3.11.17 magic/ABI through BUILD_RECEIPT. Runtime never executes the marshalled expected code and never caches admission True. Native source, RNG draws, ownership, message constructor checks, output trace/ledger and numeric compiler flags match the frozen classic parent byte for byte. This component alone does not support a232000 EPS claim.
