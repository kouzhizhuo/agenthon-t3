"""Future source/ELF-bound import; never compiles at runtime."""
import json
from pathlib import Path
import platform
import struct
import sys
import sysconfig
from source_provenance import HERE, SOURCE_RECEIPT, sha, verify_sources, verify_runtime


def load(build_dir, runtime):
    import importlib
    root = Path(build_dir).resolve()
    verify_sources()
    verify_runtime(runtime)
    from observer_domain import configure_expectations
    configure_expectations(root, runtime)
    spec = json.loads((HERE / "compile_spec.json").read_bytes())
    receipt = json.loads((root / "BUILD_RECEIPT.json").read_bytes())
    if (receipt["build_succeeded"] is not True
            or receipt["source_receipt_sha256"] != sha(HERE / SOURCE_RECEIPT)
            or receipt["runtime_pins_sha256"] != sha(HERE / "RUNTIME_PINS.json")
            or receipt["compile_spec_sha256"] != sha(HERE / "compile_spec.json")
            or sys.platform != "linux" or platform.machine() != "x86_64"
            or list(sys.version_info[:3]) != spec["python"] or struct.calcsize("P") != 8 or sys.byteorder != "little"):
        raise ValueError("source, build or Linux ABI authority differs")
    paths = {}
    for row in receipt["extensions"]:
        path = root / row["path"]
        expected = root / "native" / (row["module"] + sysconfig.get_config_var("EXT_SUFFIX"))
        if path != expected or path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("native ELF artifact differs")
        paths[row["module"]] = path
    if set(paths) != set(spec["modules"]):
        raise ValueError("native extension roster differs")
    from importlib.metadata import version
    if {name: version(name) for name in spec["dependencies"]} != spec["dependencies"]:
        raise ValueError("loaded runtime dependencies differ from compiled ABI")
    sys.path.insert(0, str(root / "native"))
    modules = {}
    for name in ("dynamic_arena_chain",):
        module = importlib.import_module(name)
        if Path(module.__file__).resolve() != paths[name].resolve():
            raise ValueError("native module loaded from wrong path")
        modules[name] = module
    from composite_boundary import bind_dynamic_engine
    bind_dynamic_engine(modules["dynamic_arena_chain"], paths["dynamic_arena_chain"])
    return modules
