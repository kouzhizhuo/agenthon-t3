"""Server-only proof dispatch; keep actual candidate callbacks untouched."""
import argparse
import json
from pathlib import Path
import runpy
import subprocess
import sys

CANDIDATE = Path("/opt/proof/completion1009/candidates/native_core_spine_v1")
MARKER = "T3_NATIVE_SPINE_PROOF="


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("simulate", "simulate-batch"))
    parser.add_argument("--config")
    parser.add_argument("--out")
    parser.add_argument("--batch-dir")
    parser.add_argument("--out-dir")
    parser.add_argument("--mode", choices=("baseline", "optimized", "controls"), required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(CANDIDATE))
    if args.mode == "controls":
        if (args.verb != "simulate" or args.config != "/input/scenario.json"
                or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir
                or json.loads(Path(args.config).read_text()) != {"proof_command": "finite-and-four-market-controls-v1"}):
            raise ValueError("fixed proof-only controls invocation required")
        completed = subprocess.run([sys.executable, "-B", str(CANDIDATE / "controls.py"),
            "--out", "/output/controls"], cwd="/output", timeout=840)
        raise SystemExit(completed.returncode)
    probe = Path("/tmp/NATIVE_EPISODES.json")
    command = [str(CANDIDATE / "host_probe.py"), "--mode", args.mode, "--probe", str(probe)]
    if args.verb == "simulate":
        if args.config != "/input/scenario.json" or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir:
            raise ValueError("fixed single proof paths required")
        command += ["--config", args.config, "--out", args.out]
    else:
        if args.batch_dir != "/input/scenarios" or args.out_dir != "/output" or args.config or args.out:
            raise ValueError("fixed batch proof paths required")
        command += ["--batch-dir", args.batch_dir, "--out-dir", args.out_dir]
    sys.argv = command
    # Frozen host_probe calls the real CLI directly; terminate captures each
    # witness. This dispatcher changes no candidate globals or owner bindings.
    runpy.run_path(str(CANDIDATE / "host_probe.py"), run_name="__main__")
    print(MARKER + json.dumps(json.loads(probe.read_text()), sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
