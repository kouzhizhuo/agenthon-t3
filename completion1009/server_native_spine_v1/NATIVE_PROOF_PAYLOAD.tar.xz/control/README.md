# Native core spine: finite Linux proof v1

This runner proves the frozen `native_core_spine_v1` prototype on Linux amd64.
It builds one receipt-bound CPython 3.11 / Cython 3.1.3 extension, then reuses
that immutable image for every serial proof run. It makes no throughput or
ranking claim: the prototype keeps Python witness dictionaries on its hot path.
Both proof modes retain the original `ScenarioLatencyModel.get_latency`,
including its NumPy clipping. They do not use the separate faster screen's
scalar-latency binding. This is intentional for an exact native-core proof;
its reported CLI metadata must not be compared as a speed score against that
screen. Later performance work must compose individually proved optimizations.
The probe invokes `simulate` after imports, so its CLI wall time also starts
later than the production entry timer. All timing fields here are diagnostics.

The server sequence is fixed:

1. Verify the reviewed archive and prepared 62-file runtime snapshot.
2. Run source preflight, then one CPython 3.11.17 native build in the pinned base image.
3. Copy the actual source bindings, build receipt, generated C and extension
   from a never-started owned container; verify their hashes and ABI.
4. Run all 65 named finite controls and four full-market differential
   controls with the same strict resource launch used for scenario proofs.
5. Run canonical and native S001, AS06, MP01 and RA01. Apply the unchanged
   official developer verifier to each original unit and compare all output
   frames exactly, including byte equality between paired modes.
6. Run the first two sorted members of the original hetero-mix batch in each
   mode, then run each member alone in fresh containers. Compare original
   reference frames, aggregate arithmetic, paired bytes and batch isolation.

The two-member batch is an internal proof subset. Its original official card
describes five members, so this runner does not label the subset as an official
developer-gate PASS. Original single-unit cards are used unchanged.

Only participant source enters the image. Only unchanged scenario JSON enters
ordinary proof runs. The control run receives one fixed host command JSON.
Reference data, task cards, validators and toolkit stay on the evaluator host.
The frozen `host_probe.py` directly calls the real CLI and reads witness records
captured by each actual `NativeSpineKernel.terminate`. No authenticated callback
is wrapped. A small server entry dispatches the frozen probe and prints its
receipt from `/tmp`; it never adds files to the official output tree.

All containers use Linux amd64/runc, 4 CPUs, 16 GiB memory and swap, no network,
256 PIDs, nofile 1024, nproc 256, fsize 256 MiB, dropped capabilities,
no-new-privileges, UID/GID 65534, a read-only root, and a 64 MiB hardened `/tmp`.
The existing `verify_linux.py` launch, ownership and cleanup checks are reused.
The wrapper adds nproc/fsize checks without changing that host verifier source.

`stage.py` only parses and copies source, checks hashes, and creates an archive.
It does not import the candidate, generate C, build, simulate, publish, dispatch
a workflow or make a competition submission. `workflow.yml` is a reviewable
finite server workflow. Root coordinates all actual execution and publication.

Failures stop later stages and retain logs and every emitted output. The
workflow preserves its exact source archive with evidence, even on failure.
Successful proof is a prerequisite for a later production/performance design,
not a final competition-ready version.
