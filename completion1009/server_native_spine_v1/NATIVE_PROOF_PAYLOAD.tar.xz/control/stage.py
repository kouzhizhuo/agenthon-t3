"""Parse, copy and archive frozen sources only; never load the candidate."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import (BASE, BATCH, CANDIDATE, MAX_BYTES, MAX_FILES, SINGLES,
                    SOURCE_RECEIPT_SHA256, inventory, safe_name, sha, write)

HERE = Path(__file__).resolve().parent
COMPLETION = HERE.parent


def copy(source, destination):
    if source.is_symlink() or not source.is_file():
        raise ValueError("ordinary source file required: " + str(source))
    if source.suffix == ".py":
        ast.parse(source.read_text(), filename=str(source))
    if source.suffix == ".json":
        json.loads(source.read_text())
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    destination.chmod(0o644)
    if sha(source) != sha(destination):
        raise ValueError("source copy differs")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.archive.exists():
        raise ValueError("new staging directory and source archive required")
    candidate = COMPLETION / "candidates/native_core_spine_v1"
    receipt_path = candidate / "SOURCE_PREPARATION_RECEIPT.json"
    if sha(receipt_path) != SOURCE_RECEIPT_SHA256:
        raise ValueError("reviewed final native source receipt differs")
    receipt = json.loads(receipt_path.read_text())
    if receipt.get("file_count") != 17 or len(receipt["files"]) != 17:
        raise ValueError("reviewed 17-file source freeze required")
    args.out.mkdir(parents=True)
    for row in receipt["files"]:
        name = safe_name(row["path"])
        source = candidate / name
        if source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]:
            raise ValueError("candidate source differs: " + name)
        copy(source, args.out / CANDIDATE / name)
    pins_path = candidate / "PINNED_RUNTIME.json"
    pins = json.loads(pins_path.read_text())
    if (pins.get("schema") != "t3-native-spine-frozen-source-pins-v1"
            or len(pins["runtime_files"]) != 62 or pins.get("runtime_source_changes") != 0
            or pins.get("frozen_manifest_sha256") != sha(COMPLETION / "RUNTIME_MANIFEST.json")):
        raise ValueError("prepared pinned 62-file runtime required")
    original = json.loads((COMPLETION / "RUNTIME_MANIFEST.json").read_text())
    frozen = {safe_name(row["path"]): row for row in original["files"]}
    expected_runtime = {}
    for row in pins["runtime_files"]:
        name = safe_name(row["path"])
        source = candidate / "runtime" / name
        origin = frozen["runtime/" + name]
        if (source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]
                or (row["bytes"], row["sha256"]) != (origin["bytes"], origin["sha256"])):
            raise ValueError("prepared runtime differs: " + name)
        copy(source, args.out / CANDIDATE / "runtime" / name)
        expected_runtime[name] = {"bytes": row["bytes"], "sha256": row["sha256"]}
    if inventory(candidate / "runtime") != expected_runtime:
        raise ValueError("prepared runtime contains extra or missing members")
    copy(pins_path, args.out / CANDIDATE / "PINNED_RUNTIME.json")
    copy(receipt_path, args.out / CANDIDATE / "SOURCE_PREPARATION_RECEIPT.json")
    for name in ("verify_linux.py", "verify_public.py", "fetch_evaluation.py"):
        copy(COMPLETION / name, args.out / "host" / name)
    controls = ("common.py", "materialize.py", "entry.py", "controller.py", "stage.py", "Dockerfile", "README.md")
    for name in controls:
        copy(HERE / name, args.out / "control" / name)
    plan = {"schema": "t3-native-core-spine-linux-proof-plan-v1", "base": BASE,
        "candidate": CANDIDATE, "source_receipt_sha256": SOURCE_RECEIPT_SHA256,
        "runtime_pins_sha256": sha(pins_path), "source_files": receipt["files"],
        "single_units": SINGLES, "batch_unit": BATCH, "batch_first_sorted_members": 2,
        "modes": ["baseline", "optimized"], "controls_first": True, "build_count": 1,
        "proof_only": True, "timing_claim": False, "rankable": False,
        "official_submission": False, "subset_batch_official_gate": False}
    write(args.out / "PROOF_PLAN.json", plan)
    files = inventory(args.out)
    if len(files) + 1 > MAX_FILES or sum(row["bytes"] for row in files.values()) > MAX_BYTES:
        raise ValueError("source payload exceeds finite bound")
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-native-spine-payload-v1", "files": files})
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.archive, "w:xz", preset=6) as archive:
        for name in sorted(inventory(args.out)):
            data = (args.out / name).read_bytes()
            member = tarfile.TarInfo(safe_name(name))
            member.size, member.mode, member.mtime = len(data), 0o644, 0
            member.uid = member.gid = 0
            archive.addfile(member, io.BytesIO(data))
    write(args.archive.with_suffix(args.archive.suffix + ".json"), {
        "archive": str(args.archive), "sha256": sha(args.archive), "bytes": args.archive.stat().st_size,
        "regular_members": len(files) + 1, "source_only": True, "candidate_imported": False,
        "native_build_executed": False, "market_executed": False, "workflow_dispatched": False})


if __name__ == "__main__":
    main()
