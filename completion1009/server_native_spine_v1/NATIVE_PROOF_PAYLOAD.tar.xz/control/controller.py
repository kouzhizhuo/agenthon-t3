"""Finite source-bound Linux proof; no score or throughput conclusions."""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import sys
import uuid
from common import (BASE, BATCH, CANDIDATE, IMAGE_CANDIDATE, MARKER, SINGLES,
                    finite_names, inventory, safe_name, sha, verify_payload, write)

PAYLOAD = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public


class StrictCommands(linux.DockerCommands):
    """Add finite process/file ulimits while keeping original launch checks."""
    def call(self, arguments, label, seconds=30, cleanup=False):
        if arguments and arguments[0] == "create":
            arguments = [arguments[0], "--ulimit", "nproc=256:256", "--ulimit",
                         "fsize=268435456:268435456", *arguments[1:]]
        return super().call(arguments, label, seconds, cleanup)

    def inspect(self, name, cleanup=False, seconds=30):
        info, command = super().inspect(name, cleanup, seconds)
        if info is not None and not cleanup and info.get("Config", {}).get("Entrypoint") == ["/usr/local/bin/python", "-B", "/opt/proof/entry.py"]:
            host = info["HostConfig"]
            limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
            expected = {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
            if any(limits.get(name) != value for name, value in expected.items()):
                raise ValueError("actual complete proof ulimits differ")
            mounts = info.get("Mounts", [])
            binds = [row for row in mounts if row.get("Destination") != "/tmp"]
            if (len(binds) != 2 or {row.get("Destination") for row in binds} != {"/input", "/output"}
                    or any(row.get("Type") != "bind" for row in binds)
                    or any(row.get("Type") != "tmpfs" for row in mounts if row.get("Destination") == "/tmp")):
                raise ValueError("proof mounts differ from input/output-only contract")
        return info, command


linux.DockerCommands = StrictCommands


def execute(args, command, prefix, seconds):
    row = linux.run_command(command, prefix, seconds, args.log_cap_bytes)
    write(prefix.with_name(prefix.name + ".json"), row)
    if not row["succeeded"]:
        raise RuntimeError("failed bounded command; diagnostics: " + str(prefix))
    return row


def image(args, requested, folder):
    folder.mkdir(parents=True)
    return linux.image_metadata(args, requested, folder)


def validate_build(plan, copied):
    source = PAYLOAD / CANDIDATE
    receipt = public.read_json(copied / "artifacts/build_v1/BUILD_RECEIPT.json")
    spec = public.read_json(source / "compile_spec.json")
    bindings = public.read_json(copied / "SOURCE_BINDINGS.json")
    expected_sources = {path.name: sha(path) for path in source.iterdir()
        if path.is_file() and not path.name.startswith("._")
        and (path.suffix in (".py", ".pyx", ".md") or path.name == "compile_spec.json")}
    if (receipt.get("schema") != "t3-native-core-spine-build-v1" or receipt.get("build_succeeded") is not True
            or receipt.get("candidate_sources") != expected_sources or receipt.get("cython") != spec["cython"]
            or receipt.get("dependencies") != spec["dependencies"]
            or receipt.get("compile_flags") != spec["compile_flags"] or receipt.get("directives") != spec["directives"]
            or receipt.get("compile_spec_sha256") != sha(source / "compile_spec.json")
            or receipt.get("runtime_pins_sha256") != plan["runtime_pins_sha256"]
            or receipt.get("source_bindings_sha256") != sha(copied / "SOURCE_BINDINGS.json")
            or receipt.get("market_execution") is not False or receipt.get("timing_claim") is not False):
        raise ValueError("actual native build receipt differs from frozen source recipe")
    abi = receipt["abi"]
    if (abi.get("implementation") != "cpython" or abi.get("version") != [3, 11, 17]
            or abi.get("platform") != "linux" or abi.get("machine") not in ("x86_64", "AMD64")
            or abi.get("pointer_bits") != 64 or abi.get("byteorder") != "little"
            or abi.get("cache_tag") != "cpython-311" or not abi.get("ext_suffix", "").endswith(".so")):
        raise ValueError("actual native ABI is not pinned Linux amd64 CPython 3.11")
    expected_python = {name: digest for name, digest in expected_sources.items() if name.endswith(".py")}
    if (bindings.get("schema") != "t3-native-spine-source-bindings-v1"
            or bindings.get("candidate_python_sources") != expected_python
            or bindings.get("runtime_pins_sha256") != plan["runtime_pins_sha256"]
            or bindings.get("native_execution") is not False):
        raise ValueError("actual source binding receipt differs")
    build = copied / "artifacts/build_v1"
    extension_record = receipt["extension"]
    extension = build / safe_name(extension_record["path"])
    if extension.stat().st_size != extension_record["bytes"] or sha(extension) != extension_record["sha256"]:
        raise ValueError("actual extracted extension bytes differ")
    generated = receipt.get("generated_c", {})
    if not generated or any(sha(build / safe_name(name)) != digest for name, digest in generated.items()):
        raise ValueError("actual extracted generated C differs")
    for name in expected_sources:
        if sha(copied / name) != expected_sources[name]:
            raise ValueError("actual installed candidate source differs: " + name)
    pins = public.read_json(source / "PINNED_RUNTIME.json")
    expected_runtime = {row["path"]: {"bytes": row["bytes"], "sha256": row["sha256"]} for row in pins["runtime_files"]}
    if inventory(copied / "runtime") != expected_runtime or sha(copied / "PINNED_RUNTIME.json") != plan["runtime_pins_sha256"]:
        raise ValueError("actual installed runtime snapshot differs")
    proof = {"passed": True, "build_receipt_sha256": sha(build / "BUILD_RECEIPT.json"),
        "source_bindings_sha256": sha(copied / "SOURCE_BINDINGS.json"), "extension": extension_record,
        "abi": abi, "generated_c": generated, "rankable": False, "timing_claim": False}
    write(copied.parent / "BUILD_PROVENANCE.json", proof)
    return proof


def build(args, plan):
    evidence = args.evidence
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("real Linux amd64 host required")
    anonymous = evidence / "anonymous-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        execute(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], evidence / "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    write(evidence / "BASE.json", image(args, BASE, evidence / "base"))
    context = evidence / "build-context"
    context.mkdir()
    shutil.copytree(PAYLOAD / "completion1009", context / "completion1009")
    (context / "control").mkdir()
    shutil.copyfile(PAYLOAD / "control/entry.py", context / "control/entry.py")
    shutil.copyfile(PAYLOAD / "control/Dockerfile", context / "Dockerfile")
    iid = evidence / "native.image-id"
    execute(args, [args.docker, "build", "--platform", "linux/amd64", "--iidfile", str(iid),
        "-t", "t3-native-spine-proof:v1", "-f", str(context / "Dockerfile"), str(context)], evidence / "native-build", 1200)
    metadata = image(args, iid.read_text().strip(), evidence / "image")
    write(evidence / "IMAGE.json", metadata)
    token = uuid.uuid4().hex
    name = "t3-native-receipt-" + token[:12]
    commands = StrictCommands(args.docker, evidence / "receipt-commands", args.log_cap_bytes)
    commands.folder.mkdir(parents=True)
    created = commands.call(["create", "--name", name, "--label", linux.OWNER_LABEL + "=" + token,
        "--pull", "never", "--entrypoint", "/usr/local/bin/python", metadata["id"], "--help"], "create")
    try:
        if not created["succeeded"]:
            raise RuntimeError("never-started receipt container creation failed")
        info, _ = commands.inspect(name)
        linux.require_owned(info, name, token, metadata["id"])
        target = evidence / "actual-candidate"
        copied = commands.call(["cp", name + ":" + IMAGE_CANDIDATE, str(target)], "copy-actual-candidate", 120)
        if not copied["succeeded"]:
            raise ValueError("actual image receipt/source/native bytes unavailable")
        validate_build(plan, target)
    finally:
        settled = linux.settle_container(commands, name, token, metadata["id"], creation_uncertain=not created["succeeded"])
        write(evidence / "RECEIPT_CLEANUP.json", {"cleanup": settled, "commands": commands.rows})
        if not settled["settled"] or not settled["final_absent"] or settled["errors"]:
            raise RuntimeError("owned receipt container not settled")
    write(evidence / "BUILD_READY.json", {"passed": True, "image_id": metadata["id"],
        "build_count": 1, "rankable": False, "timing_claim": False})


def probe(execution, mode, expected, provenance):
    if not execution["succeeded"]:
        raise ValueError("proof container did not finish successfully")
    if any(sha(Path(row["staged"])) != row["sha256"] for row in execution["staged_inputs"]):
        raise ValueError("actual staged input changed during proof")
    lines = Path(execution["attach"]["stdout"]["path"]).read_text().splitlines()
    receipts = [json.loads(line[len(MARKER):]) for line in lines if line.startswith(MARKER)]
    if len(receipts) != 1:
        raise ValueError("exactly one actual episode probe marker required")
    value = receipts[0]
    episodes = value["episodes"]
    if value.get("rankable") is not False or value.get("cli_source") != IMAGE_CANDIDATE + "/cli.py":
        raise ValueError("probe source or proof scope differs")
    if mode == "baseline":
        if episodes:
            raise ValueError("canonical proof unexpectedly reported native episode")
    elif len(episodes) != expected:
        raise ValueError("actual terminate witness count differs from episode roster")
    else:
        for episode in episodes:
            counts = episode.get("counts", {})
            if (episode.get("candidate") != "native_core_spine_v1" or episode.get("native_active") is not True
                    or episode.get("fallback_used") is not False or episode.get("proof_only") is not True
                    or episode.get("extension_sha256") != provenance["extension"]["sha256"]
                    or episode.get("receipt_sha256") != provenance["build_receipt_sha256"]
                    or episode.get("abi") != provenance["abi"]
                    or episode.get("extension_path") != IMAGE_CANDIDATE + "/artifacts/build_v1/" + provenance["extension"]["path"]
                    or episode.get("receipt_path") != IMAGE_CANDIDATE + "/artifacts/build_v1/BUILD_RECEIPT.json"
                    or not all(isinstance(number, int) and not isinstance(number, bool) and number >= 0 for number in counts.values())
                    or counts.get("pop", 0) <= 0 or counts.get("wake", 0) <= 0 or counts.get("act", 0) <= 0
                    or counts.get("exchange_book_bridge", 0) <= 0 or counts.get("pop") != episode.get("ttl_messages")):
                raise ValueError("episode lacks actual receipt-bound active native path")
    return value


def probe_sidecar(witnessed, output, item):
    name = "events.json" if item["shape"] == "single" else "batch_events.json"
    if witnessed.get("events") != public.read_json(output / name):
        raise ValueError("probe returned metadata differs from actual emitted sidecar")
    if item["shape"] == "batch":
        expected = [entry["sub"] for entry in sorted(item["subs"], key=lambda entry: entry["sub"])]
        if [row["sub"] for row in witnessed["events"]["per_scenario"]] != expected:
            raise ValueError("actual batch probe order differs from sorted original scenario roster")


def require_pass(row, folder, rows):
    rows.append(row)
    write(folder / "PROOF.json", row)
    write(folder.parents[1] / "PROOF_ROWS.json", rows)
    if not row["passed"]:
        raise ValueError("proof failed; retain output: " + str(folder))


def reference_single(unit, entry, output):
    frames = [public.compare_frame(output / name, unit / "checks/reference_data" / entry["sub"] / name)
              for name in public.SUB_FILES[:2]]
    sidecar = public.verify_events(output, public.read_json(unit / entry["scenario_file"]), frames[0].get("candidate_rows", 0))
    tree = public.check_tree(output, set(public.SUB_FILES))
    return {"passed": all(frame["passed"] for frame in frames) and sidecar["passed"] and tree["passed"],
            "frames": frames, "sidecar": sidecar, "output_tree": tree}


def prove(args, plan):
    evidence = args.evidence
    metadata = public.read_json(evidence / "IMAGE.json")
    provenance = validate_build(plan, evidence / "actual-candidate")
    current = image(args, metadata["id"], evidence / "image-before-proof")
    if current["id"] != metadata["id"]:
        raise ValueError("immutable native image changed")
    roster = public.collect_plan(args.reference_root, SINGLES + [BATCH])
    write(evidence / "REFERENCE_PLAN.json", roster)
    by_name = {item["unit"]: item for item in roster["units"]}
    token, rows, failure = uuid.uuid4().hex, [], None
    try:
        controls_input = evidence / "fixed-control-input.json"
        write(controls_input, {"proof_command": "finite-and-four-market-controls-v1"})
        controls_item = {"shape": "single", "scenario_paths": [str(controls_input)]}
        folder = evidence / "runs/controls"
        execution, output = linux.run_container(args, metadata["id"], "controls", controls_item, folder, token, "controls")
        result = public.read_json(output / "controls/RESULT.json") if (output / "controls/RESULT.json").is_file() else None
        finite = public.read_json(output / "controls/FINITE_RESULT.json") if (output / "controls/FINITE_RESULT.json").is_file() else None
        finite_cases = finite.get("cases", []) if finite else []
        exact_finite = ([case.get("name") for case in finite_cases] == finite_names()
            and len(finite_cases) == 65 and all(case.get("passed") is True for case in finite_cases))
        market_cases = result.get("cases", []) if result else []
        exact_markets = ([case.get("seed") for case in market_cases] == [81009, 82009, 83009, 84009]
            and all(case.get("passed") is True and case.get("native_witness", {}).get("native_active") is True
                and case.get("native_witness", {}).get("fallback_used") is False
                and case.get("native_witness", {}).get("extension_sha256") == provenance["extension"]["sha256"]
                for case in market_cases))
        actual_receipts = [value.get("native_receipt", {}) for value in (result, finite) if value]
        exact_receipts = (len(actual_receipts) == 2 and all(
            receipt.get("extension_sha256") == provenance["extension"]["sha256"]
            and receipt.get("receipt_sha256") == provenance["build_receipt_sha256"]
            and receipt.get("abi") == provenance["abi"] for receipt in actual_receipts))
        passed = (execution["succeeded"] and result and result.get("all_passed") is True
            and exact_markets and result.get("sources_unchanged") is True
            and result.get("timing_claim") is False and finite and finite.get("all_passed") is True
            and exact_finite and finite.get("sources_unchanged") is True
            and exact_receipts
            and all(sha(Path(row["staged"])) == row["sha256"] for row in execution["staged_inputs"]))
        require_pass({"phase": "controls", "passed": bool(passed), "execution": execution,
                      "control_result": result, "finite_result": finite,
                      "exact_65_finite_case_names": exact_finite,
                      "exact_four_market_seed_coverage": exact_markets, "rankable": False}, folder, rows)
        for name in SINGLES:
            item, prior = by_name[name], None
            for mode in plan["modes"]:
                folder = evidence / "runs" / (name + "-" + mode)
                execution, output = linux.run_container(args, metadata["id"], mode, item, folder, token, name[3:7] + "-" + mode)
                witnessed = probe(execution, mode, 1, provenance)
                probe_sidecar(witnessed, output, item)
                checked = public.verify_outputs(args.reference_root / name, output, item)
                gate = linux.gate(args, args.reference_root / name, output, folder)
                pair = linux.output_pair(output, prior, item) if prior else None
                passed = checked["passed"] and gate.get("admissible") is True and (pair is None or pair["passed"])
                require_pass({"phase": "original-single", "unit": name, "mode": mode, "passed": passed,
                    "execution": execution, "probe": witnessed, "output_verification": checked,
                    "official_developer_gate": gate, "paired_bytes": pair, "rankable": False}, folder, rows)
                prior = output
        full = by_name[BATCH]
        selected = sorted(full["subs"], key=lambda entry: entry["sub"])[:2]
        if len(selected) != 2:
            raise ValueError("two original batch members required")
        subset = dict(full, subs=selected, scenario_paths=[str(args.reference_root / BATCH / entry["scenario_file"]) for entry in selected])
        batch_outputs = {}
        for mode in plan["modes"]:
            folder = evidence / "runs" / ("batch2-" + mode)
            execution, output = linux.run_container(args, metadata["id"], mode, subset, folder, token, "batch2-" + mode)
            witnessed = probe(execution, mode, 2, provenance)
            probe_sidecar(witnessed, output, subset)
            checked = public.verify_outputs(args.reference_root / BATCH, output, subset)
            pair = linux.output_pair(output, batch_outputs["baseline"], subset) if mode == "optimized" else None
            require_pass({"phase": "two-original-members-batch", "unit": BATCH, "mode": mode,
                "passed": checked["passed"] and (pair is None or pair["passed"]), "execution": execution,
                "probe": witnessed, "output_verification": checked, "paired_bytes": pair,
                "official_developer_gate": "not applicable: original card describes five members",
                "rankable": False}, folder, rows)
            batch_outputs[mode] = output
        for index, entry in enumerate(selected):
            prior = None
            for mode in plan["modes"]:
                folder = evidence / "runs" / ("isolate-" + str(index) + "-" + mode)
                scenario = args.reference_root / BATCH / entry["scenario_file"]
                execution, output = linux.run_container(args, metadata["id"], mode, subset, folder, token,
                    "isolate-" + str(index) + "-" + mode, scenario=scenario)
                witnessed = probe(execution, mode, 1, provenance)
                probe_sidecar(witnessed, output, {"shape": "single"})
                checked = reference_single(args.reference_root / BATCH, entry, output)
                shape = {"shape": "single", "subs": []}
                isolation = linux.output_pair(output, batch_outputs[mode] / entry["sub"], shape)
                pair = linux.output_pair(output, prior, shape) if prior else None
                require_pass({"phase": "fresh-process-batch-isolation", "sub": entry["sub"], "mode": mode,
                    "passed": checked["passed"] and isolation["passed"] and (pair is None or pair["passed"]),
                    "execution": execution, "probe": witnessed, "output_verification": checked,
                    "batch_isolation_bytes": isolation, "paired_bytes": pair, "rankable": False}, folder, rows)
                prior = output
    except BaseException as error:
        failure = {"type": type(error).__name__, "message": str(error)}
    unchanged = all(sha(args.reference_root / item["unit"] / name) == digest for item in roster["units"]
        for mapping in (item["input_sha256"], item["reference_sha256"]) for name, digest in mapping.items())
    expected = 1 + len(SINGLES) * 2 + 2 + 2 * 2
    result = {"schema": "t3-native-spine-finite-linux-proof-result-v1", "all_passed": failure is None
        and len(rows) == expected and all(row["passed"] for row in rows) and unchanged,
        "completed_runs": len(rows), "planned_runs": expected, "failure": failure,
        "original_inputs_references_unchanged": unchanged, "image_id": metadata["id"],
        "build_count": 1, "proof_only": True, "rankable": False, "timing_claim": False,
        "official_submission": False, "sealed_evaluation": False, "rows": rows}
    write(evidence / "PROOF_RESULT.json", result)
    if not result["all_passed"]:
        raise RuntimeError("finite Linux proof incomplete or failed; preserve evidence")


def archive_evidence(args):
    if args.artifact.exists():
        raise ValueError("new artifact directory required")
    args.artifact.mkdir(parents=True)
    for source in sorted(args.evidence.rglob("*")):
        if not source.is_file() or source.is_symlink():
            continue
        relative = source.relative_to(args.evidence)
        # Avoid repeating the source context; preserve actual build/runtime,
        # every proof output and command log, including failure diagnostics.
        if relative.parts[0] in ("build-context", "anonymous-config"):
            continue
        target = args.artifact / "evidence" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    shutil.copyfile(args.archive, args.artifact / "NATIVE_PROOF_PAYLOAD.tar.xz")
    write(args.artifact / "ARTIFACT.json", {"archive_sha256": sha(args.archive),
        "retained_every_emitted_proof_output": True, "rankable": False, "timing_claim": False,
        "files": inventory(args.artifact)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("build", "prove", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--reference-root", type=Path)
    parser.add_argument("--gate-kit", type=Path)
    parser.add_argument("--gate-python", default=sys.executable)
    parser.add_argument("--docker", default="docker")
    parser.add_argument("--timeout", type=float, default=900)
    parser.add_argument("--log-cap-bytes", type=int, default=4 * 1024 ** 2)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--artifact", type=Path)
    args = parser.parse_args()
    signal.signal(signal.SIGINT, linux.cancellation)
    signal.signal(signal.SIGTERM, linux.cancellation)
    args.evidence = args.evidence.resolve()
    args.evidence.mkdir(parents=True, exist_ok=True)
    if args.stage == "artifact":
        archive_evidence(args)
        return
    verify_payload(PAYLOAD)
    plan = public.read_json(PAYLOAD / "PROOF_PLAN.json")
    if (plan.get("base") != BASE or plan.get("candidate") != CANDIDATE or plan.get("single_units") != SINGLES
            or plan.get("batch_unit") != BATCH or plan.get("modes") != ["baseline", "optimized"]
            or plan.get("batch_first_sorted_members") != 2 or plan.get("controls_first") is not True
            or plan.get("build_count") != 1 or plan.get("proof_only") is not True
            or plan.get("timing_claim") is not False or plan.get("rankable") is not False):
        raise ValueError("fixed proof plan differs")
    if args.stage == "build":
        build(args, plan)
    else:
        if not args.reference_root or not args.gate_kit:
            raise ValueError("original host references and official toolkit required")
        prove(args, plan)


if __name__ == "__main__":
    main()
