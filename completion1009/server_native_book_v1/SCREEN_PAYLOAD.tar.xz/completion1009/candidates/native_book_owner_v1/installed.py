"""Install the admitted book constructor for one serial configuration/run."""
from contextlib import contextmanager
import os
from t3_canonical_engine import CanonicalKernel


class GuardedCanonicalKernel(CanonicalKernel):
    """Check the exact empty book owner before any agent initializes."""
    def run(self):
        runtime_guard(self)
        return super().run()


def quiet_summary_writer(self):
    return None


def runtime_guard(kernel):
    from admission import admit_kernel
    return admit_kernel(kernel)


@contextmanager
def enabled(active=True):
    """Pair one original canonical event owner with either book arm."""
    from abides_core import abides
    from abides_fork import trace
    from column_trace import make_extractor
    from t3_canonical_engine import ColumnLedger
    original = abides.Kernel
    abides.Kernel = GuardedCanonicalKernel if active else CanonicalKernel
    extractor = make_extractor(ColumnLedger, trace.extract_message_trace,
                               trace.MESSAGE_TRACE_COLUMNS, trace._MSG_DTYPES)
    try:
        yield extractor
    finally:
        abides.Kernel = original


def ensure_native_admission():
    from admission import load_native
    receipt = os.environ.get("T3_NATIVE_BOOK_RECEIPT")
    if not receipt:
        raise ValueError("T3_NATIVE_BOOK_RECEIPT must name a successful isolated build")
    return load_native(receipt)


def authenticate():
    from binding_audit import source_manifest, static_admission
    source_manifest()
    static_admission()


@contextmanager
def book_owner(scenario, active=True):
    if not active:
        yield None
        return
    from admission import admit_producers
    native = admit_producers(scenario)
    from abides_markets.agents import exchange_agent
    from abides_markets.order_book import OrderBook
    if exchange_agent.OrderBook is not OrderBook:
        raise ValueError("book constructor changed before episode installation")
    exchange_agent.OrderBook = native.NativeBook
    try:
        yield native
    finally:
        exchange_agent.OrderBook = OrderBook


def collect_proof(end_state, native=True):
    from admission import native_receipt
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.order_book import OrderBook
    if native:
        from native_book import NativeBook
    agents = end_state.get("agents")
    if type(agents) is not list or not agents or type(agents[0]) is not ExchangeAgent:
        raise ValueError("native book end-state owner differs")
    rows = {}
    for symbol, book in agents[0].order_books.items():
        if type(book) is not (NativeBook if native else OrderBook):
            raise ValueError("native book end-state contains an unowned book")
        if not native:
            rows[symbol] = None
            continue
        counts = book.proof_counts()
        if (type(counts) is not dict or list(counts) != ["match", "cancel", "insert", "read"]
                or any(type(value) is not int or value < 0 for value in counts.values())):
            raise ValueError("native book proof counts differ")
        rows[symbol] = counts
    return {"schema": "t3-native-book-owner-episode-proof-v1", "native": native_receipt() if native else None,
            "book_counts": rows, "active": native, "proof_only": True, "timing_claim": False}
