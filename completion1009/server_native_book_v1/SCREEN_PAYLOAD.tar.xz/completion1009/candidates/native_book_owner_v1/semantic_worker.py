#!/usr/bin/env python3
"""Prepared actual native/canonical full-market differential worker, untimed."""
import argparse
from pathlib import Path
import sys
parser = argparse.ArgumentParser()
parser.add_argument("--arm", choices=("canonical", "native"), required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--receipt", required=True)
args = parser.parse_args()
HERE = Path(__file__).resolve().parent
RUNTIME = HERE / "runtime"
OUTPUT = Path(args.out)
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
import hashlib
import io
import json
import pickle
import types
import warnings
from contextlib import redirect_stdout
import numpy as np
import pandas as pd
from abides_core import abides
from abides_core.agent import Agent
from abides_core.kernel import Kernel
from abides_core.message import Message
from abides_fork.config import build_config
from abides_fork.simulate import reset_abides_counters
from abides_fork import trace
from abides_markets.orders import Order, Side
from installed import authenticate, quiet_summary_writer, enabled, book_owner, collect_proof
from admission import load_native, admit_config
from abides_markets.order_book import OrderBook
from abides_markets.price_level import PriceLevel
native_module = None

def encode(value):
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.ndarray): return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if type(value) is Side: return ["Side", value.value]
    if type(value) in (list, tuple): return [type(value).__name__, [encode(x) for x in value]]
    if isinstance(value, dict): return ["dict", [[encode(k), encode(v)] for k, v in value.items()]]
    if type(value) is bytes: return ["bytes", value.hex()]
    raise TypeError("unsupported semantic scalar value: " + type(value).__name__)

def graph(value, kernel, seen=None):
    seen = {} if seen is None else seen
    def descend(x): return graph(x, kernel, seen)
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, np.generic): return [type(value).__name__, descend(value.item())]
    if type(value) is Side: return ["Side", value.value]
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)):
        return ["binding", getattr(value, "__module__", ""), getattr(value, "__qualname__", getattr(value, "__name__", ""))]
    if id(value) in seen: return ["ref", seen[id(value)]]
    serial = len(seen); seen[id(value)] = serial
    if isinstance(value, np.random.RandomState): return ["RandomState", serial, encode(value.get_state())]
    if isinstance(value, np.ndarray): return ["ndarray", serial, str(value.dtype), list(value.shape), descend(value.tolist()) if value.dtype.hasobject else value.tobytes().hex()]
    if isinstance(value, dict):
        return ["dict", serial, [(descend(k), descend(v)) for k, v in value.items()
            if not (value is kernel.custom_state and k == "kernel_event_queue_elapsed_wallclock")]]
    if type(value) in (list, tuple): return [type(value).__name__, serial, [descend(x) for x in value]]
    if type(value) in (set, frozenset): return [type(value).__name__, serial, sorted([encode(x) for x in value], key=repr)]
    if isinstance(value, (pd.DataFrame, pd.Series)):
        return [type(value).__name__, serial, str(value.dtypes), encode(value.to_dict())]
    if value is kernel:
        fields = [(k, v) for k, v in vars(kernel).items() if k not in
                  ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir", "messages")]
        # Both kernels project the same business queue and field ownership.
        calendar = kernel.logical_calendar() if hasattr(kernel, "logical_calendar") else kernel.messages.queue
        fields.append(("logical_calendar", calendar))
        return ["logical_kernel", serial, [(k, descend(v)) for k, v in fields]]
    if type(value) in (OrderBook, native_module.NativeBook):
        return ["abides_markets.order_book", "OrderBook", serial, [(k, descend(v)) for k, v in vars(value).items()]]
    if type(value) in (PriceLevel, native_module.NativeLevel):
        return ["abides_markets.price_level", "PriceLevel", serial, [(k, descend(v)) for k, v in vars(value).items()]]
    if hasattr(value, "__dict__"):
        return [type(value).__module__, type(value).__name__, serial, [(k, descend(v)) for k, v in vars(value).items()]]
    raise TypeError("unsupported business graph value: " + type(value).__name__)

def rngs(value, path="root", seen=None):
    seen = set() if seen is None else seen
    if isinstance(value, np.random.RandomState): return {path: encode(value.get_state())}
    if value is None or isinstance(value, (int, str, float, bool, np.ndarray, np.generic)): return {}
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)): return {}
    if id(value) in seen: return {}
    seen.add(id(value))
    if isinstance(value, dict): children = [(str(k), v) for k, v in value.items()]
    elif type(value) in (list, tuple): children = [(str(i), v) for i, v in enumerate(value)]
    elif hasattr(value, "__dict__"): children = [(k, v) for k, v in vars(value).items() if k != "kernel"]
    else: return {}
    result = {}
    for key, item in children: result.update(rngs(item, path + "/" + key, seen))
    return result

def scenario(seed, latency, protocol=False):
    exchange = {"symbol": "CTRL", "tick_size": 1, "lot_size": 1, "min_price": 1, "max_price": 1000000}
    if protocol: exchange.update(protocol_enforcement=True, stp_policy="cancel_newest", ack_delay_ns=3000, compute_delay_ns=700)
    return {"scenario_id": "direct-state-controls-" + str(seed), "seed": seed, "horizon_ns": 2000000000,
        "exchange_config": exchange,
        "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100000, "kappa": .05,
            "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}}, "latency_config": latency,
        "agent_configs": [
            {"agent_type": "NoiseTrader", "count": 2, "params": {"arrival_rate_hz": 6., "order_size_mean": 10}},
            {"agent_type": "MarketMaker", "count": 1, "params": {"spread_ticks": 2, "depth_levels": 3,
                "size_per_level": 12, "rebalance_interval_ns": 300000000}},
            {"agent_type": "ValueTrader", "count": 1, "params": {"arrival_rate_hz": 4., "threshold_ticks": 2}},
            {"agent_type": "MomentumTrader", "count": 1, "params": {"arrival_rate_hz": 5., "threshold_ticks": 2}}]}

def run(value):
    reset_abides_counters(); np.random.seed(19301009)
    summary_writer = Kernel.write_summary_log; Kernel.write_summary_log = quiet_summary_writer
    try:
        output = io.StringIO()
        with warnings.catch_warnings(record=True) as observed, redirect_stdout(output):
            warnings.simplefilter("always")
            with book_owner(value, args.arm == "native"):
                config = build_config(value)
                if args.arm == "native":
                    admit_config(config)
                with enabled(args.arm == "native") as extractor:
                    state = abides.run(config)
            frames = [trace.extract_trace(state), extractor(state)]
            blobs = []
            for frame in frames:
                stream = io.BytesIO(); frame.to_parquet(stream, compression="snappy", index=False); blobs.append(stream.getvalue())
            kernel = state["agents"][0].kernel
            before_ids = [Order._order_id_counter, Message._Message__message_id_counter]
            business_state = graph([state, config, kernel], kernel)
            assert before_ids == [Order._order_id_counter, Message._Message__message_id_counter], "state projection incremented counters"
            random_state = {"global": encode(np.random.get_state()), **rngs(config), "kernel": encode(kernel.random_state.get_state())}
            payload = [blobs, business_state, random_state, before_ids,
                       {"warnings": [(item.category.__name__, str(item.message)) for item in observed],
                        "stdout": output.getvalue()}]
            witness = collect_proof(state, native=args.arm == "native")
            if args.arm == "native":
                assert witness["active"] is True and witness["native"]["extension_sha256"]
                assert all(type(book) is native_module.NativeBook for book in state["agents"][0].order_books.values())
                assert all(list(counts) == ["match", "cancel", "insert", "read"]
                           and all(type(v) is int and v > 0 for v in counts.values())
                           for counts in witness["book_counts"].values())
            stats = {"trace_rows": len(frames[0]), "message_rows": len(frames[1]), "ttl_messages": kernel.ttl_messages,
                     "rng_states": len(random_state), "native_witness": witness}
            return {"seed": value["seed"], "frames": frames, "payload": payload, "stats": stats}
    finally: Kernel.write_summary_log = summary_writer

def main():
    global native_module
    authenticate()
    native_module = load_native(args.receipt)
    values = [run(scenario(seed, latency, protocol)) for seed, latency, protocol in
        [(81009, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}, False),
         (82009, {"model": "deterministic", "params": {"mean_ns": 0}}, True),
         (83009, {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}, False),
         (84009, {}, False)]]
    data = pickle.dumps(values, protocol=4)
    (OUTPUT / "VALUES.pkl").write_bytes(data)
    (OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps({"arm": args.arm, "timing_claim": False,
        "values_sha256": hashlib.sha256(data).hexdigest(), "cases": [x["stats"] for x in values]}, indent=2) + "\n")
    print(json.dumps({"arm": args.arm, "cases": [x["stats"] for x in values]}, indent=2))
if __name__ == "__main__": main()
