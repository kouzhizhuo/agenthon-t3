"""Offline source proof and full live original-Python binding admission.

No market runs here. preflight.py performs the full source/hash proof and saves
interpreter-specific pins. Static admission reads those pins and checks actual
bindings/defaults/constants without compiling or execing a second namespace.
"""
import hashlib
import importlib
import json
import marshal
from pathlib import Path
import sys
import types
import warnings

HERE = Path(__file__).resolve().parent
RUNTIME = HERE / "runtime"

# Include core Kernel/abides and all prescribed dependency modules. Sources not
# directly dispatched still have full inventory hashes in offline preflight.
MODULES = (
    ("abides_core", "vendor/abides/abides-core/abides_core/__init__.py"),
    ("abides_core.abides", "vendor/abides/abides-core/abides_core/abides.py"),
    ("abides_core.kernel", "vendor/abides/abides-core/abides_core/kernel.py"),
    ("abides_core.agent", "vendor/abides/abides-core/abides_core/agent.py"),
    ("abides_core.message", "vendor/abides/abides-core/abides_core/message.py"),
    ("abides_core.latency_model", "vendor/abides/abides-core/abides_core/latency_model.py"),
    ("abides_core.utils", "vendor/abides/abides-core/abides_core/utils.py"),
    ("abides_fork.agents", "abides_fork/agents.py"),
    ("abides_fork.config", "abides_fork/config.py"),
    ("abides_fork.trace", "abides_fork/trace.py"),
    ("abides_fork.simulate", "abides_fork/simulate.py"),
    ("abides_markets.agents.utils", "vendor/abides/abides-markets/abides_markets/agents/utils.py"),
    ("abides_markets.utils", "vendor/abides/abides-markets/abides_markets/utils/__init__.py"),
    ("abides_markets.oracles.oracle", "vendor/abides/abides-markets/abides_markets/oracles/oracle.py"),
    ("abides_markets.agents.financial_agent", "vendor/abides/abides-markets/abides_markets/agents/financial_agent.py"),
    ("abides_markets.agents.trading_agent", "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py"),
    ("abides_markets.agents.exchange_agent", "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py"),
    ("abides_markets.orders", "vendor/abides/abides-markets/abides_markets/orders.py"),
    ("abides_markets.order_book", "vendor/abides/abides-markets/abides_markets/order_book.py"),
    ("abides_markets.price_level", "vendor/abides/abides-markets/abides_markets/price_level.py"),
    ("abides_markets.oracles.sparse_mean_reverting_oracle", "vendor/abides/abides-markets/abides_markets/oracles/sparse_mean_reverting_oracle.py"),
    ("abides_markets.messages.query", "vendor/abides/abides-markets/abides_markets/messages/query.py"),
    ("abides_markets.messages.order", "vendor/abides/abides-markets/abides_markets/messages/order.py"),
    ("abides_markets.messages.orderbook", "vendor/abides/abides-markets/abides_markets/messages/orderbook.py"),
    ("abides_markets.messages.market", "vendor/abides/abides-markets/abides_markets/messages/market.py"),
    ("abides_markets.messages.marketdata", "vendor/abides/abides-markets/abides_markets/messages/marketdata.py"),
    ("t3_canonical_engine", "t3_canonical_engine.py"),
    ("optimizations", "optimizations.py"),
    ("column_trace", "column_trace.py"),
)
DYNAMIC_CLASS_VALUES = {"_Message__message_id_counter", "_order_id_counter"}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def normalized_code(code):
    # Marshal tracks string interning and object-reference flags, which are not
    # reproducible across fresh/imported namespaces. Serialize every semantic
    # code field explicitly, ignoring only checkout-dependent co_filename.
    def constant(value):
        if type(value) is types.CodeType: return ["code", normalized_code(value)]
        if value is Ellipsis: return ["ellipsis"]
        if type(value) is complex: return ["complex", value.real.hex(), value.imag.hex()]
        if type(value) is tuple: return ["tuple", [constant(item) for item in value]]
        if type(value) is frozenset: return ["frozenset", sorted([constant(item) for item in value], key=repr)]
        token = scalar(value)
        if token is None: raise ValueError("unsupported code constant: " + type(value).__name__)
        return token
    fields = ("co_argcount", "co_posonlyargcount", "co_kwonlyargcount", "co_nlocals",
              "co_stacksize", "co_flags", "co_code", "co_names", "co_varnames",
              "co_freevars", "co_cellvars", "co_name", "co_firstlineno", "co_lnotab",
              "co_qualname", "co_linetable", "co_exceptiontable")
    result = {name: scalar(getattr(code, name)) for name in fields if hasattr(code, name)}
    result["co_consts"] = [constant(value) for value in code.co_consts]
    return result

def code_digest(code):
    return sha(json.dumps(normalized_code(code), sort_keys=True, separators=(",", ":")).encode())

def reference(value):
    if isinstance(value, types.ModuleType):
        return ["module", value.__name__]
    if isinstance(value, (type, types.FunctionType, types.BuiltinFunctionType)):
        return ["binding", value.__module__, value.__qualname__]
    return None

def scalar(value):
    if value is None or type(value) in (int, str, bool):
        return [type(value).__name__, value]
    if type(value) is float:
        return ["float", value.hex()]
    if type(value) is bytes:
        return ["bytes", value.hex()]
    import numpy as np
    if isinstance(value, np.generic):
        return ["numpy_scalar", type(value).__name__, scalar(value.item())]
    if type(value) in (list, tuple):
        items = [scalar(item) for item in value]
        return [type(value).__name__, items] if all(item is not None for item in items) else None
    if type(value) in (set, frozenset):
        items = [scalar(item) for item in value]
        return [type(value).__name__, sorted(items, key=repr)] if all(item is not None for item in items) else None
    if type(value) is dict:
        items = [[scalar(key), scalar(item)] for key, item in value.items()]
        return ["dict", items] if all(a is not None and b is not None for a, b in items) else None
    ref = reference(value)
    if ref is not None:
        return ref
    # Enum defaults are keyed by their canonical owner and name.
    from enum import Enum
    if isinstance(value, Enum):
        return ["enum", type(value).__module__, type(value).__qualname__, value.name]
    return None

def function_token(value):
    if isinstance(value, property):
        return ["property", function_token(value.fget),
                function_token(value.fset) if value.fset else None,
                function_token(value.fdel) if value.fdel else None]
    if isinstance(value, (staticmethod, classmethod)):
        return [type(value).__name__, function_token(value.__func__)]
    if type(value) is not types.FunctionType:
        return None
    defaults, kwdefaults = scalar(value.__defaults__), scalar(value.__kwdefaults__)
    if defaults is None or kwdefaults is None:
        raise ValueError("unsupported callable default in admission: " + value.__qualname__)
    closure = []
    for cell in value.__closure__ or ():
        item = cell.cell_contents
        token = function_token(item) if type(item) is types.FunctionType else scalar(item)
        if token is None:
            raise ValueError("unsupported callable closure in admission: " + value.__qualname__)
        closure.append(token)
    return ["function", code_digest(value.__code__), defaults, kwdefaults, closure]

def class_token(value, owner):
    methods, constants, nested = {}, {}, {}
    for name, item in vars(value).items():
        token = function_token(item)
        if token is not None:
            methods[name] = token
        elif isinstance(item, type) and item.__module__ == owner:
            nested[name] = class_token(item, owner)
        elif name not in DYNAMIC_CLASS_VALUES and not name.startswith("__"):
            token = scalar(item)
            if token is not None:
                constants[name] = token
    return {"bases": [reference(base) for base in value.__bases__],
            "methods": methods, "constants": constants, "nested": nested}

def namespace_token(namespace, owner):
    result = {"functions": {}, "classes": {}, "imports": {}, "constants": {}}
    for name, value in namespace.items():
        if name.startswith("__"):
            continue
        if type(value) is types.FunctionType and value.__module__ == owner:
            result["functions"][name] = function_token(value)
        elif isinstance(value, type) and value.__module__ == owner:
            result["classes"][name] = class_token(value, owner)
        else:
            token = reference(value)
            if token is not None:
                result["imports"][name] = token
            else:
                token = scalar(value)
                if token is not None:
                    result["constants"][name] = token
    return result

def resolve_reference(token):
    if token[0] == "module":
        return importlib.import_module(token[1])
    value = importlib.import_module(token[1])
    for piece in token[2].split("."):
        value = getattr(value, piece)
    return value

def check_token(module, expected, allow_quiet_summary=False, allowed_kernel=None, allowed_book=None):
    actual = namespace_token(vars(module), module.__name__)
    # Python imports attach child modules to an already-loaded package. Fresh
    # package source execution does not reproduce those import-system bindings.
    # Admit only exact child module name + identity, never arbitrary extras.
    for name in list(actual["imports"]):
        value = vars(module)[name]
        if name not in expected["imports"] and isinstance(value, types.ModuleType) and value.__name__ == module.__name__ + "." + name and importlib.import_module(value.__name__) is value:
            del actual["imports"][name]
    if allow_quiet_summary and module.__name__ == "abides_core.kernel":
        from installed import quiet_summary_writer
        if module.Kernel.write_summary_log is quiet_summary_writer:
            actual["classes"]["Kernel"]["methods"]["write_summary_log"] = expected["classes"]["Kernel"]["methods"]["write_summary_log"]
    if allowed_kernel is not None and module.__name__ == "abides_core.abides" and module.Kernel is allowed_kernel:
        actual["imports"]["Kernel"] = expected["imports"]["Kernel"]
    if allowed_book is not None and module.__name__ == "abides_markets.agents.exchange_agent" and module.OrderBook is allowed_book:
        actual["imports"]["OrderBook"] = expected["imports"]["OrderBook"]
    if actual != expected:
        for category, values in expected.items():
            for name, token in values.items():
                if actual[category].get(name) != token:
                    raise ValueError("canonical binding differs: " + module.__name__ + "." + name)
        raise ValueError("extra or missing canonical bindings: " + module.__name__)
    for name, token in expected["imports"].items():
        if allowed_kernel is not None and module.__name__ == "abides_core.abides" and name == "Kernel" and module.Kernel is allowed_kernel:
            continue
        if allowed_book is not None and module.__name__ == "abides_markets.agents.exchange_agent" and name == "OrderBook" and module.OrderBook is allowed_book:
            continue
        if vars(module)[name] is not resolve_reference(token):
            raise ValueError("import identity differs: " + module.__name__ + "." + name)

def loaded_modules():
    result = []
    for name, relative in MODULES:
        module = importlib.import_module(name)
        if Path(module.__file__).resolve() != RUNTIME / relative:
            raise ValueError("canonical module origin differs: " + name)
        result.append((module, relative))
    return result

def source_manifest():
    pins = json.loads((HERE / "PINNED_RUNTIME.json").read_text())
    current = {str(path.relative_to(RUNTIME)): sha(path.read_bytes())
               for path in sorted(RUNTIME.rglob("*.py"))
               if not path.name.startswith("._") and "__pycache__" not in path.parts}
    if current != pins["python_sources"]:
        raise ValueError("pinned runtime Python inventory differs")
    for item in pins["runtime_files"]:
        data = (RUNTIME / item["path"]).read_bytes()
        if len(data) != item["bytes"] or sha(data) != item["sha256"]:
            raise ValueError("pinned runtime file differs: " + item["path"])
    return pins

def prove_sources():
    source_manifest()
    snapshots = {}
    for module, relative in loaded_modules():
        namespace = {"__name__": module.__name__, "__package__": module.__package__,
                     "__file__": str(RUNTIME / relative)}
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            code = compile((RUNTIME / relative).read_bytes(), str(RUNTIME / relative),
                           "exec", dont_inherit=True)
        exec(code, namespace)
        expected = namespace_token(namespace, module.__name__)
        check_token(module, expected)
        snapshots[module.__name__] = expected
    cross_bindings()
    return snapshots

def cross_bindings(allowed_kernel=None, allowed_book=None):
    from abides_core import abides, kernel
    from abides_fork import config, agents
    from abides_core.latency_model import LatencyModel
    from abides_markets.oracles.sparse_mean_reverting_oracle import SparseMeanRevertingOracle
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.agents import exchange_agent
    from abides_markets.order_book import OrderBook
    import t3_canonical_engine
    if abides.Kernel is not (kernel.Kernel if allowed_kernel is None else allowed_kernel):
        raise ValueError("core Kernel identity differs before installation")
    if t3_canonical_engine.IncumbentKernel is not kernel.Kernel:
        raise ValueError("canonical engine incumbent identity differs")
    if config.LatencyModel is not LatencyModel or config.SparseMeanRevertingOracle is not SparseMeanRevertingOracle:
        raise ValueError("config latency/oracle identity differs")
    if config.ExchangeAgent is not ExchangeAgent:
        raise ValueError("exchange identity differs")
    if exchange_agent.OrderBook is not (OrderBook if allowed_book is None else allowed_book):
        raise ValueError("exchange book constructor identity differs")
    if config.AGENT_REGISTRY is not agents.AGENT_REGISTRY:
        raise ValueError("scenario registry ownership differs")
    import heapq, _heapq
    if heapq.heappush is not _heapq.heappush or heapq.heappop is not _heapq.heappop:
        raise ValueError("reference heapq requires CPython C heap functions")

def interpreter_pin():
    return {"cache_tag": sys.implementation.cache_tag,
            "version": list(sys.version_info[:3]), "marshal_version": marshal.version}

def source_files():
    return {path.name: sha(path.read_bytes()) for path in sorted(HERE.glob("*.py"))
            if not path.name.startswith("._")}

def candidate_constants(namespace, owner):
    """Exact namespace constants; runtime admission state has separate evidence."""
    dynamic = {"_module", "_receipt", "_captured", "_native_bindings"} if owner == "admission" else set()
    values = {}
    for name, value in namespace.items():
        if name.startswith("__") or name in dynamic:
            continue
        if reference(value) is not None:
            continue
        if isinstance(value, Path):
            token = ["Path", str(value.resolve())]
        else:
            token = scalar(value)
        if token is None:
            raise ValueError("unsupported candidate namespace constant: " + owner + "." + name)
        values[name] = token
    return values

def candidate_callable_pins():
    """Authenticate loaded candidate helpers against fresh exact source AST/code."""
    result = {}
    for name in ("installed", "admission", "provenance", "binding_audit"):
        module = importlib.import_module(name)
        path = HERE / (name + ".py")
        if Path(module.__file__).resolve() != path:
            raise ValueError("candidate helper origin differs: " + name)
        namespace = {"__name__": name, "__package__": "", "__file__": str(path)}
        exec(compile(path.read_bytes(), str(path), "exec", dont_inherit=True), namespace)
        expected = {key: function_token(value) for key, value in namespace.items()
                    if type(value) is types.FunctionType and value.__module__ == name}
        actual = {key: function_token(value) for key, value in vars(module).items()
                  if type(value) is types.FunctionType and value.__module__ == name}
        if actual != expected:
            raise ValueError("candidate helper callable source differs: " + name)
        expected_imports = {key: reference(value) for key, value in namespace.items()
                            if not key.startswith("__") and reference(value) is not None
                            and getattr(value, "__module__", None) != name}
        actual_imports = {key: reference(value) for key, value in vars(module).items()
                          if not key.startswith("__") and reference(value) is not None
                          and getattr(value, "__module__", None) != name}
        if actual_imports != expected_imports:
            raise ValueError("candidate helper imported namespace differs: " + name)
        expected_classes = {key for key, value in namespace.items() if isinstance(value, type) and value.__module__ == name}
        actual_classes = {key for key, value in vars(module).items() if isinstance(value, type) and value.__module__ == name}
        if actual_classes != expected_classes:
            raise ValueError("candidate helper owned class namespace differs: " + name)
        if name == "installed":
            expected["GuardedCanonicalKernel"] = class_token(namespace["GuardedCanonicalKernel"], name)
            actual_class = class_token(module.GuardedCanonicalKernel, name)
            if actual_class != expected["GuardedCanonicalKernel"]:
                raise ValueError("candidate guarded kernel source differs")
        expected["__imports__"] = expected_imports
        expected["__classes__"] = sorted(expected_classes)
        for key, token in expected["__imports__"].items():
            if vars(module).get(key) is not resolve_reference(token):
                raise ValueError("candidate helper imported owner differs: " + name + "." + key)
        expected["__constants__"] = candidate_constants(namespace, name)
        if candidate_constants(vars(module), name) != expected["__constants__"]:
            raise ValueError("candidate helper constants/source namespace differs: " + name)
        result[name] = expected
    return result

def check_candidate_callable_pins(expected):
    """Read saved callable pins without reexecuting source during an episode."""
    for name, pins in expected.items():
        module = importlib.import_module(name)
        actual = {key: function_token(value) for key, value in vars(module).items()
                  if type(value) is types.FunctionType and value.__module__ == name}
        if name == "installed":
            actual["GuardedCanonicalKernel"] = class_token(module.GuardedCanonicalKernel, name)
        actual["__classes__"] = sorted(key for key, value in vars(module).items()
                                     if isinstance(value, type) and value.__module__ == name)
        actual["__imports__"] = {key: reference(value) for key, value in vars(module).items()
                                 if not key.startswith("__") and reference(value) is not None
                                 and getattr(value, "__module__", None) != name}
        for key, token in pins["__imports__"].items():
            if vars(module).get(key) is not resolve_reference(token):
                raise ValueError("candidate helper imported identity changed: " + name + "." + key)
        actual["__constants__"] = candidate_constants(vars(module), name)
        if actual != pins:
            raise ValueError("candidate helper callable changed: " + name)

def static_admission(allowed_kernel=None, allowed_book=None):
    pins = json.loads((HERE / "SOURCE_BINDINGS.json").read_text())
    if pins.get("interpreter") != interpreter_pin():
        raise ValueError("static binding pins require offline preflight on this interpreter")
    check_candidate_callable_pins(pins["candidate_bindings"])
    for module, relative in loaded_modules():
        check_token(module, pins["bindings"][module.__name__], allow_quiet_summary=True, allowed_kernel=allowed_kernel, allowed_book=allowed_book)
    cross_bindings(allowed_kernel, allowed_book)
    return pins

def callable_bindings():
    """Cheap immutable code/identity snapshot after full static proof."""
    captured = []
    def descend(owner):
        for name, value in vars(owner).items():
            if type(value) is types.FunctionType:
                captured.append((owner, name, value, value.__code__))
            elif isinstance(value, (property, staticmethod, classmethod)):
                captured.append((owner, name, value, None))
            elif isinstance(value, type) and value.__module__ == owner.__module__ and value.__qualname__.startswith(owner.__qualname__ + "."):
                descend(value)
    for module, relative in loaded_modules():
        for name, value in vars(module).items():
            if type(value) is types.FunctionType and value.__module__ == module.__name__:
                captured.append((module, name, value, value.__code__))
            elif isinstance(value, type) and value.__module__ == module.__name__:
                descend(value)
    return captured

def check_callable_bindings(captured):
    from installed import quiet_summary_writer
    from abides_core.kernel import Kernel
    for owner, name, original, code in captured:
        actual = vars(owner).get(name)
        if owner is Kernel and name == "write_summary_log" and actual is quiet_summary_writer:
            continue
        if actual is not original or code is not None and actual.__code__ is not code:
            raise ValueError("canonical callable changed after static proof: " + name)

def method_names(cls):
    names = set()
    for base in cls.__mro__:
        for name, value in vars(base).items():
            if type(value) is types.FunctionType or isinstance(value, (property, staticmethod, classmethod)):
                names.add(name)
    return names

def reject_instance_overrides(value, label):
    shadowed = method_names(type(value)).intersection(vars(value))
    if shadowed:
        raise ValueError("direct slice refuses instance callback override: " + label + "." + sorted(shadowed)[0])
