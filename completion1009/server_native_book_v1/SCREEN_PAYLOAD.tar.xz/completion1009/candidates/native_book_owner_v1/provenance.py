"""Shared read-only source and ABI receipt helpers; never load native code."""
from pathlib import Path
import hashlib
import importlib.metadata
import platform
import sys
import sysconfig

HERE = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def candidate_sources():
    return {path.name: sha(path) for path in sorted(HERE.iterdir())
        if path.is_file() and not path.name.startswith("._") and (path.suffix in (".py", ".pyx", ".md") or path.name == "compile_spec.json")}

def abi():
    return {"implementation": sys.implementation.name, "version": list(sys.version_info[:3]),
        "cache_tag": sys.implementation.cache_tag, "soabi": sysconfig.get_config_var("SOABI"),
        "ext_suffix": sysconfig.get_config_var("EXT_SUFFIX"), "platform": sys.platform,
        "machine": platform.machine(), "byteorder": sys.byteorder,
        "pointer_bits": 64 if sys.maxsize > 2**32 else 32}

def dependencies(spec):
    actual = {name: importlib.metadata.version(name) for name in spec["dependencies"]}
    if actual != spec["dependencies"]:
        raise ValueError("native book owner dependency versions differ: " + repr(actual))
    return actual
