#!/usr/bin/env python3
"""Offline Python-source/actual-binding proof, separate from native provenance."""
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent

def main():
    if sys.implementation.name != "cpython" or sys.version_info[:2] != (3, 11):
        raise ValueError("source pins require CPython 3.11")
    destination = HERE / "SOURCE_BINDINGS.json"
    if destination.exists():
        raise ValueError("source evidence exists; preserve prior result")
    sys.path.insert(0, str(HERE / "runtime"))
    from bootstrap import activate
    activate()
    from binding_audit import prove_sources, interpreter_pin, source_files, sha, candidate_callable_pins
    bindings = prove_sources()
    value = {"schema": "t3-native-book-source-bindings-v1", "interpreter": interpreter_pin(),
        "bindings": bindings, "candidate_bindings": candidate_callable_pins(), "candidate_python_sources": source_files(),
        "runtime_pins_sha256": sha((HERE / "PINNED_RUNTIME.json").read_bytes()),
        "source_proof_only": True, "native_execution": False, "timing_claim": False}
    destination.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

if __name__ == "__main__":
    main()
