"""Receipt-bound exact native ownership admission before construction/initialize."""
import importlib
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import sys
from provenance import HERE, abi, candidate_sources, dependencies, sha

_module = None
_receipt = None
_captured = None
_native_bindings = None


def native_token(module):
    from binding_audit import scalar
    rows = []
    for owner in [module] + [value for value in vars(module).values()
                            if isinstance(value, type) and value.__module__ == module.__name__]:
        for name, value in vars(owner).items():
            if name.startswith("__"):
                continue
            rows.append((owner, name, value, scalar(getattr(value, "__defaults__", None)),
                         scalar(getattr(value, "__kwdefaults__", None)), scalar(value)))
    return rows


def check_native():
    from binding_audit import scalar
    for owner, name, value, defaults, kwdefaults, constant in _native_bindings:
        current = vars(owner).get(name)
        if (current is not value or scalar(getattr(current, "__defaults__", None)) != defaults
                or scalar(getattr(current, "__kwdefaults__", None)) != kwdefaults or scalar(current) != constant):
            raise ValueError("native book binding mutated: " + name)
    if sha(_receipt["extension_path"]) != _receipt["extension_sha256"]:
        raise ValueError("native book extension changed after admission")


def cross_bindings(module):
    from abides_markets import orders, order_book, price_level
    if module.OriginalOrderBook is not order_book.OrderBook or module.OriginalPriceLevel is not price_level.PriceLevel:
        raise ValueError("native book original facade identity differs")
    if module.logger is not order_book.logger:
        raise ValueError("native book logger identity differs")
    for name in ("Order", "LimitOrder", "MarketOrder", "Side"):
        if getattr(module, name) is not getattr(orders, name):
            raise ValueError("native book raw order identity differs: " + name)
    for name, value in vars(module).items():
        if isinstance(value, type) and value.__module__.startswith(("abides_core", "abides_markets")):
            canonical = importlib.import_module(value.__module__)
            for piece in value.__qualname__.split("."):
                canonical = getattr(canonical, piece)
            if value is not canonical:
                raise ValueError("native book raw notification identity differs: " + name)


def load_native(receipt_path):
    global _module, _receipt, _captured, _native_bindings
    receipt_path = Path(receipt_path).resolve()
    receipt = json.loads(receipt_path.read_text())
    spec = json.loads((HERE / "compile_spec.json").read_text())
    if (receipt.get("schema") != "t3-native-book-owner-build-v1"
            or receipt.get("candidate") != "native_book_owner_v1" or receipt.get("build_succeeded") is not True):
        raise ValueError("native book requires a successful build receipt")
    if receipt.get("abi") != abi() or receipt.get("cython") != spec["cython"] or receipt.get("dependencies") != dependencies(spec):
        raise ValueError("native book ABI/dependency/Cython identity differs")
    if receipt.get("candidate_sources") != candidate_sources():
        raise ValueError("native book source changed since build")
    for field, name in (("compile_spec_sha256", "compile_spec.json"),
                        ("runtime_pins_sha256", "PINNED_RUNTIME.json"),
                        ("source_bindings_sha256", "SOURCE_BINDINGS.json")):
        if receipt.get(field) != sha(HERE / name):
            raise ValueError("native book provenance differs: " + name)
    if receipt.get("compile_flags") != spec["compile_flags"] or receipt.get("directives") != spec["directives"]:
        raise ValueError("native book compiler recipe differs")
    build_root = receipt_path.parent
    record = receipt["extension"]
    extension = (build_root / record["path"]).resolve()
    if (not extension.is_relative_to(build_root) or extension.suffix not in (".so", ".pyd")
            or extension.stat().st_size != record["bytes"] or sha(extension) != record["sha256"]):
        raise ValueError("native book extension bytes/path differ")
    if not receipt.get("generated_c"):
        raise ValueError("native book generated C receipt absent")
    for relative, digest in receipt["generated_c"].items():
        path = (build_root / relative).resolve()
        if not path.is_relative_to(build_root) or sha(path) != digest:
            raise ValueError("native book generated C differs")
    import binding_audit
    binding_audit.source_manifest()
    pins = binding_audit.static_admission()
    if pins.get("candidate_python_sources") != binding_audit.source_files() or pins.get("runtime_pins_sha256") != sha(HERE / "PINNED_RUNTIME.json"):
        raise ValueError("native book source-binding evidence differs")
    existing = sys.modules.get("native_book")
    if existing is None:
        module_spec = importlib.util.spec_from_file_location("native_book", extension)
        if module_spec is None or not isinstance(module_spec.loader, importlib.machinery.ExtensionFileLoader):
            raise ValueError("native book requires an extension loader")
        module = importlib.util.module_from_spec(module_spec)
        sys.modules["native_book"] = module
        try:
            module_spec.loader.exec_module(module)
        except BaseException:
            sys.modules.pop("native_book", None)
            raise
    else:
        module = existing
    if Path(module.__file__).resolve() != extension or not isinstance(module.__spec__.loader, importlib.machinery.ExtensionFileLoader):
        raise ValueError("native book loaded origin differs")
    if _module is not None:
        check_native()
    cross_bindings(module)
    _module, _receipt = module, {"receipt_path": str(receipt_path), "receipt_sha256": sha(receipt_path),
                                "extension_path": str(extension), "extension_sha256": record["sha256"], "abi": receipt["abi"]}
    _captured, _native_bindings = binding_audit.callable_bindings(), native_token(module)
    return module


def admit_producers(scenario):
    """Whole-episode scalar/domain proof through exact frozen four producers."""
    if _module is None:
        raise ValueError("native book not loaded")
    import binding_audit
    binding_audit.static_admission()
    binding_audit.check_callable_bindings(_captured)
    check_native()
    cross_bindings(_module)
    from abides_fork import agents
    expected = {"NoiseTrader": agents.NoiseTrader, "MarketMaker": agents.MarketMaker,
                "ValueTrader": agents.ValueTrader, "MomentumTrader": agents.MomentumTrader}
    if agents.AGENT_REGISTRY != expected:
        raise ValueError("native book requires exact four-registry producer owners")
    if (type(scenario) is not dict or type(scenario.get("agent_configs")) is not list
            or any(type(row) is not dict or row.get("agent_type") not in expected
                   or type(row.get("count")) is not int for row in scenario["agent_configs"])):
        raise ValueError("native book episode producer domain unsupported")
    # scenario originates from json.loads + validate_scenario in the CLI. The
    # full source-bound producer graph emits only original scalar quantities;
    # users cannot install callback-bearing quantity owners via this interface.
    def json_value(value):
        if value is None or type(value) in (str, int, float, bool):
            return True
        if type(value) is list:
            return all(json_value(item) for item in value)
        if type(value) is dict:
            return all(type(key) is str and json_value(item) for key, item in value.items())
        return False
    if not json_value(scenario):
        raise ValueError("native book refuses arbitrary callback-bearing scenario objects")
    return _module


def admit_config(config, allowed_kernel=None):
    """Check ownership before kernel initialization; no running fallback."""
    import binding_audit
    binding_audit.static_admission(allowed_kernel=allowed_kernel, allowed_book=_module.NativeBook)
    binding_audit.check_callable_bindings(_captured)
    check_native()
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.orders import LimitOrder, MarketOrder, Side
    from abides_fork.agents import AGENT_REGISTRY
    import numpy as np
    agents = config.get("agents")
    if type(agents) is not list or not agents or type(agents[0]) is not ExchangeAgent:
        raise ValueError("native book requires original exchange-first list")
    if any(type(a.id) is not int or a.id != i for i, a in enumerate(agents)):
        raise ValueError("native book requires dense original agent IDs")
    def original_scalar(value):
        return type(value) in (int, float, bool) or type(value) in tuple(np.sctypeDict[name] for name in
            ("int8", "int16", "int32", "int64", "uint8", "uint16", "uint32", "uint64", "float32", "float64", "bool_"))
    for agent in agents:
        binding_audit.reject_instance_overrides(agent, "agent")
        if agent is not agents[0] and type(agent) not in AGENT_REGISTRY.values():
            raise ValueError("native book unknown strategy owner")
        if agent is not agents[0]:
            for name in ("holdings", "orders", "known_bids", "known_asks", "last_trade",
                         "daily_close_price", "stream_history", "transacted_volume"):
                if type(getattr(agent, name)) is not dict:
                    raise ValueError("native book requires original strategy dictionary owner: " + name)
        for order in getattr(agent, "orders", {}).values():
            if type(order) not in (LimitOrder, MarketOrder):
                raise ValueError("native book requires original raw orders")
            binding_audit.reject_instance_overrides(order, "order")
            if not original_scalar(order.quantity) or order.side not in (Side.BID, Side.ASK):
                raise ValueError("native book callback-bearing order scalar unsupported")
    if type(agents[0].order_books) is not dict:
        raise ValueError("native book requires original book mapping owner")
    for symbol, book in agents[0].order_books.items():
        if (type(book) is not _module.NativeBook or type(book.bids) is not list or type(book.asks) is not list
                or book.bids or book.asks or book.owner is not agents[0] or book.symbol != symbol):
            raise ValueError("native book requires its original empty owner topology")
        if set(vars(book)) != {"owner", "symbol", "bids", "asks", "last_trade", "book_log2", "quotes_seen",
                               "history", "last_update_ts", "buy_transactions", "sell_transactions"}:
            raise ValueError("native book state fields differ before initialize")
        for name in ("book_log2", "history", "buy_transactions", "sell_transactions"):
            if type(getattr(book, name)) is not list or getattr(book, name):
                raise ValueError("native book requires empty original list owner: " + name)
        if (type(book.quotes_seen) is not set or book.quotes_seen or book.last_trade is not None
                or book.last_update_ts != agents[0].mkt_open
                or any(type(value) is not int or value != 0 for value in book.proof_counts().values())):
            raise ValueError("native book initial scalar/witness state differs")
        if any(callable(value) for value in vars(book).values()):
            raise ValueError("native book refuses instance callback overrides")
    return True


def admit_kernel(kernel):
    """The original Kernel invokes this guard immediately before initialize."""
    import binding_audit
    from installed import GuardedCanonicalKernel
    if type(kernel) is not GuardedCanonicalKernel:
        raise ValueError("native book requires the exact guarded canonical kernel")
    binding_audit.static_admission(allowed_kernel=GuardedCanonicalKernel, allowed_book=_module.NativeBook)
    binding_audit.check_callable_bindings(_captured)
    check_native()
    binding_audit.reject_instance_overrides(kernel, "kernel")
    admit_config({"agents": kernel.agents}, allowed_kernel=GuardedCanonicalKernel)
    from abides_fork.config import ScenarioLatencyModel
    from abides_core.latency_model import LatencyModel
    from abides_markets.oracles.sparse_mean_reverting_oracle import SparseMeanRevertingOracle
    latency = kernel.agent_latency_model
    if latency is not None:
        if type(latency) not in (ScenarioLatencyModel, LatencyModel):
            raise ValueError("native book unpinned latency owner")
        binding_audit.reject_instance_overrides(latency, "latency")
    if type(kernel.oracle) is not SparseMeanRevertingOracle:
        raise ValueError("native book unpinned oracle owner")
    binding_audit.reject_instance_overrides(kernel.oracle, "oracle")
    return True


def native_receipt():
    if _receipt is None:
        raise ValueError("native book receipt absent")
    return dict(_receipt)
