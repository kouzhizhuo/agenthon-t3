#!/usr/bin/env python3
"""Paired exact native owner finite controls; separate from all market timing."""
import argparse
from contextlib import redirect_stdout
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import sys
import warnings

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    destination = Path(args.out).resolve()
    if destination.exists():
        raise ValueError("control evidence exists; preserve it")
    sys.path.insert(0, str(HERE / "runtime"))
    from bootstrap import activate
    activate()
    import numpy as np
    import pandas as pd
    from abides_core.message import Message
    from abides_markets.order_book import OrderBook
    from abides_markets.price_level import PriceLevel
    from abides_markets.orders import LimitOrder, MarketOrder, Order, Side
    from admission import load_native, native_receipt
    native = load_native(args.receipt)
    NativeBook, NativeLevel = native.NativeBook, native.NativeLevel
    checks, failures, receipts = [], [], []
    original_order_counter = Order._order_id_counter
    original_message_counter = Message._Message__message_id_counter

    class Oracle:
        def observe_price(self, symbol, current_time, sigma_n=0, random_state=None):
            return 99 + int(random_state.randint(0, 2))

    class Owner:
        def __init__(self, policy=None, logging=False):
            self.mkt_open = 1612517400000000000
            self.current_time = self.mkt_open
            self.book_logging = logging
            self.book_log_depth = 5
            self.stp_policy = policy
            self.messages = []
            self.events = []
            self.random_state = np.random.RandomState(47)
            self.oracle = Oracle()

        def send_message(self, recipient, message):
            self.messages.append((recipient, message))

        def logEvent(self, kind, value):
            self.events.append((kind, value))

    def order(identifier, quantity=10, side=Side.BID, price=100, agent=1, **flags):
        return LimitOrder(agent, 1612517400000000000, "ABM", quantity, side, price,
                          order_id=identifier, **flags)

    def market(identifier, quantity=10, side=Side.BID, agent=2, tag=None):
        return MarketOrder(agent, 1612517400000000000, "ABM", quantity, side,
                           order_id=identifier, tag=tag)

    def graph(roots):
        """Exact types/values and alias partitions, including cyclic PTC graphs."""
        objects, ids, queue = [], {}, []
        def scalar(value):
            if value is None or type(value) in (bool, int, str):
                return [type(value).__name__, value]
            if type(value) is float:
                return ["float", value.hex()]
            if type(value) is bytes:
                return ["bytes", value.hex()]
            if isinstance(value, np.generic):
                return ["numpy", type(value).__name__, scalar(value.item())]
            if isinstance(value, Side):
                return ["Side", value.name]
            return None
        def ref(value):
            item = scalar(value)
            if item is not None:
                return item
            identifier = id(value)
            if identifier not in ids:
                ids[identifier] = len(queue)
                queue.append(value)
            return ["ref", ids[identifier]]
        root = ref(roots)
        cursor = 0
        while cursor < len(queue):
            value = queue[cursor]
            cursor += 1
            if type(value) in (list, tuple):
                item = [type(value).__name__, [ref(x) for x in value]]
            elif type(value) is dict:
                item = ["dict", [[ref(k), ref(v)] for k, v in value.items()]]
            elif type(value) in (set, frozenset):
                item = [type(value).__name__, sorted([ref(x) for x in value], key=repr)]
            elif type(value) is np.ndarray:
                item = ["ndarray", value.dtype.str, list(value.shape),
                        ref(value.tolist()) if value.dtype.hasobject else value.tobytes().hex()]
            elif type(value) is np.random.RandomState:
                item = ["RandomState", ref(value.get_state())]
            elif isinstance(value, pd.DataFrame):
                item = ["DataFrame", list(value.columns), [str(x) for x in value.dtypes],
                        ref(value.to_dict("list")), ref(value.index.tolist())]
            elif type(value) in (OrderBook, NativeBook):
                item = ["OrderBook", ref(vars(value))]
            elif type(value) in (PriceLevel, NativeLevel):
                item = ["PriceLevel", ref(vars(value))]
            elif hasattr(value, "__dict__"):
                # Message serial IDs are episode-global; reset before each arm.
                item = [type(value).__module__ + "." + type(value).__qualname__, ref(vars(value))]
            else:
                raise TypeError("unsupported control graph value: " + type(value).__name__)
            objects.append(item)
        return [root, objects]

    def capture(call):
        stream = io.StringIO()
        with warnings.catch_warnings(record=True) as notices, redirect_stdout(stream):
            warnings.simplefilter("always")
            try:
                result, error = call(), None
            except Exception as exception:
                result, error = None, [type(exception).__module__, type(exception).__name__, str(exception)]
        return result, error, [[n.category.__module__, n.category.__name__, str(n.message)] for n in notices], stream.getvalue()

    def check(name, actual):
        if not actual:
            raise AssertionError(name)
        checks.append(name)

    def pair(name, setup, actions):
        Message._Message__message_id_counter = original_message_counter
        left = setup(OrderBook, PriceLevel)
        Message._Message__message_id_counter = original_message_counter
        right = setup(NativeBook, NativeLevel)
        check(name + ":initial_state", graph(left) == graph(right))
        for index, action in enumerate(actions):
            before = Message._Message__message_id_counter
            a = capture(lambda: action(left))
            after_a = Message._Message__message_id_counter
            Message._Message__message_id_counter = before
            b = capture(lambda: action(right))
            after_b = Message._Message__message_id_counter
            check(name + ":result_aliases:" + str(index), graph([left, a[0]]) == graph([right, b[0]]))
            check(name + ":exception_warning_stdout:" + str(index), a[1:] == b[1:])
            check(name + ":state_alias_types:" + str(index), graph(left) == graph(right))
            check(name + ":message_counter:" + str(index), after_a == after_b)
        receipts.append({"case": name, "actions": len(actions), "passed": True})
        return right

    def book_setup(policy=None, logging=False, orders=()):
        def setup(book_type, level_type):
            owner = Owner(policy, logging)
            book = book_type(owner, "ABM")
            placed = [make() for make in orders]
            metadata = [{"index": i} for i in range(len(placed))]
            for item, data in zip(placed, metadata):
                book.enter_order(item, data, quiet=True)
            return {"book": book, "owner": owner, "orders": placed, "metadata": metadata, "returns": []}
        return setup

    try:
        # Raw list/row/order/metadata aliasing, duplicate IDs and both FIFOs.
        def level_setup(book_type, level_type):
            rows = [(order(5, 10), {"row": "v5"}),
                    (order(5, 7, is_hidden=True), {"row": "h5"}),
                    (order(3, 6, insert_by_id=True), {"row": "v3"}),
                    (order(5, 12, insert_by_id=True), {"row": "v5b"}),
                    (order(9, 4, is_hidden=True), {"row": "h9"})]
            level = level_type(rows)
            return {"level": level, "orders": [x[0] for x in rows], "metadata": [x[1] for x in rows],
                    "visible_alias": level.visible_orders, "hidden_alias": level.hidden_orders, "returns": []}
        state = pair("level_fifo_hidden_duplicate_alias", level_setup, [
            lambda s: s["level"].peek(),
            lambda s: s["level"].update_order_quantity(5, 8),
            lambda s: s["level"].update_order_quantity(5, 22),
            lambda s: s["level"].update_order_quantity(9, -1),
            lambda s: s["level"].update_order_quantity(9, 0),
            lambda s: s["level"].remove_order(5),
            lambda s: s["level"].remove_order(999),
            lambda s: s["returns"].append(s["level"].pop()),
            lambda s: s["returns"].append(s["level"].pop()),
            lambda s: s["returns"].append(s["level"].pop()),
            lambda s: s["returns"].append(s["level"].pop()),
            lambda s: s["level"].peek(), lambda s: s["level"].pop(),
            lambda s: s["level"].is_empty, lambda s: s["level"].total_quantity,
        ])
        check("level_live_lists_retained", state["visible_alias"] is state["level"].visible_orders
              and state["hidden_alias"] is state["level"].hidden_orders)
        pair("raw_queue_structural_alias", level_setup, [
            lambda s: s["visible_alias"].append((order(21, 6), s["metadata"][0])),
            lambda s: s["level"].total_quantity,
            lambda s: s["visible_alias"].reverse(),
            lambda s: s["level"].peek(),
            lambda s: s["hidden_alias"].pop(),
            lambda s: s["level"].update_order_quantity(5, 25)])
        for side in (Side.BID, Side.ASK):
            def side_setup(book_type, level_type, side=side):
                level = level_type([(order(1, side=side), {})])
                return {"level": level, "same": order(2, side=side),
                        "opposite": order(3, side=Side.ASK if side.is_bid() else Side.BID)}
            pair("level_comparison_" + side.value, side_setup, [
                lambda s: s["level"].order_is_match(s["same"]),
                lambda s: s["level"].order_has_better_price(s["opposite"]),
                lambda s: s["level"].order_has_worse_price(s["opposite"]),
                lambda s: s["level"].order_has_equal_price(s["opposite"]),
                lambda s: s["level"].order_is_match(s["opposite"]),
                lambda s: s["level"].order_has_equal_price(s["same"]),
                lambda s: s["level"].__eq__(object()),
            ])
        numeric_lanes = [
            ("builtin_big", [2**80, 2**79, -2**78]),
            ("numpy_int64_overflow", [np.int64(2**63 - 1), np.int64(1), np.int64(-1)]),
            ("numpy_uint64", [np.uint64(2**63), np.uint64(7), np.uint64(1)]),
            ("numpy_int32", [np.int32(2**31 - 1), np.int32(1), np.int32(-1)]),
            ("numpy_float32", [np.float32(2**24), np.float32(1), np.float32(-2**24)]),
            ("mixed_numpy_builtin", [1, np.int64(4), 2**80, np.int64(-2)]),
            ("builtin_float", [2**53, 1.0, -float(2**53)]),
            ("bool", [True, np.bool_(True), False]),
        ]
        for label, quantities in numeric_lanes:
            def numeric_setup(book_type, level_type, quantities=quantities):
                rows = [(order(50 + i, q), {}) for i, q in enumerate(quantities)]
                return {"level": level_type(rows), "orders": [x[0] for x in rows]}
            pair("exact_sum_" + label, numeric_setup, [lambda s: s["level"].total_quantity,
                lambda s, quantities=quantities: setattr(s["orders"][0], "quantity", quantities[-1]),
                lambda s: s["level"].total_quantity])
        for side in (Side.BID, Side.ASK):
            opp = Side.ASK if side.is_bid() else Side.BID
            for policy in (None, "cancel_oldest", "cancel_newest", "unknown_truthy"):
                setup = book_setup(policy, True, [lambda opp=opp: order(100, 7, opp, 100, agent=2),
                    lambda opp=opp: order(101, 8, opp, 100, agent=3),
                    lambda opp=opp: order(102, 9, opp, 101 if side.is_bid() else 99, agent=4)])
                def incoming(s, side=side):
                    item = order(103, 20, side, 110 if side.is_bid() else 90, agent=2)
                    s["orders"].append(item)
                    return s["book"].handle_limit_order(item)
                final = pair("limit_multilevel_stp_" + side.value + "_" + str(policy), setup,
                             [incoming, lambda s: s["book"].get_transacted_volume(),
                              lambda s: s["book"].get_imbalance(), lambda s: s["book"].get_L1_snapshots()])
                check("native_internal_counts_" + side.value + "_" + str(policy),
                      all(type(v) is int and v >= 0 for v in final["book"].proof_counts().values())
                      and final["book"].proof_counts()["match"] > 0 and final["book"].proof_counts()["read"] > 0)
            for quiet in (False, True):
                pair("limit_accept_quiet_" + side.value + "_" + str(quiet), book_setup(logging=True), [
                    lambda s, side=side, quiet=quiet: s["book"].handle_limit_order(order(120, 6, side, 100, tag={"mutable": [1]}), quiet=quiet),
                    lambda s: s["book"].get_l2_bid_data(), lambda s: s["book"].get_l2_ask_data()])
            for policy in (None, "cancel_oldest", "cancel_newest"):
                pair("market_multilevel_stp_" + side.value + "_" + str(policy),
                     book_setup(policy, True, [lambda opp=opp: order(130, 5, opp, agent=2),
                                              lambda opp=opp: order(131, 7, opp, agent=3)]), [
                     lambda s, side=side: s["book"].handle_market_order(market(132, 20, side)),
                     lambda s: s["book"].get_transacted_volume("0ns")])
            for tag in ("MR_preprocess_ADD", "MR_preprocess_REPLACE"):
                pair("MR_post_only_" + side.value + "_" + tag,
                     book_setup(logging=True, orders=[lambda opp=opp: order(140, 5, opp)]), [
                     lambda s, side=side, tag=tag: s["book"].handle_limit_order(order(141, 6, side, tag=tag))])
            for partial in (False, True):
                # PTC hidden half is one tick better and comes first in book.
                pair("PTC_fill_" + side.value + "_" + str(partial),
                     book_setup(logging=True, orders=[lambda opp=opp: order(150, 10, opp, is_price_to_comply=True)]), [
                     lambda s, side=side, partial=partial: s["book"].execute_order(order(151, 4 if partial else 10, side, 110 if side.is_bid() else 90)),
                     lambda s: s["book"].get_l3_bid_data(), lambda s: s["book"].get_l3_ask_data()])
            pair("PTC_cancel_" + side.value, book_setup(logging=True, orders=[lambda side=side: order(160, 10, side, is_price_to_comply=True)]), [
                lambda s, side=side: s["book"].cancel_order(order(160, 1, side, agent=9), tag="auctionFill", cancellation_metadata={"quantity": 4, "price": 99}),
                lambda s: s["book"].cancel_order(s["orders"][0])])
            pair("hidden_post_only_" + side.value, book_setup(logging=True, orders=[lambda opp=opp: order(170, 10, opp, is_hidden=True)]), [
                lambda s, side=side: s["book"].execute_order(order(171, 4, side, is_post_only=True)),
                lambda s, side=side: s["book"].execute_order(order(172, 4, side)),
                lambda s: s["book"].get_l1_bid_data(), lambda s: s["book"].get_l1_ask_data()])
            pair("PTC_visible_execution_exception_residue_" + side.value,
                 book_setup(logging=True, orders=[lambda opp=opp: order(175, 10, opp, is_price_to_comply=True)]), [
                 lambda s, opp=opp: (s["book"].asks if opp.is_ask() else s["book"].bids).pop(0),
                 lambda s, side=side: s["book"].execute_order(order(176, 20, side, 110 if side.is_bid() else 90))])
        for method in ("handle_limit_order", "handle_market_order"):
            for label, quantity, price, symbol in [("zero", 0, 100, "ABM"), ("negative", -1, 100, "ABM"),
                    ("fraction", 1.5, 100, "ABM"), ("numpy", np.int64(6), np.int64(100), "ABM"),
                    ("price_negative", 5, -1, "ABM"), ("price_fraction", 5, 100.5, "ABM"),
                    ("wrong_symbol", 5, 100, "OTHER"), ("nan", float("nan"), 100, "ABM"),
                    ("huge", 2**80, 2**80, "ABM")]:
                def invalid(s, method=method, quantity=quantity, price=price, symbol=symbol):
                    item = order(180, quantity, price=price) if method == "handle_limit_order" else market(180, quantity)
                    item.symbol = symbol
                    s["orders"].append(item)
                    return getattr(s["book"], method)(item)
                pair("validation_" + method + "_" + label, book_setup(logging=True), [invalid])
        # Read depths preserve slice-before-filter and hidden-only L1 oddities.
        for side in (Side.BID, Side.ASK):
            setup = book_setup(logging=True, orders=[lambda side=side: order(200, 3, side, 101),
                lambda side=side: order(201, 4, side, 100, is_hidden=True),
                lambda side=side: order(202, 5, side, 99)])
            actions = []
            for depth in (None, 0, 1, 2, 9, -1, -2):
                for method in ("get_l2_bid_data", "get_l2_ask_data", "get_l3_bid_data", "get_l3_ask_data"):
                    actions.append(lambda s, method=method, depth=depth: getattr(s["book"], method)(depth))
            actions.extend([lambda s: s["book"].get_l1_bid_data(), lambda s: s["book"].get_l1_ask_data(),
                lambda s: s["book"].get_imbalance(), lambda s: s["book"].append_book_log2(),
                lambda s: s["book"].get_L1_snapshots(), lambda s: s["book"].get_L2_snapshots(4)])
            pair("read_depth_" + side.value, setup, actions)
            pair("L1_hidden_only_" + side.value,
                 book_setup(orders=[lambda side=side: order(210, 8, side, is_hidden=True)]),
                 [lambda s, side=side: getattr(s["book"], "get_l1_bid_data" if side.is_bid() else "get_l1_ask_data")()])
            pair("L1_hidden_best_visible_next_" + side.value,
                 book_setup(orders=[lambda side=side: order(215, 8, side, 101 if side.is_bid() else 99, is_hidden=True),
                                    lambda side=side: order(216, 7, side, 100)]),
                 [lambda s, side=side: getattr(s["book"], "get_l1_bid_data" if side.is_bid() else "get_l1_ask_data")()])
        for logging in (False, True, None, 1):
            pair("modify_partial_replace_" + str(logging), book_setup(logging=logging, orders=[
                 lambda: order(220, 10), lambda: order(221, 7)]), [
                 lambda s: s["book"].modify_order(s["orders"][0], order(999, 2)),
                 lambda s: s["book"].modify_order(s["orders"][0], order(220, 20)),
                 lambda s: s["book"].modify_order(s["orders"][0], order(220, 8)),
                 lambda s: s["book"].partial_cancel_order(s["orders"][0], 2, tag="auctionFill", cancellation_metadata={"quantity": 2, "price": 100}),
                 lambda s: s["book"].partial_cancel_order(s["orders"][0], 30),
                 lambda s: s["book"].partial_cancel_order(order(19653081), 3),
                 lambda s: s["book"].replace_order(9, s["orders"][1], order(222, 5, Side.ASK)),
                 lambda s: s["book"].replace_order(9, order(999), order(223, 5)),
                 lambda s: s["book"].cancel_order(order(999)),
                 lambda s: s["book"].get_l3_itch()])
        def volume_setup(book_type, level_type):
            s = book_setup()(book_type, level_type)
            now = s["owner"].current_time
            s["book"].buy_transactions.extend([(now - 30, 1), (now - 10, np.int64(2)), (now, 3)])
            s["book"].sell_transactions.extend([(now - 20, 4), (now - 5, np.int64(5))])
            return s
        pair("volume_windows", volume_setup, [lambda s: s["book"].get_transacted_volume("10ns"),
            lambda s: s["book"].get_transacted_volume("0ns"), lambda s: s["book"].get_transacted_volume("1min"),
            lambda s: s["book"].get_transacted_volume("invalid")])
        def diagnostic_setup(book_type, level_type):
            s = book_setup(orders=[lambda: order(230, 4), lambda: order(231, 5, Side.ASK, 102)])(book_type, level_type)
            s["book"].last_trade = 100
            return s
        pair("padding_pretty_print_rng", diagnostic_setup, [
            lambda s: s["book"].bids_padding(np.array([], dtype=int), 3),
            lambda s: s["book"].asks_padding(np.array([[100, 4]], dtype=int), 3),
            lambda s: s["book"].bids_padding(np.array([[100, 4]], dtype=int), 3),
            lambda s: s["book"].pretty_print(), lambda s: s["book"].pretty_print(False)])
        # All native cdef ownership witnesses must be exercised by real routes.
        witness = pair("owner_witness_all_four", book_setup(logging=True), [
            lambda s: s["book"].enter_order(order(240, 10)),
            lambda s: s["book"].get_l2_bid_data(),
            lambda s: s["book"].execute_order(order(241, 3, Side.ASK, 90)),
            lambda s: s["book"].cancel_order(order(240))])
        check("cdef_witness_all_four", list(witness["book"].proof_counts()) == ["match", "cancel", "insert", "read"]
              and all(type(value) is int and value > 0 for value in witness["book"].proof_counts().values()))
        # Admission controls do not construct agents or run an episode.
        from admission import admit_producers
        scenario = {"agent_configs": [{"agent_type": "NoiseTrader", "count": 1}]}
        check("admission_original_four_producer", admit_producers(scenario) is native)
        for label, unsupported in [("unknown", {"agent_configs": [{"agent_type": "CustomTrader", "count": 1}]}),
                                   ("bool_count", {"agent_configs": [{"agent_type": "NoiseTrader", "count": True}]}),
                                   ("callback_quantity", {"agent_configs": [{"agent_type": "NoiseTrader", "count": 1}], "quantity": object()})]:
            error = capture(lambda unsupported=unsupported: admit_producers(unsupported))[1]
            check("admission_reject_" + label, error is not None and error[1] == "ValueError")
        from abides_fork import agents as raw_agents
        original_registry = raw_agents.AGENT_REGISTRY.copy()
        try:
            raw_agents.AGENT_REGISTRY["NoiseTrader"] = object
            error = capture(lambda: admit_producers(scenario))[1]
            check("admission_registry_mutation", error is not None and error[1] == "ValueError")
        finally:
            raw_agents.AGENT_REGISTRY.clear()
            raw_agents.AGENT_REGISTRY.update(original_registry)
        original_helper = native._positive_row
        try:
            native._positive_row = lambda row: True
            error = capture(lambda: admit_producers(scenario))[1]
            check("admission_native_binding_mutation", error is not None and error[1] == "ValueError")
        finally:
            native._positive_row = original_helper
        check("admission_restored_exact_producer", admit_producers(scenario) is native)
        import binding_audit
        original_modules = binding_audit.MODULES
        try:
            binding_audit.MODULES = original_modules[:1]
            error = capture(lambda: admit_producers(scenario))[1]
            check("admission_module_roster_constant_mutation", error is not None and error[1] == "ValueError")
        finally:
            binding_audit.MODULES = original_modules
        original_dynamic = binding_audit.DYNAMIC_CLASS_VALUES
        try:
            binding_audit.DYNAMIC_CLASS_VALUES = original_dynamic | {"injected_ignore"}
            error = capture(lambda: admit_producers(scenario))[1]
            check("admission_dynamic_constant_allowlist_mutation", error is not None and error[1] == "ValueError")
        finally:
            binding_audit.DYNAMIC_CLASS_VALUES = original_dynamic
        try:
            binding_audit.EXTRA_UNAUTHENTICATED_NAMESPACE = 17
            error = capture(lambda: admit_producers(scenario))[1]
            check("admission_extra_namespace_constant", error is not None and error[1] == "ValueError")
        finally:
            del binding_audit.EXTRA_UNAUTHENTICATED_NAMESPACE
        try:
            binding_audit.EXTRA_IMPORTED_NAMESPACE = json
            error = capture(lambda: admit_producers(scenario))[1]
            check("admission_extra_imported_namespace", error is not None and error[1] == "ValueError")
        finally:
            del binding_audit.EXTRA_IMPORTED_NAMESPACE
        try:
            binding_audit.EXTRA_OWNED_NAMESPACE = type("ExtraOwned", (), {"__module__": "binding_audit"})
            error = capture(lambda: admit_producers(scenario))[1]
            check("admission_extra_owned_class_namespace", error is not None and error[1] == "ValueError")
        finally:
            del binding_audit.EXTRA_OWNED_NAMESPACE
        check("admission_constants_namespace_restored", admit_producers(scenario) is native)
        # Construction only: exact original agents/oracle/latency are created,
        # but initialize/runner/market are never called by these refusal cases.
        from abides_fork.config import build_config
        from abides_core.utils import subdict
        from installed import book_owner, GuardedCanonicalKernel, runtime_guard
        from admission import admit_config
        fixed = {"scenario_id": "native-book-admission-controls", "seed": 901009, "horizon_ns": 1000000,
                 "exchange_config": {"symbol": "ABM"},
                 "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100000, "kappa": .05,
                     "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}},
                 "latency_config": {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}},
                 "agent_configs": [{"agent_type": "NoiseTrader", "count": 1, "params": {"arrival_rate_hz": 6.}},
                                   {"agent_type": "MarketMaker", "count": 1, "params": {"depth_levels": 2}},
                                   {"agent_type": "ValueTrader", "count": 1, "params": {}},
                                   {"agent_type": "MomentumTrader", "count": 1, "params": {}}]}
        before_config_order_counter = Order._order_id_counter
        with book_owner(fixed):
            config = build_config(fixed)
            check("admission_empty_native_config", admit_config(config))
            from abides_core import abides
            previous_kernel = abides.Kernel
            abides.Kernel = GuardedCanonicalKernel
            try:
                kernel = GuardedCanonicalKernel(random_state=np.random.RandomState(0), log_dir="control",
                    **subdict(config, ["start_time", "stop_time", "agents", "agent_latency_model",
                                       "default_computation_delay", "custom_properties"]))
                check("preinitialize_exact_original_owner", runtime_guard(kernel))
                book = kernel.agents[0].order_books["ABM"]
                def refusal(label, owner, name, bad):
                    state = vars(owner)
                    present, before = name in state, state.get(name)
                    try:
                        setattr(owner, name, bad)
                        error = capture(lambda: runtime_guard(kernel))[1]
                        check("preinitialize_reject_" + label, error is not None and error[1] == "ValueError")
                    finally:
                        if present:
                            setattr(owner, name, before)
                        else:
                            delattr(owner, name)
                    check("preinitialize_restored_" + label, runtime_guard(kernel))
                refusal("book_falsey_tuple", book, "bids", ())
                refusal("book_foreign_level", book, "bids", [PriceLevel([(order(270), {})])])
                refusal("book_callback", book, "execute_order", lambda item: None)
                refusal("strategy_callback", kernel.agents[1], "act", lambda: None)
                refusal("kernel_callback", kernel, "initialize", lambda: None)
                refusal("oracle_callback", kernel.oracle, "observe_price", lambda *args: 0)
                refusal("latency_callback", kernel.agent_latency_model, "get_latency", lambda *args: 0)
                saved = kernel.agents[1].orders
                bad_order = order(271)
                bad_order.quantity = object()
                refusal("raw_order_callback_scalar", kernel.agents[1], "orders", {271: bad_order})
                check("preinitialize_no_agent_kernel_link", all(getattr(agent, "kernel", None) is None for agent in kernel.agents))
                check("preinitialize_no_message_started", kernel.messages.queue == [])
            finally:
                abides.Kernel = previous_kernel
        check("admission_config_Order_counter_residue", Order._order_id_counter == before_config_order_counter)
        check("Order_counter_residue", Order._order_id_counter == original_order_counter)
    except Exception as error:
        failures.append({"type": type(error).__name__, "message": str(error), "last_passed": checks[-1] if checks else None})
    finally:
        Order._order_id_counter = original_order_counter
        Message._Message__message_id_counter = original_message_counter
    result = {"schema": "t3-native-book-owner-finite-v1", "candidate": "native_book_owner_v1",
              "all_passed": not failures, "checks": len(checks), "check_names": checks,
              "cases": receipts, "failures": failures, "native": native_receipt(),
              "control_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "market_run": False, "timing_claim": False, "rankable": False}
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"all_passed": result["all_passed"], "checks": len(checks), "cases": len(receipts), "failures": failures}))
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
