#!/usr/bin/env python3
"""Run the pinned ABIDES engine; public reference material is never loaded here."""
import time

ENTRY_STARTED = time.perf_counter()

from pathlib import Path as EntryPath
import sys as entry_sys
ENTRY_DIRECTORY = EntryPath(__file__).resolve().parent
entry_sys.path.insert(0, str(ENTRY_DIRECTORY / "runtime"))
from bootstrap import activate
activate()

import argparse
import json
from pathlib import Path
import resource
import sys

from abides_core import abides
from abides_core.kernel import Kernel
from abides_fork.config import build_config
from abides_fork.simulate import reset_abides_counters
from abides_fork.trace import extract_trace, extract_message_trace
from contracts import sha256, validate_scenario, validate_frames
from installed import enabled, book_owner, authenticate, ensure_native_admission, collect_proof, quiet_summary_writer


def simulate(config_path, out_path, mode="optimized", started=None):
    t0 = time.perf_counter() if started is None else started
    scenario = json.loads(Path(config_path).read_text())
    validate_scenario(scenario)
    reset_abides_counters()
    with book_owner(scenario, mode == "optimized"):
        config = build_config(scenario)
        if mode == "optimized":
            from admission import admit_config
            admit_config(config)
        summary_writer = Kernel.write_summary_log
        Kernel.write_summary_log = quiet_summary_writer
        try:
            with enabled(mode == "optimized") as message_extractor:
                end_state = abides.run(config)
        finally:
            Kernel.write_summary_log = summary_writer
    trace = extract_trace(end_state)
    messages = message_extractor(end_state)
    validate_frames(trace, messages)
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    trace.to_parquet(out, compression="snappy", index=False)
    messages.to_parquet(out.parent / "message_trace.parquet", compression="snappy", index=False)
    trace_digest = sha256(out)
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    wall = time.perf_counter() - t0
    events = {"scenario_id": str(scenario["scenario_id"]), "seed": int(scenario["seed"]),
              "n_events": len(trace), "wall_clock_sec": wall,
              "events_per_sec": len(trace) / wall, "trace_sha256": trace_digest,
              "peak_memory_bytes": int(rss) if sys.platform == "darwin" else int(rss) * 1024,
              "gpu_seconds": 0.0}
    (out.parent / "events.json").write_text(json.dumps(events, indent=2) + "\n")
    # Development witness is serialized after the per-scenario wall timestamp
    # for both arms. It is stdout evidence for an external host sink and never
    # becomes a file in the official output tree. The encompassing batch clock
    # includes this per-member serialization/output cost in both arms.
    proof = collect_proof(end_state, native=mode == "optimized")
    print("T3_NATIVE_BOOK_PROOF=" + json.dumps(proof, sort_keys=True, separators=(",", ":")))
    return events


def simulate_batch(batch_dir, out_dir, mode="optimized", started=None):
    t0 = time.perf_counter() if started is None else started
    paths = sorted(p for p in Path(batch_dir).glob("*.json") if not p.name.startswith("._"))
    if not paths:
        raise ValueError("batch-dir contains no scenario JSON files")
    per_scenario = []
    for path in paths:
        events = simulate(path, Path(out_dir) / path.stem / "trace.parquet", mode)
        per_scenario.append({"sub": path.stem, "n_events": events["n_events"],
                             "scenario_id": events["scenario_id"], "seed": events["seed"]})
    wall = time.perf_counter() - t0
    total = sum(row["n_events"] for row in per_scenario)
    result = {"n_scenarios": len(per_scenario), "total_events": total,
              "wall_clock_sec": wall, "events_per_sec": total / wall,
              "per_scenario": per_scenario}
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    (Path(out_dir) / "batch_events.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main():
    authenticate()
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="verb", required=True)
    single = sub.add_parser("simulate")
    single.add_argument("--config", required=True)
    single.add_argument("--out", required=True)
    batch = sub.add_parser("simulate-batch")
    batch.add_argument("--batch-dir", required=True)
    batch.add_argument("--out-dir", required=True)
    for command in (single, batch):
        command.add_argument("--mode", choices=["baseline", "optimized"], default="optimized")
    args = parser.parse_args()
    if args.mode == "optimized":
        ensure_native_admission()
    if args.verb == "simulate":
        result = simulate(args.config, args.out, args.mode, started=ENTRY_STARTED)
    else:
        result = simulate_batch(args.batch_dir, args.out_dir, args.mode, started=ENTRY_STARTED)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
