#!/usr/bin/env python3
"""Copy authenticated original runtime bytes for isolated book proof preparation."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output = HERE / "runtime"
    if output.exists():
        raise ValueError("snapshot exists; preserve the prior snapshot")
    manifest_path = ROOT / "RUNTIME_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    files = []
    for row in manifest["files"]:
        relative = str(Path(row["path"]).relative_to("runtime"))
        data = (ROOT / "runtime" / relative).read_bytes()
        if len(data) != row["bytes"] or sha(data) != row["sha256"]:
            raise ValueError("frozen runtime differs: " + relative)
        files.append((relative, data, row))
    for relative, data, row in files:
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        if destination.name in ("simulate", "simulate-batch", "agent.py"):
            destination.chmod(0o755)
    pins = {"schema": "t3-native-book-owner-runtime-pins-v1",
            "frozen_manifest_sha256": sha(manifest_path.read_bytes()),
            "runtime_files": [{"path": relative, "bytes": len(data), "sha256": sha(data)} for relative, data, _ in files],
            "python_sources": {relative: sha(data) for relative, data, _ in files if relative.endswith(".py")},
            "original_runtime_unchanged": True, "native_execution": False, "market_run": False}
    (HERE / "PINNED_RUNTIME.json").write_text(json.dumps(pins, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"source_snapshot_prepared": True, "files": len(files), "native_execution": False}))


if __name__ == "__main__":
    main()
