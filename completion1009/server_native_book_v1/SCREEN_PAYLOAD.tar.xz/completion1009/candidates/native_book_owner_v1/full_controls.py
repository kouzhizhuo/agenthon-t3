#!/usr/bin/env python3
"""Serial finite + four full-market native book controls, with all failures kept."""
import argparse
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys
from provenance import HERE, candidate_sources, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    output = Path(args.out).resolve()
    if output.exists():
        raise ValueError("control evidence exists; preserve the previous attempt")
    output.mkdir(parents=True)
    before = candidate_sources()
    result = {"schema": "t3-native-book-owner-all-controls-v1", "candidate": "native_book_owner_v1",
              "all_passed": False, "cases": [], "failures": [], "candidate_sources": before,
              "timing_claim": False, "rankable": False, "official_gate": False}
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    def launch(script, arguments, log):
        with log.open("w") as stream:
            completed = subprocess.run([sys.executable, str(HERE / script), *arguments],
                cwd=HERE, env=environment, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
        if completed.returncode:
            raise ValueError("control failed; retained log: " + str(log))
    try:
        launch("controls.py", ["--receipt", args.receipt, "--out", str(output / "FINITE_RESULT.json")], output / "finite.log")
        finite = json.loads((output / "FINITE_RESULT.json").read_text())
        if finite.get("all_passed") is not True or not finite.get("native", {}).get("extension_sha256"):
            raise ValueError("finite controls lack actual native PASS/provenance")
        for arm in ("canonical", "native"):
            directory = output / arm
            directory.mkdir()
            launch("semantic_worker.py", ["--receipt", args.receipt, "--arm", arm, "--out", str(directory)], directory / "run.log")
        # These pickle files are created by our immediately preceding isolated
        # workers, never fetched from a public artifact or untrusted source.
        values = [pickle.loads((output / arm / "VALUES.pkl").read_bytes()) for arm in ("canonical", "native")]
        import pandas as pd
        if len(values[0]) != 4 or len(values[1]) != 4:
            raise ValueError("full-market roster is incomplete")
        for original, native in zip(*values):
            if original["seed"] != native["seed"] or original["stats"]["ttl_messages"] != native["stats"]["ttl_messages"]:
                raise ValueError("full horizon/seed/pop total differs")
            for a, b in zip(original["frames"], native["frames"]):
                pd.testing.assert_frame_equal(a, b, check_exact=True, check_dtype=True, rtol=0, atol=0)
            for label, a, b in zip(("Parquet", "complete business graph/aliases", "all RNG", "IDs", "warnings/stdout"),
                                   original["payload"], native["payload"]):
                if a != b:
                    raise ValueError(label + " differs for seed " + str(original["seed"]))
            witness = native["stats"]["native_witness"]
            if (witness["active"] is not True
                    or witness["native"]["extension_sha256"] != finite["native"]["extension_sha256"]
                    or any(type(counts) is not dict or list(counts) != ["match", "cancel", "insert", "read"]
                           or any(type(v) is not int or v <= 0 for v in counts.values())
                           for counts in witness["book_counts"].values())):
                raise ValueError("actual native book ownership witness differs")
            result["cases"].append({"seed": original["seed"], "passed": True, **native["stats"]})
        if candidate_sources() != before:
            raise ValueError("candidate sources changed during controls")
        result.update(all_passed=True, finite_cases=len(finite["cases"]), finite_checks=finite["checks"],
                      sources_unchanged=True, native=finite["native"])
    except Exception as error:
        result["failures"].append({"type": type(error).__name__, "message": str(error)})
    result["controller_sha256"] = sha(__file__)
    (output / "RESULT.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"all_passed": result["all_passed"], "markets": len(result["cases"]), "failures": result["failures"]}))
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
