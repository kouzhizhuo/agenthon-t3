"""Stdlib-only finite Noise packaging; exact candidate/wrapper PASS must seal."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import (CANDIDATE_RECEIPT, CANDIDATE_SHA256, CANDIDATE_FILE_COUNT, WRAPPER_FILE_COUNT,
    RUNTIME_RECEIPT, RUNTIME_SHA256, CALLS_PER_ARM, WRAPPER_RECEIPT, inventory, sha, verify_candidate, verify_payload, verify_rows, write)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CANDIDATE = ROOT / "candidates/noise_owned_episode_control_v1"
RUNTIME = ROOT / "candidates/lean_production_native_projection_v1/runtime"
RUNTIME_PINS = RUNTIME.parent / RUNTIME_RECEIPT


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--candidate-review", type=Path, required=True)
    parser.add_argument("--candidate-review-sha256", required=True)
    parser.add_argument("--wrapper-review", type=Path, required=True)
    parser.add_argument("--wrapper-review-sha256", required=True)
    args = parser.parse_args()
    if args.out.exists() or args.archive.exists():
        raise ValueError("fresh finite Noise source payload/archive required")
    wrapper_path = HERE / WRAPPER_RECEIPT
    wrapper = json.loads(wrapper_path.read_bytes())
    if (wrapper.get("source_frozen") is not True or wrapper.get("candidate_source_receipt_sha256") != CANDIDATE_SHA256
            or wrapper.get("runtime_source_receipt_sha256") != RUNTIME_SHA256 or len(wrapper["files"]) != WRAPPER_FILE_COUNT):
        raise ValueError("exact frozen ten-file wrapper receipt required")
    verify_rows(HERE, wrapper["files"])
    reviewed = json.loads(args.wrapper_review.read_bytes())
    if (sha(args.wrapper_review) != args.wrapper_review_sha256 or reviewed.get("status") != "PASS_SOURCE_ONLY"
            or reviewed.get("unresolved_source_blockers") != [] or reviewed.get("wrapper_source_receipt_sha256") != sha(wrapper_path)
            or reviewed.get("candidate_source_receipt_sha256") != CANDIDATE_SHA256
            or reviewed.get("reviewed_wrapper_files") != wrapper["files"]):
        raise ValueError("independent exact wrapper source PASS required to seal")
    candidate = verify_candidate(CANDIDATE)
    independent = json.loads(args.candidate_review.read_bytes())
    if (sha(args.candidate_review) != args.candidate_review_sha256 or independent.get("status") != "PASS_SOURCE_ONLY"
            or independent.get("unresolved_source_blockers") != [] or independent.get("reviewed_source_receipt_sha256") != CANDIDATE_SHA256
            or independent.get("reviewed_files") != candidate["files"]):
        raise ValueError("independent exact candidate source PASS required")
    if sha(RUNTIME_PINS) != RUNTIME_SHA256:
        raise ValueError("exact original64 runtime receipt required")
    runtime = json.loads(RUNTIME_PINS.read_bytes())
    verify_rows(RUNTIME, runtime["files"])
    if inventory(RUNTIME) != sorted(runtime["files"], key=lambda row: row["path"]):
        raise ValueError("unchanged original64 runtime source required")
    copies = [(CANDIDATE / row["path"], "candidate/" + row["path"]) for row in candidate["files"]]
    copies.append((CANDIDATE / CANDIDATE_RECEIPT, "candidate/" + CANDIDATE_RECEIPT))
    copies += [(HERE / row["path"], "control/" + row["path"]) for row in wrapper["files"]]
    copies += [(RUNTIME / row["path"], "runtime/source/" + row["path"]) for row in runtime["files"]]
    copies += [(RUNTIME_PINS, "runtime/" + RUNTIME_RECEIPT),
        (args.candidate_review, "source_review/INDEPENDENT_CANDIDATE_REVIEW.json"),
        (wrapper_path, "source_review/" + WRAPPER_RECEIPT),
        (args.wrapper_review, "source_review/INDEPENDENT_WRAPPER_REVIEW.json")]
    args.out.mkdir(parents=True)
    for source, relative in copies:
        target = args.out / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        if target.suffix == ".py":
            ast.parse(target.read_bytes())
            compile(target.read_bytes(), str(target), "exec", dont_inherit=True)
    plan = {"schema": "t3-noise-owned-episode-finite-controls-plan-v1", "frozen_source_inputs": True,
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "candidate_sources": CANDIDATE_FILE_COUNT,
        "runtime_source_receipt_sha256": RUNTIME_SHA256, "original_runtime_sources": 64,
        "wrapper_source_receipt_sha256": sha(wrapper_path), "independent_wrapper_review_sha256": args.wrapper_review_sha256,
        "independent_candidate_review_sha256": args.candidate_review_sha256,
        "native_builds": 1, "expression_cases": 16, "calls_per_arm": CALLS_PER_ARM,
        "arms": ["original", "new", "new-repeat"], "runner_public_boundaries": 7,
        "all624_words_initial_before_after_each_call": True, "all624_words_after_each_expression": True,
        "result_types_bits_errors_warnings": True, "public_replacement_adapter_only": True,
        "market_controls": False, "performance_controls": False, "arena_integration": False, "runtime_authentication_exercised": False,
        "minimum_host_free_bytes": 4 * 1024**3, "controls_fsize_limit_bytes": 1024**3,
        "build_resources": {"cpus": 1, "memory_bytes": 8 * 1024**3, "tmp_bytes": 1024**3},
        "correctness_resources": {"cpus": 4, "memory_bytes": 16 * 1024**3, "tmp_bytes": 64 * 1024**2, "tmp_noexec": True},
        "source_only": True, "runtime_pass": False, "rankable": False, "official_submission": False, "speed_claim": False}
    write(args.out / "CONTROL_PLAN.json", plan)
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-noise-owned-episode-finite-payload-manifest-v1", "files": inventory(args.out)})
    verify_payload(args.out)
    with tarfile.open(args.archive, "w:xz") as archive:
        for row in inventory(args.out):
            data = (args.out / row["path"]).read_bytes()
            item = tarfile.TarInfo(row["path"])
            item.size = len(data); item.mode = 0o644; item.mtime = 0; item.uid = item.gid = 0; item.uname = item.gname = ""
            archive.addfile(item, io.BytesIO(data))
    write(args.archive.with_suffix(".receipt.json"), {"source_only": True, "archive_sha256": sha(args.archive),
        "archive_bytes": args.archive.stat().st_size, "payload_files": len(inventory(args.out)),
        "candidate_source_receipt_sha256": CANDIDATE_SHA256, "runtime_executed": False})
    print(json.dumps({"archive": str(args.archive), "bytes": args.archive.stat().st_size, "sha256": sha(args.archive)}))


if __name__ == "__main__":
    main()
