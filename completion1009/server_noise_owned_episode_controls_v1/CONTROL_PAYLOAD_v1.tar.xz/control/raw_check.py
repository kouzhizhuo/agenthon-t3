"""Stdlib recomputation of retained Noise expressions/full state; no candidate import."""
import argparse
import json
import math
from pathlib import Path
import struct
from common import BOUNDARY_MODES, CASE_SPECS, CALLS_PER_ARM, CANDIDATE_SHA256, sha, write


def require(ok, message):
    if not ok:
        raise ValueError(message)


def scalar(value):
    if type(value) is float:
        return {"type": "builtins.float", "bits": struct.pack("!d", value).hex()}
    if type(value) is int:
        return {"type": "builtins.int", "value": str(value)}
    if type(value) is bool:
        return {"type": "builtins.bool", "value": value}
    if type(value) is tuple:
        return {"type": "builtins.tuple", "items": [scalar(item) for item in value]}
    if value is None:
        return {"type": "builtins.NoneType"}
    raise ValueError("finite checker scalar required")


def scalar_shape(value):
    require(type(value) is dict and type(value.get("type")) is str, "retained scalar absent")
    kind = value["type"]
    if kind == "builtins.float":
        require(set(value) == {"type", "bits"} and type(value["bits"]) is str and len(value["bits"]) == 16,
                "retained float bits absent")
        struct.unpack("!d", bytes.fromhex(value["bits"]))
    elif kind == "builtins.int":
        require(set(value) == {"type", "value"} and type(value["value"]) is str
                and str(int(value["value"])) == value["value"], "retained integer absent")
    elif kind == "builtins.bool":
        require(set(value) == {"type", "value"} and type(value["value"]) is bool, "retained bool absent")
    elif kind == "builtins.tuple":
        require(set(value) == {"type", "items"} and type(value["items"]) is list, "retained tuple absent")
        for item in value["items"]:
            scalar_shape(item)
    elif kind == "builtins.NoneType":
        require(set(value) == {"type"}, "retained None differs")
    else:
        raise ValueError("unretained scalar type")


def outcome_shape(value):
    require(type(value) is dict and type(value.get("returned")) is bool and type(value.get("warnings")) is list,
            "result/error/warnings absent")
    require(all(type(row) is dict and set(row) == {"type", "message"}
                and all(type(row[key]) is str for key in row) for row in value["warnings"]), "warning roster differs")
    if value["returned"]:
        require(set(value) == {"returned", "result", "warnings"}, "return roster differs")
        scalar_shape(value["result"])
    else:
        require(set(value) == {"returned", "type", "message", "warnings"}
                and type(value["type"]) is str and type(value["message"]) is str, "error roster differs")


def state_shape(value):
    require(type(value) is dict and set(value) == {"kind", "words_le_hex", "position", "has_gauss", "gauss_bits"}
            and value["kind"] == "MT19937" and type(value["position"]) is int and 0 <= value["position"] <= 624
            and type(value["has_gauss"]) is int and value["has_gauss"] in (0, 1)
            and type(value["words_le_hex"]) is str and len(value["words_le_hex"]) == 4992
            and type(value["gauss_bits"]) is str and len(value["gauss_bits"]) == 16, "complete624 state absent")
    struct.unpack("<624I", bytes.fromhex(value["words_le_hex"]))
    require(math.isfinite(struct.unpack("!d", bytes.fromhex(value["gauss_bits"]))[0]), "nonfinite Gaussian cache")


def same_states(values, count=3):
    require(type(values) is list and len(values) == count, "state arm roster differs")
    for value in values:
        state_shape(value)
    require(all(value == values[0] for value in values), "full624 state differs")


def same_outcomes(values, count=3):
    require(type(values) is list and len(values) == count, "outcome arm roster differs")
    for value in values:
        outcome_shape(value)
    require(all(value == values[0] for value in values), "result/error/warnings differ")


def diagnostics(value):
    keys = {"owned", "handoffs", "normal_calls", "randint_calls", "words_consumed", "twists",
            "normal_rejections", "integer_rejections", "export_failures"}
    require(type(value) is dict and set(value) == keys and value["owned"] is False and value["handoffs"] == 1
            and value["export_failures"] == [] and all(type(value[key]) is int and value[key] >= 0
                for key in keys - {"owned", "export_failures"}), "terminal owner diagnostics differ")


def check_controls(value, build):
    build = Path(build)
    receipt = build / "BUILD_RECEIPT.json"
    require(value.get("schema") == "t3-noise-owned-fused-expression-controls-v1" and value.get("all_passed") is True
            and "failure" not in value and value.get("source_receipt_sha256") == CANDIDATE_SHA256
            and value.get("build_receipt") == {"bytes": receipt.stat().st_size, "sha256": sha(receipt)}
            and value.get("arms") == ["original", "new", "new-repeat"]
            and all(value.get(key) is False for key in ("market_executed", "rankable", "speed_claim")),
            "raw source/build/scope binding differs")
    rows = value.get("cases")
    require(type(rows) is list and len(rows) == len(CASE_SPECS), "fixed16 expression cases absent")
    retained, states, outcomes, traces, normal_calls, randint_calls, words, twists, rejections = (0,) * 9
    for row, (name, mean, scale, offset, patch, count) in zip(rows, CASE_SPECS):
        require(set(row) == {"name", "mean", "scale", "offset", "state_patch", "calls", "initial_actual_states",
                "final_actual_exported_states", "diagnostics"} and row["name"] == name
                and row["mean"] == scalar(mean) and row["scale"] == scalar(scale) and row["offset"] == scalar(offset)
                and row["state_patch"] == {key: scalar(item) for key, item in patch.items()}, "case source inputs differ")
        same_states(row["initial_actual_states"]); states += 3
        initial = row["initial_actual_states"][0]
        for key in ("position", "has_gauss"):
            if key in patch:
                require(initial[key] == patch[key], "initial state patch differs")
        if "gauss" in patch:
            require(initial["gauss_bits"] == struct.pack("!d", patch["gauss"]).hex(), "initial cache bits differ")
        calls = row["calls"]
        require(type(calls) is list and len(calls) == count, "complete finite calls absent")
        previous = row["initial_actual_states"]
        expected_names = ([] if name in ("negative_std", "negativezero_std") else
            ["normal"] if name == "overflow_before_integer_draws" else
            ["normal", "size", "direction"] if name in ("invalid_offset_after_prior_draws", "high_offset_error_after_prior_draws") else
            ["normal", "size", "direction", "offset"])
        for ordinal, call in enumerate(calls):
            require(set(call) == {"ordinal", "outcomes", "before_states", "boundary_traces", "after_states"}
                    and type(call["ordinal"]) is int and call["ordinal"] == ordinal, "call ordinal/roster differs")
            same_states(call["before_states"]); same_states(call["after_states"]); same_outcomes(call["outcomes"])
            require(call["before_states"] == previous, "full624 state continuity differs")
            previous = call["after_states"]; states += 6; outcomes += 3
            recorded = call["boundary_traces"]
            require(type(recorded) is list and len(recorded) == 3 and recorded[0] == recorded[1] == recorded[2],
                    "full expression traces differ")
            for arm in recorded:
                require(type(arm) is list and [item.get("boundary") for item in arm] == expected_names,
                        "normal/Python/direction/offset evaluation order differs")
                for item in arm:
                    require(set(item) == {"boundary", "value", "state"}, "trace roster differs")
                    scalar_shape(item["value"]); state_shape(item["state"]); states += 1; traces += 1
            outcome = call["outcomes"][0]
            require(outcome["returned"] is (len(expected_names) == 4), "success/error call boundary differs")
            if expected_names:
                require(recorded[0][-1]["state"] == call["after_states"][0], "last expression consumed state differs")
            else:
                require(call["before_states"] == call["after_states"], "negative scale consumed RNG before validation")
            if len(expected_names) >= 2:
                normal = struct.unpack("!d", bytes.fromhex(recorded[0][0]["value"]["bits"]))[0]
                require(recorded[0][0]["value"]["type"] == "builtins.float"
                        and recorded[0][1]["value"] == scalar(int(max(1, round(normal))))
                        and recorded[0][0]["state"] == recorded[0][1]["state"], "Python round/max/int differs")
            if len(expected_names) >= 3:
                require(recorded[0][2]["value"]["type"] == "builtins.bool", "direction bool differs")
            if len(expected_names) == 4:
                delta = int(recorded[0][3]["value"]["value"])
                require(recorded[0][3]["value"]["type"] == "builtins.int" and 0 <= delta <= offset
                        and outcome["result"] == {"type": "builtins.tuple", "items": [item["value"] for item in recorded[0][1:]]},
                        "returned size/direction/offset tuple differs")
                if offset == 0:
                    require(recorded[0][2]["state"] == recorded[0][3]["state"], "zero width consumed integer word")
        same_states(row["final_actual_exported_states"]); states += 3
        require(row["final_actual_exported_states"] == previous, "actual terminal state differs from consumed state")
        require(type(row["diagnostics"]) is list and len(row["diagnostics"]) == 2
                and row["diagnostics"][0] == row["diagnostics"][1], "repeat native diagnostics differ")
        diag = row["diagnostics"][0]; diagnostics(diag)
        expected_normal = 0 if name in ("negative_std", "negativezero_std") else count
        expected_integer = 0 if name in ("negative_std", "negativezero_std", "overflow_before_integer_draws") else (
            1 if len(expected_names) == 3 else 2 * count)
        require(diag["normal_calls"] == expected_normal and diag["randint_calls"] == expected_integer,
                "native call order/count differs")
        normal_calls += diag["normal_calls"]; randint_calls += diag["randint_calls"]
        words += diag["words_consumed"]; twists += diag["twists"]
        rejections += diag["normal_rejections"] + diag["integer_rejections"]; retained += count
    require(retained == CALLS_PER_ARM and words > 0 and twists > 0 and rejections > 0,
            "complete actual native branch coverage absent")
    boundaries = value.get("boundary_controls")
    require(type(boundaries) is list and [row.get("mode") for row in boundaries] == list(BOUNDARY_MODES),
            "seven runner/public boundaries absent")
    for row in boundaries:
        require(set(row) == {"mode", "outcome", "consumed_before_export", "actual_public_exported_state",
                "diagnostics", "cleanup_failures", "extra"}, "runner boundary roster differs")
        state_shape(row["consumed_before_export"]); state_shape(row["actual_public_exported_state"]); states += 2
        require(row["consumed_before_export"] == row["actual_public_exported_state"] and row["cleanup_failures"] == [],
                "runner terminal state/export failure differs")
        diagnostics(row["diagnostics"]); outcome_shape(row["outcome"]); outcomes += 1
        require(row["diagnostics"]["normal_calls"] == 1 and row["diagnostics"]["randint_calls"] == 2,
                "runner native draw unexercised")
        mode = row["mode"]; outcome = row["outcome"]; extra = row["extra"]
        if mode == "BaseException":
            require(outcome == {"returned": False, "type": "__main__.FiniteAbort",
                    "message": "finite actor abort after draws", "warnings": []}, "active runner error differs")
        else:
            require(outcome == {"returned": True, "result": scalar(None if mode == "early-return" else 3), "warnings": []},
                    "runner return/warnings differ")
        if mode == "public-snapshot":
            require(set(extra) == {"actual_public_snapshot_state"} and extra["actual_public_snapshot_state"] == row["consumed_before_export"],
                    "actual public snapshot differs")
            state_shape(extra["actual_public_snapshot_state"]); states += 1
        elif mode == "public-replacement":
            require(set(extra) == {"standalone_setter_boundary_adapter_only", "former_owner_lookup_retired", "terminal_entry_retained",
                    "selected_original_after_replacement", "continuation_outcomes", "actual_replacement_public_states"}
                    and all(extra[key] is True for key in ("standalone_setter_boundary_adapter_only", "former_owner_lookup_retired",
                        "terminal_entry_retained", "selected_original_after_replacement")), "replacement boundary witnesses absent")
            same_outcomes(extra["continuation_outcomes"], 2); same_states(extra["actual_replacement_public_states"], 2)
            require(extra["continuation_outcomes"][0]["returned"] is True, "replacement original continuation failed")
            outcomes += 2; states += 2
        else:
            require(extra == {}, "unexpected runner boundary evidence")
    return {"all_passed": True, "expression_cases": len(rows), "calls_per_arm": retained, "runner_public_boundaries": len(boundaries),
        "full624_state_records_checked": states, "outcome_records_checked": outcomes, "expression_trace_records_checked": traces,
        "native_normal_calls_per_new_arm": normal_calls, "native_randint_calls_per_new_arm": randint_calls,
        "words_per_new_arm": words, "twists_per_new_arm": twists, "rejections_per_new_arm": rejections,
        "source_receipt_sha256": CANDIDATE_SHA256, "build_receipt_sha256": sha(receipt),
        "market_executed": False, "speed_claim": False, "rankable": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh independent raw-check result required")
    result = check_controls(json.loads(args.raw.read_bytes()), args.build)
    result["raw_file"] = {"bytes": args.raw.stat().st_size, "sha256": sha(args.raw)}
    write(args.out, result)


if __name__ == "__main__":
    main()
