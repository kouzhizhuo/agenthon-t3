"""Future exact-source finite build. No native or participant runtime imported."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def pin(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--review", type=Path, required=True)
    parser.add_argument("--review-sha256", required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != "linux" or platform.machine() != "x86_64" or list(sys.version_info[:3]) != [3, 11, 17] or args.receipt.exists():
        raise ValueError("fresh pinned Linux amd64 CPython3.11.17 build required")
    source_path = HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"
    source = json.loads(source_path.read_bytes())
    review = json.loads(args.review.read_bytes())
    if (pin(args.review)["sha256"] != args.review_sha256 or review.get("status") != "PASS_SOURCE_ONLY"
            or review.get("unresolved_source_blockers") != []
            or review.get("reviewed_source_receipt_sha256") != pin(source_path)["sha256"]
            or review.get("reviewed_files") != source["files"]):
        raise ValueError("independent exact full Noise source PASS required")
    for row in source["files"]:
        if pin(HERE / row["path"]) != {k: row[k] for k in ("bytes", "sha256")}:
            raise ValueError("frozen Noise source differs")
    from importlib.metadata import version
    if {name: version(name) for name in ("Cython", "numpy")} != {"Cython": "3.1.3", "numpy": "1.26.4"}:
        raise ValueError("pinned scalar build dependencies required")
    ambient = {name: os.environ.get(name, "") for name in ("CFLAGS", "CPPFLAGS", "LDFLAGS")}
    unsafe = ("-ffast-math", "-Ofast", "-funsafe-math-optimizations", "-ffinite-math-only",
              "-freciprocal-math", "-fassociative-math", "-ffp-contract=fast")
    if any(flag in value for value in ambient.values() for flag in unsafe):
        raise ValueError("unsafe ambient scalar compiler flags")
    if list(HERE.glob("_noise_owned*.so")) or (HERE / "noise_owner.c").exists():
        raise ValueError("fresh unbuilt Noise checkout required")
    command = [sys.executable, "-B", str(HERE / "setup.py"), "build_ext", "--inplace"]
    log = args.receipt.with_suffix(".build.log")
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("xb") as stream:
        actual = subprocess.run(command, cwd=HERE, stdout=stream, stderr=subprocess.STDOUT,
            timeout=600, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    extensions = list(HERE.glob("_noise_owned*.so"))
    if actual.returncode or len(extensions) != 1:
        raise ValueError("actual finite Noise extension build failed")
    for row in source["files"]:
        if pin(HERE / row["path"]) != {k: row[k] for k in ("bytes", "sha256")}:
            raise ValueError("source changed during actual build")
    report = {"schema": "t3-noise-owned-finite-actual-build-v1", "source_receipt_sha256": pin(source_path)["sha256"],
        "independent_review_sha256": args.review_sha256, "python": sys.version,
        "extension": {"path": extensions[0].name, **pin(extensions[0])}, "generated_C": pin(HERE / "noise_owner.c"),
        "command": command, "log": pin(log), "build_succeeded": True,
        "ambient_flags": ambient,
        "participant_imported": False, "RNG_drawn": False, "market_executed": False, "speed_claim": False}
    args.receipt.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
