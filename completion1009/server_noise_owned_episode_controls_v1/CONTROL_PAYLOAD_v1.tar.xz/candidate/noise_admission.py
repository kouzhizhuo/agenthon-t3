"""One cold authentication/census before first controlled Noise RNG draw."""
import ast
import builtins
import hashlib
import importlib
import json
import math
from pathlib import Path
import types
from episode_boundary import NoiseEpisodeBoundary

HERE = Path(__file__).resolve().parent


def pin(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def authenticate_runtime(runtime):
    runtime = Path(runtime).resolve()
    receipt = json.loads((HERE / "RUNTIME_SOURCE_PINS_v1.json").read_bytes())
    for row in receipt["files"]:
        name = Path(row["path"])
        if name.is_absolute() or any(x in ("..", "__pycache__") or x.startswith("._") for x in name.parts):
            raise ValueError("clean original runtime source path required")
        if pin(runtime / name) != {k: row[k] for k in ("bytes", "sha256")}:
            raise ValueError("original runtime source differs before Noise ownership")
    from observer_domain import authenticate_loaded, _defaults_match
    if not authenticate_loaded():
        raise ValueError("original whole-episode inherited callback/global domain required")
    from abides_fork import agents, config
    from abides_core import agent, kernel
    from abides_markets.agents import trading_agent
    modules = [(agents, "abides_fork/agents.py"), (config, "abides_fork/config.py"),
        (agent, "vendor/abides/abides-core/abides_core/agent.py"),
        (kernel, "vendor/abides/abides-core/abides_core/kernel.py"),
        (trading_agent, "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py")]
    for module, relative in modules:
        if Path(module.__file__).resolve() != runtime / relative:
            raise ValueError("loaded Noise inherited module path differs")
        # Only compile source to inert code objects; never invoke the source body.
        code = compile(Path(module.__file__).read_bytes(), str(Path(module.__file__)), "exec", dont_inherit=True)
        def codes(value):
            result = {(value.co_name, value.co_firstlineno): value}
            for item in value.co_consts:
                if isinstance(item, types.CodeType):
                    result.update(codes(item))
            return result
        expected = codes(code)
        classes = [value for value in vars(module).values() if isinstance(value, type) and value.__module__ == module.__name__]
        selected = [(name, value) for name, value in vars(module).items() if isinstance(value, types.FunctionType) and value.__module__ == module.__name__]
        for cls in classes:
            selected.extend((name, value) for name, value in vars(cls).items() if isinstance(value, types.FunctionType))
        for name, fn in selected:
            if (fn.__globals__ is not vars(module)
                    or fn.__code__ != expected.get((name, fn.__code__.co_firstlineno))):
                raise ValueError("loaded inherited Noise source code/globals differ")
    defaults = {}
    for cls, names in ((agents.NoiseTrader, ("__init__", "act")),
                       (agents.ScheduledAgent, ("__init__", "kernel_starting", "wakeup", "receive_message", "act", "get_wake_frequency"))):
        for name in names:
            if not _defaults_match(vars(cls)[name], agents, cls.__name__, name, defaults):
                raise ValueError("original Noise constructor/callback defaults required")
    if (agents.NoiseTrader.__bases__ != (agents.ScheduledAgent,)
            or agents.ScheduledAgent.__bases__ != (trading_agent.TradingAgent,)):
        raise ValueError("original exact Noise inherited class chain required")
    import numpy as np
    umath = importlib.import_module("numpy.core._multiarray_umath")
    mtrand = importlib.import_module("numpy.random.mtrand")
    if (np.__version__ != "1.26.4" or agents.np is not np or config.np is not np
            or np.random.RandomState is not mtrand.RandomState
            or np.asarray is not umath.asarray or np.uint32 is not umath.dtype("uint32").type
            or np.ndarray is not umath.ndarray or np.dtype is not umath.dtype):
        raise ValueError("exact original NumPy RandomState and public state primitives required")
    for name in ("normal", "randint", "get_state", "set_state"):
        descriptor = vars(mtrand.RandomState).get(name)
        if (type(descriptor) is not types.MethodDescriptorType or descriptor.__objclass__ is not mtrand.RandomState
                or descriptor.__name__ != name):
            raise ValueError("original mtrand C RNG method origin required")
    for module in (agents, config):
        for name in ("round", "max", "int", "bool", "float"):
            value = getattr(builtins, name)
            if name in vars(module) and vars(module)[name] is not value:
                raise ValueError("overridden Noise scalar builtin global")
    if agents.AGENT_REGISTRY.get("NoiseTrader") is not agents.NoiseTrader:
        raise ValueError("original Noise registry identity required")
    return np, agents


def public_state(rng, np):
    state = rng.get_state()
    if (type(state) is not tuple or len(state) != 5 or state[0] != "MT19937"
            or type(state[1]) is not np.ndarray or state[1].dtype != np.dtype("uint32")
            or state[1].shape != (624,) or type(state[2]) is not int or not 0 <= state[2] <= 624
            or type(state[3]) is not int or state[3] not in (0, 1)
            or type(state[4]) is not float or not math.isfinite(state[4])):
        raise ValueError("full original finite public MT19937 state required")
    return (state[0], [int(x) for x in state[1]], state[2], state[3], state[4])


def acquire_initialized(kernel, native, runtime):
    """Called after original initialize, before cold source dictionaries retire."""
    np, agents = authenticate_runtime(runtime)
    roster = kernel.agents
    if type(roster) is not list or kernel.gym_agents or kernel.custom_state:
        raise ValueError("controlled original CLI roster without external actor callbacks required")
    candidate = [actor for actor in roster if type(actor) is agents.NoiseTrader]
    blocked_rngs = [actor.random_state for actor in roster if type(actor) is not agents.NoiseTrader]
    blocked_rngs += [kernel.random_state, np.random.mtrand._rand]
    if kernel.agent_latency_model is not None and hasattr(kernel.agent_latency_model, "random_state"):
        blocked_rngs.append(kernel.agent_latency_model.random_state)
    oracle = kernel.oracle
    if oracle is not None:
        symbols = oracle.symbols
        if type(symbols) is not dict or any(type(value) is not dict for value in symbols.values()):
            raise ValueError("source-defined original oracle symbol RNG census required")
        blocked_rngs.extend(value["random_state"] for value in symbols.values())
    counts = {}
    for actor in candidate:
        counts[id(actor.random_state)] = counts.get(id(actor.random_state), 0) + 1
    entries, declined = [], []
    try:
        for actor in candidate:
            rng = actor.random_state
            if (type(rng) is not np.random.RandomState or counts[id(rng)] != 1
                    or any(rng is other for other in blocked_rngs)
                    or type(actor.order_size_mean) is not float or not math.isfinite(actor.order_size_mean)
                    or type(actor.order_size_std) is not float or not math.isfinite(actor.order_size_std)
                    or type(actor.price_offset_ticks) is not int):
                declined.append(actor.id)
                continue
            # Unsupported/invalid finite scalars may hand off at the original
            # call boundary; acquisition itself never draws or changes identity.
            owner = native.NoiseRNGOwner(rng, public_state(rng, np), rng.normal, rng.randint,
                rng.get_state, rng.set_state, np.asarray, np.uint32)
            entries.append((actor, owner, rng))
        boundary = NoiseEpisodeBoundary(entries)
    except BaseException as acquisition_error:
        cleanup_failures = []
        for actor, owner, rng in entries:
            try:
                owner.export_to_original()
            except BaseException as cleanup_error:
                cleanup_failures.append({"actor_id": id(actor), "rng_id": id(rng),
                    "type": type(cleanup_error).__name__, "message": str(cleanup_error)})
        # Record cleanup evidence without replacing the active acquisition
        # failure and attempt every acquired owner. This cold error path never
        # invokes a participant callback or retries acquisition/draws.
        try:
            acquisition_error.noise_ownership_cleanup_failures = cleanup_failures
        except BaseException:
            pass
        raise
    boundary.declined_actor_ids = tuple(declined)
    return boundary
