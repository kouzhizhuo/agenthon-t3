# cython: language_level=3, annotation_typing=False, infer_types=False
"""Finite controlled Noise actor RNG; episode admission occurs before construction."""
from libc.stdint cimport uint32_t, uint64_t
from libc.string cimport memset
from libc.math cimport isfinite

cdef extern from "owned_legacy.h":
    ctypedef struct t3_owned_state:
        uint32_t key[624]
        int pos
        int has_gauss
        double gauss
        int wide_high_first
        uint64_t words_consumed
        uint64_t twists
        uint64_t normal_rejections
        uint64_t integer_rejections
    double t3_legacy_normal(t3_owned_state *, double, double)
    uint64_t t3_default_int64_fill_one(t3_owned_state *, uint64_t, uint64_t)
    int t3_signbit(double)


cdef class NoiseRNGOwner:
    cdef object original_rng, original_normal, original_randint, original_get_state
    cdef object original_set_state, original_asarray, original_uint32
    cdef t3_owned_state state
    cdef bint owned
    cdef unsigned long normal_calls, randint_calls, handoffs
    cdef object export_failures
    cdef object control_trace

    def __init__(self, original_rng, public_tuple, original_normal, original_randint,
                 original_get_state, original_set_state, original_asarray, original_uint32):
        cdef int i
        if (type(public_tuple) is not tuple or len(public_tuple) != 5 or public_tuple[0] != "MT19937"
                or type(public_tuple[1]) is not list or len(public_tuple[1]) != 624
                or type(public_tuple[2]) is not int or not 0 <= public_tuple[2] <= 624
                or type(public_tuple[3]) is not int or public_tuple[3] not in (0, 1)
                or type(public_tuple[4]) is not float or not isfinite(public_tuple[4])):
            raise ValueError("exact full finite public MT19937 state required")
        memset(&self.state, 0, sizeof(t3_owned_state))
        for i in range(624):
            value = public_tuple[1][i]
            if type(value) is not int or not 0 <= value <= 0xffffffff:
                raise ValueError("exact uint32 public key word required")
            self.state.key[i] = value
        self.state.pos, self.state.has_gauss, self.state.gauss = public_tuple[2], public_tuple[3], public_tuple[4]
        self.state.wide_high_first = 1
        self.original_rng = original_rng
        self.original_normal, self.original_randint = original_normal, original_randint
        self.original_get_state, self.original_set_state = original_get_state, original_set_state
        self.original_asarray, self.original_uint32 = original_asarray, original_uint32
        self.export_failures = []
        self.control_trace = []
        self.owned = True

    cdef object _state(self):
        cdef int i
        return ("MT19937", [int(self.state.key[i]) for i in range(624)], int(self.state.pos),
                int(self.state.has_gauss), float(self.state.gauss))

    cdef void _export(self) except *:
        if self.owned:
            value = self._state()
            words = self.original_asarray(value[1], dtype=self.original_uint32)
            self.original_set_state((value[0], words, value[2], value[3], value[4]))
            self.owned = False
            self.handoffs += 1

    cdef object _normal(self, object mean, object scale):
        cdef double location, deviation
        if not self.owned:
            return self.original_normal(mean, scale)
        # No source hash or generic callback guard occurs on this controlled
        # scalar path. Unsupported mutable public inputs hand off at this call.
        if type(mean) is not float or type(scale) is not float:
            self._export()
            return self.original_normal(mean, scale)
        location, deviation = mean, scale
        if not isfinite(location) or not isfinite(deviation):
            self._export()
            return self.original_normal(mean, scale)
        if t3_signbit(deviation):
            # Original NumPy validation occurs before a draw, including -0.0.
            self._export()
            return self.original_normal(mean, scale)
        self.normal_calls += 1
        return float(t3_legacy_normal(&self.state, location, deviation))

    cdef object _randint(self, object high):
        cdef uint64_t width
        if not self.owned:
            return self.original_randint(0, high)
        if type(high) is not int or not 1 <= high <= (1 << 63):
            self._export()
            return self.original_randint(0, high)
        width = high - 1
        self.randint_calls += 1
        return int(t3_default_int64_fill_one(&self.state, 0, width))

    cdef object _draw(self, object mean, object scale, object offset_ticks):
        # Keep each original expression separate. round/max/int may fail after
        # normal; no subsequent integer draw occurs in that case.
        size = int(max(1, round(self._normal(mean, scale))))
        buy = bool(self._randint(2))
        offset = int(self._randint(offset_ticks + 1))
        return (size, buy, offset)

    def draw(self, mean, scale, offset_ticks):
        # Only controlled actor/runner calls may retain private state on return.
        # An exception immediately hands off consumed state without replay.
        try:
            return self._draw(mean, scale, offset_ticks)
        except BaseException:
            try:
                self._export()
            except BaseException as cleanup_error:
                self.export_failures.append({"type": type(cleanup_error).__name__, "message": str(cleanup_error)})
            raise

    def control_draw(self, mean, scale, offset_ticks):
        # Separate finite witness path. Production _draw has no trace writes,
        # snapshots, whole-file hashes or callback guards on the hot path.
        self.control_trace = []
        try:
            normal = self._normal(mean, scale)
            self.control_trace.append(("normal", normal, self.control_private_state()))
            size = int(max(1, round(normal)))
            self.control_trace.append(("size", size, self.control_private_state()))
            buy = bool(self._randint(2))
            self.control_trace.append(("direction", buy, self.control_private_state()))
            offset = int(self._randint(offset_ticks + 1))
            self.control_trace.append(("offset", offset, self.control_private_state()))
            return (size, buy, offset)
        except BaseException:
            try:
                self._export()
            except BaseException as cleanup_error:
                self.export_failures.append({"type": type(cleanup_error).__name__, "message": str(cleanup_error)})
            raise

    def control_trace_rows(self):
        return list(self.control_trace)

    def export_to_original(self):
        self._export()

    def original_identity(self):
        # Public exposure makes stale state visible only after permanent export.
        self._export()
        return self.original_rng

    def snapshot(self):
        self._export()
        return self.original_get_state()

    def control_private_state(self):
        # Finite control-only witness; production integration will keep this
        # private to same-extension C methods and export before public snapshots.
        if self.owned:
            return self._state()
        value = self.original_get_state()
        return (value[0], [int(x) for x in value[1]], value[2], value[3], value[4])

    def diagnostics(self):
        return {"owned": bool(self.owned), "handoffs": int(self.handoffs),
                "normal_calls": int(self.normal_calls), "randint_calls": int(self.randint_calls),
                "words_consumed": int(self.state.words_consumed), "twists": int(self.state.twists),
                "normal_rejections": int(self.state.normal_rejections), "integer_rejections": int(self.state.integer_rejections),
                "export_failures": list(self.export_failures)}
