"""Future finite Linux build; participant/RNG/market bodies are never imported."""
import sys
from setuptools import Extension, setup
from Cython.Build import cythonize

if sys.platform != "linux" or sys.maxsize != (1 << 63) - 1:
    raise RuntimeError("Linux64 build required")
flags = ["-O2", "-std=c99", "-fno-fast-math", "-ffp-contract=off", "-fno-associative-math", "-fno-unsafe-math-optimizations"]
extension = Extension("_noise_owned", ["noise_owner.pyx", "owned_legacy.c"], libraries=["m"], extra_compile_args=flags)
setup(name="t3-noise-owned-episode-finite-control", version="0.0.1", ext_modules=cythonize([extension],
    compiler_directives={"language_level": 3, "boundscheck": True, "wraparound": True,
                        "cdivision": False, "annotation_typing": False, "infer_types": False}))
