"""Future fused-expression and terminal-boundary evidence; no market claimed."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import warnings

HERE = Path(__file__).resolve().parent


def pin(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def require(value, message):
    if not value:
        raise ValueError(message)


def scalar(value):
    if type(value) is float:
        return {"type": "builtins.float", "bits": struct.pack("!d", value).hex()}
    if type(value) is int:
        return {"type": "builtins.int", "value": str(value)}
    if type(value) is bool:
        return {"type": "builtins.bool", "value": value}
    if type(value) is tuple:
        return {"type": "builtins.tuple", "items": [scalar(x) for x in value]}
    if value is None:
        return {"type": "builtins.NoneType"}
    raise ValueError("finite plain scalar witness required")


def state(value):
    return {"kind": value[0], "words_le_hex": struct.pack("<624I", *value[1]).hex(),
        "position": int(value[2]), "has_gauss": int(value[3]), "gauss_bits": struct.pack("!d", value[4]).hex()}


def observed(call):
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter("always")
        try:
            result = {"returned": True, "result": scalar(call())}
        except BaseException as error:
            result = {"returned": False, "type": type(error).__module__ + "." + type(error).__name__, "message": str(error)}
        result["warnings"] = [{"type": w.category.__module__ + "." + w.category.__name__, "message": str(w.message)} for w in seen]
        return result


def trace_rows(rows):
    return [{"boundary": name, "value": scalar(value), "state": state(snapshot)} for name, value, snapshot in rows]


def original_draw(rng, mean, scale, offset, trace):
    normal = rng.normal(mean, scale)
    trace.append(("normal", float(normal), rng.get_state()))
    size = int(max(1, round(normal)))
    trace.append(("size", size, rng.get_state()))
    buy = bool(rng.randint(0, 2))
    trace.append(("direction", buy, rng.get_state()))
    delta = int(rng.randint(0, offset + 1))
    trace.append(("offset", delta, rng.get_state()))
    return size, buy, delta


def cases():
    return [("ordinary", 10.0, 2.0, 5, {}, 700),
        ("rollover622", 10.0, 2.0, 3, {"position": 622}, 200),
        ("rollover623", 10.0, 2.0, 3, {"position": 623}, 200),
        ("rollover624", 10.0, 2.0, 3, {"position": 624}, 200),
        ("pending_positive_zero", 10.0, 2.0, 5, {"has_gauss": 1, "gauss": 0.0}, 20),
        ("pending_negative_zero", 10.0, 2.0, 5, {"has_gauss": 1, "gauss": -0.0}, 20),
        ("pending_nonzero", 10.0, 2.0, 5, {"has_gauss": 1, "gauss": -1.2345}, 20),
        ("zero_std_draws", 10.0, 0.0, 5, {}, 50),
        ("zero_offset_no_integer_word", 10.0, 2.0, 0, {}, 50),
        ("wide_offset", 10.0, 2.0, (1 << 40) + 3, {}, 50),
        ("maximum_offset", 10.0, 2.0, (1 << 63) - 1, {}, 50),
        ("negative_std", 10.0, -1.0, 5, {}, 1),
        ("negativezero_std", 10.0, -0.0, 5, {}, 1),
        ("invalid_offset_after_prior_draws", 10.0, 2.0, -1, {}, 1),
        ("high_offset_error_after_prior_draws", 10.0, 2.0, (1 << 63), {}, 1),
        ("overflow_before_integer_draws", 1e308, 1e308, 5, {"has_gauss": 1, "gauss": 2.0}, 1)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh finite Noise raw evidence required")
    import numpy as np
    from episode_boundary import NoiseEpisodeBoundary
    from noise_admission import public_state
    require(np.__version__ == "1.26.4", "pinned NumPy1.26.4 finite control required")
    build = json.loads(args.build_receipt.read_bytes())
    require(build["source_receipt_sha256"] == pin(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json")["sha256"], "same frozen source build required")
    extension = HERE / build["extension"]["path"]
    require(pin(extension) == {k: build["extension"][k] for k in ("bytes", "sha256")}, "same exact finite ELF required")
    spec = importlib.util.spec_from_file_location("_noise_owned", extension)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    raw = {"schema": "t3-noise-owned-fused-expression-controls-v1", "all_passed": False,
        "cases": [], "boundary_controls": [], "source_receipt_sha256": build["source_receipt_sha256"],
        "build_receipt": pin(args.build_receipt), "arms": ["original", "new", "new-repeat"],
        "market_executed": False, "rankable": False, "speed_claim": False}
    try:
        for index, (name, mean, scale, offset, patch, count) in enumerate(cases()):
            rngs = [np.random.RandomState(95600 + index) for _ in range(3)]
            for rng in rngs:
                initial = list(rng.get_state())
                initial[2], initial[3], initial[4] = patch.get("position", initial[2]), patch.get("has_gauss", initial[3]), patch.get("gauss", initial[4])
                rng.set_state(tuple(initial))
            owners = [None] + [native.NoiseRNGOwner(rng, public_state(rng, np), rng.normal, rng.randint,
                rng.get_state, rng.set_state, np.asarray, np.uint32) for rng in rngs[1:]]
            row = {"name": name, "mean": scalar(mean), "scale": scalar(scale), "offset": scalar(offset),
                "state_patch": {k: scalar(v) for k, v in patch.items()}, "calls": [],
                "initial_actual_states": [state(public_state(rng, np)) for rng in rngs]}
            require(row["initial_actual_states"][0] == row["initial_actual_states"][1]
                    == row["initial_actual_states"][2], "finite initial full624 states differ")
            for ordinal in range(count):
                before = [state(public_state(rngs[0], np))] + [state(owner.control_private_state()) for owner in owners[1:]]
                traces = [[], [], []]
                results = [observed(lambda: original_draw(rngs[0], mean, scale, offset, traces[0]))]
                for arm in (1, 2):
                    results.append(observed(lambda arm=arm: owners[arm].control_draw(mean, scale, offset)))
                    traces[arm] = owners[arm].control_trace_rows()
                recorded = [trace_rows(value) for value in traces]
                after = [state(public_state(rngs[0], np))] + [state(owner.control_private_state()) for owner in owners[1:]]
                require(before[0] == before[1] == before[2]
                        and results[0] == results[1] == results[2] and recorded[0] == recorded[1] == recorded[2]
                        and after[0] == after[1] == after[2], "fused expression boundary/outcome/full624 state differs")
                row["calls"].append({"ordinal": ordinal, "outcomes": results, "before_states": before,
                    "boundary_traces": recorded, "after_states": after})
            for owner in owners[1:]:
                owner.export_to_original(); owner.export_to_original()
            exported = [state(public_state(rng, np)) for rng in rngs]
            require(exported[0] == exported[1] == exported[2], "actual public terminal state differs")
            row["final_actual_exported_states"] = exported
            row["diagnostics"] = [owner.diagnostics() for owner in owners[1:]]
            raw["cases"].append(row)
        for mode in ("normal-return", "early-return", "BaseException", "public-exposure", "public-snapshot",
                     "public-replacement", "repeat-export"):
            rng = np.random.RandomState(95700)
            reference_rng = np.random.RandomState(95700)
            expected_draw = observed(lambda: original_draw(reference_rng, 10.0, 2.0, 5, []))
            owner = native.NoiseRNGOwner(rng, public_state(rng, np), rng.normal, rng.randint,
                rng.get_state, rng.set_state, np.asarray, np.uint32)
            class FiniteActor:
                def __init__(self, random_state):
                    self.random_state = random_state
            actor = FiniteActor(rng)
            boundary = NoiseEpisodeBoundary([(actor, owner, rng)])
            private_before_export = None
            extra = {}
            class FiniteAbort(BaseException):
                pass
            def runner():
                nonlocal private_before_export
                actual_draw = observed(lambda: owner.draw(10.0, 2.0, 5))
                require(actual_draw == expected_draw, "controlled runner draw differs from original")
                private_before_export = state(owner.control_private_state())
                require(private_before_export == state(public_state(reference_rng, np)), "runner full624 state differs from original")
                if mode == "BaseException":
                    raise FiniteAbort("finite actor abort after draws")
                if mode == "public-exposure":
                    require(boundary.expose_rng(actor) is rng, "public original identity changed")
                if mode == "public-snapshot":
                    extra["actual_public_snapshot_state"] = state(owner.snapshot())
                    require(extra["actual_public_snapshot_state"] == private_before_export
                            and owner.original_identity() is rng, "public snapshot state/identity changed")
                if mode == "public-replacement":
                    replacement = np.random.RandomState(95701)
                    replacement_reference = np.random.RandomState(95701)
                    boundary.before_replace_rng(actor)
                    actor.random_state = replacement
                    require(boundary.owner_for_controlled_actor(actor) is None and len(boundary.entries) == 1,
                            "former owner still selected after public replacement")
                    expected = observed(lambda: original_draw(replacement_reference, 10.0, 2.0, 5, []))
                    actual = observed(lambda: original_draw(actor.random_state, 10.0, 2.0, 5, []))
                    replacement_states = [state(public_state(value, np)) for value in (replacement_reference, replacement)]
                    require(actual == expected and replacement_states[0] == replacement_states[1]
                            and state(public_state(rng, np)) == private_before_export,
                            "replacement original continuation/full624 state differs")
                    extra.update({"standalone_setter_boundary_adapter_only": True,
                        "former_owner_lookup_retired": True, "terminal_entry_retained": True,
                        "selected_original_after_replacement": True, "continuation_outcomes": [expected, actual],
                        "actual_replacement_public_states": replacement_states})
                return None if mode == "early-return" else 3
            result = observed(lambda: boundary.run(runner))
            expected_result = ({"returned": False, "type": FiniteAbort.__module__ + "." + FiniteAbort.__name__,
                "message": "finite actor abort after draws", "warnings": []} if mode == "BaseException" else
                {"returned": True, "result": scalar(None if mode == "early-return" else 3), "warnings": []})
            require(result == expected_result, "runner return/exception/warnings differ")
            if mode == "repeat-export":
                boundary.export_all(); boundary.export_all()
            actual = state(public_state(rng, np))
            require(actual == private_before_export and owner.diagnostics()["owned"] is False
                    and owner.diagnostics()["handoffs"] == 1 and boundary.cleanup_failures == [], "runner/public terminal export incomplete")
            raw["boundary_controls"].append({"mode": mode, "outcome": result, "consumed_before_export": private_before_export,
                "actual_public_exported_state": actual, "diagnostics": owner.diagnostics(),
                "cleanup_failures": boundary.cleanup_failures, "extra": extra})
        raw["all_passed"] = True
    except BaseException as error:
        raw["failure"] = {"type": type(error).__name__, "message": str(error)}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(raw, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(raw["all_passed"], "finite Noise fused/control boundary failed")


if __name__ == "__main__":
    main()
