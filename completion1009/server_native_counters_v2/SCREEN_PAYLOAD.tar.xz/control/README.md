# Native counter server screen v2

## Executive summary

This experiment asks whether replacing ten internal Python dictionary counters with checked native counters makes the same market simulation faster. One Linux image contains the original simulator and two separately compiled native versions. It checks that their trades, messages and event totals agree before comparing their speed on the same server. This is a development experiment; it does not submit a competition entry or establish a ranking.

The frozen counter candidate changes counter storage only. It retains every original increment position, promotes overflowing values to exact Python integers, and rejects diagnostic seeded counters in production episodes. The original strategy, exchange, order book, RNG owners and simulation inputs remain authoritative. The parent and counter runtime snapshots contain the same 62 original files.

## Fixed execution plan

The three arms are `canonical`, `native_reference` and `native_counters`. A single multi-stage image build compiles two distinct `native_spine` extensions in separate candidate directories. Each simulation starts in a fresh container and loads only its selected extension. All arms share the same entry wrapper and original latency implementation.

The screen runs serially, rotating and reversing the arm order between rounds:

| Stage | Runs | Purpose |
|---|---:|---|
| Counter controls | 1 container | 95 finite cases and four full-market state, RNG and alias controls |
| Smoke | 9 | Three units, three arms |
| Paired screen | 60 | Five units, one warmup and three measured repeats, three arms |
| Fresh batch isolation | 15 | All five batch members separately, three arms |
| Total | 85 containers | 84 ordinary runs, 45 measured runs, 69 unchanged official verifier invocations |

The five units are S001 price-time priority, AS06 throughput, MP01 self-trade prevention, RA01 fundamental shock, and the original full five-member heterogeneous batch. The original public roster is checked to contain 71 units; this screen selects five of them and cannot replace full-roster validation.

Every ordinary run checks actual Parquet row counts, reference frame values and dtypes, event sidecars and resource limits. The 69 smoke and screen runs also invoke the unchanged official developer verifier. Cross-arm and repeat comparisons require identical Parquet bytes and stable sidecar values. Isolation compares fresh single runs with the original isolated reference and their own full batch outputs. Native probes bind actual extension bytes, source receipts, ABI, exact counter keys and unseeded execution. Counter values must agree with the native parent.

## Timing and interpretation

The common wrapper resolves arguments and selects a candidate before the selected `cli.py` sets `ENTRY_STARTED`. The CLI clock includes runtime imports, authentication performed by `enabled`, simulation, frame validation, Parquet writing and hashing. It stops before sidecar serialization, as in the frozen CLI. The wrapper invokes `simulate` directly and therefore excludes `main`'s redundant admission call; all three arms use the same boundary. The final witness marker is outside the CLI clock.

Host timing covers create, inspect, start and terminal inspect, excluding cleanup. Daemon timing uses actual `State.StartedAt` through `FinishedAt`, including wrapper startup and marker emission. Cleanup time is retained separately. These are representative server comparisons under this protocol, not an official score. Do not compare their absolute times with the earlier native proof, whose clock started after imports, or project a five-unit result onto the full competition roster.

Each measured unit uses the ratio of the baseline median time to the candidate median time across three repeats. The screen reports the arithmetic mean of those five ratios for CLI, host and daemon timing, separately for counters versus parent and both native versions versus canonical. A ratio above one means faster within this experiment. The selected production observer/scalar candidate is outside this experiment; composing changes requires a later measurement.

## Resources and provenance

Participant containers use Linux amd64, CPython 3.11.17, runc, 4 CPU quota, 16 GiB memory with swap disabled, network none, read-only root, UID/GID 65534, no capabilities and no new privileges. PID and nproc limits are 256; the file descriptor limit is 1024. `/tmp` is a 64 MiB noexec tmpfs. File and complete output limits are 256 MiB. Both official simulation verbs are exercised. The host evaluator uses Python 3.13.7 and the pinned current toolkit fetched by the unchanged source-bound evaluator helper.

`stage.py` copies and parses frozen sources without importing the simulator, compiling native code or running a market. `materialize.py` accepts only an exact-hash, bounded archive of unique regular files. The workflow has read-only repository permission, uses the existing serial Linux concurrency group, builds once, runs controls before measurements, and uploads evidence without publishing an image or consuming a competition submission.

Evidence preserves actual source/runtime files, generated C, both ELF extensions, compiler and evaluator receipts, all command logs, resource configuration, original reference hashes and comparisons. Successful ordinary input/output bytes are compacted only when the entire screen passes; an exact byte/hash omission inventory is saved. All control outputs and all failed or unknown ordinary outputs are retained. The downloaded evidence audit must distinguish saved comparisons from a fresh comparison of any omitted Parquet bytes.

Before any official submission, the selected competitive production image still needs full 71-unit checks, the current repeat plan, anonymous pull validation, the official descriptor parser and seal, and the official two-member submission ZIP. The 230000 events/sec goal remains unverified.

This v2 screen retains the failed v1 archive and run37931005600. The candidate fixes only two uint64 array capacities to the literal10 after reproducing the Cython3.1.3 named-enum generation failure. Both complete v2 candidate sources pass pure Cython generation with exact directives; real Linux compilation and execution still require this screen. The three-arm 85-container protocol is unchanged.
