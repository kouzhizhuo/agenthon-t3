The prepared controls prove a real compiled execution path against the immutable canonical source; they have not been run. Their first gate is a successful CPython 3.11/Cython 3.1.3 receipt, and any failure blocks performance or submission claims. Whole official Linux workload validation remains a separate parent-task gate.

## Prepared finite controls

- Actual native calendar vs CPython C heapq ordering for huge builtin PyLong times, NumPy scalar times, equal dataclass payloads, same-UID different payloads and shared raw-message aliases.
- Four strategies across initial/open/closed wake, empty/one-sided/two-sided spread and closed spread; exact state, queue, ledger, original RNG, IDs and kernel clocks.
- Accepted/executed/partial/full/missing/cancelled notifications, side-specific holdings, original warnings and live order mutations.
- Production native one-pop vs separately named test-only original runner fixture, comparing each state after batch submessages, busy requeue and the original previous-clock stop boundary.
- Actual native debug hook with a live bound batch list append and list rebinding after the first receive; original submessage UID/causal sequencing and changing compute/additional delay.
- Replaced original callable defaults and replaced compiled exports must be refused while preserving the subsequent original bindings.

## Prepared whole-market controls

The four complete deterministic markets use uniform latency; delayed exchange protocol; log-normal latency; and default latency. Each uses the four original agent families and original matching. Canonical/native processes compare trace and message frames, exact dtypes/values/Parquet bytes, logical complete business state with aliases and pending queue, RNG states, Message/Order counters, warnings and every pop. Wall-clock fields and only the new private core/calendar representation are excluded; business state is not normalized away.

The native witness must show a receipt-bound loaded `.so`, no fallback, strategy acts and book bridges. The result stores build provenance and source inventories, and refuses overwritten evidence. An actual compiled witness is necessary but insufficient for official speed or ranking.

## Further required before a submission

Add strict negative tests for builtin-ID range/types, unknown strategy/latency/book/oracle classes, instance overrides, Gym/debug, tampered generated C/source/ABI/extension receipt, and kernel installation restoration on early exceptions. Expand finite coverage to default/no-model latency and integer overflow/warning edges, every rare protocol notification, repeated episodes and broadcast/requeue/pending-stop aliases. Add fixture checks for malformed depth and custom comparison failure only if the admitted producer domain is expanded; those domains are excluded now.

Review official command line, archive layout, output file names and schema, dtype/value/trace ordering, true complete horizon and pop counts, zero GPU accounting, process wall/RSS accounting and all hidden-scenario families before packaging. Run a paired complete Linux performance screen only after semantics pass and with the proof instrumentation explicitly identified. The parent task owns execution and formal submission opportunity accounting.
