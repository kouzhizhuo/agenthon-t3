"""Install one strict serial native or canonical proof arm and restore bindings."""
from contextlib import contextmanager
import os

_last_episode = None
_episodes = []

def quiet_summary_writer(self):
    """Shared named diagnostic-IO suppression; business logs remain original."""
    return None

def authenticate():
    from binding_audit import static_admission, source_manifest
    source_manifest()
    return static_admission()

def ensure_native_admission():
    path = os.environ.get("NATIVE_SPINE_BUILD_RECEIPT")
    if not path:
        raise ValueError("NATIVE_SPINE_BUILD_RECEIPT must identify the explicit build")
    from admission import load_native
    return load_native(path)

@contextmanager
def enabled(active=True):
    from abides_core import abides
    from abides_fork import trace
    from column_trace import make_extractor
    from t3_canonical_engine import CanonicalKernel, ColumnLedger
    authenticate()
    cls = ensure_native_admission().NativeSpineKernel if active else CanonicalKernel
    original = abides.Kernel
    extractor = make_extractor(ColumnLedger, trace.extract_message_trace,
        trace.MESSAGE_TRACE_COLUMNS, trace._MSG_DTYPES)
    abides.Kernel = cls
    try:
        yield extractor
    finally:
        abides.Kernel = original

def capture_episode(kernel):
    global _last_episode
    from admission import native_receipt
    _last_episode = {**kernel.path_witness(), **native_receipt(), "ttl_messages": kernel.ttl_messages}
    _episodes.append(dict(_last_episode))

def active_probe():
    return None if _last_episode is None else dict(_last_episode)

def reset_episode_probes():
    global _last_episode
    _last_episode = None
    _episodes.clear()

def episode_probes():
    return [dict(episode) for episode in _episodes]
