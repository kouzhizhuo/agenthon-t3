This is an unbuilt, untested source prototype for a continuous native scheduler and the four official fixed strategies. It keeps the original Python agents and kernel as the sole business-state owners and retains original matching, order objects, RNG, oracle, logs and output projection. It is a semantic proof step, with no events-per-second, rank or 230000 claim. The parent task alone schedules builds, simulations and timing on GitHub Linux.

## Scope and ownership

`NativeSpineKernel` is a Python-compatible facade around the extension's `cdef NativeCore`. `TypedCalendar` holds typed envelope references and CPython-style heap sifts. An envelope strongly owns the actual original Message object; shared broadcasts, delayed cancellation orders and MessageBatch lists stay live. There is no compact arena, reconstruction UID, copied AgentState, clock mirror or synchronization phase.

Only positions, dense builtin integer IDs and immutable strategy-kind metadata use native integer fields. Timestamp and business arithmetic stay Python objects, including NumPy scalar types, PyLong range, original operation association, normal warnings and exceptions. The core retains original raw Message/LimitOrder constructors and deepcopy calls. The initial exact `create_limit_order` local holdings calculation is preserved even when the original default skips its risk check.

Admission is strict for the whole episode. It requires frozen original sources and actual loaded Python callback/default/global/class bindings; exact original classes and no instance callback overrides; exchange first; four known strategies; dense builtin integer IDs; original dictionary owners, plain initial limit orders, matching/oracle/latency owners; no Gym or debug-logging mode. It refuses unsupported input before `initialize`. This prototype has no midstream fallback. Canonical is a separate explicit arm.

The admitted producer domain is the official validated fixed scenario configuration and original callbacks. Arbitrary external scheduler calls with custom sender/recipient scalars, hostile numeric/message subclasses, arbitrary private heap mutation or comparison-triggered reentrant mutation are outside this proof scope. Deepcopy/pickle of the entire agent→kernel→native-core graph is also outside the current controls. Actual dataclass equality and shared raw identity are retained and prepared for testing. `TypedCalendar.queue` is a diagnostic logical snapshot; mutation of that private representation is excluded. Logical queue values, message types/IDs and raw reference aliases remain observable controls.

## Native provenance

An optimized arm can load only an actual `ExtensionFileLoader` image named `native_spine`, compiled for the current CPython 3.11 ABI with Cython 3.1.3. The successful build receipt binds the candidate source inventory, frozen snapshot and source-binding evidence, generated C hashes, native extension bytes/hash, exact ABI, package version pins, compiler configuration, directives and flags. Native export identity/default/constant mutations and original callback/default/constant mutations are checked. Package metadata versions are pins; they are not a claim that third-party NumPy/SciPy native image bytes were independently audited.

The frozen 62-file runtime is copied by `prepare_snapshot.py` only after its full manifest passes, and its Python modules remain source modules for this proof. No existing direct-v2, canonical runtime or previous Linux screen is changed. `preflight.py` prepares independent source/default/binding pins; native provenance is checked separately and never treats a Python `FunctionType` fixture as compiled evidence.

## Explicit Linux preparation and controls

The parent task stages this entire directory beside the unchanged `completion1009/RUNTIME_MANIFEST.json` and `completion1009/runtime`. In a fresh CPython 3.11 Linux environment with the versions in `compile_spec.json` and Cython 3.1.3, the scheduled commands are:

```sh
python3.11 prepare_snapshot.py
python3.11 preflight.py
python3.11 build_native.py --out artifacts/build_v1
export NATIVE_SPINE_BUILD_RECEIPT="$PWD/artifacts/build_v1/BUILD_RECEIPT.json"
python3.11 controls.py --out controls/attempt_v1
```

These are prepared recipes, not executed receipts. Every output directory is new; existing results or failed builds are refused and preserved. Build runs generate into `artifacts/build_v1/generated`, `objects`, and `native`; no inplace extension or generated C is written into the frozen runtime. Arithmetic flags are `-O2 -fPIC -fno-fast-math -ffp-contract=off`; semantic checks and `infer_types=False`, `annotation_typing=False`, `cdivision=False` remain enabled.

`controls.py` first requires actual native finite controls, then runs canonical/native full markets in separate serial processes. It compares exact trace/message DataFrames, dtypes and Parquet bytes, complete logical business graph and aliases, all RNG states, ID counters, warnings and actual event-pop totals. It requires native strategy and original book-bridge execution witnesses. No finite PASS, package build or local projection alone satisfies official submission validation.

## CLI and additive host probe

`cli.py` exposes the official single/batch CLI contract using the unchanged output validators and projection. Native loading happens before simulation; `installed.enabled` restores the Kernel binding on every exit and does not replace latency methods. Both proof arms use the same named summary-file IO suppression. The original authoritative business logs remain intact.

`host_probe.py` loads the real candidate CLI as module `agent`, invokes `simulate`/`simulate_batch` directly, and receives one production `terminate` witness per actual episode. `installed.reset_episode_probes()` and `installed.episode_probes()` expose the retained list without wrapping callbacks. It never wraps source-authenticated `enabled`, `abides.run` or class callbacks. Example after scheduled successful controls:

```sh
python3.11 host_probe.py --config scenario.json --out probe/native/trace.parquet --mode optimized --probe probe/native/receipt.json
python3.11 cli.py simulate-batch --batch-dir scenarios --out-dir outputs --mode optimized
```

The probe is diagnostic. Its measured rate is not rankable until the parent task validates the official environment, complete workload, resource accounting and comparison procedure.

## Known cost and next gates

The cdef region still bridges Python message constructors, exact numeric operations, RNG, oracle, matching, logs and final projection. Its Python dictionary counters add work absent the canonical runner; current controls carry this instrumentation intentionally and timing would measure this instrumented proof path. This scheduler/strategy spine cannot establish the required speedup by architecture alone. No target-speed claim is warranted without scheduled complete Linux evidence.

The immediate gates are real Cython compilation, finite and full-market exactness, negative-admission controls, complete official schema/resource review, then separately authorized paired Linux performance measurement. Failed evidence stays intact. Only later evidence can justify removing proof instrumentation, expanding the native region to matching/notifications/output columns, or spending a formal submission.
