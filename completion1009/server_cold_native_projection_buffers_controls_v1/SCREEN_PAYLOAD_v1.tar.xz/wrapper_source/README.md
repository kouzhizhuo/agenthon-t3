# Cold native projection buffers controls and whole-market screen V1

This test will check whether converting completed market records directly into
native output buffers saves time while preserving every result. It first checks
the compiled code and final files, then runs complete markets with the same
inputs and limits. This directory contains prepared source only; it has not
compiled, run, uploaded or submitted a candidate.

The candidate is the frozen `cold_native_projection_buffers_v1` source receipt
`d9eeab53a9c61604f1ef63ea0579f6884dc14221515caa4b5be0f30b8b12cfc8`,
whose 100 files have an independent source review. The new wrapper retains the
composite V1 controller's actual-tested bounded Docker lifecycle, strict 4 CPU /
16 GiB runtime, offline/read-only/unprivileged setup, input/output-only mounts,
cleanup after uncertain creation, serial execution, and unchanged official host
verifier. The upstream wrapper and candidate remain immutable. This reuse is a
source relationship; it proves no new runtime result.

The anonymous-pullable construction base is exactly
`ghcr.io/kouzhizhuo/agenthon-t3@sha256:5a190afe0bdfe7685e64cbf1aec30d39885199c85f688a971b8d4a0ab8d217eb`.
Construction uses pinned CPython 3.11.17/Cython 3.1.3 and strict numeric flags.
The host requires the complete translated C file to equal the complete build
generated C file byte for byte, then checks retained compiler objects, exact ELF
and source/dependency/schema receipts. A failed construction still builds a data
carrier so partial source/C/object/ELF/logs can be copied and rejected by the host.
Construction resources are outside the market timing comparison.

The first runtime container authenticates all nine original public scenarios,
then runs two separate cold output fixture children and six complete market
children. The original fixture child uses its genuine original projectors and
pandas writer. The native child uses the actual source/ELF-bound cold projectors
and production Arrow writer. The host checks all six fixture file pairs, explicit
values, schema/dtypes, exact Parquet bytes, nullable/UTF8/range/tie controls,
hostile-key decline without callbacks, readonly descriptors and owner-destruction
lifetime. Fixture owners are explicitly uninitialized cold packer inputs and
never establish market authority.

The separate complete market children cover original, light canonical, native,
native repeat and forced decline of each projector. They must show initialized
native authority, positive actual message/order arena use, equal repeat arena
diagnostics, full STATE and both output bytes equality, no output mutation of the
authoritative graph, restored bindings/observer, and complete same-market pair
fallback before any writes. Normal children reject pandas/scipy import attempts.

After those prerequisites, five original public units run in three arms:
baseline, light canonical, and `light_dynamic` using the frozen cold native
output buffers. Each unit/arm receives one fresh-container warmup and two fresh
measured repeats, with rotated/reversed arm ordering. The heterogeneous five-sub
batch also receives 15 fresh isolation runs. This is 61 execution containers,
102 market episodes, 60 ordinary runs, 30 measured runs, 45 unchanged developer
verifier calls and 180 required gate passes. The two packing fixture children
execute no markets. There is no measured phase instrumentation.

Rates use actual verified event count divided by settled Docker StartedAt /
FinishedAt time per run. Per-unit median and mean remain separate; the five-unit
mean of medians is a diagnostic surrogate. Development verifier scores use its
self-reported practice profile and are not substituted for daemon timing. No
full71/sealed/final score, 230000 threshold, ranking or submission claim follows
from prepared source or this small finite screen. Actual files, receipts, logs,
timing and cleanup must be independently read after any future root-owned run.
