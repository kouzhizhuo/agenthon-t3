"""Cache exact source expectations; recheck actual loaded domain every episode."""
from pathlib import Path
import ast
import abc
import hashlib
import types

# Frozen image source pins are additive to the packaging manifest. No source
# outside this closed relative-path set can supply cached expectations.
_SOURCE_PINS = (('vendor/abides/abides-core/abides_core/agent.py', '47c6310965a85cec48b691408a5fb89d24fbd382aaef78e311afd6e42e383db7'), ('vendor/abides/abides-core/abides_core/kernel.py', '0a9ff4b2c24c7eebab09c8eedf08cc224b4adc50c5c90a44dbe903c506ba01cd'), ('vendor/abides/abides-core/abides_core/message.py', 'c1ddc0f0962d68e8d6750fb00210a2676d7bbdd2dd7f3b021e9fa94287901e48'), ('vendor/abides/abides-markets/abides_markets/orders.py', '50a3c460ca4acd2d98bd08d0637971c9d4652bc9591655fb3634ffc05eb0be0e'), ('vendor/abides/abides-markets/abides_markets/order_book.py', '4b2dc88b08bbb2501f430e4f60644f8f71cef2816c933ccbfa20deaaa58a4822'), ('vendor/abides/abides-markets/abides_markets/price_level.py', 'd448ccf12f49c8078994c6d1d2ca150bfed169dbfa393fcfd4d8bc7e4eb9c1b1'), ('vendor/abides/abides-markets/abides_markets/utils/__init__.py', '16cddfcff15e5e36644d180a0fed5ad5e84cfda79a8c2cd4c753a08d5f18771c'), ('vendor/abides/abides-markets/abides_markets/agents/trading_agent.py', '0293867728c4f033e7bed62a1d90d2ceea1543bb86544be257cac4b3f5102d2d'), ('vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py', '701e84305ef18d596aedb2f72a9109b11148a4d7ec8742b0f394d683df2106e6'), ('abides_fork/agents.py', 'f4521ce1e9d0093761df7b92e996e63a879ce909b42d158a03458eef552c636a'), ('abides_fork/config.py', '5e72af5a9a576927d4a5d21199eb9ef5ea821813dfefc3b02306e2a8cf952384'), ('abides_fork/trace.py', '1e32d9612c23564343070a413360132e4561cc6b57e01244b2c27e80997ef2e0'), ('observer.py', '98ebe546b9a7d3c3a5066b15512e6b763d16de89fd795632b04efa5a2ccf9556'), ('vendor/abides/abides-core/abides_core/utils.py', '92e12f8102a07aaf067bfa26c93764a7c55ea505b417d9569f270845c6c05f9c'), ('canonical_time.py', '5b3fa379835804d199cb9f859468e10a1ba9937da73eb6a4c75b778a36a090e1'), ('canonical_buffers.py', 'c01ff523f066191965d9a98dae7c70f437be04f9931428e1ad8d7c2f098d2600'), ('column_trace.py', '1efce7b58412aa3b39daa266c3994915728d871dc76e4faa4212d1a00a1d0964'), ('contracts.py', '868402dcf156d370d897ec611aed1f07a9c6512dce8f20397ca2006a08ef4a87'), ('optimizations.py', 'fa90d2189f4651fc5c15ef72c417278df785abce2b354cb4c09bbcd831936a2c'), ('counters.py', '9f8edbc09d54da34c8e96ae6ba7cfd7e27837fc35b12913f90d922895caff907'), ('vendor/abides/abides-markets/abides_markets/agents/__init__.py', '18a6900db7554d39950602b99f8323a305a8621c5e9f56f30862106460fb1939'), ('composite_boundary.py', '7d154c674a2e660dc13cb33a9ceb536820849c15d1a1722602853b7316f20d59'))
_SOURCE_CACHE = {}
_CACHE_RECEIPTS = {}
_CLASS_EXPORTS = {}
_CACHE_COMPILES = 0
_CACHE_AST_PARSES = 0
CACHE_VERSION = 1


def _source_image(module, images):
    """Read/hash exact image bytes per admission; compile/parse once per digest."""
    global _CACHE_COMPILES, _CACHE_AST_PARSES
    path = Path(module.__file__).resolve()
    import observer
    runtime = Path(observer.__file__).resolve().parent
    relative = str(path.relative_to(runtime))
    expected = dict(_SOURCE_PINS).get(relative)
    if expected is None or path != runtime / relative:
        raise ValueError("unsupported source image path")
    if path in images:
        return images[path]
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != expected:
        raise ValueError("source bytes differ from frozen image: " + relative)
    key = (path, digest)
    image = _SOURCE_CACHE.get(key)
    if image is None:
        if key in _CACHE_RECEIPTS:
            raise ValueError("expected source cache entry disappeared")
        code = compile(data, str(path), "exec", dont_inherit=True)
        tree = ast.parse(data)
        image = {"code": code, "tree": tree, "functions": {}, "defaults": {}}
        _SOURCE_CACHE[key] = image
        _CACHE_RECEIPTS[key] = image
        _CACHE_COMPILES += 1
        _CACHE_AST_PARSES += 1
    if (_CACHE_RECEIPTS.get(key) is not image or type(image) is not dict
            or set(image) != {"code", "tree", "functions", "defaults"}
            or type(image["code"]) is not types.CodeType
            or type(image["tree"]) is not ast.Module
            or type(image["functions"]) is not dict or type(image["defaults"]) is not dict):
        raise ValueError("malformed or replaced source cache entry")
    images[path] = image
    return image


def _code_at(module, class_name, method_name, compiled, first=False):
    image = _source_image(module, compiled)
    key = (class_name, method_name, first)
    if key not in image["functions"]:
        code = image["code"]
        if class_name:
            code = next(c for c in code.co_consts if type(c) is types.CodeType and c.co_name == class_name)
        matches = [c for c in code.co_consts if type(c) is types.CodeType and c.co_name == method_name]
        image["functions"][key] = matches[0] if first else matches[-1]
    return image["functions"][key]


def _defaults_match(function, module, class_name, name, parsed, first=False):
    image = _source_image(module, parsed)
    key = (class_name, name, first)
    if key not in image["defaults"]:
        nodes = image["tree"].body
        if class_name:
            nodes = next(node.body for node in nodes if isinstance(node, ast.ClassDef) and node.name == class_name)
        matches = [node for node in nodes if isinstance(node, ast.FunctionDef) and node.name == name]
        node = matches[0] if first else matches[-1]
        def descriptor(value):
            if (isinstance(value, ast.Attribute) and value.attr == "maxsize"
                    and isinstance(value.value, ast.Name) and value.value.id == "sys"):
                return ("sys.maxsize", None)
            return ("literal", ast.literal_eval(value))
        positional = tuple(descriptor(value) for value in node.args.defaults)
        keywords = tuple((argument.arg, descriptor(value)) for argument, value in zip(node.args.kwonlyargs, node.args.kw_defaults) if value is not None)
        image["defaults"][key] = positional, keywords
    positional, keywords = image["defaults"][key]
    def current_value(value):
        kind, expected = value
        if kind == "sys.maxsize":
            import sys
            if vars(module).get("sys") is not sys:
                raise ValueError("sys.maxsize default has modified owning binding")
            return sys.maxsize
        return expected
    expected_positional = tuple(current_value(value) for value in positional) or None
    expected_keywords = {name: current_value(value) for name, value in keywords} or None
    return function.__defaults__ == expected_positional and function.__kwdefaults__ == expected_keywords


def authenticate_loaded():
    """Return False for an unsupported loaded domain before any agents exist.

    The shipped snapshot is manifest-verified during preparation and packaging.
    This check authenticates producer code, inherited logging/constructors and
    all four mappings as actually imported; no hot-loop checks are installed.
    """
    from abides_core import agent, kernel, message, latency_model
    import abides_core.utils as core_utils
    import canonical_time, canonical_buffers, column_trace, contracts, optimizations, counters, composite_boundary
    from abides_markets import orders, order_book, price_level
    import abides_markets.utils as utils
    from abides_markets.agents import trading_agent, exchange_agent
    from abides_markets import agents as market_agents
    from abides_fork import agents, config, trace
    import observer
    runtime = Path(observer.__file__).resolve().parent
    checks = (
        (composite_boundary, "composite_boundary.py", None, ("bind_dynamic_engine", "exact_dynamic_engine")),
        (core_utils, "vendor/abides/abides-core/abides_core/utils.py", None, ("str_to_ns", "datetime_str_to_ns", "fmt_ts")),
        (canonical_time, "canonical_time.py", None, ("str_to_ns", "datetime_str_to_ns", "fmt_ts", "_integer_type")),
        (canonical_buffers, "canonical_buffers.py", None, ("project_trace", "project_messages", "validate_columns", "validate_admitted_columns", "write_outputs", "_array", "_schemas", "_metadata", "_integer", "_exact_order_integer", "_trusted_dict", "_type_is", "import_witness")),
        (canonical_buffers, "canonical_buffers.py", "Columns", ("__init__",)),
        (canonical_buffers, "canonical_buffers.py", "Declined", ("__init__",)),
        (column_trace, "column_trace.py", None, ("make_extractor",)),
        (contracts, "contracts.py", None, ("validate_frames", "validate_scenario")),
        (optimizations, "optimizations.py", None, ("scalar_latency",)),
        (counters, "counters.py", None, ("reset_abides_counters",)),
        (market_agents, "vendor/abides/abides-markets/abides_markets/agents/__init__.py", None, ("__getattr__",)),
        (agent, "vendor/abides/abides-core/abides_core/agent.py", "Agent", ("__init__", "logEvent", "kernel_terminating", "write_log")),
        (kernel, "vendor/abides/abides-core/abides_core/kernel.py", "Kernel", ("write_log", "append_summary_log")),
        (orders, "vendor/abides/abides-markets/abides_markets/orders.py", "Order", ("__init__", "to_dict")),
        (orders, "vendor/abides/abides-markets/abides_markets/orders.py", "LimitOrder", ("__init__", "__deepcopy__")),
        (trading_agent, "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py", "TradingAgent", (
            "__init__", "create_limit_order", "place_limit_order", "place_market_order", "place_multiple_orders", "cancel_order", "partial_cancel_order", "modify_order", "replace_order", "order_executed", "order_accepted", "order_cancelled", "order_partial_cancelled", "order_modified", "order_replaced", "kernel_starting", "kernel_stopping", "query_spread")),
        (exchange_agent, "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py", "ExchangeAgent", ("__init__", "receive_message", "send_message", "kernel_terminating", "analyse_order_book", "get_time_dropout", "_original_time_dropout")),
        (order_book, "vendor/abides/abides-markets/abides_markets/order_book.py", "OrderBook", ("handle_limit_order", "execute_order", "enter_order", "append_book_log2", "get_l2_bid_data", "get_l2_ask_data", "get_l3_bid_data", "get_l3_ask_data")),
        (price_level, "vendor/abides/abides-markets/abides_markets/price_level.py", "PriceLevel", ("__init__", "add_order", "total_quantity")),
        (message, "vendor/abides/abides-core/abides_core/message.py", "Message", ("type",)),
        (utils, "vendor/abides/abides-markets/abides_markets/utils/__init__.py", None, ("generate_uniform_random_pairwise_dist_on_line", "generate_latency_model", "meters_to_light_ns", "__getattr__")),
        (config, "abides_fork/config.py", None, ("build_config", "_agent_kwargs")),
        (agents, "abides_fork/agents.py", "ScheduledAgent", ("__init__", "wakeup", "receive_message", "kernel_starting")),
        (trace, "abides_fork/trace.py", None, ("extract_trace", "_parse_trace_logs", "_canonical_trace")),
    )
    try:
        compiled = parsed = {}
        class_exports = {}
        for module, relative, class_name, names in checks:
            if Path(module.__file__).resolve() != runtime / relative:
                return False
            cls = getattr(module, class_name) if class_name else module
            if class_name:
                key = (Path(module.__file__).resolve(), class_name)
                expected_meta = abc.ABCMeta if module is orders and class_name in ("Order", "LimitOrder") else type
                if (type(cls) is not expected_meta or cls.__module__ != module.__name__
                        or (key in _CLASS_EXPORTS and _CLASS_EXPORTS[key] is not cls)):
                    return False
                if expected_meta is abc.ABCMeta and orders.ABC is not abc.ABC:
                    return False
                class_exports[key] = cls
            for name in names:
                function = getattr(cls, name)
                if isinstance(function, property): function = function.fget
                if type(function) is not types.FunctionType or function.__code__ != _code_at(module, class_name, name, compiled):
                    return False
                if (function.__globals__ is not vars(module)
                        or Path(function.__globals__["__file__"]).resolve() != runtime / relative
                        or not _defaults_match(function, module, class_name, name, parsed)):
                    return False
        for name in observer.STRATEGIES:
            cls = getattr(agents, name)
            key = (Path(agents.__file__).resolve(), name)
            if (type(cls) is not type or cls.__module__ != agents.__name__
                    or (key in _CLASS_EXPORTS and _CLASS_EXPORTS[key] is not cls)):
                return False
            class_exports[key] = cls
            if cls.act.__code__ != _code_at(agents, name, "act", compiled):
                return False
            if cls.__init__.__code__ != _code_at(agents, name, "__init__", compiled):
                return False
            if (cls.act.__globals__ is not vars(agents) or cls.__init__.__globals__ is not vars(agents)
                    or not _defaults_match(cls.act, agents, name, "act", parsed)
                    or not _defaults_match(cls.__init__, agents, name, "__init__", parsed)):
                return False
        if agents.AGENT_REGISTRY != {name: getattr(agents, name) for name in observer.STRATEGIES}:
            return False
        if config.AGENT_REGISTRY is not agents.AGENT_REGISTRY:
            return False
        if (config.ExchangeAgent is not exchange_agent.ExchangeAgent
                or agents.TradingAgent is not trading_agent.TradingAgent
                or trading_agent.LimitOrder is not orders.LimitOrder
                or trading_agent.Side is not orders.Side
                or exchange_agent.OrderBook is not order_book.OrderBook):
            return False
        # Combined witness producers and unchanged metric consumers share the
        # actual loaded globals/identities. Lazy import keeps SciPy unloaded
        # until needed; any already-loaded public function must be its SciPy
        # binding. No import is forced merely to perform admission.
        import sys
        import datetime
        import numpy as np
        if (order_book.PriceLevel is not price_level.PriceLevel
                or price_level.LimitOrder is not orders.LimitOrder
                or price_level.Side is not orders.Side
                or config.generate_latency_model is not utils.generate_latency_model
                or utils.LatencyModel is not latency_model.LatencyModel
                or utils.np is not np
                or order_book.np is not np or exchange_agent.np is not np):
            return False
        if (canonical_time.np is not np or canonical_buffers.np is not np
                or canonical_buffers.TRACE_TYPES is not contracts.TRACE_TYPES
                or canonical_buffers.MESSAGE_TYPES is not contracts.MESSAGE_TYPES
                or canonical_buffers.EVENT_TYPES is not contracts.EVENT_TYPES
                or canonical_time._INTEGER_TYPES != (int, np.int64, np.int32)
                or canonical_buffers._INTEGER_TYPES != (int, np.int64, np.int32)
                or canonical_time.datetime is not datetime.datetime
                or canonical_time.timedelta is not datetime.timedelta
                or canonical_time._EPOCH != datetime.datetime(1970, 1, 1)
                or canonical_time._DURATIONS != {"09:30:00": 34200000000000, "16:00:00": 57600000000000,
                    "1s": 1000000000, "60s": 60000000000, "1min": 60000000000}
                or canonical_buffers._MESSAGE_SOURCE != {"message_id": 0, "src_id": 1, "dst_id": 2,
                    "t_send_ns": 3, "t_recv_ns": 4, "latency_ns": 5, "msg_type": 6, "order_id": 7, "causal_parent": 8}):
            return False
        if (counters.Order is not orders.Order or counters.Message is not message.Message
                or market_agents._EXPORTS != {
                    "MomentumAgent": ".examples.momentum_agent",
                    "AdaptiveMarketMakerAgent": ".market_makers.adaptive_market_maker_agent",
                    "ExchangeAgent": ".exchange_agent", "FinancialAgent": ".financial_agent",
                    "NoiseAgent": ".noise_agent", "TradingAgent": ".trading_agent",
                    "ValueAgent": ".value_agent"}
                or market_agents.__all__ != list(market_agents._EXPORTS)):
            return False
        for name in ("pdist", "squareform"):
            if name in vars(utils):
                distance = sys.modules.get("scipy.spatial.distance")
                if distance is None or vars(utils)[name] is not getattr(distance, name, None):
                    return False
        if any(getattr(module, "_observer", None) is not observer
               for module in (agent, trading_agent, exchange_agent, order_book)):
            return False
        for name in ("begin_episode", "finish_episode", "record_log", "order", "quote",
                     "skip_termination", "_payload", "replay_state", "extract_trace", "diagnostic", "imbalance"):
            function = getattr(observer, name)
            if (function.__code__ != _code_at(observer, None, name, compiled)
                    or function.__globals__ is not vars(observer)
                    or not _defaults_match(function, observer, None, name, parsed)):
                return False
        for name in ("__init__", "append"):
            function = getattr(observer.Episode, name)
            if (function.__code__ != _code_at(observer, "Episode", name, compiled)
                    or function.__globals__ is not vars(observer)
                    or not _defaults_match(function, observer, "Episode", name, parsed)):
                return False
        key = (Path(observer.__file__).resolve(), "Episode")
        if (type(observer.Episode) is not type or observer.Episode.__module__ != observer.__name__
                or (key in _CLASS_EXPORTS and _CLASS_EXPORTS[key] is not observer.Episode)):
            return False
        class_exports[key] = observer.Episode
        fallback = trace._extract_trace_observer_original
        if type(fallback) is not types.FunctionType or fallback.__code__ != _code_at(trace, None, "extract_trace", compiled, first=True):
            return False
        if fallback.__globals__ is not vars(trace) or not _defaults_match(fallback, trace, None, "extract_trace", parsed, first=True):
            return False
        if (trace._side_to_str.__code__ != _code_at(trace, None, "_side_to_str", compiled)
                or trace._side_to_str.__globals__ is not vars(trace)
                or trace.Side is not orders.Side):
            return False
        if (observer.ORDER_FIELDS != ("agent_id", "order_id", "side", "quantity", "limit_price", "fill_price")
                or observer.FIELDS != ("ScalarEventValue", "agent_id", "order_id", "side", "quantity", "limit_price", "fill_price", "EventTime", "EventType")
                or observer.STRATEGIES != frozenset(("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"))
                or observer.ORDER_TYPES != frozenset(("ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_EXECUTED", "ORDER_CANCELLED", "ORDER_REPLACED"))):
            return False
        columns = ["t_ns", "agent_id", "msg_type", "side", "price", "size", "order_id"]
        dtypes = {"t_ns": "int64", "agent_id": "int32", "msg_type": "string", "side": "string", "price": "int64", "size": "int64", "order_id": "int64"}
        if (trace.TRACE_COLUMNS != columns or trace._TRACE_DTYPES != dtypes
                or trace._ORDER_EVENT_MAP != {name: name for name in observer.ORDER_TYPES if name != "ORDER_EXECUTED"}):
            return False
        # Plain field defaults are a separate witness from bytecode equality.
        if trading_agent.TradingAgent.place_limit_order.__defaults__ != (None, False, False, False, False, True, None):
            return False
        if orders.LimitOrder.__init__.__defaults__ != (False, False, False, False, None, None):
            return False
        _CLASS_EXPORTS.update(class_exports)
        return True
    except (AttributeError, KeyError, IndexError, StopIteration, TypeError, ValueError, OSError, SyntaxError):
        return False
