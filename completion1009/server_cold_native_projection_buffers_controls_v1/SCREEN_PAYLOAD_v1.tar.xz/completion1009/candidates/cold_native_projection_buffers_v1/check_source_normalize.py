from pathlib import Path
import re,ast,json,hashlib
D=Path(__file__).resolve().parent
def normalize(source):
 lines=[];property_mode=False
 for line in source.splitlines():
  if re.match(r'^    property \w+:',line):property_mode=True;lines.append('');continue
  if property_mode:
   if line.strip() and not line.startswith('        '):property_mode=False
   else:lines.append('');continue
  if ' cimport ' in line or re.match(r'^include ',line):lines.append('');continue
  line=line.replace('cdef class ','class ',1)
  if re.match(r'\s*cdef .*?\w+\([^\n]*\).*:',line):
   line=re.sub(r'cdef (.+?) \*?([A-Za-z_]\w*)\(',r'def \2(',line,1)
   line=re.sub(r' (?:except NULL|except \*|except\? 0|noexcept)(?: nogil)?:',':',line)
   # Remove typed pointer and scalar parameter prefixes from finite headers.
   line=re.sub(r'\b(?:const void|unsigned int|object|bint|size_t|Py_ssize_t|int64_t|int32_t|uint32_t|uint64_t|ColdRow|char|OrderArena|MessageArena|DeliveryRow|OrderSlot|MessageSlot)\s*\*{0,2}\s*([A-Za-z_]\w*)',r'\1',line)
  elif re.match(r'\s*def ',line):
   line=re.sub(r'\b(?:OrderArena|MessageArena|NativeTrader|NativeExchange|NativeLevel|NativeBook) ([A-Za-z_]\w*)',r'\1',line)
  elif re.match(r'\s*cdef ',line):
   if '=' in line:line=re.sub(r'cdef .+? \*?([A-Za-z_]\w*)\s*=',r'\1 =',line)
   else:lines.append('');continue
  line=re.sub(r'<(?:NativeTrader|NativeExchange|NativeBook|NativeLevel|OrderSlot|MessageSlot|DeliveryRow|PyObject|object|uint64_t|uint32_t|size_t|int64_t|int32_t|ColdRow|unsigned char|char)\s*\*{0,2}>','',line)
  line=re.sub(r'sizeof\([^)]*\)', '1',line)
  line=re.sub(r'&(self\._rows\[[^\]]+\]|self\._chunks\[[^\]]+\]\[[^\]]+\]|self\._rows\[i\])',r'\1',line)
  line=re.sub(r'&([A-Za-z_]\w*)',r'\1',line)
  lines.append(line)
 return ast.parse('\n'.join(lines))
source=(D/'dynamic_arena_chain.pyx').read_text()
try:
 tree=normalize(source)
 print('normalized source Python AST parse only PASS')
except SyntaxError as e:
 print(e)
 raise
