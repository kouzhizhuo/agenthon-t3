# Prepared cold native output controls

These checks will compare the final files with the original simulator and check
that the faster output step does not change values or their order. They are ready
as source for a future Linux test; none has run and none measures market speed.

These Python files are prepared source, not locally executed tests. Run only in
the actual pinned Linux construction/runtime under the root-owned test wrapper.

`native_output_fixtures_v1.py` starts separate original and native processes. The
original process uses its own baseline runtime, genuine trace extractors and
pandas writer. The native process loads the source/ELF-bound built extension and
uses its genuine cold projectors and production Arrow writer. Full Parquet bytes,
explicit expected rows and independent pandas dtype/value readback must match.

Fixtures cover reverse execution timestamps, equal timestamp/order ID records
across owners, final-execution winner, quote overwrite with first insertion order,
order ID -1 ties, exact timestamp coercion, missing IDs, Side/string normalization,
signed trace limits, duplicate ledger keys retaining their final sequence, stable
sequence ties, unselected nonkey values, all-null nullable integers, empty/null/
UTF8 strings, bitmaps across the ninth row and signed integer extrema.

The native child checks byte-owned immutable descriptors, numeric null bytes,
bitmap padding, unsealed public construction rejection and readonly fields. It
destroys source state, episode and ledger before writing, then destroys owners
and verifies retained output bytes again. Hostile end-state/map keys and invalid
scalar/overflow domains must decline without callbacks. Ordinary native children
reject any pandas/scipy import attempt.

Fixture owners are allocated via genuine extension `__new__` for isolated cold
packing. They are explicitly uninitialized and make no market ownership claim.
`controls.py` independently runs six complete actual markets through original,
light canonical, light dynamic, repeat and each forced projector decline. It
requires authenticated initialized native owners, positive actual arenas,
dynamic/repeat diagnostics equality, full STATE and both output bytes equality,
one market only, readonly authoritative graph and restored process bindings.

No fixture or source audit establishes runtime ABI success, throughput, official
score, threshold satisfaction or ranking. Those require saved actual build and
whole-market measurements from the root-owned wrapper.
