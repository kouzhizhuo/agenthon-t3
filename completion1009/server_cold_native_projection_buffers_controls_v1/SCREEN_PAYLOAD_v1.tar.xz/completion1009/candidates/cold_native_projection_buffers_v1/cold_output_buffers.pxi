"""Cold only exact primitive projection/packing; no business append changes."""
from libc.stdint cimport int64_t, int32_t
from libc.stdlib cimport qsort
from cpython.bytearray cimport PyByteArray_AS_STRING

cdef class NativeColumns:
    def __cinit__(self):
        self.kind = None
        self.n_rows = 0
        self.fields = ()
        self._sealed = False

    def __init__(self):
        raise TypeError("native output columns are created only by exact cold projection")

    def sealed(self):
        return bool(self._sealed)


cdef bint _cold_integer(object value, unsigned int bits, bint exact53=False) except *:
    actual = type(value)
    if actual is not int and actual is not np.int64 and actual is not np.int32:
        return False
    if exact53 and not -9007199254740992 <= value <= 9007199254740992:
        return False
    if bits == 32:
        return -2147483648 <= value < 2147483648
    return -9223372036854775808 <= value < 9223372036854775808


cdef object _cold_timestamp(object value):
    actual = type(value)
    if actual is int or actual is bool or actual is np.int64:
        if -9223372036854775808 <= value < 9223372036854775808: return int(value)
        return None
    if actual is float or actual is np.int32 or value is None or actual is str:
        return 0
    return None


cdef unsigned int _cold_side(object value) except *:
    if value is None: return 0
    if type(value) is Side: return 1 if value.value == 'BID' else 2
    text = value.upper()
    if 'BID' in text: return 1
    if 'ASK' in text: return 2
    return 0


cdef unsigned int _cold_event(object value) except *:
    if value == 'ORDER_SUBMITTED': return 1
    if value == 'ORDER_ACCEPTED': return 2
    if value == 'ORDER_FILLED': return 3
    if value == 'PARTIAL_FILL': return 4
    if value == 'ORDER_CANCELLED': return 5
    if value == 'ORDER_REPLACED': return 6
    if value == 'QUOTE_UPDATE': return 7
    if value == 'ORDER_EXECUTED': return 8
    return 0


cdef int _cold_compare(const void *left, const void *right) noexcept nogil:
    cdef ColdRow *a = <ColdRow *>left
    cdef ColdRow *b = <ColdRow *>right
    if a.primary < b.primary: return -1
    if a.primary > b.primary: return 1
    if a.secondary < b.secondary: return -1
    if a.secondary > b.secondary: return 1
    if a.category < b.category: return -1
    if a.category > b.category: return 1
    if a.ordinal < b.ordinal: return -1
    if a.ordinal > b.ordinal: return 1
    return 0


cdef void _cold_reserve(ColdRow **rows, size_t *capacity, size_t required) except *:
    cdef size_t grown
    cdef ColdRow *replacement
    if required <= capacity[0]: return
    grown = 1024 if capacity[0] == 0 else capacity[0]
    while grown < required:
        if grown > <size_t>sys.maxsize // 2: raise OverflowError("native cold row capacity")
        grown *= 2
    if grown > <size_t>sys.maxsize // sizeof(ColdRow): raise OverflowError("native cold row allocation")
    replacement = <ColdRow *>realloc(rows[0], grown * sizeof(ColdRow))
    if replacement == NULL: raise MemoryError("native cold row reserve")
    rows[0] = replacement
    capacity[0] = grown


cdef NativeColumns _cold_columns():
    cdef NativeColumns result = NativeColumns.__new__(NativeColumns)
    return result


cdef void _cold_put(char *data, size_t row, int64_t value, unsigned int width) noexcept:
    cdef uint64_t unsigned_value = <uint64_t>value
    cdef unsigned int shift
    for shift in range(width):
        data[row * width + shift] = <char>((unsigned_value >> (shift * 8)) & 255)


cdef object _cold_numeric(ColdRow *rows, size_t n, unsigned int field):
    cdef unsigned int width = 4 if field == 1 else 8
    cdef size_t index
    cdef int64_t value
    cdef char *target
    if n > <size_t>sys.maxsize // width: raise OverflowError("native numeric output size")
    packed = bytearray(n * width)
    target = PyByteArray_AS_STRING(packed)
    for index in range(n):
        if field == 0: value = rows[index].primary
        elif field == 1: value = rows[index].agent_id
        elif field == 4: value = rows[index].price
        elif field == 5: value = rows[index].quantity
        else: value = rows[index].secondary
        _cold_put(target, index, value, width)
    return ('int32' if width == 4 else 'int64', None, None, bytes(packed), 0)


cdef object _cold_string_capacity(size_t used, Py_ssize_t length):
    # Check signed length before conversion and subtraction; never permit
    # unsigned wraparound to admit an oversized single encoded value.
    return length >= 0 and length < 2147483648 and used <= <size_t>(2147483648 - 1) - <size_t>length


cdef object _cold_trace_string(ColdRow *rows, size_t n, bint side):
    cdef size_t index, used = 0
    cdef Py_ssize_t length
    cdef unsigned int code
    cdef char *offset_data
    cdef char *validity_data
    cdef int64_t nulls = 0
    if n >= <size_t>sys.maxsize // 4: raise OverflowError("native string offset size")
    offsets = bytearray((n + 1) * 4)
    validity = bytearray((n + 7) // 8)
    payload = bytearray()
    offset_data = PyByteArray_AS_STRING(offsets)
    validity_data = PyByteArray_AS_STRING(validity)
    events = (b'', b'ORDER_SUBMITTED', b'ORDER_ACCEPTED', b'ORDER_FILLED', b'PARTIAL_FILL', b'ORDER_CANCELLED', b'ORDER_REPLACED', b'QUOTE_UPDATE')
    sides = (b'', b'BID', b'ASK')
    for index in range(n):
        code = rows[index].side if side else rows[index].event
        if side and code == 0:
            nulls += 1
        else:
            validity_data[index >> 3] = <char>(<unsigned char>validity_data[index >> 3] | (1 << (index & 7)))
            encoded = sides[code] if side else events[code]
            length = len(encoded)
            if not _cold_string_capacity(used, length):
                raise OverflowError("native canonical UTF8 offsets exceed signed32")
            payload.extend(encoded)
            used += length
        _cold_put(offset_data, index + 1, <int64_t>used, 4)
    return ('string', bytes(validity) if nulls else None, bytes(offsets), bytes(payload), nulls)


def cold_trace_buffers(end_state, episode):
    cdef ColdRow *rows = NULL
    cdef size_t n = 0
    cdef size_t capacity = 0
    cdef size_t order_n, index, winner
    cdef unsigned int event, side
    cdef int64_t timestamp_value, oid_value
    cdef NativeColumns result
    if (type(episode) is not _observer.Episode or type(end_state) is not dict
            or any(type(key) is not str for key in end_state)):
        return 'inactive-or-untrusted-trace-state'
    if (type(end_state.get('agents')) is not list or type(episode.contract) is not dict
            or type(episode.has_scalar) is not bool):
        return 'inactive-or-untrusted-trace-state'
    roster = end_state['agents']
    if (not roster or type(roster[0]) is not NativeExchange
            or any(type(owner) is not NativeTrader for owner in roster[1:])):
        return 'untrusted-native-owner-roster'
    owner_ids = {id(owner) for owner in roster}
    if len(owner_ids) != len(roster) or any(id(owner) not in owner_ids for owner in episode.contract):
        return 'untrusted-native-contract-owner'
    winners, quotes = {}, {}
    try:
        for owner in end_state['agents']:
            records = episode.contract.get(owner, ())
            if type(records) is not list and type(records) is not tuple: return 'untrusted-contract-records'
            for record in records:
                if type(record) is not tuple or len(record) != 4: return 'untrusted-contract-record'
                timestamp, event_type, kind, values = record
                if type(event_type) is not str or type(kind) is not str or type(values) is not tuple:
                    return 'untrusted-contract-fields'
                normalized_time = _cold_timestamp(timestamp)
                if normalized_time is None: return 'untrusted-timestamp-type-or-range'
                timestamp_value = normalized_time
                if kind == 'raw': return 'legacy-raw-record'
                if kind == 'order' or kind == 'market':
                    if len(values) != 6: return 'order-shape'
                    aid, oid, side_value, quantity, limit_price, fill_price = values
                    if oid is None: continue
                    if aid is None: aid = owner.id
                    price = fill_price if event_type == 'ORDER_EXECUTED' else limit_price
                    if (not _cold_integer(oid, 64, True) or not _cold_integer(aid, 32, True)
                            or not _cold_integer(quantity, 64, True)
                            or (price is not None and not _cold_integer(price, 64, True))
                            or (type(side_value) is not Side and type(side_value) is not str and side_value is not None)):
                        return 'legacy-order-inference'
                    event = _cold_event(event_type)
                    if event == 0: return 'unknown-canonical-event'
                    side = _cold_side(side_value)
                    _cold_reserve(&rows, &capacity, n + 1)
                    rows[n].primary = timestamp_value
                    rows[n].secondary = oid
                    rows[n].agent_id = aid
                    rows[n].price = 0 if price is None else price
                    rows[n].quantity = quantity
                    rows[n].event = 4 if event == 8 else event
                    rows[n].side = side
                    rows[n].category = 0
                    rows[n].ordinal = n
                    if event == 8:
                        previous = winners.get(int(oid))
                        winner = 0 if previous is None else previous
                        if previous is None or rows[winner].primary <= timestamp_value:
                            winners[int(oid)] = n
                    n += 1
                elif kind == 'quote':
                    if len(values) != 3: return 'quote-shape'
                    symbol, price, quantity = values
                    if (type(symbol) is not str or ',' in symbol or not _cold_integer(price, 64, True)
                            or not _cold_integer(quantity, 64, True) or not _cold_integer(owner.id, 32, True)):
                        return 'legacy-quote-inference'
                    side = 1 if event_type == 'BEST_BID' else 2
                    # Dict assignment retains first key insertion position.
                    quotes[(int(timestamp_value), side)] = (owner.id, price, quantity)
                else: return 'unknown-contract-kind'
        if n == 0 or not episode.has_scalar: return 'legacy-empty-or-scalar-inference'
        for selected in winners.values():
            winner = selected
            rows[winner].event = 3
        order_n = n
        for key, values in quotes.items():
            _cold_reserve(&rows, &capacity, n + 1)
            rows[n].primary = key[0]
            rows[n].secondary = -1
            rows[n].agent_id = values[0]
            rows[n].price = values[1]
            rows[n].quantity = values[2]
            rows[n].event = 7
            rows[n].side = key[1]
            rows[n].category = 1
            rows[n].ordinal = n - order_n
            n += 1
        qsort(rows, n, sizeof(ColdRow), _cold_compare)
        result = _cold_columns()
        result.kind = 'trace'
        result.n_rows = n
        result.fields = (_cold_numeric(rows, n, 0), _cold_numeric(rows, n, 1),
            _cold_trace_string(rows, n, False), _cold_trace_string(rows, n, True),
            _cold_numeric(rows, n, 4), _cold_numeric(rows, n, 5), _cold_numeric(rows, n, 6))
        result._sealed = True
        return result
    finally:
        if rows != NULL: free(rows)


cdef object _cold_message_field(object column, ColdRow *rows, size_t n, object dtype):
    cdef size_t index, used = 0
    cdef unsigned int width = 4 if dtype == 'int32' else 8
    cdef int64_t nulls = 0, numeric
    cdef Py_ssize_t utf8_n
    cdef char *data_pointer
    cdef char *validity_pointer
    cdef char *offset_pointer
    if n > <size_t>sys.maxsize // width or n >= <size_t>sys.maxsize // 4:
        raise OverflowError('native message buffer size')
    data = bytearray() if dtype == 'string' else bytearray(n * width)
    offsets = bytearray((n + 1) * 4) if dtype == 'string' else None
    validity = bytearray((n + 7) // 8)
    validity_pointer = PyByteArray_AS_STRING(validity)
    data_pointer = NULL if dtype == 'string' else PyByteArray_AS_STRING(data)
    offset_pointer = PyByteArray_AS_STRING(offsets) if dtype == 'string' else NULL
    cache = {}
    for index in range(n):
        value = rows[index].primary if column is None else column[rows[index].ordinal]
        if value is None:
            if dtype != 'string' and dtype != 'Int64': return 'legacy-message-integer-inference'
            nulls += 1
        else:
            validity_pointer[index >> 3] = <char>(<unsigned char>validity_pointer[index >> 3] | (1 << (index & 7)))
            if dtype == 'string':
                if type(value) is not str: return 'legacy-message-string-inference'
                encoded = cache.get(value)
                if encoded is None:
                    encoded = value.encode('utf8')
                    if len(cache) < 256: cache[value] = encoded
                utf8_n = len(encoded)
                if not _cold_string_capacity(used, utf8_n):
                    raise OverflowError('native canonical UTF8 offsets exceed signed32')
                data.extend(encoded)
                used += utf8_n
            else:
                if not _cold_integer(value, 32 if dtype == 'int32' else 64): return 'legacy-message-integer-inference'
                numeric = value
                _cold_put(data_pointer, index, numeric, width)
        if dtype == 'string': _cold_put(offset_pointer, index + 1, <int64_t>used, 4)
    return (dtype, bytes(validity) if nulls else None, bytes(offsets) if offsets is not None else None, bytes(data), nulls)


def cold_message_buffers(end_state, ledger_type):
    cdef ColdRow *rows = NULL
    cdef size_t n = 0
    cdef size_t capacity = 0
    cdef size_t index, source_n
    cdef NativeColumns result
    if (ledger_type is not ColumnLedger or type(end_state) is not dict
            or any(type(key) is not str for key in end_state)):
        return 'legacy-ledger-type'
    if type(end_state.get('message_ledger')) is not ColumnLedger:
        return 'legacy-ledger-type'
    source = end_state['message_ledger'].columns
    seqmap = end_state.get('deliver_seq_by_key')
    if (type(source) is not tuple or len(source) != 9 or any(type(c) is not list for c in source)
            or type(seqmap) is not dict or len({id(c) for c in source}) != 9):
        return 'untrusted-ledger-containers-or-aliases'
    for key, value in seqmap.items():
        if type(key) is not tuple or len(key) != 2 or type(key[0]) is not int or type(key[1]) is not int or type(value) is not int:
            return 'untrusted-delivery-map-key-or-value'
    source_n = len(source[0])
    if any(len(c) != source_n for c in source): return 'ledger-column-lengths'
    try:
        for index in range(source_n):
            mid, dst = source[0][index], source[2][index]
            if not _cold_integer(mid, 64) or not _cold_integer(dst, 32): return 'legacy-ledger-key-inference'
            sequence = seqmap.get((int(mid), int(dst)))
            if sequence is not None:
                if not _cold_integer(sequence, 64): return 'legacy-sequence-inference'
                _cold_reserve(&rows, &capacity, n + 1)
                rows[n].primary = sequence
                rows[n].secondary = 0
                rows[n].category = 0
                rows[n].ordinal = index
                n += 1
        if n == 0: return 'legacy-empty-message-output'
        qsort(rows, n, sizeof(ColdRow), _cold_compare)
        fields = []
        for position, dtype in ((-1, 'int64'), (4, 'int64'), (3, 'Int64'), (5, 'int64'),
                (1, 'int32'), (2, 'int32'), (0, 'int64'), (6, 'string'), (7, 'Int64'), (8, 'Int64')):
            descriptor = _cold_message_field(None if position == -1 else source[position], rows, n, dtype)
            if type(descriptor) is str: return descriptor
            fields.append(descriptor)
        result = _cold_columns()
        result.kind = 'message_trace'
        result.n_rows = n
        result.fields = tuple(fields)
        result._sealed = True
        return result
    finally:
        if rows != NULL: free(rows)
