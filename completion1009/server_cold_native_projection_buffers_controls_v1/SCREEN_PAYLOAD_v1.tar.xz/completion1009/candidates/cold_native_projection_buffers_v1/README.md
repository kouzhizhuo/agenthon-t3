# Cold native canonical projection buffers V1, unfinished source

This version aims to make the final output step faster while preserving every
market result. It keeps the market simulation unchanged and converts completed
records directly into the same Parquet files. It is prepared source only: real
Linux compilation, output comparisons and complete timing are still required.

Fresh source branch of the frozen lightweight dynamic composite V1. The full
donor native pyx is preserved as an exact prefix, followed by an included cold
projection module. Market producers, RNG, book, scheduler, message/order ownership
and original initialization are unchanged. No primitive append shadow is added.

The new final projection validates the same primitive tuples and actual dynamic
ColumnLedger, selects the exact final execution/quote/sequence rows, applies a
total native row sort representing original stable ties, and packs immutable
little-endian numeric/validity/UTF8 buffers. The Python boundary still verifies
same source/ELF owner roster and selects complete trace/message pair fallback
before writing. PyArrow uses the same actual pinned schema and Parquet defaults.

Trace selection uses roster/local encounter order, greatest execution timestamp
then last equal-timestamp encounter, quote dictionary payload overwrite with
first key order retained, and `(time, order_id, order-or-quote, ordinal)` sort.
Message duplicates sharing a final `(message_id,dst_id)` sequence remain distinct
and sort by `(final sequence, original ledger index)`. Input range validation
precedes native signed conversion. Payload storage returned to Arrow is exact
immutable bytes, which owns data independently of native temporary rows and the
finished observer episode.

Prepared isolated output controls compare actual original and native writers in
separate processes, covering stable ties, signed limits, nullable values, UTF8,
immutable byte lifetime and domain refusal without callbacks. The separate six
whole-market controls require initialized native authority, unchanged full state,
positive arena use, repeat equivalence and complete two-output fallback. All are
prepared source and have not run. Both launch verbs remain `simulate` and
`simulate-batch`; the offline runtime must retain exact seven-column order trace,
ten-column message trace, event strings, dtype/schema/null/order and Snappy output.

This directory is not frozen or deployable yet. It has only source implementation
and source-only normalized lexical checks. Remaining work includes complete
authentication/pins/receipt refresh, native serializer boundary controls,
independent source review, real pinned Cython translation, real native construction,
actual whole-market/fallback equivalence and actual full-entry timing. No speed,
score, rank or submission claim is made.
