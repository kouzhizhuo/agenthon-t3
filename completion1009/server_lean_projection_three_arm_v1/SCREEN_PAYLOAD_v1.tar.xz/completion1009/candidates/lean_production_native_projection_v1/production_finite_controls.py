"""Exact 38 projection fixtures exercise the production wrapper, untimed."""
import argparse
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent

def cases(np, Side):
    def order(t, oid, quantity=3, kind="ORDER_EXECUTED", aid=0, side=Side.BID, price=100, fill=101):
        return (t, kind, "order", (aid, oid, side, quantity, price, fill))
    def quote(t, side="BEST_BID", price=99, quantity=4, symbol="ABM"):
        return (t, side, "quote", (symbol, price, quantity))
    yield "basic_lifecycle", [(0, [order(1, 4, kind="ORDER_SUBMITTED"), order(2, 4, kind="ORDER_ACCEPTED"), order(3, 4)])], True, True
    yield "unsorted_max_time_and_tied_final", [(0, [order(20, 4, 1), order(10, 4, 2), order(20, 4, 3)])], True, True
    yield "equal_time_cross_agent_final_emission", [(1, [order(10, 4, 1)]), (0, [order(10, 4, 2)])], True, True
    yield "negative_order_id_quote_collision", [(0, [order(10, -1), quote(10), order(10, -1, 5)])], True, True
    yield "quote_last_write_first_insertion_tie", [(0, [quote(10, "BEST_ASK", 101), order(10, -1), quote(10, price=99), quote(10, "BEST_ASK", 102)])], True, True
    yield "duplicate_quote_across_agents", [(1, [quote(10, price=98), order(11, 4)]), (2, [quote(10, price=99)])], True, True
    yield "mixed_all_order_kinds", [(0, [order(i, 4, kind=k) for i, k in enumerate(("ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_CANCELLED", "ORDER_REPLACED", "ORDER_EXECUTED"))])], True, True
    yield "missing_order_id_skips", [(0, [order(1, None), order(2, 5)])], True, True
    yield "agent_id_none_fallback", [(19, [order(1, 5, aid=None)])], True, True
    yield "market_missing_limit_price", [(0, [(1, "ORDER_SUBMITTED", "market", (0, 4, Side.BID, 3, None, None)), order(2, 4)])], True, True
    yield "missing_fill_price_zero", [(0, [order(1, 4, fill=None)])], True, True
    yield "nullable_side_string_array", [(0, [order(1, 4, side=None), order(2, 5, side="strange")])], True, True
    yield "side_bid_precedence", [(0, [order(1, 4, side="ask-bid"), order(2, 5, side="aSk")])], True, True
    yield "numpy_integral_types", [(np.int32(0), [order(np.int64(1612517400000000001), np.int64(4), np.int32(3), aid=np.int32(0), price=np.int64(100))])], True, True
    yield "int64_timestamp_extremes", [(0, [order(-(1 << 63), 4), order((1 << 63) - 1, 4)])], True, True
    yield "timestamp_npint32_original_zero", [(0, [order(np.int32(123), 4)])], True, True
    yield "bool_timestamp_original_integer", [(0, [order(True, 4)])], True, True
    yield "noninteger_timestamp_original_zero", [(0, [order("123", 4)])], True, True
    yield "integer53_edges", [(0, [order(1, -(1 << 53), quantity=(1 << 53), price=-(1 << 53)), order(2, (1 << 53))])], True, True
    yield "agent_int32_edges", [(-(1 << 31), [order(1, 4, aid=None)]), ((1 << 31) - 1, [order(2, 5, aid=None)])], True, True
    yield "rehash_many_fill_and_quote_keys", [(0, [record for i in range(160) for record in (order(200 - i, i), quote(i), order(200 - i, i, 5))])], True, True
    yield "many_equal_keys_stable", [(0, [order(10, 4, i) for i in range(140)])], True, True
    yield "large_negative_sort_keys", [(0, [order(t, oid) for t, oid in ((-4, -1), (-5, 7), (-4, -9), (-5, -1))])], True, True
    yield "single_row_sort_zero_passes", [(0, [order(1, 4)])], True, True
    yield "raw_field_override_replay", [(0, [(1, "ORDER_EXECUTED", "raw", {"EventTime": 3, "order_id": 4, "agent_id": 0, "side": Side.BID, "quantity": 2, "fill_price": 100})])], True, False
    yield "raw_array_original_exception", [(0, [(1, "ORDER_EXECUTED", "raw", np.array([1, 2]))])], True, False
    yield "out_of_integer53_replay", [(0, [order(1, (1 << 53) + 1)])], True, False
    yield "out_of_int32_agent_replay", [(0, [order(1, 4, aid=(1 << 31))])], True, False
    yield "float_quantity_replay", [(0, [order(1, 4, quantity=3.5)])], True, False
    yield "boolean_quantity_replay", [(0, [order(1, 4, quantity=True)])], True, False
    yield "quote_comma_symbol_replay", [(0, [order(1, 4), quote(2, symbol="A,B")])], True, False
    yield "quote_float_price_replay", [(0, [order(1, 4), quote(2, price=99.)])], True, False
    yield "absent_scalar_inference_replay", [(0, [order(1, 4)])], False, False
    yield "empty_contract_replay", [(0, [])], True, False
    yield "quotes_only_replay", [(0, [quote(1)])], True, False
    yield "huge_timestamp_replay", [(0, [order(1 << 63, 4)])], True, False
    class CallbackInteger(int):
        def __int__(self):
            raise RuntimeError("original timestamp integer callback")
    yield "integer_timestamp_callback_replay", [(0, [order(CallbackInteger(10), 4)])], True, False
    yield "large_uint64_timestamp_original_zero", [(0, [order(np.uint64((1 << 63) + 3), 4)])], True, False

def outcome(operation, pd):
    try:
        frame = operation()
        stream = io.BytesIO()
        frame.to_parquet(stream, compression="snappy", index=False)
        return {"kind": "frame", "frame": frame, "bytes": stream.getvalue()}
    except Exception as error:
        return {"kind": "exception", "type": type(error).__name__, "message": str(error)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("new production finite result required")
    sys.path.insert(0, str(HERE / "runtime"))
    from bootstrap import activate
    activate()
    import numpy as np
    import pandas as pd
    import observer
    from abides_fork import trace
    from abides_markets.orders import Side, Order
    from abides_core.message import Message
    from production_projection import begin_projection, extract_projection, episode_probes, reset_probes
    from production_loader import native_receipt
    result = {"schema": "t3-lean-production-native-projection-finite-v1", "cases": [], "admission_checks": [], "failures": [],
        "market_executed": False, "timing_claim": False, "rankable": False,
        "runtime_mutation_audits_claimed": False}
    fixture_scenario = {"agent_configs": [{"agent_type": "NoiseTrader", "count": 1}]}
    # These checks exercise actual JSON-domain admission, separately from the
    # unchanged 38 record fixtures. No custom callback is a JSON input.
    json_cases = (
        ("four_strategies", {"agent_configs": [{"agent_type": name, "count": 1} for name in
            ("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader")]}, True),
        ("zero_count", {"agent_configs": [{"agent_type": "NoiseTrader", "count": 0}]}, True),
        ("boolean_count_declines", {"agent_configs": [{"agent_type": "NoiseTrader", "count": True}]}, False),
        ("float_count_declines", {"agent_configs": [{"agent_type": "NoiseTrader", "count": 1.0}]}, False),
        ("negative_count_declines", {"agent_configs": [{"agent_type": "NoiseTrader", "count": -1}]}, False),
        ("unknown_strategy_declines", {"agent_configs": [{"agent_type": "Unknown", "count": 1}]}, False),
        ("string_count_declines", {"agent_configs": [{"agent_type": "NoiseTrader", "count": "1"}]}, False),
        ("empty_agents_declines", {"agent_configs": []}, False),
        ("array_root_declines", [], False),
        ("missing_agents_declines", {}, False),
    )
    for name, value, expected in json_cases:
        admitted = observer.begin_episode(json.loads(json.dumps(value)))
        assert type(admitted) is bool and admitted is expected, "JSON admission differs: " + name
        assert (observer.STATE is not None) is expected, "observer state admission differs: " + name
        assert begin_projection(False, admitted) is False, "disabled parent admission differs"
        if not expected:
            assert begin_projection(True, admitted) is False, "declined JSON enabled native projection"
        result["admission_checks"].append({"name": name, "passed": True, "admitted": admitted})
        observer.finish_episode()
    for name, groups, has_scalar, active in cases(np, Side):
        admitted = observer.begin_episode(json.loads(json.dumps(fixture_scenario)))
        assert admitted is True, "normal fixture JSON declined"
        state = observer.STATE
        agents = [type("FixtureAgent", (), {"id": aid})() for aid, _ in groups]
        for agent, (_, records) in zip(agents, groups):
            state.contract[agent] = records
            state.inference[agent] = [(0, "AGENT_TYPE", "raw", "fixture")] + records if has_scalar else records
        state.has_scalar = has_scalar
        end_state = {"agents": agents}
        original_state = deepcopy(groups)
        ids_before = (Order._order_id_counter, Message._Message__message_id_counter)
        reset_probes()
        begin_projection(True, admitted)
        try:
            expected = outcome(lambda: trace.extract_trace(end_state), pd)
            actual = outcome(lambda: extract_projection(end_state), pd)
            assert expected["kind"] == actual["kind"], "frame/exception kind differs"
            if actual["kind"] == "frame":
                pd.testing.assert_frame_equal(expected["frame"], actual["frame"], check_exact=True, check_dtype=True, rtol=0, atol=0)
                assert expected["bytes"] == actual["bytes"], "Parquet bytes differ"
            else:
                assert (expected["type"], expected["message"]) == (actual["type"], actual["message"]), "original exception differs"
            assert (Order._order_id_counter, Message._Message__message_id_counter) == ids_before, "UID side effect"
            for (_, before_rows), (_, after_rows) in zip(original_state, groups):
                for a, b in zip(before_rows, after_rows):
                    if isinstance(a[3], np.ndarray): assert a[3].tobytes() == b[3].tobytes()
                    else: assert a == b
            witness = episode_probes()[-1] if actual["kind"] == "frame" else None
            if witness is not None:
                assert witness["native_projection_active"] is active
                if active:
                    assert witness["python_sort_key_callbacks"] == 0
                    assert witness["typed_numeric_write_rows"] == len(actual["frame"])
                    assert witness["native_load_count"] == 1
            result["cases"].append({"name": name, "passed": True, "kind": actual["kind"], "witness": witness})
        except Exception as error:
            result["failures"].append({"name": name, "type": type(error).__name__, "message": str(error)})
        finally:
            observer.STATE = None
    result["native_receipt"] = native_receipt()
    result["all_passed"] = (not result["failures"] and len(result["cases"]) == 38
        and len(result["admission_checks"]) == 10 and all(row["passed"] for row in result["admission_checks"]))
    result["controls_source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
