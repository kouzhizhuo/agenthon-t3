"""Fresh-process three-arm entry and untimed six-arm complete-state controls."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys

ROOT = Path("/opt/projection-screen/completion1009/candidates")
FROZEN = ROOT / "production_native_projection_v1"
LEAN = ROOT / "lean_production_native_projection_v1"
DONOR = ROOT / "native_canonical_projection_v2"
ARMS = ("production_native", "lean_native", "lean_observer")
MARKER = "T3_LEAN_PROJECTION_THREE_ARM_SCREEN="


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def controls(receipt):
    output = Path("/output/controls")
    if output.exists(): raise ValueError("fresh controls output required")
    output.mkdir()
    report = {"schema": "t3-lean-projection-three-arm-controls-v1", "cases": [], "failures": [],
        "rankable": False, "timing_claim": False, "official_gate": False}
    def launch(source, arguments, log):
        with log.open("xb") as stream:
            result = subprocess.run([sys.executable, "-B", str(source), *arguments],
                stdout=stream, stderr=subprocess.STDOUT, cwd=str(source.parent),
                env=dict(os.environ), timeout=900)
        if result.returncode: raise ValueError("fresh control worker failed: " + str(log))
    try:
        # One donor control invocation: 56 proof fixtures and four parent/native
        # markets, followed by two independent 38-normal production paths.
        launch(DONOR / "controls.py", ["--receipt", str(receipt), "--out", str(output / "proof")], output / "proof.log")
        for label, candidate in (("frozen", FROZEN), ("lean", LEAN)):
            launch(candidate / "production_finite_controls.py", ["--out", str(output / (label + "_FINITE_RESULT.json"))],
                output / (label + "-finite.log"))
            for arm in ("parent", "native"):
                launch(candidate / "production_semantic_worker.py", ["--runtime", str(candidate / "runtime"),
                    "--receipt", str(receipt), "--arm", arm, "--out", str(output / (label + "_" + arm))],
                    output / (label + "_" + arm + ".log"))
        finite_proof = json.loads((output / "proof/FINITE_RESULT.json").read_text())
        frozen_finite = json.loads((output / "frozen_FINITE_RESULT.json").read_text())
        lean_finite = json.loads((output / "lean_FINITE_RESULT.json").read_text())
        assert finite_proof["all_passed"] and len(finite_proof["cases"]) == 56
        assert frozen_finite["all_passed"] and len(frozen_finite["cases"]) == 38
        assert lean_finite["all_passed"] and len(lean_finite["cases"]) == 38
        assert len(lean_finite["admission_checks"]) == 10 and all(row["passed"] for row in lean_finite["admission_checks"])
        folders = (output / "proof/parent", output / "proof/native", output / "frozen_parent",
                   output / "frozen_native", output / "lean_parent", output / "lean_native")
        values = [pickle.loads((folder / "SEMANTIC_VALUES.pkl").read_bytes()) for folder in folders]
        # Only exact authored worker data is read in this untimed control
        # process. Saved-evidence auditing uses an inert protocol decoder.
        sys.path.insert(0, str(LEAN / "runtime"))
        from bootstrap import activate
        activate()
        import pandas as pd
        assert all(len(rows) == 4 for rows in values)
        for index, seed in enumerate((81009, 82009, 83009, 84009)):
            rows = [group[index] for group in values]
            expected = rows[0]
            assert all(row["seed"] == seed for row in rows)
            for actual in rows[1:]:
                assert expected["details"] == actual["details"], "complete details differ"
                assert len(expected["frames"]) == len(actual["frames"]) == 2
                for before, after in zip(expected["frames"], actual["frames"]):
                    pd.testing.assert_frame_equal(before, after, check_exact=True, check_dtype=True, rtol=0, atol=0)
                assert len(expected["payload"]) == len(actual["payload"]) == 9
                assert expected["payload"] == actual["payload"], "complete nine payload graphs differ"
            assert all(row["json_domain_admitted"] is True for row in rows[4:])
            report["cases"].append({"seed": seed, "passed": True, "six_way_complete_equal": True,
                "trace_rows": len(expected["frames"][0]), "message_rows": len(expected["frames"][1]),
                "details": expected["details"], "witnesses": {label: row["projection_witness"] for label, row in
                    zip(("proof_parent", "proof_native", "frozen_parent", "frozen_native", "lean_parent", "lean_native"), rows)},
                "lean_json_domain_admitted": [row["json_domain_admitted"] for row in rows[4:]]})
        report.update(all_passed=True, proof_finite_cases=56, frozen_finite_cases=38, lean_finite_cases=38,
            finite_record_cases=132, json_admission_checks=10, full_market_cases=4, full_market_episodes=24,
            full_control_arms=["proof_parent", "proof_native", "frozen_parent", "frozen_native", "lean_parent", "lean_native"],
            data_sha256={folder.relative_to(output).as_posix(): sha(folder / "SEMANTIC_VALUES.pkl") for folder in folders})
    except Exception as error:
        report["all_passed"] = False
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    report["controls_source_sha256"] = sha(Path(__file__))
    (output / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["all_passed"] else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("simulate", "simulate-batch"))
    parser.add_argument("--config")
    parser.add_argument("--out")
    parser.add_argument("--batch-dir")
    parser.add_argument("--out-dir")
    parser.add_argument("--mode", choices=(*ARMS, "controls"), required=True)
    args = parser.parse_args()
    receipt = DONOR / "artifacts/build_v2/BUILD_RECEIPT.json"
    os.environ["NATIVE_PROJECTION_BUILD_RECEIPT"] = str(receipt)
    if args.mode == "controls":
        if (args.verb != "simulate" or args.config != "/input/scenario.json"
                or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir
                or json.loads(Path(args.config).read_text()) != {"proof_command":
                    "lean-projection-three-arm-proof56-frozen38-lean38-json10-six-market-arms-v1"}):
            raise ValueError("fixed controls input required")
        raise SystemExit(controls(receipt))
    candidate = FROZEN if args.mode == "production_native" else LEAN
    sys.path.insert(0, str(candidate))
    single = args.verb == "simulate"
    if single:
        if args.config != "/input/scenario.json" or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir:
            raise ValueError("fixed single paths required")
    elif args.batch_dir != "/input/scenarios" or args.out_dir != "/output" or args.config or args.out:
        raise ValueError("fixed batch paths required")
    os.environ["NATIVE_PROJECTION_ENABLED"] = "0" if args.mode == "lean_observer" else "1"
    import production_cli as cli
    from production_projection import reset_probes, episode_probes
    reset_probes()
    result = (cli.simulate(args.config, args.out, started=cli.ENTRY_STARTED) if single
        else cli.simulate_batch(args.batch_dir, args.out_dir, started=cli.ENTRY_STARTED))
    episodes = episode_probes()
    if len(episodes) != (1 if single else result["n_scenarios"]):
        raise ValueError("actual projection episode roster differs")
    for witness in episodes:
        if witness.get("candidate") != candidate.name: raise ValueError("actual candidate origin differs")
        if args.mode != "lean_observer":
            if (witness.get("native_projection_active") is not True or witness.get("fallback_used") is not False
                    or witness.get("implementation") != "observer_contract_typed_rows_stable_merge_v1"
                    or witness.get("typed_numeric_write_rows") != witness.get("complete_trace_rows")
                    or witness.get("python_sort_key_callbacks") != 0 or witness.get("native_load_count") != 1):
                raise ValueError("actual native projection not observed")
        elif witness.get("native_projection_active") is not False: raise ValueError("lean observer used native projection")
    print(MARKER + json.dumps({"schema": "t3-lean-projection-three-arm-entry-v1", "arm": args.mode,
        "events": result, "episodes": episodes, "cli_source": str(candidate / "production_cli.py"),
        "entry_source": str(Path(__file__).resolve()), "rankable": False,
        "timing_scope": "CLI ENTRY_STARTED through Parquet/hash; unchanged sidecar cutoff; marker serialization outside CLI timer"},
        sort_keys=True, allow_nan=False), flush=True)


if __name__ == "__main__": main()
