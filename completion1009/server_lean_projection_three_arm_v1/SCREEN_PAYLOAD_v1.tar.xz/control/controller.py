"""Source-bound two-arm Linux projection screen; no official score or ranking claim."""
import argparse
import calendar
from datetime import datetime
import math
import statistics
import struct
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import sys
import uuid
from common import (BASE, BATCH, CANDIDATE, FROZEN, PARENT, DONOR, ARMS, ARM_CANDIDATES, IMAGE_CANDIDATE, MARKER, SINGLES,
                    TIMING_SCOPE, finite_names, json_admission_expected, RUNTIME_PINS_SHA256,
                    DONOR_RUNTIME_PINS_SHA256, arm_order, inventory, safe_name, sha, verify_payload, write)

PAYLOAD = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public


class StrictCommands(linux.DockerCommands):
    """Add finite process/file ulimits while keeping original launch checks."""
    def call(self, arguments, label, seconds=30, cleanup=False):
        if arguments and arguments[0] == "create":
            arguments = [arguments[0], "--ulimit", "nproc=256:256", "--ulimit",
                         "fsize=268435456:268435456", *arguments[1:]]
        return super().call(arguments, label, seconds, cleanup)

    def inspect(self, name, cleanup=False, seconds=30):
        info, command = super().inspect(name, cleanup, seconds)
        if info is not None and not cleanup and '--mode' in info.get('Config', {}).get('Cmd', []) and info.get('Config', {}).get('Entrypoint') != ['/usr/local/bin/python', '-B', '/opt/projection-screen/entry.py']:
            raise ValueError('actual screen entrypoint differs')
        if info is not None and not cleanup and info.get("Config", {}).get("Entrypoint") == ["/usr/local/bin/python", "-B", "/opt/projection-screen/entry.py"]:
            host = info["HostConfig"]
            limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
            expected = {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
            if any(limits.get(name) != value for name, value in expected.items()):
                raise ValueError("actual complete proof ulimits differ")
            mounts = info.get("Mounts", [])
            binds = [row for row in mounts if row.get("Destination") != "/tmp"]
            if (len(binds) != 2 or {row.get("Destination") for row in binds} != {"/input", "/output"}
                    or any(row.get("Type") != "bind" for row in binds)
                    or any(row.get("Type") != "tmpfs" for row in mounts if row.get("Destination") == "/tmp")):
                raise ValueError("proof mounts differ from input/output-only contract")
        return info, command


linux.DockerCommands = StrictCommands


def execute(args, command, prefix, seconds):
    row = linux.run_command(command, prefix, seconds, args.log_cap_bytes)
    write(prefix.with_name(prefix.name + ".json"), row)
    if not row["succeeded"]:
        raise RuntimeError("failed bounded command; diagnostics: " + str(prefix))
    return row


def image(args, requested, folder):
    folder.mkdir(parents=True)
    return linux.image_metadata(args, requested, folder)


def validate_donor_build(plan, copied, candidate):
    source = PAYLOAD / candidate
    if candidate == PARENT:
        manifest = public.read_json(source / "SNAPSHOT_MANIFEST.json")
        expected = {row["path"]: {k: row[k] for k in ("bytes", "sha256")} for row in manifest["files"]}
        if (len(expected) != 64 or sha(source / "SNAPSHOT_MANIFEST.json") != plan["parent_manifest_sha256"]
                or sha(copied / "SNAPSHOT_MANIFEST.json") != plan["parent_manifest_sha256"]
                or inventory(copied / "runtime") != expected):
            raise ValueError("actual selected observer parent source differs")
        proof = {"passed": True, "candidate": candidate, "runtime_files": expected,
            "parent_manifest_sha256": plan["parent_manifest_sha256"], "rankable": False, "timing_claim": False}
        write(copied / "BUILD_PROVENANCE.json", proof)
        return proof
    source_receipt = source / "SOURCE_PREPARATION_RECEIPT.json"
    if sha(source_receipt) != plan["source_receipt_sha256"] or sha(copied / source_receipt.name) != plan["source_receipt_sha256"]:
        raise ValueError("actual installed projection freeze receipt differs")
    for record in plan["source_files"]:
        installed = copied / safe_name(record["path"])
        if {"bytes": installed.stat().st_size, "sha256": sha(installed)} != {k: record[k] for k in ("bytes", "sha256")}:
            raise ValueError("actual complete projection source differs")
    receipt = public.read_json(copied / "artifacts/build_v2/BUILD_RECEIPT.json")
    spec = public.read_json(source / "compile_spec.json")
    bindings = public.read_json(copied / "SOURCE_PINS.json")
    expected_sources = {path.name: sha(path) for path in source.iterdir()
        if path.is_file() and not path.name.startswith("._")
        and (path.suffix in (".py", ".pyx", ".md") or path.name == "compile_spec.json")}
    if (receipt.get("schema") != "t3-native-canonical-projection-build-v2" or receipt.get("build_succeeded") is not True
            or receipt.get("candidate") != Path(candidate).name or receipt.get("candidate_sources") != expected_sources
            or receipt.get("cython") != spec["cython"] or spec["cython"] != "3.1.3"
            or spec["module"] != "native_projection" or spec["source"] != "native_projection.pyx"
            or receipt.get("ambient_flags", "").strip() != ""
            or receipt.get("compiler_configuration") != {"CC": "gcc", "CCSHARED": "-fPIC",
                "CFLAGS": "-Wsign-compare -DNDEBUG -g -fwrapv -O3 -Wall", "CXX": "g++", "LDSHARED": "gcc -shared"} or receipt.get("dependencies") != spec["dependencies"]
            or receipt.get("compile_flags") != spec["compile_flags"] or receipt.get("directives") != spec["directives"]
            or receipt.get("compile_spec_sha256") != sha(source / "compile_spec.json")
            or receipt.get("runtime_pins_sha256") != plan["runtime_pins_sha256"]
            or receipt.get("source_bindings_sha256") != sha(copied / "SOURCE_PINS.json")
            or receipt.get("market_execution") is not False or receipt.get("timing_claim") is not False
            or bindings.get("candidate_sources") != expected_sources or bindings.get("native_execution") is not False
            or bindings.get("runtime_pins_sha256") != plan["runtime_pins_sha256"]):
        raise ValueError("actual projection build receipt/source proof differs")
    abi = receipt["abi"]
    if (abi.get("implementation") != "cpython" or abi.get("version") != [3, 11, 17]
            or abi.get("platform") != "linux" or abi.get("machine") not in ("x86_64", "AMD64")
            or abi.get("pointer_bits") != 64 or abi.get("byteorder") != "little"
            or abi.get("cache_tag") != "cpython-311" or "cpython-311" not in abi.get("soabi", "")
            or "x86_64" not in abi.get("ext_suffix", "") or not abi.get("ext_suffix", "").endswith(".so")):
        raise ValueError("actual projection ABI is not pinned Linux amd64 CPython 3.11")
    build = copied / "artifacts/build_v2"
    record = receipt["extension"]
    extension = build / safe_name(record["path"])
    data = extension.read_bytes()
    if (extension.stat().st_size != record["bytes"] or sha(extension) != record["sha256"]
            or data[:7] != b"\x7fELF\x02\x01\x01" or struct.unpack_from("<HH", data, 16) != (3, 62)
            or extension.name != "native_projection" + abi["ext_suffix"] or b"PyInit_native_projection" not in data):
        raise ValueError("actual extracted projection extension bytes differ")
    generated = receipt.get("generated_c", {})
    if (len(generated) != 1 or any(sha(build / safe_name(name)) != digest
            or "Generated by Cython 3.1.3" not in (build / safe_name(name)).read_text()
            or "PyInit_native_projection" not in (build / safe_name(name)).read_text() for name, digest in generated.items())):
        raise ValueError("actual extracted generated C differs")
    pins = public.read_json(source / "RUNTIME_PINS.json")
    expected = {row["path"]: {k: row[k] for k in ("bytes", "sha256")} for row in pins["files"]}
    if len(expected) != 64 or pins["runtime_source_changes"] != 0 or inventory(copied / "runtime") != expected or sha(copied / "RUNTIME_PINS.json") != plan["runtime_pins_sha256"]:
        raise ValueError("actual projection unchanged parent runtime differs")
    proof = {"passed": True, "candidate": candidate, "build_receipt_sha256": sha(build / "BUILD_RECEIPT.json"),
        "source_bindings_sha256": sha(copied / "SOURCE_PINS.json"), "extension": record, "abi": abi,
        "generated_c": generated, "candidate_sources": expected_sources, "rankable": False, "timing_claim": False}
    write(copied / "BUILD_PROVENANCE.json", proof)
    return proof


def validate_build(plan, copied, candidate):
    if candidate not in (CANDIDATE, FROZEN):
        donor_plan = dict(plan, source_receipt_sha256=plan["donor_source_receipt_sha256"],
            source_files=plan["donor_source_files"], runtime_pins_sha256=plan["donor_runtime_pins_sha256"])
        return validate_donor_build(donor_plan, copied, candidate)
    source = PAYLOAD / candidate
    local_plan = dict(plan)
    if candidate == FROZEN:
        local_plan.update(source_receipt_sha256=plan["frozen_source_receipt_sha256"],
            source_files=plan["frozen_source_files"], runtime_pins_sha256=plan["frozen_runtime_pins_sha256"])
    if sha(source / "SOURCE_PREPARATION_RECEIPT.json") != local_plan["source_receipt_sha256"]:
        raise ValueError("production source freeze differs")
    for record in local_plan["source_files"]:
        path = copied / safe_name(record["path"])
        if path.stat().st_size != record["bytes"] or sha(path) != record["sha256"]:
            raise ValueError("installed production source differs")
    if sha(copied / "SOURCE_PREPARATION_RECEIPT.json") != local_plan["source_receipt_sha256"]:
        raise ValueError("installed production freeze differs")
    pins = public.read_json(source / "RUNTIME_PINS.json")
    expected = {row["path"]: {k: row[k] for k in ("bytes", "sha256")} for row in pins["files"]}
    if len(expected) != 64 or inventory(copied / "runtime") != expected or sha(copied / "RUNTIME_PINS.json") != local_plan["runtime_pins_sha256"]:
        raise ValueError("production exact runtime differs")
    donor = validate_donor_build(dict(plan, source_receipt_sha256=plan["donor_source_receipt_sha256"],
        source_files=plan["donor_source_files"], runtime_pins_sha256=plan["donor_runtime_pins_sha256"]),
        copied.parent / Path(DONOR).name, DONOR)
    deployment = public.read_json(copied / "DEPLOYMENT.json")
    extension = copied / safe_name(deployment["extension_path"])
    if (deployment.get("schema") != "t3-production-native-projection-deployment-v1"
            or deployment.get("candidate") != Path(candidate).name or deployment["abi"] != donor["abi"]
            or deployment["extension_sha256"] != donor["extension"]["sha256"]
            or extension.stat().st_size != deployment["extension_bytes"] or sha(extension) != deployment["extension_sha256"]
            or deployment["donor_build_receipt_sha256"] != donor["build_receipt_sha256"]
            or deployment["donor_source_receipt_sha256"] != plan["donor_source_receipt_sha256"]
            or deployment["native_pyx_sha256"] != plan["native_pyx_sha256"]
            or deployment["production_source_receipt_sha256"] != local_plan["source_receipt_sha256"]
            or deployment["runtime_pins_sha256"] != local_plan["runtime_pins_sha256"]):
        raise ValueError("production installed ELF/deployment binding differs")
    proof = {"passed": True, "candidate": candidate, "deployment": deployment,
        "deployment_sha256": sha(copied / "DEPLOYMENT.json"), "abi": donor["abi"],
        "extension": {"path": deployment["extension_path"], "bytes": deployment["extension_bytes"], "sha256": deployment["extension_sha256"]},
        "candidate_sources": {row["path"]: row["sha256"] for row in local_plan["source_files"]},
        "rankable": False, "timing_claim": False}
    write(copied / "BUILD_PROVENANCE.json", proof)
    return proof


def build(args, plan):
    evidence = args.evidence
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("real Linux amd64 host required")
    anonymous = evidence / "anonymous-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        execute(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], evidence / "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    write(evidence / "BASE.json", image(args, BASE, evidence / "base"))
    context = evidence / "build-context"
    context.mkdir()
    shutil.copytree(PAYLOAD / "completion1009", context / "completion1009")
    (context / "control").mkdir()
    shutil.copyfile(PAYLOAD / "control/entry.py", context / "control/entry.py")
    shutil.copyfile(PAYLOAD / "control/Dockerfile", context / "Dockerfile")
    iid = evidence / "native.image-id"
    execute(args, [args.docker, "build", "--platform", "linux/amd64", "--iidfile", str(iid),
        "-t", "t3-lean-projection-three-arm-screen:v1", "-f", str(context / "Dockerfile"), str(context)], evidence / "native-build", 1200)
    metadata = image(args, iid.read_text().strip(), evidence / "image")
    write(evidence / "IMAGE.json", metadata)
    token = uuid.uuid4().hex
    name = "t3-native-receipt-" + token[:12]
    commands = StrictCommands(args.docker, evidence / "receipt-commands", args.log_cap_bytes)
    commands.folder.mkdir(parents=True)
    created = commands.call(["create", "--name", name, "--label", linux.OWNER_LABEL + "=" + token,
        "--pull", "never", "--entrypoint", "/usr/local/bin/python", metadata["id"], "--help"], "create")
    try:
        if not created["succeeded"]:
            raise RuntimeError("never-started receipt container creation failed")
        info, _ = commands.inspect(name)
        linux.require_owned(info, name, token, metadata["id"])
        target = evidence / "actual-candidates"
        target.mkdir()
        for candidate in (PARENT, DONOR, FROZEN, CANDIDATE):
            destination = target / Path(candidate).name
            copied = commands.call(["cp", name + ":/opt/projection-screen/" + candidate, str(destination)],
                "copy-" + Path(candidate).name, 120)
            if not copied["succeeded"]:
                raise ValueError("actual image receipt/source/native bytes unavailable")
            validate_build(plan, destination, candidate)
    finally:
        settled = linux.settle_container(commands, name, token, metadata["id"], creation_uncertain=not created["succeeded"])
        write(evidence / "RECEIPT_CLEANUP.json", {"cleanup": settled, "commands": commands.rows})
        if not settled["settled"] or not settled["final_absent"] or settled["errors"]:
            raise RuntimeError("owned receipt container not settled")
    write(evidence / "BUILD_READY.json", {"passed": True, "image_id": metadata["id"],
        "build_count": 1, "rankable": False, "timing_claim": False})


def duration_ns(state):
    def parse(value):
        base, fraction = value.rstrip('Z').split('.', 1)
        return calendar.timegm(datetime.strptime(base, '%Y-%m-%dT%H:%M:%S').timetuple()) * 10**9 + int(fraction.ljust(9, '0'))
    return (parse(state['FinishedAt']) - parse(state['StartedAt'])) / 10**9


def require_probe(execution, arm, expected, provenance):
    lines = Path(execution["attach"]["stdout"]["path"]).read_text().splitlines()
    values = [json.loads(line[len(MARKER):]) for line in lines if line.startswith(MARKER)]
    if len(values) != 1:
        raise ValueError("one actual production entry marker required")
    value = values[0]
    if (value.get("schema") != "t3-lean-projection-three-arm-entry-v1" or value.get("arm") != arm
            or value.get("cli_source") != "/opt/projection-screen/" + ARM_CANDIDATES[arm] + "/production_cli.py"
            or value.get("entry_source") != "/opt/projection-screen/entry.py"
            or value.get("timing_scope") != TIMING_SCOPE or value.get("rankable") is not False
            or len(value["episodes"]) != expected):
        raise ValueError("actual production entry origin/arm/episode roster differs")
    owner = ARM_CANDIDATES[arm]
    proof = provenance[owner]
    for episode in value["episodes"]:
        if episode.get("candidate") != Path(owner).name:
            raise ValueError("actual production candidate differs")
        if arm == "lean_observer":
            if episode.get("native_projection_active") is not False:
                raise ValueError("observer parent used production native projection")
            continue
        if (episode.get("native_projection_active") is not True or episode.get("fallback_used") is not False
                or episode.get("extension_sha256") != proof["extension"]["sha256"] or episode.get("abi") != proof["abi"]
                or episode.get("extension_path") != "/opt/projection-screen/" + owner + "/" + proof["extension"]["path"]
                or episode.get("donor_build_receipt_sha256") != proof["deployment"]["donor_build_receipt_sha256"]
                or episode.get("implementation") != "observer_contract_typed_rows_stable_merge_v1"
                or episode.get("typed_numeric_write_rows") != episode.get("complete_trace_rows")
                or episode.get("python_sort_key_callbacks") != 0 or episode.get("native_load_count") != 1
                or episode.get("runtime_provenance") != "external_build_and_host_receipt"
                or episode.get("runtime_source_compilation") is not False or episode.get("per_episode_native_hash_audit") is not False):
            raise ValueError("actual production path lacks exact externally bound typed projection")
    return value


def run_one(args, metadata, provenance, arm, item, folder, suffix, reference=True):
    execution, output = linux.run_container(args, metadata['id'], arm, item, folder, args.owner, suffix)
    row = {'arm': arm, 'unit': item['unit'], 'execution': execution, 'output': str(output),
        'passed': False, 'rankable': False, 'timing_included': False}
    try:
        if not execution['succeeded'] or any(sha(Path(value['staged'])) != value['sha256'] for value in execution['staged_inputs']):
            raise ValueError('strict run or original staged input failed')
        row['output_inventory'] = inventory(output)
        row['probe'] = require_probe(execution, arm, len(item['subs']) if item['shape'] == 'batch' else 1, provenance)
        events = public.read_json(output / ('events.json' if item['shape'] == 'single' else 'batch_events.json'))
        if events != row['probe']['events']:
            raise ValueError('probe/actual sidecar differs')
        if item['shape'] == 'batch' and [r['sub'] for r in events.get('per_scenario', [])] != sorted(r['sub'] for r in item['subs']):
            raise ValueError('actual batch episode order differs from original CLI sorted input order')
        if reference:
            row['reference_checks'] = public.verify_outputs(args.reference_root / item['unit'], output, item)
            row['developer_verifier'] = linux.gate(args, args.reference_root / item['unit'], output, folder)
            if not row['reference_checks']['passed'] or row['developer_verifier'].get('admissible') is not True:
                raise ValueError('original reference or unchanged official verifier failed')
        else:
            scenario = public.read_json(item['scenario_paths'][0])
            frames = [public.compare_frame(output / name, Path(item['isolated_reference']) / name) for name in public.SUB_FILES[:2]]
            checked = public.verify_events(output, scenario, frames[0].get('candidate_rows', 0))
            tree = public.check_tree(output, set(public.SUB_FILES))
            if not all(r['passed'] for r in frames) or not checked['passed'] or not tree['passed']:
                raise ValueError('isolated original reference/sidecar/tree failed')
            row['reference_checks'] = {'passed': True, 'frames': frames, 'sidecar': checked, 'tree': tree,
                'actual_events': frames[0]['candidate_rows']}
        actual = row['reference_checks']['actual_events']
        if events.get('n_events', events.get('total_events')) != actual:
            raise ValueError('actual Parquet rows differ from sidecar/probe')
        row.update(actual_events=actual,
            cli_wall_sec=events['wall_clock_sec'], settled_container_runtime_sec=duration_ns(execution['state']))
        if any(not math.isfinite(value) or value <= 0 for value in
                (row['cli_wall_sec'], row['settled_container_runtime_sec'], execution['host_wall_sec'])):
            raise ValueError('actual measured wall clocks must be positive and finite')
        row['cli_events_per_sec'] = row['actual_events'] / row['cli_wall_sec']
        row['host_events_per_sec'] = row['actual_events'] / execution['host_wall_sec']
        row['daemon_events_per_sec'] = row['actual_events'] / row['settled_container_runtime_sec']
        row['passed'] = True
    except BaseException as error:
        row['failure'] = type(error).__name__ + ': ' + str(error)
    write(folder / 'RUN_RESULT.json', row)
    print(arm, item['unit'], 'PASS' if row['passed'] else 'FAIL', flush=True)
    return row


def pair(output, other, item):
    frames = list(public.SUB_FILES[:2]) if item['shape'] == 'single' else [sub['sub'] + '/' + name for sub in item['subs'] for name in public.SUB_FILES[:2]]
    results = [public.compare_frame(output / name, other / name) for name in frames]
    sidecars = ['events.json'] if item['shape'] == 'single' else [sub['sub'] + '/events.json' for sub in item['subs']] + ['batch_events.json']
    stable = []
    for name in sidecars:
        a, b = public.read_json(output / name), public.read_json(other / name)
        for value in (a, b):
            for key in ('wall_clock_sec', 'events_per_sec', 'peak_memory_bytes', 'gpu_seconds'):
                value.pop(key, None)
        stable.append({'path': name, 'candidate': a, 'baseline': b, 'passed': a == b})
    return {'passed': all(r['passed'] and r.get('byte_equal') for r in results) and all(r['passed'] for r in stable),
        'frames': results, 'stable_sidecars': stable}


def validate_controls(output, provenance):
    donor = provenance[DONOR]
    donor_receipt = {"receipt_path": "/opt/projection-screen/" + DONOR + "/artifacts/build_v2/BUILD_RECEIPT.json",
        "receipt_sha256": donor["build_receipt_sha256"], "extension_path": "/opt/projection-screen/" + DONOR +
        "/artifacts/build_v2/" + donor["extension"]["path"], "extension_sha256": donor["extension"]["sha256"], "abi": donor["abi"]}
    finite = public.read_json(output / "proof/FINITE_RESULT.json")
    proof_markets = public.read_json(output / "proof/RESULT.json")
    result = public.read_json(output / "RESULT.json")
    if (finite.get("all_passed") is not True or proof_markets.get("all_passed") is not True
            or [row["name"] for row in finite["cases"]] != finite_names()
            or any(row.get("passed") is not True for row in finite["cases"])
            or finite["sources_unchanged"] is not True or proof_markets["sources_unchanged"] is not True
            or finite["failures"] != [] or proof_markets["failures"] != []
            or finite["native_receipt"] != donor_receipt or proof_markets["native_receipt"] != donor_receipt
            or finite["proof_only"] is not True or finite["rankable"] is not False
            or proof_markets["proof_only"] is not True or proof_markets["rankable"] is not False
            or [row["seed"] for row in proof_markets["cases"]] != [81009, 82009, 83009, 84009]
            or any(row["passed"] is not True for row in proof_markets["cases"])
            or finite["controls_source_sha256"] != donor["candidate_sources"]["finite_controls.py"]
            or proof_markets["controls_source_sha256"] != donor["candidate_sources"]["controls.py"]
            or proof_markets["candidate_sources"] != donor["candidate_sources"]):
        raise ValueError("actual unchanged donor proof56/four-market bindings differ")
    for case in proof_markets["cases"]:
        witness = case["native_projection_witness"]
        if (any(witness.get(k) != v for k, v in donor_receipt.items())
                or witness.get("native_projection_active") is not True or witness.get("fallback_used") is not False
                or witness.get("typed_numeric_write_rows") != case["trace_rows"]
                or witness.get("python_sort_key_callbacks") != 0
                or witness.get("source_derived_live_helper_proof") is not True
                or witness.get("numeric_side_crossbindings_checked") is not True):
            raise ValueError("fresh proof path native witness differs")
    normal = {}
    expected_receipts = {}
    for label, owner, schema in (("frozen", FROZEN, "t3-production-native-projection-finite-v1"),
                                ("lean", CANDIDATE, "t3-lean-production-native-projection-finite-v1")):
        proof = provenance[owner]
        expected = {"extension_path": "/opt/projection-screen/" + owner + "/" + proof["extension"]["path"],
            "extension_sha256": proof["extension"]["sha256"], "donor_build_receipt_sha256": donor["build_receipt_sha256"],
            "donor_source_receipt_sha256": proof["deployment"]["donor_source_receipt_sha256"], "abi": proof["abi"],
            "runtime_provenance": "external_build_and_host_receipt", "runtime_source_compilation": False,
            "per_episode_native_hash_audit": False, "native_load_count": 1}
        rows = public.read_json(output / (label + "_FINITE_RESULT.json"))
        if (rows.get("schema") != schema or rows.get("all_passed") is not True or rows.get("failures") != []
                or [row["name"] for row in rows["cases"]] != finite_names()[:38]
                or any(row.get("passed") is not True for row in rows["cases"])
                or rows["native_receipt"] != expected or rows["runtime_mutation_audits_claimed"] is not False
                or rows["controls_source_sha256"] != proof["candidate_sources"]["production_finite_controls.py"]):
            raise ValueError("fresh frozen/lean record38 source/native receipt differs")
        if label == "lean":
            admission = rows.get("admission_checks", [])
            if ([(row["name"], row["admitted"]) for row in admission] != json_admission_expected()
                    or any(row.get("passed") is not True or type(row.get("admitted")) is not bool for row in admission)):
                raise ValueError("actual separate JSON10 admission controls differ")
        normal[label], expected_receipts[label] = rows, expected
    arms = ["proof_parent", "proof_native", "frozen_parent", "frozen_native", "lean_parent", "lean_native"]
    if (result.get("schema") != "t3-lean-projection-three-arm-controls-v1" or result.get("all_passed") is not True
            or result.get("failures") != [] or result.get("rankable") is not False or result.get("timing_claim") is not False
            or result.get("proof_finite_cases") != 56 or result.get("frozen_finite_cases") != 38 or result.get("lean_finite_cases") != 38
            or result.get("finite_record_cases") != 132 or result.get("json_admission_checks") != 10
            or result.get("full_market_cases") != 4 or result.get("full_market_episodes") != 24
            or result.get("full_control_arms") != arms
            or result.get("controls_source_sha256") != sha(PAYLOAD / "control/entry.py")
            or [case["seed"] for case in result["cases"]] != [81009, 82009, 83009, 84009]):
        raise ValueError("actual source-bound six-way complete control report differs")
    workers = {}
    for label, folder, schema in (
            ("proof_parent", "proof/parent", "t3-native-canonical-projection-semantic-worker-v2"),
            ("proof_native", "proof/native", "t3-native-canonical-projection-semantic-worker-v2"),
            ("frozen_parent", "frozen_parent", "t3-production-native-projection-semantic-worker-v1"),
            ("frozen_native", "frozen_native", "t3-production-native-projection-semantic-worker-v1"),
            ("lean_parent", "lean_parent", "t3-lean-production-native-projection-semantic-worker-v1"),
            ("lean_native", "lean_native", "t3-lean-production-native-projection-semantic-worker-v1")):
        worker = public.read_json(output / folder / "WORKER_RECEIPT.json")
        if (worker.get("schema") != schema or worker.get("arm") != label.rsplit("_", 1)[1]
                or worker.get("timing_claim") is not False
                or worker.get("values_sha256") != sha(output / folder / "SEMANTIC_VALUES.pkl")
                or result["data_sha256"].get(folder) != worker["values_sha256"]
                or [case["seed"] for case in worker["cases"]] != [81009, 82009, 83009, 84009]):
            raise ValueError("actual six-worker data/source receipt differs")
        if label.startswith("lean"):
            if worker.get("json_domain_admitted_all") is not True or worker.get("runtime_mutation_audits_claimed") is not False:
                raise ValueError("lean worker actual JSON admission differs")
        elif worker.get("loaded_domain_authenticated") is not True:
            raise ValueError("frozen/proof worker original authentication differs")
        workers[label] = worker
    if set(result["data_sha256"]) != {"proof/parent", "proof/native", "frozen_parent", "frozen_native", "lean_parent", "lean_native"}:
        raise ValueError("complete six-worker data roster differs")
    for index, case in enumerate(result["cases"]):
        if (case.get("passed") is not True or case.get("six_way_complete_equal") is not True
                or case.get("lean_json_domain_admitted") != [True, True]
                or case.get("trace_rows", 0) <= 0 or case.get("message_rows", 0) <= 0
                or set(case["witnesses"]) != set(arms)):
            raise ValueError("actual six-way complete market assertion differs")
        for label in arms:
            worker_case = workers[label]["cases"][index]
            witness = case["witnesses"][label]
            if (worker_case["details"] != case["details"] or worker_case["trace_rows"] != case["trace_rows"]
                    or worker_case["message_rows"] != case["message_rows"] or worker_case["projection_witness"] != witness):
                raise ValueError("six-way case differs from actual individual worker receipt")
            if label.endswith("parent"):
                if witness.get("native_projection_active") is not False: raise ValueError("parent arm used native projection")
            elif label == "proof_native":
                if (any(witness.get(k) != v for k, v in donor_receipt.items())
                        or witness.get("native_projection_active") is not True or witness.get("fallback_used") is not False
                        or witness.get("typed_numeric_write_rows") != case["trace_rows"]
                        or witness.get("python_sort_key_callbacks") != 0):
                    raise ValueError("six-way proof native witness differs")
            else:
                expected = expected_receipts[label.split("_", 1)[0]]
                if (any(witness.get(k) != v for k, v in expected.items())
                        or witness.get("native_projection_active") is not True or witness.get("fallback_used") is not False
                        or witness.get("typed_numeric_write_rows") != case["trace_rows"]
                        or witness.get("complete_trace_rows") != case["trace_rows"] or witness.get("python_sort_key_callbacks") != 0):
                    raise ValueError("six-way frozen/lean native witness differs")
    return {"finite": finite, "proof_markets": proof_markets, "normal": normal, "markets": result, "workers": workers}


def screen(args, plan):
    args.owner = uuid.uuid4().hex
    args.timeout = 300
    metadata = public.read_json(args.evidence / 'IMAGE.json')
    provenance = {candidate: validate_build(plan, args.evidence / 'actual-candidates' / Path(candidate).name, candidate)
        for candidate in (PARENT, DONOR, FROZEN, CANDIDATE)}
    before_image = image(args, metadata['id'], args.evidence / 'image-before-screen')
    if before_image['inspection'] != metadata['inspection']:
        raise ValueError('actual image changed before screen')
    roster = public.collect_plan(args.reference_root, SINGLES + [BATCH])
    write(args.evidence / 'REFERENCE_PLAN.json', roster)
    items = {value['unit']: value for value in roster['units']}
    if len(items[BATCH]['subs']) != 5:
        raise ValueError('original full five-member batch required')
    rows, failure, first, serial = [], None, {}, 0
    try:
        controls_input = args.evidence / 'fixed-control-input.json'
        write(controls_input, {'proof_command': 'lean-projection-three-arm-proof56-frozen38-lean38-json10-six-market-arms-v1'})
        controls_item = {'shape': 'single', 'scenario_paths': [str(controls_input)]}
        args.timeout = 1800
        execution, output = linux.run_container(args, metadata['id'], 'controls', controls_item,
            args.evidence / 'controls', args.owner, 'controls')
        args.timeout = 300
        if not execution['succeeded'] or any(sha(Path(r['staged'])) != r['sha256'] for r in execution['staged_inputs']):
            raise ValueError('strict controls container or fixed input failed')
        audited_controls = validate_controls(output / 'controls', provenance)
        write(args.evidence / 'CONTROL_RESULT.json', {'passed': True, 'execution': execution, **audited_controls})
        for stage, repeats in (('smoke', [0]), ('screen', [-1, 0, 1, 2])):
            units = [SINGLES[0], SINGLES[1], BATCH] if stage == 'smoke' else SINGLES + [BATCH]
            for repeat in repeats:
                for index, unit in enumerate(units):
                    order = arm_order(index, repeat)
                    group = {}
                    for arm in order:
                        serial += 1
                        folder = args.evidence / stage / ('warmup' if repeat < 0 else 'repeat-' + str(repeat)) / unit / arm
                        row = run_one(args, metadata, provenance, arm, items[unit], folder, '%04d' % serial)
                        row.update(stage=stage, repeat=repeat, warmup=repeat < 0, order=order,
                            timing_included=stage == 'screen' and repeat >= 0)
                        rows.append(row); group[arm] = row
                        write(args.evidence / 'RAW_RESULTS.json', rows)
                        if not row['passed']:
                            raise ValueError('screen stopped at failed run')
                    for arm, row in group.items():
                        output = Path(row['output'])
                        row['same_round_pair'] = pair(output, Path(group['lean_observer']['output']), items[unit])
                        key = (stage, unit, arm)
                        previous = first.setdefault(key, output)
                        row['same_arm_repeat_pair'] = pair(output, previous, items[unit])
                        row['passed'] &= row['same_round_pair']['passed'] and row['same_arm_repeat_pair']['passed']
                        write(output.parent / 'RUN_RESULT.json', row)
                        write(args.evidence / 'RAW_RESULTS.json', rows)
                        if not row['passed']:
                            raise ValueError('paired or repeat output differs')
                    write(args.evidence / 'RAW_RESULTS.json', rows)
        batch = items[BATCH]
        for arm in ARMS:
            full = next(r for r in reversed(rows) if r['unit'] == BATCH and r['arm'] == arm)
            for sub in batch['subs']:
                serial += 1
                item = {'unit': BATCH + '/' + sub['sub'], 'shape': 'single', 'subs': [],
                    'scenario_paths': [str(args.reference_root / BATCH / sub['scenario_file'])],
                    'isolated_reference': str(args.reference_root / BATCH / 'checks/reference_data' / sub['sub'])}
                folder = args.evidence / 'isolation' / arm / sub['sub']
                row = run_one(args, metadata, provenance, arm, item, folder, '%04d' % serial, reference=False)
                row.update(stage='isolation')
                rows.append(row)
                write(args.evidence / 'RAW_RESULTS.json', rows)
                row.update(stage='isolation', isolation_pair=pair(Path(row['output']), Path(full['output']) / sub['sub'], item))
                row['passed'] &= row['isolation_pair']['passed']
                write(folder / 'RUN_RESULT.json', row); write(args.evidence / 'RAW_RESULTS.json', rows)
                if not row['passed']:
                    raise ValueError('fresh batch isolation failed')
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
    unchanged = all(sha(args.reference_root / item['unit'] / name) == digest for item in roster['units']
        for mapping in (item['input_sha256'], item['reference_sha256']) for name, digest in mapping.items())
    try:
        after_image = image(args, metadata['id'], args.evidence / 'image-after-screen')
        immutable = after_image['inspection'] == before_image['inspection']
        verify_payload(PAYLOAD)
        for candidate in (PARENT, DONOR, FROZEN, CANDIDATE):
            validate_build(plan, args.evidence / 'actual-candidates' / Path(candidate).name, candidate)
        if not immutable:
            raise ValueError('actual image changed during screen')
    except BaseException as error:
        immutable = False
        failure = failure or type(error).__name__ + ': ' + str(error)
    measured = [r for r in rows if r.get('timing_included')]
    official_runs = sum('developer_verifier' in r for r in rows)
    official_gate_passes = sum(
        gate.get('passed') is True
        for row in rows for gate in (row.get('developer_verifier', {}).get('verdict') or {}).get('gate_results', {}).values())
    comparisons = []
    for arm, baseline in (('lean_native', 'production_native'), ('lean_native', 'lean_observer'), ('production_native', 'lean_observer')):
        rates = []
        for unit in SINGLES + [BATCH]:
            a = [r for r in measured if r['arm'] == baseline and r['unit'] == unit and r['passed']]
            b = [r for r in measured if r['arm'] == arm and r['unit'] == unit and r['passed']]
            if len(a) != 3 or len(b) != 3:
                continue
            rates.append({'unit': unit, **{name: statistics.median(r[key] if key != 'host_wall_sec' else r['execution'][key] for r in a)
                / statistics.median(r[key] if key != 'host_wall_sec' else r['execution'][key] for r in b)
                for name, key in (('cli_ratio', 'cli_wall_sec'), ('host_ratio', 'host_wall_sec'), ('daemon_ratio', 'settled_container_runtime_sec'))}})
        comparisons.append({'arm': arm, 'baseline': baseline, 'per_unit': rates,
            **{key: statistics.mean(r[key] for r in rates) if len(rates) == 5 else None for key in ('cli_ratio', 'host_ratio', 'daemon_ratio')}})
    summary = {'schema': 't3-lean-projection-three-arm-screen-result-v1', 'all_passed': failure is None and len(rows) == 84
        and len(measured) == 45 and official_runs == 69 and official_gate_passes == 276
        and all(r['passed'] for r in rows) and unchanged and immutable,
        'runs': len(rows), 'planned_runs': 84, 'control_invocations': 1, 'measured_runs': len(measured),
        'failure': failure, 'comparisons': comparisons, 'original_inputs_references_unchanged': unchanged,
        'image_source_provenance_unchanged': immutable, 'total_execution_containers': len(rows) + 1,
        'official_verifier_runs': official_runs, 'official_gate_passes': official_gate_passes,
        'rankable': False, 'official_score': None, 'publication': False, 'competition_upload': False}
    write(args.evidence / 'SUMMARY.json', summary)
    if not summary['all_passed']:
        raise RuntimeError('native projection screen incomplete or failed')


def archive_evidence(args):
    if args.artifact.exists():
        raise ValueError("new artifact directory required")
    args.artifact.mkdir(parents=True)
    success = (args.evidence / 'SUMMARY.json').is_file() and public.read_json(args.evidence / 'SUMMARY.json').get('all_passed') is True
    omitted = {}
    for source in sorted(args.evidence.rglob("*")):
        if not source.is_file() or source.is_symlink():
            continue
        relative = source.relative_to(args.evidence)
        # Omit ordinary successful run bytes only after every gate passed.
        # Always retain controls outputs and complete failed/unknown run bytes.
        compact_run = success and relative.parts[0] in ('smoke', 'screen', 'isolation') and any(p in ('input', 'output') for p in relative.parts)
        if relative.parts[0] in ('build-context', 'anonymous-config') or compact_run:
            omitted[relative.as_posix()] = {'bytes': source.stat().st_size, 'sha256': sha(source),
                'reason': 'successful ordinary run bytes' if compact_run else 'duplicate build context or empty anonymous configuration'}
            continue
        target = args.artifact / "evidence" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    write(args.artifact / 'OMITTED_FILES.json', {'all_runs_passed': success, 'files': omitted})
    shutil.copyfile(args.archive, args.artifact / "SCREEN_PAYLOAD.tar.xz")
    write(args.artifact / "ARTIFACT.json", {"archive_sha256": sha(args.archive),
        "compact_success_outputs_omitted_full_failures_retained": True, 'successful_runs_compacted': success,
        'controls_outputs_retained': True, "rankable": False, "timing_claim": False,
        "files": inventory(args.artifact)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("build", "screen", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--reference-root", type=Path)
    parser.add_argument("--gate-kit", type=Path)
    parser.add_argument("--gate-python", default=sys.executable)
    parser.add_argument("--docker", default="docker")
    parser.add_argument("--timeout", type=float, default=900)
    parser.add_argument("--log-cap-bytes", type=int, default=4 * 1024 ** 2)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--artifact", type=Path)
    args = parser.parse_args()
    signal.signal(signal.SIGINT, linux.cancellation)
    signal.signal(signal.SIGTERM, linux.cancellation)
    args.evidence = args.evidence.resolve()
    args.evidence.mkdir(parents=True, exist_ok=True)
    if args.stage == "artifact":
        archive_evidence(args)
        return
    verify_payload(PAYLOAD)
    plan = public.read_json(PAYLOAD / "SCREEN_PLAN.json")
    if (plan.get("base") != BASE or plan.get("candidate") != CANDIDATE or plan.get("parent") != PARENT
            or plan.get("single_units") != SINGLES or plan.get("batch_unit") != BATCH
            or plan.get("arms") != ARMS or plan.get("proof_finite_cases") != 56 or plan.get("production_finite_cases") != 38
            or plan.get("frozen") != FROZEN or plan.get("frozen_finite_cases") != 38
            or plan.get("finite_record_cases") != 132 or plan.get("full_market_episodes") != 24
            or plan.get("frozen_runtime_pins_sha256") != DONOR_RUNTIME_PINS_SHA256
            or plan.get("json_admission_checks") != 10
            or plan.get("runtime_pins_sha256") != RUNTIME_PINS_SHA256
            or plan.get("donor_runtime_pins_sha256") != DONOR_RUNTIME_PINS_SHA256
            or plan.get("full_control_arms") != ["proof_parent", "proof_native", "frozen_parent", "frozen_native", "lean_parent", "lean_native"]
            or plan.get("per_episode_source_authentication") != {"production_native": True, "lean_native": False, "lean_observer": False}
            or plan.get("arm_order") != "three_fresh_rotating_positions_unit_parity_reversal"
            or plan.get("build_time_bytecode_factor") is not False
            or plan.get("donor") != DONOR or plan.get("market_cases") != 4
            or plan.get("proof_complete_market_cases") != 4 or plan.get("production_complete_market_cases") != 4
            or plan.get("planned_runs") != 84 or plan.get("measured_runs") != 45
            or plan.get('control_invocations') != 1 or plan.get('total_execution_containers') != 85
            or plan.get('official_verifier_runs') != 69 or plan.get('full_five_member_batch') is not True
            or plan.get('official_gate_passes') != 276 or plan.get('no_performance_early_stop') is not True
            or plan.get("warmups") != 1 or plan.get("measured_repeats") != 3
            or plan.get("build_count") != 1 or plan.get("extension_builds") != 1
            or plan.get("rankable") is not False):
        raise ValueError("fixed native projection screen plan differs")
    if args.stage == "build":
        build(args, plan)
    else:
        if not args.reference_root or not args.gate_kit:
            raise ValueError("original host references and official toolkit required")
        screen(args, plan)


if __name__ == "__main__":
    main()
