"""Explicit read-only representation mapping for untimed transaction controls.

Only the declared Kernel/heap/ledger/book/level representation is mapped. Every other
business attribute remains in the graph. The separate actual Cython probe
must establish the native private owner/list aliases before mapping is used.
"""
import _thread
from collections import defaultdict, deque
from datetime import datetime, timedelta
import types

import numpy as np
import pandas as pd
from abides_core.kernel import Kernel
from abides_markets.orders import Side
from abides_markets.order_book import OrderBook
from abides_markets.price_level import PriceLevel

_engine = None
_arm = None
_owner_probe = None
_installed_kernel = None
_audited = {}


def configure(engine, arm, owner_probe, installed_kernel):
    global _engine, _arm, _owner_probe, _installed_kernel
    if arm not in ("original_canonical", "actual_native"):
        raise ValueError("unknown mapping arm")
    if (arm == "actual_native") != (owner_probe is not None):
        raise ValueError("native mapping requires the actual control probe")
    if arm == "original_canonical":
        if installed_kernel is not engine.CanonicalKernel:
            raise ValueError("original installed Kernel class differs")
    elif (installed_kernel.__bases__ != (engine.CanonicalKernel,)
            or installed_kernel.__module__ != "transaction_installation"
            or installed_kernel.__qualname__ != "enabled.<locals>.GuardedKernel"
            or set(vars(installed_kernel)) != {"__module__", "__init__", "__doc__"}):
        raise ValueError("actual installed GuardedKernel class differs")
    _engine, _arm, _owner_probe, _installed_kernel = engine, arm, owner_probe, installed_kernel
    _audited.clear()


def audit_kernel(kernel, end_state):
    if _engine is None or type(kernel) is not _installed_kernel:
        raise ValueError("mapping kernel has the wrong concrete owner")
    heap, ledger = kernel.messages, kernel._msg_ledger
    if type(heap) is not _engine.FlatHeap or type(ledger) is not _engine.ColumnLedger:
        raise ValueError("mapping heap/ledger owner differs")
    if set(vars(heap)) != {"queue"} or type(heap.queue) is not list:
        raise ValueError("mapping heap has undeclared attributes")
    columns = ledger.columns
    if type(columns) is not tuple or len(columns) != 9 or not all(type(v) is list for v in columns):
        raise ValueError("mapping ledger requires the original nine lists")
    if len({id(v) for v in columns}) != 9 or ledger.columns is not columns:
        raise ValueError("ledger column identities differ")
    if not all(len(v) == len(columns[0]) for v in columns) or len(ledger) != len(columns[0]):
        raise ValueError("ledger column lengths differ")
    native_private = None
    if _arm == "original_canonical":
        if set(vars(ledger)) != {"columns"} or "_canonical_scheduler" in vars(kernel):
            raise ValueError("original representation has unexpected fields")
    else:
        if set(vars(ledger)) != {"columns"}:
            raise ValueError("native ledger dynamic fields differ")
        scheduler = kernel._canonical_scheduler
        if type(scheduler) is not _engine.CanonicalScheduler:
            raise ValueError("native scheduler concrete owner differs")
        native_private = _owner_probe.audit_owner(kernel)
        # The loader/source receipt binds the actual probe and its assertions;
        # any private alias failure raises before the mapping is permitted.
        if type(native_private) is not dict or not native_private:
            raise ValueError("actual native private-owner witness is missing")
        if (native_private.get("column_list_aliases") != [True] * 9
                or native_private.get("column_lists_distinct") is not True
                or native_private.get("scheduler_kernel_identity") is not True):
            raise ValueError("native private-owner assertions did not pass")
        transaction = _owner_probe.audit_transaction(kernel, kernel.agents[0])
        if (type(transaction) is not dict
                or transaction.get("schema") != "t3-native-canonical-transaction-private-owner-control-v1"
                or transaction.get("control_only") is not True
                or transaction.get("mutation_performed") is not False
                or transaction.get("production_hot_counters") is not False
                or transaction.get("same_extension_book_level_scheduler") is not True
                or transaction.get("nine_original_column_list_aliases") is not True
                or len(transaction.get("books", [])) != len(kernel.agents[0].order_books)
                or not transaction.get("books")
                or not all(row["same_scheduler"] and row["raw_owner"] for row in transaction["books"])):
            raise ValueError("native complete transaction owner proof differs")
        native_private["transaction"] = transaction
    if end_state["agents"] is not kernel.agents or end_state["message_ledger"] is not ledger or end_state["deliver_seq_by_key"] is not kernel._deliver_seq_by_key:
        raise ValueError("end-state kernel/ledger/map aliases differ")
    if not all(agent.kernel is kernel for agent in kernel.agents):
        raise ValueError("agent kernel aliases differ")
    _audited[id(kernel)] = kernel
    _audited[id(ledger)] = ledger
    _audited[id(heap)] = heap
    book_owner = OrderBook if _arm == "original_canonical" else _engine.NativeBook
    level_owner = PriceLevel if _arm == "original_canonical" else _engine.NativeLevel
    books = kernel.agents[0].order_books
    if type(books) is not dict or not books:
        raise ValueError("nonempty exact exchange book mapping required")
    for symbol, book in books.items():
        if type(book) is not book_owner or book.owner is not kernel.agents[0] or book.symbol != symbol:
            raise ValueError("exact book/raw exchange owner differs")
        if type(book.bids) is not list or type(book.asks) is not list:
            raise ValueError("original book level lists required")
        _audited[id(book)] = book
        for level in book.bids + book.asks:
            if (type(level) is not level_owner or type(level.visible_orders) is not list
                    or type(level.hidden_orders) is not list):
                raise ValueError("exact level/original order lists required")
            _audited[id(level)] = level
    return {"mapping_version": "t3-transaction-representation-v6", "arm": _arm,
            "exact_kernel_heap_ledger_types": True, "heap_queue_original_list": True,
            "columns_tuple_retained": True, "nine_distinct_exact_list_aliases": True,
            "ledger_rows": len(ledger), "end_state_aliases": [True, True, True],
            "all_agent_kernel_aliases": True,
            "exact_installed_kernel_class": True, "exact_book_level_raw_owner_types": True,
            "scheduler_owner_verified": _arm != "original_canonical",
            "original_has_no_scheduler": _arm == "original_canonical",
            "native_private_witness": native_private}


def kernel_fields(kernel):
    if _audited.get(id(kernel)) is not kernel:
        raise ValueError("kernel mapping was not audited")
    omitted = {"kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir", "agents", "gym_agents", "custom_state"}
    if _arm != "original_canonical":
        omitted.add("_canonical_scheduler")
    return {key: value for key, value in vars(kernel).items() if key not in omitted}


def encode(value):
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is bytes: return ["bytes", value.hex()]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, pd.Timestamp): return ["Timestamp", value.isoformat()]
    if type(value) is datetime: return ["datetime", value.isoformat()]
    if type(value) is timedelta: return ["timedelta", value.days, value.seconds, value.microseconds]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.ndarray): return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if type(value) is defaultdict:
        factory = value.default_factory
        if factory is not None and factory is not list:
            raise TypeError("unsupported semantic defaultdict factory")
        token = ["NoneType", None] if factory is None else ["binding", "builtins", "list"]
        return ["defaultdict", token, [(encode(k), encode(v)) for k, v in value.items()]]
    if type(value) is dict: return ["dict", [(encode(k), encode(v)) for k, v in value.items()]]
    if type(value) is deque: return ["deque", value.maxlen, [encode(v) for v in value]]
    if type(value) in (list, tuple): return [type(value).__name__, [encode(v) for v in value]]
    if type(value) is Side: return ["Side", value.value]
    if hasattr(value, "__dict__"): return [type(value).__module__, type(value).__name__, encode(vars(value))]
    raise TypeError("unsupported semantic scalar value: " + type(value).__name__)


def graph(value, seen=None, kernel_telemetry=False):
    seen = {} if seen is None else seen
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is bytes: return ["bytes", value.hex()]
    if type(value) is float: return ["float", value.hex()]
    if type(value) is datetime: return ["datetime", value.isoformat()]
    if type(value) is timedelta: return ["timedelta", value.days, value.seconds, value.microseconds]
    if isinstance(value, np.generic): return [type(value).__name__, graph(value.item(), seen)]
    if type(value) is Side: return ["Side", value.value]
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType,
                          types.BuiltinFunctionType, types.BuiltinMethodType, type)):
        for name in ("CanonicalKernel", "FlatHeap", "ColumnLedger"):
            if value is getattr(_engine, name): return ["binding", "t3_scheduler_mapping", name]
        if value is _installed_kernel: return ["binding", "t3_scheduler_mapping", "CanonicalKernel"]
        return ["binding", getattr(value, "__module__", ""), getattr(value, "__qualname__", getattr(value, "__name__", ""))]
    if type(value) is _thread.LockType: return ["thread_lock", value.locked()]
    if id(value) in seen: return ["ref", seen[id(value)][0]]
    serial = len(seen)
    seen[id(value)] = (serial, value)
    if isinstance(value, np.random.RandomState): return ["RandomState", serial, encode(value.get_state())]
    if isinstance(value, np.ndarray): return ["ndarray", serial, str(value.dtype), list(value.shape),
        graph(value.tolist(), seen) if value.dtype.hasobject else value.tobytes().hex()]
    if type(value) is defaultdict:
        factory = value.default_factory
        if factory is not None and factory is not list:
            raise TypeError("unsupported business graph defaultdict factory")
        token = ["NoneType", None] if factory is None else ["binding", "builtins", "list"]
        return ["defaultdict", serial, token, [(graph(k, seen), graph(v, seen)) for k, v in value.items()]]
    if type(value) is dict:
        return ["dict", serial, [(graph(k, seen), graph(v, seen)) for k, v in value.items()
            if not (kernel_telemetry and type(k) is str and k == "kernel_event_queue_elapsed_wallclock")]]
    if type(value) is deque: return ["deque", serial, value.maxlen, [graph(v, seen) for v in value]]
    if type(value) in (list, tuple): return [type(value).__name__, serial, [graph(v, seen) for v in value]]
    if type(value) in (set, frozenset): return [type(value).__name__, serial, sorted([encode(v) for v in value], key=repr)]
    if isinstance(value, (pd.DataFrame, pd.Series)): return [type(value).__name__, serial, str(value.dtypes), encode(value.to_dict())]
    if isinstance(value, pd.Timestamp): return ["Timestamp", serial, value.isoformat()]
    if _engine is None:
        raise ValueError("unconfigured representation mapping")
    if type(value) is _installed_kernel or type(value) in (_engine.FlatHeap, _engine.ColumnLedger):
        if _audited.get(id(value)) is not value:
            raise ValueError("undeclared unaudited native representation")
        if type(value) is _engine.ColumnLedger:
            return ["t3_scheduler_mapping", "ColumnLedger", serial, [("columns", graph(value.columns, seen))]]
        if type(value) is _engine.FlatHeap:
            return ["t3_scheduler_mapping", "FlatHeap", serial, [("queue", graph(value.queue, seen))]]
        attrs = [(key, child) for key, child in vars(value).items()
                 if key not in ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir", "_canonical_scheduler")]
        return ["t3_scheduler_mapping", "CanonicalKernel", serial,
                [(key, graph(child, seen, key == "custom_state")) for key, child in attrs]]
    if hasattr(value, "__dict__"):
        attrs = [(key, child) for key, child in vars(value).items()
                 if not (isinstance(value, Kernel) and key in ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir"))]
        book = type(value) is OrderBook or (_arm == "actual_native" and type(value) is _engine.NativeBook)
        level = type(value) is PriceLevel or (_arm == "actual_native" and type(value) is _engine.NativeLevel)
        if (book or level) and _audited.get(id(value)) is not value:
            raise ValueError("book/level representation was not owner-audited")
        module_name = "t3_transaction_mapping" if book or level else type(value).__module__
        type_name = "OrderBook" if book else "PriceLevel" if level else type(value).__name__
        return [module_name, type_name, serial,
                [(key, graph(child, seen, isinstance(value, Kernel) and key == "custom_state")) for key, child in attrs]]
    raise TypeError("unsupported business graph value: " + type(value).__name__)
