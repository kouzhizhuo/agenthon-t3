"""Future exact original/cdef strategy boundaries; not run during source prep."""
from copy import deepcopy
import warnings


STRATEGIES = ("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader")
TRANSITIONS = ("wake_initial", "wake_open", "wake_closed", "spread_empty", "spread_bid",
               "spread_ask", "spread_both", "spread_closed", "act_empty", "act_both")
NOTIFICATIONS = ("hours", "close_prices", "market_closed", "accepted", "executed_partial_bid",
                 "executed_full_ask", "executed_unowned", "cancelled_owned", "cancelled_unowned",
                 "partial_cancel", "modified", "replaced", "last_trade", "order_stream", "volume", "unknown")
CASES = tuple((strategy, case) for strategy in STRATEGIES for case in TRANSITIONS + NOTIFICATIONS)
ERRORS = ("malformed_depth", "negative_order_warning", "cancel_nonlimit_warning",
          "latency_raises_after_order_copy", "observer_raises_after_enqueue", "past_wakeup",
          "oracle_raises_after_mid", "missing_known_symbol")
ERROR_CASES = tuple((strategy, case) for strategy in STRATEGIES for case in ERRORS
                   if case != "oracle_raises_after_mid" or strategy == "ValueTrader")
ROUNDTRIP_CASES = tuple((strategy, protocol) for strategy in STRATEGIES for protocol in (False, True))


def encode(value, np):
    if value is None or type(value) in (str, int, bool): return [type(value).__name__, value]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item(), np)]
    if isinstance(value, np.random.RandomState): return ["RandomState", encode(value.get_state(), np)]
    if isinstance(value, np.ndarray): return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist(), np)]
    from abides_markets.orders import Side
    if type(value) is Side: return ["Side", value.value]
    if type(value) in (list, tuple): return [type(value).__name__, [encode(child, np) for child in value]]
    if isinstance(value, dict): return ["dict", [(encode(key, np), encode(child, np)) for key, child in value.items()]]
    if type(value) in (set, frozenset): return [type(value).__name__, sorted([encode(child, np) for child in value], key=repr)]
    if hasattr(value, "__dict__"):
        return [type(value).__module__, type(value).__name__, encode({key: child for key, child in vars(value).items() if key != "kernel"}, np)]
    raise TypeError("unsupported complete strategy fixture value: " + type(value).__name__)


def setup(strategy, case, engine, np, native):
    from abides_fork.agents import AGENT_REGISTRY
    from abides_fork.config import ScenarioLatencyModel
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.orders import Order
    from abides_core.message import Message
    from abides_markets.oracles.sparse_mean_reverting_oracle import SparseMeanRevertingOracle
    from abides_markets.agents import exchange_agent
    Order._order_id_counter = 0
    Message._Message__message_id_counter = 1
    np.random.seed(7631009)
    agent = AGENT_REGISTRY[strategy](id=1, name="CTRL", type=strategy, symbol="ABM", starting_cash=10000,
        random_state=np.random.RandomState(7311009), interval_ns=100)
    original_book = exchange_agent.OrderBook
    try:
        if native: exchange_agent.OrderBook = engine.NativeBook
        exchange = ExchangeAgent(0, 100, 1000, ["ABM"], random_state=np.random.RandomState(7321009),
                                 log_orders=None, book_logging=True, pipeline_delay=0, computation_delay=0)
    finally:
        exchange_agent.OrderBook = original_book
    latency = ScenarioLatencyModel(2, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 7}}, np.random.RandomState(7331009))
    oracle = SparseMeanRevertingOracle(100, 2000, {"ABM": {"r_bar": 100, "kappa": .01,
        "fund_vol": .01, "megashock_lambda_a": .01, "megashock_mean": 0,
        "megashock_var": 0, "random_state": np.random.RandomState(7351009)}})
    kernel = engine.CanonicalKernel([exchange, agent], start_time=1, stop_time=2000,
        random_state=np.random.RandomState(7341009), agent_latency_model=latency, custom_properties={"oracle": oracle})
    exchange.kernel = agent.kernel = kernel
    exchange.oracle = oracle
    if native: kernel._canonical_scheduler.bind_exchange(exchange)
    agent.exchange_id = 0
    agent.oracle = oracle
    agent.log_events = exchange.log_events = True
    agent.mkt_open, agent.mkt_close = (None, None) if case in ("wake_initial", "hours") else (100, 1000)
    agent.mkt_closed = case in ("wake_closed", "spread_closed")
    # First market-hours delivery occurs before open100; every other
    # normal control retains120. The explicit past_wakeup error remains separate.
    agent.current_time = kernel.current_time = 50 if case == "hours" else 120
    kernel.ttl_messages = 0
    bids = [] if case in ("spread_empty", "spread_ask", "act_empty") else [(99, 3)]
    asks = [] if case in ("spread_empty", "spread_bid", "act_empty") else [(101, 4)]
    agent.known_bids["ABM"], agent.known_asks["ABM"] = bids, asks
    if strategy == "MomentumTrader": agent._mid_history.extend([98., 99., 99., 100., 100.])
    if case.startswith("spread_"): agent.state = "AWAITING_SPREAD"
    return kernel, agent, bids, asks


def message_for(case, agent, bids, asks):
    from abides_core.message import Message
    from abides_markets.orders import LimitOrder, Side
    from abides_markets.messages.market import MarketHoursMsg, MarketClosePriceMsg, MarketClosedMsg
    from abides_markets.messages.query import QuerySpreadResponseMsg, QueryLastTradeResponseMsg, QueryOrderStreamResponseMsg, QueryTransactedVolResponseMsg
    from abides_markets.messages.orderbook import OrderAcceptedMsg, OrderExecutedMsg, OrderCancelledMsg, OrderPartialCancelledMsg, OrderModifiedMsg, OrderReplacedMsg
    if case.startswith("spread_"): return QuerySpreadResponseMsg("ABM", case == "spread_closed", 1, bids, asks, 100)
    if case == "hours": return MarketHoursMsg(100, 1000)
    if case == "close_prices": return MarketClosePriceMsg({"ABM": 102})
    if case == "market_closed": return MarketClosedMsg()
    if case == "last_trade": return QueryLastTradeResponseMsg("ABM", True, 105)
    if case == "order_stream": return QueryOrderStreamResponseMsg("ABM", False, 1, [{"orders": [1, 2]}])
    if case == "volume": return QueryTransactedVolResponseMsg("ABM", False, 5, 9)
    if case == "unknown": return Message()
    side = Side.ASK if case == "executed_full_ask" else Side.BID
    order = LimitOrder(1, 110, "ABM", 7, side, 100)
    if case not in ("executed_unowned", "cancelled_unowned"): agent.orders[order.order_id] = deepcopy(order)
    new = deepcopy(order)
    if case.startswith("executed"):
        new.quantity = 2 if case == "executed_partial_bid" else 7
        new.fill_price = 101
        return OrderExecutedMsg(new)
    if case == "accepted": return OrderAcceptedMsg(new)
    if case.startswith("cancelled"): return OrderCancelledMsg(new)
    if case == "partial_cancel":
        new.quantity = 3
        return OrderPartialCancelledMsg(new)
    if case == "modified":
        new.quantity = 11
        return OrderModifiedMsg(new)
    if case == "replaced":
        new.order_id += 19
        return OrderReplacedMsg(order, new)
    raise ValueError("missing explicit strategy fixture message")


def snapshot(kernel, agent, np, observer, outcome=None, warning_values=None, roundtrip=False):
    from abides_markets.orders import Order
    from abides_core.message import Message
    from strategy_graph import graph
    roots = {"agent": agent, "queue": kernel.messages.queue, "ledger": kernel._msg_ledger.columns,
        "global_rng": np.random.get_state(), "kernel_rng": kernel.random_state,
        "latency_rng": kernel.agent_latency_model.random_state, "oracle": kernel.oracle,
        "ids": [Order._order_id_counter, Message._Message__message_id_counter],
        "times": [kernel.current_time, kernel.ttl_messages, kernel.agent_current_times, kernel.agent_computation_delays,
            kernel.current_agent_additional_delay, kernel._deliver_seq, kernel._deliver_seq_by_key, kernel._current_causal_uid],
        "observer": {key: value for key, value in vars(observer.STATE).items() if key not in ("inference", "contract")},
        "raw_aliases": [kernel.agents[1] is agent, agent.kernel is kernel, agent.oracle is kernel.oracle],
        "outcome": outcome, "warning_values": warning_values}
    if roundtrip:
        exchange = kernel.agents[0]
        roots["exchange"] = {key: value for key, value in vars(exchange).items() if key not in ("kernel", "order_books")}
        roots["book"] = exchange.order_books["ABM"]
    # One root graph/memo preserves aliases between agent holdings/orders/logs,
    # raw queue/ledger messages, exchange/log/book data and NumPy state owners.
    return graph(roots, np)


def probe_case(strategy, case, engine, owner_probe, np):
    import original_canonical_engine
    import observer
    scenario = {"scenario_id": "strategy-source-control", "seed": 1, "horizon_ns": 1000,
        "agent_configs": [{"agent_type": strategy, "count": 1}], "exchange_config": {}, "oracle_config": {}}
    values = []
    owner_witness = None
    for native in (False, True):
        observer.begin_episode(scenario, authenticated=True)
        try:
            kernel, agent, bids, asks = setup(strategy, case, engine if native else original_canonical_engine, np, native)
            message = None if case.startswith(("wake_", "act_")) else message_for(case, agent, bids, asks)
            operation = "wakeup" if case.startswith("wake_") else "act" if case.startswith("act_") else "receive_message"
            arguments = [kernel.current_time] if operation == "wakeup" else [] if operation == "act" else [kernel.current_time, 0, message]
            with warnings.catch_warnings(record=True) as observed:
                warnings.simplefilter("always")
                try:
                    returned = owner_probe.strategy_transition(kernel._canonical_scheduler, agent, operation, arguments) if native else getattr(agent, operation)(*arguments)
                    outcome = ["returned", encode(returned, np)]
                except Exception as error:
                    outcome = ["raised", type(error).__module__ + "." + type(error).__name__, encode(error.args, np)]
                warning_values = [(item.category.__name__, str(item.message)) for item in observed]
            assert outcome == ["returned", ["NoneType", None]], (strategy, case, outcome)
            if native: owner_witness = owner_probe.strategy_owner(kernel, agent)
            values.append(snapshot(kernel, agent, np, observer, outcome, warning_values))
        finally:
            observer.finish_episode()
    assert values[0] == values[1], (strategy, case, "original/cdef complete strategy boundary differs")
    assert owner_witness and all(owner_witness[key] is True for key in ("original_raw_agent_sole_state",
        "actual_scheduler_agent_kernel_alias", "same_extension_strategy_scheduler_book", "original_cancel_default_alias", "control_only"))
    return {"strategy": strategy, "case": case, "passed": True, "two_arms_complete_equal": True, "owner": owner_witness}


def error_case(strategy, case, engine, owner_probe, np):
    """Independent expected type plus complete state/exception/warning equality."""
    import original_canonical_engine
    import observer
    from abides_markets.orders import LimitOrder, Side
    scenario = {"agent_configs": [{"agent_type": strategy, "count": 1}]}
    values = []
    expected = {"malformed_depth": "builtins.IndexError", "latency_raises_after_order_copy": "builtins.RuntimeError",
        "observer_raises_after_enqueue": "builtins.RuntimeError", "past_wakeup": "builtins.ValueError",
        "oracle_raises_after_mid": "builtins.RuntimeError", "missing_known_symbol": "builtins.KeyError"}
    for native in (False, True):
        observer.begin_episode(scenario, authenticated=True)
        original_order_observer = observer.order
        try:
            kernel, agent, bids, asks = setup(strategy, "act_both", engine if native else original_canonical_engine, np, native)
            def failed(*args, **kwargs): raise RuntimeError("strategy boundary " + case + " failed")
            operation, arguments = "act", []
            if case == "malformed_depth": agent.known_bids["ABM"] = [(99,)]
            elif case == "missing_known_symbol": del agent.known_bids["ABM"]
            elif case == "negative_order_warning": operation, arguments = "place_limit_order", ["ABM", -1, Side.BID, 100]
            elif case == "cancel_nonlimit_warning": operation, arguments = "cancel_order", [None, None, {}]
            elif case == "latency_raises_after_order_copy":
                operation, arguments = "place_limit_order", ["ABM", 3, Side.BID, 100]
                kernel.agent_latency_model.get_latency = failed
            elif case == "observer_raises_after_enqueue":
                operation, arguments = "place_limit_order", ["ABM", 3, Side.BID, 100]
                observer.order = failed
            elif case == "past_wakeup":
                operation, arguments = "wakeup", [1]
                agent.first_wake = False
                agent.interval_ns = 1
            elif case == "oracle_raises_after_mid":
                agent.oracle.observe_price = failed
            else: raise ValueError("unknown error boundary")
            with warnings.catch_warnings(record=True) as observed:
                warnings.simplefilter("always")
                try:
                    value = owner_probe.strategy_transition(kernel._canonical_scheduler, agent, operation, arguments) if native else getattr(agent, operation)(*arguments)
                    outcome = ["returned", encode(value, np)]
                except Exception as error:
                    outcome = ["raised", type(error).__module__ + "." + type(error).__name__, encode(error.args, np)]
                warning_values = [(item.category.__name__, str(item.message)) for item in observed]
            if case in expected: assert outcome[:2] == ["raised", expected[case]], (strategy, case, outcome)
            else:
                assert outcome == ["returned", ["NoneType", None]] and len(warning_values) == 1
            # Test callbacks are intentionally non-production. Do not encode the
            # bound failing callable itself; all actual business fields remain.
            if case == "oracle_raises_after_mid": del agent.oracle.observe_price
            values.append(snapshot(kernel, agent, np, observer, outcome, warning_values))
        finally:
            observer.order = original_order_observer
            observer.finish_episode()
    assert values[0] == values[1], (strategy, case, "original/cdef partial-error boundary differs")
    return {"strategy": strategy, "case": case, "passed": True, "exact_outcome_partial_state_warnings_equal": True}


def roundtrip_case(strategy, protocol, engine, owner_probe, np):
    """Actual production scheduler wake→spread→act→book→report return chain."""
    import original_canonical_engine
    import observer
    from abides_markets.orders import LimitOrder, Side
    from abides_core.message import WakeupMsg
    from abides_markets.messages.order import LimitOrderMsg
    import heapq
    from datetime import datetime
    scenario = {"agent_configs": [{"agent_type": strategy, "count": 1}]}
    values = []
    for native in (False, True):
        observer.begin_episode(scenario, authenticated=True)
        try:
            kernel, agent, bids, asks = setup(strategy, "act_both", engine if native else original_canonical_engine, np, native)
            exchange = kernel.agents[0]
            exchange.stp_policy = "cancel_oldest" if protocol else None
            exchange.pipeline_delay = 3 if protocol else 0
            exchange.computation_delay = 2 if protocol else 0
            agent.first_wake = False
            agent.interval_ns = 10000
            # Actual original order messages seed both sides before a raw wake.
            for side, price in ((Side.BID, 99), (Side.ASK, 101)):
                order = LimitOrder(1, 110, "ABM", 7, side, price)
                agent.orders[order.order_id] = deepcopy(order)
                kernel.send_message(1, 0, LimitOrderMsg(order))
            heapq.heappush(kernel.messages.queue, (180, 1, 1, WakeupMsg()))
            kernel.stop_time = 500
            kernel.event_queue_wall_clock_start = datetime.now()
            returned = kernel.runner()
            assert returned == {"done": True, "result": None}
            assert kernel.ttl_messages > 0
            result = snapshot(kernel, agent, np, observer, returned, [], roundtrip=True)
            if native:
                owner_probe.strategy_owner(kernel, agent)
                owner_probe.audit_transaction(kernel, exchange)
            values.append(result)
        finally:
            observer.finish_episode()
    # Exact NativeLevel/PriceLevel and book type mapping is inside the finite
    # graph, after actual private owner checks; every raw field stays present.
    assert values[0] == values[1], (strategy, protocol, "complete original/cdef scheduler transaction chain differs")
    return {"strategy": strategy, "protocol": protocol, "passed": True, "actual_scheduler_transaction_roundtrip_equal": True}
