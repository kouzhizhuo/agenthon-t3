"""Execute future real Cython strategy controls only against actual deployment."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists(): raise ValueError("fresh actual strategy control result required")
    pins = json.loads((HERE / "RUNTIME_PINS.json").read_text())
    for row in pins["files"]:
        data = (args.runtime / row["path"]).read_bytes()
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            raise ValueError("actual strategy fixture runtime changed")
    sys.path.insert(0, str(args.runtime.resolve()))
    from bootstrap import activate
    activate()
    import numpy as np
    from transaction_loader import load_transaction, native_receipt
    from owner_probe_loader import load_owner_probe
    from strategy_fixtures import CASES, ERROR_CASES, ROUNDTRIP_CASES, probe_case, error_case, roundtrip_case
    report = {"schema": "t3-native-transaction-v6-strategy-controls-v1", "all_passed": False,
        "cases": [], "failures": [], "runtime_files": 64, "expected_boundary_cases": 141,
        "strategy_types": 4, "original_raw_agent_sole_state": True, "rankable": False, "timing_claim": False}
    try:
        engine = load_transaction()
        owner_probe = load_owner_probe(engine)
        report["native_receipt"] = native_receipt()
        assert report["native_receipt"]["native_load_count"] == 1
        from strategy_graph_controls import run_all as graph_controls
        report["strategy_graph_oracle"] = graph_controls(np)
        assert len(report["strategy_graph_oracle"]["cases"]) == 8
        assert len(CASES) == 104
        for strategy, case in CASES:
            report["cases"].append(probe_case(strategy, case, engine, owner_probe, np))
        assert len(ERROR_CASES) == 29 and len(ROUNDTRIP_CASES) == 8
        for strategy, case in ERROR_CASES:
            report["cases"].append(error_case(strategy, case, engine, owner_probe, np))
        for strategy, protocol in ROUNDTRIP_CASES:
            report["cases"].append(roundtrip_case(strategy, protocol, engine, owner_probe, np))
        report["all_passed"] = len(report["cases"]) == 141
    except Exception as error:
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
