cdef class FlatHeap:
    cdef dict __dict__

cdef class ColumnLedger:
    cdef dict __dict__
    cdef list c0, c1, c2, c3, c4, c5, c6, c7, c8
    cdef void _append(self, message_id, src_id, dst_id, t_send_ns, t_recv_ns,
                     latency_ns, msg_type, order_id, causal_parent) except *

cdef class CanonicalScheduler:
    cdef object kernel
    cdef object exchange_owner
    cdef object _run(self, agent_actions)
    cdef object _send(self, sender_id, recipient_id, message, delay)
    cdef object _set_wakeup(self, sender_id, requested_time)
    cdef object _receive(self, kernel, sender_id, recipient_id, message)
    cdef object _record_send(self, kernel, message, sender_id, recipient_id,
                             sent_time, deliver_at)
    cdef object _exchange_receive(self, a, current_time, sender_id, message)
    cdef object _exchange_send(self, a, recipient_id, message)
    cdef object _publish(self, a)

    cdef object _base_wakeup(self, a, current_time)
    cdef object _base_receive_message(self, a, current_time, sender_id, message)
    cdef object _trading_wakeup(self, a, current_time)
    cdef object _trading_receive_message(self, a, current_time, sender_id, message)
    cdef object _trader_wakeup(self, a, current_time)
    cdef object _trader_receive_message(self, a, current_time, sender_id, message)
    cdef object _trader_get_current_spread(self, a, symbol, depth=*)
    cdef object _trader_get_known_bid_ask(self, a, symbol, best=*)
    cdef object _trader_place_limit_order(self, a, symbol, quantity, side, limit_price, order_id=*, is_hidden=*, is_price_to_comply=*, insert_by_id=*, is_post_only=*, ignore_risk=*, tag=*)
    cdef object _trader_create_limit_order(self, a, symbol, quantity, side, limit_price, order_id=*, is_hidden=*, is_price_to_comply=*, insert_by_id=*, is_post_only=*, ignore_risk=*, tag=*)
    cdef object _trader_cancel_all_orders(self, a)
    cdef object _trader_cancel_order(self, a, order, tag, metadata)
    cdef object _trader_order_accepted(self, a, order)
    cdef object _trader_order_executed(self, a, order)
    cdef object _trader_order_cancelled(self, a, order)
    cdef object _trader_order_partial_cancelled(self, a, order)
    cdef object _trader_order_modified(self, a, order)
    cdef object _trader_order_replaced(self, a, old_order, new_order)
    cdef object _trader_market_closed(self, a)
    cdef object _trader_query_last_trade(self, a, symbol, price)
    cdef object _trader_query_spread(self, a, symbol, price, bids, asks, book)
    cdef object _trader_query_order_stream(self, a, symbol, orders)
    cdef object _trader_query_transacted_volume(self, a, symbol, bid_volume, ask_volume)
    cdef object _trader_handle_market_data(self, a, message)
    cdef object _trader_get_wake_frequency(self, a)
    cdef object _trader_mark_to_market(self, a, holdings, use_midpoint=*)
    cdef object _trader_get_known_bid_ask_midpoint(self, a, symbol)
    cdef object _trader_fmt_holdings(self, a, holdings)
    cdef object _act_NoiseTrader(self, a)
    cdef object _act_MarketMaker(self, a)
    cdef object _act_ValueTrader(self, a)
    cdef object _act_MomentumTrader(self, a)
    cdef object _trader_send(self, a, recipient_id, message, delay=*)
    cdef object _trader_set_wakeup(self, a, requested_time)
    cdef object _trader_act(self, a)

cdef class NativeLevel:
    cdef dict __dict__
    cdef object _add_order(self, object order, object metadata=*)
    cdef object _update_order_quantity(self, object order_id, object new_quantity)
    cdef object _remove_order(self, object order_id)
    cdef object _peek(self)
    cdef object _pop(self)
    cdef object _order_is_match(self, object order)
    cdef object _order_has_better_price(self, object order)
    cdef object _order_has_worse_price(self, object order)
    cdef object _order_has_equal_price(self, object order)
    cdef object _total_quantity(self)
    cdef object _is_empty(self)

cdef class NativeBook:
    cdef dict __dict__
    cdef CanonicalScheduler _scheduler
    cdef object _handle_limit_order(self, object order, object quiet=*)
    cdef object _handle_market_order(self, object order)
    cdef object _execute_order(self, object order)
    cdef object _enter_order(self, object order, object metadata=*, object quiet=*)
    cdef object _cancel_order(self, object order, object tag=*, object cancellation_metadata=*, object quiet=*)
    cdef object _modify_order(self, object order, object new_order)
    cdef object _partial_cancel_order(self, object order, object quantity, object tag=*, object cancellation_metadata=*)
    cdef object _replace_order(self, object agent_id, object old_order, object new_order)
    cdef object _append_book_log2(self)
    cdef object _get_l1_bid_data(self)
    cdef object _get_l1_ask_data(self)
    cdef object _get_l2_bid_data(self, object depth=*)
    cdef object _get_l2_ask_data(self, object depth=*)
    cdef object _get_l3_bid_data(self, object depth=*)
    cdef object _get_l3_ask_data(self, object depth=*)
    cdef object _get_transacted_volume(self, object lookback_period=*)
    cdef object _get_imbalance(self)
    cdef object _send(self, recipient_id, message)
