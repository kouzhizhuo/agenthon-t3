"""Future finite encoder self-controls, called only by actual Linux runner."""
from collections import defaultdict, deque
from types import SimpleNamespace
from strategy_graph import graph


def run_all(np):
    rows = []
    mapping = defaultdict(list)
    mapping["self"] = mapping
    value = graph(mapping, np)
    assert value == ["defaultdict", 0, ["binding", "builtins", "list"], [[["str", "self"], ["ref", 0]]]]
    rows.append({"case": "exact_factory_and_recursive_mapping", "passed": True})
    assert graph(defaultdict(None), np) == ["defaultdict", 0, ["NoneType", None], []]
    rows.append({"case": "None_factory_distinct", "passed": True})
    calls = []
    def unknown():
        calls.append(True)
        return []
    try:
        graph(defaultdict(unknown), np)
    except TypeError as error:
        assert str(error) == "unsupported strategy graph defaultdict factory"
    else:
        raise AssertionError("unknown factory accepted")
    assert calls == []
    rows.append({"case": "unknown_factory_refused_without_invocation", "passed": True})
    shared = []
    mapping = defaultdict(list, [("z", shared), ("a", shared)])
    value = graph([mapping, shared], np)
    assert [item[0] for item in value[2][0][3]] == [["str", "z"], ["str", "a"]]
    assert value[2][0][3][0][1] == ["list", 2, []]
    assert value[2][0][3][1][1] == value[2][1] == ["ref", 2]
    rows.append({"case": "insertion_order_and_cross_root_shared_list", "passed": True})
    obj = SimpleNamespace(payload=shared)
    value = graph([obj, obj, shared], np)
    assert value[2][1] == ["ref", 1] and value[2][2] == ["ref", 2]
    rows.append({"case": "raw_object_and_payload_alias", "passed": True})
    array = np.array([1, 2], dtype=np.int64)
    value = graph([array, array], np)
    assert value[2][0][:4] == ["ndarray", 1, "int64", [2]] and value[2][1] == ["ref", 1]
    rows.append({"case": "NumPy_array_exact_dtype_bytes_shared_owner", "passed": True})
    rng = np.random.RandomState(11)
    value = graph([rng, rng], np)
    assert value[2][0][:2] == ["RandomState", 1] and value[2][1] == ["ref", 1]
    rows.append({"case": "RandomState_exact_state_shared_owner", "passed": True})
    queue = deque([shared])
    value = graph([queue, queue, shared], np)
    assert value[2][0] == ["deque", 1, [["list", 2, []]]]
    assert value[2][1] == ["ref", 1] and value[2][2] == ["ref", 2]
    rows.append({"case": "deque_and_child_alias", "passed": True})
    return {"schema": "t3-native-transaction-v6-strategy-graph-controls-v1", "all_passed": True,
        "cases": rows, "single_shared_graph_memo_checked": True, "factory_never_called": True,
        "control_only": True, "production_hot_counters": False, "rankable": False}
