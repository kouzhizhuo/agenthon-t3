"""Production fixed-JSON/preinitialize topology admission; no source audit.

Deployment/code authority belongs to external build/host proof. This module
never reads files, compiles source, imports scientific code or authenticates
mutable first-observed code.
"""
from collections import defaultdict
import types

def admit_scenario(value):

    def plain(child):
        if child is None or any((type(child) is owner for owner in (str, int, float, bool))):
            return True
        if type(child) is list:
            return all((plain(item) for item in child))
        if type(child) is dict:
            return all((type(key) is str and plain(item) for (key, item) in child.items()))
        return False
    if type(value) is not dict or not plain(value) or type(value.get('agent_configs')) is not list:
        return False
    return bool(value['agent_configs']) and all((type(row) is dict and row.get('agent_type') in ('NoiseTrader', 'MarketMaker', 'ValueTrader', 'MomentumTrader') and (type(row.get('count')) is int) and (row['count'] >= 0) for row in value['agent_configs']))

def admit_kernel(kernel, engine):
    from abides_fork.agents import AGENT_REGISTRY
    from abides_markets.agents.exchange_agent import ExchangeAgent
    values = kernel.agents
    if type(values) is not list or not values or type(values[0]) is not ExchangeAgent or kernel.gym_agents:
        raise ValueError('transaction exchange-first producer domain unsupported before initialize')
    if any((type(a.id) is not int or a.id != index for (index, a) in enumerate(values))):
        raise ValueError('transaction exact dense raw IDs required')
    for a in values:
        if a is not values[0] and (not any((type(a) is owner for owner in AGENT_REGISTRY.values()))):
            raise ValueError('transaction unknown raw producer owner')
        methods = {name for base in type(a).__mro__ for (name, value) in vars(base).items() if isinstance(value, (types.FunctionType, property, staticmethod, classmethod))}
        if methods.intersection(vars(a)):
            raise ValueError('transaction refuses instance callable overrides before initialize')
        if a.kernel is not None:
            raise ValueError('transaction agent already initialized')
    exchange = values[0]
    if type(exchange.order_books) is not dict or type(exchange.data_subscriptions) not in (dict, defaultdict):
        raise ValueError('transaction raw book/subscription mapping owner differs')
    for (symbol, book) in exchange.order_books.items():
        if type(book) is not engine.NativeBook or book.owner is not exchange or book.symbol != symbol:
            raise ValueError('transaction exact typed book owner differs')
        for name in ('bids', 'asks', 'book_log2', 'history', 'buy_transactions', 'sell_transactions'):
            if type(getattr(book, name)) is not list or getattr(book, name):
                raise ValueError('transaction book must have empty original list aliases')
        if type(book.quotes_seen) is not set or book.quotes_seen or book.last_trade is not None:
            raise ValueError('transaction book initial business state differs')
    return True
