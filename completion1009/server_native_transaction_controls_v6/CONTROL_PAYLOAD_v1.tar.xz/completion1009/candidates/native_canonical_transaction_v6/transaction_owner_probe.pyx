"""Control-only private layout reads. No hot counters or mutation in production."""
from native_canonical_transaction cimport CanonicalScheduler, NativeBook, NativeLevel, ColumnLedger
import native_canonical_transaction as owner


def bind_owner(native):
    assert native is owner
    return True


def audit_owner(kernel):
    cdef CanonicalScheduler scheduler
    scheduler = kernel._canonical_scheduler
    assert type(scheduler) is owner.CanonicalScheduler and scheduler.kernel is kernel
    result = audit_ledger(kernel._msg_ledger)
    result.update(scheduler_kernel_identity=True)
    return result


def audit_transaction(kernel, exchange):
    cdef CanonicalScheduler scheduler
    cdef NativeBook book
    cdef NativeLevel level
    cdef ColumnLedger ledger
    scheduler = kernel._canonical_scheduler
    assert type(scheduler) is owner.CanonicalScheduler
    assert scheduler.kernel is kernel and scheduler.exchange_owner is exchange
    ledger = kernel._msg_ledger
    assert type(ledger) is owner.ColumnLedger
    columns = ledger.columns
    assert type(columns) is tuple and len(columns) == 9 and len({id(v) for v in columns}) == 9
    assert ledger.c0 is columns[0] and ledger.c1 is columns[1] and ledger.c2 is columns[2]
    assert ledger.c3 is columns[3] and ledger.c4 is columns[4] and ledger.c5 is columns[5]
    assert ledger.c6 is columns[6] and ledger.c7 is columns[7] and ledger.c8 is columns[8]
    rows = []
    for symbol, value in exchange.order_books.items():
        assert type(value) is owner.NativeBook
        book = value
        assert book.owner is exchange and book._scheduler is scheduler
        assert type(book.bids) is list and type(book.asks) is list
        for value in book.bids + book.asks:
            assert type(value) is owner.NativeLevel
            level = value
            assert type(level.visible_orders) is list and type(level.hidden_orders) is list
        rows.append({"symbol": symbol, "same_scheduler": True, "raw_owner": True,
                     "bid_levels": len(book.bids), "ask_levels": len(book.asks)})
    return {"schema": "t3-native-canonical-transaction-private-owner-control-v1",
            "control_only": True, "mutation_performed": False, "production_hot_counters": False,
            "same_extension_book_level_scheduler": True, "nine_original_column_list_aliases": True,
            "books": rows}


def audit_ledger(value):
    cdef ColumnLedger ledger
    assert type(value) is owner.ColumnLedger
    ledger = value
    columns = ledger.columns
    assert ledger.c0 is columns[0] and ledger.c1 is columns[1] and ledger.c2 is columns[2]
    assert ledger.c3 is columns[3] and ledger.c4 is columns[4] and ledger.c5 is columns[5]
    assert ledger.c6 is columns[6] and ledger.c7 is columns[7] and ledger.c8 is columns[8]
    return {"column_list_aliases": [True] * 9, "column_lists_distinct": len({id(v) for v in columns}) == 9}


def exchange_receive(scheduler_value, a, current_time, sender_id, message):
    cdef CanonicalScheduler scheduler = scheduler_value
    return scheduler._exchange_receive(a, current_time, sender_id, message)


def exchange_send(scheduler_value, a, recipient_id, message):
    cdef CanonicalScheduler scheduler = scheduler_value
    return scheduler._exchange_send(a, recipient_id, message)


def strategy_transition(scheduler_value, a, operation, arguments):
    """Control-only cdef entry; no instrumentation or second business owner."""
    cdef CanonicalScheduler scheduler = scheduler_value
    assert scheduler.kernel is a.kernel
    if operation == "wakeup":
        assert len(arguments) == 1
        return scheduler._trader_wakeup(a, arguments[0])
    if operation == "receive_message":
        assert len(arguments) == 3
        return scheduler._trader_receive_message(a, arguments[0], arguments[1], arguments[2])
    if operation == "act":
        assert not arguments
        return scheduler._trader_act(a)
    if operation == "place_limit_order":
        assert len(arguments) == 4
        return scheduler._trader_place_limit_order(a, arguments[0], arguments[1], arguments[2], arguments[3])
    if operation == "cancel_order":
        assert len(arguments) == 3
        return scheduler._trader_cancel_order(a, arguments[0], arguments[1], arguments[2])
    if operation == "get_known_bid_ask":
        assert len(arguments) == 2
        return scheduler._trader_get_known_bid_ask(a, arguments[0], arguments[1])
    raise ValueError("unknown native strategy control operation")


def strategy_owner(kernel, a):
    from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
    assert type(a) in (NoiseTrader, MarketMaker, ValueTrader, MomentumTrader)
    assert kernel.agents[a.id] is a and a.kernel is kernel
    assert type(kernel._canonical_scheduler) is owner.CanonicalScheduler
    assert owner.DEFAULT_CANCEL_TAG is owner.TradingAgent.cancel_order.__defaults__[0]
    assert owner.DEFAULT_CANCEL_METADATA is owner.TradingAgent.cancel_order.__defaults__[1]
    return {"original_raw_agent_sole_state": True, "actual_scheduler_agent_kernel_alias": True,
            "same_extension_strategy_scheduler_book": True, "original_cancel_default_alias": True,
            "production_event_proof_counters": False, "control_only": True}
