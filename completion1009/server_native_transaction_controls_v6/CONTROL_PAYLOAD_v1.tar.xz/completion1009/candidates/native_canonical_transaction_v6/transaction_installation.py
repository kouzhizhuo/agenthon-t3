"""Install the deploy-bound ordinary JSON episode; no per-episode source audit."""
from contextlib import contextmanager


@contextmanager
def enabled(scenario, arm="actual_native"):
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_fork import trace
    from abides_fork.config import ScenarioLatencyModel
    from abides_markets.agents import exchange_agent
    from abides_markets.order_book import OrderBook
    from column_trace import make_extractor
    from optimizations import scalar_latency
    from transaction_admission import admit_scenario
    if arm not in ("actual_native", "original_canonical"):
        raise ValueError("unknown transaction arm")
    admitted = admit_scenario(scenario)
    if not admitted:
        yield {"extractor": trace.extract_message_trace, "requested_arm": arm,
               "native_active": False, "json_domain_admitted": False,
               "fallback_before_configuration": True, "observer_authenticated": False,
               "installed_engine": "original_incumbent", "deployment_authority": None,
               "per_episode_source_hashes": 0, "per_episode_original_source_compilations": 0}
        return

    if arm == "actual_native":
        from transaction_loader import load_transaction, native_receipt
        engine = load_transaction()
        authority = native_receipt()["deployment_authority"]

        class GuardedKernel(engine.CanonicalKernel):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                from transaction_admission import admit_kernel
                admit_kernel(self, engine)
                self._canonical_scheduler.bind_exchange(self.agents[0])

        chosen, book_owner = GuardedKernel, engine.NativeBook
    else:
        import original_canonical_engine as engine
        chosen, book_owner, authority = engine.CanonicalKernel, OrderBook, None
    if (engine.IncumbentKernel is not Kernel or exchange_agent.OrderBook is not OrderBook
            or engine.CanonicalKernel.initialize is not Kernel.initialize
            or engine.CanonicalKernel.terminate is not Kernel.terminate):
        raise ValueError("transaction deployment original owner differs before installation")
    extractor = make_extractor(engine.ColumnLedger, trace.extract_message_trace,
                               trace.MESSAGE_TRACE_COLUMNS, trace._MSG_DTYPES)
    old_kernel, old_book, old_latency = abides.Kernel, exchange_agent.OrderBook, ScenarioLatencyModel.get_latency
    abides.Kernel, exchange_agent.OrderBook, ScenarioLatencyModel.get_latency = chosen, book_owner, scalar_latency
    try:
        yield {"extractor": extractor, "requested_arm": arm, "native_active": arm == "actual_native",
               "json_domain_admitted": True, "fallback_before_configuration": False,
               "observer_authenticated": True, "installed_engine": "canonical",
               "deployment_authority": authority, "per_episode_source_hashes": 0,
               "per_episode_original_source_compilations": 0}
    finally:
        abides.Kernel, exchange_agent.OrderBook, ScenarioLatencyModel.get_latency = old_kernel, old_book, old_latency
