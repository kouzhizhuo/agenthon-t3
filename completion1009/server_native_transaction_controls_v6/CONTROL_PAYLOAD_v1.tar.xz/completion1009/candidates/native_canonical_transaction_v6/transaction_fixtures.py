"""Future finite controls for complete Exchange -> book -> scheduler return leg.

Author preparation only AST-parses this source; these fixtures are never called
locally. The root's isolated Linux command must use the real built extensions.
"""
from collections import defaultdict
from copy import deepcopy
from datetime import datetime
from types import SimpleNamespace

CASES = (
    "limit_accept", "limit_match_matched_then_aggressor", "market_partial_match", "cancel_found",
    "cancel_missing_false", "partial_cancel", "modify_quantity", "replace", "unknown_symbol_warning",
    "invalid_quantity_warning", "invalid_price_warning", "market_closed", "stp_cancel_oldest",
    "stp_cancel_newest", "price_to_comply_hidden_visible", "quiet_limit_no_accept", "matched_first_send_failure",
    "first_constructor_failure", "second_constructor_failure", "latency_before_heap_failure",
    "observer_failure_after_enqueue", "publish_live_subscription_mutation", "replace_copy_failure",
    "modify_second_copy_failure", "cancel_tag_getter_failure", "book_warning_raises",
    "message_type_failure_after_heap", "order_id_failure_after_heap",
)


def freeze(value, memo=None):
    """Record exact reachable business contents and aliases; clocks excluded."""
    memo = {} if memo is None else memo
    if value is None or type(value) in (str, bool, int):
        return [type(value).__name__, value]
    if type(value) is float:
        return ["float", value.hex()]
    if type(value) is bytes:
        return ["bytes", value.hex()]
    if type(value).__module__.startswith("numpy"):
        return [type(value).__name__, str(value.dtype), value.tolist()]
    if id(value) in memo:
        return ["ref", memo[id(value)]]
    memo[id(value)] = len(memo)
    if type(value) in (list, tuple):
        return [type(value).__name__, [freeze(v, memo) for v in value]]
    if type(value) is defaultdict:
        # The fixed original Exchange subscription map owns exact builtins.list
        # as factory. Do not invoke it, project to dict or lose graph aliases.
        factory = value.default_factory
        if factory is not None and factory is not list:
            raise AssertionError("unsupported fixture defaultdict factory")
        token = ["NoneType", None] if factory is None else ["binding", "builtins", "list"]
        return ["defaultdict", token, [[freeze(k, memo), freeze(v, memo)] for k, v in value.items()]]
    if type(value) is dict:
        return ["dict", [[freeze(k, memo), freeze(v, memo)] for k, v in value.items()]]
    if type(value) is set:
        return ["set", sorted((freeze(v, {}) for v in value), key=repr)]
    if callable(value):
        return ["callback", getattr(value, "__name__", type(value).__name__)]
    if hasattr(value, "value") and hasattr(value, "name"):
        return ["enum", type(value).__name__, value.name]
    if hasattr(value, "__dict__"):
        label = type(value).__name__
        if label in ("NativeBook", "OrderBook"):
            label = "Book"
        if label in ("NativeLevel", "PriceLevel"):
            label = "Level"
        return [label, freeze(vars(value), memo)]
    raise AssertionError("unsupported fixture object: " + type(value).__name__)


def outcome(call, expected=None):
    try:
        result = call()
    except BaseException as error:
        if expected is None:
            raise AssertionError("unexpected fixture exception") from error
        assert type(error) is expected[0] and error.args == expected[1]
        return ["raises", type(error).__name__, freeze(error.args)]
    assert expected is None, "intended exception absent"
    assert result is None, "complete Exchange operation must retain original void return"
    return ["returns", None]


def run_case(case, engine, probe, np, native):
    import heapq
    import observer
    import warnings
    from abides_core.message import Message
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.order_book import OrderBook
    from abides_markets.orders import Order, LimitOrder, MarketOrder, Side
    from abides_markets.messages.order import LimitOrderMsg, MarketOrderMsg, CancelOrderMsg, PartialCancelOrderMsg, ModifyOrderMsg, ReplaceOrderMsg
    from abides_markets.messages.orderbook import OrderExecutedMsg, OrderAcceptedMsg
    from abides_markets.agents import exchange_agent
    Order._order_id_counter = 100
    Message._Message__message_id_counter = 1000
    old_constructor = exchange_agent.OrderBook
    old_order_observer, old_diag, old_record_log = observer.order, observer.diagnostic, observer.record_log
    events = []
    exchange_agent.OrderBook = engine.NativeBook if native else OrderBook
    try:
        exchange = ExchangeAgent(0, 0, 1000, ["ABM"], name="fixture_exchange", type="ExchangeAgent",
            book_logging=False, pipeline_delay=7, computation_delay=2,
            stream_history=10, log_orders=True, random_state=np.random.RandomState(101))
    finally:
        exchange_agent.OrderBook = old_constructor
    receiver = SimpleNamespace(id=1, name="fixture_trader")
    resting_receiver = SimpleNamespace(id=2, name="resting_trader")
    kernel = engine.CanonicalKernel([exchange, receiver, resting_receiver], start_time=1, stop_time=1000,
        default_computation_delay=2, default_latency=0, latency_noise=[1.0], random_state=np.random.RandomState(303))
    exchange.kernel = kernel
    exchange.current_time = kernel.current_time = 10
    kernel.event_queue_wall_clock_start = datetime.now()
    scheduler = kernel._canonical_scheduler if native else None
    if native:
        scheduler.bind_exchange(exchange)
    observer.order = lambda a, kind, order, **kwargs: events.append(("observer_order", kind, deepcopy(vars(order)), kwargs))
    observer.diagnostic = lambda a, kind, message: events.append(("diagnostic", kind))
    observer.record_log = lambda *args, **kwargs: False
    book = exchange.order_books["ABM"]
    bid = LimitOrder(1, 1, "ABM", 8, Side.BID, 100)
    resting = LimitOrder(2, 1, "ABM", 6, Side.ASK, 100)
    book.handle_limit_order(resting, quiet=True)
    kernel.messages.queue.clear()
    for column in kernel._msg_ledger.columns:
        column.clear()
    events.clear()
    original_uid = Message._Message__message_id_counter
    expected = None
    # Allocate exactly one request before failure controls; otherwise assigning
    # a second normal-case message would obscure constructor/UID residue.
    message = LimitOrderMsg(deepcopy(bid))
    call = lambda: probe.exchange_receive(scheduler, exchange, 10, 1, message) if native else ExchangeAgent.receive_message(exchange, 10, 1, message)
    old_symbols = {}

    def patch(owner, name, value):
        old_symbols[(owner, name)] = getattr(owner, name)
        setattr(owner, name, value)

    def fail(name):
        def callback(*args, **kwargs):
            events.append(("failure", name))
            raise RuntimeError(name)
        return callback

    try:
        if case == "limit_accept":
            message.order.limit_price = 90
        elif case == "limit_match_matched_then_aggressor":
            pass
        elif case == "market_partial_match":
            message = MarketOrderMsg(MarketOrder(1, 1, "ABM", 4, Side.BID))
        elif case in ("cancel_found", "cancel_missing_false"):
            order = deepcopy(resting)
            if case == "cancel_missing_false":
                order.order_id = -200
            message = CancelOrderMsg(order, None, {})
        elif case == "partial_cancel":
            message = PartialCancelOrderMsg(deepcopy(resting), 2, None, {})
        elif case == "modify_quantity":
            changed = deepcopy(resting); changed.quantity = 4
            message = ModifyOrderMsg(deepcopy(resting), changed)
        elif case in ("replace", "replace_copy_failure"):
            changed = deepcopy(resting); changed.order_id += 100; changed.limit_price = 110
            message = ReplaceOrderMsg(2, deepcopy(resting), changed)
            if case.endswith("failure"):
                expected = (RuntimeError, ("replacement_copy",))
                class BrokenOrder(LimitOrder):
                    def __deepcopy__(self, memo):
                        raise RuntimeError("replacement_copy")
                message.new_order = BrokenOrder(2, 1, "ABM", 2, Side.ASK, 110)
        elif case == "unknown_symbol_warning":
            message.order.symbol = "UNKNOWN"
        elif case == "invalid_quantity_warning":
            message.order.quantity = 0
        elif case == "invalid_price_warning":
            message.order.limit_price = -1
        elif case == "market_closed":
            exchange.mkt_close = 9
        elif case in ("stp_cancel_oldest", "stp_cancel_newest"):
            message.order.agent_id = resting.agent_id
            exchange.stp_policy = "cancel_oldest" if case.endswith("oldest") else "cancel_newest"
        elif case == "price_to_comply_hidden_visible":
            message.order.is_price_to_comply = True
            message.order.limit_price = 90
        elif case == "quiet_limit_no_accept":
            message.order.limit_price = 90
            call = lambda: book.handle_limit_order(deepcopy(message.order), quiet=True)
        elif case in ("matched_first_send_failure", "latency_before_heap_failure"):
            expected = (RuntimeError, ("first_send_latency",))
            kernel.agent_latency_model = SimpleNamespace(get_latency=fail("first_send_latency"))
        elif case in ("first_constructor_failure", "second_constructor_failure"):
            expected = (RuntimeError, (case,))
            attempts = []
            original = OrderExecutedMsg
            def constructor(order):
                attempts.append(order.order_id)
                if len(attempts) == (1 if case.startswith("first") else 2):
                    raise RuntimeError(case)
                return original(order)
            # Both source owners use the original book global at construction.
            patch(engine if native else __import__("abides_markets.order_book", fromlist=["OrderExecutedMsg"]), "OrderExecutedMsg", constructor)
        elif case == "observer_failure_after_enqueue":
            expected = (RuntimeError, ("post_send_observer",))
            def observe(a, kind, order, **kwargs):
                if kwargs.get("deepcopy_event") is False:
                    events.append(("pre_observer", kind))
                    return
                raise RuntimeError("post_send_observer")
            observer.order = observe
        elif case == "publish_live_subscription_mutation":
            subscriptions = [exchange.L1DataSubscription(1, 0, 0)]
            exchange.data_subscriptions["ABM"] = subscriptions
            def publish(symbol, sub):
                events.append(("subscription", sub.agent_id))
                if len(subscriptions) == 1:
                    subscriptions.append(exchange.L1DataSubscription(1, 0, 0))
                return []
            exchange.handle_frequency_based_data_subscription = publish
        elif case == "modify_second_copy_failure":
            expected = (RuntimeError, ("modify_second_copy",))
            class BrokenOrder(LimitOrder):
                def __deepcopy__(self, memo):
                    raise RuntimeError("modify_second_copy")
            message = ModifyOrderMsg(deepcopy(resting), BrokenOrder(2, 1, "ABM", 2, Side.ASK, 100))
        elif case == "cancel_tag_getter_failure":
            expected = (RuntimeError, ("cancel_tag",))
            class BrokenCancel(CancelOrderMsg):
                def __getattribute__(self, name):
                    if name == "tag":
                        raise RuntimeError("cancel_tag")
                    return super().__getattribute__(name)
            message = BrokenCancel(deepcopy(resting), None, {})
        elif case == "book_warning_raises":
            message.order.quantity = 0
            expected = (RuntimeError, ("warning",))
            patch(warnings, "warn", fail("warning"))
        elif case in ("message_type_failure_after_heap", "order_id_failure_after_heap"):
            expected = (RuntimeError, (case,))
            class BrokenMessage(OrderAcceptedMsg):
                def type(self):
                    if case.startswith("message_type"):
                        raise RuntimeError(case)
                    return super().type()
            if case.startswith("order_id"):
                class BrokenId:
                    @property
                    def order_id(self):
                        raise RuntimeError(case)
                value = BrokenMessage(BrokenId())
            else:
                value = BrokenMessage(deepcopy(bid))
            call = lambda: probe.exchange_send(scheduler, exchange, 1, value) if native else ExchangeAgent.send_message(exchange, 1, value)
        else:
            raise AssertionError("unknown transaction fixture")
        result = outcome(call, expected)
        witness = probe.audit_transaction(kernel, exchange) if native else None
        state = {"books": exchange.order_books, "subscriptions": exchange.data_subscriptions,
            "metric_trackers": exchange.metric_trackers,
            "market_close_subscriptions": exchange.market_close_price_subscriptions,
            "log": exchange.log, "summary": kernel.summary_log, "events": events,
            "heap": kernel.messages.queue, "ledger": list(kernel._msg_ledger.columns),
            "kernel_rng": kernel.random_state.get_state(), "exchange_rng": exchange.random_state.get_state(),
            "counters": [Order._order_id_counter, Message._Message__message_id_counter],
            "current": [exchange.current_time, kernel.current_time, kernel.agent_computation_delays,
                        kernel.agent_current_times, kernel.current_agent_additional_delay,
                        kernel._current_causal_uid, kernel._deliver_seq, kernel._deliver_seq_by_key],
            "outcome": result}
        # Kernel cycles are excluded from book owner only after alias witness.
        for b in exchange.order_books.values():
            assert b.owner is exchange
        exchange.kernel = None
        for b in exchange.order_books.values():
            b.owner = None
        encoded = freeze(state)
        if case == "matched_first_send_failure":
            assert Message._Message__message_id_counter == original_uid + 2
            assert len(kernel.messages.queue) == 0
        if case == "observer_failure_after_enqueue":
            assert len(kernel.messages.queue) == 1 and len(kernel._msg_ledger) == 1
        if case == "quiet_limit_no_accept":
            assert not kernel.messages.queue and len(kernel._msg_ledger) == 0
        if case in ("message_type_failure_after_heap", "order_id_failure_after_heap"):
            assert len(kernel.messages.queue) == 1 and len(kernel._msg_ledger) == 0
        if case == "limit_match_matched_then_aggressor":
            delivered = sorted(kernel.messages.queue, key=lambda row: row[3].message_id)
            assert [row[2] for row in delivered[:2]] == [2, 1]
        if case == "publish_live_subscription_mutation":
            assert [value for value in events if value[0] == "subscription"] == [
                ("subscription", 1), ("subscription", 1)]
        return {"case": case, "state": encoded, "native_private_witness": witness,
                "expected_exception_checked": expected is not None, "return_checked": True}
    finally:
        observer.order, observer.diagnostic, observer.record_log = old_order_observer, old_diag, old_record_log
        for (owner, name), original in old_symbols.items():
            setattr(owner, name, original)


def run_all(native, probe, np):
    import original_canonical_engine as original
    reports = []
    for case in CASES:
        left = run_case(case, original, probe, np, False)
        right = run_case(case, native, probe, np, True)
        assert left["state"] == right["state"], "complete transaction state diverges: " + case
        reports.append({"case": case, "passed": True, "return_checked": True,
            "expected_exception_checked": left["expected_exception_checked"],
            "same_extension_owner_checked": right["native_private_witness"]["same_extension_book_level_scheduler"],
            "state": right["state"]})
    return reports
