"""Explicit control-only actual extension loader after production owner load."""
import importlib.machinery
import importlib.util
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
_probe = None


def load_owner_probe(native):
    global _probe
    if _probe is not None:
        assert sys.modules.get("native_canonical_transaction") is native
        return _probe
    deployment = json.loads((HERE / "DEPLOYMENT.json").read_text())
    native_path = (HERE / deployment["extension_path"]).resolve()
    row = deployment["control_probe"]
    probe_path = (HERE / row["path"]).resolve()
    assert deployment["schema"] == "t3-native-canonical-transaction-deployment-v6"
    assert deployment["candidate"] == HERE.name and row["control_only"] is True
    assert Path(native.__file__).resolve() == native_path
    assert sys.modules.get("native_canonical_transaction") is native
    assert probe_path.parent == (HERE / "native").resolve() and probe_path.is_file()
    assert probe_path.stat().st_size == row["bytes"]
    assert hashlib.sha256(probe_path.read_bytes()).hexdigest() == row["sha256"]
    assert hashlib.sha256(native_path.read_bytes()).hexdigest() == deployment["extension_sha256"]
    assert hashlib.sha256((HERE / "transaction_owner_probe.pyx").read_bytes()).hexdigest() == deployment["control_probe_source_sha256"]
    name = "transaction_owner_probe"
    assert name not in sys.modules
    spec = importlib.util.spec_from_file_location(name, probe_path)
    assert spec is not None and isinstance(spec.loader, importlib.machinery.ExtensionFileLoader)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
        assert Path(module.__file__).resolve() == probe_path
        assert callable(module.audit_owner)
        assert callable(module.audit_ledger)
        assert module.bind_owner(native) is True
        assert sys.modules.get("native_canonical_transaction") is native
    except BaseException:
        sys.modules.pop(name, None)
        raise
    _probe = module
    return module
