"""Exact source-based admission before configuration and stateful callbacks.

The compiled owner is an externally verified read-only deployment. The runtime
method tokens below come from independently compiled original source code, never
from first-observed mutable functions. No source executes in a second namespace.
"""
import ast
import __future__
from collections import defaultdict
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import types

HERE = Path(__file__).resolve().parent
RUNTIME = HERE.parent / "lean_production_native_projection_v1/runtime"
ACTIVE_PYTHON = {
    "abides_fork/agents.py", "abides_fork/config.py", "abides_fork/trace.py", "abides_fork/simulate.py",
    "observer.py", "optimizations.py", "contracts.py", "column_trace.py", "t3_canonical_engine.py",
    "vendor/abides/abides-core/abides_core/kernel.py", "vendor/abides/abides-core/abides_core/agent.py",
    "vendor/abides/abides-core/abides_core/message.py", "vendor/abides/abides-core/abides_core/utils.py",
    "vendor/abides/abides-core/abides_core/latency_model.py", "vendor/abides/abides-core/abides_core/abides.py",
    "vendor/abides/abides-markets/abides_markets/agents/financial_agent.py",
    "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py",
    "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py",
    "vendor/abides/abides-markets/abides_markets/orders.py",
    "vendor/abides/abides-markets/abides_markets/order_book.py",
    "vendor/abides/abides-markets/abides_markets/price_level.py",
    "vendor/abides/abides-markets/abides_markets/oracles/oracle.py",
    "vendor/abides/abides-markets/abides_markets/oracles/sparse_mean_reverting_oracle.py",
    "vendor/abides/abides-markets/abides_markets/messages/order.py",
    "vendor/abides/abides-markets/abides_markets/messages/orderbook.py",
    "vendor/abides/abides-markets/abides_markets/messages/market.py",
    "vendor/abides/abides-markets/abides_markets/messages/marketdata.py",
    "vendor/abides/abides-markets/abides_markets/messages/query.py",
}


def admit_scenario(value):
    def plain(child):
        if child is None or any(type(child) is owner for owner in (str, int, float, bool)):
            return True
        if type(child) is list:
            return all(plain(item) for item in child)
        if type(child) is dict:
            return all(type(key) is str and plain(item) for key, item in child.items())
        return False
    if type(value) is not dict or not plain(value) or type(value.get("agent_configs")) is not list:
        return False
    return bool(value["agent_configs"]) and all(type(row) is dict
        and row.get("agent_type") in ("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader")
        and type(row.get("count")) is int and row["count"] >= 0 for row in value["agent_configs"])


def code_token(code):
    def value(item):
        if type(item) is types.CodeType:
            return ["code", code_token(item)]
        if item is Ellipsis:
            return ["ellipsis"]
        if type(item) is bytes:
            return ["bytes", item.hex()]
        if type(item) is float:
            return ["float", item.hex()]
        if type(item) is complex:
            return ["complex", item.real.hex(), item.imag.hex()]
        if type(item) is tuple:
            return ["tuple", [value(child) for child in item]]
        if type(item) is frozenset:
            return ["frozenset", sorted((value(child) for child in item), key=repr)]
        if item is None or type(item) in (str, bool, int):
            return [type(item).__name__, item]
        raise ValueError("unsupported immutable source code constant")
    keys = ("co_argcount", "co_posonlyargcount", "co_kwonlyargcount", "co_nlocals", "co_stacksize", "co_flags",
            "co_code", "co_names", "co_varnames", "co_freevars", "co_cellvars", "co_name", "co_firstlineno",
            "co_qualname", "co_linetable", "co_exceptiontable")
    return {**{key: value(getattr(code, key)) for key in keys}, "co_consts": [value(child) for child in code.co_consts]}


def _source_codes(code, prefix=()):
    result = {}
    for child in code.co_consts:
        if type(child) is types.CodeType:
            path = prefix + (child.co_name,)
            result[(path, child.co_firstlineno)] = child
            result.update(_source_codes(child, path))
    return result


def _definition_targets(tree):
    """Resolve final source bindings and retained aliases without executing them.

    The pinned trace source keeps its first extract_trace under an alias before
    redefining extract_trace. Both live functions must authenticate separately.
    """
    bindings = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bindings[node.name] = node
        elif isinstance(node, ast.Assign):
            source = bindings.get(node.value.id) if isinstance(node.value, ast.Name) else None
            for target in node.targets:
                if isinstance(target, ast.Name):
                    if source is None:
                        bindings.pop(target.id, None)
                    else:
                        bindings[target.id] = source

    targets = []

    def descend(node, live_parts, source_parts):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            targets.append((live_parts, source_parts, node))
        elif isinstance(node, ast.ClassDef):
            children = {}
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    children[child.name] = child
            for name, child in children.items():
                class_name = node.name.lstrip("_")
                live_name = "_" + class_name + name if name.startswith("__") and not name.endswith("__") and class_name else name
                descend(child, live_parts + (live_name,), source_parts + (child.name,))

    for name, node in bindings.items():
        descend(node, (name,), (node.name,))
    return targets


def _default_value(node, namespace):
    """Resolve source defaults without eval and with exact imported owners."""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return namespace[node.id]
    if isinstance(node, ast.Attribute):
        return getattr(_default_value(node.value, namespace), node.attr)
    if isinstance(node, ast.List):
        return [_default_value(child, namespace) for child in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_default_value(child, namespace) for child in node.elts)
    if isinstance(node, ast.Dict):
        return {_default_value(key, namespace): _default_value(value, namespace)
                for key, value in zip(node.keys, node.values)}
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        value = _default_value(node.operand, namespace)
        return -value if isinstance(node.op, ast.USub) else value
    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "str_to_ns"
            and len(node.args) == 1 and not node.keywords and isinstance(node.args[0], ast.Constant)):
        text = node.args[0].value
        known = {"09:30:00": 34200000000000, "16:00:00": 57600000000000}
        if text in known:
            return known[text]
        raise ValueError("unrecognized exact source time default")
    raise ValueError("unsupported source default must decline before configuration")


def _imports(tree, module):
    namespace = vars(module)
    for node in tree.body:
        if isinstance(node, ast.Import):
            for item in node.names:
                expected = importlib.import_module(item.name if item.asname else item.name.split('.')[0])
                if namespace.get(item.asname or item.name.split('.')[0]) is not expected:
                    raise ValueError("transaction source import identity differs")
        elif isinstance(node, ast.ImportFrom):
            if node.module == "__future__" and node.level == 0:
                # Compiler directives bind no runtime module symbols. Source
                # code tokens include their compiler flags independently.
                for item in node.names:
                    if item.asname or not isinstance(getattr(__future__, item.name, None), __future__._Feature):
                        raise ValueError("transaction unknown future compiler directive")
                continue
            name = node.module or ''
            if node.level:
                name = importlib.util.resolve_name('.' * node.level + name, module.__package__)
            imported = importlib.import_module(name)
            for item in node.names:
                if item.name == '*':
                    names = getattr(imported, '__all__', [key for key in vars(imported) if not key.startswith('_')])
                    if any(namespace.get(key) is not getattr(imported, key) for key in names):
                        raise ValueError("transaction star import owner differs")
                elif namespace.get(item.asname or item.name) is not getattr(imported, item.name):
                    raise ValueError("transaction source imported symbol differs")


def _engine_imports(engine):
    """Check only ordinary import statements in the externally frozen pyx header.

    This is Python AST parsing of imports, never Cython compilation or execution.
    """
    statements = [line for line in (HERE / "native_canonical_transaction.pyx").read_text().splitlines()
                  if line.startswith("import ") or line.startswith("from ")]
    _imports(ast.parse("\n".join(statements)), engine)


def authenticate_runtime(engine):
    from abides_core import kernel, agent, message
    from abides_fork import agents
    from abides_markets import orders, order_book, price_level
    from abides_markets.agents import exchange_agent
    from optimizations import scalar_latency
    import heapq
    import _heapq
    _engine_imports(engine)
    if (engine.IncumbentKernel is not kernel.Kernel or engine.ExchangeAgent is not exchange_agent.ExchangeAgent
            or engine.OriginalOrderBook is not order_book.OrderBook or engine.OriginalPriceLevel is not price_level.PriceLevel
            or engine.Order is not orders.Order or engine.LimitOrder is not orders.LimitOrder or engine.MarketOrder is not orders.MarketOrder
            or engine.Message is not message.Message or engine.MessageBatch is not message.MessageBatch or engine.WakeupMsg is not message.WakeupMsg
            or engine.book_logger is not order_book.logger or engine.exchange_logger is not exchange_agent.logger
            or heapq.heappush is not _heapq.heappush or heapq.heappop is not _heapq.heappop):
        raise ValueError("transaction raw source owners differ")
    pins = json.loads((HERE / "RUNTIME_PINS.json").read_text())
    compiled_modules = 0
    authenticated_functions = 0
    for row in pins["files"]:
        path = RUNTIME / row["path"]
        data = path.read_bytes()
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            raise ValueError("transaction frozen runtime source differs")
        if row["path"] not in ACTIVE_PYTHON:
            continue
        if row["path"].startswith("vendor/abides/abides-core/"):
            module_name = row["path"].split("vendor/abides/abides-core/", 1)[1].removesuffix(".py").replace("/", ".")
        elif row["path"].startswith("vendor/abides/abides-markets/"):
            module_name = row["path"].split("vendor/abides/abides-markets/", 1)[1].removesuffix(".py").replace("/", ".")
        else:
            module_name = row["path"].removesuffix(".py").replace("/", ".")
        module_name = module_name.removesuffix(".__init__")
        module = importlib.import_module(module_name)
        if Path(module.__file__).resolve() != path.resolve():
            raise ValueError("transaction runtime module origin differs: " + module_name)
        expected_codes = _source_codes(compile(data, str(path), "exec", dont_inherit=True))
        compiled_modules += 1
        tree = ast.parse(data)
        _imports(tree, module)
        for parts, source_parts, source_node in _definition_targets(tree):
            owner = module
            for part in parts:
                namespace = vars(owner)
                if part not in namespace:
                    raise ValueError("transaction source method binding absent: " + module_name + "." + ".".join(parts))
                owner = namespace[part]
            if isinstance(owner, (staticmethod, classmethod)):
                owner = owner.__func__
            if isinstance(owner, property):
                owner = owner.fget
            if source_node.decorator_list and any(isinstance(d, ast.Name) and d.id == "contextmanager"
                for d in source_node.decorator_list):
                if type(owner) is not types.FunctionType or not hasattr(owner, "__wrapped__"):
                    raise ValueError("transaction original contextmanager wrapper differs")
                owner = owner.__wrapped__
            # The exact scalar-latency adapter is the sole installation exception.
            if parts == ("ScenarioLatencyModel", "get_latency") and owner is scalar_latency:
                continue
            first_line = min([source_node.lineno] + [d.lineno for d in source_node.decorator_list])
            expected = expected_codes.get((source_parts, first_line))
            if expected is None:
                raise ValueError("transaction source token path unsupported before configuration")
            if type(owner) is not types.FunctionType or code_token(owner.__code__) != code_token(expected):
                raise ValueError("transaction source method code differs: " + module_name + "." + ".".join(parts))
            defaults = tuple(_default_value(child, vars(module)) for child in source_node.args.defaults)
            expected_defaults = defaults if defaults else None
            kwdefaults = {arg.arg: _default_value(child, vars(module)) for arg, child in
                zip(source_node.args.kwonlyargs, source_node.args.kw_defaults) if child is not None}
            if owner.__defaults__ != expected_defaults or owner.__kwdefaults__ != (kwdefaults or None):
                raise ValueError("transaction original source defaults differ")
            authenticated_functions += 1
    if agents.AGENT_REGISTRY != {name: getattr(agents, name) for name in ("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader")}:
        raise ValueError("transaction exact producer registry differs")
    return {"runtime_source_files_hashed": len(pins["files"]),
            "original_source_modules_compiled_for_code_tokens": compiled_modules,
            "source_functions_authenticated": authenticated_functions,
            "runtime_native_compilation": False}


def admit_kernel(kernel, engine):
    from abides_fork.agents import AGENT_REGISTRY
    from abides_markets.agents.exchange_agent import ExchangeAgent
    values = kernel.agents
    if type(values) is not list or not values or type(values[0]) is not ExchangeAgent or kernel.gym_agents:
        raise ValueError("transaction exchange-first producer domain unsupported before initialize")
    if any(type(a.id) is not int or a.id != index for index, a in enumerate(values)):
        raise ValueError("transaction exact dense raw IDs required")
    for a in values:
        if a is not values[0] and not any(type(a) is owner for owner in AGENT_REGISTRY.values()):
            raise ValueError("transaction unknown raw producer owner")
        methods = {name for base in type(a).__mro__ for name, value in vars(base).items()
                   if isinstance(value, (types.FunctionType, property, staticmethod, classmethod))}
        if methods.intersection(vars(a)):
            raise ValueError("transaction refuses instance callable overrides before initialize")
        if a.kernel is not None:
            raise ValueError("transaction agent already initialized")
    exchange = values[0]
    if type(exchange.order_books) is not dict or type(exchange.data_subscriptions) not in (dict, defaultdict):
        raise ValueError("transaction raw book/subscription mapping owner differs")
    for symbol, book in exchange.order_books.items():
        if type(book) is not engine.NativeBook or book.owner is not exchange or book.symbol != symbol:
            raise ValueError("transaction exact typed book owner differs")
        for name in ("bids", "asks", "book_log2", "history", "buy_transactions", "sell_transactions"):
            if type(getattr(book, name)) is not list or getattr(book, name):
                raise ValueError("transaction book must have empty original list aliases")
        if type(book.quotes_seen) is not set or book.quotes_seen or book.last_trade is not None:
            raise ValueError("transaction book initial business state differs")
    return True
