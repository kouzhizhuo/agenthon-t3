#!/usr/bin/env python3
"""Run deploy-bound native or canonical output; no per-episode source audit."""
import time

ENTRY_STARTED = time.perf_counter()

import argparse
import json
import os
from pathlib import Path
import resource
import sys

HERE = Path(__file__).resolve().parent
RUNTIME = Path(os.environ.get("T3_TRANSACTION_RUNTIME", str(HERE.parent / "lean_production_native_projection_v1/runtime"))).resolve()
CANDIDATE = Path(os.environ.get("T3_TRANSACTION_CANDIDATE", str(HERE))).resolve()
sys.path.insert(0, str(CANDIDATE))
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()

from abides_core import abides
from abides_core.kernel import Kernel
from abides_fork.config import build_config, ScenarioLatencyModel
from abides_fork.simulate import reset_abides_counters
from abides_fork.trace import extract_trace
from contracts import sha256, validate_scenario, validate_frames
import observer
from transaction_installation import enabled

ARMS = ("original_canonical", "actual_native")
_probes = []


def reset_probes():
    _probes.clear()


def episode_probes():
    return list(_probes)


def simulate(config_path, out_path, arm="actual_native", started=None):
    if arm not in ARMS:
        raise ValueError("unknown scheduler arm: " + str(arm))
    t0 = time.perf_counter() if started is None else started
    scenario = json.loads(Path(config_path).read_text())
    validate_scenario(scenario)
    if "proof_authentication" in sys.modules or "host_proof" in sys.modules:
        raise ValueError("production process entered external research proof")
    original_kernel, original_latency = abides.Kernel, ScenarioLatencyModel.get_latency
    summary_writer = Kernel.write_summary_log
    try:
        reset_abides_counters()
        # Canonical arms suppress this same non-contract diagnostic IO after
        # authentication. A declined whole original episode retains its writer.
        try:
            with enabled(scenario, arm) as installed:
                observer.begin_episode(scenario, authenticated=installed["observer_authenticated"])
                config = build_config(scenario)
                if installed["installed_engine"] == "canonical":
                    Kernel.write_summary_log = lambda self: None
                end_state = abides.run(config)
                message_extractor = installed["extractor"]
        finally:
            Kernel.write_summary_log = summary_writer
        if abides.Kernel is not original_kernel or ScenarioLatencyModel.get_latency is not original_latency:
            raise ValueError("scheduler installation bindings were not restored")
        kernel = end_state["agents"][0].kernel
        if not all(agent.kernel is kernel for agent in end_state["agents"]):
            raise ValueError("agent kernel aliases differ")
        receipt = None
        if installed["native_active"]:
            from transaction_loader import load_transaction, native_receipt
            engine = load_transaction()
            if not isinstance(kernel, engine.CanonicalKernel) or type(kernel._msg_ledger) is not engine.ColumnLedger:
                raise ValueError("actual native scheduler/ledger was not installed")
            receipt = native_receipt()
            if receipt["native_load_count"] != 1:
                raise ValueError("native scheduler loaded more than once")
        elif installed["installed_engine"] == "canonical":
            import importlib
            engine = importlib.import_module("original_canonical_engine")
            if not isinstance(kernel, engine.CanonicalKernel) or type(kernel._msg_ledger) is not engine.ColumnLedger:
                raise ValueError("selected Python scheduler/ledger was not installed")
            if (arm == "original_canonical" and "native_canonical_transaction" in sys.modules) or "transaction_owner_probe" in sys.modules:
                raise ValueError("Python arm loaded a native scheduler/probe")
        else:
            if type(kernel) is not Kernel or type(kernel._msg_ledger) is not list or observer.STATE is not None:
                raise ValueError("whole original fallback kernel/ledger/observer differs")
        if "transaction_owner_probe" in sys.modules:
            raise ValueError("production entry loaded the control-only owner probe")
        if "proof_authentication" in sys.modules or "host_proof" in sys.modules:
            raise ValueError("production episode entered external research proof")
        trace = extract_trace(end_state)
        messages = message_extractor(end_state)
        validate_frames(trace, messages)
    finally:
        Kernel.write_summary_log = summary_writer
        observer.finish_episode()
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    trace.to_parquet(out, compression="snappy", index=False)
    messages.to_parquet(out.parent / "message_trace.parquet", compression="snappy", index=False)
    trace_digest = sha256(out)
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    wall = time.perf_counter() - t0
    events = {"scenario_id": str(scenario["scenario_id"]), "seed": int(scenario["seed"]),
              "n_events": len(trace), "wall_clock_sec": wall, "events_per_sec": len(trace) / wall,
              "trace_sha256": trace_digest,
              "peak_memory_bytes": int(rss) if sys.platform == "darwin" else int(rss) * 1024,
              "gpu_seconds": 0.0}
    (out.parent / "events.json").write_text(json.dumps(events, indent=2) + "\n")
    _probes.append({"scheduler_arm": arm, "native_active": installed["native_active"],
                   "fallback_used": installed["fallback_before_configuration"], "json_domain_admitted": installed["json_domain_admitted"],
                   "complete_trace_rows": len(trace), "message_rows": len(messages),
                   "native_receipt": receipt, "installation_restored": True,
                   "control_probe_loaded": False,
                   "deployment_authority": installed["deployment_authority"],
                   "per_episode_source_hashes": installed["per_episode_source_hashes"],
                   "per_episode_original_source_compilations": installed["per_episode_original_source_compilations"],
                   "installed_engine": installed["installed_engine"],
                   "observer_authenticated": installed["observer_authenticated"],
                   "runtime_native_compilation": False,
                   "per_episode_native_hash_audit": False, "rankable": False})
    return events


def simulate_batch(batch_dir, out_dir, arm="actual_native", started=None):
    t0 = time.perf_counter() if started is None else started
    paths = sorted(p for p in Path(batch_dir).glob("*.json") if not p.name.startswith("._"))
    if not paths:
        raise ValueError("batch-dir contains no scenario JSON files")
    per_scenario = []
    for path in paths:
        events = simulate(path, Path(out_dir) / path.stem / "trace.parquet", arm)
        per_scenario.append({"sub": path.stem, "n_events": events["n_events"],
                             "scenario_id": events["scenario_id"], "seed": events["seed"]})
    wall = time.perf_counter() - t0
    total = sum(row["n_events"] for row in per_scenario)
    result = {"n_scenarios": len(per_scenario), "total_events": total,
              "wall_clock_sec": wall, "events_per_sec": total / wall, "per_scenario": per_scenario}
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    (Path(out_dir) / "batch_events.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="verb", required=True)
    single = sub.add_parser("simulate")
    single.add_argument("--config", required=True)
    single.add_argument("--out", required=True)
    batch = sub.add_parser("simulate-batch")
    batch.add_argument("--batch-dir", required=True)
    batch.add_argument("--out-dir", required=True)
    for command in (single, batch):
        command.add_argument("--arm", choices=ARMS, default="actual_native")
    args = parser.parse_args()
    result = (simulate(args.config, args.out, args.arm, ENTRY_STARTED) if args.verb == "simulate"
              else simulate_batch(args.batch_dir, args.out_dir, args.arm, ENTRY_STARTED))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
