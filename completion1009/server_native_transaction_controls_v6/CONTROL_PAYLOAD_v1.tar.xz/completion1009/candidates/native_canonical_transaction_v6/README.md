This fresh source candidate closes the four declared strategies into the same continuous extension as the native transaction scheduler, book and price level. It preserves every original raw Agent as the sole mutable business owner. Constructors, orders/messages, holdings/history, NumPy RandomState/oracle, scalar numeric expressions, private log/observer paths and output contract remain original. No shadow agent, per-event synchronization or production proof counters are added.

The 35 new cdef functions derive from the current frozen runtime's exact Agent/TradingAgent/ScheduledAgent bodies and four `act` bodies. Parent wake/receive and declared submission, cancellation, notification, query and send/wakeup helper calls become same-extension calls. Original logger aliases and every body statement stay in order. The metadata default for cancellation remains the authenticated original default dictionary object. The scheduler selects exact class ownership; configuration identifiers and known parameter values do not choose the algorithm. Unadmitted generic scheduler fixtures still use their original callbacks, while production preinitialize admission restricts the actual raw topology to the original exchange and four strategy classes.

NativeBook, NativeLevel, FlatHeap, ColumnLedger and CanonicalKernel retain the V2 normalized AST exactly. All V2 scheduler methods retain their AST except the two exact four-owner wake/receive dispatch sites. Original sends enter the complete CanonicalScheduler latency, raw stable tuple heap and causal nine-list ledger path. Matching notifications enter the same scheduler through the existing NativeBook and exchange return leg.

The source-only author reader compares 32 generated original function bodies, 73 pyx/pxd declarations, unchanged V2 classes and scheduler helpers, all 30 frozen parent source bytes and the 64 runtime pins. Those checks do not establish a successful Cython build or actual runtime behavior. The separate private control probe adds direct strategy entries and verifies original raw Agent/scheduler ownership plus original cancellation default aliases. Production does not load that probe.

All earlier 41 scheduler boundaries, 33 variants/99 arms, 22 guard subchecks, five integration children, 28 transaction cases and eight V4 external-authority/admission children remain required. A new runner prepares 141 strategy cases: 104 normal wake/act/spread/notification boundaries, 29 exact error/warning/partial-state cases and eight actual scheduler wake→spread→act→book→report roundtrips, with and without protocol enforcement. It invokes the real cdef methods or production scheduler against the real compiled deployment and compares original state, RNG, UID, queue, ledger, clocks, observer records and warnings. The source-preparation process never runs those controls.

Source authority remains external to production. A actual pinned Linux build/deploy must produce fresh build/ELF receipts and execute `host_proof --mode create`; a host/controller must bind the actual image/source/ELF/authority and execute fresh `--mode verify` before and after all controls. New build/deployment/proof/authority schemas identify V4. The immutable runtime authentication oracle remains the same exact source token audit; production has no per-episode source hashing or compilation.

Full markets, exact CLI single/batch/daemon entry, both complete Parquets, full official Tier A/B gates, event counts and committed repeated host timing must pass before composition, promotion or submission. A separate Linux V4 wrapper and independent canonical-semantic review are still required. Unsupported-JSON child controls only prove preconfiguration original bindings/extractor/inactive observer, rather than a complete fallback market. No build, fixture, market, server, network, upload or official submission has occurred during this preparation.

The strategy change is a first phase toward a native authoritative state, dynamic message arena, stable original tuple calendar, append-only trace/ledger columns and narrowed NumPy RNG/oracle bridges. Those phases are documented in `research/continuous_native_boundary_review_v1/CONTINUOUS_STRATEGY_V4_AND_NATIVE_STATE_PATH_v1.md`. This source does not predict 230000 EPS or first place; organizer host measurement and full gates determine competitiveness.


V4 preserves frozen V3 and its independent blocked review. The sole V3 blocker
was a normal first-hours fixture delivered at120 with market open100, so the
original correctly rejected scheduling in the past. V4 delivers that first
notification at50 with open100/close1000 and uses the same kernel clock as the
method argument in both arms. All other normal clocks remain120; the separate
past-wakeup exception control remains unchanged. Production Cython core and
private strategy probe are byte-identical to V3. New deployment/proof/authority
identity schemas bind the fresh V4 receipt; no actual controls were run here.
Historical SOURCE_CHECKS_v3*.json are preserved parent evidence, not V4 PASS.


V5 is additive to frozen V4. The actual V2 build, deployment, external proof
and41scheduler controls completed;28transaction controls then failed in the
source-only state oracle before returning its first case, because original
ExchangeAgent.data_subscriptions is defaultdict(list). V5 records an exact
defaultdict type/factory token and every insertion-ordered item with the same
shared alias memo; a repeated or cyclic map keeps the original ref token.
The factory is never invoked. Exact builtins.list and None are supported;
unknown factories are refused explicitly. Production Cython/core/strategy
probe and all141strategy control inputs remain byte-identical to V4. Fresh
V5 build/deployment/proof/authority identities bind this fresh source receipt.
Historical V3/V4 checks/derivations are retained as parent evidence, not V5 PASS.
No fixture, participant or scientific module is executed in this preparation.


V6 repairs the confirmed reachable strategy oracle domain. It preserves the
original raw Agent and production core bytes, uses one finite graph/memo across
all snapshot roots and full roundtrip exchange/book state, and records exact
original defaultdict factories and item order. Shared raw Order/Message/list,
NumPy ndarray/RandomState and deque identities are visible as ref tokens; the
memo retains original objects to prevent temporary-ID reuse. Unknown factories
are refused without invoking them. Kernel/book owner cycles are omitted only
with existing actual private alias controls; scalar outcome/type checks and all
141control inputs remain unchanged. Seven transaction dictionary oracle and
eight strategy graph self-controls execute only in future actual Linux controls.
Historical V3/V4/V5 checks are parent evidence only. No runtime or build occurs
in source preparation. Official gates permit internal representations and do
not require this research fullgraph; actual CLI validation remains mandatory.
