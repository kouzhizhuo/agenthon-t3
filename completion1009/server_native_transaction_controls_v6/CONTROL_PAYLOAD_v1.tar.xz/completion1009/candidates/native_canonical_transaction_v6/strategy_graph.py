"""Finite control graph for reachable raw strategy values; never production."""
from collections import defaultdict, deque
from datetime import datetime, timedelta


def graph(value, np, memo=None):
    memo = {} if memo is None else memo
    if value is None or type(value) in (str, int, bool):
        return [type(value).__name__, value]
    if type(value) is float:
        return ["float", value.hex()]
    if type(value) is bytes:
        return ["bytes", value.hex()]
    from abides_markets.orders import Side
    if type(value) is Side:
        return ["Side", value.value]
    if isinstance(value, np.generic):
        return [type(value).__name__, graph(value.item(), np, memo)]
    if type(value) is datetime:
        return ["datetime", value.isoformat()]
    if type(value) is timedelta:
        return ["timedelta", value.days, value.seconds, value.microseconds]
    if id(value) in memo:
        return ["ref", memo[id(value)][0]]
    serial = len(memo)
    # Keep the original object alive: temporary attribute dicts/array.tolist()
    # must not have their IDs reused and falsely appear as shared raw aliases.
    memo[id(value)] = (serial, value)
    if isinstance(value, np.random.RandomState):
        return ["RandomState", serial, graph(value.get_state(), np, memo)]
    if isinstance(value, np.ndarray):
        return ["ndarray", serial, str(value.dtype), list(value.shape),
                graph(value.tolist(), np, memo) if value.dtype.hasobject else value.tobytes().hex()]
    if type(value) in (list, tuple, deque):
        return [type(value).__name__, serial, [graph(child, np, memo) for child in value]]
    if type(value) is defaultdict:
        factory = value.default_factory
        if factory is not None and factory is not list:
            raise TypeError("unsupported strategy graph defaultdict factory")
        token = ["NoneType", None] if factory is None else ["binding", "builtins", "list"]
        return ["defaultdict", serial, token,
                [[graph(key, np, memo), graph(child, np, memo)] for key, child in value.items()]]
    if type(value) is dict:
        return ["dict", serial, [[graph(key, np, memo), graph(child, np, memo)] for key, child in value.items()]]
    if type(value) in (set, frozenset):
        # Reachable oracle/order-book sets contain scalar/tuple price values.
        # Foreign mutable set members are refused instead of losing aliases.
        for child in value:
            if type(child) not in (str, int, bool, float, tuple):
                raise TypeError("unsupported strategy graph set member")
        return [type(value).__name__, serial, sorted([graph(child, np, memo) for child in value], key=repr)]
    if hasattr(value, "__dict__"):
        name = type(value).__name__
        module = type(value).__module__
        if name in ("NativeBook", "OrderBook"):
            module, name = "transaction_mapping", "OrderBook"
        if name in ("NativeLevel", "PriceLevel"):
            module, name = "transaction_mapping", "PriceLevel"
        attrs = [[key, graph(child, np, memo)] for key, child in vars(value).items()
                 if key != "kernel" and not (name == "OrderBook" and key == "owner")]
        return [module, name, serial, attrs]
    raise TypeError("unsupported reachable strategy graph value: " + type(value).__name__)
