"""Future data-oracle controls; source preparation never executes this."""
from collections import defaultdict


def run_all(freeze):
    records = []
    empty = defaultdict(list)
    assert freeze(empty) == ["defaultdict", ["binding", "builtins", "list"], []]
    records.append({"case": "empty_list_factory", "passed": True})
    before = list(empty.items())
    freeze(empty)
    assert list(empty.items()) == before and empty.default_factory is list
    records.append({"case": "factory_not_invoked_no_missing_key_insertion", "passed": True})
    values = defaultdict(list, [("z", [3]), ("a", [1])])
    encoded = freeze(values)
    assert [row[0] for row in encoded[2]] == [["str", "z"], ["str", "a"]]
    records.append({"case": "insertion_order_retained", "passed": True})
    shared = []
    values = defaultdict(list, [("left", shared), ("right", shared)])
    encoded = freeze([values, shared])
    first = encoded[1][0][2][0][1]
    alias = encoded[1][0][2][1][1]
    assert first == ["list", []] and alias == encoded[1][1] == ["ref", 2]
    records.append({"case": "shared_value_and_outer_alias_retained", "passed": True})
    cycle = defaultdict(list)
    cycle["self"] = cycle
    assert freeze(cycle) == ["defaultdict", ["binding", "builtins", "list"], [[["str", "self"], ["ref", 0]]]]
    records.append({"case": "recursive_mapping_alias_retained", "passed": True})
    assert freeze(defaultdict(None, {"a": []}))[1] == ["NoneType", None]
    records.append({"case": "None_factory_distinct_from_list", "passed": True})
    calls = []
    def unknown():
        calls.append(True)
        return []
    try:
        freeze(defaultdict(unknown))
    except AssertionError as error:
        assert str(error) == "unsupported fixture defaultdict factory"
    else:
        raise AssertionError("unknown factory accepted")
    assert calls == []
    records.append({"case": "unknown_factory_refused_without_call", "passed": True})
    return {"schema": "t3-native-transaction-v5-defaultdict-oracle-controls-v1", "all_passed": True,
        "cases": records, "factory_never_called": True, "complete_factory_and_shared_alias_graph_checked": True,
        "production_hot_counters": False, "rankable": False}
