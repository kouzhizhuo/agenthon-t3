"""Fixture-only actual entry: three fresh serial children, no markets/timing."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path("/opt/lightweight-canonical-fixtures-v4-1")
CANDIDATE = ROOT / "completion1009/candidates/lightweight_canonical_buffers_v4"
BASELINE = ROOT / "completion1009/candidates/lean_production_native_projection_v1/runtime"


def main():
    if sys.argv[1:] != ["controls"]:
        raise ValueError("fixture-only controls command required")
    if json.loads(Path("/input/command.json").read_text()) != {"command": "lightweight-canonical-fixture3-parquet9-no-market-v4-1"}:
        raise ValueError("fixed fixture control input required")
    output = Path("/output/fixtures")
    if output.exists():
        raise ValueError("fresh fixture directory required")
    output.mkdir()
    receipts = {}
    for arm, runtime in (("baseline", BASELINE), ("new", CANDIDATE / "runtime"), ("cold-new", CANDIDATE / "runtime")):
        with (output / (arm + ".log")).open("xb") as log:
            process = subprocess.run([sys.executable, "-B", str(ROOT / "control/combined_child.py"),
                "--runtime", str(runtime), "--worker", str(CANDIDATE / "controls/output_fixture_worker_v1.py"),
                "--arm", arm, "--out-dir", str(output / arm)], stdout=log, stderr=subprocess.STDOUT, timeout=180)
        if process.returncode:
            raise RuntimeError("actual combined fixture child failed: " + arm)
        receipts[arm] = json.loads((output / arm / "DOMAIN_RECEIPT_v1.json").read_text())
    if receipts["baseline"]["public_time_results"] != receipts["new"]["public_time_results"]:
        raise AssertionError("actual original/new public time return/throw controls differ")
    if receipts["baseline"]["general_original_output_results"] != receipts["new"]["general_original_output_results"]:
        raise AssertionError("actual original/new general output fallback controls differ")
    for arm in ("new", "cold-new"):
        if receipts[arm]["actual_config"] != receipts["baseline"]["actual_config"]:
            raise AssertionError("actual config type/agent/time differs")
        for name in ("trace.parquet", "message_trace.parquet", "trace_sort_ties.parquet", "trace_sort_ties.json"):
            if (output / arm / name).read_bytes() != (output / "baseline" / name).read_bytes():
                raise AssertionError("actual full Parquet bytes differ")
        fixture = receipts[arm]["candidate_writer_fixture"]
        baseline_fixture = receipts["baseline"]["candidate_writer_fixture"]
        if fixture["production_write_api_files"] != baseline_fixture["production_write_api_files"]:
            raise AssertionError("actual production write_outputs API bytes/hash differ")
        if fixture["production_write_api_readbacks"] != baseline_fixture["production_write_api_readbacks"]:
            raise AssertionError("actual production write_outputs API rows/schema/nulls differ")
        if fixture["full_serializer_groups"] != baseline_fixture["full_serializer_groups"]:
            raise AssertionError("actual rowgroup schema/null/empty/lifetime fixture differs")
        if fixture["trace_sort_tie_cases"] != baseline_fixture["trace_sort_tie_cases"]:
            raise AssertionError("actual cross-agent/time/order/quote ties differ")
    import pandas as pd
    import pyarrow.parquet as pq
    readbacks = {}
    for name in ("trace.parquet", "message_trace.parquet", "trace_sort_ties.parquet"):
        baseline = pd.read_parquet(output / "baseline" / name)
        schema = pq.read_schema(output / "baseline" / name)
        for arm in ("new", "cold-new"):
            actual = pd.read_parquet(output / arm / name)
            pd.testing.assert_frame_equal(baseline, actual, check_dtype=True, check_exact=True)
            if not schema.equals(pq.read_schema(output / arm / name), check_metadata=True):
                raise AssertionError("actual schema metadata differs")
        readbacks[name] = {"rows": len(baseline), "dtypes": {field: str(baseline[field].dtype) for field in baseline.columns}}
    cold = receipts["cold-new"]
    if (cold["candidate_writer_fixture"]["pandas_loaded"] or cold["pandas_loaded_after_domains"]
            or cold["scipy_loaded_after_domains"]
            or cold["candidate_writer_fixture"]["pandas_import_attempts"]
            or cold["pandas_import_attempts_through_domains"]
            or cold["full_entry_config_import_witness"]["unused_stock_modules_loaded"]
            or cold["full_entry_config_import_witness"]["stock_cli_loaded"]):
        raise AssertionError("cold normal import/writer/config witness differs")
    result = {"schema": "t3-lightweight-canonical-fixture-only-container-result-v4-1", "all_passed": True,
              "children": receipts, "retained_parquets": 9, "actual_parquet_bytes_equal": True,
              "actual_readbacks": readbacks, "actual_schema_metadata_equal": True,
              "public_time_return_throw_equal": True, "normal_config_constructed": True,
              "general_original_outputs_equal": True,
              "cold_pandas_attempts_zero": True, "kernel_or_market_run": False,
              "cold_scipy_attempts_zero": True, "full_entry_imported_cold": True,
              "actual_trace_sort_ties_equal": True,
              "timing_result": False, "rankable": False}
    (output / "RESULT_v1.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("T3_LIGHTWEIGHT_CANONICAL_FIXTURES_V4=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
