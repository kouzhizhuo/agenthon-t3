"""Bounded actual build + one fixture container; no market/evaluator/publish."""
import argparse
import ast
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time
import uuid
from common import BASE, CANDIDATE, BASELINE, GENERATOR, ENTRYPOINT, sha, inventory, verify_payload, write

PAYLOAD = Path(__file__).resolve().parents[1]


def call(args, command, label, seconds=60, allow_failure=False):
    path = args.evidence / (label + ".log")
    started = time.monotonic()
    result = None
    failure = None
    timed_out = False
    with path.open("xb") as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=seconds)
        except subprocess.TimeoutExpired as error:
            timed_out = True
            failure = {"type": type(error).__name__, "message": str(error)}
        except OSError as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    record = {"command": command, "returncode": None if result is None else result.returncode,
              "timed_out": timed_out, "failure": failure, "host_elapsed_sec": time.monotonic() - started,
              "log": {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}}
    write(args.evidence / (label + ".json"), record)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual bounded command failed: " + label)
    return record


def inspect(args, name, label):
    call(args, [args.docker, "inspect", name], label)
    value = json.loads((args.evidence / (label + ".log")).read_text())
    if type(value) is not list or len(value) != 1:
        raise ValueError("one actual inspected object required")
    return value[0]


def run(args):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("actual Linux amd64 host required")
    verify_payload(PAYLOAD)
    plan = json.loads((PAYLOAD / "FIXTURE_PLAN.json").read_text())
    if (plan.get("schema") != "t3-lightweight-canonical-fixture-only-source-plan-v4-1"
            or plan.get("prototype_only") is not False
            or plan.get("candidate_source_receipt_sha256") != "5a7efb13de2aa4dd888480d235250e5f2b894a60a16900b29724ec8e3553fbf0"
            or sha(PAYLOAD / "control/INDEPENDENT_CANDIDATE_SOURCE_REVIEW.json") != plan.get("independent_review_sha256")
            or sha(PAYLOAD / "control/INDEPENDENT_WRAPPER_SOURCE_REVIEW.json") != plan.get("independent_wrapper_review_sha256")
            or sha(PAYLOAD / "control/WRAPPER_SOURCE_PREPARATION_RECEIPT_v4_1.json") != plan.get("wrapper_source_receipt_sha256")):
        raise ValueError("reviewed final exact fixture payload required")
    args.evidence.mkdir(parents=True, exist_ok=True)
    anonymous = args.evidence / "anonymous-docker-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        call(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    base = inspect(args, BASE, "base-inspect")
    if "sha256:5a190afe0bdfe7685e64cbf1aec30d39885199c85f688a971b8d4a0ab8d217eb" not in " ".join(base.get("RepoDigests", [])):
        raise ValueError("actual base digest differs")
    tag = "t3-lightweight-canonical-fixtures-v4-1:" + uuid.uuid4().hex
    call(args, [args.docker, "build", "--platform", "linux/amd64", "--pull=false", "-t", tag,
                "-f", str(PAYLOAD / "control/Dockerfile"), str(PAYLOAD)], "image-build", 600)
    image = inspect(args, tag, "image-inspect")
    if image["Config"]["Entrypoint"] != ENTRYPOINT or image["Config"]["User"] != "65534:65534":
        raise ValueError("actual fixture image entry/user differs")
    evidence_name = "t3-fixture-evidence-" + uuid.uuid4().hex
    try:
        call(args, [args.docker, "create", "--name", evidence_name, tag], "evidence-create")
        copied = args.evidence / "installed"
        call(args, [args.docker, "cp", evidence_name + ":/opt/lightweight-canonical-fixtures-v4-1", str(copied)], "installed-copy")
    finally:
        call(args, [args.docker, "rm", "-f", evidence_name], "evidence-remove", allow_failure=True)
    # Frozen sources, generated metadata and pin are inspected after the actual
    # build rather than accepted from Dockerfile text or claimed receipt flags.
    for row in plan["candidate_sources"]:
        actual = copied / CANDIDATE / row["path"]
        if actual.stat().st_size != row["bytes"] or sha(actual) != row["sha256"]:
            raise ValueError("installed candidate source differs")
    if inventory(copied / BASELINE) != plan["baseline_sources"]:
        raise ValueError("installed baseline source differs")
    if sha(copied / GENERATOR) != plan["generator_sha256"]:
        raise ValueError("installed exact schema generator differs")
    metadata = copied / CANDIDATE / "runtime/schema_metadata_v1.json"
    pin = copied / CANDIDATE / "runtime/schema_metadata_pin_v1.py"
    deployed = json.loads((copied / "schema-build/DEPLOYED_SCHEMA_PIN_RECEIPT_v1.json").read_text())
    if (deployed["metadata"]["sha256"] != sha(metadata) or deployed["metadata"]["bytes"] != metadata.stat().st_size
            or deployed["source_pin"]["sha256"] != sha(pin) or deployed["source_pin"]["bytes"] != pin.stat().st_size):
        raise ValueError("actual generated metadata/pin binding differs")
    pin_tree = ast.parse(pin.read_bytes())
    pin_value = ast.literal_eval(next(node.value for node in pin_tree.body if isinstance(node, ast.Assign)
        and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "SCHEMA_METADATA_SHA256"))
    baseline_schema = json.loads((copied / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json").read_text())
    if (pin_value != sha(metadata) or baseline_schema.get("versions") != {"numpy": "1.26.4", "pandas": "1.5.3", "pyarrow": "15.0.2"}
            or baseline_schema.get("metadata", {}).get("sha256") != sha(metadata)
            or baseline_schema.get("generator", {}).get("sha256") != plan["generator_sha256"]
            or deployed.get("baseline_receipt_sha256") != sha(copied / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json")):
        raise ValueError("actual pinned schema generator/receipt/source constant differs")
    expected_runtime = {row["path"][len("runtime/"):]: {"bytes": row["bytes"], "sha256": row["sha256"]}
        for row in plan["candidate_sources"] if row["path"].startswith("runtime/")}
    actual_runtime = inventory(copied / CANDIDATE / "runtime")
    for name in ("schema_metadata_v1.json", "schema_metadata_pin_v1.py"):
        if name not in actual_runtime:
            raise ValueError("actual generated schema runtime file absent")
        actual_runtime.pop(name)
    if actual_runtime != expected_runtime:
        raise ValueError("actual runtime contains changed or extra ordinary sources")
    for name, expected in plan["control_sources"].items():
        actual = copied / "control" / name
        if actual.stat().st_size != expected["bytes"] or sha(actual) != expected["sha256"]:
            raise ValueError("actual installed fixture control source differs")
    for name, key in (("INDEPENDENT_CANDIDATE_SOURCE_REVIEW.json", "independent_review_sha256"),
                      ("INDEPENDENT_WRAPPER_SOURCE_REVIEW.json", "independent_wrapper_review_sha256"),
                      ("WRAPPER_SOURCE_PREPARATION_RECEIPT_v4_1.json", "wrapper_source_receipt_sha256")):
        if sha(copied / "control" / name) != plan[key]:
            raise ValueError("actual installed independent review/source receipt differs")
    write(args.evidence / "ACTUAL_BUILD_INVENTORY_v1.json", {"schema": "t3-lightweight-canonical-fixture-build-inventory-v4-1",
        "base_image": base["Id"], "fixture_image": image["Id"], "installed_files": inventory(copied),
        "generated_metadata_sha256": sha(metadata), "generated_pin_sha256": sha(pin),
        "candidate_source_receipt_sha256": plan["candidate_source_receipt_sha256"],
        "candidate_executed_during_build": False, "kernel_or_market_run": False, "rankable": False})
    inputs, outputs = args.evidence / "input", args.evidence / "output"
    inputs.mkdir(); outputs.mkdir(); outputs.chmod(0o777)
    write(inputs / "command.json", {"command": "lightweight-canonical-fixture3-parquet9-no-market-v4-1"})
    name = "t3-lightweight-canonical-fixture-" + uuid.uuid4().hex
    try:
        call(args, [args.docker, "create", "--name", name, "--cpus", "4", "--memory", "16g", "--memory-swap", "16g",
            "--network", "none", "--read-only", "--user", "65534:65534", "--pids-limit", "256",
            "--ulimit", "nofile=1024:1024", "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456",
            "--security-opt", "no-new-privileges", "--cap-drop", "ALL", "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m",
            "--mount", "type=bind,src=" + str(inputs.resolve()) + ",dst=/input,readonly",
            "--mount", "type=bind,src=" + str(outputs.resolve()) + ",dst=/output", tag, "controls"], "fixture-create")
        before = inspect(args, name, "fixture-inspect-before")
        host = before["HostConfig"]
        if (before["Config"]["Entrypoint"] != ENTRYPOINT or before["Config"]["Cmd"] != ["controls"]
                or before["Config"]["User"] != "65534:65534" or host["NetworkMode"] != "none"
                or host["ReadonlyRootfs"] is not True or host["NanoCpus"] != 4000000000
                or host["Memory"] != 16 * 1024 ** 3 or host["MemorySwap"] != 16 * 1024 ** 3):
            raise ValueError("actual one-container resources/entry differ")
        limits = {item["Name"]: (item["Soft"], item["Hard"]) for item in host.get("Ulimits", [])}
        if (limits != {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
                or host.get("PidsLimit") != 256 or host.get("CapDrop") != ["ALL"]
                or not any(value in ("no-new-privileges", "no-new-privileges:true") for value in host.get("SecurityOpt", []))
                or host.get("Tmpfs", {}).get("/tmp") != "rw,noexec,nosuid,nodev,size=64m"):
            raise ValueError("actual fixture ulimits/capabilities/tmpfs differ")
        binds = [m for m in before["Mounts"] if m.get("Type") == "bind"]
        if (len(binds) != 2 or {m["Destination"]: (m["RW"], m["Source"]) for m in binds}
                != {"/input": (False, str(inputs.resolve())), "/output": (True, str(outputs.resolve()))}):
            raise ValueError("actual fixture mounts differ")
        call(args, [args.docker, "start", "-a", name], "fixture-run", 600)
        after = inspect(args, name, "fixture-inspect-after")
        if after["State"]["ExitCode"] != 0 or after["State"].get("OOMKilled") is not False:
            raise ValueError("actual fixture process failed or OOM")
    finally:
        call(args, [args.docker, "rm", "-f", name], "fixture-remove", allow_failure=True)
    result = json.loads((outputs / "fixtures/RESULT_v1.json").read_text())
    if (result.get("schema") != "t3-lightweight-canonical-fixture-only-container-result-v4-1" or result.get("all_passed") is not True
            or result.get("retained_parquets") != 9 or result.get("kernel_or_market_run") is not False
            or result.get("timing_result") is not False or result.get("rankable") is not False
            or set(result.get("children", {})) != {"baseline", "new", "cold-new"}
            or result.get("cold_pandas_attempts_zero") is not True
            or result.get("cold_scipy_attempts_zero") is not True
            or result.get("full_entry_imported_cold") is not True
            or result.get("actual_trace_sort_ties_equal") is not True):
        raise ValueError("complete actual fixture-only result required")
    for key in ("actual_parquet_bytes_equal", "actual_schema_metadata_equal", "public_time_return_throw_equal",
                "normal_config_constructed", "general_original_outputs_equal"):
        if result.get(key) is not True:
            raise ValueError("complete actual domain/byte/schema checks absent")
    for arm, child in result["children"].items():
        fixture = child["candidate_writer_fixture"]
        if (child.get("arm") != arm or child.get("kernel_or_market_run") is not False
                or child.get("actual_config_constructed") is not True
                or fixture.get("expected_values_equal") is not True or fixture.get("raw_state_unchanged") is not True
                or fixture.get("market_executed") is not False or fixture.get("timing_result") is not False):
            raise ValueError("actual three-child domain/fixture flags differ")
        if arm == "cold-new" and (fixture["pandas_import_attempts"] != [] or fixture["pandas_loaded"] is not False
                or child["pandas_loaded_after_domains"] is not False or child["scipy_loaded_after_domains"] is not False
                or child["pandas_import_attempts_through_domains"] != []
                or child["full_entry_config_import_witness"]["unused_stock_modules_loaded"] != []
                or child["full_entry_config_import_witness"]["stock_cli_loaded"] is not False):
            raise ValueError("actual cold child pandas import witness differs")
    files = sorted((outputs / "fixtures").glob("*/*.parquet"))
    if len(files) != 9:
        raise ValueError("exact9 actual retained Parquet files required")
    for filename in ("trace.parquet", "message_trace.parquet", "trace_sort_ties.parquet", "trace_sort_ties.json"):
        blobs = [(outputs / "fixtures" / arm / filename).read_bytes() for arm in ("baseline", "new", "cold-new")]
        if blobs[0] != blobs[1] or blobs[0] != blobs[2]:
            raise ValueError("host actual retained Parquet bytes differ")
    write(args.evidence / "SCREEN_RESULT_v1.json", {"schema": "t3-lightweight-canonical-fixture-only-host-v4-1", "all_passed": True,
        "result": result, "actual_container": after, "retained_parquets": [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p)} for p in files],
        "kernel_or_market_run": False, "timing_result": False, "official_gate": False, "rankable": False})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("run", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--artifact", type=Path)
    parser.add_argument("--docker", default="docker")
    args = parser.parse_args()
    if args.verb == "artifact":
        if args.artifact is None or args.artifact.exists():
            raise ValueError("fresh artifact directory required")
        args.artifact.mkdir(parents=True)
        if args.evidence.exists():
            shutil.copytree(args.evidence, args.artifact / "evidence", ignore=shutil.ignore_patterns("anonymous-docker-config"))
        shutil.copytree(PAYLOAD, args.artifact / "payload")
        return
    try:
        run(args)
    except BaseException as error:
        write(args.evidence / "FAILURE_v1.json", {"type": type(error).__name__, "message": str(error),
              "kernel_or_market_run": False, "rankable": False})
        raise


if __name__ == "__main__":
    main()
