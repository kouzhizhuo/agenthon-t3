"""One actual fixture child followed by normal/public time-domain controls."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--worker", type=Path, required=True)
    parser.add_argument("--arm", choices=("baseline", "new", "cold-new"), required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("actual_fixture_worker", args.worker)
    worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(worker)
    live_pandas_attempts = None
    if args.arm == "cold-new":
        original_install_oracle = worker.install_import_oracle
        def capture_control_oracle():
            nonlocal live_pandas_attempts
            live_pandas_attempts = original_install_oracle()
            return live_pandas_attempts
        # External control module only: production candidate sources are frozen
        # and untouched. Retain the same live list held by the actual audit hook.
        worker.install_import_oracle = capture_control_oracle
    sys.argv = [str(args.worker), "--runtime", str(args.runtime), "--arm", args.arm, "--out-dir", str(args.out_dir)]
    worker.main()
    # The cold child's import audit oracle remains installed through these real
    # imports and config construction. No abides.run/Kernel.run is invoked.
    import numpy as np
    from abides_core import utils
    from abides_fork.config import build_config
    if args.arm == "baseline":
        from abides_fork.simulate import reset_abides_counters
    else:
        from counters import reset_abides_counters
    normal = []
    for value, expected in (("09:30:00", 34200000000000), ("16:00:00", 57600000000000),
                            ("1s", 1000000000), ("60s", 60000000000), ("1min", 60000000000),
                            (np.int64(12), 12), (-(1 << 63) + 1, -(1 << 63) + 1), ((1 << 63) - 1, (1 << 63) - 1)):
        result = utils.str_to_ns(value)
        if type(result) is not np.int64 or int(result) != expected:
            raise AssertionError("actual normal duration/numeric return differs")
        normal.append({"value": str(value), "type": type(result).__module__ + "." + type(result).__name__, "result": int(result)})
    scenario = {"scenario_id": "cold-config-fixture", "seed": 91009, "horizon_ns": 1000000000,
                "agent_configs": [{"agent_type": name, "count": 1, "params": {}} for name in ("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader")],
                "exchange_config": {"symbol": "ABM"}, "oracle_config": {"params": {"initial_price": 100000}},
                "latency_config": {"model": "deterministic", "params": {"mean_ns": 50, "min_ns": 0, "max_ns": 100}}}
    reset_abides_counters()
    config = build_config(scenario)
    if len(config["agents"]) != 5 or type(config["start_time"]) is not int or type(config["stop_time"]) is not np.int64:
        raise AssertionError("actual normal config type/agent contract differs")
    def rng_state(rng):
        algorithm, keys, position, gaussian, cached = rng.get_state()
        return {"algorithm": algorithm, "keys": [int(x) for x in keys],
                "position": int(position), "has_gaussian": int(gaussian), "cached_gaussian": float(cached)}
    # Exact finite oracle initial state is a string-keyed dict of two-tuples.
    # Preserve scalar identity evidence while making the actual NumPy time
    # JSON-safe; this external fixture does not change candidate/oracle state.
    oracle = config["custom_properties"]["oracle"]
    if type(oracle.r) is not dict:
        raise AssertionError("actual oracle initial state must be the original dict")
    oracle_witness = {}
    for symbol, state in oracle.r.items():
        if (type(symbol) is not str or type(state) is not tuple or len(state) != 2
                or type(state[0]) is not np.int64 or type(state[1]) is not int):
            raise AssertionError("actual oracle initial state scalar/container contract differs")
        oracle_witness[symbol] = {"time_ns": int(state[0]), "reference_price": state[1],
            "container_type": type(state).__module__ + "." + type(state).__name__,
            "time_type": type(state[0]).__module__ + "." + type(state[0]).__name__,
            "price_type": type(state[1]).__module__ + "." + type(state[1]).__name__}
    config_witness = {"agents": [type(agent).__name__ for agent in config["agents"]],
                      "start_time": config["start_time"], "stop_time": int(config["stop_time"]),
                      "start_time_type": type(config["start_time"]).__name__, "stop_time_type": type(config["stop_time"]).__name__,
                      "agent_RandomState": [rng_state(agent.random_state) for agent in config["agents"]],
                      "latency_RandomState": rng_state(config["agent_latency_model"].random_state),
                      "kernel_RandomState": rng_state(config["random_state_kernel"]),
                      "global_RandomState": rng_state(np.random),
                      "oracle_initial_state": oracle_witness}
    public = []
    general_outputs = []
    if args.arm != "cold-new":
        # Genuine baseline and candidate legacy helpers, including return and
        # throw behavior, compared by the parent after the cold process exits.
        for kind, value in (("duration", "2h"), ("duration", "00:00:30"), ("duration", "bad-duration"),
                            ("duration", 1.75), ("duration", True), ("duration", np.int32(33)),
                            ("duration", 1 << 70), ("duration", -(1 << 63)), ("duration", np.int64(-(1 << 63))), ("duration", "NaT"), ("date", "2021-02-06"), ("date", "bad-date"),
                            ("format", -1), ("format", np.int64(-(1 << 63))), ("format", 1.5),
                            ("format", 1 << 70)):
            function = {"duration": utils.str_to_ns, "date": utils.datetime_str_to_ns, "format": utils.fmt_ts}[kind]
            try:
                result = function(value)
                public.append({"kind": kind, "input": str(value), "returned": True,
                               "type": type(result).__module__ + "." + type(result).__name__,
                               "value": str(result)})
            except BaseException as error:
                public.append({"kind": kind, "input": str(value), "returned": False,
                               "type": type(error).__module__ + "." + type(error).__name__, "message": str(error)})
        import pandas as pd
        import observer
        from abides_fork import trace
        from abides_markets.orders import Side
        def capture(label, function):
            try:
                frame = function()
                values = {name: [None if pd.isna(value) else (int(value) if str(frame[name].dtype) in ("int64", "int32", "Int64") else str(value)) for value in frame[name]] for name in frame.columns}
                general_outputs.append({"case": label, "returned": True, "columns": list(frame.columns),
                    "dtypes": {name: str(frame[name].dtype) for name in frame.columns}, "values": values})
            except BaseException as error:
                general_outputs.append({"case": label, "returned": False,
                    "type": type(error).__module__ + "." + type(error).__name__, "message": str(error)})
        # Same actual original trace replay in both arms, after a typed contract
        # declination would select it. No simulated output is substituted.
        for label, timestamp, oid in (("wide-id", 1612517400000000123, (1 << 53) + 1),
                                       ("np32-time", np.int32(33), 42), ("bool-time", True, 42)):
            episode = observer.Episode()
            agent = config["agents"][1]
            episode.append(agent, (0, "AGENT_TYPE", "raw", "typed-fixture"), False, True)
            episode.append(agent, (timestamp, "ORDER_SUBMITTED", "order", (1, oid, Side.BID, 1, 100, None)), True, False)
            observer.STATE = episode
            capture(label, lambda: trace.extract_trace({"agents": [agent]}))
            observer.finish_episode()
        raw = [{"message_id": 2, "src_id": 0, "dst_id": 1, "t_send_ns": None,
                "t_recv_ns": 1612517400000000123, "latency_ns": 0, "msg_type": "AGENT_WAKEUP",
                "order_id": None, "causal_parent": None}]
        capture("legacy-dict-ledger", lambda: trace.extract_message_trace({"message_ledger": raw, "deliver_seq_by_key": {(2, 1): 0}}))
    pandas_modules = sorted(name for name in sys.modules if name == "pandas" or name.startswith("pandas."))
    scipy_modules = sorted(name for name in sys.modules if name == "scipy" or name.startswith("scipy."))
    witness = None
    if args.arm != "baseline":
        from canonical_buffers import import_witness
        witness = import_witness()
    if args.arm == "cold-new" and (pandas_modules or scipy_modules or live_pandas_attempts is None or live_pandas_attempts
            or witness["unused_stock_modules_loaded"] or witness["stock_cli_loaded"]):
        raise AssertionError("normal actual entry/config loaded pandas/scipy/unused stock/stock CLI in cold child")
    result = {"schema": "t3-lightweight-canonical-combined-domain-child-v4-1", "arm": args.arm,
              "normal_time_controls": normal, "actual_config": config_witness,
              "public_time_results": public, "pandas_loaded_after_domains": bool(pandas_modules),
              "scipy_loaded_after_domains": bool(scipy_modules), "full_entry_config_import_witness": witness,
              "pandas_import_attempts_through_domains": [] if live_pandas_attempts is None else list(live_pandas_attempts),
              "general_original_output_results": general_outputs,
              "actual_config_constructed": True, "kernel_or_market_run": False,
              "candidate_writer_fixture": json.loads((args.out_dir / "receipt.json").read_text())}
    (args.out_dir / "DOMAIN_RECEIPT_v1.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
