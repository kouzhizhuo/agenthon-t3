"""Future root-owned serial fixture dispatch; preparation does not execute it."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-runtime", type=Path, required=True)
    parser.add_argument("--candidate-runtime", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.out_dir.exists():
        raise ValueError("fresh fixture results directory required")
    args.out_dir.mkdir(parents=True)
    worker = Path(__file__).with_name("output_fixture_worker_v1.py")
    receipts = {}
    for arm, runtime in (("baseline", args.baseline_runtime), ("new", args.candidate_runtime), ("cold-new", args.candidate_runtime)):
        out = args.out_dir / arm
        result = subprocess.run([sys.executable, "-B", str(worker), "--runtime", str(runtime), "--arm", arm, "--out-dir", str(out)],
                                check=False, capture_output=True, text=True)
        (args.out_dir / (arm + ".stdout.txt")).write_text(result.stdout)
        (args.out_dir / (arm + ".stderr.txt")).write_text(result.stderr)
        if result.returncode:
            raise RuntimeError("actual fixture child failed: " + arm + ", exit=" + str(result.returncode))
        receipts[arm] = json.loads((out / "receipt.json").read_text())
    for name in ("trace.parquet", "message_trace.parquet", "trace_sort_ties.parquet", "trace_sort_ties.json"):
        original = (args.out_dir / "baseline" / name).read_bytes()
        for arm in ("new", "cold-new"):
            if (args.out_dir / arm / name).read_bytes() != original:
                raise AssertionError("actual exact Parquet bytes differ: " + arm + "/" + name)
    for arm in ("new", "cold-new"):
        if receipts[arm]["production_write_api_files"] != receipts["baseline"]["production_write_api_files"]:
            raise AssertionError("actual production writer API bytes/hash differ")
        if receipts[arm]["production_write_api_readbacks"] != receipts["baseline"]["production_write_api_readbacks"]:
            raise AssertionError("actual production writer API rows/schema/nulls differ")
        if receipts[arm]["full_serializer_groups"] != receipts["baseline"]["full_serializer_groups"]:
            raise AssertionError("actual full serializer rowgroup schema/null/empty call differs")
        if receipts[arm]["trace_sort_tie_cases"] != receipts["baseline"]["trace_sort_tie_cases"]:
            raise AssertionError("actual timestamp/encounter/quote-tie projection differs")
    cold = receipts["cold-new"]["cold_import_witness"]
    if (cold["pandas_loaded"] or cold["scipy_loaded"] or cold["unused_stock_modules_loaded"] or cold["stock_cli_loaded"]):
        raise AssertionError("cold fixture loaded a forbidden scientific/unused stock/CLI module")
    # Readback is a separate verifier process after the cold writer children exit.
    import pandas as pd
    for name, contract_name in (("trace.parquet", "trace"), ("message_trace.parquet", "message_trace"), ("trace_sort_ties.parquet", "trace")):
        expected_dtypes = ({"t_ns": "int64", "agent_id": "int32", "msg_type": "string", "side": "string", "price": "int64", "size": "int64", "order_id": "int64"}
            if contract_name == "trace" else {"seq": "int64", "t_recv_ns": "int64", "t_send_ns": "Int64", "latency_ns": "int64", "src_id": "int32", "dst_id": "int32", "message_id": "int64", "msg_type": "string", "order_id": "Int64", "causal_parent": "Int64"})
        reference = pd.read_parquet(args.out_dir / "baseline" / name)
        for arm in ("new", "cold-new"):
            actual = pd.read_parquet(args.out_dir / arm / name)
            if {field: str(actual[field].dtype) for field in actual.columns} != expected_dtypes:
                raise AssertionError("actual readback logical dtypes differ")
            pd.testing.assert_frame_equal(reference, actual, check_dtype=True, check_exact=True)
    result = {"schema": "t3-pandas-free-output-fixture-controller-v1", "children": receipts,
              "actual_parquet_bytes_equal": True, "actual_readback_exact": True,
              "cold_pandas_import_attempts": receipts["cold-new"]["pandas_import_attempts"],
              "source_worker_sha256": hashlib.sha256(worker.read_bytes()).hexdigest(),
              "market_executed": False, "rankable": False}
    (args.out_dir / "FIXTURE_RESULT_v1.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
