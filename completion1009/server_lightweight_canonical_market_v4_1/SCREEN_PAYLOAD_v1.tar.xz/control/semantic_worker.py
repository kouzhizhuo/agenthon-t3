"""Actual four-strategy markets; full cold candidate writes precede control decode."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import pickle
import sys
import types
from common import SEEDS, SEMANTIC_ARMS, COLD_EMPTY, sha, write


def require(ok, message):
    if not ok: raise ValueError(message)


def cold_oracle():
    state = {"production_complete": False, "production_attempts": [], "control_attempts": []}
    def audit(event, arguments):
        if event == "import" and arguments and (arguments[0] in ("pandas", "scipy", "abides_fork.simulate",
                "abides_markets.agents.examples.momentum_agent",
                "abides_markets.agents.market_makers.adaptive_market_maker_agent",
                "abides_markets.agents.noise_agent", "abides_markets.agents.value_agent")
                or arguments[0].startswith(("pandas.", "scipy."))):
            target = state["control_attempts"] if state["production_complete"] else state["production_attempts"]
            target.append(arguments[0])
            if not state["production_complete"]:
                raise RuntimeError("actual market cold unused dependency import refused: " + arguments[0])
    sys.addaudithook(audit)
    return state


def scenario(seed, latency, protocol=False):
    result = {"scenario_id": "streaming-observer-controls-" + str(seed), "seed": seed,
        "horizon_ns": 2000000000,
        "exchange_config": {"symbol": "CTRL", "tick_size": 1, "lot_size": 1, "min_price": 1, "max_price": 1000000},
        "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100000, "kappa": .05,
            "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}},
        "agent_configs": [
            {"agent_type": "NoiseTrader", "count": 2, "params": {"arrival_rate_hz": 6., "order_size_mean": 10}},
            {"agent_type": "MarketMaker", "count": 1, "params": {"spread_ticks": 2, "depth_levels": 3,
                "size_per_level": 12, "rebalance_interval_ns": 300000000}},
            {"agent_type": "ValueTrader", "count": 1, "params": {"arrival_rate_hz": 4., "threshold_ticks": 2}},
            {"agent_type": "MomentumTrader", "count": 1, "params": {"arrival_rate_hz": 5., "threshold_ticks": 2}}]}
    if latency is not None: result["latency_config"] = latency
    if protocol: result["exchange_config"].update(protocol_enforcement=True, stp_policy="cancel_oldest", ack_delay_ns=400, compute_delay_ns=100)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--arm", choices=SEMANTIC_ARMS, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh semantic worker output required")
    args.out.mkdir(parents=True)
    output = args.out.resolve(); runtime = args.runtime.resolve()
    oracle = cold_oracle() if args.arm != "baseline" else None
    sys.path.insert(0, str(runtime))
    source = runtime / "agent.py"
    spec = importlib.util.spec_from_file_location("actual_lightweight_canonical_market_entry", source)
    cli = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cli)
    import numpy as np
    import observer
    import t3_canonical_engine as engine
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_core.message import Message
    from abides_fork.config import ScenarioLatencyModel
    from abides_markets.orders import Order, Side
    require(np.__version__ == "1.26.4", "actual pinned NumPy required")
    require(Path(observer.__file__).resolve().parent == runtime
            and Path(engine.__file__).resolve() == runtime / "t3_canonical_engine.py", "actual source runtime origins")
    def import_status():
        unused = ("abides_markets.agents.examples.momentum_agent",
                  "abides_markets.agents.market_makers.adaptive_market_maker_agent",
                  "abides_markets.agents.noise_agent", "abides_markets.agents.value_agent")
        names = lambda root: sorted(n for n in sys.modules if n == root or n.startswith(root + "."))
        pandas_modules, scipy_modules = names("pandas"), names("scipy")
        return {"pandas_loaded": bool(pandas_modules), "pandas_modules": pandas_modules,
                "scipy_loaded": bool(scipy_modules), "scipy_modules": scipy_modules,
                "unused_stock_modules_loaded": [n for n in unused if n in sys.modules],
                "stock_cli_loaded": "abides_fork.simulate" in sys.modules}
    initial_status = import_status()
    require(args.arm == "baseline" or initial_status == COLD_EMPTY,
            "actual candidate full entry loaded pandas/scipy/unused stock/CLI")

    def freeze(value, agent_ids=None):
        # Data-only exact owned scalar/container serializer. It copies values
        # now; no deferred live list, pickle load, repr, property or foreign iterator.
        actual = type(value)
        if value is None or actual is int or actual is str or actual is bool:
            return [actual.__name__, value]
        if actual is float: return ["float", value.hex()]
        if actual is bytes: return ["bytes", value.hex()]
        if actual is Side: return ["Side", value.value]
        for scalar in (np.int64, np.int32, np.float64, np.float32, np.bool_, np.uint64, np.uint32):
            if actual is scalar: return [actual.__name__, freeze(value.item(), agent_ids)]
        if actual is np.ndarray:
            require(not value.dtype.hasobject, "cold snapshot object ndarray refused")
            return ["ndarray", str(value.dtype), list(value.shape), value.tobytes().hex()]
        if actual is list or actual is tuple:
            return [actual.__name__, [freeze(child, agent_ids) for child in value]]
        if actual is dict:
            def key(item):
                if agent_ids is not None and id(item) in agent_ids:
                    return ["actual-agent", agent_ids[id(item)]]
                return freeze(item, agent_ids)
            return ["dict", [[key(k), freeze(v, agent_ids)] for k, v in value.items()]]
        raise TypeError("unsupported actual cold snapshot type: " + actual.__name__)

    def rng_walk(value, path="root", seen=None):
        seen = set() if seen is None else seen
        if type(value) is np.random.RandomState:
            return {path: freeze(value.get_state())}
        if value is None or type(value) in (int, str, float, bool, np.ndarray) or isinstance(value, np.generic): return {}
        if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)): return {}
        if id(value) in seen: return {}
        seen.add(id(value))
        if type(value) is dict: children = [(str(k), v) for k, v in value.items()]
        elif type(value) in (list, tuple): children = [(str(i), v) for i, v in enumerate(value)]
        elif hasattr(value, "__dict__"): children = list(vars(value).items())
        else: return {}
        result = {}
        for key, child in children: result.update(rng_walk(child, path + "/" + key, seen))
        return result

    def rng_snapshot(config, kernel):
        return {"numpy_global": freeze(np.random.get_state()), "config": rng_walk(config),
                "kernel": freeze(kernel.random_state.get_state())}

    def raw_snapshot(state, episode):
        agents = state["agents"]; kernel = agents[0].kernel
        require(type(episode) is observer.Episode, "actual retained observer episode absent")
        require(type(kernel) is engine.CanonicalKernel and type(kernel.messages) is engine.FlatHeap
                and type(state["message_ledger"]) is engine.ColumnLedger, "actual source-owned engine types required")
        ids = {id(agent): int(agent.id) for agent in agents}
        ledger = state["message_ledger"]; columns = ledger.columns
        aliases = [state["agents"] is kernel.agents, ledger is kernel._msg_ledger,
                   state["deliver_seq_by_key"] is kernel._deliver_seq_by_key,
                   type(columns) is tuple and len(columns) == 9,
                   len({id(c) for c in columns}) == 9,
                   *[type(c) is list for c in columns],
                   *[agent.kernel is kernel for agent in agents]]
        require(all(aliases), "actual retained raw state aliases differ")
        return {"contract": freeze(episode.contract, ids), "inference": freeze(episode.inference, ids),
                "ledger": freeze(columns), "delivery_map": freeze(state["deliver_seq_by_key"]),
                "aliases": aliases}

    def uid_snapshot():
        return [int(Order._order_id_counter), int(Message._Message__message_id_counter)]

    def counters(episode):
        return {key: freeze(child) for key, child in vars(episode).items() if key not in ("contract", "inference")}

    captured = []
    cases = ((81009, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}, False),
             (82009, {"model": "deterministic", "params": {"mean_ns": 0}}, False),
             (83009, {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}, True),
             (84009, {"model": "pareto", "params": {"min_ns": 1, "max_ns": 2000, "alpha": 1.5}}, False))
    original_run = abides.run
    for seed, latency, protocol in cases:
        value = scenario(seed, latency, protocol)
        folder = output / str(seed); folder.mkdir()
        config_path = folder / "scenario.json"; write(config_path, value)
        current = {"actual_run_calls": 0}
        old_kernel, old_latency = abides.Kernel, ScenarioLatencyModel.get_latency
        old_summary = Kernel.write_summary_log
        def capture(config, *positional, **keywords):
            current["actual_run_calls"] += 1
            require(current["actual_run_calls"] == 1, "actual entry reran the market")
            state = original_run(config, *positional, **keywords)
            kernel = state["agents"][0].kernel; episode = observer.STATE
            current.update(config=config, state=state, episode=episode,
                           pre_raw=raw_snapshot(state, episode), pre_rng=rng_snapshot(config, kernel),
                           pre_uid=uid_snapshot(), pre_counters=counters(episode))
            return state
        abides.run = capture
        try:
            np.random.seed(19301009)
            if args.arm != "baseline":
                events = cli.simulate(config_path, folder / "trace.parquet", mode="optimized",
                                      witness_path=folder / "OUTPUT_WITNESS_v1.json")
            else:
                events = cli.simulate(config_path, folder / "trace.parquet", mode="optimized")
        finally:
            abides.run = original_run
        require(abides.Kernel is old_kernel and ScenarioLatencyModel.get_latency is old_latency
                and Kernel.write_summary_log is old_summary and observer.STATE is None,
                "actual entry did not restore engine/latency/summary/observer bindings")
        require(current["actual_run_calls"] == 1, "exactly one actual market per entry required")
        state, config, episode = current["state"], current["config"], current["episode"]
        kernel = state["agents"][0].kernel
        current["post_raw"] = raw_snapshot(state, episode)
        current["post_rng"] = rng_snapshot(config, kernel)
        current["post_uid"] = uid_snapshot(); current["post_counters"] = counters(episode)
        require(current["post_raw"] == current["pre_raw"] and current["post_rng"] == current["pre_rng"]
                and current["post_uid"] == current["pre_uid"], "actual output mutated original raw state/RNG/UID")
        imports = import_status()
        witness = json.loads((folder / "OUTPUT_WITNESS_v1.json").read_text()) if args.arm != "baseline" else None
        if args.arm != "baseline":
            require(not oracle["production_attempts"] and imports == COLD_EMPTY, "new actual market/write path imported forbidden dependencies")
            require(witness["schema"] == "t3-pandas-free-output-episode-witness-v1"
                    and witness["source_authenticated"] is True and witness["observer_admitted"] is True
                    and witness["projectors_admitted"] is True and witness["declines"] == {}
                    and witness["output_mode"] == "canonical-arrow-buffers"
                    and witness["before"] == COLD_EMPTY
                    and witness["after"] == witness["before"] and witness["market_rerun"] is False,
                    "actual paired canonical writer/source/cold witness differs")
        for name in ("trace.parquet", "message_trace.parquet"):
            require((folder / name).is_file(), "actual paired production output absent")
        require(events == json.loads((folder / "events.json").read_text())
                and events["trace_sha256"] == sha(folder / "trace.parquet"), "actual event sidecar/output SHA differs")
        current.update(seed=seed, events=events, witness=witness, production_import_status=imports,
                       production_attempts=[] if oracle is None else list(oracle["production_attempts"]))
        captured.append(current)
    final_cold = {"production_attempts": [] if oracle is None else list(oracle["production_attempts"]),
        "import_status": import_status(),
        "production_complete": True, "markets_completed": len(captured)}
    require(args.arm == "baseline" or final_cold["production_attempts"] == [] and final_cold["import_status"] == COLD_EMPTY,
            "actual final cold production witness differs")
    # Explicit configured latency replaces the default SciPy-backed latency only
    # in this cold control domain; actual baseline/candidate scenario JSON is equal.
    # Recheck old episode/config/kernel sources before any deferred scientific decode.
    for row in captured:
        row["final_raw"] = raw_snapshot(row["state"], row["episode"])
        row["final_local_rng"] = {"config": rng_walk(row["config"]), "kernel": freeze(row["state"]["agents"][0].kernel.random_state.get_state())}
        require(row["final_raw"] == row["post_raw"] and row["final_local_rng"] == {k: row["post_rng"][k] for k in ("config", "kernel")},
                "later market changed a preserved episode/state or local RNG")
    if oracle is not None: oracle["production_complete"] = True
    import pandas as pd
    import pyarrow as pa
    import semantic_mapping as mapping
    from semantic_mapping import encode, graph
    require(pd.__version__ == "1.5.3" and pa.__version__ == "15.0.2", "actual pinned control decode required")
    import warnings

    def summary_aliases(kernel):
        return [[int(entry["AgentID"]), entry["EventType"],
            [(event_type, int(timestamp)) for timestamp, event_type, payload in kernel.agents[entry["AgentID"]].log
             if event_type == entry["EventType"] and payload is entry["Event"]]] for entry in kernel.summary_log]

    def snapshot_witness(rows):
        return [{key: (len(child) != 0 if key in ("bids", "asks") else child) for key, child in row.items()} for row in rows]

    def witness_consumers(kernel):
        values = []
        for agent in kernel.agents:
            for symbol, book in getattr(agent, "order_books", {}).items():
                consumers = []
                for method in ("get_time_dropout", "_original_time_dropout"):
                    probe = type(agent).__new__(type(agent)); probe.metric_trackers = {symbol: agent.MetricTracker()}
                    with warnings.catch_warnings(record=True) as observed:
                        warnings.simplefilter("always")
                        try:
                            getattr(probe, method)(book.book_log2, symbol)
                            result = ["metrics", encode(probe.metric_trackers)]
                        except Exception as error: result = ["exception", type(error).__name__, str(error)]
                        warning_values = [(w.category.__name__, str(w.message)) for w in observed]
                    consumers.append([method, result, warning_values])
                values.append([int(agent.id), symbol, encode(snapshot_witness(book.book_log2)), encode(agent.metric_trackers[symbol]), consumers])
        return values

    values, summaries = [], []
    for row in captured:
        state, config, episode = row["state"], row["config"], row["episode"]
        kernel = state["agents"][0].kernel
        require(raw_snapshot(state, episode) == row["post_raw"], "deferred decode changed raw state")
        mapping.configure(engine, "original_canonical")
        owner = mapping.audit_kernel(kernel, state)
        end = {key: child for key, child in state.items() if key not in ("kernel_event_queue_elapsed_wallclock", "agents")}
        retained = graph([state["agents"], config, mapping.kernel_fields(kernel), end])
        depth = [[int(agent.id), symbol, depth, encode(book.get_l2_bid_data(depth)), encode(book.get_l2_ask_data(depth)),
                  encode(book.get_l3_bid_data(depth)), encode(book.get_l3_ask_data(depth))]
                 for agent in state["agents"] for symbol, book in getattr(agent, "order_books", {}).items() for depth in (0, 1, 10, -1)]
        folder = output / str(row["seed"])
        frames = [pd.read_parquet(folder / name) for name in ("trace.parquet", "message_trace.parquet")]
        blobs = [(folder / name).read_bytes() for name in ("trace.parquet", "message_trace.parquet")]
        require(len(frames[0]) == row["events"]["n_events"], "actual trace rows/sidecar differ")
        if row["witness"] is not None:
            require(row["witness"]["actual_trace_rows"] == len(frames[0]) and row["witness"]["actual_trace_sha256"] == sha(folder / "trace.parquet"), "actual entry output witness row/hash differs")
        details = {"private_log_rows": sum(len(agent.log) for agent in state["agents"]), "summary_rows": len(kernel.summary_log),
                   "observer_before_output": row["pre_counters"], "ttl_messages": kernel.ttl_messages,
                   "book_rows": sum(len(book.book_log2) for agent in state["agents"] for book in getattr(agent, "order_books", {}).values())}
        payload = [blobs, retained, row["post_rng"], row["post_uid"], summary_aliases(kernel), depth,
                   graph([[[agent.id, agent.log] for agent in kernel.agents], kernel.summary_log]),
                   [agent.kernel is kernel for agent in state["agents"]], witness_consumers(kernel)]
        values.append({"seed": row["seed"], "frames": frames, "payload": payload, "details": details})
        summaries.append({"seed": row["seed"], "actual_run_calls": row["actual_run_calls"], "trace_rows": len(frames[0]), "message_rows": len(frames[1]),
            "details": details, "owner": owner, "source_entry_sha256": sha(source), "source_engine_sha256": sha(runtime / "t3_canonical_engine.py"),
            "raw_snapshot_before": row["pre_raw"], "raw_snapshot_after": row["post_raw"], "raw_snapshot_final": row["final_raw"],
            "rng_before": row["pre_rng"], "rng_after": row["post_rng"], "local_rng_final": row["final_local_rng"],
            "uids_before": row["pre_uid"], "uids_after": row["post_uid"], "observer_after_output": row["post_counters"],
            "production_import_status": row["production_import_status"], "production_attempts": row["production_attempts"], "output_witness": row["witness"],
            "bindings_restored": True, "observer_finished": True})
    data = pickle.dumps(values, protocol=4); (output / "SEMANTIC_VALUES.pkl").write_bytes(data)
    receipt = {"schema": "t3-lightweight-canonical-market-semantic-worker-v4-1", "arm": args.arm, "cases": summaries,
        "values_sha256": hashlib.sha256(data).hexdigest(), "source_worker_sha256": sha(Path(__file__)),
        "source_mapping_sha256": sha(Path(__file__).with_name("semantic_mapping.py")), "actual_entry_sha256": sha(source),
        "final_production_import_witness": final_cold, "control_decode_pandas_loaded": True,
        "control_import_attempts": [] if oracle is None else list(oracle["control_attempts"]),
        "initial_production_import_status": initial_status, "runtime": str(runtime), "versions": {"numpy": np.__version__, "pandas": pd.__version__, "pyarrow": pa.__version__},
        "market_records": 4, "retained_actual_parquets": 8, "nine_payload_components": True,
        "source_mapping_mode": "original_canonical", "rankable": False, "timing_claim": False}
    write(output / "WORKER_RECEIPT.json", receipt)
    print(json.dumps({"arm": args.arm, "markets": 4, "parquets": 8, "cold_production_complete": args.arm != "baseline", "rankable": False}), flush=True)

if __name__ == "__main__": main()
