"""Same-process actual source CLI routing; full controls are separate subprocesses."""
import argparse
import os
from pathlib import Path
import runpy
import subprocess
import sys
from common import IMAGE_ROOT, CANDIDATE, BASELINE, ARMS, PHASE_ARMS
ROOT = Path(IMAGE_ROOT)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=("simulate", "simulate-batch"))
    parser.add_argument("--config"); parser.add_argument("--out")
    parser.add_argument("--batch-dir"); parser.add_argument("--out-dir")
    parser.add_argument("--mode", choices=(*ARMS, *PHASE_ARMS, "controls"), required=True)
    args = parser.parse_args()
    if args.mode == "controls":
        if args.verb != "simulate" or args.config != "/input/scenario.json" or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir:
            raise ValueError("fixed controls paths required")
        import json
        if json.loads(Path(args.config).read_text()) != {"proof_command": "lightweight-canonical-four-markets-three-arms-full9-v4-1"}:
            raise ValueError("fixed controls command required")
        completed = subprocess.run([sys.executable, "-B", str(ROOT / "control/market_controls.py"), "--baseline", str(ROOT / BASELINE), "--new", str(ROOT / CANDIDATE / "runtime"), "--out", "/output/controls"], env=dict(os.environ), timeout=1800)
        raise SystemExit(completed.returncode)
    runtime = ROOT / (BASELINE if args.mode in ("baseline", "diagnostic-baseline") else CANDIDATE + "/runtime")
    source = runtime / "agent.py"
    if args.verb == "simulate":
        if args.config != "/input/scenario.json" or args.out != "/output/trace.parquet" or args.batch_dir or args.out_dir:
            raise ValueError("fixed single paths required")
        actual = [str(source), "simulate", "--config", args.config, "--out", args.out, "--mode", "optimized"]
    else:
        if args.batch_dir != "/input/scenarios" or args.out_dir != "/output" or args.config or args.out:
            raise ValueError("fixed batch paths required")
        actual = [str(source), "simulate-batch", "--batch-dir", args.batch_dir, "--out-dir", args.out_dir, "--mode", "optimized"]
    sys.path.insert(0, str(runtime)); sys.argv = actual
    if args.mode in PHASE_ARMS:
        from phase_entry import main as diagnostic_main
        diagnostic_main(source, actual, "baseline" if args.mode == "diagnostic-baseline" else "new")
        return
    # No hook/graph/witness/extra output in measured production.
    runpy.run_path(str(source), run_name="__main__")

if __name__ == "__main__": main()
