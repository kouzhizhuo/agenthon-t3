"""Source-bound two-arm diagnostic daemon screen; no full71 or official score claim."""
import argparse
import ast
import calendar
from datetime import datetime
import json
import math
import os
from pathlib import Path
import platform
import shutil
import signal
import statistics
import subprocess
import time
import uuid
from common import BASE, CANDIDATE, BASELINE, GENERATOR, ENTRYPOINT, ARMS, SEMANTIC_ARMS, PHASE_ARMS, COLD_EMPTY, SEEDS, SINGLES, BATCH, sha, inventory, verify_payload, write, arm_order
PAYLOAD = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public

def call(args, command, label, seconds=60, allow_failure=False):
    path = args.evidence / (label + ".log")
    started = time.monotonic()
    result = None
    failure = None
    timed_out = False
    with path.open("xb") as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=seconds)
        except subprocess.TimeoutExpired as error:
            timed_out = True
            failure = {"type": type(error).__name__, "message": str(error)}
        except OSError as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    record = {"command": command, "returncode": None if result is None else result.returncode,
              "timed_out": timed_out, "failure": failure, "host_elapsed_sec": time.monotonic() - started,
              "log": {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}}
    write(args.evidence / (label + ".json"), record)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual bounded command failed: " + label)
    return record


def inspect(args, name, label):
    call(args, [args.docker, "inspect", name], label)
    value = json.loads((args.evidence / (label + ".log")).read_text())
    if type(value) is not list or len(value) != 1:
        raise ValueError("one actual inspected object required")
    return value[0]


def build(args, plan):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("actual Linux amd64 host required")
    verify_payload(PAYLOAD)
    args.evidence.mkdir(parents=True, exist_ok=True)
    anonymous = args.evidence / "anonymous-docker-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        call(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    base = inspect(args, BASE, "base-inspect")
    if "sha256:5a190afe0bdfe7685e64cbf1aec30d39885199c85f688a971b8d4a0ab8d217eb" not in " ".join(base.get("RepoDigests", [])):
        raise ValueError("actual base digest differs")
    tag = "t3-lightweight-canonical-market-v4-1:" + uuid.uuid4().hex
    call(args, [args.docker, "build", "--platform", "linux/amd64", "--pull=false", "-t", tag,
                "-f", str(PAYLOAD / "control/Dockerfile"), str(PAYLOAD)], "image-build", 600)
    image = inspect(args, tag, "image-inspect")
    if image["Config"]["Entrypoint"] != ENTRYPOINT or image["Config"]["User"] != "65534:65534":
        raise ValueError("actual fixture image entry/user differs")
    evidence_owner = uuid.uuid4().hex
    evidence_name = "t3-lightweight-source-" + uuid.uuid4().hex
    evidence_commands = linux.DockerCommands(args.docker, args.evidence / "source-copy-commands", args.log_cap_bytes)
    copied = args.evidence / "installed"
    copied_ok = False
    cleanup = None
    try:
        made = evidence_commands.call(["create", "--name", evidence_name,
            "--label", linux.OWNER_LABEL + "=" + evidence_owner, "--pull", "never", image["Id"]], "create", 30)
        if not made["succeeded"]:
            raise RuntimeError("source evidence container create failed")
        info, _ = evidence_commands.inspect(evidence_name, cleanup=True)
        if info is None:
            raise ValueError("source evidence container absent")
        linux.require_owned(info, evidence_name, evidence_owner, image["Id"])
        copied_ok = evidence_commands.call(["cp", evidence_name + ":/opt/lightweight-canonical-market-v4-1", str(copied)], "installed-copy", 60)["succeeded"]
    finally:
        cleanup = linux.settle_container(evidence_commands, evidence_name, evidence_owner, image["Id"], creation_uncertain=True)
        write(args.evidence / "SOURCE_COPY_EXECUTION.json", {"name": evidence_name, "owner": evidence_owner,
            "image_id": image["Id"], "commands": evidence_commands.rows, "cleanup": cleanup, "rankable": False})
    if (not copied_ok or cleanup["settled"] is not True or cleanup["removed"] is not True
            or cleanup["final_absent"] is not True or cleanup["errors"] != []):
        raise ValueError("actual source-copy cleanup/exact absence failed")
    # Frozen sources, generated metadata and pin are inspected after the actual
    # build rather than accepted from Dockerfile text or claimed receipt flags.
    for row in plan["candidate_sources"]:
        actual = copied / CANDIDATE / row["path"]
        if actual.stat().st_size != row["bytes"] or sha(actual) != row["sha256"]:
            raise ValueError("installed candidate source differs")
    if inventory(copied / BASELINE) != plan["baseline_sources"]:
        raise ValueError("installed baseline source differs")
    if sha(copied / GENERATOR) != plan["generator_sha256"]:
        raise ValueError("installed exact schema generator differs")
    metadata = copied / CANDIDATE / "runtime/schema_metadata_v1.json"
    pin = copied / CANDIDATE / "runtime/schema_metadata_pin_v1.py"
    deployed = json.loads((copied / "schema-build/DEPLOYED_SCHEMA_PIN_RECEIPT_v1.json").read_text())
    if (deployed["metadata"]["sha256"] != sha(metadata) or deployed["metadata"]["bytes"] != metadata.stat().st_size
            or deployed["source_pin"]["sha256"] != sha(pin) or deployed["source_pin"]["bytes"] != pin.stat().st_size):
        raise ValueError("actual generated metadata/pin binding differs")
    pin_tree = ast.parse(pin.read_bytes())
    pin_value = ast.literal_eval(next(node.value for node in pin_tree.body if isinstance(node, ast.Assign)
        and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "SCHEMA_METADATA_SHA256"))
    baseline_schema = json.loads((copied / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json").read_text())
    if (pin_value != sha(metadata) or baseline_schema.get("versions") != {"numpy": "1.26.4", "pandas": "1.5.3", "pyarrow": "15.0.2"}
            or baseline_schema.get("metadata", {}).get("sha256") != sha(metadata)
            or baseline_schema.get("generator", {}).get("sha256") != plan["generator_sha256"]
            or deployed.get("baseline_receipt_sha256") != sha(copied / "schema-build/BASELINE_SCHEMA_BUILD_RECEIPT_v1.json")):
        raise ValueError("actual pinned schema generator/receipt/source constant differs")
    expected_runtime = {row["path"][len("runtime/"):]: {"bytes": row["bytes"], "sha256": row["sha256"]}
        for row in plan["candidate_sources"] if row["path"].startswith("runtime/")}
    actual_runtime = inventory(copied / CANDIDATE / "runtime")
    for name in ("schema_metadata_v1.json", "schema_metadata_pin_v1.py"):
        if name not in actual_runtime:
            raise ValueError("actual generated schema runtime file absent")
        actual_runtime.pop(name)
    if actual_runtime != expected_runtime:
        raise ValueError("actual runtime contains changed or extra ordinary sources")
    for name, expected in plan["control_sources"].items():
        actual = copied / "control" / name
        if actual.stat().st_size != expected["bytes"] or sha(actual) != expected["sha256"]:
            raise ValueError("actual installed fixture control source differs")
    write(args.evidence / "ACTUAL_BUILD_INVENTORY_v1.json", {"schema": "t3-pandas-free-fixture-build-inventory-v1",
        "base_image": base["Id"], "screen_image": image["Id"], "installed_files": inventory(copied),
        "generated_metadata_sha256": sha(metadata), "generated_pin_sha256": sha(pin),
        "candidate_source_receipt_sha256": plan["candidate_source_receipt_sha256"],
        "candidate_executed_during_build": False, "kernel_or_market_run": False, "rankable": False})
    for key, runtime in (("baseline", copied / BASELINE), ("new", copied / CANDIDATE / "runtime")):
        if sha(runtime / "agent.py") != plan["actual_entry_sources"][key]["sha256"]:
            raise ValueError("actual deployed entry differs")
    write(args.evidence / "BUILD_READY.json", {"image_id": image["Id"], "base_id": base["Id"], "passed": True, "rankable": False})

class StrictCommands(linux.DockerCommands):
    def call(self, arguments, label, seconds=30, cleanup=False):
        if arguments and arguments[0] == "create":
            arguments = [arguments[0], "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456", *arguments[1:]]
        return super().call(arguments, label, seconds, cleanup)

    def inspect(self, name, cleanup=False, seconds=30):
        info, record = super().inspect(name, cleanup, seconds)
        if info is not None and not cleanup:
            if info["Config"]["Entrypoint"] != ENTRYPOINT: raise ValueError("actual market screen entrypoint differs")
            host = info["HostConfig"]
            limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
            if limits != {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}:
                raise ValueError("actual full finite screen ulimits differ")
            binds = [row for row in info["Mounts"] if row["Type"] == "bind"]
            if len(binds) != 2 or {row["Destination"]: row["RW"] for row in binds} != {"/input": False, "/output": True}:
                raise ValueError("actual input/output-only bind envelope differs")
        return info, record
linux.DockerCommands = StrictCommands


def duration_ns(state):
    def parse(value):
        base, fraction = value.rstrip("Z").split(".", 1)
        return calendar.timegm(datetime.strptime(base, "%Y-%m-%dT%H:%M:%S").timetuple()) * 10 ** 9 + int(fraction.ljust(9, "0"))
    return (parse(state["FinishedAt"]) - parse(state["StartedAt"])) / 10 ** 9


def pair(output, other, item):
    paths = list(public.SUB_FILES[:2]) if item["shape"] == "single" else [sub["sub"] + "/" + name for sub in item["subs"] for name in public.SUB_FILES[:2]]
    frames = [public.compare_frame(output / name, other / name) for name in paths]
    sidecars = ["events.json"] if item["shape"] == "single" else [sub["sub"] + "/events.json" for sub in item["subs"]] + ["batch_events.json"]
    stable = []
    for name in sidecars:
        a, b = public.read_json(output / name), public.read_json(other / name)
        for value in (a, b):
            for key in ("wall_clock_sec", "events_per_sec", "peak_memory_bytes", "gpu_seconds"): value.pop(key, None)
        stable.append({"path": name, "passed": a == b, "baseline": b, "candidate": a})
    return {"passed": all(row["passed"] and row.get("byte_equal") for row in frames) and all(row["passed"] for row in stable), "frames": frames, "stable_sidecars": stable}


def run_one(args, image_id, arm, item, folder, suffix, reference=True):
    execution, output = linux.run_container(args, image_id, arm, item, folder, args.owner, suffix)
    row = {"arm": arm, "unit": item["unit"], "execution": execution, "output": str(output), "passed": False,
           "rankable": False, "timing_included": False}
    try:
        if not execution["succeeded"] or any(sha(Path(value["staged"])) != value["sha256"] for value in execution["staged_inputs"]):
            raise ValueError("actual strict run or original staged input failed")
        inspected = execution["effective_config"]["Config"]
        if inspected["Entrypoint"] != ENTRYPOINT or inspected["Cmd"][-2:] != ["--mode", arm]:
            raise ValueError("actual exact-source CLI route differs")
        row["output_inventory"] = inventory(output)
        events = public.read_json(output / ("events.json" if item["shape"] == "single" else "batch_events.json"))
        if reference:
            row["reference_checks"] = public.verify_outputs(args.reference_root / item["unit"], output, item)
            row["developer_verifier"] = linux.gate(args, args.reference_root / item["unit"], output, folder)
            if not row["reference_checks"]["passed"] or row["developer_verifier"]["admissible"] is not True:
                raise ValueError("actual official reference or unchanged verifier failed")
        else:
            frames = [public.compare_frame(output / name, Path(item["isolated_reference"]) / name) for name in public.SUB_FILES[:2]]
            checked = public.verify_events(output, public.read_json(item["scenario_paths"][0]), frames[0].get("candidate_rows", 0))
            tree = public.check_tree(output, set(public.SUB_FILES))
            if not all(value["passed"] for value in frames) or not checked["passed"] or not tree["passed"]:
                raise ValueError("actual isolated member reference/sidecar/output tree failed")
            row["reference_checks"] = {"passed": True, "actual_events": frames[0]["candidate_rows"], "frames": frames, "sidecar": checked, "tree": tree}
        actual = row["reference_checks"]["actual_events"]
        if events.get("n_events", events.get("total_events")) != actual: raise ValueError("actual trace rows/sidecar differ")
        if item["shape"] == "batch" and [r["sub"] for r in events["per_scenario"]] != sorted(r["sub"] for r in item["subs"]):
            raise ValueError("actual batch source CLI sorted order differs")
        row.update(actual_events=actual, cli_wall_sec=events["wall_clock_sec"], settled_container_runtime_sec=duration_ns(execution["state"]),
                   daemon_started_at=execution["state"]["StartedAt"], daemon_finished_at=execution["state"]["FinishedAt"])
        if any(not math.isfinite(value) or value <= 0 for value in (row["cli_wall_sec"], row["settled_container_runtime_sec"], execution["host_wall_sec"])):
            raise ValueError("actual positive finite daemon/host/CLI times required")
        row["passed"] = True
    except BaseException as error:
        row["failure"] = {"type": type(error).__name__, "message": str(error)}
    write(folder / "RUN_RESULT.json", row)
    print(arm, item["unit"], "PASS" if row["passed"] else "FAIL", flush=True)
    return row



def validate_phases(row, plan, item, canonical_arm):
    attach = row["execution"]["attach"]
    stdout = Path(attach["stdout"]["path"])
    if sha(stdout) != attach["stdout"]["sha256"] or stdout.stat().st_size != attach["stdout"]["bytes"]:
        raise ValueError("actual diagnostic stdout bytes changed")
    prefix = "T3_LIGHTWEIGHT_V4_1_UNTIMED_PHASES="
    lines = [line[len(prefix):] for line in stdout.read_text().splitlines() if line.startswith(prefix)]
    if len(lines) != 1:
        raise ValueError("one actual diagnostic phase report required")
    report = json.loads(lines[0])
    if (report["schema"] != "t3-lightweight-canonical-untimed-phase-driver-v4-1"
            or report["arm"] != canonical_arm or report["source_sha256"] != plan["actual_entry_sources"][canonical_arm]["sha256"]
            or report["failure"] is not None or report["non_marker_AST_equal"] is not True
            or report["simulate_alias_restored"] is not True or report["phase_global_removed"] is not True
            or report["trace_hook_used"] is not False or report["timing_included"] is not False
            or report["rankable"] is not False or report["diagnostic_overhead_included"] is not True):
        raise ValueError("actual source-bound marker-only phase report differs")
    ticks, milestones = report["ticks"], report["milestones"]
    if not ticks or len(ticks) > 400 or len(milestones) != 5:
        raise ValueError("finite actual phase roster absent")
    for records in (ticks, milestones):
        clocks = [v["perf_counter"] for v in records]
        if not all(type(v) in (int, float) and math.isfinite(v) and v > 0 for v in clocks) or clocks != sorted(clocks):
            raise ValueError("actual finite monotonic phase clocks differ")
    expected_configs = (["/input/scenario.json"] if item["shape"] == "single"
                        else ["/input/scenarios/" + Path(v).name for v in sorted(item["scenario_paths"])])
    groups = []
    for tick in ticks:
        if tick["phase"] == "simulate_enter":
            groups.append([])
        if not groups:
            raise ValueError("phase before actual episode entry")
        groups[-1].append(tick)
    if [g[0]["config_path"] for g in groups] != expected_configs:
        raise ValueError("actual phase original sorted episode roster differs")
    intervals = []
    for group in groups:
        labels = [v["phase"] for v in group]
        if (labels[-1] != "simulate_exit" or labels.count("simulation_enter") != 1
                or labels.count("simulation_exit") != 1 or any(v["config_path"] != group[0]["config_path"] for v in group)):
            raise ValueError("actual phase episode/run count differs")
        intervals.append({"config_path": group[0]["config_path"], "successive_marker_intervals": [
            {"phase": a["phase"], "next_phase": b["phase"], "seconds": b["perf_counter"] - a["perf_counter"]}
            for a, b in zip(group, group[1:])]})
    return {"actual_report": report, "intervals_diagnostic_only": intervals,
            "retained_stdout": attach["stdout"], "timing_included": False}

def validate_controls(output, plan):
    result = public.read_json(output / "RESULT.json")
    if (result["schema"] != "t3-lightweight-canonical-full-market-controls-v4-1" or result["all_passed"] is not True
            or result["failures"] != [] or result["arms"] != list(SEMANTIC_ARMS) or result["market_records"] != 12
            or result["retained_actual_parquets"] != 24 or result["worker_roots"] != 3
            or result["nine_payload_components"] is not True or result["actual_both_candidate_workers_continuous_cold"] is not True
            or result["rankable"] is not False or result["official_gate"] is not False or result["timing_claim"] is not False
            or result["source_mapping_sha256"] != plan["control_sources"]["semantic_mapping.py"]["sha256"]
            or result["source_worker_sha256"] != plan["control_sources"]["semantic_worker.py"]["sha256"]
            or result["source_controller_sha256"] != plan["control_sources"]["market_controls.py"]["sha256"]):
        raise ValueError("actual complete control scope/source/result differs")
    if [row["seed"] for row in result["cases"]] != list(SEEDS): raise ValueError("actual four seed roster differs")
    expected_paths = {"RESULT.json", *[a + ".log" for a in SEMANTIC_ARMS]}
    records = []
    for arm in SEMANTIC_ARMS:
        worker = public.read_json(output / arm / "WORKER_RECEIPT.json")
        if worker != result["workers"][arm] or worker["values_sha256"] != sha(output / arm / "SEMANTIC_VALUES.pkl"):
            raise ValueError("actual worker/payload saved binding differs")
        if worker["actual_entry_sha256"] != plan["actual_entry_sources"][arm]["sha256"]:
            raise ValueError("actual frozen entry source differs")
        if arm != "baseline" and worker["final_production_import_witness"] != {"production_attempts": [], "import_status": COLD_EMPTY, "production_complete": True, "markets_completed": 4}:
            raise ValueError("actual new complete cold stage missing")
        expected_paths.update(arm + "/" + name for name in ("WORKER_RECEIPT.json", "SEMANTIC_VALUES.pkl"))
        for index, seed in enumerate(SEEDS):
            case = worker["cases"][index]
            if case["source_entry_sha256"] != plan["actual_entry_sources"][arm]["sha256"] or case["source_engine_sha256"] != plan["engine_source_sha256"]:
                raise ValueError("actual per-market source origins differ")
            if (case["raw_snapshot_before"] != case["raw_snapshot_after"] or case["raw_snapshot_after"] != case["raw_snapshot_final"]
                    or case["rng_before"] != case["rng_after"] or case["uids_before"] != case["uids_after"]
                    or case["actual_run_calls"] != 1 or not case["bindings_restored"] or not case["observer_finished"]):
                raise ValueError("actual per-market raw state/RNG/UID/restoration differs")
            expected_paths.update(arm + "/" + str(seed) + "/" + name for name in ("scenario.json", "trace.parquet", "message_trace.parquet", "events.json"))
            if arm != "baseline":
                witness = public.read_json(output / arm / str(seed) / "OUTPUT_WITNESS_v1.json")
                if (case["production_import_status"] != COLD_EMPTY or case["production_attempts"] != []
                        or witness != case["output_witness"] or witness["before"] != COLD_EMPTY
                        or witness["after"] != COLD_EMPTY or witness["source_authenticated"] is not True
                        or witness["observer_admitted"] is not True or witness["projectors_admitted"] is not True
                        or witness["declines"] != {} or witness["output_mode"] != "canonical-arrow-buffers"
                        or witness["market_rerun"] is not False or witness["actual_trace_rows"] != case["trace_rows"]
                        or witness["actual_trace_sha256"] != sha(output / arm / str(seed) / "trace.parquet")):
                    raise ValueError("actual candidate admission/output/cold witness differs")
                expected_paths.add(arm + "/" + str(seed) + "/OUTPUT_WITNESS_v1.json")
            for name, count in (("trace.parquet", case["trace_rows"]), ("message_trace.parquet", case["message_rows"])):
                compared = public.compare_frame(output / arm / str(seed) / name, output / "baseline" / str(seed) / name)
                if not compared["passed"] or not compared.get("byte_equal") or compared["candidate_rows"] != count:
                    raise ValueError("actual retained production Parquet values/dtypes/bytes differ")
                records.append({"arm": arm, "seed": seed, "path": name, **compared})
    if set(inventory(output)) != expected_paths or len(records) != 24: raise ValueError("actual complete controls retained file roster differs")
    return {"result": result, "actual_parquet_records": records, "saved_full9_inert_audit_required": True,
            "host_did_not_deserialize_control_pickle": True}


def screen(args, plan):
    args.owner = uuid.uuid4().hex; args.timeout = 300
    ready = public.read_json(args.evidence / "BUILD_READY.json"); image_id = ready["image_id"]
    before = linux.image_metadata(args, image_id, args.evidence / "image-before-screen")
    if before["inspection"]["Config"]["Entrypoint"] != ENTRYPOINT:
        raise ValueError("actual pinned screen image entry differs")
    actual_installed = args.evidence / "installed"
    expected_build = public.read_json(args.evidence / "ACTUAL_BUILD_INVENTORY_v1.json")
    if inventory(actual_installed) != expected_build["installed_files"] or expected_build["screen_image"] != image_id:
        raise ValueError("actual build source/image inventory changed before screen")
    roster = public.collect_plan(args.reference_root, list(SINGLES) + [BATCH]); write(args.evidence / "REFERENCE_PLAN.json", roster)
    items = {value["unit"]: value for value in roster["units"]}
    if len(items[BATCH]["subs"]) != 5: raise ValueError("actual original five-member batch required")
    rows, failure, first, serial, controls_execution_count = [], None, {}, 0, 0
    try:
        control_input = args.evidence / "fixed-control-input.json"
        write(control_input, {"proof_command": "lightweight-canonical-four-markets-three-arms-full9-v4-1"})
        args.timeout = 1800
        execution, output = linux.run_container(args, image_id, "controls", {"shape": "single", "scenario_paths": [str(control_input)]}, args.evidence / "controls", args.owner, "controls")
        args.timeout = 300
        controls_execution_count = 1
        if not execution["succeeded"]: raise ValueError("actual complete-market controls container failed")
        controls = validate_controls(output / "controls", plan)
        write(args.evidence / "CONTROL_RESULT.json", {"passed": True, "execution": execution, **controls})
        for stage, repeats in (("smoke", [0]), ("screen", [-1, 0, 1])):
            units = [SINGLES[0], SINGLES[1], BATCH] if stage == "smoke" else list(SINGLES) + [BATCH]
            for repeat in repeats:
                for index, unit in enumerate(units):
                    order = arm_order(index, repeat); group = {}
                    for arm in order:
                        serial += 1
                        folder = args.evidence / stage / ("warmup" if repeat < 0 else "repeat-" + str(repeat)) / unit / arm
                        row = run_one(args, image_id, arm, items[unit], folder, "%04d" % serial)
                        row.update(stage=stage, repeat=repeat, warmup=repeat < 0, order=order, timing_included=stage == "screen" and repeat >= 0)
                        rows.append(row); group[arm] = row; write(args.evidence / "RAW_RESULTS.json", rows)
                        if not row["passed"]: raise ValueError("actual diagnostic stopped at failed run")
                    for arm, row in group.items():
                        current = Path(row["output"]); previous = first.setdefault((stage, unit, arm), current)
                        row["same_round_pair"] = pair(current, Path(group["baseline"]["output"]), items[unit])
                        row["same_arm_repeat_pair"] = pair(current, previous, items[unit])
                        row["passed"] &= row["same_round_pair"]["passed"] and row["same_arm_repeat_pair"]["passed"]
                        write(current.parent / "RUN_RESULT.json", row); write(args.evidence / "RAW_RESULTS.json", rows)
                        if not row["passed"]: raise ValueError("actual pair/repeat output differs")
        for arm in ARMS:
            full = next(row for row in reversed(rows) if row["unit"] == BATCH and row["arm"] == arm)
            for sub in items[BATCH]["subs"]:
                serial += 1
                item = {"unit": BATCH + "/" + sub["sub"], "shape": "single", "subs": [],
                    "scenario_paths": [str(args.reference_root / BATCH / sub["scenario_file"])],
                    "isolated_reference": str(args.reference_root / BATCH / "checks/reference_data" / sub["sub"])}
                folder = args.evidence / "isolation" / arm / sub["sub"]
                row = run_one(args, image_id, arm, item, folder, "%04d" % serial, reference=False)
                row.update(stage="isolation", timing_included=False)
                row["isolation_pair"] = pair(Path(row["output"]), Path(full["output"]) / sub["sub"], item)
                row["passed"] &= row["isolation_pair"]["passed"]; rows.append(row)
                write(folder / "RUN_RESULT.json", row); write(args.evidence / "RAW_RESULTS.json", rows)
                if not row["passed"]: raise ValueError("actual original batch fresh isolation differs")
        for index, unit in enumerate(list(SINGLES) + [BATCH]):
            for canonical_arm in arm_order(index, 0):
                serial += 1
                diagnostic_arm = "diagnostic-" + canonical_arm
                item = items[unit]
                folder = args.evidence / "phase" / unit / canonical_arm
                row = run_one(args, image_id, diagnostic_arm, item, folder, "%04d" % serial)
                row.update(stage="phase", canonical_arm=canonical_arm, timing_included=False,
                           diagnostic_overhead_included=True)
                if row["passed"]:
                    row["finite_phase_diagnostics"] = validate_phases(row, plan, item, canonical_arm)
                    original = next(r for r in reversed(rows) if r["stage"] == "screen" and r["unit"] == unit and r["arm"] == canonical_arm)
                    row["uninstrumented_output_pair"] = pair(Path(row["output"]), Path(original["output"]), item)
                    row["passed"] &= row["uninstrumented_output_pair"]["passed"]
                rows.append(row)
                write(folder / "RUN_RESULT.json", row)
                write(args.evidence / "RAW_RESULTS.json", rows)
                if not row["passed"]:
                    raise ValueError("actual finite phases or uninstrumented output equivalence failed")
    except BaseException as error:
        failure = {"type": type(error).__name__, "message": str(error)}
    unchanged = all(sha(args.reference_root / item["unit"] / name) == value for item in roster["units"] for mapping in (item["input_sha256"], item["reference_sha256"]) for name, value in mapping.items())
    immutable = False
    try:
        after = linux.image_metadata(args, image_id, args.evidence / "image-after-screen")
        immutable = before["inspection"] == after["inspection"]
        verify_payload(PAYLOAD)
        if inventory(actual_installed) != expected_build["installed_files"]:
            raise ValueError("actual installed build sources changed during screen")
        if not immutable: raise ValueError("actual image inspection changed")
    except BaseException as error: failure = failure or {"type": type(error).__name__, "message": str(error)}
    measured = [row for row in rows if row.get("timing_included")]
    official = sum("developer_verifier" in row for row in rows)
    gates = sum(gate.get("passed") is True for row in rows for gate in (row.get("developer_verifier", {}).get("verdict") or {}).get("gate_results", {}).values())
    rates = []
    for index, unit in enumerate(list(SINGLES) + [BATCH]):
        a = [r for r in measured if r["arm"] == "baseline" and r["unit"] == unit and r["passed"]]
        b = [r for r in measured if r["arm"] == "new" and r["unit"] == unit and r["passed"]]
        if len(a) != 2 or len(b) != 2: continue
        if any(r["order"] != arm_order(index, r["repeat"]) for r in a + b): raise ValueError("actual measured order not balanced")
        base_time = statistics.median(r["settled_container_runtime_sec"] for r in a)
        new_time = statistics.median(r["settled_container_runtime_sec"] for r in b)
        rates.append({"unit": unit, "baseline_daemon_median_sec": base_time, "new_daemon_median_sec": new_time,
                      "actual_daemon_time_ratio": base_time / new_time})
    summary = {"schema": "t3-lightweight-canonical-market-diagnostic-screen-v4-1", "all_passed": failure is None and len(rows) == 56 and len(measured) == 20 and len([r for r in rows if r.get("stage") == "phase"]) == 10 and official == 46 and gates == 184 and all(row["passed"] for row in rows) and unchanged and immutable,
        "failure": failure, "ordinary_runs": len(rows), "planned_ordinary_runs": 56, "measured_runs": len(measured),
        "execution_containers": len(rows) + controls_execution_count, "planned_execution_containers": 57, "official_verifier_calls": official,
        "official_gate_passes": gates, "original_inputs_references_unchanged": unchanged, "image_unchanged": immutable,
        "per_unit_actual_daemon_times": rates, "five_unit_mean_actual_daemon_time_ratio": statistics.mean(row["actual_daemon_time_ratio"] for row in rates) if len(rates) == 5 else None,
        "benefit_evidence": "actual Docker StartedAt/FinishedAt durations only; five-unit diagnostic", "rankable": False,
        "diagnostic_only": True, "full71": False, "formal_repeats": False, "official_score": None, "submission_ready": False,
        "actual_entry_sources": plan["actual_entry_sources"], "heavy_witness_in_measured_production": False, "phase_runs": len([r for r in rows if r.get("stage") == "phase"]),
        "phase_timing_included": False, "planned_market_episodes": 108}
    write(args.evidence / "SUMMARY.json", summary)
    if not summary["all_passed"]: raise RuntimeError("actual lightweight canonical diagnostic incomplete or failed")


def archive(args):
    if args.artifact is None or args.artifact.exists(): raise ValueError("fresh artifact required")
    args.artifact.mkdir(parents=True)
    if args.evidence.exists(): shutil.copytree(args.evidence, args.artifact / "evidence", ignore=shutil.ignore_patterns("anonymous-docker-config"))
    shutil.copytree(PAYLOAD, args.artifact / "payload")
    write(args.artifact / "ARTIFACT.json", {"all_actual_output_bytes_retained": True, "files": inventory(args.artifact), "rankable": False})


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("stage", choices=("build", "screen", "artifact"))
    parser.add_argument("--evidence", type=Path, required=True); parser.add_argument("--reference-root", type=Path)
    parser.add_argument("--gate-kit", type=Path); parser.add_argument("--gate-python", default=sys.executable)
    parser.add_argument("--docker", default="docker"); parser.add_argument("--artifact", type=Path)
    parser.add_argument("--log-cap-bytes", type=int, default=4 * 1024 ** 2)
    args = parser.parse_args(); args.evidence = args.evidence.resolve(); args.evidence.mkdir(parents=True, exist_ok=True)
    signal.signal(signal.SIGINT, linux.cancellation); signal.signal(signal.SIGTERM, linux.cancellation)
    if args.stage == "artifact": archive(args); return
    try:
        plan = verify_payload(PAYLOAD)
        if plan["schema"] != "t3-lightweight-canonical-market-source-plan-v4-1" or plan["rankable"] is not False or plan["execution_containers"] != 57:
            raise ValueError("fixed source diagnostic plan required")
        if args.stage == "build": build(args, plan)
        else: screen(args, plan)
    except BaseException as error:
        write(args.evidence / "FAILURE_v1.json", {"type": type(error).__name__, "message": str(error), "rankable": False})
        raise

if __name__ == "__main__": main()
