"""Three actual-entry workers: original/new/new-repeat; full9 and24 Parquets."""
import argparse
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys
from common import SEMANTIC_ARMS, COLD_EMPTY, SEEDS, sha, write
HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok: raise ValueError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--new", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh actual complete market control output required")
    args.out.mkdir(parents=True)
    result = {"schema": "t3-lightweight-canonical-full-market-controls-v4-1", "all_passed": False, "arms": list(SEMANTIC_ARMS),
        "cases": [], "workers": {}, "failures": [], "rankable": False, "official_gate": False, "timing_claim": False,
        "source_mapping_sha256": sha(HERE / "semantic_mapping.py"), "source_worker_sha256": sha(HERE / "semantic_worker.py")}
    try:
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"): env[name] = "1"
        for arm in SEMANTIC_ARMS:
            runtime = (args.baseline if arm == "baseline" else args.new).resolve()
            with (args.out / (arm + ".log")).open("xb") as log:
                completed = subprocess.run([sys.executable, "-B", str(HERE / "semantic_worker.py"),
                    "--runtime", str(runtime), "--arm", arm, "--out", str((args.out / arm).resolve())],
                    env=env, stdout=log, stderr=subprocess.STDOUT, cwd=str(HERE), timeout=900)
            require(completed.returncode == 0, "actual complete market worker failed: " + arm)
            receipt = json.loads((args.out / arm / "WORKER_RECEIPT.json").read_text())
            require(receipt["schema"] == "t3-lightweight-canonical-market-semantic-worker-v4-1" and receipt["arm"] == arm
                    and receipt["market_records"] == 4 and receipt["retained_actual_parquets"] == 8
                    and receipt["nine_payload_components"] is True and receipt["rankable"] is False
                    and receipt["timing_claim"] is False and receipt["source_mapping_mode"] == "original_canonical"
                    and receipt["source_mapping_sha256"] == result["source_mapping_sha256"]
                    and receipt["source_worker_sha256"] == result["source_worker_sha256"]
                    and receipt["actual_entry_sha256"] == sha(runtime / "agent.py")
                    and receipt["values_sha256"] == sha(args.out / arm / "SEMANTIC_VALUES.pkl")
                    and [row["seed"] for row in receipt["cases"]] == list(SEEDS), "actual worker source/scope/data receipt differs")
            require(receipt["versions"] == {"numpy": "1.26.4", "pandas": "1.5.3", "pyarrow": "15.0.2"}, "actual pinned worker decode versions")
            if arm != "baseline":
                require(receipt["final_production_import_witness"] == {"production_attempts": [], "import_status": COLD_EMPTY,
                    "production_complete": True, "markets_completed": 4}, "actual four-market continuous cold witness absent")
            result["workers"][arm] = receipt
        # Only fresh source-owned local worker pickles enter this control process.
        # Independent root saved-artifact decode must treat these as inert data.
        import pandas as pd
        values = {arm: pickle.loads((args.out / arm / "SEMANTIC_VALUES.pkl").read_bytes()) for arm in SEMANTIC_ARMS}
        require(all(len(rows) == 4 for rows in values.values()), "four actual complete markets per arm required")
        parquet_pins = []
        for index, seed in enumerate(SEEDS):
            expected = values["baseline"][index]
            snapshots = {}
            for arm in SEMANTIC_ARMS:
                row = values[arm][index]; case = result["workers"][arm]["cases"][index]
                require(row["seed"] == seed and len(row["frames"]) == 2 and len(row["payload"]) == 9
                        and row["details"] == expected["details"] and case["details"] == row["details"], "actual full9/details roster differs")
                for a, b in zip(expected["frames"], row["frames"]):
                    pd.testing.assert_frame_equal(a, b, check_exact=True, check_dtype=True, rtol=0, atol=0)
                require(row["payload"] == expected["payload"], "complete9 actual business state/RNG/UID/alias/consumers differ")
                require(case["actual_run_calls"] == 1 and case["bindings_restored"] is True and case["observer_finished"] is True,
                        "actual entry rerun/binding/observer witness differs")
                require(case["raw_snapshot_before"] == case["raw_snapshot_after"] == case["raw_snapshot_final"]
                        and case["rng_before"] == case["rng_after"]
                        and case["local_rng_final"] == {k: case["rng_after"][k] for k in ("config", "kernel")}
                        and case["uids_before"] == case["uids_after"], "actual captured raw/RNG/UID data changed")
                snapshots[arm] = case["raw_snapshot_after"]
                owner = case["owner"]
                require(owner["arm"] == "original_canonical" and owner["original_has_no_scheduler"] is True
                        and owner["native_private_witness"] is None and owner["scheduler_owner_verified"] is False
                        and owner["ledger_rows"] > 0 and owner["end_state_aliases"] == [True, True, True]
                        and all(owner[key] is True for key in ("exact_kernel_heap_ledger_types", "heap_queue_original_list",
                            "columns_tuple_retained", "nine_distinct_exact_list_aliases", "all_agent_kernel_aliases")), "actual original owners/aliases not proved")
                if arm != "baseline":
                    witness = case["output_witness"]
                    require(case["production_attempts"] == [] and case["production_import_status"] == COLD_EMPTY
                            and witness["source_authenticated"] is True and witness["observer_admitted"] is True
                            and witness["projectors_admitted"] is True and witness["declines"] == {}
                            and witness["output_mode"] == "canonical-arrow-buffers" and witness["market_rerun"] is False,
                            "actual source/admitted/two-output cold path differs")
                else: require(case["output_witness"] is None, "baseline falsely carries candidate writer witness")
                for output_index, name in enumerate(("trace.parquet", "message_trace.parquet")):
                    path = args.out / arm / str(seed) / name
                    require(row["payload"][0][output_index] == path.read_bytes(), "actual retained production Parquet bytes differ")
                    parquet_pins.append({"arm": arm, "seed": seed, "path": name, "bytes": path.stat().st_size, "sha256": sha(path), "rows": len(row["frames"][output_index])})
                require(case["trace_rows"] == len(row["frames"][0]) and case["message_rows"] == len(row["frames"][1]), "actual paired row counts differ")
            require(all(snapshots["baseline"] == snapshots[a] for a in SEMANTIC_ARMS), "complete actual observer contract/inference/ledger/map/alias values differ")
            result["cases"].append({"seed": seed, "passed": True, "three_way_complete_equal": True,
                "trace_rows": len(expected["frames"][0]), "message_rows": len(expected["frames"][1]), "details": expected["details"]})
        require(len(parquet_pins) == 24, "exact24 actual production Parquets required")
        result.update(all_passed=True, market_records=12, retained_actual_parquets=24, worker_roots=3,
                      nine_payload_components=True, parquet_pins=parquet_pins, actual_both_candidate_workers_continuous_cold=True)
    except BaseException as error:
        result["failures"].append({"type": type(error).__name__, "message": str(error)})
    result["source_controller_sha256"] = sha(Path(__file__))
    write(args.out / "RESULT.json", result)
    return 0 if result["all_passed"] else 1

if __name__ == "__main__": raise SystemExit(main())
