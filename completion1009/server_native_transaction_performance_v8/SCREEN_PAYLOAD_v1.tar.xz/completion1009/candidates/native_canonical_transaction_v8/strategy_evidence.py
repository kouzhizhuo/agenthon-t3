"""Control-only complete graph retention and structured first difference."""
import hashlib
import json
from pathlib import Path

ROOT=None
LAST=None


def configure(root):
    global ROOT
    ROOT=Path(root)
    ROOT.mkdir(parents=True,exist_ok=False)


def begin(strategy,case):
    global LAST
    folder=ROOT/(strategy+"__"+str(case).replace("/","_"))
    folder.mkdir()
    LAST={"strategy":strategy,"case":case,"folder":str(folder),"arms":[],"arm_failures":[],"comparison":None}
    save()


def save():
    if ROOT is not None:
        (ROOT/"LATEST.json").write_text(json.dumps(LAST,indent=2,sort_keys=True,allow_nan=False)+"\n")


def retain_arm(native,graph,outcome=None):
    arm="actual_native" if native else "original_canonical"
    path=Path(LAST["folder"])/(arm+".json")
    data=(json.dumps({"arm":arm,"complete_graph":graph,"outcome":outcome},indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    path.write_bytes(data)
    LAST["arms"].append({"arm":arm,"path":str(path),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"complete_graph_available":True})
    save()


def arm_failure(native,error):
    arm="actual_native" if native else "original_canonical"
    failure={"arm":arm,"type":type(error).__module__+"."+type(error).__name__,"message":str(error)}
    LAST["arm_failures"].append(failure)
    path=Path(LAST["folder"])/(arm+"_failure.json")
    path.write_text(json.dumps(failure,indent=2,sort_keys=True,allow_nan=False)+"\n")
    if not any(row["arm"]==arm for row in LAST["arms"]):
        LAST["arms"].append({"arm":arm,"complete_graph_available":False,
            "unavailable_reason":"setup/operation/snapshot raised before complete graph retention",
            "failure_path":str(path)})
    save()


def first_diff(left,right,path=None):
    path=[] if path is None else path
    if type(left) is not type(right):return {"path":path,"kind":"type","original_type":type(left).__name__,"native_type":type(right).__name__,"original":left,"native":right}
    if type(left) in (list,tuple):
        if len(left)!=len(right):return {"path":path,"kind":"length","original_length":len(left),"native_length":len(right)}
        for index,(a,b) in enumerate(zip(left,right)):
            difference=first_diff(a,b,path+[index])
            if difference is not None:return difference
        return None
    if type(left) is dict:
        if list(left)!=list(right):return {"path":path,"kind":"keys","original_keys":list(left),"native_keys":list(right)}
        for key in left:
            difference=first_diff(left[key],right[key],path+[key])
            if difference is not None:return difference
        return None
    if left!=right:return {"path":path,"kind":"value","original":left,"native":right}
    return None


def compare(values,message):
    assert len(values)==2, "both arms must be attempted before comparison"
    difference=first_diff(values[0],values[1])
    complete=len(LAST["arms"])==2 and all(row["complete_graph_available"] for row in LAST["arms"])
    if difference is None and (not complete or LAST["arm_failures"]):
        difference={"path":[],"kind":"arm_failure","arm_failures":LAST["arm_failures"],
            "complete_graphs_retained":complete}
    LAST["comparison"]={"equal":difference is None,"first_diff":difference,
        "complete_graphs_retained":complete,"both_arms_attempted":True}
    (Path(LAST["folder"])/"COMPARISON.json").write_text(json.dumps(LAST["comparison"],indent=2,sort_keys=True,allow_nan=False)+"\n")
    save()
    if difference is not None:raise AssertionError(*message)
    return LAST["comparison"]


def failure(error):
    if LAST is None:
        return {"failure":{"type":type(error).__name__,"message":str(error)},"case_started":False}
    LAST["failure"]={"type":type(error).__name__,"message":str(error)}
    save()
    return dict(LAST)
