"""Future actual two-arm active/inactive quote and book logging controls."""


def run_all(engine,owner_probe,np):
    from abides_markets.orders import LimitOrder,Side
    import observer
    import original_canonical_engine
    from strategy_fixtures import setup,encode
    from strategy_graph import graph
    import strategy_evidence as evidence
    records=[]
    for active in (False,True):
        values=[]
        observed_arms=[]
        evidence.begin("BookObserver", "active_"+str(active))
        for native in (False,True):
            observer.finish_episode()
            if active:observer.begin_episode({"agent_configs":[{"agent_type":"NoiseTrader","count":1}]},authenticated=True)
            try:
                kernel,agent,bids,asks=setup("NoiseTrader","act_both",engine if native else original_canonical_engine,np,native)
                exchange=kernel.agents[0];book=exchange.order_books["ABM"]
                initial_rawlog=list(exchange.log)
                try:
                    book.handle_limit_order(LimitOrder(1,120,"ABM",3,Side.BID,99))
                    book.handle_limit_order(LimitOrder(1,120,"ABM",4,Side.ASK,101))
                    outcome=["returned",["NoneType",None]]
                except Exception as error:
                    outcome=["raised",type(error).__module__+"."+type(error).__name__,encode(error.args,np)]
                state={"observer":None if observer.STATE is None else vars(observer.STATE),
                    "booklog":book.book_log2,"rawlog":exchange.log,"ledger":kernel._msg_ledger.columns,
                    "book":book,"outcome":outcome}
                snapshot=graph(state,np)
                evidence.retain_arm(native,snapshot,outcome)
                values.append(snapshot)
                # Preserve actual observer while the other arm starts a new one.
                observed_arms.append((state,observer.STATE,exchange,initial_rawlog))
                if native:owner_probe.audit_transaction(kernel,exchange)
            except Exception as error:
                evidence.arm_failure(native,error)
                if len(values)<(2 if native else 1):values.append(None)
            finally:observer.finish_episode()
        comparison=evidence.compare(values,("BookObserver",active,"complete active/inactive quote/booklog differs"))
        # Expected result checks run only after both complete graphs and firstdiff
        # are written, so a narrow oracle failure cannot discard the other arm.
        for state,observed,exchange,initial_rawlog in observed_arms:
            assert state["outcome"]==["returned",["NoneType",None]],state["outcome"]
            booklog=state["booklog"]
            if active:
                assert observed.quote_rows==3
                rows=observed.contract[exchange]
                assert [row[2] for row in rows]==["quote"]*3
                assert [row[3] for row in rows]==[("ABM",99,3),("ABM",99,3),("ABM",101,4)]
                assert all(type(row["bids"]) is list and type(row["asks"]) is list for row in booklog)
                assert booklog[-1]["bids"]==[None] and booklog[-1]["asks"]==[None]
            else:
                assert observed is None
                assert all(type(row["bids"]) is np.ndarray and type(row["asks"]) is np.ndarray for row in booklog)
                assert booklog[-1]["bids"].tolist()==[[99,3]] and booklog[-1]["asks"].tolist()==[[101,4]]
                assert [row[1] for row in initial_rawlog]==["AGENT_TYPE"]
                assert state["rawlog"][:len(initial_rawlog)]==initial_rawlog
                assert [row[1] for row in state["rawlog"][len(initial_rawlog):]]==["BEST_BID","BEST_BID","BEST_ASK"]
        records.append({"active":active,"passed":True,"arm_records":2,"complete_graph_equal":comparison["equal"],
            "quote_rows_checked":3 if active else 0,"book_logging_checked":True})
    return {"schema":"t3-native-v8-book-observer-controls-v1","all_passed":True,"cases":records,"arm_records":4,
        "active_inactive_quote_and_booklog_checked":True,"timing_claim":False,"rankable":False}
