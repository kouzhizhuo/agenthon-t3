"""Future eight fresh V2 deployment/JSON/preinitialize controls, never markets."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
CASES = (
    "normal_deploy_bound_native_active_before_initialize",
    "unsupported_JSON_original_before_configuration",
    "structural_owner_decline_before_initialize",
    "installation_exception_restores_all_bindings",
    "fixed_native_loader_loads_once",
    "missing_external_authority_refused_before_configuration",
    "mismatched_external_authority_refused_before_configuration",
    "production_does_not_enter_research_source_authentication",
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scenario():
    return {"scenario_id": "transaction_v3_admission_fixture", "seed": 17,
            "horizon_ns": 1000, "exchange_config": {},
            "oracle_config": {"params": {}}, "latency_config": {"params": {}},
            "agent_configs": [{"agent_type": "NoiseTrader", "count": 1, "params": {}}]}


def child_control(case, runtime):
    if case not in CASES:
        raise ValueError("unknown V2 admission case")
    sys.path.insert(0, str(runtime.resolve()))
    from bootstrap import activate
    activate()
    import numpy as np
    import observer
    from abides_core import abides
    from abides_core.kernel import Kernel
    from abides_fork.config import build_config, ScenarioLatencyModel
    from abides_fork import trace
    from abides_markets.agents import exchange_agent
    from transaction_installation import enabled
    import transaction_loader as loader
    from owner_probe_loader import load_owner_probe
    assert loader._module is None and loader._load_count == 0
    old_kernel, old_book, old_latency = abides.Kernel, exchange_agent.OrderBook, ScenarioLatencyModel.get_latency
    authority_path = HERE / "DEPLOYMENT_AUTHORITY.json"
    saved_authority = authority_path.read_bytes()
    old_loader_here = loader.HERE
    invalid_deployment_copy = None
    value = scenario()
    configured = False
    body_entered = False
    source_calls = []

    def forbidden(*args, **kwargs):
        source_calls.append("research_source_authentication")
        raise AssertionError("production must not enter research source authentication")

    def restored():
        assert abides.Kernel is old_kernel and exchange_agent.OrderBook is old_book
        assert ScenarioLatencyModel.get_latency is old_latency

    try:
        if case.startswith(("missing_external", "mismatched_external")):
            # Refusal fixture uses copied real deployment bytes in a temporary
            # candidate of the same name. The actual read-only image/marker is
            # never edited, and no fake successful native module is imported.
            invalid_deployment_copy = TemporaryDirectory(prefix="t3-v3-invalid-authority-")
            invalid = Path(invalid_deployment_copy.name) / HERE.name
            (invalid / "native").mkdir(parents=True)
            shutil.copyfile(HERE / "DEPLOYMENT.json", invalid / "DEPLOYMENT.json")
            deployment = json.loads((HERE / "DEPLOYMENT.json").read_text())
            shutil.copyfile(HERE / deployment["extension_path"], invalid / deployment["extension_path"])
            if case.startswith("mismatched"):
                changed = json.loads(saved_authority)
                changed["extension_sha256"] = "0" * 64
                (invalid / "DEPLOYMENT_AUTHORITY.json").write_text(json.dumps(changed, indent=2, sort_keys=True) + "\n")
            loader.HERE = invalid
        elif case == "unsupported_JSON_original_before_configuration":
            value["agent_configs"][0]["agent_type"] = "UnknownProducer"
        elif case == "production_does_not_enter_research_source_authentication":
            assert "proof_authentication" not in sys.modules and "host_proof" not in sys.modules
            # Deliberately failing research oracle; it is not a counterfeit
            # successful native module and must never be called by production.
            sys.modules["proof_authentication"] = SimpleNamespace(authenticate_runtime=forbidden)

        if case.startswith(("missing_external", "mismatched_external")):
            try:
                with enabled(value, "actual_native"):
                    body_entered = True
            except ValueError as error:
                expected = "authority missing" if case.startswith("missing") else "authority differs"
                assert expected in str(error)
            else:
                raise AssertionError("invalid external authority was accepted")
            assert body_entered is False and loader._module is None and loader._load_count == 0
            assert "native_canonical_transaction" not in sys.modules
            restored()
        elif case == "installation_exception_restores_all_bindings":
            class BodyFailure(BaseException):
                pass
            try:
                with enabled(value, "actual_native") as installed:
                    body_entered = True
                    assert installed["native_active"] is True
                    raise BodyFailure("transaction V3 context body failed", 17)
            except BodyFailure as error:
                assert error.args == ("transaction V3 context body failed", 17)
            else:
                raise AssertionError("installation body failure missing")
            restored()
        else:
            with enabled(value, "actual_native") as installed:
                body_entered = True
                assert installed["per_episode_source_hashes"] == 0
                assert installed["per_episode_original_source_compilations"] == 0
                observer.begin_episode(value, authenticated=installed["observer_authenticated"])
                if case == "unsupported_JSON_original_before_configuration":
                    assert installed["native_active"] is False and installed["fallback_before_configuration"] is True
                    assert installed["installed_engine"] == "original_incumbent"
                    assert installed["deployment_authority"] is None
                    assert installed["observer_authenticated"] is False and observer.STATE is None
                    assert installed["extractor"] is trace.extract_message_trace
                    assert loader._module is None and loader._load_count == 0
                    restored()
                else:
                    engine = loader.load_transaction()
                    receipt = loader.native_receipt()
                    assert installed["native_active"] is True and installed["fallback_before_configuration"] is False
                    assert observer.STATE is not None
                    assert installed["deployment_authority"]["audit_all_passed"] is True
                    assert installed["deployment_authority"]["proof_report_sha256"] == sha(HERE / "DEPLOYMENT_PROOF.json")
                    assert receipt["native_load_count"] == 1
                    if case == "fixed_native_loader_loads_once":
                        assert loader.load_transaction() is engine and loader.load_transaction() is engine
                        assert loader.native_receipt() == receipt
                    else:
                        config = build_config(value)
                        configured = True
                        keys = ("start_time", "stop_time", "agents", "agent_latency_model",
                                "default_computation_delay", "custom_properties")
                        kwargs = {key: config[key] for key in keys if key in config}
                        if case == "structural_owner_decline_before_initialize":
                            config["agents"][0].receive_message = forbidden
                            try:
                                abides.Kernel(random_state=np.random.RandomState(31), **kwargs)
                            except ValueError as error:
                                assert "instance callable overrides" in str(error)
                            else:
                                raise AssertionError("structural owner override accepted before initialize")
                        else:
                            kernel = abides.Kernel(random_state=np.random.RandomState(31), **kwargs)
                            assert isinstance(kernel, engine.CanonicalKernel)
                            assert all(a.kernel is None for a in config["agents"])
                            assert kernel.initialize.__func__ is Kernel.initialize
                            witness = load_owner_probe(engine).audit_transaction(kernel, config["agents"][0])
                            assert witness["same_extension_book_level_scheduler"] is True
                            assert witness["nine_original_column_list_aliases"] is True
                            assert all(row["same_scheduler"] and row["raw_owner"] for row in witness["books"])
                    assert loader.native_receipt() == receipt
            restored()
        assert not source_calls
        if case != "production_does_not_enter_research_source_authentication":
            assert "proof_authentication" not in sys.modules
        assert "host_proof" not in sys.modules
        return {"case": case, "passed": True, "fresh_process": True,
                "configuration_constructed": configured, "context_body_entered": body_entered,
                "market_initialized": False, "market_executed": False,
                "native_active_checked": True, "deployment_authority_required_checked": True,
                "bindings_restored": True, "production_research_authentication_calls": 0,
                "per_episode_source_hashes": 0, "per_episode_original_source_compilations": 0,
                "external_authority_sha256": hashlib.sha256(saved_authority).hexdigest()}
    finally:
        observer.finish_episode()
        loader.HERE = old_loader_here
        assert authority_path.read_bytes() == saved_authority
        if invalid_deployment_copy is not None:
            invalid_deployment_copy.cleanup()
        if case == "production_does_not_enter_research_source_authentication":
            sys.modules.pop("proof_authentication", None)


def run_all(runtime):
    result = []
    source_digest = sha(__file__)
    for case in CASES:
        with TemporaryDirectory(prefix="t3-transaction-v8-admission-") as directory:
            output = Path(directory) / "RESULT.json"
            argv = [sys.executable, "-B", str(Path(__file__).resolve()), "--child", case,
                    "--runtime", str(runtime.resolve()), "--out", str(output)]
            completed = subprocess.run(argv, capture_output=True, text=True, timeout=60)
            if completed.returncode != 0:
                raise AssertionError("V2 admission child failed: " + case + ": " + completed.stderr[-4000:])
            assert completed.stdout == "" and output.is_file()
            report = json.loads(output.read_text())
            assert report["schema"] == "t3-native-transaction-admission-child-v8"
            assert report["source_sha256"] == source_digest
            witness = report["witness"]
            assert witness["case"] == case and witness["passed"] is True
            assert witness["market_initialized"] is False and witness["market_executed"] is False
            result.append(witness)
    assert sha(__file__) == source_digest
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", choices=CASES, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("fresh V2 admission result required")
    digest = sha(__file__)
    witness = child_control(args.child, args.runtime)
    assert sha(__file__) == digest
    report = {"schema": "t3-native-transaction-admission-child-v8", "source_sha256": digest,
              "witness": witness, "rankable": False, "timing_claim": False}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
