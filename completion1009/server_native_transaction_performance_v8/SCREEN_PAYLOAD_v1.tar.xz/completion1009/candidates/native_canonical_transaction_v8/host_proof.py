"""Future unranked build/host source/ELF/code audit in its own process.

Source preparation only AST-parses this file. An actual passing report requires
running this command against the real built deployment. No market executes here.
"""
import argparse
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import sys

from provenance import HERE, abi, dependencies, sha, verify_runtime, verify_sources

BINDINGS = ("candidate", "abi", "extension_path", "extension_sha256", "extension_bytes",
            "build_receipt_sha256", "source_receipt_sha256", "runtime_pins_sha256",
            "compile_spec_sha256", "control_probe_source_sha256", "control_probe")


def exact_file(path, row):
    if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
        raise ValueError("transaction actual deployed file differs: " + str(path))


def audit(runtime):
    if "native_canonical_transaction" in sys.modules:
        raise ValueError("fresh independent proof process required")
    sources = verify_sources()
    runtime_before = verify_runtime(runtime)
    spec = json.loads((HERE / "compile_spec.json").read_text())
    deployment = json.loads((HERE / "DEPLOYMENT.json").read_text())
    build_path = HERE / "BUILD_RECEIPT.json"
    build = json.loads(build_path.read_text())
    installed = dependencies(spec)
    if (deployment.get("schema") != "t3-native-canonical-transaction-deployment-v8"
            or build.get("schema") != "t3-native-canonical-transaction-build-v8"
            or deployment.get("candidate") != HERE.name or build.get("candidate") != HERE.name
            or deployment.get("abi") != abi() or build.get("abi") != abi()
            or build.get("build_succeeded") is not True
            or build.get("candidate_sources") != sources or build.get("runtime") != runtime_before
            or build.get("dependencies") != installed
            or build.get("source_receipt_sha256") != sha(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json")
            or deployment.get("source_receipt_sha256") != build["source_receipt_sha256"]
            or deployment.get("build_receipt_sha256") != sha(build_path)
            or deployment.get("runtime_pins_sha256") != runtime_before["runtime_pins_sha256"]
            or deployment.get("compile_spec_sha256") != sha(HERE / "compile_spec.json")
            or build.get("compile_spec_sha256") != deployment["compile_spec_sha256"]
            or build.get("compile_flags") != spec["compile_flags"] or build.get("directives") != spec["directives"]
            or build.get("extension_build_count") != 2 or build.get("build_invocations") != 1
            or build.get("production_extension_owners") != 1 or build.get("control_probe_extensions") != 1):
        raise ValueError("transaction actual build/source/runtime/ABI binding differs")
    extension = HERE / "native" / ("native_canonical_transaction" + abi()["ext_suffix"])
    probe = HERE / "native" / ("transaction_owner_probe" + abi()["ext_suffix"])
    if (deployment["extension_path"] != str(extension.relative_to(HERE))
            or deployment["control_probe"]["path"] != str(probe.relative_to(HERE))
            or deployment["control_probe"].get("control_only") is not True
            or build["extension"]["path"] != str(extension.relative_to(HERE))
            or build["control_probe"]["path"] != str(probe.relative_to(HERE))):
        raise ValueError("transaction actual extension/probe path differs")
    exact_file(extension, {"bytes": deployment["extension_bytes"], "sha256": deployment["extension_sha256"]})
    exact_file(extension, build["extension"])
    exact_file(probe, deployment["control_probe"])
    exact_file(probe, build["control_probe"])
    for filename, key in (("native_canonical_transaction.pyx", "pyx_sha256"),
                          ("native_canonical_transaction.pxd", "pxd_sha256"),
                          ("transaction_owner_probe.pyx", "control_probe_source_sha256")):
        digest = sha(HERE / filename)
        if digest != deployment.get(key) or digest != build.get(key):
            raise ValueError("transaction actual compiled-source binding differs")
    sys.path.insert(0, str(runtime.resolve()))
    from bootstrap import activate
    activate()
    name = "native_canonical_transaction"
    native_spec = importlib.util.spec_from_file_location(name, extension)
    if native_spec is None or not isinstance(native_spec.loader, importlib.machinery.ExtensionFileLoader):
        raise ValueError("transaction proof requires actual ExtensionFileLoader")
    module = importlib.util.module_from_spec(native_spec)
    sys.modules[name] = module
    try:
        native_spec.loader.exec_module(module)
        if Path(module.__file__).resolve() != extension.resolve():
            raise ValueError("transaction actual native origin differs")
        from proof_authentication import authenticate_runtime, RUNTIME
        if runtime.resolve() != RUNTIME.resolve():
            raise ValueError("transaction external fixed runtime path differs")
        authentication = authenticate_runtime(module)
        if (authentication["runtime_source_files_hashed"] != 64
                or authentication["original_source_modules_compiled_for_code_tokens"] != 28
                or authentication["source_functions_authenticated"] != 231
                or authentication["runtime_native_compilation"] is not False):
            raise ValueError("transaction actual source/code ownership proof incomplete")
        from abides_core.kernel import Kernel
        from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
        from abides_markets.agents.trading_agent import TradingAgent
        if (module.CanonicalKernel.initialize is not Kernel.initialize
                or module.CanonicalKernel.terminate is not Kernel.terminate
                or module.CanonicalKernel.run is not Kernel.run
                or not all(isinstance(getattr(module, field), type) for field in
                           ("NativeBook", "NativeLevel", "CanonicalScheduler", "ColumnLedger"))):
            raise ValueError("transaction actual native API owner proof differs")
        if (module.TradingAgent is not TradingAgent
                or any(getattr(module, cls.__name__) is not cls for cls in
                       (NoiseTrader, MarketMaker, ValueTrader, MomentumTrader))
                or module.DEFAULT_CANCEL_TAG is not TradingAgent.cancel_order.__defaults__[0]
                or module.DEFAULT_CANCEL_METADATA is not TradingAgent.cancel_order.__defaults__[1]):
            raise ValueError("transaction V3 original raw strategy/default owner differs")
        if "transaction_owner_probe" in sys.modules or "transaction_loader" in sys.modules:
            raise ValueError("transaction proof unexpectedly entered production/probe loader")
    finally:
        sys.modules.pop(name, None)
    if verify_sources() != sources or verify_runtime(runtime) != runtime_before:
        raise ValueError("transaction source/runtime changed during actual proof")
    exact_file(extension, build["extension"])
    exact_file(probe, build["control_probe"])
    return {"schema": "t3-native-transaction-deployment-proof-v8", "audit_all_passed": True,
            "actual_external_audit_executed": True, "candidate": HERE.name,
            "deployment_sha256": sha(HERE / "DEPLOYMENT.json"),
            "bindings": {key: deployment[key] for key in BINDINGS},
            "candidate_sources": sources, "runtime": runtime_before,
            "dependencies": installed, "source_authentication": authentication,
            "actual_extension_loader": type(native_spec.loader).__name__,
            "fixed_source_import_ownership_checked": True, "actual_native_API_owners_checked": True,
            "source_ELF_before_after_equal": True, "market_initialized": False, "market_executed": False,
            "compiled_original_code_objects_executed": False, "runtime_native_compilation": False,
            "network_used": False, "timing_claim": False, "rankable": False,
            "authority_scope": "fixed packaged ordinary JSON runtime; no arbitrary monkeypatch guarantee"}


def authority(proof, proof_digest):
    return {"schema": "t3-native-transaction-external-authority-v8", "audit_all_passed": True,
            **proof["bindings"], "proof_report_sha256": proof_digest,
            "runtime_source_files_verified": proof["runtime"]["files"],
            "ordinary_original_source_modules_authenticated": proof["source_authentication"][
                "original_source_modules_compiled_for_code_tokens"],
            "authority_scope": proof["authority_scope"], "market_executed": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("create", "verify"), required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("fresh actual host audit output required")
    proof_path, authority_path = HERE / "DEPLOYMENT_PROOF.json", HERE / "DEPLOYMENT_AUTHORITY.json"
    if args.mode == "create" and (proof_path.exists() or authority_path.exists()):
        raise ValueError("preserve existing deployment proof/authority")
    report = {"schema": "t3-native-transaction-host-audit-result-v8", "mode": args.mode,
              "audit_all_passed": False, "rankable": False, "timing_claim": False}
    try:
        proof = audit(args.runtime.resolve())
        if args.mode == "create":
            proof_path.write_text(json.dumps(proof, indent=2, sort_keys=True) + "\n")
            value = authority(proof, sha(proof_path))
            authority_path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        else:
            saved = json.loads(proof_path.read_text())
            value = json.loads(authority_path.read_text())
            if saved != proof or value != authority(saved, sha(proof_path)):
                raise ValueError("transaction actual host/deployment proof/authority bytes differ")
        report.update(audit_all_passed=True, proof=proof,
                      deployment_proof_sha256=sha(proof_path), authority_sha256=sha(authority_path),
                      deployment_authority=value)
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
