"""Require one fixed compiled owner. Source/hash audit belongs to external proof.

Loading and module initialization stay inside the host/CLI clocks. This loader
never compiles source and does no per-episode source or extension hashing.
"""
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import platform
import sys
import sysconfig

HERE = Path(__file__).resolve().parent
_module = None
_receipt = None
_load_count = 0


def deployment_authority(deployment):
    """One-time marker/envelope check; actual bytes belong to external proof.

    This function does not hash source/ELF or compile original code. The host
    audits the actual read-only image including this marker before promotion.
    """
    path = HERE / "DEPLOYMENT_AUTHORITY.json"
    if not path.is_file():
        raise ValueError("transaction external deployment authority missing")
    value = json.loads(path.read_text())
    bindings = ("candidate", "abi", "extension_path", "extension_sha256", "extension_bytes",
                "build_receipt_sha256", "source_receipt_sha256", "runtime_pins_sha256",
                "compile_spec_sha256", "control_probe_source_sha256")
    if (value.get("schema") != "t3-native-transaction-external-authority-v8"
            or value.get("audit_all_passed") is not True
            or any(value.get(key) != deployment.get(key) for key in bindings)
            or value.get("control_probe") != deployment.get("control_probe")
            or value.get("runtime_source_files_verified") != 64
            or value.get("ordinary_original_source_modules_authenticated") != 28
            or type(value.get("proof_report_sha256")) is not str
            or len(value["proof_report_sha256"]) != 64
            or any(c not in "0123456789abcdef" for c in value["proof_report_sha256"])):
        raise ValueError("transaction external deployment authority differs")
    return value


def load_transaction():
    global _module, _receipt, _load_count
    if _module is not None:
        return _module
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    if (sys.implementation.name != "cpython" or list(sys.version_info[:3]) != [3, 11, 17]
            or sys.platform != "linux" or platform.machine() != "x86_64"
            or sys.byteorder != "little" or sys.maxsize <= 2**32 or not suffix):
        raise ValueError("scheduler requires pinned Linux x86_64 CPython 3.11.17")
    name = "native_canonical_transaction"
    extension = HERE / "native" / (name + suffix)
    deployment = json.loads((HERE / "DEPLOYMENT.json").read_text())
    expected_abi = {"implementation": sys.implementation.name,
        "version": list(sys.version_info[:3]), "cache_tag": sys.implementation.cache_tag,
        "soabi": sysconfig.get_config_var("SOABI"), "ext_suffix": suffix,
        "platform": sys.platform, "machine": platform.machine(),
        "byteorder": sys.byteorder, "pointer_bits": 64}
    if (deployment.get("schema") != "t3-native-canonical-transaction-deployment-v8"
            or deployment.get("candidate") != HERE.name or deployment.get("abi") != expected_abi
            or deployment.get("extension_path") != "native/" + extension.name
            or not extension.is_file() or name in sys.modules):
        raise ValueError("scheduler deployment/ABI/fresh native owner differs")
    authority = deployment_authority(deployment)
    spec = importlib.util.spec_from_file_location(name, extension)
    if spec is None or not isinstance(spec.loader, importlib.machinery.ExtensionFileLoader):
        raise ValueError("scheduler requires an actual compiled extension")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
        from abides_core.kernel import Kernel
        from abides_core.message import Message, MessageBatch, WakeupMsg
        from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
        from abides_markets.agents.trading_agent import TradingAgent
        if (Path(module.__file__).resolve() != extension.resolve()
                or module.IncumbentKernel is not Kernel or module.Message is not Message
                or module.MessageBatch is not MessageBatch or module.WakeupMsg is not WakeupMsg
                or not isinstance(module.CanonicalKernel, type)
                or not issubclass(module.CanonicalKernel, Kernel)
                or module.CanonicalKernel.initialize is not Kernel.initialize
                or module.CanonicalKernel.terminate is not Kernel.terminate
                or module.CanonicalKernel.run is not Kernel.run
                or not isinstance(module.ColumnLedger, type)
                or not isinstance(module.CanonicalScheduler, type)):
            raise ValueError("scheduler native API or incumbent ownership differs")
        if (module.TradingAgent is not TradingAgent
                or any(getattr(module, cls.__name__) is not cls for cls in
                       (NoiseTrader, MarketMaker, ValueTrader, MomentumTrader))
                or module.DEFAULT_CANCEL_TAG is not TradingAgent.cancel_order.__defaults__[0]
                or module.DEFAULT_CANCEL_METADATA is not TradingAgent.cancel_order.__defaults__[1]):
            raise ValueError("transaction V3 raw strategy/default owner differs")
    except BaseException:
        sys.modules.pop(name, None)
        raise
    _module = module
    _load_count += 1
    _receipt = {"extension_path": str(extension), "extension_sha256": deployment["extension_sha256"],
        "build_receipt_sha256": deployment["build_receipt_sha256"],
        "source_receipt_sha256": deployment["source_receipt_sha256"],
        "runtime_pins_sha256": deployment["runtime_pins_sha256"], "abi": deployment["abi"],
        "runtime_provenance": "external_build_and_host_receipt",
        "deployment_authority": authority,
        "loader_source_compilation": False, "runtime_native_compilation": False,
        "per_episode_native_hash_audit": False}
    return _module


def native_receipt():
    if _receipt is None:
        raise ValueError("scheduler native owner has not been loaded")
    # Nested authority dictionaries belong to the fixed loader cache. Exposing
    # them directly lets a control mutate future episode receipts accidentally.
    return dict(json.loads(json.dumps(_receipt)), native_load_count=_load_count)
