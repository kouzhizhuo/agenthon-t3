"""Bounded actual host commands; retained results including failures."""
import json
from pathlib import Path
import subprocess
import time
from common import sha, write

def call(args, command, label, seconds=60, allow_failure=False):
    path = args.evidence / (label + ".log")
    started = time.monotonic()
    result = None
    failure = None
    timed_out = False
    with path.open("xb") as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=seconds)
        except subprocess.TimeoutExpired as error:
            timed_out = True
            failure = {"type": type(error).__name__, "message": str(error)}
        except OSError as error:
            failure = {"type": type(error).__name__, "message": str(error)}
    record = {"command": command, "returncode": None if result is None else result.returncode,
              "timed_out": timed_out, "failure": failure, "host_elapsed_sec": time.monotonic() - started,
              "log": {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}}
    write(args.evidence / (label + ".json"), record)
    if (result is None or result.returncode) and not allow_failure:
        raise RuntimeError("actual bounded command failed: " + label)
    return record


def inspect(args, name, label):
    call(args, [args.docker, "inspect", name], label)
    value = json.loads((args.evidence / (label + ".log")).read_text())
    if type(value) is not list or len(value) != 1:
        raise ValueError("one actual inspected object required")
    return value[0]


