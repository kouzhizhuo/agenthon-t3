"""Measured path: execute actual packaged CLI main without research diagnostics."""
import os
from pathlib import Path
import runpy
import sys

ROOT = Path("/opt/native-transaction-performance")
CANDIDATE = ROOT / "completion1009/candidates/native_canonical_transaction_v8"
RUNTIME = ROOT / "completion1009/candidates/lean_production_native_projection_v1/runtime"


def actual_argv():
    value = sys.argv[1:]
    if value not in (["simulate", "--config", "/input/scenario.json", "--out", "/output/trace.parquet"],
                     ["simulate-batch", "--batch-dir", "/input/scenarios", "--out-dir", "/output"]):
        raise ValueError("exact official production CLI arguments required")
    arm = os.environ.get("T3_TRANSACTION_CONTROL_ARM")
    if arm not in ("original_canonical", "actual_native"):
        raise ValueError("fixed comparison arm required")
    return value, arm


def main():
    value, arm = actual_argv()
    sys.path.insert(0, str(CANDIDATE)); sys.path.insert(0, str(RUNTIME))
    if arm == "original_canonical":
        sys.argv += ["--arm", arm]
    # Actual parser/entry; no wrapper receipt hashes, profiling, hook,
    # extra witness or probe calls in the measured process.
    runpy.run_path(str(CANDIDATE / "production_cli.py"), run_name="__main__")


if __name__ == "__main__": main()
