"""Actual bounded serial Docker execution with failure evidence and final absence."""
import json
from pathlib import Path
import uuid
from common import BASE, CANDIDATE, ENTRYPOINT, sha, write, inventory


def cleanup(args, name, label, call):
    removal = call(args, [args.docker, "rm", "-f", name], label + "-remove", allow_failure=True)
    absent = call(args, [args.docker, "inspect", name], label + "-absent", allow_failure=True)
    text = (args.evidence / (label + "-absent.log")).read_text()
    result = {"name": name, "remove": removal, "final_inspect": absent,
              "settled": removal["returncode"] == 0 and absent["returncode"] == 1
                  and absent["timed_out"] is False and absent["failure"] is None
                  and ("No such object: " + name in text or "No such container: " + name in text),
              "rankable": False}
    write(args.evidence / (label + "-cleanup.json"), result)
    return result


def resources(raw, inputs, outputs, command, entrypoint=ENTRYPOINT):
    host, cfg = raw["HostConfig"], raw["Config"]
    if (cfg["Entrypoint"] != entrypoint or cfg["Cmd"] != command or cfg["User"] != "65534:65534"
            or cfg["WorkingDir"] != "/output" or host["NetworkMode"] != "none"
            or host["ReadonlyRootfs"] is not True or host["NanoCpus"] != 4000000000
            or host["Memory"] != 16 * 1024 ** 3 or host["MemorySwap"] != 16 * 1024 ** 3
            or host.get("PidsLimit") != 256 or host.get("CapDrop") != ["ALL"]
            or not any(v in ("no-new-privileges", "no-new-privileges:true") for v in host.get("SecurityOpt", []))
            or host.get("Tmpfs", {}).get("/tmp") != "rw,noexec,nosuid,nodev,size=64m"):
        raise ValueError("actual fixed execution resources/CLI envelope differs")
    limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in host.get("Ulimits", [])}
    binds = [m for m in raw["Mounts"] if m.get("Type") == "bind"]
    if (limits != {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}
            or len(binds) != 2 or {m["Destination"]: (m["RW"], m["Source"]) for m in binds}
               != {"/input": (False, str(inputs.resolve())), "/output": (True, str(outputs.resolve()))}):
        raise ValueError("actual fixed execution limits/mounts differ")


def run_container(args, image, inputs, outputs, command, label, call, inspect, arm=None, seconds=300, diagnostic=False):
    name = "t3-native-performance-v8-" + label + "-" + uuid.uuid4().hex
    error = None
    before = after = attach = None
    prior_inputs = inventory(inputs)
    effective_entrypoint = ["/usr/local/bin/python"] if diagnostic else ENTRYPOINT
    effective_command = ["-B", "/opt/native-transaction-performance/control/phase_entry.py", *command] if diagnostic else command
    create = [args.docker, "create", "--name", name, "--cpus", "4", "--memory", "16g", "--memory-swap", "16g",
        "--network", "none", "--read-only", "--user", "65534:65534", "--pids-limit", "256",
        "--ulimit", "nofile=1024:1024", "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456",
        "--security-opt", "no-new-privileges", "--cap-drop", "ALL", "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m",
        "--mount", "type=bind,src=" + str(inputs.resolve()) + ",dst=/input,readonly",
        "--mount", "type=bind,src=" + str(outputs.resolve()) + ",dst=/output"]
    if arm is not None:
        create += ["--env", "T3_TRANSACTION_CONTROL_ARM=" + arm]
    if diagnostic:
        create += ["--entrypoint", effective_entrypoint[0]]
    create += [image, *effective_command]
    record = {"schema": "t3-native-transaction-v8-performance-container-execution-v1", "name": name,
        "command": effective_command, "official_argv": command, "diagnostic": diagnostic, "arm": arm, "input": str(inputs.resolve()), "output": str(outputs.resolve()),
        "input_inventory_before": prior_inputs, "all_passed": False, "timing_executed": False, "rankable": False}
    try:
        created = call(args, create, label + "-create", allow_failure=True)
        record["create"] = created
        if created["returncode"] != 0 or created["timed_out"] or created["failure"] is not None:
            raise RuntimeError("actual bounded container create failed: " + label)
        before = inspect(args, name, label + "-inspect-before")
        record["inspect_before"] = before
        if before.get("Image") != image:
            raise ValueError("actual container did not use the bound immutable image")
        resources(before, inputs, outputs, effective_command, effective_entrypoint)
        attach = call(args, [args.docker, "start", "-a", name], label + "-run", seconds, allow_failure=True)
        record["attach"] = attach
        if attach["returncode"] != 0 or attach["timed_out"] or attach["failure"] is not None:
            raise RuntimeError("actual native control/CLI process failed: " + label)
    except BaseException as failure:
        error = failure
        record["failure"] = {"type": type(failure).__name__, "message": str(failure)}
    finally:
        # Inspect before removal even after attach failure or timeout. Preserve
        # the terminal/running/OOM evidence as data rather than inventing PASS.
        try:
            after = inspect(args, name, label + "-inspect-after")
            record["inspect_after"] = after
            if after.get("Image") != image or before is not None and after.get("Id") != before.get("Id"):
                raise ValueError("actual after inspection image/container binding differs")
            resources(after, inputs, outputs, effective_command, effective_entrypoint)
            if (after["State"]["ExitCode"] != 0 or after["State"].get("OOMKilled") is not False
                    or after["State"].get("Running") is not False):
                raise ValueError("actual completed process failed/OOM/still running")
        except BaseException as failure:
            record["final_inspection_failure"] = {"type": type(failure).__name__, "message": str(failure)}
            if error is None:
                error = failure
        try:
            settled = cleanup(args, name, label, call)
            record["cleanup"] = settled
            record["input_inventory_after"] = inventory(inputs)
            if record["input_inventory_after"] != prior_inputs or settled["settled"] is not True:
                raise ValueError("actual input changed or cleanup did not settle")
        except BaseException as failure:
            record["cleanup_or_input_failure"] = {"type": type(failure).__name__, "message": str(failure)}
            if error is None:
                error = failure
        record["all_passed"] = error is None
        write(args.evidence / (label + "-EXECUTION.json"), record)
    if error is not None:
        raise error
    return record

