"""Five-unit native V8 actual CLI daemon-time protocol; no ranking claim."""
import argparse
import calendar
from datetime import datetime
import json
import math
from pathlib import Path
import platform
import shutil
import statistics
import sys
from common import ARMS, SINGLES, BATCH, WARMUPS, MEASURED_REPEATS, CANDIDATE, SOURCE_RECEIPT_SHA256, arm_order, inventory, sha, write, verify_payload
from commands import call, inspect
from build import build
from execution import run_container

PAYLOAD = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public


def daemon_seconds(state):
    def ns(value):
        raw = value.removesuffix("Z")
        base, dot, fraction = raw.partition(".")
        if dot and (not fraction.isdigit() or len(fraction) > 9):
            raise ValueError("actual daemon timestamp fraction differs")
        return calendar.timegm(datetime.strptime(base, "%Y-%m-%dT%H:%M:%S").timetuple()) * 10**9 + int((fraction or "0").ljust(9, "0"))
    seconds = (ns(state["FinishedAt"]) - ns(state["StartedAt"])) / 10**9
    if not math.isfinite(seconds) or seconds <= 0:
        raise ValueError("actual settled daemon duration must be positive finite")
    return seconds


def pair(output, prior, item):
    names = public.SUB_FILES[:2] if item["shape"] == "single" else [entry["sub"]+"/"+name for entry in item["subs"] for name in public.SUB_FILES[:2]]
    frames = [public.compare_frame(output / name, prior / name) for name in names]
    side_names = ["events.json"] if item["shape"] == "single" else [entry["sub"]+"/events.json" for entry in item["subs"]]+["batch_events.json"]
    stable=[]
    for name in side_names:
        a,b=public.read_json(output/name),public.read_json(prior/name)
        for value in (a,b):
            for key in ("wall_clock_sec","events_per_sec","peak_memory_bytes","gpu_seconds"):value.pop(key,None)
        stable.append({"path":name,"passed":a==b,"current":a,"prior":b})
    return {"passed":all(row["passed"] and row.get("byte_equal") is True for row in frames) and all(row["passed"] for row in stable),
        "frames":frames,"stable_sidecars":stable}


def run_one(args, image, arm, item, folder, label, diagnostic=False):
    inputs,outputs=folder/"input",folder/"output"
    outputs.mkdir(parents=True);outputs.chmod(0o777)
    staged=linux.stage_input(item,inputs)
    command=(["simulate","--config","/input/scenario.json","--out","/output/trace.parquet"] if item["shape"]=="single"
        else ["simulate-batch","--batch-dir","/input/scenarios","--out-dir","/output"])
    row={"arm":arm,"unit":item["unit"],"shape":item["shape"],"output":str(outputs.resolve()),"staged_inputs":staged,
        "passed":False,"timing_included":False,"diagnostic":diagnostic,"rankable":False}
    try:
        row["execution"]=run_container(args,image,inputs,outputs,command,label,call,inspect,arm,300,diagnostic)
        row["reference_checks"]=public.verify_outputs(args.reference_root/item["unit"],outputs,item)
        row["developer_verifier"]=linux.gate(args,args.reference_root/item["unit"],outputs,folder)
        if row["reference_checks"]["passed"] is not True or row["developer_verifier"]["admissible"] is not True:
            raise ValueError("actual official reference or unchanged developer gate failed")
        if any(sha(Path(value["staged"]))!=value["sha256"] for value in staged):
            raise ValueError("actual staged organizer input changed")
        actual=row["reference_checks"]["actual_events"]
        side=public.read_json(outputs/("events.json" if item["shape"]=="single" else "batch_events.json"))
        if side.get("n_events",side.get("total_events"))!=actual or actual<=0:
            raise ValueError("actual emitted rows and sidecar count differ")
        if item["shape"]=="batch" and [v["sub"] for v in side["per_scenario"]]!=sorted(v["sub"] for v in item["subs"]):
            raise ValueError("actual sorted production batch order differs")
        state=row["execution"]["inspect_after"]["State"]
        row.update(actual_events=actual,daemon_started_at=state["StartedAt"],daemon_finished_at=state["FinishedAt"],
            daemon_runtime_sec=daemon_seconds(state),cli_wall_sec=side["wall_clock_sec"],output_inventory=inventory(outputs))
        row["passed"]=True
    except BaseException as error:
        row["failure"]={"type":type(error).__name__,"message":str(error)}
        path=args.evidence/(label+"-EXECUTION.json")
        if "execution" not in row and path.is_file():row["execution"]=public.read_json(path)
    write(folder/"RUN_RESULT.json",row)
    return row


def validate_plan():
    verify_payload(PAYLOAD)
    plan=public.read_json(PAYLOAD/"SCREEN_PLAN.json")
    if (plan.get("schema")!="t3-native-transaction-v8-five-unit-performance-plan-v1" or plan.get("prototype_only") is not False
        or plan.get("candidate_source_receipt_sha256")!=SOURCE_RECEIPT_SHA256 or plan.get("warmups")!=1
        or plan.get("measured_repeats")!=5 or plan.get("measured_runs")!=50 or plan.get("main_containers")!=60
        or plan.get("diagnostic_containers")!=10 or plan.get("actual_V8_controls_audit_sha256") is None):
        raise ValueError("sealed independently reviewed protocol and actual V8 correctness audit required")
    actual=public.read_json(PAYLOAD/"source_review/ACTUAL_V8_CONTROLS_AUDIT.json")
    if (sha(PAYLOAD/"source_review/ACTUAL_V8_CONTROLS_AUDIT.json")!=plan["actual_V8_controls_audit_sha256"]
        or actual.get("all_passed") is not True or actual.get("classification")!="PASS_SAVED_FINITE_CORRECTNESS_ONLY"
            or actual.get("complete_saved_correctness") is not True or actual.get("Parquet_decoded") is not True or actual.get("candidate_source_receipt_sha256")!=SOURCE_RECEIPT_SHA256
        or actual.get("artifact_zip_sha256")!=plan["actual_V8_controls_artifact_zip_sha256"]):
        raise ValueError("actual V8 controls ZIP/audit binding differs")
    for label,expected in (("candidate",SOURCE_RECEIPT_SHA256),("wrapper",plan["wrapper_source_receipt_sha256"])):
        path=PAYLOAD/"source_review"/(label+".json")
        review=public.read_json(path)
        if sha(path)!=plan[label+"_review_sha256"] or review.get("status")!="PASS_SOURCE_ONLY" or review.get("unresolved_source_blockers")!=[] or review.get("frozen_source_receipt_sha256")!=expected:
            raise ValueError("exact independent frozen review binding differs")
    return plan


def main_runs(args,plan,ready):
    roster=public.collect_plan(args.reference_root,list(SINGLES)+[BATCH]);write(args.evidence/"REFERENCE_PLAN.json",roster)
    items={item["unit"]:item for item in roster["units"]}
    if len(items)!=5 or len(items[BATCH]["subs"])!=5:raise ValueError("exact five public units and full five-member batch required")
    before=inspect(args,ready["image_id"],"performance-image-before")
    rows,first,failure=[],{},None
    try:
        for repeat in range(-WARMUPS,MEASURED_REPEATS):
            for index,unit in enumerate(list(SINGLES)+[BATCH]):
                group={};order=arm_order(index,repeat)
                for arm in order:
                    label="perf-%02d-%02d-%s"%(repeat+1,index,arm)
                    folder=args.evidence/"main"/("warmup" if repeat<0 else "repeat-%d"%repeat)/unit/arm
                    row=run_one(args,ready["image_id"],arm,items[unit],folder,label)
                    row.update(repeat=repeat,warmup=repeat<0,order=order,timing_included=repeat>=0)
                    rows.append(row);group[arm]=row;write(args.evidence/"RAW_RESULTS.json",rows)
                    if row["passed"] is not True:raise ValueError("stop at failed actual CLI/reference/gate run")
                for arm,row in group.items():
                    current=Path(row["output"]);prior=first.setdefault((unit,arm),current)
                    row["cross_arm_pair"]=pair(current,Path(group[ARMS[0]]["output"]),items[unit])
                    row["same_arm_stability"]=pair(current,prior,items[unit])
                    row["passed"] &= row["cross_arm_pair"]["passed"] and row["same_arm_stability"]["passed"]
                    write(current.parent/"RUN_RESULT.json",row);write(args.evidence/"RAW_RESULTS.json",rows)
                    if row["passed"] is not True:raise ValueError("actual output pair/repeat stability failed")
    except BaseException as error:failure={"type":type(error).__name__,"message":str(error)}
    after=None;unchanged=False;source_unchanged=False
    try:
        after=inspect(args,ready["image_id"],"performance-image-after")
        unchanged=all(sha(args.reference_root/item["unit"]/name)==digest for item in roster["units"] for mapping in (item["input_sha256"],item["reference_sha256"]) for name,digest in mapping.items())
        verify_payload(PAYLOAD)
        built=public.read_json(args.evidence/"ACTUAL_BUILD_INSPECTION.json")
        source_unchanged=inventory(Path(ready["installed"]))==built["installed_files"]
        if not source_unchanged or before!=after:raise ValueError("actual payload/installed source/image changed")
    except BaseException as error:
        failure=failure or {"type":type(error).__name__,"message":str(error)}
    measured=[row for row in rows if row["timing_included"]]
    rates=[]
    for unit in list(SINGLES)+[BATCH]:
        arms={arm:[r for r in measured if r["unit"]==unit and r["arm"]==arm and r["passed"]] for arm in ARMS}
        if any(len(arms[arm])!=5 for arm in ARMS):continue
        detail={"unit":unit,"arms":{}}
        for arm in ARMS:
            selected=arms[arm]
            if len({r["actual_events"] for r in selected})!=1:raise ValueError("actual repeat counts differ")
            median=statistics.median(r["actual_events"]/r["daemon_runtime_sec"] for r in selected)
            detail["arms"][arm]={"measured_repeats":5,"median_daemon_events_per_sec":median,
                "daemon_durations_sec":[r["daemon_runtime_sec"] for r in selected],"actual_events":selected[0]["actual_events"]}
        detail["median_rate_ratio"]=detail["arms"][ARMS[1]]["median_daemon_events_per_sec"]/detail["arms"][ARMS[0]]["median_daemon_events_per_sec"]
        rates.append(detail)
    official=sum("developer_verifier" in r for r in rows)
    gates=sum(g.get("passed") is True for r in rows for g in (r.get("developer_verifier",{}).get("verdict") or {}).get("gate_results",{}).values())
    result={"schema":"t3-native-transaction-v8-five-unit-performance-result-v1","all_passed":failure is None and len(rows)==60 and len(measured)==50 and official==60 and gates==240 and len(rates)==5 and all(r["passed"] for r in rows) and unchanged and source_unchanged and before==after,
        "failure":failure,"main_containers":len(rows),"measured_runs":len(measured),"official_verifier_calls":official,"official_gate_passes":gates,
        "per_unit_median_rates":rates,"five_unit_mean_median_daemon_events_per_sec":{arm:statistics.mean(r["arms"][arm]["median_daemon_events_per_sec"] for r in rates) for arm in ARMS} if len(rates)==5 else None,
        "image_unchanged":before==after,"installed_sources_unchanged":source_unchanged,"original_inputs_references_unchanged":unchanged,"timing_scope":"Docker daemon StartedAt to FinishedAt",
        "actual_build":ready,"diagnostic_overhead_in_main":False,"rankable":False,"full71":False,"official_score":None,"submission_ready":False}
    write(args.evidence/"PERFORMANCE_RESULT.json",result)
    if result["all_passed"] is not True:raise RuntimeError("actual performance protocol incomplete or failed")


def main():
    parser=argparse.ArgumentParser();parser.add_argument("verb",choices=("build","run","diagnose","artifact"))
    parser.add_argument("--evidence",type=Path,required=True);parser.add_argument("--reference-root",type=Path)
    parser.add_argument("--gate-kit",type=Path);parser.add_argument("--gate-python",default=sys.executable)
    parser.add_argument("--docker",default="docker");parser.add_argument("--artifact",type=Path);parser.add_argument("--log-cap-bytes",type=int,default=4*1024**2)
    args=parser.parse_args();args.evidence=args.evidence.resolve();args.evidence.mkdir(parents=True,exist_ok=True)
    if args.verb=="artifact":
        if args.artifact is None or args.artifact.exists():raise ValueError("fresh artifact path required")
        args.artifact.mkdir(parents=True);shutil.copytree(args.evidence,args.artifact/"evidence",ignore=shutil.ignore_patterns("anonymous-docker-config"));shutil.copytree(PAYLOAD,args.artifact/"payload");return
    try:
        plan=validate_plan()
        if args.verb=="build":write(args.evidence/"BUILD_READY.json",build(args,plan));return
        ready=public.read_json(args.evidence/"BUILD_READY.json")
        if ready["candidate_source_receipt_sha256"]!=SOURCE_RECEIPT_SHA256:raise ValueError("actual native V8 build binding differs")
        if args.verb=="run":main_runs(args,plan,ready)
        else:
            from diagnostics import diagnose
            diagnose(args,plan,ready,run_one)
    except BaseException as error:
        write(args.evidence/("FAILURE-"+args.verb+".json"),{"type":type(error).__name__,"message":str(error),"rankable":False});raise


if __name__=="__main__":main()
