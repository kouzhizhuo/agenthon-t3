"""Parse independent untimed phase controls; never blend into main measurements."""
import json
import math
from pathlib import Path
from common import ARMS,SINGLES,BATCH,sha,write

LABELS=["simulate_enter","admission_enter","build_config_enter","build_config_exit","abides_run_enter","abides_run_exit",
    "extract_trace_enter","extract_ledger_enter","frame_validation_enter","trace_write_enter","message_write_enter",
    "trace_hash_enter","sidecar_write_enter","simulate_exit"]


def parse(row,item,plan):
    log=Path(row["execution"]["attach"]["log"]["path"])
    prefix="T3_NATIVE_V8_UNTIMED_PHASES="
    lines=[line[len(prefix):] for line in log.read_text().splitlines() if line.startswith(prefix)]
    if len(lines)!=1:raise ValueError("one actual untimed diagnostic receipt required")
    value=json.loads(lines[0]);ticks=value["ticks"]
    count=1 if item["shape"]=="single" else len(item["subs"])
    if (value.get("schema")!="t3-native-v8-untimed-phase-driver-v1" or value.get("non_marker_AST_equal") is not True
        or value.get("simulate_alias_restored") is not True or value.get("trace_hook_used") is not False
        or value.get("diagnostic_overhead_included") is not True or value.get("timing_included") is not False
        or value.get("failure") is not None or value.get("arm")!=row["arm"] or len(ticks)!=14*count
        or value["source_sha256"]!=next(v["sha256"] for v in plan["candidate_sources"] if v["path"]=="production_cli.py")):
        raise ValueError("actual untimed phase/source/AST/episode binding differs")
    def finite(x):return type(x) in (int,float) and math.isfinite(x) and x>0
    times=[v["perf_counter"] for v in ticks]
    if not all(finite(t) for t in times) or any(a>b for a,b in zip(times,times[1:])):raise ValueError("actual phase clocks not finite monotonic")
    episodes=[]
    scenarios=sorted(Path(p) for p in item["scenario_paths"])
    for i,scenario in enumerate(scenarios):
        group=ticks[i*14:(i+1)*14]
        expected="/input/scenario.json" if item["shape"]=="single" else "/input/scenarios/"+scenario.name
        if [v["phase"] for v in group]!=LABELS or group[0]["config_path"]!=expected or any(v["config_path"] is not None for v in group[1:]):
            raise ValueError("actual phase label/input-path roster differs")
        episodes.append({"config_path":expected,"intervals":[{"from":a["phase"],"to":b["phase"],"seconds":b["perf_counter"]-a["perf_counter"]} for a,b in zip(group,group[1:])]})
    milestones=value["milestones"]
    if [v["phase"] for v in milestones]!=["actual_entry_import_enter","actual_entry_import_exit","actual_main_enter","actual_main_exit","diagnostic_exit"]:
        raise ValueError("actual diagnostic milestone roster incomplete")
    clocks=[v["perf_counter"] for v in milestones]
    if not all(finite(t) for t in clocks) or any(a>b for a,b in zip(clocks,clocks[1:])) or not clocks[2]<=times[0]<=times[-1]<=clocks[3]:
        raise ValueError("actual import/main/phase clocks differ")
    if len(value["episodes"])!=count or any(v["installation_restored"] is not True or v["control_probe_loaded"] is not False for v in value["episodes"]):
        raise ValueError("actual production installation episode controls differ")
    value.update(parsed_episode_intervals=episodes,actual_daemon_runtime_sec=row["daemon_runtime_sec"],
        actual_entry_import_sec=clocks[1]-clocks[0],diagnostic_instrumentation_sec=clocks[2]-clocks[1],actual_main_sec=clocks[3]-clocks[2],
        driver_window_sec=clocks[-1]-value["driver_started"],daemon_minus_driver_window_sec=row["daemon_runtime_sec"]-(clocks[-1]-value["driver_started"]),
        residual_note="Includes process start before first Python tick, driver report/output and teardown after last tick; not a proven unavoidable floor")
    return value


def diagnose(args,plan,ready,run_one):
    import verify_public as public
    from controller import pair
    roster=public.collect_plan(args.reference_root,list(SINGLES)+[BATCH]);items={v["unit"]:v for v in roster["units"]}
    rows,failure=[],None
    try:
        for index,unit in enumerate(list(SINGLES)+[BATCH]):
            group={}
            for arm in ARMS:
                label="diagnostic-%02d-%s"%(index,arm);folder=args.evidence/"diagnostics"/unit/arm
                row=run_one(args,ready["image_id"],arm,items[unit],folder,label,diagnostic=True)
                row["diagnostic_checks_passed"]=False
                rows.append(row);group[arm]=row;write(args.evidence/"DIAGNOSTIC_RAW_RESULTS.json",rows)
                if row["passed"] is not True:raise ValueError("actual diagnostic CLI/official gate failed")
                row["phase_evidence"]=parse(row,items[unit],plan);write(folder/"PHASE_EVIDENCE.json",row["phase_evidence"])
                measured=next(v for v in public.read_json(args.evidence/"RAW_RESULTS.json") if v["unit"]==unit and v["arm"]==arm and not v["warmup"])
                row["unprofiled_output_pair"]=pair(Path(row["output"]),Path(measured["output"]),items[unit])
                if row["unprofiled_output_pair"]["passed"] is not True:raise ValueError("actual diagnostic changed production outputs")
                row["diagnostic_checks_passed"]=True
            matched=pair(Path(group[ARMS[1]]["output"]),Path(group[ARMS[0]]["output"]),items[unit])
            if matched["passed"] is not True:raise ValueError("actual diagnostic cross-arm output difference")
            for row in group.values():row["cross_arm_pair"]=matched
            write(args.evidence/"DIAGNOSTIC_RAW_RESULTS.json",rows)
    except BaseException as error:failure={"type":type(error).__name__,"message":str(error)}
    finally:
        write(args.evidence/"DIAGNOSTIC_RAW_RESULTS.json",rows)
        result={"schema":"t3-native-v8-untimed-phase-diagnostics-v1","all_passed":failure is None and len(rows)==10 and all(v["passed"] and v.get("diagnostic_checks_passed") is True for v in rows),
            "failure":failure,"containers":len(rows),"episodes":sum(len(v.get("phase_evidence",{}).get("episodes",[])) for v in rows),
            "rows":rows,"timing_included":False,"diagnostic_overhead_included":True,"rankable":False,"official_score":None}
        write(args.evidence/"DIAGNOSTIC_RESULT.json",result)
    if result["all_passed"] is not True:raise RuntimeError("actual untimed phase diagnostics incomplete or failed")
