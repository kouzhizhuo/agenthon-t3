"""Build and inspect actual V8 native deployment once; no market during build."""
import json
import os
from pathlib import Path
import platform
import uuid
from common import BASE, CANDIDATE, BASELINE, ENTRYPOINT, SOURCE_RECEIPT_SHA256, sha, inventory, write
from commands import call, inspect
from execution import cleanup

PAYLOAD = Path(__file__).resolve().parents[1]


def build(args, plan):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("actual Linux amd64 host required")
    anonymous = args.evidence / "anonymous-docker-config"
    anonymous.mkdir()
    prior = os.environ.get("DOCKER_CONFIG")
    os.environ["DOCKER_CONFIG"] = str(anonymous)
    try:
        call(args, [args.docker, "pull", "--platform", "linux/amd64", BASE], "base-pull", 600)
    finally:
        if prior is None:
            os.environ.pop("DOCKER_CONFIG", None)
        else:
            os.environ["DOCKER_CONFIG"] = prior
    base = inspect(args, BASE, "base-inspect")
    if "sha256:5a190afe0bdfe7685e64cbf1aec30d39885199c85f688a971b8d4a0ab8d217eb" not in " ".join(base.get("RepoDigests", [])):
        raise ValueError("actual base digest differs")
    tag = "t3-native-transaction-performance-v8:" + uuid.uuid4().hex
    call(args, [args.docker, "build", "--platform", "linux/amd64", "--pull=false", "-t", tag,
                "-f", str(PAYLOAD / "control/Dockerfile"), str(PAYLOAD)], "image-build", 600)
    image = inspect(args, tag, "image-inspect")
    if image["Config"]["Entrypoint"] != ENTRYPOINT or image["Config"]["User"] != "65534:65534":
        raise ValueError("actual control image entry/user differs")
    evidence_name = "t3-transaction-evidence-" + uuid.uuid4().hex
    try:
        call(args, [args.docker, "create", "--name", evidence_name, tag], "evidence-create")
        copied = args.evidence / "installed"
        call(args, [args.docker, "cp", evidence_name + ":/opt/native-transaction-performance", str(copied)], "installed-copy")
    finally:
        settled_copy = cleanup(args, evidence_name, "evidence", call)
        if settled_copy["settled"] is not True:
            raise ValueError("actual installed-copy cleanup/absence did not settle")
    # Actual installed source/build/ELF/proof bytes are retained and inspected.
    for row in plan["candidate_sources"]:
        actual = copied / CANDIDATE / row["path"]
        if actual.stat().st_size != row["bytes"] or sha(actual) != row["sha256"]:
            raise ValueError("installed candidate source differs")
    if inventory(copied / BASELINE) != plan["baseline_sources"]:
        raise ValueError("installed baseline source differs")
    for filename, row in plan["control_sources"].items():
        actual = copied / "control" / filename
        if actual.stat().st_size != row["bytes"] or sha(actual) != row["sha256"]:
            raise ValueError("actual installed control source differs")
    deployment = json.loads((copied / CANDIDATE / "DEPLOYMENT.json").read_text())
    authority = json.loads((copied / CANDIDATE / "DEPLOYMENT_AUTHORITY.json").read_text())
    proof = json.loads((copied / CANDIDATE / "DEPLOYMENT_PROOF.json").read_text())
    create = json.loads((copied / "build-proof-create.json").read_text())
    bindings = ("candidate", "abi", "extension_path", "extension_sha256", "extension_bytes",
                "build_receipt_sha256", "source_receipt_sha256", "runtime_pins_sha256",
                "compile_spec_sha256", "control_probe_source_sha256", "control_probe")
    extension = copied / CANDIDATE / deployment["extension_path"]
    probe = copied / CANDIDATE / deployment["control_probe"]["path"]
    if (deployment["schema"] != "t3-native-canonical-transaction-deployment-v8"
            or deployment["extension_sha256"] != sha(extension)
            or deployment["extension_bytes"] != extension.stat().st_size
            or deployment["control_probe"]["sha256"] != sha(probe)
            or deployment["control_probe"]["bytes"] != probe.stat().st_size
            or authority.get("schema") != "t3-native-transaction-external-authority-v8"
            or proof.get("schema") != "t3-native-transaction-deployment-proof-v8"
            or authority["audit_all_passed"] is not True or proof["audit_all_passed"] is not True
            or proof.get("actual_external_audit_executed") is not True
            or proof.get("actual_extension_loader") != "ExtensionFileLoader"
            or proof["deployment_sha256"] != sha(copied / CANDIDATE / "DEPLOYMENT.json")
            or proof["bindings"] != {key: deployment[key] for key in bindings}
            or any(authority[key] != deployment[key] for key in bindings)
            or authority["proof_report_sha256"] != sha(copied / CANDIDATE / "DEPLOYMENT_PROOF.json")
            or deployment["build_receipt_sha256"] != sha(copied / CANDIDATE / "BUILD_RECEIPT.json")
            or deployment["source_receipt_sha256"] != plan["candidate_source_receipt_sha256"]
            or sha(copied / CANDIDATE / "SOURCE_PREPARATION_RECEIPT_v1.json") != SOURCE_RECEIPT_SHA256
            or create.get("schema") != "t3-native-transaction-host-audit-result-v8"
            or create.get("mode") != "create" or create.get("audit_all_passed") is not True
            or create.get("proof") != proof or create.get("deployment_authority") != authority
            or create.get("deployment_proof_sha256") != sha(copied / CANDIDATE / "DEPLOYMENT_PROOF.json")
            or create.get("authority_sha256") != sha(copied / CANDIDATE / "DEPLOYMENT_AUTHORITY.json")):
        raise ValueError("actual built deployment/source/ELF/external authority differs")
    write(args.evidence / "ACTUAL_BUILD_INSPECTION.json", {
        "schema": "t3-native-transaction-v8-host-build-inspection", "all_passed": True,
        "base_image": base["Id"], "control_image": image["Id"], "installed_files": inventory(copied),
        "deployment": deployment, "authority": authority, "proof": proof,
        "source_ELF_external_proof_checked": True, "timing_executed": False, "rankable": False})
    return {"image_id": image["Id"], "image": image, "proof": proof, "authority": authority,
        "installed": str(copied), "actual_build_invocations": 1, "candidate_source_receipt_sha256": SOURCE_RECEIPT_SHA256,
        "timing_executed_during_build": False, "rankable": False}
