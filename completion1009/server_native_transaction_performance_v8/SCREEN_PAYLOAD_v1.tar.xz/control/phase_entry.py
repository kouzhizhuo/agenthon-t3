"""Untimed diagnostic: exact original simulate AST plus O(14) clock markers."""
import time
DRIVER_STARTED = time.perf_counter()
import ast
import copy
import hashlib
import importlib.util
import json
import sys
from entry import CANDIDATE, RUNTIME, actual_argv

TICKS=[]
MILESTONES=[]


def mark(phase,config_path=None):
    TICKS.append({"phase":phase,"perf_counter":time.perf_counter(),"config_path":None if config_path is None else str(config_path)})


def milestone(phase):
    MILESTONES.append({"phase":phase,"perf_counter":time.perf_counter()})


def instrument(namespace,source):
    tree=ast.parse(source)
    original=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=="simulate")
    target=copy.deepcopy(original)
    labels=[]
    def clock(label):
        labels.append(label)
        return ast.Expr(value=ast.Call(func=ast.Name(id="_t3_phase_mark",ctx=ast.Load()),args=[ast.Constant(label)],keywords=[]))
    def assignment(node,name):
        return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
    def call_stmt(node,text):return isinstance(node,ast.Expr) and ast.unparse(node).startswith(text)
    class Insert(ast.NodeTransformer):
        def visit_FunctionDef(self,node):
            self.generic_visit(node)
            if node.name=="simulate":
                node.body.insert(0,ast.Expr(value=ast.Call(func=ast.Name(id="_t3_phase_mark",ctx=ast.Load()),args=[ast.Constant("simulate_enter"),ast.Name(id="config_path",ctx=ast.Load())],keywords=[])))
            return node
        def visit_With(self,node):
            self.generic_visit(node)
            if ast.unparse(node.items[0].context_expr).startswith("enabled("):
                return [clock("admission_enter"),node]
            return node
        def visit_Assign(self,node):
            self.generic_visit(node)
            mapping={"config":"build_config_enter","end_state":"abides_run_enter","message_extractor":"abides_run_exit",
                "trace":"extract_trace_enter","messages":"extract_ledger_enter","trace_digest":"trace_hash_enter"}
            for name,label in mapping.items():
                if assignment(node,name):return [clock(label),node]
            return node
        def visit_If(self,node):
            self.generic_visit(node)
            if (ast.unparse(node.test)=="installed['installed_engine'] == 'canonical'"
                    and any(isinstance(v,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr=="write_summary_log" for t in v.targets) for v in node.body)):
                return [clock("build_config_exit"),node]
            return node
        def visit_Expr(self,node):
            self.generic_visit(node)
            mapping={"validate_frames(":"frame_validation_enter","trace.to_parquet(":"trace_write_enter",
                "messages.to_parquet(":"message_write_enter","(out.parent / 'events.json').write_text(":"sidecar_write_enter"}
            for prefix,label in mapping.items():
                if call_stmt(node,prefix):return [clock(label),node]
            return node
        def visit_Return(self,node):return [clock("simulate_exit"),node]
    transformed=Insert().visit(target)
    ast.fix_missing_locations(transformed)
    class Remove(ast.NodeTransformer):
        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=="_t3_phase_mark":return None
            return self.generic_visit(node)
    stripped=Remove().visit(copy.deepcopy(transformed))
    if ast.dump(stripped,include_attributes=False)!=ast.dump(original,include_attributes=False):
        raise ValueError("diagnostic non-marker business AST differs")
    module=ast.Module(body=[transformed],type_ignores=[])
    ast.fix_missing_locations(module)
    namespace["_t3_phase_mark"]=mark
    exec(compile(module,str(CANDIDATE/"production_cli.py")+":diagnostic","exec"),namespace)
    return True


def main():
    official,arm=actual_argv()
    sys.path.insert(0,str(CANDIDATE));sys.path.insert(0,str(RUNTIME))
    source=(CANDIDATE/"production_cli.py").read_bytes()
    milestone("actual_entry_import_enter")
    spec=importlib.util.spec_from_file_location("native_v8_untimed_actual_cli",CANDIDATE/"production_cli.py")
    actual=importlib.util.module_from_spec(spec);spec.loader.exec_module(actual)
    milestone("actual_entry_import_exit")
    original=actual.simulate
    ast_equal=instrument(vars(actual),source)
    old=list(sys.argv)
    if arm=="original_canonical":sys.argv += ["--arm",arm]
    failure=None
    try:
        milestone("actual_main_enter")
        actual.main()
        milestone("actual_main_exit")
    except BaseException as error:
        failure={"type":type(error).__name__,"message":str(error)}
        raise
    finally:
        actual.simulate=original;sys.argv=old
        milestone("diagnostic_exit")
        report={"schema":"t3-native-v8-untimed-phase-driver-v1","arm":arm,"official_argv":official,
            "driver_started":DRIVER_STARTED,"original_entry_started":actual.ENTRY_STARTED,"ticks":TICKS,"milestones":MILESTONES,
            "non_marker_AST_equal":ast_equal,"simulate_alias_restored":actual.simulate is original,
            "source_sha256":hashlib.sha256(source).hexdigest(),"episodes":actual.episode_probes(),"failure":failure,
            "trace_hook_used":False,"diagnostic_overhead_included":True,"timing_included":False,"rankable":False}
        print("T3_NATIVE_V8_UNTIMED_PHASES="+json.dumps(report,sort_keys=True,allow_nan=False))


if __name__=="__main__":main()
