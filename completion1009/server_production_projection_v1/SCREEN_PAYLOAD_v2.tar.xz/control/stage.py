"""Parse, copy and archive frozen sources only; never load the candidate."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import (BASE, BATCH, CANDIDATE, PARENT, DONOR, ARMS, MAX_BYTES, MAX_FILES, SINGLES,
                    SOURCE_RECEIPT_SHA256, DONOR_SOURCE_RECEIPT_SHA256, PARENT_MANIFEST_SHA256, inventory, safe_name, sha, write)

HERE = Path(__file__).resolve().parent
COMPLETION = HERE.parent


def copy(source, destination):
    if source.is_symlink() or not source.is_file():
        raise ValueError("ordinary source file required: " + str(source))
    if source.suffix == ".py":
        ast.parse(source.read_text(), filename=str(source))
    if source.suffix == ".json":
        json.loads(source.read_text())
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    destination.chmod(0o644)
    if sha(source) != sha(destination):
        raise ValueError("source copy differs")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.archive.exists():
        raise ValueError("new staging directory and source archive required")
    if len(SOURCE_RECEIPT_SHA256) != 64 or len(PARENT_MANIFEST_SHA256) != 64:
        raise ValueError("candidate receipt and observer manifest must be frozen before staging")
    candidate = COMPLETION / Path(CANDIDATE).relative_to("completion1009")
    parent = COMPLETION / Path(PARENT).relative_to("completion1009")
    donor = COMPLETION / Path(DONOR).relative_to("completion1009")
    receipt_path = candidate / "SOURCE_PREPARATION_RECEIPT.json"
    if sha(receipt_path) != SOURCE_RECEIPT_SHA256:
        raise ValueError("reviewed projection source receipt differs")
    receipt = json.loads(receipt_path.read_text())
    if receipt.get("file_count") != 8 or len(receipt["files"]) != 8:
        raise ValueError("reviewed 8-file production projection freeze required")
    if sha(parent / "SNAPSHOT_MANIFEST.json") != PARENT_MANIFEST_SHA256:
        raise ValueError("frozen observer parent manifest differs")
    parent_manifest = json.loads((parent / "SNAPSHOT_MANIFEST.json").read_text())
    if len(parent_manifest["files"]) != 64:
        raise ValueError("64-member observer runtime required")
    pins_path = candidate / "RUNTIME_PINS.json"
    pins = json.loads(pins_path.read_text())
    if (pins.get("runtime_source_changes") != 0 or len(pins["files"]) != 64
            or pins["parent_manifest_sha256"] != PARENT_MANIFEST_SHA256
            or pins["files"] != [{k: r[k] for k in ("path", "bytes", "sha256")} for r in parent_manifest["files"]]):
        raise ValueError("projection exact selected-parent snapshot differs")
    args.out.mkdir(parents=True)
    for row in receipt["files"]:
        name = safe_name(row["path"])
        source = candidate / name
        if source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]:
            raise ValueError("candidate source differs: " + name)
        copy(source, args.out / CANDIDATE / name)
    donor_receipt = json.loads((donor / "SOURCE_PREPARATION_RECEIPT.json").read_text())
    if sha(donor / "SOURCE_PREPARATION_RECEIPT.json") != DONOR_SOURCE_RECEIPT_SHA256 or len(donor_receipt["files"]) != 14:
        raise ValueError("unchanged complete proof donor freeze differs")
    for row in donor_receipt["files"]:
        source = donor / safe_name(row["path"])
        if source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]:
            raise ValueError("unchanged proof donor source differs")
        copy(source, args.out / DONOR / row["path"])
    for name in ("RUNTIME_PINS.json", "SOURCE_PINS.json", "SOURCE_PREPARATION_RECEIPT.json"):
        copy(donor / name, args.out / DONOR / name)
    expected_runtime = {}
    for row in pins["files"]:
        name = safe_name(row["path"])
        expected = {k: row[k] for k in ("bytes", "sha256")}
        for origin, prefix in ((candidate, CANDIDATE), (parent, PARENT), (donor, DONOR)):
            source = origin / "runtime" / name
            if {"bytes": source.stat().st_size, "sha256": sha(source)} != expected:
                raise ValueError("complete observer runtime differs: " + name)
            copy(source, args.out / prefix / "runtime" / name)
        expected_runtime[name] = expected
    if inventory(candidate / "runtime") != expected_runtime or inventory(parent / "runtime") != expected_runtime or inventory(donor / "runtime") != expected_runtime:
        raise ValueError("extra or missing observer runtime members")
    for name in ("RUNTIME_PINS.json", "SOURCE_PREPARATION_RECEIPT.json"):
        copy(candidate / name, args.out / CANDIDATE / name)
    for name in ("SNAPSHOT_MANIFEST.json", "CORRECTNESS_EVIDENCE.json"):
        copy(parent / name, args.out / PARENT / name)
    for name in ("verify_linux.py", "verify_public.py", "fetch_evaluation.py"):
        copy(COMPLETION / name, args.out / "host" / name)
    controls = ("common.py", "materialize.py", "entry.py", "controller.py", "stage.py", "Dockerfile", "README.md")
    for name in controls:
        copy(HERE / name, args.out / "control" / name)
    plan = {"schema": "t3-production-projection-screen-plan-v1", "base": BASE,
        "candidate": CANDIDATE, "source_receipt_sha256": SOURCE_RECEIPT_SHA256,
        "donor": DONOR, "donor_source_receipt_sha256": DONOR_SOURCE_RECEIPT_SHA256,
        "donor_source_files": donor_receipt["files"], "native_pyx_sha256": sha(donor / "native_projection.pyx"),
        "runtime_pins_sha256": sha(pins_path), "source_files": receipt["files"],
        "single_units": SINGLES, "batch_unit": BATCH, "parent": PARENT,
        "arms": ARMS, "controls_first": True, "build_count": 1, "extension_builds": 1,
        "warmups": 1, "measured_repeats": 3, "planned_runs": 56, "control_invocations": 1,
        "total_execution_containers": 57, "measured_runs": 30, "official_verifier_runs": 46,
        "official_gate_passes": 184, "no_performance_early_stop": True,
        "proof_finite_cases": 56, "production_finite_cases": 38, "market_cases": 4,
        "proof_complete_market_cases": 4, "production_complete_market_cases": 4, "parent_manifest_sha256": PARENT_MANIFEST_SHA256,
        "parent_runtime_files": parent_manifest["files"],
        "proof_only": True, "timing_claim": False, "rankable": False,
        "official_submission": False, "full_five_member_batch": True}
    write(args.out / "SCREEN_PLAN.json", plan)
    files = inventory(args.out)
    if len(files) + 1 > MAX_FILES or sum(row["bytes"] for row in files.values()) > MAX_BYTES:
        raise ValueError("source payload exceeds finite bound")
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-production-projection-screen-payload-v1", "files": files})
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.archive, "w:xz", preset=6) as archive:
        for name in sorted(inventory(args.out)):
            data = (args.out / name).read_bytes()
            member = tarfile.TarInfo(safe_name(name))
            member.size, member.mode, member.mtime = len(data), 0o644, 0
            member.uid = member.gid = 0
            archive.addfile(member, io.BytesIO(data))
    write(args.archive.with_suffix(args.archive.suffix + ".json"), {
        "archive": str(args.archive), "sha256": sha(args.archive), "bytes": args.archive.stat().st_size,
        "regular_members": len(files) + 1, "source_only": True, "candidate_imported": False,
        "native_build_executed": False, "market_executed": False, "workflow_dispatched": False})


if __name__ == "__main__":
    main()
