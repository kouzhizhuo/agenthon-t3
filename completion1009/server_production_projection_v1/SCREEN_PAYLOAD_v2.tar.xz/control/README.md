The fresh screen compares production observer and native projection with actual import costs included. It freshly validates the original proof path and the production path before any timing; previous screen PASS results are not reused as new correctness evidence.

# Production projection screen V1

One image contains the original observer parent, unchanged frozen proof donor and fresh production wrapper. The donor compiles exactly once; a build-only deployment script copies and binds that actual ELF to production. External host checks bind every source/runtime/native/generated C/build receipt before and after execution.

One untimed control container first executes the original 56 finite proof cases and four proof parent/native markets. It then executes 38 normal production-wrapper fixtures plus four production parent/native markets. All four arms' exact frames, nine payload graphs and details compare against the original parent. None of these proof/control runs are counted as a performance improvement.

The two timing arms use one production CLI and retain all imports, initialization, simulation, output validation, Parquet/hash and original sidecar cutoff in CLI/container clocks. The primary comparison is production native versus production observer. The original proof timing is background diagnostic evidence, not an algorithm speedup claim.

The serial selected screen retains smoke 6 + screen 40 + isolated batch members 10 = 56 ordinary runs, one control container, 30 measured runs, 46 official verifier invocations and 184 gates. Resources remain 4 CPUs, 16GiB memory, network none, 64MiB tmpfs and 256MiB per-file/full-tree output bounds. Complete failed outputs and all control graphs/logs are retained; successful ordinary bytes may be compacted only after every check passes.

This source preparation is unexecuted and non-rankable. Root owns freezing, dispatch, saved-evidence audit and promotion.
