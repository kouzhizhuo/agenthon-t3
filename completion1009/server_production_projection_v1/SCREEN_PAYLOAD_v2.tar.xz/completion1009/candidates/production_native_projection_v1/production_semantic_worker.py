#!/usr/bin/env python3
"""Prepared full-state/witness worker; no timing, no omitted market work."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import pickle
import sys
import os
import types
import _thread
import warnings
from datetime import datetime, timedelta
from collections import deque

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--arm", choices=("parent", "native"), required=True)
parser.add_argument("--receipt", required=True)
args = parser.parse_args()
RUNTIME, OUTPUT = Path(args.runtime).resolve(), Path(args.out).resolve()
os.environ["NATIVE_PROJECTION_BUILD_RECEIPT"] = str(Path(args.receipt).resolve())
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
import numpy as np
import pandas as pd
from abides_core import abides
from abides_core.agent import Agent
from abides_core.kernel import Kernel
from abides_core.message import Message
from abides_fork.config import build_config
from abides_fork.simulate import reset_abides_counters
from abides_fork import trace
from abides_markets.orders import Order, Side
from abides_markets.order_book import OrderBook
from optimizations import enabled
from production_projection import begin_projection, extract_projection, episode_probes, reset_probes
if (RUNTIME / "observer.py").exists():
    import observer
    from observer_domain import authenticate_loaded
else:
    observer = None


def encode(value):
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is bytes: return ["bytes", value.hex()]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, pd.Timestamp): return ["Timestamp", value.isoformat()]
    if type(value) is datetime: return ["datetime", value.isoformat()]
    if type(value) is timedelta: return ["timedelta", value.days, value.seconds, value.microseconds]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.ndarray): return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if isinstance(value, dict): return ["dict", [(encode(k), encode(v)) for k, v in value.items()]]
    if type(value) in (list, tuple, deque): return [type(value).__name__, [encode(v) for v in value]]
    if type(value) is Side: return ["Side", value.value]
    if hasattr(value, "__dict__"): return [type(value).__module__, type(value).__name__, encode(vars(value))]
    raise TypeError("unsupported semantic scalar value: " + type(value).__name__)


def graph(value, seen=None, kernel_telemetry=False):
    """Complete business state/aliases; omit only real wall-clock telemetry."""
    seen = {} if seen is None else seen
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is bytes: return ["bytes", value.hex()]
    if type(value) is float: return ["float", value.hex()]
    if type(value) is datetime: return ["datetime", value.isoformat()]
    if type(value) is timedelta: return ["timedelta", value.days, value.seconds, value.microseconds]
    if isinstance(value, np.generic): return [type(value).__name__, graph(value.item(), seen)]
    if type(value) is Side: return ["Side", value.value]
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType,
                          types.BuiltinFunctionType, types.BuiltinMethodType, type)):
        return ["binding", getattr(value, "__module__", ""), getattr(value, "__qualname__", getattr(value, "__name__", ""))]
    if type(value) is _thread.LockType: return ["thread_lock", value.locked()]
    if id(value) in seen: return ["ref", seen[id(value)][0]]
    serial = len(seen)
    seen[id(value)] = (serial, value)
    if isinstance(value, np.random.RandomState): return ["RandomState", serial, encode(value.get_state())]
    if isinstance(value, np.ndarray): return ["ndarray", serial, str(value.dtype), list(value.shape),
        graph(value.tolist(), seen) if value.dtype.hasobject else value.tobytes().hex()]
    if isinstance(value, dict):
        return ["dict", serial, [(graph(k, seen), graph(v, seen)) for k, v in value.items()
            if not (kernel_telemetry and type(k) is str and k == "kernel_event_queue_elapsed_wallclock")]]
    if type(value) in (list, tuple, deque): return [type(value).__name__, serial, [graph(v, seen) for v in value]]
    if type(value) in (set, frozenset): return [type(value).__name__, serial, sorted([encode(v) for v in value], key=repr)]
    if isinstance(value, (pd.DataFrame, pd.Series)): return [type(value).__name__, serial, str(value.dtypes), encode(value.to_dict())]
    if isinstance(value, pd.Timestamp): return ["Timestamp", serial, value.isoformat()]
    if hasattr(value, "__dict__"):
        attrs = [(key, child) for key, child in vars(value).items()
                 if not (isinstance(value, Kernel) and key in
                    ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir"))]
        return [type(value).__module__, type(value).__name__, serial,
                [(key, graph(child, seen, isinstance(value, Kernel) and key == "custom_state")) for key, child in attrs]]
    raise TypeError("unsupported business graph value: " + type(value).__name__)


def snapshot_witness(rows):
    # Extra consumer witness only. graph() retains the complete original
    # bids/asks payload and its aliases, without this projection.
    return [{key: (len(child) != 0 if key in ("bids", "asks") else child)
             for key, child in row.items()} for row in rows]


def witness_consumers(kernel):
    values = []
    for agent in kernel.agents:
        for symbol, book in getattr(agent, "order_books", {}).items():
            consumers = []
            for method in ("get_time_dropout", "_original_time_dropout"):
                probe = type(agent).__new__(type(agent))
                probe.metric_trackers = {symbol: agent.MetricTracker()}
                with warnings.catch_warnings(record=True) as observed:
                    warnings.simplefilter("always")
                    try:
                        getattr(probe, method)(book.book_log2, symbol)
                        result = ["metrics", encode(probe.metric_trackers)]
                    except Exception as error:
                        result = ["exception", type(error).__name__, str(error)]
                    warning_values = [(w.category.__name__, str(w.message)) for w in observed]
                consumers.append([method, result, warning_values])
            values.append([int(agent.id), symbol, encode(snapshot_witness(book.book_log2)),
                           encode(agent.metric_trackers[symbol]), consumers])
    return values


def rng_states(value, path="root", seen=None):
    seen = set() if seen is None else seen
    if isinstance(value, np.random.RandomState): return {path: encode(value.get_state())}
    if value is None or isinstance(value, (int, str, float, bool, np.ndarray, np.generic)): return {}
    if isinstance(value, (types.ModuleType, types.FunctionType, types.MethodType, type)): return {}
    if id(value) in seen: return {}
    seen.add(id(value))
    if isinstance(value, dict): children = [(str(k), v) for k, v in value.items()]
    elif isinstance(value, (list, tuple)): children = [(str(i), v) for i, v in enumerate(value)]
    elif hasattr(value, "__dict__"): children = list(vars(value).items())
    else: return {}
    result = {}
    for key, child in children:
        result.update(rng_states(child, path + "/" + key, seen))
    return result


def scenario(seed, latency, protocol=False):
    result = {"scenario_id": "streaming-observer-controls-" + str(seed), "seed": seed,
        "horizon_ns": 2000000000,
        "exchange_config": {"symbol": "CTRL", "tick_size": 1, "lot_size": 1, "min_price": 1, "max_price": 1000000},
        "oracle_config": {"type": "mean_reverting", "params": {"initial_price": 100000, "kappa": .05,
            "sigma": .001, "jump_intensity": 0., "jump_sigma": 0.}},
        "agent_configs": [
            {"agent_type": "NoiseTrader", "count": 2, "params": {"arrival_rate_hz": 6., "order_size_mean": 10}},
            {"agent_type": "MarketMaker", "count": 1, "params": {"spread_ticks": 2, "depth_levels": 3,
                "size_per_level": 12, "rebalance_interval_ns": 300000000}},
            {"agent_type": "ValueTrader", "count": 1, "params": {"arrival_rate_hz": 4., "threshold_ticks": 2}},
            {"agent_type": "MomentumTrader", "count": 1, "params": {"arrival_rate_hz": 5., "threshold_ticks": 2}}]}
    if latency is not None: result["latency_config"] = latency
    if protocol: result["exchange_config"].update(protocol_enforcement=True, stp_policy="cancel_oldest", ack_delay_ns=400, compute_delay_ns=100)
    return result


def summary_aliases(kernel):
    # Extra explicit summary-row associations; full logs also enter graph().
    return [[int(entry["AgentID"]), entry["EventType"],
        [(event_type, int(timestamp)) for timestamp, event_type, payload in kernel.agents[entry["AgentID"]].log
         if event_type == entry["EventType"] and payload is entry["Event"]]] for entry in kernel.summary_log]


def retained_logs(kernel):
    # Shared graph preserves every private log and original summary alias.
    rows = [[agent.id, agent.log] for agent in kernel.agents]
    return graph([rows, kernel.summary_log])


def run(value):
    reset_abides_counters()
    np.random.seed(19301009)
    if observer is not None:
        authenticated = authenticate_loaded()
        begin_projection(args.arm == "native", authenticated)
        assert observer.begin_episode(value, authenticated), "source domain declined"
    original_summary = Kernel.write_summary_log
    Kernel.write_summary_log = lambda self: None
    try:
        config = build_config(value)
        with enabled(True) as extractor: state = abides.run(config)
        frames = [extract_projection(state), extractor(state)]
        projection_witness = episode_probes()[-1]
        if args.arm == "native":
            assert projection_witness["native_projection_active"] is True
            assert projection_witness["typed_numeric_write_rows"] == len(frames[0])
            assert projection_witness["python_sort_key_callbacks"] == 0
        else:
            assert projection_witness["native_projection_active"] is False
        blobs = []
        for frame in frames:
            stream = io.BytesIO()
            frame.to_parquet(stream, compression="snappy", index=False)
            blobs.append(stream.getvalue())
        kernel = state["agents"][0].kernel
        assert all(agent.kernel is kernel for agent in state["agents"]), "Agent.kernel alias differs"
        fields = {key: child for key, child in vars(kernel).items()
                  if key not in ("kernel_wall_clock_start", "event_queue_wall_clock_start", "log_dir", "agents", "gym_agents", "custom_state")}
        end = {key: child for key, child in state.items() if key not in ("kernel_event_queue_elapsed_wallclock", "agents")}
        retained = graph([state["agents"], config, fields, end])
        rngs = {"numpy_global": encode(np.random.get_state()), **rng_states(config), "kernel": encode(kernel.random_state.get_state())}
        depth = [[int(agent.id), symbol, depth, encode(book.get_l2_bid_data(depth)), encode(book.get_l2_ask_data(depth)),
                  encode(book.get_l3_bid_data(depth)), encode(book.get_l3_ask_data(depth))]
                 for agent in state["agents"] for symbol, book in getattr(agent, "order_books", {}).items()
                 for depth in (0, 1, 10, -1)]
        counters = {key: child for key, child in vars(observer.STATE).items() if key not in ("inference", "contract")} if observer else {}
        details = {"private_log_rows": sum(len(agent.log) for agent in state["agents"]), "summary_rows": len(kernel.summary_log),
                   "observer": counters, "ttl_messages": kernel.ttl_messages,
                   "book_rows": sum(len(book.book_log2) for agent in state["agents"] for book in getattr(agent, "order_books", {}).values())}
        return {"seed": value["seed"], "frames": frames,
                "payload": [blobs, retained, rngs, [Order._order_id_counter, Message._Message__message_id_counter], summary_aliases(kernel), depth,
                            retained_logs(kernel), [agent.kernel is kernel for agent in state["agents"]], witness_consumers(kernel)],
                "details": details, "projection_witness": projection_witness}
    finally:
        Kernel.write_summary_log = original_summary
        if observer is not None: observer.finish_episode()


def main():
    if OUTPUT.exists(): raise ValueError("semantic attempt already exists")
    OUTPUT.mkdir(parents=True)
    values = [run(scenario(seed, latency, protocol)) for seed, latency, protocol in (
        (81009, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}, False),
        (82009, {"model": "deterministic", "params": {"mean_ns": 0}}, False),
        (83009, {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}, True),
        (84009, None, False))]
    data = pickle.dumps(values, protocol=4)
    (OUTPUT / "SEMANTIC_VALUES.pkl").write_bytes(data)
    receipt = {"schema": "t3-production-native-projection-semantic-worker-v1", "arm": args.arm, "timing_claim": False,
        "loaded_domain_authenticated": observer is None or authenticate_loaded(),
        "values_sha256": hashlib.sha256(data).hexdigest(),
        "cases": [{"seed": row["seed"], "trace_rows": len(row["frames"][0]), "message_rows": len(row["frames"][1]),
                   "details": row["details"], "projection_witness": row["projection_witness"]} for row in values]}
    (OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__": main()
