"""Load a build-bound extension once; external evidence owns source/hash audit.

The actual import and native module initialization remain inside the common CLI
and container clocks. This module never parses, compiles or hashes source files.
"""
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import sys
import sysconfig

HERE = Path(__file__).resolve().parent
_module = None
_projector = None
_receipt = None
_load_count = 0


def load_projector():
    global _module, _projector, _receipt, _load_count
    if _projector is not None:
        return _projector
    if sys.implementation.name != "cpython" or list(sys.version_info[:3]) != [3, 11, 17] or sys.platform != "linux":
        raise ValueError("production projection requires pinned Linux CPython 3.11.17")
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    extension = HERE / "native" / ("native_projection" + suffix)
    deployment = json.loads((HERE / "DEPLOYMENT.json").read_text())
    if (deployment.get("schema") != "t3-production-native-projection-deployment-v1"
            or deployment.get("candidate") != HERE.name
            or deployment.get("extension_path") != "native/" + extension.name
            or deployment.get("abi", {}).get("version") != [3, 11, 17]
            or deployment["abi"].get("platform") != "linux"
            or deployment["abi"].get("ext_suffix") != suffix
            or deployment["abi"].get("pointer_bits") != 64
            or deployment["abi"].get("byteorder") != "little"
            or "x86_64" not in suffix or not extension.is_file()):
        raise ValueError("production extension deployment/ABI differs")
    if "native_projection" in sys.modules:
        raise ValueError("production native module preloaded without its fixed owner")
    spec = importlib.util.spec_from_file_location("native_projection", extension)
    if spec is None or not isinstance(spec.loader, importlib.machinery.ExtensionFileLoader):
        raise ValueError("production projection requires an actual extension loader")
    module = importlib.util.module_from_spec(spec)
    sys.modules["native_projection"] = module
    try:
        spec.loader.exec_module(module)
        from abides_markets.orders import Side
        from abides_fork import trace
        import numpy as np
        import pandas as pd
        if (Path(module.__file__).resolve() != extension.resolve()
                or module.Side is not Side or module.np is not np or module.pd is not pd
                or module.PROJECTION_FORMAT != "observer_contract_typed_rows_stable_merge_v1"
                or tuple(module.TRACE_COLUMNS) != tuple(trace.TRACE_COLUMNS)
                or module.TRACE_DTYPES != trace._TRACE_DTYPES
                or getattr(module.project_contract, "__defaults__", None) is not None
                or getattr(module.project_contract, "__kwdefaults__", None) is not None):
            raise ValueError("production native API/constant owner differs")
    except BaseException:
        sys.modules.pop("native_projection", None)
        raise
    _module = module
    _projector = module.project_contract
    _load_count += 1
    _receipt = {"extension_path": str(extension), "extension_sha256": deployment["extension_sha256"],
        "donor_build_receipt_sha256": deployment["donor_build_receipt_sha256"],
        "donor_source_receipt_sha256": deployment["donor_source_receipt_sha256"],
        "abi": deployment["abi"], "runtime_provenance": "external_build_and_host_receipt",
        "runtime_source_compilation": False, "per_episode_native_hash_audit": False}
    return _projector


def native_receipt():
    if _receipt is None:
        raise ValueError("production native module has not been loaded")
    return dict(_receipt, native_load_count=_load_count)
