"""Original parent records enter the exact frozen typed projection algorithm."""
_active = False
_projector = None
_episodes = []


def begin_projection(active, authenticated):
    global _active, _projector
    if type(active) is not bool or type(authenticated) is not bool:
        raise ValueError("projection explicit boolean admission required")
    _active = active and authenticated
    _projector = None
    if _active:
        from production_loader import load_projector
        _projector = load_projector()
    return _active


def extract_projection(end_state):
    import observer
    from abides_fork.trace import extract_trace
    if not _active or observer.STATE is None:
        _episodes.append({"candidate": "production_native_projection_v1", "native_projection_active": False,
            "fallback_used": True, "reason": "whole_episode_not_admitted"})
        return extract_trace(end_state)
    # Preserve the original authenticated observer domain at the same point.
    from observer_domain import authenticate_loaded
    if _projector is None or not authenticate_loaded():
        raise ValueError("projection whole-episode admission changed")
    if type(end_state) is not dict or type(end_state.get("agents")) is not list or type(observer.STATE.contract) is not dict:
        frame = extract_trace(end_state)
        _episodes.append({"candidate": "production_native_projection_v1", "native_projection_active": False,
            "fallback_used": True, "reason": "unsupported_projection_owner"})
        return frame
    groups = [(agent.id, observer.STATE.contract.get(agent, [])) for agent in end_state["agents"]]
    frame, witness = _projector(groups, observer.STATE.has_scalar)
    if frame is None:
        frame = extract_trace(end_state)
    else:
        from production_loader import native_receipt
        witness.update(native_receipt())
    witness["candidate"] = "production_native_projection_v1"
    witness["complete_trace_rows"] = len(frame)
    witness["rankable"] = False
    _episodes.append(witness)
    return frame


def reset_probes():
    _episodes.clear()


def episode_probes():
    return [dict(value) for value in _episodes]
