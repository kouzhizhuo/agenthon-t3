The production candidate uses the exact tested projection algorithm and original observer runtime, with build provenance checked outside simulation. It removes repeated projection self-audits from normal episodes; actual extension loading remains inside the CLI and container clocks.

# Production native projection V1

This is a new candidate. The frozen native_canonical_projection_v2 donor, its native_projection.pyx, all 64 runtime files and original proof workers are unchanged. prepare_deployment.py binds one actual donor build to a copied ELF without importing it. The normal loader reads that deployment once and imports the extension once. It does not compile or hash Python source, generated C or ELF on every episode.

production_cli.py differs from the frozen CLI only in importing production_projection. Scenario validation, observer_domain.authenticate_loaded calls, simulation, RNG/ID reset, private and summary in-memory logs, message ledger extraction, output validation, Parquet bytes, hash and sidecar timing cutoff retain the original path. All normal types/ranges/unsupported records and original replay remain in the unchanged native algorithm and production wrapper.

The proof control container must freshly execute the unchanged donor's 56 finite controls and four complete markets using the new actual build. It then executes 38 normal fixtures through the production wrapper, plus four production parent/native markets. Frames, all nine payload graphs, details and aliases must equal proof parent/native and production parent/native exactly. Prior PASS results are background only and never substitute for these new controls.

The production loader does not claim repeated hostile monkeypatch detection. External source/runtime/build/ABI/hash checks and complete authored controls own provenance evidence. Runtime mutation audit results apply to the unchanged proof path only.

The screen uses two arms in one image: observer_parent and native_projection, both through production_cli. It keeps 56 serial ordinary runs, 30 measured runs, 46 official verifier invocations and 184 gates. Every import, initialization, simulation, output write and hash remains in the real CLI and container timers. No data-dependent prewarming or excluded initialization is allowed. Performance changes compare production native with production observer; prior proof timing may diagnose overhead but does not establish new algorithmic acceleration.

This source-only preparation does not establish a speed gain, private score, rank, full71 PASS or competition submission readiness.
