"""Build-only hash/copy binding; never import the participant or native module."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
DONOR = HERE.parent / "native_canonical_projection_v2"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if (HERE / "native").exists() or (HERE / "DEPLOYMENT.json").exists():
        raise ValueError("new production deployment destination required")
    sources = json.loads((HERE / "SOURCE_PREPARATION_RECEIPT.json").read_text())
    for row in sources["files"]:
        path = HERE / row["path"]
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("production source freeze changed")
    build = DONOR / "artifacts/build_v2"
    receipt = json.loads((build / "BUILD_RECEIPT.json").read_text())
    extension = build / receipt["extension"]["path"]
    if (receipt.get("build_succeeded") is not True or sha(extension) != receipt["extension"]["sha256"]
            or sha(DONOR / "SOURCE_PREPARATION_RECEIPT.json") != sources["donor_source_receipt_sha256"]
            or sha(DONOR / "native_projection.pyx") != sources["native_pyx_sha256"]):
        raise ValueError("actual unchanged proof donor build/source differs")
    runtime = json.loads((HERE / "RUNTIME_PINS.json").read_text())
    for row in runtime["files"]:
        for owner in (HERE, DONOR):
            path = owner / "runtime" / row["path"]
            if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
                raise ValueError("production/proof runtime source changed")
    (HERE / "native").mkdir()
    destination = HERE / "native" / extension.name
    shutil.copyfile(extension, destination)
    if sha(destination) != receipt["extension"]["sha256"]:
        raise ValueError("copied deployment extension differs")
    deployment = {"schema": "t3-production-native-projection-deployment-v1", "candidate": HERE.name,
        "extension_path": "native/" + destination.name, "extension_sha256": sha(destination),
        "extension_bytes": destination.stat().st_size, "abi": receipt["abi"],
        "donor_build_receipt_sha256": sha(build / "BUILD_RECEIPT.json"),
        "donor_source_receipt_sha256": sources["donor_source_receipt_sha256"],
        "native_pyx_sha256": sources["native_pyx_sha256"],
        "production_source_receipt_sha256": sha(HERE / "SOURCE_PREPARATION_RECEIPT.json"),
        "runtime_pins_sha256": sha(HERE / "RUNTIME_PINS.json"),
        "source_only": False, "native_imported": False, "market_executed": False, "timing_claim": False}
    (HERE / "DEPLOYMENT.json").write_text(json.dumps(deployment, indent=2) + "\n")


if __name__ == "__main__":
    main()
