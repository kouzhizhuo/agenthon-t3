"""Fresh proof and production complete-state controls; external untimed audit."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys

HERE = Path(__file__).resolve().parent
DONOR = HERE.parent / "native_canonical_projection_v2"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("new full production control output required")
    args.out.mkdir(parents=True)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[name] = "1"
    report = {"schema": "t3-production-native-projection-controls-v1", "cases": [], "failures": [],
        "rankable": False, "timing_claim": False, "official_gate": False}
    def launch(source, arguments, log):
        with log.open("xb") as stream:
            completed = subprocess.run([sys.executable, "-B", str(source), *arguments], stdout=stream,
                stderr=subprocess.STDOUT, env=dict(os.environ), cwd=str(source.parent), timeout=900)
        if completed.returncode:
            raise ValueError("proof/production control worker failed: " + str(log))
    try:
        # The unchanged proof workers use the exact new actual donor build.
        launch(DONOR / "controls.py", ["--receipt", args.receipt, "--out", str(args.out / "proof")], args.out / "proof.log")
        proof = json.loads((args.out / "proof/RESULT.json").read_text())
        finite_proof = json.loads((args.out / "proof/FINITE_RESULT.json").read_text())
        assert proof["all_passed"] and finite_proof["all_passed"] and len(finite_proof["cases"]) == 56
        launch(HERE / "production_finite_controls.py", ["--out", str(args.out / "PRODUCTION_FINITE_RESULT.json")], args.out / "production-finite.log")
        finite = json.loads((args.out / "PRODUCTION_FINITE_RESULT.json").read_text())
        assert finite["all_passed"] and len(finite["cases"]) == 38
        for arm in ("parent", "native"):
            launch(HERE / "production_semantic_worker.py", ["--runtime", str(HERE / "runtime"),
                "--receipt", args.receipt, "--arm", arm, "--out", str(args.out / arm)], args.out / (arm + ".log"))
        # Only exact authored untimed worker data is read here; independent saved
        # audit uses its inert protocol decoder rather than executing pickle.
        values = [pickle.loads((folder / "SEMANTIC_VALUES.pkl").read_bytes()) for folder in
            (args.out / "proof/parent", args.out / "proof/native", args.out / "parent", args.out / "native")]
        sys.path.insert(0, str(HERE / "runtime"))
        from bootstrap import activate
        activate()
        import pandas as pd
        assert all(len(rows) == 4 for rows in values)
        for index in range(4):
            expected = values[0][index]
            rows = [value[index] for value in values]
            assert all(row["seed"] == (81009, 82009, 83009, 84009)[index] for row in rows)
            for actual in rows[1:]:
                assert expected["details"] == actual["details"], "observer/private/summary/book/pop details differ"
                for a, b in zip(expected["frames"], actual["frames"]):
                    pd.testing.assert_frame_equal(a, b, check_exact=True, check_dtype=True, rtol=0, atol=0)
                assert expected["payload"] == actual["payload"], "complete nine payload state/alias/RNG/ID/diagnostic graph differs"
            witness = rows[-1]["projection_witness"]
            assert witness["native_projection_active"] is True and witness["fallback_used"] is False
            assert witness["native_load_count"] == 1
            assert witness["typed_numeric_write_rows"] == len(rows[-1]["frames"][0])
            assert witness["python_sort_key_callbacks"] == 0
            report["cases"].append({"seed": expected["seed"], "passed": True,
                "trace_rows": len(expected["frames"][0]), "message_rows": len(expected["frames"][1]),
                "details": expected["details"], "production_native_witness": witness,
                "three_way_parent_proof_production_complete_equal": True,
                "production_parent_equal": True})
        report.update(all_passed=True, proof_finite_cases=56, production_finite_cases=38,
            full_market_cases=4, proof_complete_market_cases=4, production_complete_market_cases=4,
            production_native_receipt=finite["native_receipt"], proof_native_receipt=finite_proof["native_receipt"])
    except Exception as error:
        report["all_passed"] = False
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    report["controls_source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (args.out / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
