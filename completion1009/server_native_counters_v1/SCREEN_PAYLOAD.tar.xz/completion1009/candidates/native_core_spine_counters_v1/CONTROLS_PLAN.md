The prepared controls target `native_core_spine_counters_v1`; they have not been run. This candidate inherits the original 65 finite controls and four canonical/native market checks, then adds the 30 counter cases below. Their first gate is a successful CPython 3.11/Cython 3.1.3 receipt with this candidate's own build schema/source/extension, and any failure blocks performance or submission claims. Whole official Linux workload validation remains a separate parent-task gate.

## Added actual compiled counter controls

- Each of the ten slots is exercised through its real scheduler/strategy operation three times, starting at UINT64_MAX-1, giving UINT64_MAX, UINT64_MAX+1 and UINT64_MAX+2. A paired unseeded fixture records each operation's exact ten-counter deltas and business snapshot, including added exchange/book fields. The seeded fixture must match exact agent/exchange/book values, queue/ledger, RNG, IDs and clocks after each operation. General graph alias topology is checked by the four inherited full-market controls rather than this value-encoded finite snapshot.
- Each slot repeats those real operations starting at the arbitrary-precision value 10**400, proving continuation beyond the typed range. Exchange counters use normal sends and production pops rather than a new direct exchange test dispatch.
- Atomic invalid-seed refusal covers wrong/missing/extra keys, non-dict/dict subclass, str-subclass keys, negative, bool, NumPy int64 and int subclass values. The original count values and unseeded marker must remain unchanged after each rejection. A separate case rejects an invalid seed on an already huge-spilled core and retains its values/sticky mark.
- Fresh witness dictionaries preserve key insertion order and cannot mutate core values. Valid seeding remains visibly and permanently marked even after reseeding zeros.
- A combined receive/act transition spills two slots into the same storage list and checks their independent exact continuation and business snapshots.
- Pop and requeue counts commit before an admitted debug hook raises; send commits after queue push and before the original ledger fails on a test-only malformed batch submessage; receive commits before a missing-order warning promoted to an exception. Seeded and unseeded business exception residue agrees.
- Seeded production capture is refused without appending an episode receipt. Replacing the compiled seed facade export is refused by native binding admission.

This is 20 per-slot cases plus three seed/snapshot, one shared-spill, four exception-residue, one capture-refusal and one export-refusal cases: 30 new cases, 95 total finite cases. These are source-prepared expectations, not execution results.

## Minimum Linux proof and performance comparison

Materialize fresh independent 62-file snapshots for frozen native v1 and this candidate. Keep the same CPython/dependency/Cython/compiler recipe in one image, with separate directories, preflight bindings and build receipts; both modules can retain name `native_spine` because arms run in separate fresh processes. One image build generates the two actual extensions. Authenticate actual generated C, ELF, ABI, source/receipt hashes and seeded=false witnesses.

Run this candidate's 95 finite cases and four canonical/candidate complete-state markets before timing. Run the frozen v1 inherited controls if required by the server proof contract. Then compare only v1 and counters on the same five original units, including the entire five-member batch, with one warmup and three measured repeats per arm/unit. Rotate order and retain raw output/files and paired correctness checks. Pass `started=ENTRY_STARTED` identically to both direct host probes so import/native admission work is included in the full CLI timer. Preserve original np.clip latency and all proof instrumentation in both arms. Host/daemon timing includes its declared overhead and must remain separate from CLI timing.

Record actual ten-counter equality across paired unseeded runs, `pop == ttl_messages`, complete trace/message bytes/dtypes/counts, actual sidecar hashes/ratios, batch order/fresh isolation and resource/cleanup receipts. Do not compare the old finite-proof seconds with this protocol. This experiment needs no publication or formal submission and provides only the small counter change's paired evidence. No gain is assumed before it runs.

## Prepared finite controls

- Actual native calendar vs CPython C heapq ordering for huge builtin PyLong times, NumPy scalar times, equal dataclass payloads, same-UID different payloads and shared raw-message aliases.
- Four strategies across initial/open/closed wake, empty/one-sided/two-sided spread and closed spread; exact state, queue, ledger, original RNG, IDs and kernel clocks.
- Accepted/executed/partial/full/missing/cancelled notifications, side-specific holdings, original warnings and live order mutations.
- Production native one-pop vs separately named test-only original runner fixture, comparing each state after batch submessages, busy requeue and the original previous-clock stop boundary.
- Actual native debug hook with a live bound batch list append and list rebinding after the first receive; original submessage UID/causal sequencing and changing compute/additional delay.
- Replaced original callable defaults and replaced compiled exports must be refused while preserving the subsequent original bindings.

## Prepared whole-market controls

The four complete deterministic markets use uniform latency; delayed exchange protocol; log-normal latency; and default latency. Each uses the four original agent families and original matching. Canonical/native processes compare trace and message frames, exact dtypes/values/Parquet bytes, logical complete business state with aliases and pending queue, RNG states, Message/Order counters, warnings and every pop. Wall-clock fields and only the new private core/calendar representation are excluded; business state is not normalized away.

The native witness must show a receipt-bound loaded `.so`, no fallback, strategy acts and book bridges. The result stores build provenance and source inventories, and refuses overwritten evidence. An actual compiled witness is necessary but insufficient for official speed or ranking.

## Further required before a submission

Add strict negative tests for builtin-ID range/types, unknown strategy/latency/book/oracle classes, instance overrides, Gym/debug, tampered generated C/source/ABI/extension receipt, and kernel installation restoration on early exceptions. Expand finite coverage to default/no-model latency and integer overflow/warning edges, every rare protocol notification, repeated episodes and broadcast/requeue/pending-stop aliases. Add fixture checks for malformed depth and custom comparison failure only if the admitted producer domain is expanded; those domains are excluded now.

Review official command line, archive layout, output file names and schema, dtype/value/trace ordering, true complete horizon and pop counts, zero GPU accounting, process wall/RSS accounting and all hidden-scenario families before packaging. Run a paired complete Linux performance screen only after semantics pass and with the proof instrumentation explicitly identified. The parent task owns execution and formal submission opportunity accounting.
