"""Strict whole-episode gate with separate Python/native provenance proofs."""
import importlib
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import sys
from provenance import HERE, sha, abi, dependencies, candidate_sources

_module = None
_receipt = None
_captured = None
_native_bindings = None

def native_binding_token(module):
    """Identity plus mutable defaults/constants of the loaded compiled exports."""
    from binding_audit import scalar
    result = []
    def capture(owner, name, value):
        defaults = scalar(getattr(value, "__defaults__", None))
        kwdefaults = scalar(getattr(value, "__kwdefaults__", None))
        constants = scalar(value)
        result.append((owner, name, value, defaults, kwdefaults, constants))
    for name, value in vars(module).items():
        if name.startswith("__"):
            continue
        capture(module, name, value)
        if isinstance(value, type) and value.__module__ == module.__name__:
            for method, descriptor in vars(value).items():
                capture(value, method, descriptor)
    return result

def check_native_bindings():
    from binding_audit import scalar
    for owner, name, original, defaults, kwdefaults, constants in _native_bindings:
        value = vars(owner).get(name)
        if value is not original or scalar(getattr(value, "__defaults__", None)) != defaults or scalar(getattr(value, "__kwdefaults__", None)) != kwdefaults or scalar(value) != constants:
            raise ValueError("loaded native binding mutated: " + name)

def load_native(receipt_path):
    """Require one actual receipt-bound extension, never a Python substitute."""
    global _module, _receipt, _captured, _native_bindings
    receipt_path = Path(receipt_path).resolve()
    receipt = json.loads(receipt_path.read_text())
    spec = json.loads((HERE / "compile_spec.json").read_text())
    if receipt.get("schema") != "t3-native-core-spine-counters-build-v1" or receipt.get("candidate") != "native_core_spine_counters_v1" or receipt.get("build_succeeded") is not True:
        raise ValueError("native spine has no successful build receipt")
    if receipt.get("abi") != abi() or receipt.get("cython") != spec["cython"]:
        raise ValueError("native spine ABI/Cython receipt differs")
    if receipt.get("dependencies") != dependencies(spec):
        raise ValueError("native spine dependency receipt differs")
    if receipt.get("candidate_sources") != candidate_sources():
        raise ValueError("native spine candidate sources differ from compiled receipt")
    for field, name in (("compile_spec_sha256", "compile_spec.json"),
                        ("runtime_pins_sha256", "PINNED_RUNTIME.json"),
                        ("source_bindings_sha256", "SOURCE_BINDINGS.json")):
        if receipt.get(field) != sha(HERE / name):
            raise ValueError("native spine provenance differs: " + name)
    if receipt.get("compile_flags") != spec["compile_flags"] or receipt.get("directives") != spec["directives"]:
        raise ValueError("native spine compiler recipe differs")
    build_root = receipt_path.parent
    record = receipt["extension"]
    extension = (build_root / record["path"]).resolve()
    if not extension.is_relative_to(build_root) or extension.suffix not in (".so", ".pyd"):
        raise ValueError("native spine extension path is invalid")
    if extension.stat().st_size != record["bytes"] or sha(extension) != record["sha256"]:
        raise ValueError("native spine extension bytes differ")
    generated = receipt.get("generated_c", {})
    if not generated:
        raise ValueError("native spine generated C receipt absent")
    for relative, digest in generated.items():
        path = (build_root / relative).resolve()
        if not path.is_relative_to(build_root) or sha(path) != digest:
            raise ValueError("native spine generated C differs")
    import binding_audit
    binding_audit.source_manifest()
    pins = binding_audit.static_admission()
    if pins.get("runtime_pins_sha256") != sha(HERE / "PINNED_RUNTIME.json") or pins.get("candidate_python_sources") != binding_audit.source_files():
        raise ValueError("native spine source-binding evidence differs from current source")
    existing = sys.modules.get("native_spine")
    if existing is None:
        module_spec = importlib.util.spec_from_file_location("native_spine", extension)
        if module_spec is None or not isinstance(module_spec.loader, importlib.machinery.ExtensionFileLoader):
            raise ValueError("native spine requires ExtensionFileLoader")
        module = importlib.util.module_from_spec(module_spec)
        sys.modules["native_spine"] = module
        try:
            module_spec.loader.exec_module(module)
        except BaseException:
            sys.modules.pop("native_spine", None)
            raise
    else:
        module = existing
    if Path(module.__file__).resolve() != extension or not isinstance(module.__spec__.loader, importlib.machinery.ExtensionFileLoader):
        raise ValueError("native spine loaded origin differs")
    if _module is not None:
        check_native_bindings()
    _module, _receipt = module, {"receipt_path": str(receipt_path), "receipt_sha256": sha(receipt_path),
        "extension_path": str(extension), "extension_sha256": record["sha256"], "abi": receipt["abi"]}
    cross_bindings(module)
    _captured = binding_audit.callable_bindings()
    _native_bindings = native_binding_token(module)
    return module

def native_receipt():
    if _receipt is None:
        raise ValueError("native spine provenance not admitted")
    return dict(_receipt)

def cross_bindings(module=None):
    module = _module if module is None else module
    if module is None:
        raise ValueError("native spine extension unavailable")
    from abides_fork import agents
    from abides_markets.agents.trading_agent import TradingAgent
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from t3_canonical_engine import CanonicalKernel
    expected = {agents.NoiseTrader: 1, agents.MarketMaker: 2, agents.ValueTrader: 3, agents.MomentumTrader: 4}
    if module.STRATEGIES != expected or module.ExchangeAgent is not ExchangeAgent or module.TradingAgent is not TradingAgent:
        raise ValueError("native spine strategy/owner binding differs")
    if module.CanonicalKernel is not CanonicalKernel or not issubclass(module.NativeSpineKernel, CanonicalKernel):
        raise ValueError("native spine canonical facade binding differs")
    if module.DEFAULT_CANCEL_METADATA is not TradingAgent.cancel_order.__defaults__[-1]:
        raise ValueError("native spine cancellation metadata identity differs")
    if module.PROOF_COUNTER_KEYS != ("pop", "requeue", "wake", "receive", "act", "exchange_query",
            "exchange_book_bridge", "raw_strategy_bridge", "send", "oracle_bridge") or type(module.PROOF_COUNTER_KEYS) is not tuple:
        raise ValueError("native proof counter key schema differs")
    # Every raw class imported into the compiled transition must be the exact
    # original owner class, including rare notification branches.
    for name, value in vars(module).items():
        if isinstance(value, type) and value.__module__.startswith(("abides_core", "abides_markets", "abides_fork")):
            owner = importlib.import_module(value.__module__)
            expected_value = owner
            for piece in value.__qualname__.split("."):
                expected_value = getattr(expected_value, piece)
            if value is not expected_value:
                raise ValueError("native spine raw class identity differs: " + name)
    if sha(_receipt["extension_path"]) != _receipt["extension_sha256"]:
        raise ValueError("native extension changed after admission")

def admit_episode(kernel):
    """Refuse unsupported state before initialize; never midstream fallback."""
    if _module is None or type(kernel) is not _module.NativeSpineKernel:
        raise ValueError("native spine kernel requires admitted native extension")
    import binding_audit
    # This proof prototype pays the full live-default/global/class-constant
    # check per episode, with only the exact installed facade normalized.
    binding_audit.static_admission(allowed_kernel=_module.NativeSpineKernel)
    binding_audit.check_callable_bindings(_captured)
    check_native_bindings()
    cross_bindings()
    from abides_core import abides
    from abides_fork.config import ScenarioLatencyModel
    from abides_core.latency_model import LatencyModel
    from abides_markets.oracles.sparse_mean_reverting_oracle import SparseMeanRevertingOracle
    from abides_markets.order_book import OrderBook
    from abides_markets.orders import LimitOrder
    from abides_markets.agents.exchange_agent import ExchangeAgent
    if abides.Kernel is not _module.NativeSpineKernel:
        raise ValueError("native spine kernel installation differs")
    if type(kernel.agents) is not list or not kernel.agents or type(kernel.agents[0]) is not ExchangeAgent:
        raise ValueError("native spine requires the original exchange-first list")
    if any(type(a.id) is not int or a.id != i for i, a in enumerate(kernel.agents)):
        raise ValueError("native spine requires dense builtin integer IDs")
    if len(kernel.agents) > sys.maxsize:
        raise ValueError("native spine dense IDs exceed native index range")
    for value, label in [(kernel, "Kernel")] + [(a, "agent[" + str(a.id) + "]") for a in kernel.agents]:
        binding_audit.reject_instance_overrides(value, label)
        # Cython facade methods are cyfunctions rather than FunctionType.
        methods = {name for base in type(value).__mro__ for name, member in vars(base).items()
            if callable(member) or isinstance(member, (property, staticmethod, classmethod))}
        if methods.intersection(vars(value)):
            raise ValueError("native spine refuses instance method override: " + label)
    for a in kernel.agents[1:]:
        if type(a) not in _module.STRATEGIES:
            raise ValueError("native spine unknown strategy")
        for name in ("holdings", "orders", "known_bids", "known_asks", "last_trade",
                     "daily_close_price", "stream_history", "transacted_volume"):
            if type(getattr(a, name)) is not dict:
                raise ValueError("native spine requires original dictionary owner: " + name)
        for order in a.orders.values():
            if type(order) is not LimitOrder:
                raise ValueError("native spine refuses non-plain initial orders")
            binding_audit.reject_instance_overrides(order, "order")
    latency = kernel.agent_latency_model
    if latency is not None:
        if type(latency) not in (ScenarioLatencyModel, LatencyModel):
            raise ValueError("native spine unpinned latency owner")
        binding_audit.reject_instance_overrides(latency, "latency")
    oracle = getattr(kernel, "oracle", None)
    if type(oracle) is not SparseMeanRevertingOracle:
        raise ValueError("native spine unpinned oracle owner")
    binding_audit.reject_instance_overrides(oracle, "oracle")
    for book in kernel.agents[0].order_books.values():
        if type(book) is not OrderBook:
            raise ValueError("native spine unpinned book owner")
        binding_audit.reject_instance_overrides(book, "book")
