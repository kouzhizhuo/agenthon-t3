"""Stdlib source-only staging; independent exact candidate/wrapper PASS seals."""
import argparse
import ast
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import (BASE, CANDIDATE, BASELINE, SOURCE_RECEIPT, SOURCE_RECEIPT_SHA256, CANDIDATE_REVIEW_SHA256, BASELINE_PINS_SHA256,
    GENERATOR, GENERATOR_SHA256, SCHEMA_DRIVER_SHA256, ARMS, CONTROL_ARMS, SINGLES, BATCH,
    MAX_FILES, MAX_BYTES, safe_name, sha, inventory, write, require_review, verify_payload)
HERE = Path(__file__).resolve().parent
COMPLETION = HERE.parent
CONTROL = ("common.py", "controller.py", "entry.py", "construction.py", "prepare_build_schema_v1.py", "control_scenario.json", "Dockerfile")
HOST_OWNER = COMPLETION / "server_native_canonical_scheduler_v3/materialized_v1/host"


def copy(source, target):
    if source.is_symlink() or not source.is_file(): raise ValueError("ordinary frozen source required")
    data = source.read_bytes()
    if source.suffix == ".py": ast.parse(data); compile(data, str(source), "exec", dont_inherit=True)
    target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, target); target.chmod(0o644)
    if sha(source) != sha(target): raise ValueError("actual source copy differs")


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--archive", type=Path); parser.add_argument("--candidate-review", type=Path)
    parser.add_argument("--candidate-review-sha256"); parser.add_argument("--wrapper-review", type=Path)
    parser.add_argument("--wrapper-review-sha256")
    args = parser.parse_args()
    if args.out.exists() or args.archive is not None and args.archive.exists(): raise ValueError("fresh prototype/seal outputs required")
    candidate = COMPLETION / Path(CANDIDATE).relative_to("completion1009")
    baseline = COMPLETION / Path(BASELINE).relative_to("completion1009")
    receipt = candidate / SOURCE_RECEIPT
    if sha(receipt) != SOURCE_RECEIPT_SHA256: raise ValueError("exact frozen127 light typed Noise receipt differs")
    definition = json.loads(receipt.read_bytes())
    if (definition["schema"] != "t3-light-typed-noise-latency-market-frozen-source-v1"
            or definition["file_count"] != 127 or len(definition["files"]) != 127
            or definition["frozen_build_input"] is not True or definition["unfrozen"] is not False):
        raise ValueError("complete exact127 frozen light typed Noise sources required")
    baseline_receipt = baseline.parent / "RUNTIME_PINS.json"
    if sha(baseline_receipt) != BASELINE_PINS_SHA256: raise ValueError("unchanged original64 runtime receipt differs")
    baseline_definition = json.loads(baseline_receipt.read_bytes())
    baseline_pins = {row["path"]: {"bytes": row["bytes"], "sha256": row["sha256"]} for row in baseline_definition["files"]}
    if len(baseline_pins) != 64 or inventory(baseline) != baseline_pins: raise ValueError("unchanged complete original64 runtime required")
    candidate_review_hash = wrapper_review_hash = wrapper_receipt_hash = None
    if args.archive is not None:
        for path, digest in ((args.candidate_review, args.candidate_review_sha256), (args.wrapper_review, args.wrapper_review_sha256)):
            if path is None or digest is None or sha(path) != digest: raise ValueError("exact independent candidate/wrapper source review required")
        if args.candidate_review_sha256 != CANDIDATE_REVIEW_SHA256:
            raise ValueError("exact reviewed coherent candidate report SHA required")
        require_review(args.candidate_review, SOURCE_RECEIPT_SHA256, definition["files"], "PASS_SOURCE_ONLY")
        wrapper_receipt = HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"
        wrapper = json.loads(wrapper_receipt.read_bytes())
        wrapper_receipt_hash = sha(wrapper_receipt)
        if wrapper.get("source_frozen") is not True: raise ValueError("frozen wrapper source required")
        require_review(args.wrapper_review, wrapper_receipt_hash, wrapper["files"])
        for row in wrapper["files"]:
            path = HERE / safe_name(row["path"])
            if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
                raise ValueError("reviewed wrapper bytes changed")
        candidate_review_hash, wrapper_review_hash = sha(args.candidate_review), sha(args.wrapper_review)
    args.out.mkdir(parents=True)
    for row in definition["files"]:
        path = candidate / safe_name(row["path"])
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]: raise ValueError("frozen candidate changed")
        copy(path, args.out / CANDIDATE / row["path"])
    copy(receipt, args.out / CANDIDATE / SOURCE_RECEIPT)
    for name in baseline_pins: copy(baseline / name, args.out / BASELINE / name)
    copy(baseline_receipt, args.out / Path(BASELINE).parent / "RUNTIME_PINS.json")
    generator = COMPLETION / Path(GENERATOR).relative_to("completion1009")
    if sha(generator) != GENERATOR_SHA256 or sha(HERE / "prepare_build_schema_v1.py") != SCHEMA_DRIVER_SHA256:
        raise ValueError("exact original baseline schema generator/driver source differs")
    copy(generator, args.out / GENERATOR)
    for name in CONTROL: copy(HERE / name, args.out / "control" / name)
    for name in ("verify_linux.py", "verify_public.py", "fetch_evaluation.py"): copy(HOST_OWNER / name, args.out / "host" / name)
    sources = {"baseline": {"bytes": (baseline / "agent.py").stat().st_size, "sha256": sha(baseline / "agent.py")}}
    sources.update({arm: {"bytes": (candidate / "production_cli.py").stat().st_size, "sha256": sha(candidate / "production_cli.py")} for arm in ARMS[1:]})
    plan = {"schema": "t3-light-typed-noise-latency-market-market-source-plan-v1", "candidate": CANDIDATE,
        "candidate_source_receipt_sha256": SOURCE_RECEIPT_SHA256, "candidate_sources": definition["files"],
        "baseline_sources": baseline_pins, "baseline_pins_sha256": BASELINE_PINS_SHA256,
        "generator_sha256": GENERATOR_SHA256, "schema_driver_sha256": SCHEMA_DRIVER_SHA256,
        "control_sources": {name: {"bytes": (HERE / name).stat().st_size, "sha256": sha(HERE / name)} for name in CONTROL},
        "host_sources": inventory(args.out / "host"), "actual_entry_sources": sources,
        "prototype_only": args.archive is None, "candidate_review_sha256": candidate_review_hash,
        "wrapper_review_sha256": wrapper_review_hash, "wrapper_source_receipt_sha256": wrapper_receipt_hash,
        "base": BASE, "arms": list(ARMS), "control_arms": list(CONTROL_ARMS), "single_units": list(SINGLES), "batch_unit": BATCH,
        "warmups": 1, "measured_repeats": 2, "ordinary_runs": 60, "execution_containers": 61, "phase_runs": 0,
        "measured_runs": 30, "official_verifier_calls": 45, "official_gate_passes": 180, "actual_market_episodes": 102,
        "control_market_episodes": 6, "isolations": 15, "official_native_admission_scenarios": 9,
        "native_builds": 1, "Cython_translation_preflight": True, "all_generated_C_objects_ELF_logs_retained": True,
        "same_ELF_Noise_control_children": 3, "same_ELF_latency_control_children": 3,
        "latency_control_roster": {"models": 24, "transforms": 96, "admission": 19, "lifecycle": 23},
        "require_translation_C_equal_build_C": True,
        "construction_resources_not_official_timing": True, "actual_execution": False, "rankable": False,
        "diagnostic_only": True, "full71": False, "submission_ready": False, "measured_production_instrumented": False,
        "throughput_calculation": "actual N divided by settled Docker runtime T per run; retain per-unit mean and median; five-unit mean uses per-unit medians"}
    write(args.out / "SCREEN_PLAN.json", plan)
    if args.archive is not None:
        copy(args.candidate_review, args.out / "source_review/INDEPENDENT_CANDIDATE_SOURCE_REVIEW.json")
        copy(args.wrapper_review, args.out / "source_review/INDEPENDENT_WRAPPER_SOURCE_REVIEW.json")
        copy(wrapper_receipt, args.out / "source_review/WRAPPER_SOURCE_PREPARATION_RECEIPT_v1.json")
        for row in wrapper["files"]:
            copy(HERE / row["path"], args.out / "wrapper_source" / row["path"])
    pins = inventory(args.out)
    if len(pins) + 1 > MAX_FILES or sum(row["bytes"] for row in pins.values()) > MAX_BYTES:
        raise ValueError("bounded source payload exceeded")
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-light-typed-noise-latency-market-market-manifest-v1", "files": pins})
    if args.archive is not None:
        verify_payload(args.out)
        with tarfile.open(args.archive, "w:xz", format=tarfile.PAX_FORMAT) as archive:
            for name in sorted(inventory(args.out)):
                data = (args.out / name).read_bytes(); member = tarfile.TarInfo(name)
                member.size = len(data); member.mode = 0o644; member.mtime = 0; member.uid = member.gid = 0
                archive.addfile(member, io.BytesIO(data))
    print(json.dumps({"prototype_only": args.archive is None, "actual_execution": False,
        "archive_sha256": None if args.archive is None else sha(args.archive)}))


if __name__ == "__main__": main()
