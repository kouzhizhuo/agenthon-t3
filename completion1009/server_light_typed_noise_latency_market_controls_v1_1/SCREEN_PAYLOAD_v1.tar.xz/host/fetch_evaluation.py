"""Fetch pinned public task data and validate every reference against its LFS pointer.

The data is mounted only into the evaluator. Simulation containers receive only
scenario inputs. No public reference, score, or task solution enters the image.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile
import urllib.request


def fetch(url):
    with urllib.request.urlopen(url, timeout=180) as response:
        return response.read()


def archive(repo, ref, out):
    if out.exists() or out.is_symlink():
        raise ValueError('fresh public archive destination required')
    raw = fetch('https://codeload.github.com/' + repo + '/tar.gz/' + ref)
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as source:
        members = []
        archive_root = None
        seen = set()
        # Validate the whole archive before materializing any files. Codeload
        # archives have exactly one relative directory prefix; normalization
        # must never hide a leading absolute path, dot component, or second root.
        for member in source.getmembers():
            name = member.name
            if (not name or '\\' in name or '\x00' in name
                    or PurePosixPath(name).is_absolute()):
                raise ValueError('unsafe public archive member name')
            clean_name = name[:-1] if member.isdir() and name.endswith('/') else name
            parts = clean_name.split('/')
            if any(part in ('', '.', '..') for part in parts):
                raise ValueError('unsafe public archive path component')
            if member.type not in (tarfile.DIRTYPE, tarfile.REGTYPE, tarfile.AREGTYPE):
                raise ValueError('special public archive member refused')
            if archive_root is None:
                archive_root = parts[0]
            if parts[0] != archive_root:
                raise ValueError('one common public archive root required')
            if len(parts) == 1 and not member.isdir():
                raise ValueError('public archive prefix must be a directory')
            normalized = '/'.join(parts)
            if normalized in seen:
                raise ValueError('duplicate public archive member')
            seen.add(normalized)
            members.append((member, parts[1:]))
        if not members:
            raise ValueError('empty public archive refused')
        member_types = {'/'.join([archive_root] + parts): member.type
                        for member, parts in members}
        for _, parts in members:
            for length in range(len(parts)):
                parent = '/'.join([archive_root] + parts[:length])
                if parent in member_types and member_types[parent] != tarfile.DIRTYPE:
                    raise ValueError('public archive file used as parent directory')
        out.mkdir(parents=True)
        for member, parts in members:
            if not parts:
                continue
            target = out.joinpath(*parts)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.extractfile(member) as stream:
                    target.write_bytes(stream.read())
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    out = Path(args.out).resolve()
    out.mkdir(parents=True)
    ref = 'bffb57227f796f9fa769a23d01fc364bee14a119'
    kit = out / 'track3'
    toolkit = out / 'toolkit'
    track_hash = archive('Agenthon-2026/track3-simulation-public', ref, kit)
    common_hash = archive('Agenthon-2026/Agenthon2026-public', 'v2.5.1', toolkit)
    references = out / 'references'
    references.mkdir()
    rows = []
    for source in sorted((kit / 'units').iterdir()):
        if not source.is_dir() or source.name == 't3-EXAMPLE-vectorized-matching':
            continue
        destination = references / source.name
        destination.mkdir()
        for path in source.rglob('*'):
            if not path.is_file() or any(part.startswith('._') for part in path.parts):
                continue
            relative = path.relative_to(source)
            if path.suffix not in ('.parquet', '.json', '.toml'):
                continue
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if path.suffix == '.parquet':
                pointer = path.read_text()
                oid = next(line.split(':', 1)[1] for line in pointer.splitlines() if line.startswith('oid sha256:'))
                size = int(next(line.split()[1] for line in pointer.splitlines() if line.startswith('size ')))
                url = 'https://media.githubusercontent.com/media/Agenthon-2026/track3-simulation-public/' + ref + '/units/' + source.name + '/' + relative.as_posix()
                raw = fetch(url)
                if len(raw) != size or hashlib.sha256(raw).hexdigest() != oid or raw[:4] != b'PAR1':
                    raise ValueError('reference LFS mismatch: ' + str(relative))
                target.write_bytes(raw)
                rows.append({'unit': source.name, 'path': relative.as_posix(), 'sha256': oid, 'bytes': size})
            else:
                shutil.copyfile(path, target)
        print(source.name, flush=True)
    if len(list(references.iterdir())) != 71 or len(rows) != 190:
        raise ValueError('complete pinned public roster required')
    (out / 'FETCH_RECEIPT.json').write_text(json.dumps({'track_ref': ref, 'track_tar_sha256': track_hash,
        'toolkit_ref': 'v2.5.1', 'toolkit_tar_sha256': common_hash, 'public_units': 71,
        'references': rows, 'runtime_reference_access': False}, indent=2) + '\n')


if __name__ == '__main__':
    main()
