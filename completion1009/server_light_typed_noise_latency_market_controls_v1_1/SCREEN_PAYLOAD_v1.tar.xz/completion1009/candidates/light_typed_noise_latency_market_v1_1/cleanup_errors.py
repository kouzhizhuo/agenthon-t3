"""Cold/error-only evidence must never replace an active error via __str__."""


def detail(error):
    try:
        message = str(error)
    except BaseException:
        message = "<exception text unavailable>"
    return {"type": type(error).__name__, "message": message}


def attach(error, name, rows):
    try:
        setattr(error, name, list(rows))
    except BaseException:
        pass
