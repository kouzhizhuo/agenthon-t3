"""Stdlib source-data compile and lexical global audit; no participant imports."""
import ast
import builtins
import hashlib
import json
from pathlib import Path
import symtable

HERE = Path(__file__).resolve().parent
SOURCE_GLOBALS = {"__file__", "__name__", "__package__", "__cached__", "__spec__", "__builtins__"}


class UnevaluatedAnnotations(ast.NodeTransformer):
    """Preserve executable AST; erase only non-evaluated annotation expressions.

    Future-annotations signatures/module/class variable annotations are strings.
    Function-local variable annotations are not evaluated even without future.
    This is a name-only view; its rewritten body is never executed.
    """
    def __init__(self, future):
        self.future = future
        self.scopes = ["module"]
        self.erased = []

    def erase(self, node):
        if node is not None:
            self.erased.append({"line": node.lineno, "expression": ast.unparse(node),
                "names": sorted({child.id for child in ast.walk(node) if isinstance(child, ast.Name)})})
        return ast.Constant(value=None)

    def visit_FunctionDef(self, node):
        if self.future:
            for arg in node.args.posonlyargs + node.args.args + node.args.kwonlyargs:
                if arg.annotation is not None: arg.annotation = self.erase(arg.annotation)
            for arg in (node.args.vararg, node.args.kwarg):
                if arg is not None and arg.annotation is not None: arg.annotation = self.erase(arg.annotation)
            if node.returns is not None: node.returns = self.erase(node.returns)
        self.scopes.append("function")
        node = self.generic_visit(node)
        self.scopes.pop()
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self.scopes.append("class")
        node = self.generic_visit(node)
        self.scopes.pop()
        return node

    def visit_AnnAssign(self, node):
        if self.future or self.scopes[-1] == "function":
            node.annotation = self.erase(node.annotation)
        return self.generic_visit(node)


def analyze(path):
    data = path.read_bytes()
    tree = ast.parse(data, filename=str(path))
    compile(tree, str(path), "exec", dont_inherit=True)
    future = any(isinstance(node, ast.ImportFrom) and node.module == "__future__"
        and any(alias.name == "annotations" for alias in node.names) for node in tree.body)
    transform = UnevaluatedAnnotations(future)
    lexical = ast.unparse(ast.fix_missing_locations(transform.visit(tree)))
    table = symtable.symtable(lexical, "source_data_lexical_only", "exec")
    declared = {symbol.get_name() for symbol in table.get_symbols()
        if symbol.is_assigned() or symbol.is_imported() or symbol.is_namespace()}
    allowed = declared | SOURCE_GLOBALS | set(dir(builtins))
    unresolved, references = [], 0

    def visit(scope, scope_path):
        nonlocal references
        for symbol in scope.get_symbols():
            if symbol.is_referenced() and symbol.is_global():
                references += 1
                if symbol.get_name() not in allowed:
                    unresolved.append({"scope": scope_path, "name": symbol.get_name()})
        for child in scope.get_children():
            visit(child, scope_path + "." + child.get_name())

    visit(table, "module")
    return {"path": path.relative_to(HERE).as_posix(), "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(), "inert_compile_passed": True,
        "future_annotations": future, "unevaluated_annotations": transform.erased,
        "global_reference_count": references, "unresolved": unresolved}


def main():
    output = HERE / "PYTHON_SOURCE_AUDIT_LATENCY_v1.json"
    if output.exists(): raise ValueError("fresh Python source audit output required")
    paths = sorted(path for path in HERE.rglob("*.py")
        if not any(part in ("__pycache__", "__MACOSX", "build") or part.startswith("._") for part in path.relative_to(HERE).parts))
    rows = [analyze(path) for path in paths]
    unresolved = [dict(path=row["path"], **item) for row in rows for item in row["unresolved"]]
    report = {"schema": "t3-composite-python-inert-source-audit-v1", "source_only": True,
        "participant_imported": False, "native_built": False, "market_executed": False,
        "runtime_pass": False, "speed_claim": False, "file_count": len(rows), "files": rows,
        "unresolved": unresolved, "all_declared": not unresolved,
        "limits": "Finite lexical name declaration check; excludes only unevaluated annotations. Does not prove runtime binding identity, dynamic namespace resolution, Cython translation, output semantics or performance."}
    output.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"file_count": len(rows), "all_declared": not unresolved, "unresolved": unresolved}))
    if unresolved: raise ValueError("undeclared Python executable lexical globals")


if __name__ == "__main__": main()
