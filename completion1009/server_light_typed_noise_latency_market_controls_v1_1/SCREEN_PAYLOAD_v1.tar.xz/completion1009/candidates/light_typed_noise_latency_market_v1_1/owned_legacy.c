/*
 * Adapted only from the pinned NumPy 1.26.4 scalar MT/legacy/masked-fill
 * functions. No private NumPy object or exported internal symbol is used.
 * The two wide-word orders are separate whole-control variants; actual
 * same-image result/state evidence must select an order before integration.
 */
#include "owned_legacy.h"
#include <math.h>

static void t3_twist(t3_owned_state *state) {
  uint32_t y;
  int i;
  for (i = 0; i < 624 - 397; i++) {
    y = (state->key[i] & 0x80000000UL) | (state->key[i + 1] & 0x7fffffffUL);
    state->key[i] = state->key[i + 397] ^ (y >> 1) ^ (-(y & 1) & 0x9908b0dfUL);
  }
  for (; i < 624 - 1; i++) {
    y = (state->key[i] & 0x80000000UL) | (state->key[i + 1] & 0x7fffffffUL);
    state->key[i] = state->key[i + (397 - 624)] ^ (y >> 1) ^ (-(y & 1) & 0x9908b0dfUL);
  }
  y = (state->key[624 - 1] & 0x80000000UL) | (state->key[0] & 0x7fffffffUL);
  state->key[624 - 1] = state->key[397 - 1] ^ (y >> 1) ^ (-(y & 1) & 0x9908b0dfUL);
  state->pos = 0;
  state->twists++;
}

uint32_t t3_next32(t3_owned_state *state) {
  uint32_t y;
  if (state->pos == 624) t3_twist(state);
  y = state->key[state->pos++];
  y ^= (y >> 11);
  y ^= (y << 7) & 0x9d2c5680UL;
  y ^= (y << 15) & 0xefc60000UL;
  y ^= (y >> 18);
  state->words_consumed++;
  return y;
}

uint64_t t3_next64(t3_owned_state *state) {
  uint32_t first = t3_next32(state);
  uint32_t second = t3_next32(state);
  if (state->wide_high_first) return ((uint64_t)first << 32) | second;
  return ((uint64_t)second << 32) | first;
}

double t3_next_double(t3_owned_state *state) {
  int32_t a = t3_next32(state) >> 5;
  int32_t b = t3_next32(state) >> 6;
  return (a * 67108864.0 + b) / 9007199254740992.0;
}

double t3_legacy_gauss(t3_owned_state *state) {
  if (state->has_gauss) {
    const double temp = state->gauss;
    state->has_gauss = 0;
    state->gauss = 0.0;
    return temp;
  } else {
    double f, x1, x2, r2;
    do {
      x1 = 2.0 * t3_next_double(state) - 1.0;
      x2 = 2.0 * t3_next_double(state) - 1.0;
      r2 = x1 * x1 + x2 * x2;
      if (r2 >= 1.0 || r2 == 0.0) state->normal_rejections++;
    } while (r2 >= 1.0 || r2 == 0.0);
    f = sqrt(-2.0 * log(r2) / r2);
    state->gauss = f * x1;
    state->has_gauss = 1;
    return f * x2;
  }
}

double t3_legacy_normal(t3_owned_state *state, double loc, double scale) {
  return loc + scale * t3_legacy_gauss(state);
}

double t3_legacy_lognormal(t3_owned_state *state, double mean, double sigma) {
  return exp(t3_legacy_normal(state, mean, sigma));
}

double t3_legacy_uniform(t3_owned_state *state, double lower, double range) {
  return lower + range * t3_next_double(state);
}

double t3_legacy_pareto(t3_owned_state *state, double a) {
  double exponential = -log(1.0 - t3_next_double(state));
  return exp(exponential / a) - 1;
}

static uint64_t t3_mask(uint64_t maximum) {
  maximum |= maximum >> 1;
  maximum |= maximum >> 2;
  maximum |= maximum >> 4;
  maximum |= maximum >> 8;
  maximum |= maximum >> 16;
  maximum |= maximum >> 32;
  return maximum;
}

uint64_t t3_default_int64_fill_one(t3_owned_state *state, uint64_t off, uint64_t range) {
  uint64_t value, mask;
  if (range == 0) return off;
  if (range <= 0xffffffffUL) {
    if (range == 0xffffffffUL) return off + (uint64_t)t3_next32(state);
    mask = t3_mask(range);
    do {
      value = (uint64_t)t3_next32(state) & mask;
      if (value > range) state->integer_rejections++;
    } while (value > range);
    return off + value;
  }
  if (range == 0xffffffffffffffffULL) return off + t3_next64(state);
  mask = t3_mask(range);
  do {
    value = t3_next64(state) & mask;
    if (value > range) state->integer_rejections++;
  } while (value > range);
  return off + value;
}

int t3_signbit(double value) { return signbit(value) != 0; }
