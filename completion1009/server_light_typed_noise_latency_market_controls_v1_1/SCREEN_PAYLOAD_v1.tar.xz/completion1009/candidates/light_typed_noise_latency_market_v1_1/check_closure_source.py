from pathlib import Path
import ast,re,json,hashlib
D=Path(__file__).resolve().parent
module=ast.parse((D/'check_source_normalize.py').read_bytes());ns={};keep=[n for n in module.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))];exec(compile(ast.fix_missing_locations(ast.Module(body=keep,type_ignores=[])),'stdlib_arena_normalizer','exec'),ns)
source=(D/'dynamic_arena_chain.pyx').read_text();pxd=(D/'dynamic_arena_chain.pxd').read_text();tree=ns['normalize'](source)
classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
blocks={m.group(1):m.group(2) for m in re.finditer(r'^cdef class (\w+):\n(.*?)(?=^cdef class |\Z)',pxd,re.M|re.S)}
if set(classes)!=set(blocks):raise ValueError((set(classes)-set(blocks),set(blocks)-set(classes)))
declared={};sigcount=0;missing=[]
for name,c in classes.items():
 fields=set();sigs={};methods={n.name:n for n in c.body if isinstance(n,ast.FunctionDef)}
 for line in blocks[name].splitlines():
  if '(' not in line:
   m=re.match(r'    cdef (?:public )?(?:unsigned long|unsigned int|\w+)(?: \*{1,2})? (.+)$',line)
   if m:fields.update(x.strip().lstrip('*') for x in m.group(1).split(','))
  else:
   m=re.match(r'    cdef .+? \*?(\w+)\(([^)]*)\)',line)
   if m:
    sigs[m.group(1)]=tuple(x.strip().split('=')[0].strip().split()[-1].lstrip('*') for x in m.group(2).split(','))
 for method,args in sigs.items():
  if method not in methods or tuple(x.arg for x in methods[method].args.args)!=args:missing.append(['signature',name,method,args])
 sigcount+=len(sigs)
 start=source.index('cdef class '+name+':');end=source.find('\ncdef class ',start+1)
 properties=set(re.findall(r'^    property (\w+):',source[start:] if end<0 else source[start:end],re.M))
 declared[name]=fields|set(methods)|properties
refs=0
links={'_orders':'OrderArena','orders':'OrderArena','_messages':'MessageArena','messages':'MessageArena','_owner':'NativeExchange','_scheduler':'ChainScheduler','ledger':'ColumnLedger','heap':'DeliveryHeap','arena':'MessageArena'}
for name,c in classes.items():
 for m in c.body:
  if not isinstance(m,ast.FunctionDef):continue
  for n in ast.walk(m):
   if isinstance(n,ast.Attribute) and isinstance(n.value,ast.Name) and n.value.id=='self':
    refs+=1
    if n.attr not in declared[name]:missing.append(['self',name,m.name,n.attr,n.lineno])
   if isinstance(n,ast.Attribute) and isinstance(n.value,ast.Attribute) and isinstance(n.value.value,ast.Name) and n.value.value.id=='self':
    target=links.get(n.value.attr)
    if target:
     refs+=1
     if n.attr not in declared[target]:missing.append(['receiver',name,m.name,target,n.attr,n.lineno])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'source_only':True,'normalized_AST_parse_only':True,'native_built':False,'runtime_pass':False,'speed_claim':False,'classes':list(classes),'cdef_signatures':sigcount,'typed_member_references':refs,'missing':missing,'pyx_sha256':sha(D/'dynamic_arena_chain.pyx'),'pxd_sha256':sha(D/'dynamic_arena_chain.pxd')}
(D/'STATIC_CYTHON_CLOSURE_PROGRESS_v1.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report))
