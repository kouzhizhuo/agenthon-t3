"""Stdlib lexical free-name audit; never imports participant source bodies."""
import ast
import builtins
import hashlib
import json
import re
import symtable
from pathlib import Path

HERE = Path(__file__).resolve().parent
C_IMPORT_NAMES = {"calloc", "realloc", "free", "uint32_t", "uint64_t", "UINT32_MAX",
                  "PyObject", "Py_INCREF", "Py_DECREF", "size_t", "memset", "isfinite",
                  "t3_legacy_normal", "t3_legacy_lognormal", "t3_legacy_uniform", "t3_legacy_pareto",
                  "t3_default_int64_fill_one", "t3_signbit", "isnan"}
C_STRUCT_NAMES = {"OrderSlot", "MessageSlot", "DeliveryRow", "t3_owned_state"}
C_BUILTIN_NAMES = {"NULL"}


def normalized_source(source):
    # Only the stdlib-backed normalizer function is executed. The candidate
    # body is parsed/unparsed as data and is never executed or imported.
    module = ast.parse((HERE / "check_source_normalize.py").read_bytes())
    keep = [node for node in module.body
            if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef))]
    namespace = {}
    exec(compile(ast.fix_missing_locations(ast.Module(body=keep, type_ignores=[])),
                 "stdlib_source_normalizer_only", "exec"), namespace)
    tree = namespace["normalize"](source)
    # C declarations without initializers are deliberately erased by the parse
    # normalizer. Restore their lexical binding as inert None assignments for
    # this name-only audit so local C structs do not become false globals.
    source_lines = source.splitlines()
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        names = []
        for line in source_lines[node.lineno - 1:node.end_lineno]:
            stripped = line.strip()
            if not stripped.startswith("cdef ") or "(" in stripped or "=" in stripped:
                continue
            match = re.match(r"cdef (?:unsigned (?:int|long)|[A-Za-z_]\w*)(?:\s+\*{0,2})?\s+(.+)$", stripped)
            if match is None:
                continue
            names.extend(name.strip().lstrip("*") for name in match.group(1).split(",")
                         if name.strip().lstrip("*").isidentifier())
        for name in sorted(set(names)):
            node.body.insert(0, ast.Assign(targets=[ast.Name(id=name, ctx=ast.Store())],
                                           value=ast.Constant(value=None)))
    return ast.unparse(ast.fix_missing_locations(tree))


def analyze(source):
    normalized = normalized_source(source)
    table = symtable.symtable(normalized, "normalized_candidate_data", "exec")
    declared = {symbol.get_name() for symbol in table.get_symbols()
                if symbol.is_assigned() or symbol.is_imported() or symbol.is_namespace()}
    allowed = declared | C_IMPORT_NAMES | C_STRUCT_NAMES | C_BUILTIN_NAMES | set(dir(builtins)) | {"__file__", "__name__"}
    references = []

    def visit(scope, path):
        for symbol in scope.get_symbols():
            if symbol.is_referenced() and symbol.is_global():
                references.append({"scope": path, "name": symbol.get_name(),
                                   "resolved": symbol.get_name() in allowed})
        for child in scope.get_children():
            visit(child, path + "." + child.get_name())

    visit(table, "module")
    unresolved = [row for row in references if not row["resolved"]]
    return {"module_declarations": sorted(declared), "c_import_names": sorted(C_IMPORT_NAMES),
            "c_struct_names": sorted(C_STRUCT_NAMES), "c_builtin_names": sorted(C_BUILTIN_NAMES), "global_references": references,
            "unresolved": unresolved, "all_declared": not unresolved}


def main():
    path = HERE / "dynamic_arena_chain.pyx"
    result = analyze(path.read_text())
    result.update(schema="t3-normalized-lexical-global-name-source-audit-v1", source_only=True,
                  normalized_AST_symtable_only=True, participant_imported=False,
                  native_built=False, runtime_pass=False, speed_claim=False,
                  pyx_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  limits="Finite stdlib lexical name audit with explicit C-import/struct allowlist; actual pinned Cython translation, member types, optional ABI and execution remain required.")
    out = HERE / "GLOBAL_NAME_SOURCE_AUDIT_LATENCY_v1.json"
    if out.exists():
        raise ValueError("fresh global audit output required")
    out.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"all_declared": result["all_declared"],
                      "global_reference_count": len(result["global_references"]),
                      "unresolved": result["unresolved"], "output": str(out)}))
    if result["unresolved"]:
        raise ValueError("unresolved lexical global names")


if __name__ == "__main__":
    main()
