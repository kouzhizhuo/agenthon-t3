"""Pristine NumPy1.26.4 source/wrapped-chain provenance; no unverified capture."""
import ast
import hashlib
import importlib
import json
from pathlib import Path
import types

HERE = Path(__file__).resolve().parent
MODULES = ("numpy.core.fromnumeric", "numpy.core._methods", "numpy.core.overrides", "numpy.core.multiarray")


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def all_codes(code):
    found = {(code.co_name, code.co_firstlineno): code}
    for item in code.co_consts:
        if isinstance(item, types.CodeType):
            found.update(all_codes(item))
    return found


class PristineToken:
    def __init__(self, np):
        self.np, self.source_verified = np, False
        manifest = json.loads((HERE / "NUMPY_SOURCE_PINS_v1.json").read_text())
        if (manifest["schema"] != "t3-configured-latency-numpy1264-source-pins-v1"
                or manifest["immutable_official_version"] != "v1.26.4" or np.__version__ != "1.26.4"):
            raise ValueError("official immutable NumPy1.26.4 source pins required")
        self.modules, self.functions, self.identities = {}, {}, []
        selected = {"numpy.core.fromnumeric": ("_wrapfunc", "_wrapit", "_clip_dispatcher"),
                    "numpy.core._methods": ("_clip",),
                    "numpy.core.overrides": ("array_function_dispatch", "verify_matching_signatures"),
                    "numpy.core.multiarray": ()}
        for name in MODULES:
            module = importlib.import_module(name)
            source = Path(module.__file__).resolve()
            expected = manifest["files"][name]
            if pin(source) != {k: expected[k] for k in ("bytes", "sha256")}:
                raise ValueError("loaded NumPy source differs from pinned official source")
            codes = all_codes(compile(source.read_bytes(), str(source), "exec", dont_inherit=True))
            self.modules[name] = module
            parsed = ast.parse(source.read_bytes())
            for key in selected[name]:
                value = vars(module).get(key)
                if type(value) is not types.FunctionType:
                    raise ValueError("actual selected NumPy wrapper function absent")
                expected_code = codes.get((key, value.__code__.co_firstlineno))
                definition = next(v for v in parsed.body if isinstance(v, ast.FunctionDef) and v.name == key)
                defaults = tuple(ast.literal_eval(v) for v in definition.args.defaults) or None
                kwdefaults = {arg.arg: ast.literal_eval(v) for arg, v in zip(definition.args.kwonlyargs, definition.args.kw_defaults) if v is not None} or None
                if (expected_code is None or value.__code__ != expected_code or value.__globals__ is not vars(module)
                        or value.__defaults__ != defaults or value.__kwdefaults__ != kwdefaults):
                    raise ValueError("loaded NumPy wrapper code/defaults/globals differs")
                self.functions[(name, key)] = (value, value.__code__, value.__defaults__, value.__kwdefaults__)
        fromnumeric, methods = self.modules[MODULES[0]], self.modules[MODULES[1]]
        overrides = self.modules[MODULES[2]]
        multiarray = self.modules[MODULES[3]]
        umath = importlib.import_module("numpy.core._multiarray_umath")
        # Dispatcher type must be the actual C public type from the pinned base;
        # implementation is checked against the official fromnumeric code object.
        dispatcher = getattr(umath, "_ArrayFunctionDispatcher", None)
        if dispatcher is None or type(np.clip) is not dispatcher or fromnumeric.clip is not np.clip:
            raise ValueError("exact NumPy clip dispatcher/type required")
        implementation = getattr(np.clip, "_implementation", None)
        wrapped = getattr(np.clip, "__wrapped__", None)
        if type(implementation) is not types.FunctionType or wrapped is not implementation:
            raise ValueError("exact public clip implementation/wrapped alias required")
        source = Path(fromnumeric.__file__).resolve()
        codes = all_codes(compile(source.read_bytes(), str(source), "exec", dont_inherit=True))
        if (implementation.__code__ != codes.get(("clip", implementation.__code__.co_firstlineno))
                or implementation.__globals__ is not vars(fromnumeric)
                or implementation.__defaults__ != (None,) or implementation.__kwdefaults__ is not None):
            raise ValueError("original clip implementation code/default/globals required")
        if (fromnumeric._methods is not methods or fromnumeric.mu is not multiarray
                or fromnumeric.overrides is not overrides or fromnumeric.asarray is not np.asarray
                or multiarray.ndarray is not np.ndarray or methods.um.clip is not umath.clip
                or methods.um.minimum is not umath.minimum or methods.um.maximum is not umath.maximum
                or np.zeros is not umath.zeros or np.asarray is not umath.asarray
                or multiarray.asarray is not umath.asarray or np.ndarray is not umath.ndarray
                or np.dtype is not umath.dtype or np.uint32 is not umath.dtype("uint32").type):
            raise ValueError("actual original NumPy clip primitive global chain differs")
        self.clip, self.clip_impl, self.clip_code = np.clip, implementation, implementation.__code__
        self.clip_defaults, self.clip_kwdefaults = implementation.__defaults__, implementation.__kwdefaults__
        self.umath, self.dispatcher = umath, dispatcher
        for name in ("log", "minimum", "maximum", "clip"):
            value = getattr(umath, name)
            if type(value) is not np.ufunc or value.__name__ != name:
                raise ValueError("exact original named scalar NumPy ufunc required")
        if np.log is not umath.log or type(np.zeros) is not types.BuiltinFunctionType or np.zeros.__name__ != "zeros":
            raise ValueError("original NumPy log/zeros primitive identity differs")
        for name in ("clip", "log", "zeros", "asarray", "ndarray", "uint32", "dtype"):
            self.identities.append((np, name, getattr(np, name)))
        self.identities.append((np.random, "RandomState", np.random.RandomState))
        for module in self.modules.values():
            # Freeze every imported callable/module authority used by those
            # scalar clip wrappers; primitive literals are source-code-bound.
            for name, value in vars(module).items():
                if callable(value) or isinstance(value, types.ModuleType):
                    self.identities.append((module, name, value))
        for module in (umath,):
            for name in ("minimum", "maximum", "clip", "log", "_ArrayFunctionDispatcher", "asarray", "dtype", "ndarray"):
                if hasattr(module, name):self.identities.append((module, name, getattr(module, name)))
        self.source_verified = True

    def guard_identities(self):
        if not self.source_verified or self.np.clip is not self.clip or type(self.clip) is not self.dispatcher:
            return False
        if (getattr(self.clip, "_implementation", None) is not self.clip_impl
                or getattr(self.clip, "__wrapped__", None) is not self.clip_impl
                or self.clip_impl.__code__ is not self.clip_code
                or self.clip_impl.__defaults__ != self.clip_defaults or self.clip_impl.__kwdefaults__ != self.clip_kwdefaults):
            return False
        for (module_name, name), (fn, code, defaults, kwdefaults) in self.functions.items():
            if (vars(self.modules[module_name]).get(name) is not fn or fn.__code__ is not code
                    or fn.__defaults__ != defaults or fn.__kwdefaults__ != kwdefaults):
                return False
        return all(getattr(module, name, None) is value for module, name, value in self.identities)

    def verify_loaded(self):
        return self.guard_identities()


def establish_pristine_token(np):
    return PristineToken(np)
