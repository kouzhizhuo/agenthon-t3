"""Future same-ELF latency scalar24/transform96 controls; no market proof.

The genuine cold admission helper authorizes each original constructed model.
Private control adapters expose full state without a public ownership handoff.
Distribution intermediate values are not claimed by this suite; postprocess
intermediates are retained separately in all 96 exact donor transforms.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
import warnings

HERE = Path(__file__).resolve().parent
DONOR_CONTROLS_SHA256 = "8a77857871a163a337cfdd188fd4f2a64dad61b186b45fbae0124871f7a80a93"
_CONTROL_OWNERS = []


def pin(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def require(value, message):
    if not value:
        raise ValueError(message)


def scalar(value, np):
    kind = type(value).__module__ + "." + type(value).__name__
    if type(value) in (float, np.float64):
        return {"type": kind, "bits": struct.pack("!d", value).hex()}
    if type(value) is int:
        return {"type": kind, "value": str(value)}
    if type(value) is bool:
        return {"type": kind, "value": value}
    if type(value) is np.int64:
        return {"type": kind, "value": str(int(value))}
    if value is None:
        return {"type": "builtins.NoneType"}
    if type(value) is str:
        return {"type": kind, "value": value}
    if type(value) is tuple:
        return {"type": kind, "items": [scalar(item, np) for item in value]}
    if type(value) is np.ndarray:
        return {"type": kind, "dtype": str(value.dtype), "shape": list(value.shape), "bytes": value.tobytes().hex()}
    raise TypeError("finite plain scalar input/result required")


def state(value):
    require(type(value) is tuple and len(value) == 5 and value[0] == "MT19937"
            and len(value[1]) == 624 and type(value[2]) is int and 0 <= value[2] <= 624
            and type(value[3]) is int and value[3] in (0, 1) and type(value[4]) is float,
            "full actual MT19937 tuple required")
    return {"kind": value[0], "words_le_hex": struct.pack("<624I", *value[1]).hex(),
            "position": value[2], "has_gauss": value[3], "gauss_bits": struct.pack("!d", value[4]).hex()}


def observed(call, np):
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter("always")
        try:
            result = {"returned": True, "result": scalar(call(), np)}
        except BaseException as error:
            result = {"returned": False, "type": type(error).__module__ + "." + type(error).__name__, "message": str(error)}
        result["warnings"] = [{"type": item.category.__module__ + "." + item.category.__name__, "message": str(item.message)} for item in seen]
        return result


def transform_cases(np):
    values = [-0.0, 0.0, -1.0, 0.5, 1.5, 2.5, 3.0,
              float(np.nextafter(0.5, 0.0)), float(np.nextafter(0.5, 1.0)),
              float(np.nextafter(1.5, 1.0)), float(np.nextafter(1.5, 2.0)),
              float(2 ** 52 - 0.5), float(2 ** 52), float(2 ** 53), float("inf"), float("-inf")]
    cases = []
    for lower, upper in ((0.0, 3.0), (-0.0, 0.0), (0.0, -0.0), (-0.0, -0.0), (1.5, 1.5), (0.0, float(2 ** 53))):
        for value in values:
            cases.append((value, lower, upper))
    return cases

def model_cases():
    # Every constructor stays original; fields may be explicitly patched solely
    # for finite fallback controls and the exact patches are retained.
    return [
        ("uniform", {"model": "uniform", "params": {"min_ns": 0, "max_ns": 2000}}, {}, {}, 700),
        ("lognormal", {"model": "log_normal", "params": {"mean_ns": 500, "sigma": 1.2, "max_ns": 2000}}, {}, {}, 700),
        ("pareto", {"model": "pareto", "params": {"min_ns": 1, "max_ns": 2000, "alpha": 1.5}}, {}, {}, 700),
        ("uniform_equal_still_draws", {"model": "uniform", "params": {"min_ns": 5, "max_ns": 5}}, {}, {}, 20),
        ("lognormal_zero_sigma_still_draws", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 0}}, {}, {}, 20),
        ("rollover622", {"model": "uniform"}, {}, {"position": 622}, 700),
        ("rollover623", {"model": "uniform"}, {}, {"position": 623}, 700),
        ("rollover624", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"position": 624}, 700),
        ("pending_positive_zero", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"has_gauss": 1, "gauss": 0.0}, 20),
        ("pending_negative_zero", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"has_gauss": 1, "gauss": -0.0}, 20),
        ("pending_nonzero", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": 1.2}}, {}, {"has_gauss": 1, "gauss": -1.2345}, 20),
        ("lognormal_positive_overflow", {"model": "log_normal", "params": {"mean_ns": 1, "sigma": 1}}, {"_mu": 710.0}, {}, 20),
        ("pareto_positive_overflow", {"model": "pareto", "params": {"alpha": 1e-300}}, {}, {}, 20),
        ("constant_unknown", {"model": "source-unknown-constant", "params": {"mean_ns": 1.5}}, {}, {}, 20),
        ("negativezero_sigma_fallback", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": -0.0}}, {}, {}, 5),
        ("negative_sigma_fallback", {"model": "log_normal", "params": {"mean_ns": 3, "sigma": -1}}, {}, {}, 5),
        ("invalid_alpha_fallback", {"model": "pareto", "params": {"alpha": 0}}, {}, {}, 5),
        ("negative_bounds_fallback", {"model": "uniform", "params": {"min_ns": -3, "max_ns": 3}}, {}, {}, 5),
        ("reversed_bounds_fallback", {"model": "uniform", "params": {"min_ns": 3, "max_ns": 0}}, {}, {}, 5),
        ("nan_string_fallback", {"model": "uniform", "params": {"min_ns": "nan", "max_ns": 3}}, {}, {}, 5),
        ("infinity_string_fallback", {"model": "uniform", "params": {"min_ns": 0, "max_ns": "inf"}}, {}, {}, 5),
        ("nullfield_fallback", {"model": "deterministic"}, {"_min_ns": None}, {}, 5),
        ("numpyfield_fallback", {"model": "deterministic"}, {"_min_ns": "NP_FLOAT64"}, {}, 5),
        ("arrayfield_fallback", {"model": "deterministic"}, {"_min_ns": "NP_ARRAY"}, {}, 5),
    ]


def model_state(rng, owner):
    return state(rng.get_state() if owner is None else owner.control_private_state())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(sys.platform == "linux" and not args.out.exists(), "fresh genuine Linux scalar controls required")
    from production_cli import activate_paths
    activate_paths(args.runtime)
    from native_loader import load
    native = load(args.build, args.runtime)["dynamic_arena_chain"]
    from latency_admission import authenticate_runtime, acquire_control_model
    authority = authenticate_runtime(args.runtime)
    np = authority.np
    require(np.__version__ == "1.26.4", "pinned scalar NumPy required")
    from abides_fork import config
    require(authority.model_class is config.ScenarioLatencyModel, "genuine original configured class required")
    build_path = args.build / "BUILD_RECEIPT.json"
    build = json.loads(build_path.read_bytes())
    extension = next(row for row in build["extensions"] if row["module"] == "dynamic_arena_chain")
    raw = {"schema": "t3-light-typed-noise-latency-same-ELF-expression-controls-v1", "all_passed": False,
        "arms": ["original", "integrated", "integrated-repeat"], "transforms": [], "models": [],
        "original_constructor_errors": [], "source_receipt_sha256": build["source_receipt_sha256"],
        "build_receipt": pin(build_path), "extension": extension, "same_extension_module": "dynamic_arena_chain",
        "standalone_scalar_control_only": True, "initialized_market_owners_claimed": False,
        "native_model_retirement_exercised": False, "native_public_properties_exercised": False,
        "distribution_intermediate_values_observed": False, "postprocess_intermediates_observed": True,
        "donor_controls_sha256": DONOR_CONTROLS_SHA256, "market_executed": False, "rankable": False, "speed_claim": False}
    try:
        transforms = transform_cases(np)
        require(len(transforms) == 96, "exact donor96 postprocess transforms required")
        for ordinal, (value, lower, upper) in enumerate(transforms):
            original_intermediate = float(np.clip(value, lower, upper))
            original = (original_intermediate, int(round(original_intermediate)))
            outcomes = [observed(lambda: original, np),
                observed(lambda: native.control_latency_scalar_postprocess(value, lower, upper, np.clip), np),
                observed(lambda: native.control_latency_scalar_postprocess(value, lower, upper, np.clip), np)]
            require(outcomes[0] == outcomes[1] == outcomes[2], "sameELF clip/round/type/signzero intermediate differs")
            raw["transforms"].append({"ordinal": ordinal, "value": scalar(value, np), "lower": scalar(lower, np),
                "upper": scalar(upper, np), "outcomes": outcomes, "passed": True})
        definitions = model_cases()
        require(len(definitions) == 24, "exact donor24 genuine models required")
        for index, (name, definition, patch, state_patch, count) in enumerate(definitions):
            models, rngs, constructors = [], [], []
            for arm in range(3):
                rng = np.random.RandomState(93009 + index)
                before = state(rng.get_state())
                created = []
                def construct():
                    model = config.ScenarioLatencyModel(2, definition, rng)
                    created.append(model)
                    return None
                constructor = observed(construct, np)
                require(constructor["returned"] is True and len(created) == 1, "genuine original constructor failed")
                model = created[0]
                after = state(rng.get_state())
                require(before == after and model.random_state is rng, "configured original constructor consumed RNG or changed identity")
                for key, value in patch.items():
                    if type(value) is str and value == "NP_FLOAT64":
                        value = np.float64(0.0)
                    elif type(value) is str and value == "NP_ARRAY":
                        value = np.array([0.0, 1.0])
                    setattr(model, key, value)
                if state_patch:
                    public = list(rng.get_state())
                    public[2], public[3], public[4] = state_patch.get("position", public[2]), state_patch.get("has_gauss", public[3]), state_patch.get("gauss", public[4])
                    rng.set_state(tuple(public))
                constructors.append({"outcome": constructor, "before_state": before, "after_state": after})
                models.append(model); rngs.append(rng)
            require(constructors[0] == constructors[1] == constructors[2], "genuine original constructors differ")
            acquisitions, owners, acquisition_rows = [], [None], []
            for arm in (1, 2):
                before = state(rngs[arm].get_state())
                acquisition = acquire_control_model(models[arm], native, args.runtime, ())
                after = state(rngs[arm].get_state())
                require(before == after and acquisition.source_model is models[arm], "cold scalar acquisition changed actual source/RNG")
                owner = acquisition.owner
                if owner is not None:
                    _CONTROL_OWNERS.append(owner)
                    require(acquisition.rng is rngs[arm] and acquisition.raw_dict is object.__getattribute__(models[arm], "__dict__")
                            and tuple(acquisition.fields) == tuple(acquisition.raw_dict)
                            and all(acquisition.fields[key] is value for key, value in acquisition.raw_dict.items()),
                            "cold scalar field/rawdictionary identity differs")
                    require(state(owner.control_private_state()) == before, "private initial full624 copy differs")
                acquisitions.append(acquisition); owners.append(owner)
                acquisition_rows.append({"before_actual_state": before, "after_actual_state": after,
                    "declined_reason": acquisition.declined_reason, "owner_selected": owner is not None})
            expected_owned = "fallback" not in name
            require([owner is not None for owner in owners] == [False, expected_owned, expected_owned],
                    "exact donor native ownership/unsupported fallback differs")
            calls = []
            initial_actual = [state(rng.get_state()) for rng in rngs]
            require(initial_actual[0] == initial_actual[1] == initial_actual[2], "actual initial patched state differs")
            try:
                for ordinal in range(count):
                    sender, recipient = (0, 0) if ordinal % 7 == 0 else ((0, 1) if ordinal % 2 else (1, 0))
                    outcomes, before_states, after_states, native_diagnostics = [], [], [], []
                    for arm in range(3):
                        before_states.append(model_state(rngs[arm], owners[arm]))
                        call = (lambda arm=arm: native.control_latency_private_sample(owners[arm], sender, recipient)) if owners[arm] is not None else (lambda arm=arm: models[arm].get_latency(sender_id=sender, recipient_id=recipient))
                        outcomes.append(observed(call, np))
                        after_states.append(model_state(rngs[arm], owners[arm]))
                        native_diagnostics.append(None if owners[arm] is None else owners[arm].diagnostics())
                    require(outcomes[0] == outcomes[1] == outcomes[2] and before_states[0] == before_states[1] == before_states[2]
                            and after_states[0] == after_states[1] == after_states[2], "genuine latency result/warning/exception/full624 state differs")
                    require(all(model.random_state is rng for model, rng in zip(models, rngs)), "retained original model/RNG identity changed")
                    if sender == recipient:
                        require(before_states == after_states, "self latency consumed RNG")
                    if expected_owned:
                        require(native_diagnostics[1] == native_diagnostics[2], "repeated private native diagnostics differ")
                    calls.append({"ordinal": ordinal, "sender": sender, "recipient": recipient, "outcomes": outcomes,
                        "before_states": before_states, "after_states": after_states, "diagnostics_after": native_diagnostics})
            finally:
                for owner in owners[1:]:
                    if owner is not None:
                        owner.export_to_original(); owner.export_to_original()
            exported = [state(rng.get_state()) for rng in rngs]
            require(exported[0] == exported[1] == exported[2], "terminal actual original full624 export differs")
            diagnostics = [None if owner is None else owner.diagnostics() for owner in owners]
            if expected_owned:
                require(diagnostics[1] == diagnostics[2] and diagnostics[1]["owned"] is False and diagnostics[1]["handoffs"] == 1,
                        "terminal permanent one-shot export/repeat differs")
                require(diagnostics[1]["self_calls"] >= 1 and diagnostics[1]["native_calls"] >= 1,
                        "scalar native positive consumption witness absent")
            raw["models"].append({"name": name, "definition": definition, "constructors": constructors,
                "field_patch": {key: scalar(getattr(models[0], key), np) for key in patch},
                "initial_state_patch": {key: scalar(value, np) for key, value in state_patch.items()},
                "initial_actual_states": initial_actual, "acquisitions": acquisition_rows, "calls": calls,
                "owners_selected": [owner is not None for owner in owners], "final_exported_actual_states": exported,
                "diagnostics": diagnostics, "passed": True})
        for definition in ({"model": "uniform", "params": {"min_ns": None}},
                           {"model": "log_normal", "params": {"sigma": None}},
                           {"model": "pareto", "params": {"alpha": None}},
                           {"model": "uniform", "params": {"min_ns": "not-a-number"}}):
            arm_rows = []
            for _ in range(3):
                rng = np.random.RandomState(96009)
                before = state(rng.get_state())
                def bad_constructor():
                    config.ScenarioLatencyModel(2, definition, rng)
                    return None
                result = observed(bad_constructor, np)
                after = state(rng.get_state())
                require(result["returned"] is False and before == after, "original failed constructor consumed RNG")
                arm_rows.append({"outcome": result, "before_state": before, "after_state": after})
            require(arm_rows[0] == arm_rows[1] == arm_rows[2], "original failed constructor behavior differs")
            raw["original_constructor_errors"].append({"definition": definition, "arms": arm_rows,
                "native_acquired": False, "passed": True})
        require(len(raw["models"]) == 24 and len(raw["transforms"]) == 96, "complete scalar donor roster required")
        raw["call_count_per_arm"] = sum(len(row["calls"]) for row in raw["models"])
        raw["all_passed"] = True
    except BaseException as error:
        raw["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        cleanup_failures = []
        for owner in _CONTROL_OWNERS:
            try:
                owner.export_to_original()
            except BaseException as error:
                cleanup_failures.append({"type": type(error).__name__, "message": str(error)})
        raw["cleanup_failures"] = cleanup_failures
        if cleanup_failures:
            raw["all_passed"] = False
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(raw, indent=2, sort_keys=True) + "\n")
    require(raw["all_passed"] is True, "complete scalar evidence or authoritative cleanup failed")


if __name__ == "__main__":
    main()
