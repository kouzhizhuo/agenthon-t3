#!/usr/bin/env python3
"""Run the pinned ABIDES engine; public reference material is never loaded here."""
import time

ENTRY_STARTED = time.perf_counter()

from bootstrap import activate
activate()

import argparse
import json
from pathlib import Path
import resource
import sys

from abides_core import abides
from abides_core.kernel import Kernel
from abides_fork.config import build_config
from counters import reset_abides_counters
from abides_fork.trace import extract_trace, extract_message_trace
from contracts import sha256, validate_scenario, validate_frames
from canonical_buffers import (Declined, project_trace, project_messages,
                               validate_admitted_columns, write_outputs, import_witness)
import observer
from observer_domain import authenticate_loaded
from optimizations import enabled


def simulate(config_path, out_path, mode="optimized", started=None, witness_path=None):
    t0 = time.perf_counter() if started is None else started
    scenario = json.loads(Path(config_path).read_text())
    validate_scenario(scenario)
    authenticated = authenticate_loaded()
    admitted_episode = observer.begin_episode(scenario, authenticated)
    witness_before = import_witness() if witness_path is not None else None
    reset_abides_counters()
    config = build_config(scenario)
    # Upstream write_summary_log ignores skip_log and writes ./log even with
    # a read-only container root. It is not a competition output and does not
    # modify end_state, so both comparison modes suppress that diagnostic IO.
    summary_writer = Kernel.write_summary_log
    Kernel.write_summary_log = lambda self: None
    try:
        with enabled(mode == "optimized") as message_extractor:
            end_state = abides.run(config)
    finally:
        Kernel.write_summary_log = summary_writer
    from abides_markets.orders import Side
    from abides_fork.trace import _side_to_str
    try:
        trace = (project_trace(end_state, observer.STATE, Side, _side_to_str) if admitted_episode
                 else Declined("unauthenticated-episode"))
        ledger_type = getattr(message_extractor, "ledger_type", None)
        messages = (project_messages(end_state, ledger_type) if admitted_episode and isinstance(ledger_type, type)
                    else Declined("legacy-extractor-pair"))
        declines = {name: value.reason for name, value in (("trace", trace), ("message_trace", messages))
                    if type(value) is Declined}
        if declines:
            # Select the complete original pair before any output file is written.
            # Projection read only trusted containers; the market is never rerun.
            trace = extract_trace(end_state)
            messages = message_extractor(end_state)
            validate_frames(trace, messages)
        else:
            validate_admitted_columns(trace, messages)
    finally:
        observer.finish_episode()
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    if declines:
        trace.to_parquet(out, compression="snappy", index=False)
        messages.to_parquet(out.parent / "message_trace.parquet", compression="snappy", index=False)
        n_events = len(trace)
    else:
        write_outputs(trace, messages, out)
        n_events = trace.n_rows
    trace_digest = sha256(out)
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    wall = time.perf_counter() - t0
    events = {"scenario_id": str(scenario["scenario_id"]), "seed": int(scenario["seed"]),
              "n_events": n_events, "wall_clock_sec": wall,
              "events_per_sec": n_events / wall, "trace_sha256": trace_digest,
              "peak_memory_bytes": int(rss) if sys.platform == "darwin" else int(rss) * 1024,
              "gpu_seconds": 0.0}
    (out.parent / "events.json").write_text(json.dumps(events, indent=2) + "\n")
    if witness_path is not None:
        witness = {"schema": "t3-pandas-free-output-episode-witness-v1",
                   "scenario_id": str(scenario["scenario_id"]), "seed": int(scenario["seed"]),
                   "source_authenticated": authenticated, "observer_admitted": admitted_episode,
                   "projectors_admitted": not bool(declines), "declines": declines,
                   "output_mode": "legacy-pandas" if declines else "canonical-arrow-buffers",
                   "before": witness_before, "after": import_witness(),
                   "actual_trace_rows": n_events, "actual_trace_sha256": trace_digest,
                   "market_rerun": False}
        target = Path(witness_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(witness, indent=2) + "\n")
    return events


def simulate_batch(batch_dir, out_dir, mode="optimized", started=None, witness_path=None):
    t0 = time.perf_counter() if started is None else started
    paths = sorted(p for p in Path(batch_dir).glob("*.json") if not p.name.startswith("._"))
    if not paths:
        raise ValueError("batch-dir contains no scenario JSON files")
    per_scenario = []
    for path in paths:
        events = simulate(path, Path(out_dir) / path.stem / "trace.parquet", mode,
                          witness_path=None if witness_path is None else Path(witness_path) / (path.stem + ".json"))
        per_scenario.append({"sub": path.stem, "n_events": events["n_events"],
                             "scenario_id": events["scenario_id"], "seed": events["seed"]})
    wall = time.perf_counter() - t0
    total = sum(row["n_events"] for row in per_scenario)
    result = {"n_scenarios": len(per_scenario), "total_events": total,
              "wall_clock_sec": wall, "events_per_sec": total / wall,
              "per_scenario": per_scenario}
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    (Path(out_dir) / "batch_events.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="verb", required=True)
    single = sub.add_parser("simulate")
    single.add_argument("--config", required=True)
    single.add_argument("--out", required=True)
    batch = sub.add_parser("simulate-batch")
    batch.add_argument("--batch-dir", required=True)
    batch.add_argument("--out-dir", required=True)
    for command in (single, batch):
        command.add_argument("--mode", choices=["baseline", "optimized"], default="optimized")
        command.add_argument("--output-witness", help="isolated control receipt path; batch uses a directory")
    args = parser.parse_args()
    if args.verb == "simulate":
        result = simulate(args.config, args.out, args.mode, started=ENTRY_STARTED, witness_path=args.output_witness)
    else:
        result = simulate_batch(args.batch_dir, args.out_dir, args.mode, started=ENTRY_STARTED, witness_path=args.output_witness)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
