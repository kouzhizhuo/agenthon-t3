"""Cold source/ELF-established exact engine authority for read-only final projection."""
from pathlib import Path
import sys
import types

_ENGINE = None
_ENGINE_PATH = None
_TYPES = None


def bind_dynamic_engine(engine, path):
    global _ENGINE, _ENGINE_PATH, _TYPES
    path = Path(path).resolve()
    if (type(engine) is not types.ModuleType or engine.__name__ != "dynamic_arena_chain"
            or sys.modules.get("dynamic_arena_chain") is not engine
            or Path(engine.__file__).resolve() != path):
        raise ValueError("source/ELF-loaded dynamic engine required")
    types_ = (engine.NativeTrader, engine.NativeExchange, engine.ColumnLedger)
    if any(type(value) is not type or value.__module__ != "dynamic_arena_chain" for value in types_):
        raise ValueError("same-extension native owner/ledger types required")
    if _ENGINE is not None and (_ENGINE is not engine or _ENGINE_PATH != path or _TYPES != types_):
        raise ValueError("process already bound to another dynamic engine")
    _ENGINE, _ENGINE_PATH, _TYPES = engine, path, types_


def exact_dynamic_engine(engine):
    return (engine is not None and engine is _ENGINE and type(engine) is types.ModuleType
            and sys.modules.get("dynamic_arena_chain") is engine and Path(engine.__file__).resolve() == _ENGINE_PATH
            and (engine.NativeTrader, engine.NativeExchange, engine.ColumnLedger) == _TYPES)
