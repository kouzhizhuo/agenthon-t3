"""Direct exact column-ledger projection; no dictionary rematerialization."""
import numpy as np


def make_extractor(ColumnLedger, original, columns, dtypes):
    def extract(end_state):
        import pandas as pd
        ledger = end_state.get('message_ledger')
        if type(ledger) is not ColumnLedger:
            return original(end_state)
        seqmap = end_state.get('deliver_seq_by_key') or {}
        if type(seqmap) is not dict:
            raise TypeError('canonical final delivery map must be a dict')
        empty = pd.DataFrame({name: [] for name in columns}).astype(dtypes)
        if not ledger:
            return empty
        source = ledger.columns
        # Same final-map lookup and stable seq order as incumbent; repeated sends remain rows.
        rows = [(seq, index) for index, (message_id, dst_id) in enumerate(zip(source[0], source[2]))
                if (seq := seqmap.get((int(message_id), int(dst_id)))) is not None]
        if not rows:
            return empty
        rows.sort(key=lambda row: row[0])
        permutation = [index for _, index in rows]
        indices = {'message_id': 0, 'src_id': 1, 'dst_id': 2, 't_send_ns': 3,
                   't_recv_ns': 4, 'latency_ns': 5, 'msg_type': 6, 'order_id': 7, 'causal_parent': 8}
        raw_columns = {
            name: ([seq for seq, _ in rows] if name == 'seq'
                   else [source[indices[name]][i] for i in permutation])
            for name in dtypes
        }
        # Original DataFrame column inference and final astype remain the
        # conversion fallback. Build nullable fields identically before either arm.
        for name, dtype in dtypes.items():
            if dtype in ('string', 'Int64'):
                raw_columns[name] = pd.array(raw_columns[name], dtype=dtype)

        def original_column_conversion():
            return pd.DataFrame(raw_columns).astype(dtypes)[columns]

        result = {}
        try:
            for name, dtype in dtypes.items():
                values = raw_columns[name]
                if dtype in ('string', 'Int64'):
                    result[name] = values
                else:
                    numbers = np.asarray(values)
                    if numbers.dtype.kind not in ('b', 'i'):
                        return original_column_conversion()
                    lower, upper = ((-(1 << 31), 1 << 31) if dtype == 'int32'
                                    else (-(1 << 63), 1 << 63))
                    if np.any(numbers < lower) or np.any(numbers >= upper):
                        return original_column_conversion()
                    result[name] = numbers.astype(dtype, copy=False)
            return pd.DataFrame(result, columns=columns)
        except (TypeError, ValueError, KeyError, OverflowError):
            return original_column_conversion()
    extract.ledger_type = ColumnLedger
    return extract
