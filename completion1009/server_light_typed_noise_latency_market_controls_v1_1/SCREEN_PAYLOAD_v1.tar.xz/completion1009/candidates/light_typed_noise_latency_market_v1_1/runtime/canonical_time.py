"""Exact fast domain used by the T3 config; other public inputs keep pandas.

No random state, clock arithmetic or caller-owned values are changed. Duration
results deliberately remain numpy.int64, as in the pinned pandas conversion.
"""
from datetime import datetime, timedelta
import numpy as np

_EPOCH = datetime(1970, 1, 1)
_DURATIONS = {"09:30:00": 34200000000000, "16:00:00": 57600000000000,
              "1s": 1000000000, "60s": 60000000000, "1min": 60000000000}
_INTEGER_TYPES = (int, np.int64, np.int32)


def _integer_type(value):
    actual = type(value)
    return actual is int or actual is np.int64 or actual is np.int32


def str_to_ns(value):
    if type(value) is str and value in _DURATIONS:
        return np.int64(_DURATIONS[value])
    if _integer_type(value) and -(1 << 63) < value < (1 << 63):
        return np.int64(value)
    # Exact int64 minimum is pandas NaT, whose original conversion throws.
    import pandas as pd
    return pd.to_timedelta(value).to_timedelta64().astype(int)


def datetime_str_to_ns(value):
    if type(value) is str and value == "20210205":
        return (datetime(2021, 2, 5) - _EPOCH).days * 86400000000000
    import pandas as pd
    return pd.Timestamp(value).value


def fmt_ts(value):
    if _integer_type(value) and -(1 << 63) < value < (1 << 63):
        # Floor seconds, including negative nanoseconds, matches Timestamp.
        return (_EPOCH + timedelta(seconds=int(value) // 1000000000)).strftime("%Y-%m-%d %H:%M:%S")
    import pandas as pd
    return pd.Timestamp(value, unit="ns").strftime("%Y-%m-%d %H:%M:%S")
