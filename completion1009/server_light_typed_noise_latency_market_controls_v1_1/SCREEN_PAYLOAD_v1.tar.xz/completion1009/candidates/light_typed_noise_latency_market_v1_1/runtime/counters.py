"""The original two class-counter assignments without loading the stock CLI."""
from abides_core.message import Message
from abides_markets.orders import Order


def reset_abides_counters():
    Order._order_id_counter = 0
    setattr(Message, "_Message__message_id_counter", 1)
