"""Original construction/initialize with one cold Noise/latency migration."""
from abides_core.kernel import Kernel as OriginalKernel


class NativeOwnerKernel(OriginalKernel):
    @property
    def agent_latency_model(self):
        # OriginalKernel.__init__ uses this property before ownership exists.
        # The raw ordinary slot is retained; no owner access or recursive lookup.
        values = self.__dict__
        if "agent_latency_model" not in values:
            raise AttributeError("kernel has no initialized attribute 'agent_latency_model'")
        boundary = values.get("_chain_episode_boundary")
        if boundary is not None and boundary.committed:
            boundary.export_all()
        return values["agent_latency_model"]

    @agent_latency_model.setter
    def agent_latency_model(self, value):
        values = self.__dict__
        boundary = values.get("_chain_episode_boundary")
        if boundary is not None and boundary.committed:
            boundary.export_all()
        # Successful export permanently retires the former native owner. A
        # replacement (including same identity) stays on the original route.
        values["agent_latency_model"] = value

    @agent_latency_model.deleter
    def agent_latency_model(self):
        values = self.__dict__
        if "agent_latency_model" not in values:
            raise AttributeError("kernel has no initialized attribute 'agent_latency_model'")
        boundary = values.get("_chain_episode_boundary")
        if boundary is not None and boundary.committed:
            boundary.export_all()
        del values["agent_latency_model"]

    def initialize(self):
        if "_chain_migration" in self.__dict__:
            raise ValueError("chain does not reinitialize a live owner")
        super().initialize()
        import dynamic_arena_chain
        from state_mapper import migrate
        migrate(self, dynamic_arena_chain)

    def runner(self, agent_actions=None):
        return self._chain_episode_boundary.run(self._chain_scheduler.run, agent_actions)

    def terminate(self):
        if "_chain_episode_boundary" in self.__dict__:
            self._chain_episode_boundary.export_all()
        return super().terminate()

    def send_message(self, sender_id, recipient_id, message, delay=0):
        if "_chain_scheduler" not in self.__dict__:
            return super().send_message(sender_id, recipient_id, message, delay)
        # Scheduler public send exports all streams before foreign arguments.
        return self._chain_scheduler.send(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        if "_chain_scheduler" not in self.__dict__:
            return super().set_wakeup(sender_id, requested_time)
        return self._chain_scheduler.set_wakeup(sender_id, requested_time)
