"""Future actual initialized/migrated NativeTrader public RNG finite controls."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def pin(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def require(value, message):
    if not value:
        raise ValueError(message)


def fixture(native, np, migrated):
    import observer
    from observer_domain import authenticate_loaded
    from abides_fork.config import build_config
    from abides_core.kernel import Kernel
    from abides_core.utils import subdict
    from counters import reset_abides_counters
    from state_mapper import migrate
    from noise_admission import authenticate_runtime
    from native_runtime_binding import runtime_for
    scenario = json.loads((HERE / "control_scenario.json").read_bytes())
    require(observer.STATE is None and authenticate_loaded(), "fresh exact cold observer domain required")
    authenticate_runtime(runtime_for(native))
    np.random.seed(19301009)
    reset_abides_counters()
    require(observer.begin_episode(scenario, True), "fresh actual observer episode admission required")
    kernel = None
    try:
        config = build_config(scenario)
        kernel = Kernel(random_state=np.random.RandomState(0), log_dir="finite-no-runner",
            **subdict(config, ["start_time", "stop_time", "agents", "agent_latency_model",
                              "default_computation_delay", "custom_properties"]))
        Kernel.initialize(kernel)
        if migrated:
            record = migrate(kernel, native)
            record.assert_authority()
            require(kernel.ttl_messages == 0 and kernel._deliver_seq == 0,
                    "cold actual migration must precede runner delivery")
            actor = next(value for value in kernel.agents[1:] if value.strategy_name() == "NoiseTrader")
            owner = kernel._noise_boundary.owner_for_controlled_actor(actor)
            require(owner is not None and actor.noise_diagnostics()["owned"], "actual NativeTrader private owner selected")
        else:
            from abides_fork.agents import NoiseTrader
            actor = next(value for value in kernel.agents if type(value) is NoiseTrader)
            owner = None
        return kernel, actor, owner
    except BaseException as error:
        from cleanup_errors import attach, detail
        failures = []
        if kernel is not None and "_chain_episode_boundary" in kernel.__dict__:
            try:
                kernel._chain_episode_boundary.export_all()
            except BaseException as cleanup:
                failures.append({"phase": "fixture-export-all", **detail(cleanup)})
        try:
            observer.finish_episode()
        except BaseException as cleanup:
            failures.append({"phase": "fixture-finish-observer", **detail(cleanup)})
        if failures:
            attach(error, "finite_fixture_cleanup_failures", failures)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh actual native lifecycle evidence required")
    sys.path.insert(0, str(HERE))
    from production_cli import activate_paths
    activate_paths(args.runtime)
    from native_loader import load
    native = load(args.build, args.runtime)["dynamic_arena_chain"]
    import numpy as np
    import observer
    from noise_admission import public_state
    from noise_expression_controls import observed, original_draw, state
    modes = ("getter", "snapshot", "new-RNG-setter", "same-RNG-setter", "delete",
             "public-holdings-wrapper", "failed-export-getter", "failed-export-setter", "failed-export-delete")
    raw = {"schema": "t3-light-typed-noise-actual-native-public-lifecycle-controls-v1", "all_passed": False,
        "cases": [], "arms": ["original", "new", "new-repeat"],
        "build_receipt": pin(args.build / "BUILD_RECEIPT.json"), "source_receipt": pin(HERE / "SOURCE_PREPARATION_RECEIPT_v1.json"),
        "actual_original_initialize_exercised": True, "actual_full_owner_migration_exercised": True,
        "market_runner_executed": False, "rankable": False, "speed_claim": False,
        "untested": ["direct-public-scheduler-run", "kernel-terminate", "partial-run-continuation",
                     "post-draw-order-send-error", "migration-preflight-and-commit-error-injection"]}
    try:
        for mode in modes:
            rows = []
            for arm in raw["arms"]:
                kernel, actor, owner = fixture(native, np, arm != "original")
                export_callback = None
                active_error = False
                try:
                    retained_rng = actor.random_state if owner is None else None
                    # Retired source dictionaries deliberately contain no business
                    # state. Actual registry entries retain the original RNG.
                    if owner is not None:
                        retained_rng = next(rng for value, value_owner, rng in kernel._noise_boundary.entries
                                            if value is actor and value_owner is owner)
                    require(type(retained_rng) is np.random.RandomState, "actual original RNG retained exactly")
                    replacement = np.random.RandomState(95701)
                    initial = state(public_state(retained_rng, np))
                    draw = observed(lambda: original_draw(retained_rng, 10.0, 2.0, 5, []) if owner is None
                                    else native.control_noise_private_draw(owner, 10.0, 2.0, 5))
                    consumed = state(public_state(retained_rng, np) if owner is None else owner.control_private_state())
                    before_public = state(public_state(retained_rng, np))
                    require(draw["returned"] is True, "ordinary actual private draw must complete")
                    if owner is not None:
                        require(consumed != before_public and before_public == initial,
                                "ordinary native private draw must retain stale original until public export")
                    failure_count = [0]
                    recovery_before = None
                    class FiniteExportError(BaseException):
                        pass
                    def failed_export(value):
                        failure_count[0] += 1
                        raise FiniteExportError("finite injected native export failure")
                    if mode.startswith("failed-export") and owner is not None:
                        # A deliberate public owner test callback intervention;
                        # admission still acquired the exact original methods.
                        export_callback = owner.control_replace_export_callback(failed_export)
                    if mode in ("getter", "failed-export-getter"):
                        outcome = observed(lambda: actor.random_state is retained_rng)
                    elif mode == "snapshot":
                        outcome = observed(lambda: (actor.__dict__["random_state"] if owner is None else
                                                    actor.snapshot_fields()["random_state"]) is retained_rng)
                    elif mode in ("new-RNG-setter", "same-RNG-setter", "failed-export-setter"):
                        installed = retained_rng if mode == "same-RNG-setter" else replacement
                        outcome = observed(lambda: setattr(actor, "random_state", installed))
                    elif mode in ("delete", "failed-export-delete"):
                        outcome = observed(lambda: delattr(actor, "random_state"))
                    else:
                        outcome = observed(lambda: actor.get_holdings("CASH"))
                    if mode.startswith("failed-export") and owner is not None:
                        require(outcome["returned"] is False and failure_count[0] == 1
                                and outcome["type"] == FiniteExportError.__module__ + "." + FiniteExportError.__name__
                                and outcome["message"] == "finite injected native export failure",
                                "native public export failure must propagate exactly once")
                        require(owner.diagnostics()["owned"] is True and owner.diagnostics()["handoffs"] == 0
                                and kernel._noise_boundary.owner_for_controlled_actor(actor) is owner
                                and state(public_state(retained_rng, np)) == before_public,
                                "failed native export detached or mutated retained slot/owner")
                        recovery_before = {"diagnostics": owner.diagnostics(),
                            "actual_original_state": state(public_state(retained_rng, np)),
                            "private_consumed_state": state(owner.control_private_state()),
                            "owner_registry_preserved": kernel._noise_boundary.owner_for_controlled_actor(actor) is owner}
                        owner.control_replace_export_callback(export_callback)
                        export_callback = None
                        # Getter now witnesses the slot survived failed setter/
                        # deletion and permanently exports the original stream.
                        require(actor.random_state is retained_rng, "failed native property changed original slot")
                        require(owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1
                                and kernel._noise_boundary.owner_for_controlled_actor(actor) is None,
                                "recovered actual native getter did not detach permanently")
                    elif owner is not None:
                        require(owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1
                                and kernel._noise_boundary.owner_for_controlled_actor(actor) is None,
                                "actual NativeTrader public boundary did not detach owner permanently")
                    exported = state(public_state(retained_rng, np))
                    require(exported == consumed, "actual native property terminal full624 state differs")
                    continuation = None
                    continuation_state = None
                    missing = None
                    if mode in ("new-RNG-setter", "same-RNG-setter"):
                        require(actor.random_state is installed, "native setter installed wrong identity")
                        continuation = observed(lambda: original_draw(actor.random_state, 10.0, 2.0, 5, []))
                        continuation_state = state(public_state(actor.random_state, np))
                    if mode == "delete":
                        missing = observed(lambda: actor.random_state)
                        require(missing["returned"] is False and missing["type"] == "builtins.AttributeError",
                                "actual deleted random_state property still present")
                    row = {"arm": arm, "initial_actual_state": initial, "draw_outcome": draw,
                        "consumed_full624_state": consumed, "before_public_original_state": before_public,
                        "public_outcome": outcome, "terminal_original_state": exported,
                        "continuation_outcome": continuation, "continuation_actual_state": continuation_state,
                        "deleted_property_outcome": missing, "before_failed_export_recovery": recovery_before,
                        "native_export_failure_calls": failure_count[0],
                        "native_diagnostics": None if owner is None else owner.diagnostics(),
                        "actual_kernel_deliveries": [kernel.ttl_messages, kernel._deliver_seq]}
                    rows.append(row)
                except BaseException:
                    active_error = True
                    raise
                finally:
                    cleanup_failures = []
                    from cleanup_errors import detail, attach
                    active = sys.exception()
                    if export_callback is not None:
                        try:
                            owner.control_replace_export_callback(export_callback)
                        except BaseException as error:
                            cleanup_failures.append({"phase": "restore-export-callback", **detail(error)})
                    if owner is not None:
                        try:
                            kernel._chain_episode_boundary.export_all()
                        except BaseException as error:
                            cleanup_failures.append({"phase": "export-all-owners", **detail(error)})
                    try:
                        observer.finish_episode()
                    except BaseException as error:
                        cleanup_failures.append({"phase": "finish-observer", **detail(error)})
                    if cleanup_failures:
                        if active_error:
                            attach(active, "finite_lifecycle_cleanup_failures", cleanup_failures)
                        else:
                            raise RuntimeError("finite lifecycle terminal cleanup failed")
            common = ("initial_actual_state", "draw_outcome", "consumed_full624_state", "terminal_original_state",
                      "continuation_outcome", "continuation_actual_state", "actual_kernel_deliveries")
            require(all(rows[0][key] == rows[1][key] == rows[2][key] for key in common),
                    "actual original/native/native-repeat public state or continuation differs")
            if not mode.startswith("failed-export"):
                require(rows[0]["public_outcome"] == rows[1]["public_outcome"] == rows[2]["public_outcome"],
                        "actual public native outcomes differ")
            if mode == "delete":
                # Original and native messages identify different owner types;
                # exact exception type/return/warnings remain required across
                # original/native, with complete native-repeat text equality.
                keys = ("returned", "type", "warnings")
                require(all(rows[0]["deleted_property_outcome"][key] == rows[1]["deleted_property_outcome"][key]
                            == rows[2]["deleted_property_outcome"][key] for key in keys)
                        and rows[1]["deleted_property_outcome"] == rows[2]["deleted_property_outcome"],
                        "actual deleted property outcome differs")
            require(rows[1]["native_diagnostics"] == rows[2]["native_diagnostics"],
                    "actual repeated native public diagnostics differ")
            require(rows[1]["public_outcome"] == rows[2]["public_outcome"],
                    "actual repeated native public outcomes differ")
            raw["cases"].append({"mode": mode, "arms": rows, "passed": True})
        raw["all_passed"] = True
    except BaseException as error:
        from cleanup_errors import detail
        raw["failure"] = detail(error)
        if observer.STATE is not None:
            observer.finish_episode()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(raw, sort_keys=True, indent=2, allow_nan=False) + "\n")
    require(raw["all_passed"], "actual native public lifecycle controls failed")


if __name__ == "__main__":
    main()
