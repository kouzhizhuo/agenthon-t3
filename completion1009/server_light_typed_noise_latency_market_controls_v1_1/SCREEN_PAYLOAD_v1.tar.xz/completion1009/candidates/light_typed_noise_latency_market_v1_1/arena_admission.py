"""Whole-episode source binding before reset/config/RNG/agent creation."""
from pathlib import Path
import ast,sys,types,abc
from dataclasses import Field, MISSING, _init_fn, _FIELD, _FIELD_CLASSVAR

def admit(scenario,runtime):
    if type(scenario) is not dict or type(scenario.get("agent_configs")) is not list:
        return False
    from observer_domain import authenticate_loaded,_code_at,_defaults_match
    if not authenticate_loaded():return False
    from abides_core import message
    from abides_markets.messages import market,query,order,orderbook
    from abides_markets.agents import trading_agent
    from abides_fork import agents
    from abides_markets import orders
    if not all(type(x) is dict and x.get("agent_type") in agents.AGENT_REGISTRY for x in scenario["agent_configs"]):return False
    runtime=Path(runtime).resolve()
    modules={message:"vendor/abides/abides-core/abides_core/message.py",market:"vendor/abides/abides-markets/abides_markets/messages/market.py",query:"vendor/abides/abides-markets/abides_markets/messages/query.py",order:"vendor/abides/abides-markets/abides_markets/messages/order.py",orderbook:"vendor/abides/abides-markets/abides_markets/messages/orderbook.py"}
    for module,relative in modules.items():
        if Path(module.__file__).resolve()!=runtime/relative:return False
    compiled={}
    parsed={}
    if type(message.Message.__post_init__) is not types.FunctionType or message.Message.__post_init__.__code__!=_code_at(message,"Message","__post_init__",compiled):return False
    expected=((message,"WakeupMsg"),(market,"MarketClosePriceRequestMsg"),(market,"MarketHoursRequestMsg"),(market,"MarketHoursMsg"),(query,"QuerySpreadMsg"),(query,"QuerySpreadResponseMsg"),(order,"LimitOrderMsg"),(orderbook,"OrderAcceptedMsg"),(orderbook,"OrderExecutedMsg"),(order,"CancelOrderMsg"),(orderbook,"OrderCancelledMsg"),(market,"MarketClosePriceMsg"),(market,"MarketClosedMsg"))
    field_roster={"WakeupMsg":(),"MarketClosePriceRequestMsg":(),"MarketHoursRequestMsg":(),"MarketHoursMsg":("mkt_open","mkt_close"),"QuerySpreadMsg":("symbol","depth"),"QuerySpreadResponseMsg":("symbol","mkt_closed","depth","bids","asks","last_trade"),"LimitOrderMsg":("order",),"OrderAcceptedMsg":("order",),"OrderExecutedMsg":("order",),"CancelOrderMsg":("order","tag","metadata"),"OrderCancelledMsg":("order",),"MarketClosePriceMsg":("close_prices",),"MarketClosedMsg":()}
    for module,name in expected:
        cls=getattr(module,name)
        expected_meta=abc.ABCMeta if module in (query,order,orderbook) else type
        if type(cls) is not expected_meta or cls.__module__!=module.__name__ or not issubclass(cls,message.Message):return False
        if cls.__post_init__ is not message.Message.__post_init__:return False
        # Generate only the stdlib dataclass constructor for the pinned field
        # roster, never construct a participant, draw RNG or call its body.
        roster=list(cls.__dataclass_fields__.values())
        if tuple(f.name for f in roster)!=("_Message__message_id_counter","message_id")+field_roster[name]:return False
        if any(type(f) is not Field for f in roster):return False
        if roster[0]._field_type is not _FIELD_CLASSVAR or any(f._field_type is not _FIELD for f in roster[1:]):return False
        counter=roster[0]
        if counter.default != 1 or type(counter.default) is not int or counter.default_factory is not MISSING or counter.init is not True or counter.kw_only is not MISSING:return False
        if any(f.default is not MISSING or f.default_factory is not MISSING or f.kw_only is not False for f in roster[1:]):return False
        if roster[1].init is not False or any(f.init is not True for f in roster[2:]):return False
        if any(f.repr is not True or f.compare is not True or f.hash is not None or type(f.metadata) is not types.MappingProxyType or f.metadata for f in roster):return False
        init_fields=roster[1:]
        ordinary=[f for f in init_fields if f.init]
        try:
            generated=_init_fn(init_fields,ordinary,[],False,True,"self",vars(module),False)
        except (TypeError,AttributeError):return False
        if type(cls.__init__) is not types.FunctionType or cls.__init__.__code__!=generated.__code__:return False
        if cls.__init__.__globals__ is not vars(module):return False
        if cls.__init__.__defaults__!=generated.__defaults__ or cls.__init__.__kwdefaults__!=generated.__kwdefaults__:return False
    # Message constructors referenced by the original producer globals must be
    # those same authenticated dataclass classes, not a patched exported twin.
    from abides_markets.agents import exchange_agent
    from abides_markets import order_book
    import abides_core.kernel as kernel
    bindings=((trading_agent,"MarketClosePriceRequestMsg",market.MarketClosePriceRequestMsg),(trading_agent,"MarketHoursRequestMsg",market.MarketHoursRequestMsg),(trading_agent,"QuerySpreadMsg",query.QuerySpreadMsg),(trading_agent,"LimitOrderMsg",order.LimitOrderMsg),(trading_agent,"CancelOrderMsg",order.CancelOrderMsg),(exchange_agent,"MarketHoursMsg",market.MarketHoursMsg),(exchange_agent,"QuerySpreadResponseMsg",query.QuerySpreadResponseMsg),(exchange_agent,"MarketClosePriceMsg",market.MarketClosePriceMsg),(exchange_agent,"MarketClosedMsg",market.MarketClosedMsg),(order_book,"OrderAcceptedMsg",orderbook.OrderAcceptedMsg),(order_book,"OrderExecutedMsg",orderbook.OrderExecutedMsg),(order_book,"OrderCancelledMsg",orderbook.OrderCancelledMsg),(kernel,"WakeupMsg",message.WakeupMsg))
    if any(getattr(module,name,None) is not value for module,name,value in bindings):return False
    if trading_agent.LimitOrder is not orders.LimitOrder:return False
    defaults=trading_agent.TradingAgent.cancel_order.__defaults__
    if type(defaults) is not tuple or len(defaults)!=2 or defaults[0] is not None or type(defaults[1]) is not dict or defaults[1]:return False
    # Exact four acts only call normal limit placement/cancel/query spread.
    # The complete original engine is selected upfront for any unsupported
    # loaded callback/default family; native code never performs mid-event fallback.
    checks=((message,"Message",("__post_init__","__lt__")),(trading_agent,"TradingAgent",("wakeup","receive_message","cancel_all_orders")))
    for module,class_name,names in checks:
        cls=getattr(module,class_name)
        for name in names:
            func=getattr(cls,name)
            if type(func) is not types.FunctionType or func.__code__!=_code_at(module,class_name,name,compiled):return False
            if func.__globals__ is not vars(module) or not _defaults_match(func,module,class_name,name,parsed):return False
    return True
