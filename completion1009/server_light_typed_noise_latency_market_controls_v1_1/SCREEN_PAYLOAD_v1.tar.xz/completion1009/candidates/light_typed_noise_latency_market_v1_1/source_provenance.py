"""Fresh coherent light typed Noise/latency source/runtime binding; all reviewed bytes required."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE_RECEIPT = "SOURCE_PREPARATION_RECEIPT_v1.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean_path(relative):
    path = Path(relative)
    return (type(relative) is str and relative and not path.is_absolute() and path.as_posix() == relative
        and "\\" not in relative and "\x00" not in relative and "//" not in relative
        and all(part not in ("", ".", "..", "__pycache__", "__MACOSX") and not part.startswith("._") for part in relative.split("/")))


def verify_sources():
    receipt = json.loads((HERE / SOURCE_RECEIPT).read_bytes())
    if (receipt.get("schema") != "t3-light-typed-noise-latency-market-frozen-source-v1"
            or receipt.get("frozen_build_input") is not True or receipt.get("unfrozen") is not False):
        raise ValueError("exact light typed Noise frozen source receipt required")
    rows = receipt["files"]
    if len({row["path"] for row in rows}) != len(rows):
        raise ValueError("duplicate light typed Noise source pins")
    for row in rows:
        path = HERE / row["path"]
        if not clean_path(row["path"]) or path.is_symlink() or len(path.read_bytes()) != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("frozen light typed Noise source changed: " + row["path"])
    return receipt


def verify_runtime(runtime):
    runtime = Path(runtime).resolve()
    pins = json.loads((HERE / "RUNTIME_PINS.json").read_bytes())
    if pins.get("schema") != "t3-light-typed-noise-market-runtime-pins-v1" or pins.get("file_count") != 68:
        raise ValueError("complete fresh68 runtime roster required")
    rows = pins["files"]
    if len(rows) != 68 or len({row["path"] for row in rows}) != 68:
        raise ValueError("duplicate or incomplete light typed Noise runtime pins")
    for row in rows:
        path = runtime / row["path"]
        if not clean_path(row["path"]) or path.is_symlink() or len(path.read_bytes()) != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("fresh pinned light/native runtime changed: " + row["path"])
    actual = {path.relative_to(runtime).as_posix() for path in runtime.rglob("*") if path.is_file()
              and not any(part.startswith("._") or part in ("__pycache__", "__MACOSX") for part in path.parts)
              and path.relative_to(runtime).as_posix() not in ("schema_metadata_v1.json", "schema_metadata_pin_v1.py")}
    if actual != {row["path"] for row in rows}:
        raise ValueError("runtime contains unmanifested/missing source")
    return pins
