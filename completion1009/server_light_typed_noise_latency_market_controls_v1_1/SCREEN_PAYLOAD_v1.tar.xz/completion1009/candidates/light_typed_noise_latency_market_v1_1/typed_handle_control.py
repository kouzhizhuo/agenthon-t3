"""Future finite typed-handle control runner; source preparation never runs it."""
import argparse,json
from pathlib import Path
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--runtime",type=Path,required=True)
    parser.add_argument("--build",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    if args.out.exists():raise ValueError("fresh finite control evidence required")
    from production_cli import activate_paths
    activate_paths(args.runtime)
    from native_loader import load
    loaded=load(args.build,args.runtime)
    report=loaded["dynamic_arena_chain"].control_typed_handle_checks()
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
    if report.get("all_passed") is not True:raise AssertionError("typed handle finite control failed")
if __name__=="__main__":main()
