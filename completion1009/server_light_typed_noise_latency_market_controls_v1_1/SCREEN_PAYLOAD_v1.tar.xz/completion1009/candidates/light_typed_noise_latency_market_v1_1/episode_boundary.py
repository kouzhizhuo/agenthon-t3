"""Cold episode ownership, public exposure, rollback and finally boundaries."""
from cleanup_errors import detail


class NoiseEpisodeBoundary:
    def __init__(self, entries):
        self.entries = tuple(entries)
        self.by_actor = {id(actor): (actor, owner, rng) for actor, owner, rng in self.entries}
        if len(self.by_actor) != len(self.entries) or len({id(rng) for _, _, rng in self.entries}) != len(self.entries):
            raise ValueError("unique controlled actor and exclusive retained RNG identities required")
        self.closed = False
        self.cleanup_failures = []

    def rebind_native_actors(self, source_to_native):
        # Cold one-time migration only; all identity mapping is checked before mutation.
        rebound = []
        for actor, owner, rng in self.entries:
            native = source_to_native.get(id(actor))
            if native is None:
                raise ValueError("complete source-to-native Noise actor mapping required")
            rebound.append((native, owner, rng))
        if len({id(actor) for actor, _, _ in rebound}) != len(rebound):
            raise ValueError("native Noise actor identities must stay distinct")
        self.entries = tuple(rebound)
        self.by_actor = {id(actor): (actor, owner, rng) for actor, owner, rng in self.entries}

    def retire_after_export(self, actor):
        # Native field detachment occurs only after its export succeeds.
        value = self.by_actor.get(id(actor))
        if value is not None and value[0] is actor:
            self.by_actor.pop(id(actor))

    def owner_for_controlled_actor(self, actor):
        value = self.by_actor.get(id(actor))
        if value is None or value[0] is not actor:
            return None
        return value[1]

    def expose_rng(self, actor):
        value = self.by_actor.get(id(actor))
        if value is None or value[0] is not actor:
            raise ValueError("admitted controlled actor required")
        value[1].export_to_original()
        return value[2]

    def before_replace_rng(self, actor):
        # Native actor setter exports the former identity, then keeps the new
        # RNG on the original route for the rest of this episode.
        self.expose_rng(actor)
        # Retain entries for terminal cleanup, but the old stream must never be
        # selected again after the caller installs a replacement public RNG.
        self.by_actor.pop(id(actor))

    def export_all(self):
        failures = []
        for actor, owner, rng in self.entries:
            try:
                owner.export_to_original()
            except BaseException as error:
                failures.append({"actor_id": id(actor), "rng_id": id(rng), **detail(error)})
        self.cleanup_failures.extend(failures)
        self.closed = not failures
        if failures:
            raise RuntimeError("owned Noise RNG terminal export incomplete")

    def run(self, controlled_runner, *args, **kwargs):
        active_error = False
        try:
            return controlled_runner(*args, **kwargs)
        except BaseException:
            active_error = True
            raise
        finally:
            try:
                self.export_all()
            except BaseException:
                # Preserve the active participant error; retain export failure
                # separately. Normal/early returns fail if export failed.
                if not active_error:
                    raise

    def rollback_before_draw(self):
        self.export_all()
