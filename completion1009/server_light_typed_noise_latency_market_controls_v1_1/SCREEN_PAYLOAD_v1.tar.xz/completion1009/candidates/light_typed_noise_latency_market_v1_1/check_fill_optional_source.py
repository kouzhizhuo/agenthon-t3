from pathlib import Path
import ast,re,json,hashlib
D=Path(__file__).resolve().parent;p=D/'dynamic_arena_chain.pyx'
# Import only stdlib static normalization definitions from the temporary authored script.
module=ast.parse((D/'check_source_normalize.py').read_bytes());ns={}
keep=[n for n in module.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
exec(compile(ast.fix_missing_locations(ast.Module(body=keep,type_ignores=[])),'stdlib_arena_normalizer','exec'),ns)
s=p.read_text();lines=s.splitlines(keepends=True);tree=ns['normalize'](s)
sigs={};defs=[]
for c in tree.body:
 if not isinstance(c,ast.ClassDef):continue
 sigs[c.name]={}
 for m in c.body:
  if isinstance(m,ast.FunctionDef) and re.match(r'^    cdef .*?\*?'+re.escape(m.name)+r'\(',lines[m.lineno-1]):
   args=[a.arg for a in m.args.args][1:];defaults=dict(zip(args[len(args)-len(m.args.defaults):],m.args.defaults))
   sigs[c.name][m.name]=(args,defaults)
changes=[];checked=[];unresolved=[]
for c in tree.body:
 if not isinstance(c,ast.ClassDef):continue
 for method in c.body:
  if not isinstance(method,ast.FunctionDef):continue
  locals={'self':c.name}
  for line in lines[method.lineno-1:method.end_lineno]:
   m=re.match(r'\s*cdef (NativeTrader|NativeExchange|NativeBook|NativeLevel|ChainScheduler|OrderArena|MessageArena|DeliveryHeap|ColumnLedger) (\w+)',line)
   if m:locals[m.group(2)]=m.group(1)
  for n in ast.walk(method):
   if not isinstance(n,ast.Call) or not isinstance(n.func,ast.Attribute):continue
   name=n.func.attr;v=n.func.value;target=None
   if isinstance(v,ast.Name):target=locals.get(v.id)
   elif isinstance(v,ast.Attribute) and isinstance(v.value,ast.Name) and v.value.id=='self':target={'_orders':'OrderArena','orders':'OrderArena','_messages':'MessageArena','messages':'MessageArena','_scheduler':'ChainScheduler','_owner':'NativeExchange','heap':'DeliveryHeap','arena':'MessageArena','ledger':'ColumnLedger'}.get(v.attr)
   options=[k for k,x in sigs.items() if name in x and x[name][1]]
   if target is None:
    snippet=lines[n.lineno-1][n.col_offset:n.end_col_offset];m=re.search(r'<(NativeBook|NativeLevel)>',snippet)
    if m:target=m.group(1)
   if target is None and len(options)==1:target=options[0]
   if target is None and c.name=='NativeExchange' and name=='_cancel_order':target='NativeBook'
   if target not in sigs or name not in sigs[target] or not sigs[target][name][1]:
    if options and target is None:unresolved.append([c.name,method.name,n.lineno,name])
    continue
   args,defaults=sigs[target][name];bound=dict(zip(args,n.args));bound.update({k.arg:k.value for k in n.keywords})
   if any(a not in bound and a not in defaults for a in args):raise ValueError(('required_missing',c.name,method.name,n.lineno,args,bound))
   effective=[bound.get(a,defaults.get(a)) for a in args]
   checked.append([c.name,method.name,n.lineno,target,name])
   if len(n.args)==len(args) and not n.keywords:continue
   inner=""
   line=lines[n.lineno-1]
   normalized_line=ns['normalize']('def temp():\n'+line).body[0] if False else None
   # Search actual function prefix by identifying supplied expression receiver segment.
   receiver=ast.unparse(n.func.value)
   candidate=re.search(r'((?:\(<[^>]+>[^\n]*?\)|self(?:\.[A-Za-z_]\w*)*)\.'+re.escape(name)+r'\()',line)
   # Direct source position is correct for cdef-body normalized lines except cast positions.
   method_ix=line.find('.'+name+'(',max(0,n.col_offset-40))
   if method_ix<0:raise ValueError(line)
   call_start=n.col_offset
   if line[call_start:method_ix].strip().startswith('(') is False and '(' in line[call_start:method_ix]:call_start=line.rfind('(',0,method_ix)
   open_ix=method_ix+len(name)+1
   depth=0;q=None;esc=False;close_ix=None
   for j in range(open_ix,len(line)):
    ch=line[j]
    if q:
     if esc:esc=False
     elif ch=='\\':esc=True
     elif ch==q:q=None
    elif ch in "'\"":q=ch
    elif ch=='(':depth+=1
    elif ch==')':
     depth-=1
     if depth==0:close_ix=j+1;break
   actual=line[call_start:close_ix]
   # Repeat replacement renderer on actual original call inner preserves Cython syntax.
   before_paren=actual.find('.'+name+'(')+len(name)+1
   actual_inner=actual[before_paren+1:-1]
   # If actual receiver had prefix offset drift, retain exact actual segment only.
   # Current source optional calls are simple one-line statements, no multiline expansion.
   if actual_inner!=inner:
    inner=actual_inner;tokens=[];last=0;level=0;quote=None;escape=False
    for i,ch in enumerate(inner):
     if quote:
      if escape:escape=False
      elif ch=='\\':escape=True
      elif ch==quote:quote=None
     elif ch in "'\"":quote=ch
     elif ch in '([{':level+=1
     elif ch in ')]}':level-=1
     elif ch==',' and level==0:tokens.append(inner[last:i].strip());last=i+1
    if inner[last:].strip():tokens.append(inner[last:].strip())
    supplied={};pos=0
    for token in tokens:
     match=re.match(r'^([A-Za-z_]\w*)\s*=(?!=)',token)
     if match:supplied[match.group(1)]=token[match.end():].strip()
     else:supplied[args[pos]]=token;pos+=1
   rendered=actual[:before_paren+1]+', '.join(supplied[a] if a in supplied else ast.unparse(defaults[a]) for a in args)+')'
   a=sum(map(len,lines[:n.lineno-1]))+call_start;b=sum(map(len,lines[:n.lineno-1]))+close_ix
   changes.append((a,b,rendered))
if unresolved:raise ValueError(unresolved)
# Nested optional calls may overlap; apply outer call with unchanged nested source then next scan rounds.
selected=[]
for x in sorted(changes):
 if selected and x[0]<selected[-1][1]:continue
 selected.append(x)
for a,b,v in sorted(selected,reverse=True):s=s[:a]+v+s[b:]
ns['normalize'](s)
if selected:p.write_text(s)
print(json.dumps({'optional_calls_checked':len(checked),'changed':len(selected),'unresolved':unresolved}))
