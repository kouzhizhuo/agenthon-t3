"""Cold exact original final-sequence filtering and stable tie ordering."""


def extract(end_state, columns, dtypes):
    import pandas as pd
    import dynamic_arena_chain as engine
    ledger = end_state.get("message_ledger")
    seqmap = end_state.get("deliver_seq_by_key") or {}
    if type(ledger) is not engine.ColumnLedger or type(seqmap) is not dict:
        raise ValueError("actual chain ledger and final sequence dictionary required")
    names = ("message_id", "src_id", "dst_id", "t_send_ns", "t_recv_ns", "latency_ns", "msg_type", "order_id", "causal_parent")
    rows = []
    for index in range(len(ledger)):
        message_id = ledger.columns[0][index]
        dst = ledger.columns[2][index]
        seq = seqmap.get((int(message_id), int(dst)))
        if seq is not None:
            rows.append((seq, index))
    rows.sort(key=lambda pair: pair[0])
    result = {}
    for name in columns:
        values = [seq for seq, _ in rows] if name == "seq" else [ledger.columns[names.index(name)][i] for _, i in rows]
        # Same nullable integer construction and original dtype order.
        result[name] = pd.array(values, dtype=dtypes[name]) if dtypes[name] in ("Int64", "string") else values
    return pd.DataFrame(result, columns=columns).astype(dtypes)[columns]
