"""Genuine initialized original/integrated kernel fixture; finite controls only."""
import json
from pathlib import Path
from cleanup_errors import attach, detail

HERE = Path(__file__).resolve().parent


def fixture(native, np, migrated=False, scenario=None):
    import observer
    from observer_domain import authenticate_loaded
    from latency_admission import authenticate_runtime
    from native_runtime_binding import runtime_for
    from abides_fork.config import build_config
    from abides_core.kernel import Kernel
    from native_owner_kernel import NativeOwnerKernel
    from abides_core.utils import subdict
    from counters import reset_abides_counters
    from state_mapper import migrate
    if scenario is None:
        scenario = json.loads((HERE / "control_scenario.json").read_bytes())
    if observer.STATE is not None or not authenticate_loaded():
        raise ValueError("fresh exact original observer source required")
    authenticate_runtime(runtime_for(native))
    np.random.seed(19301009)
    reset_abides_counters()
    if not observer.begin_episode(scenario, True):
        raise ValueError("actual control scenario observer admission required")
    kernel = None
    try:
        config = build_config(scenario)
        cls = NativeOwnerKernel if migrated else Kernel
        kernel = cls(random_state=np.random.RandomState(0), log_dir="finite-latency-controls",
            **subdict(config, ["start_time", "stop_time", "agents", "agent_latency_model",
                              "default_computation_delay", "custom_properties"]))
        # Invoke genuine original initialization without automatic migration so
        # the actual cold graph and precommit controls have a visible cut.
        Kernel.initialize(kernel)
        model = kernel.__dict__["agent_latency_model"]
        raw_dict = object.__getattribute__(model, "__dict__")
        rng = raw_dict["random_state"]
        if migrated:
            record = migrate(kernel, native)
            record.assert_authority()
            owner = kernel._latency_acquisition.owner
            if owner is None or not owner.diagnostics()["owned"]:
                raise ValueError("actual private configured latency owner required")
        else:
            owner = None
        return {"kernel": kernel, "model": model, "raw_dict": raw_dict, "rng": rng,
                "owner": owner, "config": config}
    except BaseException as error:
        failures = []
        if kernel is not None:
            boundary = kernel.__dict__.get("_chain_episode_boundary")
            if boundary is not None:
                try:
                    boundary.export_all()
                except BaseException as cleanup:
                    failures.append({"phase": "fixture-export-all", **detail(cleanup)})
        try:
            observer.finish_episode()
        except BaseException as cleanup:
            failures.append({"phase": "fixture-finish-observer", **detail(cleanup)})
        if failures:
            attach(error, "finite_fixture_cleanup_failures", failures)
        raise


def cleanup(values, active_error=None):
    import observer
    failures = []
    boundary = values["kernel"].__dict__.get("_chain_episode_boundary")
    if boundary is not None:
        try:
            boundary.export_all()
        except BaseException as error:
            failures.append({"phase": "fixture-export-all", **detail(error)})
    try:
        observer.finish_episode()
    except BaseException as error:
        failures.append({"phase": "fixture-finish-observer", **detail(error)})
    if failures:
        if active_error is not None:
            attach(active_error, "finite_fixture_cleanup_failures", failures)
        else:
            raise RuntimeError("finite fixture cleanup incomplete")
    return failures
