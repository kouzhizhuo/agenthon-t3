"""Cold exact configured-latency authority and symmetric active RNG census.

This module runs before config construction and once after original initialize.
It adds no authentication work to the private event loop and accepts no caller
token. Unknown/default/absent models and unsupported fields decline without
changing their original route. Arbitrary outside raw aliases are not admitted.
"""
import ast
import builtins
import hashlib
import importlib
import math
from pathlib import Path
import sys
import types


HERE = Path(__file__).resolve().parent
MODEL_FIELDS = ("_model", "_mean_ns", "_sigma", "_min_ns", "_max_ns", "_alpha",
                "_mu", "latency_model", "random_state", "min_latency")
FLOAT_FIELDS = ("_mean_ns", "_sigma", "_min_ns", "_max_ns", "_alpha", "_mu")
NUMPY_DONOR_PINS = {
    "numpy_authentication.py": (8058, "e8117578859e7c3c0f83fe80d492cc788db150fe4bcf2cbe5337056a2ef35cf3"),
    "NUMPY_SOURCE_PINS_v1.json": (1387, "5c1f443af65bd0692e0e237336d9f76767e28d4610bdf1b5f092eee2be2f7a27"),
}


class NumericAuthority:
    def __init__(self, np, token, model_class, base_class):
        self.np = np
        self.token = token
        self.model_class = model_class
        self.base_class = base_class


class LatencyAcquisition:
    def __init__(self, owner, source_model, raw_dict, fields, rng, declined_reason):
        self.owner = owner
        self.source_model = source_model
        self.raw_dict = raw_dict
        self.fields = fields
        self.rng = rng
        self.declined_reason = declined_reason


def _declined(model, reason, raw_dict=None, fields=None, rng=None):
    return LatencyAcquisition(None, model, raw_dict, fields, rng, reason)


def _codes(code):
    found = {(code.co_name, code.co_firstlineno): code}
    for value in code.co_consts:
        if type(value) is types.CodeType:
            found.update(_codes(value))
    return found


def _source_function(fn, declaration, module, codes, cls=None):
    if (type(fn) is not types.FunctionType or fn.__module__ != module.__name__
            or fn.__globals__ is not vars(module)
            or fn.__builtins__ is not builtins.__dict__
            or fn.__code__ != codes.get((declaration.name, declaration.lineno))):
        raise ValueError("cold latency source function/code/globals differs")
    defaults = tuple(ast.literal_eval(value) for value in declaration.args.defaults) or None
    keywords = {argument.arg: ast.literal_eval(value)
                for argument, value in zip(declaration.args.kwonlyargs, declaration.args.kw_defaults)
                if value is not None} or None
    if fn.__defaults__ != defaults or fn.__kwdefaults__ != keywords:
        raise ValueError("cold latency source defaults differ")
    if fn.__code__.co_freevars == ("__class__",):
        if (cls is None or type(fn.__closure__) is not tuple or len(fn.__closure__) != 1
                or fn.__closure__[0].cell_contents is not cls):
            raise ValueError("cold latency original class closure differs")
    elif fn.__code__.co_freevars or fn.__closure__ is not None:
        raise ValueError("cold latency unexpected source closure")


def _source_class(cls, declaration, module, codes, bases, storage):
    methods = {node.name: node for node in declaration.body if type(node) is ast.FunctionDef}
    expected = {"__module__", "__doc__", *methods}
    if storage:
        expected.update(("__dict__", "__weakref__"))
    roster = vars(cls)
    if (type(cls) is not type or cls.__module__ != module.__name__
            or cls.__bases__ != bases or set(roster) != expected
            or roster["__doc__"] != ast.get_docstring(declaration, clean=False)
            or cls.__getattribute__ is not object.__getattribute__
            or hasattr(cls, "__getattr__") or cls.__setattr__ is not object.__setattr__
            or cls.__delattr__ is not object.__delattr__):
        raise ValueError("cold latency source class/storage/lookup differs")
    for name in ("__dict__", "__weakref__"):
        if name in roster:
            descriptor = roster[name]
            if (type(descriptor) is not types.GetSetDescriptorType
                    or descriptor.__objclass__ is not cls or descriptor.__name__ != name):
                raise ValueError("cold latency original storage descriptor differs")
    for name, node in methods.items():
        _source_function(roster[name], node, module, codes, cls)


def _authenticate_numpy_donor(np):
    for name, (size, digest) in NUMPY_DONOR_PINS.items():
        path = HERE / name
        data = path.read_bytes()
        if path.is_symlink() or len(data) != size or hashlib.sha256(data).hexdigest() != digest:
            raise ValueError("exact frozen V1.5 NumPy authentication donor required")
    module = importlib.import_module("numpy_authentication")
    path = HERE / "numpy_authentication.py"
    if (type(module) is not types.ModuleType or module.__name__ != "numpy_authentication"
            or Path(module.__file__).resolve() != path or module.HERE != HERE
            or module.MODULES != ("numpy.core.fromnumeric", "numpy.core._methods",
                                   "numpy.core.overrides", "numpy.core.multiarray")):
        raise ValueError("actual loaded pinned NumPy authentication module required")
    source = path.read_bytes()
    codes = _codes(compile(source, str(path), "exec", dont_inherit=True))
    tree = ast.parse(source)
    for node in tree.body:
        if type(node) is ast.FunctionDef:
            _source_function(vars(module).get(node.name), node, module, codes)
        elif type(node) is ast.ClassDef:
            _source_class(vars(module).get(node.name), node, module, codes, (object,), True)
    imports = {"ast": ast, "hashlib": hashlib, "importlib": importlib,
               "json": importlib.import_module("json"), "Path": Path, "types": types}
    if any(vars(module).get(name) is not value for name, value in imports.items()):
        raise ValueError("NumPy authentication donor imported authority differs")
    for name in ("type", "isinstance", "getattr", "hasattr", "vars", "compile", "callable",
                 "next", "tuple", "dict", "all", "len", "ValueError"):
        if name in vars(module) and vars(module)[name] is not getattr(builtins, name):
            raise ValueError("NumPy authentication donor builtin override")
    # Genuine authenticated constructor only, never __new__ or a caller token.
    token = module.PristineToken(np)
    if (type(token) is not module.PristineToken or token.np is not np
            or token.source_verified is not True or not token.verify_loaded()):
        raise ValueError("internally established original NumPy authority required")
    return token


def authenticate_runtime(runtime):
    """Authenticate numeric authority before original config log/zeros executes."""
    runtime = Path(runtime).resolve()
    from source_provenance import verify_sources
    verify_sources()
    from noise_admission import authenticate_runtime as authenticate_noise_runtime, _compile_source
    np, _ = authenticate_noise_runtime(runtime)
    from abides_fork import config
    from abides_core import latency_model
    for module, relative, specs in (
            (latency_model, "vendor/abides/abides-core/abides_core/latency_model.py",
             (("LatencyModel", (object,), True),)),
            (config, "abides_fork/config.py",
             (("ScenarioLatencyModel", (latency_model.LatencyModel,), False),))):
        path = runtime / relative
        if Path(module.__file__).resolve() != path:
            raise ValueError("actual configured latency source path differs")
        source = path.read_bytes()
        code, tree = _compile_source(source, path)
        codes = _codes(code)
        for name, bases, storage in specs:
            declaration = next(node for node in tree.body if type(node) is ast.ClassDef and node.name == name)
            _source_class(vars(module).get(name), declaration, module, codes, bases, storage)
    if (config.ScenarioLatencyModel.__mro__ != (config.ScenarioLatencyModel, latency_model.LatencyModel, object)
            or latency_model.LatencyModel.__mro__ != (latency_model.LatencyModel, object)
            or config.LatencyModel is not latency_model.LatencyModel or latency_model.np is not np):
        raise ValueError("exact configured/base latency class chain required")
    for module in (config, latency_model):
        for name in ("round", "float", "int", "str", "super", "type"):
            if name in vars(module) and vars(module)[name] is not getattr(builtins, name):
                raise ValueError("configured latency numeric builtin override")
    mtrand = importlib.import_module("numpy.random.mtrand")
    for name in ("lognormal", "uniform", "pareto", "get_state", "set_state"):
        descriptor = vars(mtrand.RandomState).get(name)
        if (type(descriptor) is not types.MethodDescriptorType
                or descriptor.__objclass__ is not mtrand.RandomState or descriptor.__name__ != name):
            raise ValueError("original mtrand latency C descriptor required")
    token = _authenticate_numpy_donor(np)
    return NumericAuthority(np, token, config.ScenarioLatencyModel, latency_model.LatencyModel)


def _model_fields(model, authority):
    if model is None:
        return _declined(model, "absent-latency-model")
    if type(model) is authority.base_class:
        return _declined(model, "default-latency-model")
    if type(model) is not authority.model_class:
        return _declined(model, "foreign-latency-model")
    raw = object.__getattribute__(model, "__dict__")
    if type(raw) is not dict or tuple(raw) != MODEL_FIELDS:
        return _declined(model, "unsupported-model-field-roster", raw)
    fields = dict(raw)
    if (type(fields["_model"]) is not str or type(fields["latency_model"]) is not str
            or fields["latency_model"] != "deterministic"):
        return _declined(model, "unsupported-model-kind", raw, fields)
    if any(type(fields[name]) is not float or not math.isfinite(fields[name]) for name in FLOAT_FIELDS):
        return _declined(model, "unsupported-model-scalars", raw, fields)
    low, high = fields["_min_ns"], fields["_max_ns"]
    if not 0 <= low <= high <= 2 ** 53 or not math.isfinite(high - low):
        return _declined(model, "unsupported-model-bounds", raw, fields)
    if fields["_model"] == "log_normal" and math.copysign(1.0, fields["_sigma"]) < 0:
        return _declined(model, "unsupported-lognormal-sigma", raw, fields)
    if fields["_model"] == "pareto" and fields["_alpha"] <= 0:
        return _declined(model, "unsupported-pareto-alpha", raw, fields)
    np = authority.np
    matrix = fields["min_latency"]
    if type(matrix) is not np.ndarray or matrix.ndim != 2 or matrix.dtype != np.dtype("float64"):
        return _declined(model, "unsupported-original-latency-matrix", raw, fields)
    rng = fields["random_state"]
    if type(rng) is not np.random.RandomState:
        return _declined(model, "unsupported-latency-RNG", raw, fields, rng)
    return LatencyAcquisition(None, model, raw, fields, rng, None)


def _owner(acquisition, native, authority, blocked_rngs):
    if acquisition.declined_reason is not None:
        return acquisition
    rng = acquisition.rng
    if any(rng is value for value in blocked_rngs):
        acquisition.declined_reason = "shared-active-latency-RNG"
        return acquisition
    from noise_admission import public_state
    state = public_state(rng, authority.np)
    acquisition.owner = native.ConfiguredLatencyRNGOwner(acquisition.source_model,
        acquisition.fields, rng, state, rng.get_state, rng.set_state,
        authority.np.asarray, authority.np.uint32, authority.np.clip)
    return acquisition


def _bound_native(native, runtime):
    from native_runtime_binding import runtime_for
    if (type(native) is not types.ModuleType or native.__name__ != "dynamic_arena_chain"
            or sys.modules.get("dynamic_arena_chain") is not native
            or runtime_for(native) != Path(runtime).resolve()):
        raise ValueError("actual loader-bound same-extension latency owner required")


def acquire_initialized(kernel, native, runtime, source_model):
    """One no-draw original-initialize census before any source dict retires."""
    _bound_native(native, runtime)
    authority = authenticate_runtime(runtime)
    from abides_core.kernel import Kernel
    from native_owner_kernel import NativeOwnerKernel
    if type(kernel) not in (Kernel, NativeOwnerKernel):
        raise ValueError("actual exact original or native kernel required")
    raw = object.__getattribute__(kernel, "__dict__")
    if (type(raw) is not dict
            or "agent_latency_model" not in raw or source_model is not raw["agent_latency_model"]
            or any(name in raw for name in ("_chain_scheduler", "_chain_migration", "_chain_episode_boundary"))):
        raise ValueError("actual fresh original kernel latency field required")
    if (raw["ttl_messages"] != 0 or raw["_deliver_seq"] != 0
            or raw["_current_causal_uid"] is not None or raw["current_time"] != raw["start_time"]
            or raw["gym_agents"] or raw["custom_state"]):
        raise ValueError("genuine original initialized latency census required")
    acquisition = _model_fields(source_model, authority)
    if acquisition.declined_reason is not None:
        return acquisition
    from abides_fork import agents, config
    from abides_markets.agents.exchange_agent import ExchangeAgent
    roster = raw["agents"]
    classes = (ExchangeAgent, agents.NoiseTrader, agents.MarketMaker,
               agents.ValueTrader, agents.MomentumTrader)
    if (type(roster) is not list or not roster or type(roster[0]) is not ExchangeAgent
            or len({id(actor) for actor in roster}) != len(roster)):
        raise ValueError("actual original exchange-first latency consumer roster required")
    blocked = []
    for index, actor in enumerate(roster):
        if type(actor) not in classes:
            raise ValueError("unsupported active latency consumer class")
        actor_fields = object.__getattribute__(actor, "__dict__")
        if (type(actor_fields) is not dict or type(actor_fields.get("id")) is not int
                or actor_fields["id"] != index or actor_fields.get("kernel") is not kernel):
            raise ValueError("actual dense original actor RNG census required")
        rng = actor_fields["random_state"]
        if type(rng) is not authority.np.random.RandomState:
            raise ValueError("actual original actor RandomState census required")
        # Include every Noise actor even if its private owner was declined.
        blocked.append(rng)
    if type(raw["random_state"]) is not authority.np.random.RandomState:
        raise ValueError("actual kernel RandomState census required")
    blocked.extend((raw["random_state"], authority.np.random.mtrand._rand))
    oracle = raw["oracle"]
    if oracle is not None:
        if type(oracle) is not config.SparseMeanRevertingOracle:
            raise ValueError("actual original oracle latency census required")
        symbols = object.__getattribute__(oracle, "__dict__")["symbols"]
        if type(symbols) is not dict or any(type(value) is not dict for value in symbols.values()):
            raise ValueError("actual original oracle symbol dictionary census required")
        for value in symbols.values():
            rng = value["random_state"]
            if type(rng) is not authority.np.random.RandomState:
                raise ValueError("actual original oracle symbol RandomState census required")
            blocked.append(rng)
    return _owner(acquisition, native, authority, blocked)


def acquire_control_model(model, native, runtime, active_consumer_rngs=()):
    """Finite standalone genuine-model helper; no fabricated authority token."""
    _bound_native(native, runtime)
    authority = authenticate_runtime(runtime)
    acquisition = _model_fields(model, authority)
    if acquisition.declined_reason is not None:
        return acquisition
    if type(active_consumer_rngs) not in (tuple, list):
        raise ValueError("finite actual control consumer RNG roster required")
    if any(type(rng) is not authority.np.random.RandomState for rng in active_consumer_rngs):
        raise ValueError("finite actual original control consumer RNG identities required")
    blocked = tuple(active_consumer_rngs) + (authority.np.random.mtrand._rand,)
    return _owner(acquisition, native, authority, blocked)
