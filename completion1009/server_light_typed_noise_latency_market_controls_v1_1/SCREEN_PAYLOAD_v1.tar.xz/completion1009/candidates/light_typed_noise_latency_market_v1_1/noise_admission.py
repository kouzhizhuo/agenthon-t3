"""One cold authentication/census before first controlled Noise RNG draw."""
import ast
import builtins
import hashlib
import importlib
import json
import math
from pathlib import Path
import sys
import types
import warnings
from episode_boundary import NoiseEpisodeBoundary
from cleanup_errors import attach, detail

HERE = Path(__file__).resolve().parent


def pin(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def _exact_summary_suppression(fn):
    # One explicit shared cold IO exception. Arbitrary replaced methods still
    # fail source authentication, including functions with the same name.
    path = HERE / "production_cli.py"
    if type(fn) is not types.FunctionType:
        return False
    globals_ = fn.__globals__
    if (type(globals_) is not dict or Path(globals_.get("__file__", "")).resolve() != path
            or fn is not globals_.get("_suppressed_summary_log")
            or globals_.get("__name__") not in ("production_cli", "__main__")
            or fn.__defaults__ is not None or fn.__kwdefaults__ is not None or fn.__closure__ is not None):
        return False
    code = compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
    expected = [value for value in code.co_consts if type(value) is types.CodeType
                and value.co_name == "_suppressed_summary_log"]
    return len(expected) == 1 and fn.__code__ == expected[0]


def _source_defaults(fn, node, module):
    def matches(actual, expression):
        if (type(expression) is ast.Call and type(expression.func) is ast.Name
                and expression.func.id == "str_to_ns" and len(expression.args) == 1
                and not expression.keywords and type(expression.args[0]) is ast.Constant):
            # The two pinned Kernel constructor clocks are constant defaults;
            # check their initialized values without invoking source callbacks.
            clocks = {"09:30:00": 34200000000000, "16:00:00": 57600000000000}
            return type(actual) is module.np.int64 and int(actual) == clocks[expression.args[0].value]
        expected = ast.literal_eval(expression)
        def exact(left, right):
            if type(left) is not type(right):
                return False
            if type(right) in (tuple, list):
                return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
            if type(right) is dict:
                return tuple(left) == tuple(right) and all(exact(left[key], right[key]) for key in right)
            return left == right
        return exact(actual, expected)
    defaults = fn.__defaults__
    keyword_nodes = [(argument.arg, item) for argument, item in zip(node.args.kwonlyargs, node.args.kw_defaults)
                     if item is not None]
    if not node.args.defaults:
        positional_ok = defaults is None
    else:
        positional_ok = (type(defaults) is tuple and len(defaults) == len(node.args.defaults)
                         and all(matches(actual, expression) for actual, expression in zip(defaults, node.args.defaults)))
    keywords = fn.__kwdefaults__
    keyword_ok = (keywords is None if not keyword_nodes else type(keywords) is dict
                  and tuple(keywords) == tuple(name for name, _ in keyword_nodes)
                  and all(matches(keywords[name], expression) for name, expression in keyword_nodes))
    return positional_ok and keyword_ok



def _compile_source(source, path):
    """Ignore only the pinned original docstring's compiler-only diagnostic.

    No source body runs here. Numerical/callback warnings are outside this
    context and remain observable. Other compiler diagnostics fail closed.
    """
    path = Path(path)
    expected_sha = "bdc67c0f5d53829d442d8a53980a5e4242cb302bc4c84c98605a944b0d6a2a61"
    if path.name != "latency_model.py":
        return compile(source, str(path), "exec", dont_inherit=True), ast.parse(source)
    if hashlib.sha256(source).hexdigest() != expected_sha:
        raise ValueError("exact original latency docstring source required")
    with warnings.catch_warnings(record=True) as diagnostics:
        warnings.simplefilter("always")
        code = compile(source, str(path), "exec", dont_inherit=True)
        tree = ast.parse(source)
    if len(diagnostics) != 2 or any(item.category is not DeprecationWarning
            or str(item.message) not in ("invalid escape sequence '\\ '", "invalid escape sequence \\ ") or item.lineno != 7
            for item in diagnostics):
        raise ValueError("unexpected pinned source compilation diagnostic")
    return code, tree


def authenticate_runtime(runtime):
    runtime = Path(runtime).resolve()
    receipt = json.loads((HERE / "RUNTIME_PINS.json").read_bytes())
    for row in receipt["files"]:
        name = Path(row["path"])
        if name.is_absolute() or any(x in ("..", "__pycache__", "__MACOSX") or x.startswith("._") for x in name.parts):
            raise ValueError("clean original runtime source path required")
        if pin(runtime / name) != {k: row[k] for k in ("bytes", "sha256")}:
            raise ValueError("original runtime source differs before Noise ownership")
    from observer_domain import authenticate_loaded, _defaults_match
    if not authenticate_loaded():
        raise ValueError("original whole-episode inherited callback/global domain required")
    from abides_fork import agents, config
    from abides_core import agent, kernel, latency_model
    from abides_markets.oracles import sparse_mean_reverting_oracle, mean_reverting_oracle
    from abides_markets.agents import trading_agent
    modules = [(agents, "abides_fork/agents.py"), (config, "abides_fork/config.py"),
        (agent, "vendor/abides/abides-core/abides_core/agent.py"),
        (kernel, "vendor/abides/abides-core/abides_core/kernel.py"),
        (trading_agent, "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py"),
        (latency_model, "vendor/abides/abides-core/abides_core/latency_model.py"),
        (sparse_mean_reverting_oracle, "vendor/abides/abides-markets/abides_markets/oracles/sparse_mean_reverting_oracle.py"),
        (mean_reverting_oracle, "vendor/abides/abides-markets/abides_markets/oracles/mean_reverting_oracle.py")]
    for module, relative in modules:
        if Path(module.__file__).resolve() != runtime / relative:
            raise ValueError("loaded Noise inherited module path differs")
        # Only compile source to inert code objects; never invoke the source body.
        source = Path(module.__file__).read_bytes()
        code, tree = _compile_source(source, Path(module.__file__))
        def codes(value):
            result = {(value.co_name, value.co_firstlineno): value}
            for item in value.co_consts:
                if isinstance(item, types.CodeType):
                    result.update(codes(item))
            return result
        expected = codes(code)
        # The saved source fixes what must be authenticated. A foreign replaced
        # function/class must fail rather than silently disappear from a roster
        # selected from current __module__ attributes.
        selected = []
        for node in tree.body:
            if type(node) is ast.FunctionDef:
                value = vars(module).get(node.name)
                if type(value) is not types.FunctionType or value.__module__ != module.__name__:
                    raise ValueError("source-defined inherited Noise module function replaced")
                selected.append((node.name, value, node, None))
            elif type(node) is ast.ClassDef:
                cls = vars(module).get(node.name)
                if type(cls) is not type or cls.__module__ != module.__name__:
                    raise ValueError("source-defined inherited Noise class replaced")
                for method in node.body:
                    if type(method) is ast.FunctionDef:
                        value = vars(cls).get(method.name)
                        if type(value) is not types.FunctionType:
                            raise ValueError("source-defined inherited Noise method replaced")
                        selected.append((method.name, value, method, cls))
        for name, fn, node, cls in selected:
            if (module is kernel and name == "write_summary_log"
                    and fn is vars(kernel.Kernel).get("write_summary_log")
                    and _exact_summary_suppression(fn)):
                continue
            if (fn.__globals__ is not vars(module)
                    or fn.__builtins__ is not builtins.__dict__
                    or fn.__code__ != expected.get((name, fn.__code__.co_firstlineno))):
                raise ValueError("loaded inherited Noise source code/globals differ")
            if fn.__code__.co_freevars == ("__class__",):
                if (cls is None or type(fn.__closure__) is not tuple or len(fn.__closure__) != 1
                        or fn.__closure__[0].cell_contents is not cls):
                    raise ValueError("source-defined inherited Noise class closure differs")
            elif fn.__code__.co_freevars or fn.__closure__ is not None:
                raise ValueError("unexpected inherited Noise source closure")
            if not _source_defaults(fn, node, module):
                raise ValueError("source-defined inherited Noise defaults differ")
    defaults = {}
    for cls, names in ((agents.NoiseTrader, ("__init__", "act")),
                       (agents.ScheduledAgent, ("__init__", "kernel_starting", "wakeup", "receive_message", "act", "get_wake_frequency"))):
        for name in names:
            if not _defaults_match(vars(cls)[name], agents, cls.__name__, name, defaults):
                raise ValueError("original Noise constructor/callback defaults required")
    if (agents.NoiseTrader.__bases__ != (agents.ScheduledAgent,)
            or agents.ScheduledAgent.__bases__ != (trading_agent.TradingAgent,)):
        raise ValueError("original exact Noise inherited class chain required")
    if (config.LatencyModel is not latency_model.LatencyModel
            or config.ScenarioLatencyModel.__bases__ != (latency_model.LatencyModel,)
            or config.SparseMeanRevertingOracle is not sparse_mean_reverting_oracle.SparseMeanRevertingOracle
            or sparse_mean_reverting_oracle.SparseMeanRevertingOracle.__bases__ != (mean_reverting_oracle.MeanRevertingOracle,)
            or sparse_mean_reverting_oracle.MeanRevertingOracle is not mean_reverting_oracle.MeanRevertingOracle):
        raise ValueError("original configured latency/oracle base and factory identities required")
    import numpy as np
    umath = importlib.import_module("numpy.core._multiarray_umath")
    mtrand = importlib.import_module("numpy.random.mtrand")
    if (np.__version__ != "1.26.4" or agents.np is not np or config.np is not np
            or np.random.RandomState is not mtrand.RandomState
            or np.asarray is not umath.asarray or np.uint32 is not umath.dtype("uint32").type
            or np.ndarray is not umath.ndarray or np.dtype is not umath.dtype):
        raise ValueError("exact original NumPy RandomState and public state primitives required")
    global_rng = mtrand._rand
    if np.random.mtrand is not mtrand or type(global_rng) is not mtrand.RandomState:
        raise ValueError("actual original module-global RandomState required")
    # NumPy1.26.4 mtrand.pyx defines seed as a module-level convenience
    # wrapper; it is not the bound _rand.seed alias. Keep its module origin
    # separate from the actual singleton-bound scalar variate methods.
    seed = np.random.seed
    if (seed is not mtrand.seed or seed.__name__ != "seed"
            or seed.__module__ != mtrand.__name__):
        raise ValueError("original module-level RNG seed wrapper origin differs")
    for name in ("randint", "exponential"):
        fn = getattr(np.random, name)
        if (fn is not getattr(mtrand, name) or type(fn) is not types.BuiltinFunctionType
                or fn.__self__ is not global_rng or fn.__name__ != name):
            raise ValueError("module-global RNG function origin differs")
    for name in ("normal", "randint", "get_state", "set_state"):
        descriptor = vars(mtrand.RandomState).get(name)
        if (type(descriptor) is not types.MethodDescriptorType or descriptor.__objclass__ is not mtrand.RandomState
                or descriptor.__name__ != name):
            raise ValueError("original mtrand C RNG method origin required")
    for module in (agents, config):
        for name in ("round", "max", "int", "bool", "float"):
            value = getattr(builtins, name)
            if name in vars(module) and vars(module)[name] is not value:
                raise ValueError("overridden Noise scalar builtin global")
    if agents.AGENT_REGISTRY.get("NoiseTrader") is not agents.NoiseTrader:
        raise ValueError("original Noise registry identity required")
    return np, agents


def public_state(rng, np):
    state = rng.get_state()
    if (type(state) is not tuple or len(state) != 5 or state[0] != "MT19937"
            or type(state[1]) is not np.ndarray or state[1].dtype != np.dtype("uint32")
            or state[1].shape != (624,) or type(state[2]) is not int or not 0 <= state[2] <= 624
            or type(state[3]) is not int or state[3] not in (0, 1)
            or type(state[4]) is not float or not math.isfinite(state[4])):
        raise ValueError("full original finite public MT19937 state required")
    return (state[0], [int(x) for x in state[1]], state[2], state[3], state[4])


def acquire_initialized(kernel, native, runtime):
    """Called after original initialize, before cold source dictionaries retire."""
    np, agents = authenticate_runtime(runtime)
    roster = kernel.agents
    if type(roster) is not list or kernel.gym_agents or kernel.custom_state:
        raise ValueError("controlled original CLI roster without external actor callbacks required")
    candidate = [actor for actor in roster if type(actor) is agents.NoiseTrader]
    blocked_rngs = [actor.random_state for actor in roster if type(actor) is not agents.NoiseTrader]
    blocked_rngs += [kernel.random_state, np.random.mtrand._rand]
    from abides_fork import config
    from abides_core.latency_model import LatencyModel
    if kernel.agent_latency_model is not None:
        if type(kernel.agent_latency_model) not in (LatencyModel, config.ScenarioLatencyModel):
            raise ValueError("exact original latency RNG census domain required")
        blocked_rngs.append(kernel.agent_latency_model.random_state)
    oracle = kernel.oracle
    if oracle is not None:
        if type(oracle) is not config.SparseMeanRevertingOracle:
            raise ValueError("exact original oracle RNG census domain required")
        symbols = oracle.symbols
        if type(symbols) is not dict or any(type(value) is not dict for value in symbols.values()):
            raise ValueError("source-defined original oracle symbol RNG census required")
        blocked_rngs.extend(value["random_state"] for value in symbols.values())
    counts = {}
    for actor in candidate:
        counts[id(actor.random_state)] = counts.get(id(actor.random_state), 0) + 1
    entries, declined = [], []
    try:
        for actor in candidate:
            rng = actor.random_state
            if (type(rng) is not np.random.RandomState or counts[id(rng)] != 1
                    or any(rng is other for other in blocked_rngs)
                    or type(actor.order_size_mean) is not float or not math.isfinite(actor.order_size_mean)
                    or type(actor.order_size_std) is not float or not math.isfinite(actor.order_size_std)
                    or type(actor.price_offset_ticks) is not int):
                declined.append(actor.id)
                continue
            # Unsupported/invalid finite scalars may hand off at the original
            # call boundary; acquisition itself never draws or changes identity.
            owner = native.NoiseRNGOwner(rng, public_state(rng, np), rng.normal, rng.randint,
                rng.get_state, rng.set_state, np.asarray, np.uint32)
            entries.append((actor, owner, rng))
        boundary = NoiseEpisodeBoundary(entries)
    except BaseException as acquisition_error:
        cleanup_failures = []
        for actor, owner, rng in entries:
            try:
                owner.export_to_original()
            except BaseException as cleanup_error:
                cleanup_failures.append({"actor_id": id(actor), "rng_id": id(rng), **detail(cleanup_error)})
        # Record cleanup evidence without replacing the active acquisition
        # failure and attempt every acquired owner. This cold error path never
        # invokes a participant callback or retries acquisition/draws.
        attach(acquisition_error, "noise_ownership_cleanup_failures", cleanup_failures)
        raise
    boundary.declined_actor_ids = tuple(declined)
    return boundary
