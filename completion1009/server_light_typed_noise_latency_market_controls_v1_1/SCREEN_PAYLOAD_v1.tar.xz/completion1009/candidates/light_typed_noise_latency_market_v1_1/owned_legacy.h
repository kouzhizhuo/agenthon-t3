/* Finite NumPy 1.26.4 legacy scalar port. See NUMPY-LICENSE.txt and pins. */
#ifndef T3_EXACT_OWNED_LEGACY_H
#define T3_EXACT_OWNED_LEGACY_H
#include <stdint.h>

typedef struct {
  uint32_t key[624];
  int pos;
  int has_gauss;
  double gauss;
  int wide_high_first;
  uint64_t words_consumed;
  uint64_t twists;
  uint64_t normal_rejections;
  uint64_t integer_rejections;
} t3_owned_state;

uint32_t t3_next32(t3_owned_state *state);
uint64_t t3_next64(t3_owned_state *state);
double t3_next_double(t3_owned_state *state);
double t3_legacy_gauss(t3_owned_state *state);
double t3_legacy_normal(t3_owned_state *state, double loc, double scale);
double t3_legacy_lognormal(t3_owned_state *state, double mean, double sigma);
double t3_legacy_uniform(t3_owned_state *state, double lower, double range);
double t3_legacy_pareto(t3_owned_state *state, double a);
uint64_t t3_default_int64_fill_one(t3_owned_state *state, uint64_t off, uint64_t range);
int t3_signbit(double value);
#endif
