"""Future fused-expression and terminal-boundary evidence; no market claimed."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import warnings

HERE = Path(__file__).resolve().parent
_CONTROL_OWNERS = []


def pin(path):
    data = Path(path).read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def require(value, message):
    if not value:
        raise ValueError(message)


def scalar(value):
    if type(value) is float:
        return {"type": "builtins.float", "bits": struct.pack("!d", value).hex()}
    if type(value) is int:
        return {"type": "builtins.int", "value": str(value)}
    if type(value) is bool:
        return {"type": "builtins.bool", "value": value}
    if type(value) is tuple:
        return {"type": "builtins.tuple", "items": [scalar(x) for x in value]}
    if value is None:
        return {"type": "builtins.NoneType"}
    raise ValueError("finite plain scalar witness required")


def state(value):
    return {"kind": value[0], "words_le_hex": struct.pack("<624I", *value[1]).hex(),
        "position": int(value[2]), "has_gauss": int(value[3]), "gauss_bits": struct.pack("!d", value[4]).hex()}


def observed(call):
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter("always")
        try:
            result = {"returned": True, "result": scalar(call())}
        except BaseException as error:
            result = {"returned": False, "type": type(error).__module__ + "." + type(error).__name__, "message": str(error)}
        result["warnings"] = [{"type": w.category.__module__ + "." + w.category.__name__, "message": str(w.message)} for w in seen]
        return result


def trace_rows(rows):
    return [{"boundary": name, "value": scalar(value), "state": state(snapshot)} for name, value, snapshot in rows]


def original_draw(rng, mean, scale, offset, trace):
    normal = rng.normal(mean, scale)
    trace.append(("normal", float(normal), rng.get_state()))
    size = int(max(1, round(normal)))
    trace.append(("size", size, rng.get_state()))
    buy = bool(rng.randint(0, 2))
    trace.append(("direction", buy, rng.get_state()))
    delta = int(rng.randint(0, offset + 1))
    trace.append(("offset", delta, rng.get_state()))
    return size, buy, delta


def cases():
    return [("ordinary", 10.0, 2.0, 5, {}, 700),
        ("rollover622", 10.0, 2.0, 3, {"position": 622}, 200),
        ("rollover623", 10.0, 2.0, 3, {"position": 623}, 200),
        ("rollover624", 10.0, 2.0, 3, {"position": 624}, 200),
        ("pending_positive_zero", 10.0, 2.0, 5, {"has_gauss": 1, "gauss": 0.0}, 20),
        ("pending_negative_zero", 10.0, 2.0, 5, {"has_gauss": 1, "gauss": -0.0}, 20),
        ("pending_nonzero", 10.0, 2.0, 5, {"has_gauss": 1, "gauss": -1.2345}, 20),
        ("zero_std_draws", 10.0, 0.0, 5, {}, 50),
        ("zero_offset_no_integer_word", 10.0, 2.0, 0, {}, 50),
        ("wide_offset", 10.0, 2.0, (1 << 40) + 3, {}, 50),
        ("maximum_offset", 10.0, 2.0, (1 << 63) - 1, {}, 50),
        ("negative_std", 10.0, -1.0, 5, {}, 1),
        ("negativezero_std", 10.0, -0.0, 5, {}, 1),
        ("invalid_offset_after_prior_draws", 10.0, 2.0, -1, {}, 1),
        ("high_offset_error_after_prior_draws", 10.0, 2.0, (1 << 63), {}, 1),
        ("overflow_before_integer_draws", 1e308, 1e308, 5, {"has_gauss": 1, "gauss": 2.0}, 1)]


class FiniteAbort(BaseException):
    pass


def boundary_controls(native, np):
    from episode_boundary import NoiseEpisodeBoundary
    from noise_admission import public_state
    rows = []
    modes = ("normal-return", "early-return", "BaseException", "public-owner-draw", "public-exposure", "public-snapshot",
             "public-replacement", "same-RNG-replacement", "repeat-export", "rebind-native-adapter")
    for mode in modes:
        arm_rows = []
        for arm in ("original", "new", "new-repeat"):
            rng = np.random.RandomState(95700)
            owner = None if arm == "original" else native.NoiseRNGOwner(rng, public_state(rng, np), rng.normal,
                rng.randint, rng.get_state, rng.set_state, np.asarray, np.uint32)
            if owner is not None:
                _CONTROL_OWNERS.append(owner)
            class FiniteActor:
                def __init__(self, random_state):
                    self.random_state = random_state
            actor = FiniteActor(rng)
            boundary = None if owner is None else NoiseEpisodeBoundary([(actor, owner, rng)])
            before = state(public_state(rng, np))
            draw_outcome = None
            private_state = None
            exposed_state = None
            continuation_outcome = None
            continuation_state = None
            def runner():
                nonlocal actor, draw_outcome, private_state, exposed_state, continuation_outcome, continuation_state
                if owner is None:
                    draw_outcome = observed(lambda: original_draw(rng, 10.0, 2.0, 5, []))
                    private_state = state(public_state(rng, np))
                else:
                    # This intentionally calls a same-extension cdef adapter.
                    # Public owner.draw has its own mandatory handoff contract.
                    draw_outcome = observed(lambda: owner.draw(10.0, 2.0, 5) if mode == "public-owner-draw"
                                            else native.control_noise_private_draw(owner, 10.0, 2.0, 5))
                    private_state = state(owner.control_private_state())
                if mode == "BaseException":
                    raise FiniteAbort("finite actor abort after draws")
                if mode == "rebind-native-adapter" and boundary is not None:
                    replacement_actor = FiniteActor(rng)
                    boundary.rebind_native_actors({id(actor): replacement_actor})
                    require(boundary.owner_for_controlled_actor(actor) is None
                            and boundary.owner_for_controlled_actor(replacement_actor) is owner,
                            "complete cold rebound registry identity differs")
                    actor = replacement_actor
                if mode in ("public-exposure", "rebind-native-adapter"):
                    require(owner is None or boundary.expose_rng(actor) is rng, "public retained RNG identity differs")
                    exposed_state = state(public_state(rng, np))
                if mode == "public-snapshot":
                    exposed_state = state(rng.get_state() if owner is None else owner.snapshot())
                    require(owner is None or owner.original_identity() is rng, "public snapshot identity differs")
                if mode in ("public-replacement", "same-RNG-replacement"):
                    replacement = (rng if mode == "same-RNG-replacement" else np.random.RandomState(95701))
                    if boundary is not None:
                        boundary.before_replace_rng(actor)
                        require(boundary.owner_for_controlled_actor(actor) is None and len(boundary.entries) == 1,
                                "former owner registry still active after replacement")
                    actor.random_state = replacement
                    exposed_state = state(public_state(rng, np))
                    continuation_outcome = observed(lambda: original_draw(actor.random_state, 10.0, 2.0, 5, []))
                    continuation_state = state(public_state(actor.random_state, np))
                return None if mode == "early-return" else 3
            outcome = observed(lambda: runner() if boundary is None else boundary.run(runner))
            if mode == "repeat-export" and boundary is not None:
                boundary.export_all(); boundary.export_all()
            actual = state(public_state(rng, np))
            row = {"arm": arm, "initial_actual_state": before, "draw_outcome": draw_outcome,
                "private_consumed_state": private_state, "runner_outcome": outcome,
                "exposed_actual_state": exposed_state, "continuation_outcome": continuation_outcome,
                "continuation_actual_state": continuation_state, "terminal_actual_state": actual,
                "diagnostics": None if owner is None else owner.diagnostics(),
                "cleanup_failures": [] if boundary is None else list(boundary.cleanup_failures),
                "native_actor_properties_exercised": False, "registry_adapter_only": True}
            arm_rows.append(row)
            if owner is not None:
                require(owner.diagnostics()["owned"] is False and owner.diagnostics()["handoffs"] == 1
                        and row["cleanup_failures"] == [], "permanent one-shot registry terminal handoff differs")
        keys = ("initial_actual_state", "draw_outcome", "private_consumed_state", "runner_outcome", "exposed_actual_state",
                "continuation_outcome", "continuation_actual_state", "terminal_actual_state")
        require(all(arm_rows[0][key] == arm_rows[1][key] == arm_rows[2][key] for key in keys),
                "three actual registry runner/public arms differ")
        require(arm_rows[1]["diagnostics"] == arm_rows[2]["diagnostics"], "repeated native lifecycle diagnostics differ")
        rows.append({"mode": mode, "arms": arm_rows, "passed": True})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "fresh finite Noise raw evidence required")
    import numpy as np
    from episode_boundary import NoiseEpisodeBoundary
    from noise_admission import public_state
    require(np.__version__ == "1.26.4", "pinned NumPy1.26.4 finite control required")
    from production_cli import activate_paths
    activate_paths(args.runtime)
    from native_loader import load
    native = load(args.build, args.runtime)["dynamic_arena_chain"]
    build_receipt = args.build / "BUILD_RECEIPT.json"
    build = json.loads(build_receipt.read_bytes())
    extension = next(row for row in build["extensions"] if row["module"] == "dynamic_arena_chain")
    raw = {"schema": "t3-light-typed-noise-same-ELF-expression-controls-v1", "all_passed": False,
        "cases": [], "boundary_controls": [], "source_receipt_sha256": build["source_receipt_sha256"],
        "build_receipt": pin(build_receipt), "arms": ["original", "new", "new-repeat"],
        "same_extension_module": "dynamic_arena_chain", "extension": extension,
        "market_executed": False, "rankable": False, "speed_claim": False}
    try:
        for index, (name, mean, scale, offset, patch, count) in enumerate(cases()):
            rngs = [np.random.RandomState(95600 + index) for _ in range(3)]
            for rng in rngs:
                initial = list(rng.get_state())
                initial[2], initial[3], initial[4] = patch.get("position", initial[2]), patch.get("has_gauss", initial[3]), patch.get("gauss", initial[4])
                rng.set_state(tuple(initial))
            owners = [None]
            for rng in rngs[1:]:
                owner = native.NoiseRNGOwner(rng, public_state(rng, np), rng.normal, rng.randint,
                    rng.get_state, rng.set_state, np.asarray, np.uint32)
                _CONTROL_OWNERS.append(owner)
                owners.append(owner)
            row = {"name": name, "mean": scalar(mean), "scale": scalar(scale), "offset": scalar(offset),
                "state_patch": {k: scalar(v) for k, v in patch.items()}, "calls": [],
                "initial_actual_states": [state(public_state(rng, np)) for rng in rngs]}
            require(row["initial_actual_states"][0] == row["initial_actual_states"][1]
                    == row["initial_actual_states"][2], "finite initial full624 states differ")
            for ordinal in range(count):
                before = [state(public_state(rngs[0], np))] + [state(owner.control_private_state()) for owner in owners[1:]]
                traces = [[], [], []]
                results = [observed(lambda: original_draw(rngs[0], mean, scale, offset, traces[0]))]
                for arm in (1, 2):
                    results.append(observed(lambda arm=arm: owners[arm].control_draw(mean, scale, offset)))
                    traces[arm] = owners[arm].control_trace_rows()
                recorded = [trace_rows(value) for value in traces]
                after = [state(public_state(rngs[0], np))] + [state(owner.control_private_state()) for owner in owners[1:]]
                require(before[0] == before[1] == before[2]
                        and results[0] == results[1] == results[2] and recorded[0] == recorded[1] == recorded[2]
                        and after[0] == after[1] == after[2], "fused expression boundary/outcome/full624 state differs")
                row["calls"].append({"ordinal": ordinal, "outcomes": results, "before_states": before,
                    "boundary_traces": recorded, "after_states": after})
            for owner in owners[1:]:
                owner.export_to_original(); owner.export_to_original()
            exported = [state(public_state(rng, np)) for rng in rngs]
            require(exported[0] == exported[1] == exported[2], "actual public terminal state differs")
            row["final_actual_exported_states"] = exported
            row["diagnostics"] = [owner.diagnostics() for owner in owners[1:]]
            raw["cases"].append(row)
        raw["boundary_controls"] = boundary_controls(native, np)
        raw["all_passed"] = True
    except BaseException as error:
        from cleanup_errors import detail
        raw["failure"] = detail(error)
    finally:
        from cleanup_errors import detail
        failures = []
        for owner in _CONTROL_OWNERS:
            try:
                owner.export_to_original()
            except BaseException as error:
                failures.append(detail(error))
        raw["terminal_cleanup_failures"] = failures
        if failures:
            raw["all_passed"] = False
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(raw, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(raw["all_passed"], "finite Noise fused/control boundary failed")


if __name__ == "__main__":
    main()
