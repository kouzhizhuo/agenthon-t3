"""One cold closed-CLI ownership interval with complete all-owner export."""
from cleanup_errors import attach, detail


class ChainEpisodeBoundary:
    def __init__(self, noise_boundary, latency_acquisition):
        self.noise = noise_boundary
        self.latency = latency_acquisition
        self.committed = False
        self.closed = False
        self.cleanup_failures = []

    def export_all(self):
        # Attempt each independent stream even if one export fails. The Noise
        # child already attempts every actor; the latency owner is separate.
        failures = []
        try:
            self.noise.export_all()
        except BaseException as error:
            failures.append({"owner": "Noise", **detail(error),
                             "stream_failures": list(self.noise.cleanup_failures)})
        if self.latency.owner is not None:
            try:
                self.latency.owner.export_to_original()
            except BaseException as error:
                failures.append({"owner": "configured-latency", **detail(error)})
        self.cleanup_failures.extend(failures)
        self.closed = not failures
        if failures:
            error = RuntimeError("common owned RNG terminal export incomplete")
            attach(error, "chain_ownership_cleanup_failures", failures)
            raise error

    def run(self, controlled_runner, *args, **kwargs):
        active_error = None
        try:
            return controlled_runner(*args, **kwargs)
        except BaseException as error:
            active_error = error
            raise
        finally:
            try:
                self.export_all()
            except BaseException:
                if active_error is None:
                    raise
                attach(active_error, "chain_ownership_cleanup_failures", self.cleanup_failures)

    def rollback_before_draw(self):
        self.export_all()

    def assert_authority(self):
        if self.latency.owner is not None:
            self.latency.owner.assert_authority()
        return True
