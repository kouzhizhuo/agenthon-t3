"""Future same-ELF cold admission controls; source preparation never runs them.

The server creates one genuine original initialized market fixture without
running its event queue. Every admission/patch/alias action then checks the full
retained graph and all RNG states before and after. No patched body is invoked.
"""
import argparse
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import types


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
        ensure_ascii=True, allow_nan=False).encode()).hexdigest()


@contextmanager
def replaced_attribute(owner, name, value):
    dictionary = vars(owner)
    existed, former = name in dictionary, dictionary.get(name)
    setattr(owner, name, value)
    try:
        yield
    finally:
        if existed:
            setattr(owner, name, former)
        else:
            delattr(owner, name)


@contextmanager
def replaced_bases(cls, bases):
    former = cls.__bases__
    cls.__bases__ = bases
    try:
        yield
    finally:
        cls.__bases__ = former


def clone_function(fn, globals_=None, defaults=None, closure=None):
    value = types.FunctionType(fn.__code__, fn.__globals__ if globals_ is None else globals_,
        fn.__name__, fn.__defaults__ if defaults is None else defaults,
        fn.__closure__ if closure is None else closure)
    value.__module__, value.__qualname__ = fn.__module__, fn.__qualname__
    value.__kwdefaults__ = None if fn.__kwdefaults__ is None else dict(fn.__kwdefaults__)
    return value


def cell(value):
    return (lambda retained: lambda: retained)(value).__closure__[0]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("fresh Noise admission control evidence required")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    report = {"schema": "t3-light-typed-noise-real-admission-controls-v1", "all_passed": False,
        "source_only": False, "rankable": False, "speed_claim": False, "market_episodes": 0,
        "original_initializations": 0, "cases": []}
    calls = {"foreign_bodies": 0}
    boundaries = []
    fixture = None
    try:
        import production_cli as cli
        runtime = cli.activate_paths(args.runtime)
        from native_loader import load
        engine = load(args.build, runtime)["dynamic_arena_chain"]
        from native_runtime_binding import bind, runtime_for
        from noise_admission import authenticate_runtime, acquire_initialized, public_state, _exact_summary_suppression
        from abides_core.kernel import Kernel
        from abides_core.message import Message
        from abides_core import latency_model
        from abides_markets.orders import Order
        from abides_fork import agents, config
        from counters import reset_abides_counters
        import builtins
        import numpy as np
        import observer
        from control_graph import graph
        from cleanup_errors import detail
        authenticate_runtime(runtime)
        if observer.STATE is not None or runtime_for(engine) != runtime:
            raise ValueError("inactive observer and actual loader-bound runtime required")
        scenario = json.loads(args.config.read_bytes())
        scenario = json.loads(json.dumps(scenario))
        for row in scenario["agent_configs"]:
            if row["agent_type"] == "NoiseTrader":
                row["count"] = 2
        if not any(row["agent_type"] == "NoiseTrader" and row["count"] == 2 for row in scenario["agent_configs"]):
            raise ValueError("actual two-Noise fixture required")
        reset_abides_counters()
        built = config.build_config(scenario)
        # Same original construction as abides.run; its wrapper uses seed zero,
        # rather than the unused config random_state_kernel field.
        fixture = Kernel(random_state=np.random.RandomState(seed=0), log_dir="",
            **{name: built[name] for name in ("start_time", "stop_time", "agents",
                "agent_latency_model", "default_computation_delay", "custom_properties")})
        fixture.initialize()
        report["original_initializations"] = 1
        noise = [actor for actor in fixture.agents if type(actor) is agents.NoiseTrader]
        others = [actor for actor in fixture.agents if type(actor) is not agents.NoiseTrader]
        if (len(noise) != 2 or not others or fixture.ttl_messages != 0 or fixture._deliver_seq != 0
                or fixture.current_time != fixture.start_time or fixture.custom_state or fixture.gym_agents):
            raise ValueError("genuine fresh original initialized fixture required")

        def snapshot():
            roots = {"agents": fixture.agents, "oracle": fixture.oracle,
                "kernel_rng": fixture.random_state, "latency": fixture.agent_latency_model,
                "global_rng": np.random.mtrand._rand, "global_state": np.random.get_state(),
                "ttl_messages": fixture.ttl_messages, "deliver_seq": fixture._deliver_seq,
                "delivery_keys": fixture._deliver_seq_by_key, "current_time": fixture.current_time,
                "current_causal_uid": fixture._current_causal_uid,
                "agent_current_times": fixture.agent_current_times,
                "agent_computation_delays": fixture.agent_computation_delays,
                "additional_delay": fixture.current_agent_additional_delay,
                "ledger": fixture._msg_ledger, "queue": fixture.messages.queue,
                "custom_state": fixture.custom_state, "observer": observer.STATE,
                "summary_log": fixture.summary_log,
                "mean_result_by_agent_type": fixture.mean_result_by_agent_type,
                "agent_count_by_type": fixture.agent_count_by_type,
                "message_counter": Message._Message__message_id_counter,
                "order_counter": Order._order_id_counter}
            return graph(roots, np)

        def check(name, action):
            before = snapshot()
            row = {"case": name, "passed": False, "before_graph_sha256": digest(before), "before_graph": before}
            try:
                value = action()
                after = snapshot()
                row.update(result=value, after_graph_sha256=digest(after), after_graph=after,
                    full_graph_RNG_UID_queue_ledger_unchanged=before == after,
                    foreign_body_calls=calls["foreign_bodies"])
                if before != after or calls["foreign_bodies"]:
                    raise AssertionError("cold admission changed state or called foreign body")
                row["passed"] = True
            except BaseException as error:
                row["failure"] = detail(error)
                raise
            finally:
                report["cases"].append(row)

        def refusal(action):
            try:
                action()
            except ValueError as error:
                return {"refused": True, "failure": detail(error)}
            raise AssertionError("modified cold authentication was accepted")

        def foreign(*values, **keywords):
            calls["foreign_bodies"] += 1
            raise AssertionError("foreign callback must never be invoked")

        def acquire(expected_declined):
            inner_before = snapshot()
            boundary = acquire_initialized(fixture, engine, runtime)
            boundaries.append(boundary)
            diagnostics = []
            try:
                if set(boundary.declined_actor_ids) != set(expected_declined):
                    raise AssertionError("actual alias decline roster differs")
                admitted = [actor for actor in noise if actor.id not in expected_declined]
                if [actor for actor, _, _ in boundary.entries] != admitted:
                    raise AssertionError("actual unique Noise acquisition roster differs")
                for actor, owner, rng in boundary.entries:
                    diagnostic = owner.diagnostics()
                    if (rng is not actor.random_state or owner.control_private_state() != public_state(rng, np)
                            or diagnostic["owned"] is not True or diagnostic["handoffs"] != 0
                            or diagnostic["normal_calls"] != 0 or diagnostic["randint_calls"] != 0
                            or diagnostic["words_consumed"] != 0 or diagnostic["export_failures"]):
                        raise AssertionError("no-draw actual owner acquisition differs")
                    diagnostics.append({"actor_id": actor.id, "rng_identity": id(rng),
                        "private_state_sha256": digest(owner.control_private_state()),
                        "private_full_state": owner.control_private_state(), "before_export": diagnostic})
            finally:
                boundary.export_all()
            for item, (_, owner, _) in zip(diagnostics, boundary.entries):
                after = owner.diagnostics()
                item["after_export"] = after
                if after["owned"] is not False or after["handoffs"] != 1 or after["export_failures"]:
                    raise AssertionError("no-draw permanent export differs")
            if snapshot() != inner_before or boundary.closed is not True or boundary.cleanup_failures:
                raise AssertionError("acquisition/export changed original retained state")
            return {"admitted_actor_ids": [actor.id for actor in admitted],
                "declined_actor_ids": list(boundary.declined_actor_ids), "diagnostics": diagnostics,
                "acquisition_and_export_draws": 0, "inner_full_graph_unchanged": True}

        check("actual_runtime_authentication", lambda: {"accepted": authenticate_runtime(runtime)[1] is agents,
            "actual_runtime": str(runtime_for(engine)), "same_extension": engine.__name__})
        check("actual_unique_initialized_Noise_acquisition", lambda: acquire([]))

        def alias_case(rng, declined):
            with replaced_attribute(noise[0], "random_state", rng):
                return acquire(declined)

        aliases = (("shared_Noise_Noise", noise[1].random_state, [actor.id for actor in noise]),
            ("shared_Noise_other_actor", others[0].random_state, [noise[0].id]),
            ("shared_Noise_kernel", fixture.random_state, [noise[0].id]),
            ("shared_Noise_latency", fixture.agent_latency_model.random_state, [noise[0].id]),
            ("shared_Noise_oracle_symbol", next(iter(fixture.oracle.symbols.values()))["random_state"], [noise[0].id]),
            ("shared_Noise_module_global", np.random.mtrand._rand, [noise[0].id]))
        for name, rng, declined in aliases:
            check(name, lambda rng=rng, declined=declined: alias_case(rng, declined))

        def patched(owner, name, replacement):
            with replaced_attribute(owner, name, replacement):
                return refusal(lambda: authenticate_runtime(runtime))

        check("foreign_draw_random_state_helper", lambda: patched(config, "_draw_random_state", foreign))
        foreign_class = type("ForeignScenarioLatency", (), {"__module__": __name__})
        check("foreign_ScenarioLatencyModel_class", lambda: patched(config, "ScenarioLatencyModel", foreign_class))
        check("foreign_explicit_round_global", lambda: patched(agents, "round", foreign))
        def foreign_global_functions():
            return {"bound_randint_refusal": patched(np.random, "randint", foreign),
                    "module_seed_wrapper_refusal": patched(np.random, "seed", foreign)}
        check("foreign_module_global_rng_function", foreign_global_functions)

        def wrong_globals():
            original = agents.NoiseTrader.act
            replacement = clone_function(original, globals_=dict(original.__globals__))
            return patched(agents.NoiseTrader, "act", replacement)
        check("same_code_foreign_globals", wrong_globals)

        def wrong_builtins():
            original = agents.NoiseTrader.act
            owner_globals = original.__globals__
            former = owner_globals.get("__builtins__")
            custom = dict(builtins.__dict__); custom["round"] = foreign
            owner_globals["__builtins__"] = custom
            try:
                replacement = clone_function(original)
            finally:
                owner_globals["__builtins__"] = former
            if replacement.__globals__ is not owner_globals or replacement.__builtins__ is not custom:
                raise AssertionError("actual foreign builtins fixture was not constructed")
            return patched(agents.NoiseTrader, "act", replacement)
        check("same_code_foreign_builtins_table", wrong_builtins)

        def wrong_default_type():
            original = Kernel.__init__
            values = list(original.__defaults__)
            if type(values[2]) is not int or values[2] != 1:
                raise AssertionError("actual constructor literal default fixture differs")
            values[2] = True
            return patched(Kernel, "__init__", clone_function(original, defaults=tuple(values)))
        check("equal_value_bool_integer_default_refusal", wrong_default_type)

        def wrong_clock_type():
            original = Kernel.__init__
            values = list(original.__defaults__); values[0] = int(values[0])
            return patched(Kernel, "__init__", clone_function(original, defaults=tuple(values)))
        check("equal_value_constructor_clock_type_refusal", wrong_clock_type)

        def wrong_closure():
            original = agents.ScheduledAgent.__init__
            replacement = clone_function(original, closure=(cell(foreign_class),))
            return patched(agents.ScheduledAgent, "__init__", replacement)
        check("same_code_foreign_super_class_cell", wrong_closure)

        def wrong_base():
            base = type("ForeignLatencyBase", (latency_model.LatencyModel,), {"__module__": __name__})
            with replaced_bases(config.ScenarioLatencyModel, (base,)):
                return refusal(lambda: authenticate_runtime(runtime))
        check("source_code_same_foreign_latency_base", wrong_base)

        def summary_cases():
            original = cli._suppressed_summary_log
            with replaced_attribute(Kernel, "write_summary_log", original):
                authenticate_runtime(runtime)
            # Inert function fixtures cover the precise function-globals route;
            # actual direct/runpy production entry remains a whole-entry gate.
            globals_ = dict(original.__globals__); globals_["__name__"] = "__main__"
            main_fn = clone_function(original, globals_=globals_); globals_["_suppressed_summary_log"] = main_fn
            if not _exact_summary_suppression(main_fn):
                raise AssertionError("exact main-name summary function fixture declined")
            with replaced_attribute(Kernel, "write_summary_log", main_fn):
                authenticate_runtime(runtime)
            bad_globals = dict(globals_); bad_globals["__file__"] = str(args.out.parent / "foreign-production-cli.py")
            bad = clone_function(original, globals_=bad_globals); bad_globals["_suppressed_summary_log"] = bad
            if _exact_summary_suppression(bad):
                raise AssertionError("foreign-path summary function accepted")
            result = patched(Kernel, "write_summary_log", foreign)
            return {"imported_function_accepted": True, "inert_main_function_fixture_accepted": True,
                "actual_direct_runpy_execution_claim": False, "foreign_path_refused": True, "foreign_body": result}
        check("exact_shared_summary_and_foreign_refusal", summary_cases)

        def wrong_runtime():
            receipt = json.loads((Path(__file__).parent / "RUNTIME_PINS.json").read_bytes())
            with tempfile.TemporaryDirectory(prefix="noise-auth-source-copy-", dir=args.out.parent) as directory:
                alternate = Path(directory)
                for row in receipt["files"]:
                    target = alternate / row["path"]; target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(runtime / row["path"], target)
                result = refusal(lambda: authenticate_runtime(alternate))
                binding = refusal(lambda: bind(engine, alternate))
                if runtime_for(engine) != runtime:
                    raise AssertionError("foreign runtime attempt changed actual binding")
            return {"complete_source_copy_loaded_path_refusal": result, "runtime_rebind_refusal": binding}
        check("same68_source_bytes_wrong_actual_runtime_path", wrong_runtime)
        check("unknown_engine_runtime_binding_refusal", lambda: refusal(lambda: runtime_for(types.ModuleType("dynamic_arena_chain"))))
        check("post_patch_original_authentication_and_acquisition", lambda: acquire([]))
        report["fixture"] = {"scenario_sha256": digest(scenario), "actor_count": len(fixture.agents),
            "noise_actor_ids": [actor.id for actor in noise], "pending_initial_wakeups": fixture.messages.qsize(),
            "ttl_messages": fixture.ttl_messages, "deliver_seq": fixture._deliver_seq,
            "actual_runtime": str(runtime), "final_graph_sha256": digest(snapshot()),
            "participant_queue_runner_called": False, "foreign_body_calls": calls["foreign_bodies"]}
        report["build_receipt"] = {"bytes": (args.build / "BUILD_RECEIPT.json").stat().st_size,
            "sha256": hashlib.sha256((args.build / "BUILD_RECEIPT.json").read_bytes()).hexdigest()}
        report["all_passed"] = len(report["cases"]) == 22 and all(row["passed"] for row in report["cases"])
        if not report["all_passed"]:
            raise AssertionError("complete22 cold Noise admission cases required")
    except BaseException as error:
        from cleanup_errors import detail
        report["failure"] = detail(error)
        raise
    finally:
        cleanup = []
        for boundary in boundaries:
            try:
                boundary.export_all()
            except BaseException as error:
                from cleanup_errors import detail
                cleanup.append(detail(error))
        report["terminal_cleanup_failures"] = cleanup
        if cleanup:
            report["all_passed"] = False
        args.out.write_text(json.dumps(report, sort_keys=True, indent=2, allow_nan=False) + "\n")
    if report["all_passed"] is not True:
        raise RuntimeError("finite Noise admission controls or terminal cleanup failed")


if __name__ == "__main__":
    main()
