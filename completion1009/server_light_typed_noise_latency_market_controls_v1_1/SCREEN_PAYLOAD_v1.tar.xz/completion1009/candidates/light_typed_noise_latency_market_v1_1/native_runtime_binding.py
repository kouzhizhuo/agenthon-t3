"""Cold bind the actual loader-verified runtime to its same-extension owner."""
from pathlib import Path
import sys
import types

_ENGINE = None
_RUNTIME = None


def bind(engine, runtime):
    global _ENGINE, _RUNTIME
    runtime = Path(runtime).resolve()
    if (type(engine) is not types.ModuleType or engine.__name__ != "dynamic_arena_chain"
            or sys.modules.get("dynamic_arena_chain") is not engine):
        raise ValueError("actual loaded same-extension engine required")
    if _ENGINE is not None and (_ENGINE is not engine or _RUNTIME != runtime):
        raise ValueError("process already bound to another native runtime")
    _ENGINE, _RUNTIME = engine, runtime


def runtime_for(engine):
    if engine is not _ENGINE or sys.modules.get("dynamic_arena_chain") is not engine or _RUNTIME is None:
        raise ValueError("loader-verified actual native runtime required")
    return _RUNTIME
