"""Prepare exact pinned baseline schemas in an explicit future build control.

This source is not executed during preparation/review. Scientific libraries are
imported only by main when the owner deliberately runs this build control. The
generated schema file is metadata, never cached simulated values or outputs.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path

VERSIONS = {'numpy': '1.26.4', 'pandas': '1.5.3', 'pyarrow': '15.0.2'}
CONTRACTS = {
    'trace': {'t_ns': 'int64', 'agent_id': 'int32', 'msg_type': 'string', 'side': 'string',
              'price': 'int64', 'size': 'int64', 'order_id': 'int64'},
    'message_trace': {'seq': 'int64', 't_recv_ns': 'int64', 't_send_ns': 'Int64',
              'latency_ns': 'int64', 'src_id': 'int32', 'dst_id': 'int32',
              'message_id': 'int64', 'msg_type': 'string', 'order_id': 'Int64',
              'causal_parent': 'Int64'},
}
PHYSICAL = {'int64': 'int64', 'Int64': 'int64', 'int32': 'int32', 'string': 'string'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def b64(data):
    return base64.b64encode(data).decode('ascii')

def metadata_items(metadata):
    # Retain the library-generated mapping order and bytes, not reserialized JSON.
    return [{'key_b64': b64(key), 'value_b64': b64(value)} for key, value in (metadata or {}).items()]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.receipt.exists() or args.out.resolve() == args.receipt.resolve():
        raise ValueError('fresh distinct metadata and external receipt paths required')
    import numpy as np
    import pandas as pd
    import pyarrow as pa
    actual = {'numpy': np.__version__, 'pandas': pd.__version__, 'pyarrow': pa.__version__}
    if actual != VERSIONS:
        raise ValueError('exact pinned baseline versions required: ' + repr(actual))
    result = {'schema': 't3-pandas-free-schema-metadata-v1',
        'numpy_version': actual['numpy'], 'pandas_version': actual['pandas'],
        'pyarrow_version': actual['pyarrow'], 'tables': {}}
    for name, contract in CONTRACTS.items():
        frame = pd.DataFrame({field: pd.Series([], dtype=dtype) for field, dtype in contract.items()}, columns=list(contract))
        if {field: str(frame[field].dtype) for field in frame.columns} != contract:
            raise ValueError('baseline exact empty dtype contract differs')
        table = pa.Table.from_pandas(frame, preserve_index=False)
        schema = table.schema
        if schema.names != list(contract) or table.num_rows != 0:
            raise ValueError('baseline exact empty Arrow roster differs')
        if any(str(field.type) != PHYSICAL[contract[field.name]] for field in schema):
            raise ValueError('baseline Arrow physical type differs')
        pandas_metadata = json.loads(schema.metadata[b'pandas'])
        if (pandas_metadata['index_columns'] != [] or pandas_metadata['column_indexes'] != []
                or pandas_metadata['creator'] != {'library': 'pyarrow', 'version': actual['pyarrow']}
                or pandas_metadata['pandas_version'] != actual['pandas']
                or [row['name'] for row in pandas_metadata['columns']] != list(contract)
                or [row['numpy_type'] for row in pandas_metadata['columns']] != list(contract.values())):
            raise ValueError('baseline pandas metadata/type/index/version differs')
        serialized = schema.serialize().to_pybytes()
        result['tables'][name] = {
            'columns': [{'name': field.name, 'pandas_dtype': contract[field.name],
                'arrow_type': str(field.type), 'nullable': field.nullable,
                'field_metadata': metadata_items(field.metadata)} for field in schema],
            'schema_metadata': metadata_items(schema.metadata),
            'schema_serialized_b64': b64(serialized),
            'schema_serialized_sha256': sha(serialized),
        }
    data = (json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n').encode('utf8')
    receipt = {'schema': 't3-pandas-free-baseline-schema-build-receipt-v1',
        'versions': actual, 'generator': {'path': str(Path(__file__).resolve()),
            'sha256': sha(Path(__file__).read_bytes())},
        'metadata': {'path': str(args.out.resolve()), 'bytes': len(data), 'sha256': sha(data)},
        'table_rosters': {name: list(fields) for name, fields in CONTRACTS.items()},
        'baseline_API': 'pyarrow.Table.from_pandas(empty_typed_dataframe,preserve_index=False)',
        'empty_metadata_fixture_only': True, 'candidate_imported': False,
        'native_build_executed': False, 'market_executed': False,
        'runtime_writer_verified': False, 'readback_verified': False, 'rankable': False}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('xb') as stream:
        stream.write(data)
    with args.receipt.open('x') as stream:
        stream.write(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
