"""Future explicit build step: exact schema fixture plus deployment source pin.

Only main imports/runs the pinned baseline generator. Preparation itself stores
this source. The generated module contains a metadata digest, never event data.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--generator", type=Path, required=True)
    parser.add_argument("--receipt-dir", type=Path, required=True)
    args = parser.parse_args()
    runtime = args.runtime.resolve()
    metadata = runtime / "schema_metadata_v1.json"
    pin = runtime / "schema_metadata_pin_v1.py"
    if metadata.exists() or pin.exists() or args.receipt_dir.exists():
        raise ValueError("fresh build schema paths required")
    args.receipt_dir.mkdir(parents=True)
    generation = args.receipt_dir / "BASELINE_SCHEMA_BUILD_RECEIPT_v1.json"
    subprocess.run([sys.executable, "-B", str(args.generator), "--out", str(metadata), "--receipt", str(generation)], check=True)
    digest = hashlib.sha256(metadata.read_bytes()).hexdigest()
    source = ('"""Build-generated exact metadata pin; contains no simulated rows."""\n'
              + 'SCHEMA_METADATA_SHA256 = ' + repr(digest) + '\n')
    with pin.open("x") as stream:
        stream.write(source)
    receipt = {"schema": "t3-pandas-free-deployed-schema-source-pin-v1",
               "metadata": {"path": str(metadata), "sha256": digest, "bytes": metadata.stat().st_size},
               "source_pin": {"path": str(pin), "sha256": hashlib.sha256(pin.read_bytes()).hexdigest(), "bytes": pin.stat().st_size},
               "generator": {"path": str(args.generator.resolve()), "sha256": hashlib.sha256(args.generator.read_bytes()).hexdigest()},
               "baseline_receipt_sha256": hashlib.sha256(generation.read_bytes()).hexdigest(),
               "deployment_inventory_required": True, "candidate_executed": False, "market_executed": False,
               "runtime_writer_verified": False}
    (args.receipt_dir / "DEPLOYED_SCHEMA_PIN_RECEIPT_v1.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
