"""Future isolated original/new output controls; this file is source-prepared.

No simulation is invoked. Allocate genuine source-defined agent containers
without constructors, then compare the actual original projectors/writer against
the new read-only projectors. The parent retains the baseline as an independent
process with its own module identities; no alternate-output mock is the oracle.
"""
import argparse
import copy
import gc
import hashlib
import json
from pathlib import Path
import sys


def install_import_oracle():
    attempts = []
    def audit(event, args):
        if event == "import" and args and (args[0] == "pandas" or args[0].startswith("pandas.")):
            attempts.append(args[0])
            raise RuntimeError("control-only pandas import oracle: " + args[0])
    sys.addaudithook(audit)
    return attempts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--arm", choices=("baseline", "new", "cold-new"), required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.out_dir.exists():
        raise ValueError("fresh fixture output directory required")
    args.out_dir.mkdir(parents=True)
    pandas_attempts = install_import_oracle() if args.arm == "cold-new" else []
    runtime = args.runtime.resolve()
    for path in reversed((runtime, runtime / "vendor/abides/abides-core", runtime / "vendor/abides/abides-markets")):
        sys.path.insert(0, str(path))
    import numpy as np
    import observer
    from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
    from abides_fork import trace
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.orders import Side
    from t3_canonical_engine import ColumnLedger
    from column_trace import make_extractor
    from contracts import TRACE_TYPES, MESSAGE_TYPES
    import pyarrow as pa
    versions = {"numpy": np.__version__, "pyarrow": pa.__version__}
    if versions != {"numpy": "1.26.4", "pyarrow": "15.0.2"}:
        raise AssertionError("exact pinned fixture dependencies required before extraction")
    if args.arm != "baseline":
        from canonical_buffers import (Columns, Declined, project_trace, project_messages,
                                       validate_columns, write_outputs, _schemas, _array, import_witness)
        from observer_domain import authenticate_loaded
        if not authenticate_loaded():
            raise AssertionError("candidate loaded domain authentication failed")
    else:
        import pandas as pd
        versions["pandas"] = pd.__version__
        if versions["pandas"] != "1.5.3":
            raise AssertionError("exact pinned baseline pandas required before extraction")
    baseline_extractor = make_extractor(ColumnLedger, trace.extract_message_trace,
                                       trace.MESSAGE_TRACE_COLUMNS, trace._MSG_DTYPES)
    agents = [cls.__new__(cls) for cls in (ExchangeAgent, NoiseTrader, MarketMaker, ValueTrader, MomentumTrader)]
    for aid, agent in enumerate(agents):
        agent.id = aid
        agent.log = []
    base = 1612517400000000123
    records = {
        agents[0]: [(base + 1, "BEST_ASK", "quote", ("ABM", 102, 11)),
                    (base + 1, "BEST_BID", "quote", ("ABM", 100, 8)),
                    (base + 1, "BEST_ASK", "quote", ("ABM", 103, 17))],
        agents[1]: [(base, "ORDER_SUBMITTED", "order", (1, 42, Side.BID, 10, 101, None)),
                    (base + 1, "ORDER_EXECUTED", "order", (1, 42, Side.BID, 3, 101, 101)),
                    (base + 1, "ORDER_EXECUTED", "order", (1, 42, Side.BID, 7, 101, 101)),
                    (base + 1, "ORDER_CANCELLED", "order", (1, 43, None, 2, None, None))],
        agents[2]: [(base, "ORDER_ACCEPTED", "order", (2, 44, Side.ASK, 1, 105, None))],
    }
    episode = observer.Episode()
    for agent in agents:
        episode.append(agent, (base - 1, "AGENT_TYPE", "raw", "fixed-source-fixture"), False, True)
        for record in records.get(agent, ()):
            episode.append(agent, record, True, record[2] == "quote")
    observer.STATE = episode
    ledger = ColumnLedger()
    # Repeated send rows retain the final map sequence. Unreceived rows disappear.
    sent = [(9, 1, 0, base, base + 9, 9, "LIMIT_ORDER", 42, 7),
            (9, 1, 0, base + 1, base + 10, 9, "LIMIT_ORDER", 42, 7),
            (11, 0, 0, None, base + 2, 0, "AGENT_WAKEUP", None, None),
            (12, 0, 1, base + 2, base + 5, 3, "ORDER_ACCEPTED", 42, 9),
            (13, 1, 0, base, base + 500, 500, "LIMIT_ORDER", 99, 12)]
    for row in sent:
        ledger.append_values(*row)
    seqmap = {(9, 0): 8, (11, 0): 2, (12, 1): 7}
    end_state = {"agents": agents, "message_ledger": ledger, "deliver_seq_by_key": seqmap}
    snapshot_records = {agent: copy.deepcopy(rows) for agent, rows in episode.contract.items()}
    snapshot_ledger = copy.deepcopy(ledger.columns)
    snapshot_map = copy.deepcopy(seqmap)
    expected_trace = {
        "t_ns": [base, base, base + 1, base + 1, base + 1, base + 1, base + 1],
        "agent_id": [1, 2, 0, 0, 1, 1, 1],
        "msg_type": ["ORDER_SUBMITTED", "ORDER_ACCEPTED", "QUOTE_UPDATE", "QUOTE_UPDATE", "PARTIAL_FILL", "ORDER_FILLED", "ORDER_CANCELLED"],
        "side": ["BID", "ASK", "ASK", "BID", "BID", "BID", None],
        "price": [101, 105, 103, 100, 101, 101, 0], "size": [10, 1, 17, 8, 3, 7, 2],
        "order_id": [42, 44, -1, -1, 42, 42, 43],
    }
    expected_messages = {
        "seq": [2, 7, 8, 8], "t_recv_ns": [base + 2, base + 5, base + 9, base + 10],
        "t_send_ns": [None, base + 2, base, base + 1], "latency_ns": [0, 3, 9, 9],
        "src_id": [0, 0, 1, 1], "dst_id": [0, 1, 0, 0], "message_id": [11, 12, 9, 9],
        "msg_type": ["AGENT_WAKEUP", "ORDER_ACCEPTED", "LIMIT_ORDER", "LIMIT_ORDER"],
        "order_id": [None, 42, 42, 42], "causal_parent": [None, 9, 7, 7],
    }
    if args.arm == "baseline":
        projected_trace = trace.extract_trace(end_state)
        projected_messages = baseline_extractor(end_state)
        def values(frame):
            return {name: [None if pd.isna(value) else (int(value) if str(frame[name].dtype) in ("int64", "int32", "Int64") else str(value)) for value in frame[name]] for name in frame.columns}
        actual_trace, actual_messages = values(projected_trace), values(projected_messages)
    else:
        projected_trace = project_trace(end_state, episode, Side, trace._side_to_str)
        projected_messages = project_messages(end_state, ColumnLedger)
        if type(projected_trace) is Declined or type(projected_messages) is Declined:
            raise AssertionError("normal fixture unexpectedly declined")
        validate_columns(projected_trace, projected_messages)
        actual_trace, actual_messages = projected_trace.values, projected_messages.values
        write_outputs(projected_trace, projected_messages, args.out_dir / "trace.parquet")
        # Wide values explicitly decline, preserving the original inference pair.
        wide = observer.Episode()
        wide.has_scalar = True
        wide.contract[agents[1]] = [(base, "ORDER_SUBMITTED", "order", (1, (1 << 53) + 1, Side.BID, 1, 100, None))]
        if type(project_trace(end_state, wide, Side, trace._side_to_str)) is not Declined:
            raise AssertionError("wide inference must decline before output writes")
        alias = ColumnLedger()
        alias.columns = (ledger.columns[0],) * 9
        if type(project_messages({"message_ledger": alias, "deliver_seq_by_key": seqmap}, ColumnLedger)) is not Declined:
            raise AssertionError("aliased columns must decline")
        callbacks = []
        class Collision:
            def __hash__(self):
                return hash((9, 0))
            def __eq__(self, other):
                callbacks.append("eq")
                raise AssertionError("untrusted key callback invoked")
        hostile_map = {Collision(): 8}
        if type(project_messages({"message_ledger": ledger, "deliver_seq_by_key": hostile_map}, ColumnLedger)) is not Declined or callbacks:
            raise AssertionError("untrusted map must decline without custom comparison")
        boundary_callbacks = []
        def hostile_side(value):
            boundary_callbacks.append("side")
            raise AssertionError("untrusted side callback invoked")
        if type(project_trace(end_state, episode, Side, hostile_side)) is not Declined or boundary_callbacks:
            raise AssertionError("foreign side helper must decline before callback")
        class HostileMeta(type):
            def __eq__(cls, other):
                boundary_callbacks.append("metaclass-eq")
                raise AssertionError("untrusted metaclass comparison invoked")
        class ForeignScalar(metaclass=HostileMeta):
            pass
        class ForeignLedger:
            @property
            def columns(self):
                boundary_callbacks.append("ledger-property")
                raise AssertionError("untrusted ledger property invoked")
        foreign = ForeignLedger()
        if type(project_messages({"message_ledger": foreign, "deliver_seq_by_key": {}}, ForeignLedger)) is not Declined:
            raise AssertionError("foreign ledger owner must decline before property")
        hostile_episode = observer.Episode()
        hostile_episode.has_scalar = True
        hostile_episode.contract[agents[1]] = [(base, "ORDER_SUBMITTED", "order", (1, ForeignScalar(), Side.BID, 1, 100, None))]
        if type(project_trace(end_state, hostile_episode, Side, trace._side_to_str)) is not Declined:
            raise AssertionError("foreign scalar metaclass must decline by identity")
        if boundary_callbacks:
            raise AssertionError("source domain decline ran a custom callback")
        from canonical_time import str_to_ns, datetime_str_to_ns, fmt_ts
        duration_controls = [("09:30:00", 34200000000000), ("16:00:00", 57600000000000),
                             ("1s", 1000000000), ("60s", 60000000000), ("1min", 60000000000),
                             (np.int64(12), 12), (-(1 << 63), -(1 << 63)), ((1 << 63) - 1, (1 << 63) - 1)]
        for value, expected in duration_controls:
            result = str_to_ns(value)
            if type(result) is not np.int64 or int(result) != expected:
                raise AssertionError("exact numeric/duration nanosecond return differs")
        if datetime_str_to_ns("20210205") != 1612483200000000000:
            raise AssertionError("fixed date nanoseconds differ")
        for value, expected in ((0, "1970-01-01 00:00:00"), (-1, "1969-12-31 23:59:59"),
                                (1000000001, "1970-01-01 00:00:01")):
            if fmt_ts(value) != expected:
                raise AssertionError("timestamp second floor differs")
        import pyarrow as pa
        schemas = _schemas(pa)
        primitive_controls = []
        for dtype, values_ in (("Int64", [None, -(1 << 63), (1 << 63) - 1]),
                               ("Int64", [base, base + 1]), ("Int64", [None, None]),
                               ("string", [None, "", "买入", "🙂"]), ("string", [])):
            field = pa.field("test", pa.string() if dtype == "string" else pa.int64())
            array = _array(pa, field, dtype, values_)
            if array.to_pylist() != values_:
                raise AssertionError("primitive null/string/range control differs")
            primitive_controls.append({"dtype": dtype, "rows": len(values_), "nulls": array.null_count})
        if args.arm == "cold-new" and (pandas_attempts or import_witness()["pandas_loaded"]):
            raise AssertionError("cold source/writer attempted or loaded pandas")
    if actual_trace != expected_trace or actual_messages != expected_messages:
        raise AssertionError("explicit stable-row expected values differ")
    if snapshot_records != episode.contract or snapshot_ledger != ledger.columns or snapshot_map != seqmap:
        raise AssertionError("projection mutated caller-owned contract/ledger/map")
    # The production API is called first into this actual pair. Save its bytes
    # before the broader row-group fixture overwrites these same two paths.
    if args.arm == "baseline":
        projected_trace.to_parquet(args.out_dir / "trace.parquet", compression="snappy", index=False)
        projected_messages.to_parquet(args.out_dir / "message_trace.parquet", compression="snappy", index=False)
    else:
        write_outputs(projected_trace, projected_messages, args.out_dir / "trace.parquet")
    production_api_files = {name: {"bytes": (args.out_dir / name).stat().st_size,
        "sha256": hashlib.sha256((args.out_dir / name).read_bytes()).hexdigest()}
        for name in ("trace.parquet", "message_trace.parquet")}
    # Full-file serializer controls use two real files per child. Each group is
    # written by the genuine baseline Table.from_pandas or new buffer table;
    # the controller compares the complete row-group files and pandas readback.
    import pyarrow.parquet as pq
    def domain_groups(contract):
        groups = []
        for label, count in (("ordinary-all-valid", 2), ("all-null-nullable", 2),
                             ("utf8-empty-null", 3), ("signed-range", 2), ("zero-row", 0)):
            values = {}
            for name, dtype in contract.items():
                if dtype == "string":
                    column = ["x"] * count
                    if label == "all-null-nullable": column = [None] * count
                    if label == "utf8-empty-null": column = ["", "买入🙂", None]
                else:
                    column = list(range(1, count + 1))
                    if dtype == "Int64" and label == "all-null-nullable": column = [None] * count
                    if label == "signed-range":
                        bits = 32 if dtype == "int32" else 64
                        column = [-(1 << (bits - 1)), (1 << (bits - 1)) - 1]
                    if dtype == "Int64" and label == "ordinary-all-valid": column = [base, base + 1]
                values[name] = column
            groups.append((label, values))
        return groups
    serializer_groups = []
    production_readbacks = {}
    for kind, contract, ordinary in (("trace", TRACE_TYPES, expected_trace), ("message_trace", MESSAGE_TYPES, expected_messages)):
        group_values = [("actual-projection", ordinary), *domain_groups(contract)]
        tables = []
        for label, values_ in group_values:
            if args.arm == "baseline":
                frame = pd.DataFrame({name: pd.array(values_[name], dtype=dtype) for name, dtype in contract.items()}, columns=list(contract))
                table = pa.Table.from_pandas(frame, preserve_index=False)
                del frame
            else:
                schema = _schemas(pa)[kind]
                arrays = [_array(pa, field, contract[field.name], values_[field.name]) for field in schema]
                table = pa.Table.from_arrays(arrays, schema=schema)
                del arrays
            tables.append((label, table))
        del group_values
        del values_
        gc.collect()
        schema = tables[0][1].schema
        path = args.out_dir / ("trace.parquet" if kind == "trace" else "message_trace.parquet")
        production_table = pq.ParquetFile(path).read()
        if not production_table.schema.equals(schema, check_metadata=True) or production_table.to_pydict() != ordinary:
            raise AssertionError("actual production writer values/schema metadata differ")
        production_readbacks[kind] = {"rows": production_table.num_rows,
            "schema_sha256": hashlib.sha256(production_table.schema.serialize().to_pybytes()).hexdigest(),
            "null_counts": {name: production_table[name].null_count for name in production_table.column_names}}
        del production_table
        with pq.ParquetWriter(path, schema, compression="snappy") as writer:
            for label, table in tables:
                if not table.schema.equals(schema, check_metadata=True):
                    raise AssertionError("full serializer group schema metadata differs")
                writer.write_table(table)
                serializer_groups.append({"table": kind, "group": label, "rows": table.num_rows,
                    "actual_write_table_called": True,
                    "schema_sha256": hashlib.sha256(table.schema.serialize().to_pybytes()).hexdigest(),
                    "null_counts": {name: table[name].null_count for name in table.column_names}})
        del tables
        gc.collect()
    if args.arm == "cold-new" and (pandas_attempts or import_witness()["pandas_loaded"]):
        raise AssertionError("full serializer/lifetime control attempted or loaded pandas")
    import pyarrow as pa
    versions["pyarrow"] = pa.__version__
    if versions["numpy"] != "1.26.4" or versions["pyarrow"] != "15.0.2" or (args.arm == "baseline" and versions["pandas"] != "1.5.3"):
        raise AssertionError("exact pinned fixture dependencies required")
    files = {p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in args.out_dir.glob("*.parquet")}
    result = {"schema": "t3-pandas-free-output-fixture-worker-v1", "arm": args.arm,
              "runtime": str(runtime), "versions": versions, "files": files,
              "expected_values_equal": True, "raw_state_unchanged": True,
              "pandas_import_attempts": pandas_attempts,
              "pandas_loaded": any(name == "pandas" or name.startswith("pandas.") for name in sys.modules),
              "primitive_controls": [] if args.arm == "baseline" else primitive_controls,
              "source_domain_callback_controls": [] if args.arm == "baseline" else boundary_callbacks,
              "full_serializer_groups": serializer_groups,
              "production_write_api_files": production_api_files,
              "production_write_api_readbacks": production_readbacks,
              "market_executed": False, "timing_result": False}
    (args.out_dir / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    observer.finish_episode()
    print(json.dumps(result))


if __name__ == "__main__":
    main()
