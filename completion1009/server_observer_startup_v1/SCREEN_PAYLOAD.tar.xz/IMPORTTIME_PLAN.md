# Two optional import-time diagnostics, excluded from screening statistics

Keep these as a plan until the final two-arm correctness and server screen
pass. Do not add `-X importtime` to measured commands. It changes import work
and stderr volume, so its totals are diagnostic rather than rankable timing.

Use two original single units: S001 (small, emphasizes startup cost) and AS06
(larger, separates similar startup work from market execution). For each unit
run the winner once and the composition once, serially: four additional
containers, not part of the 56-run screen. Reuse each already-built immutable
image and exactly the same no-network/nonroot/read-only/resource contract.
The sole invocation change is CPython `-X importtime` before the existing
`/screen/entry_probe.py`; keep verb, original scenario bytes and CLI unchanged.
Retain hard-bounded stderr, actual interpreter command, cold stock-module
visibility, entry receipt, output hashes and strict cleanup. If retaining the
same entrypoint requires fragile Docker command interception, postpone this
diagnostic instead of modifying authenticated candidate aliases.

Extract cumulative and self import microseconds for NumPy, Pandas, PyArrow,
SciPy, `abides_markets.agents` and its four deferred stock modules, the entry,
observer and observer_domain. Preserve the raw tree because cumulative rows
overlap and must not be summed. Note modules already loaded before a repeated
import have no new row. Compare presence and import paths first; use durations
only to locate follow-up startup work. Final post-run authentication may add
import rows after market completion, so trace boundaries and cold visibility
are necessary before interpreting them. Do not claim all stderr rows are
inside the production CLI startup timer.

No implementation, source import, container build, simulation or dispatch was
performed for this plan.
