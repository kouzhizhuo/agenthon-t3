"""Run the real CLI with finite path witnesses, then authenticate outside its timer."""
from contextlib import contextmanager
import contextlib
import ast
import functools
import importlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import platform
import resource
import sys
import types
from common import sha

ROOT = Path("/opt/t3-screen")
SPEC = json.loads(Path("/screen/ARM.json").read_text())
MARKER = "T3_SCREEN_RECEIPT="
PROBE_SCHEMA = "t3-screen-entry-probe-v2"
STOCK_MODULES = ("abides_markets.agents.examples.momentum_agent",
    "abides_markets.agents.market_makers.adaptive_market_maker_agent",
    "abides_markets.agents.noise_agent", "abides_markets.agents.value_agent")
STOCK_EXPORTS = ("MomentumAgent", "AdaptiveMarketMakerAgent", "NoiseAgent", "ValueAgent")


def stock_visibility():
    # sys.modules and the already-loaded package dict cannot invoke its lazy
    # export machinery. Never call dir, __all__, wildcard or stock getattr here.
    package = sys.modules.get("abides_markets.agents")
    if package is None:
        raise ValueError("real entry did not load the vendor agents package")
    return {"loaded_stock_modules": [name for name in STOCK_MODULES if name in sys.modules],
        "stock_dict_names": [name for name in STOCK_EXPORTS if name in vars(package)]}


def require_visibility(value):
    expected = {"loaded_stock_modules": [], "stock_dict_names": []} if SPEC["startup_lazy_expected"] else {
        "loaded_stock_modules": list(STOCK_MODULES), "stock_dict_names": list(STOCK_EXPORTS)}
    if value != expected:
        raise ValueError("actual cold stock imports differ from frozen startup arm")


def warm_observer_admissions():
    # This finite post-timer proof calls the exact original domain twice. It
    # adds no source pin and no producer patch. Whole admission is never cached.
    import observer_domain as domain
    def counters():
        return {"compiles": domain._CACHE_COMPILES, "ast_parses": domain._CACHE_AST_PARSES,
            "entries": len(domain._SOURCE_CACHE), "receipt_entries": len(domain._CACHE_RECEIPTS),
            "source_pins": len(domain._SOURCE_PINS)}
    before = counters()
    if before != {"compiles": 13, "ast_parses": 13, "entries": 13, "receipt_entries": 13, "source_pins": 13}:
        raise ValueError("actual observer source cache is not the thirteen-source warm cache")
    admissions = []
    for _ in range(2):
        admissions.append(domain.authenticate_loaded())
        if admissions[-1] is not True or counters() != before:
            raise ValueError("warm observer admission failed or regenerated expectations")
    visibility = stock_visibility()
    require_visibility(visibility)
    return {"passed": True, "admissions": admissions, "before": before, "after": counters(),
        "stock_visibility": visibility, "timing_scope": "post CLI timer; included in host/container time"}


def resolve(binding):
    module, name = binding.rsplit(":", 1)
    value = importlib.import_module(module)
    for part in name.split("."):
        value = getattr(value, part)
    return value


def definition_codes(code):
    return {value.co_name: value for value in code.co_consts if type(value) is types.CodeType}


def frozen_contextmanager(target):
    """Authenticate the actual wrapper and its single generator closure."""
    raw = getattr(target, "__wrapped__", None)
    helper = next(c for c in contextlib.contextmanager.__code__.co_consts
                  if type(c) is types.CodeType and c.co_name == "helper")
    if (type(target) is not types.FunctionType or target.__code__ != helper
            or target.__globals__ is not vars(contextlib)
            or target.__defaults__ is not None or target.__kwdefaults__ is not None
            or target.__code__.co_freevars != ("func",)
            or len(target.__closure__ or ()) != 1
            or target.__closure__[0].cell_contents is not raw
            or type(raw) is not types.FunctionType):
        raise ValueError("actual contextmanager wrapper/closure differs")
    return raw


def auth_definitions(module, path):
    """Compare loaded explicit Python definitions, including wrapped methods."""
    tree = ast.parse(path.read_bytes())
    compiled = compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
    checked = []
    def walk(nodes, loaded, code, prefix=""):
        definitions = definition_codes(code)
        counts = {}
        for node in nodes:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                counts[node.name] = counts.get(node.name, 0) + 1
        seen = {}
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                target = getattr(loaded, node.name)
                if target.__module__ != module.__name__:
                    raise ValueError("loaded class origin differs: " + node.name)
                walk(node.body, target, definitions[node.name], prefix + node.name + ".")
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                ordinal = seen.get(node.name, 0)
                seen[node.name] = ordinal + 1
                matching_codes = [c for c in code.co_consts if type(c) is types.CodeType and c.co_name == node.name]
                if counts[node.name] > 1:
                    key = module.__name__ + ":" + prefix + node.name + "#" + str(ordinal)
                    alias = SPEC.get("binding_aliases", {}).get(key)
                    if alias is None:
                        raise ValueError("duplicate source definition requires exact saved-binding alias: " + key)
                    target = resolve(alias)
                else:
                    target = inspect.getattr_static(loaded, node.name)
                if isinstance(target, property):
                    target = target.fget
                elif isinstance(target, (classmethod, staticmethod)):
                    target = target.__func__
                decorators = node.decorator_list
                if any(isinstance(d, ast.Name) and d.id == "contextmanager" for d in decorators):
                    target = frozen_contextmanager(target)
                elif getattr(target, "__wrapped__", None) is not None:
                    raise ValueError("unexpected wrapped source function: " + node.name)
                if type(target) is not types.FunctionType or target.__code__ != matching_codes[ordinal]:
                    raise ValueError("loaded definition differs: " + module.__name__ + ":" + prefix + node.name)
                checked.append(prefix + node.name)
    walk(tree.body, module, compiled)
    return checked


def authenticate(entry):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64") or platform.python_version() != "3.11.17" or os.getuid() != 65534:
        raise ValueError("exact participant Linux amd64 Python/nonroot ABI differs")
    import numpy, pandas, pyarrow
    versions = {"numpy": numpy.__version__, "pandas": pandas.__version__, "pyarrow": pyarrow.__version__}
    if versions != SPEC["dependency_versions"]:
        raise ValueError("participant numeric dependency versions differ")
    files = {}
    for relative, expected in SPEC["participant_inventory"].items():
        path = ROOT / relative
        if path.is_symlink() or not path.is_file() or sha(path) != expected["sha256"] or path.stat().st_size != expected["bytes"]:
            raise ValueError("participant source changed: " + relative)
        files[relative] = expected
    modules = []
    for name, relative in SPEC["modules"].items():
        module = entry if name == "@entry" else importlib.import_module(name)
        path = ROOT / relative
        if Path(module.__file__).resolve() != path:
            raise ValueError("source-only loaded module origin differs: " + name)
        modules.append({"module": name, "path": str(path), "sha256": sha(path),
                        "definitions": auth_definitions(module, path)})
    native = []
    if SPEC["native"]:
        receipt = json.loads((ROOT / "NATIVE_BUILD_RECEIPT.json").read_text())
        for row in receipt["modules"]:
            module = importlib.import_module(row["module"])
            path = ROOT / row["extension"]
            if Path(module.__file__).resolve() != path or sha(path) != row["extension_sha256"]:
                raise ValueError("native loaded origin/hash differs")
            native.append(row)
    allowed = {row["module"] for row in native}
    incidental = []
    for name, module in list(sys.modules.items()):
        filename = getattr(module, "__file__", None)
        if filename and str(filename).startswith(str(ROOT) + "/") and str(filename).endswith((".so", ".pyd")) and name not in allowed:
            incidental.append({"module": name, "file": filename})
    if incidental:
        raise ValueError("incidental native runtime module prohibited: " + repr(incidental))
    limits = {name: list(resource.getrlimit(value)) for name, value in (
        ("nofile", resource.RLIMIT_NOFILE), ("nproc", resource.RLIMIT_NPROC), ("fsize", resource.RLIMIT_FSIZE))}
    if limits != {"nofile": [1024, 1024], "nproc": [256, 256], "fsize": [268435456, 268435456]}:
        raise ValueError("effective process ulimits differ")
    generated = list(SPEC.get("generated_files", []))
    if SPEC.get("preflight"):
        generated.append("LINUX_PREFLIGHT_RECEIPT.json")
    if SPEC["native"]:
        generated.append("NATIVE_BUILD_RECEIPT.json")
    generated_hashes = {relative: sha(ROOT / relative) for relative in generated}
    return {"passed": True, "source_files": files, "loaded_modules": modules, "native_modules": native,
        "generated_file_hashes": generated_hashes,
        "python": sys.version, "dependencies": versions, "uid": os.getuid(), "limits": limits}


def main():
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / SPEC["runtime"]))
    filename = ROOT / SPEC["entrypoint"]
    module_spec = importlib.util.spec_from_file_location(SPEC.get("entry_module_name", "_t3_screen_real_entry"), filename)
    entry = importlib.util.module_from_spec(module_spec)
    sys.modules[module_spec.name] = entry
    module_spec.loader.exec_module(entry)
    cold_stock = stock_visibility()
    require_visibility(cold_stock)
    if SPEC.get("preflight"):
        # Authenticate clean immutable bindings before any external witness.
        entry.ensure_static_admission()
    from abides_core import abides
    from abides_fork.config import ScenarioLatencyModel
    original_enabled, original_run = entry.enabled, abides.run
    original_extract = entry.extract_trace
    raw_enabled = frozen_contextmanager(original_enabled)
    import optimizations
    if raw_enabled.__globals__ is not vars(optimizations):
        raise ValueError("enabled generator owning globals differs")
    witnesses = []
    if SPEC.get("no_enabled_patch") and not SPEC.get("no_run_patch"):
        raise ValueError("unmodified enabled path requires an unmodified runner")
    @contextmanager
    def witnessed_enabled(*args, **kwargs):
        with original_enabled(*args, **kwargs) as extractor:
            expected = resolve(SPEC["expected_kernel"])
            if abides.Kernel is not expected:
                raise ValueError("expected exact kernel path is not active")
            if ScenarioLatencyModel.get_latency is not resolve(SPEC["expected_latency"]):
                raise ValueError("expected scalar latency path is not active")
            witnesses.append({"kernel": expected.__module__ + ":" + expected.__qualname__,
                "latency": ScenarioLatencyModel.get_latency.__module__ + ":" + ScenarioLatencyModel.get_latency.__qualname__,
                "extractor": extractor.__module__ + ":" + extractor.__qualname__, "native_sides": 0, "native_levels": 0})
            yield extractor
    def witnessed_run(*args, **kwargs):
        state = original_run(*args, **kwargs)
        witness = witnesses[-1]
        for agent in state["agents"]:
            if type(agent.kernel) is not resolve(SPEC["expected_kernel"]):
                raise ValueError("returned market used unexpected kernel")
            for book in getattr(agent, "order_books", {}).values():
                for side in (book.bids, book.asks):
                    if type(side).__module__ == "closed_book_store":
                        witness["native_sides"] += 1
                        witness["native_levels"] += len(side)
        return state
    def witnessed_extract(*args, **kwargs):
        # This CLI-local alias is outside the observer domain's authenticated
        # helpers. The original extractor runs unchanged before state capture.
        result = original_extract(*args, **kwargs)
        if SPEC.get("no_enabled_patch"):
            # Preserve the driver's authenticated aliases and all simulation
            # producers. The real returned Kernel identifies the actual path.
            agents = args[0]["agents"]
            expected = resolve(SPEC["expected_kernel"])
            if not agents or any(type(agent.kernel) is not expected for agent in agents):
                raise ValueError("returned market used unexpected kernel")
            witnesses.append({"kernel": expected.__module__ + ":" + expected.__qualname__,
                "latency": SPEC["expected_latency"],
                "latency_evidence": "authenticated unchanged enabled generator installs scalar binding for this exact returned Kernel; no temporary-method observation",
                "extractor": original_extract.__module__ + ":" + original_extract.__qualname__,
                "agent_count": len(agents),
                "books": [{"symbol": symbol, "retained_depth_rows": len(book.book_log2),
                    "bid_levels": len(book.bids), "ask_levels": len(book.asks),
                    "metrics": {name: {"type": type(getattr(agent.metric_trackers[symbol], name)).__name__,
                        "repr": repr(getattr(agent.metric_trackers[symbol], name))}
                        for name in ("total_time_no_liquidity_asks", "total_time_no_liquidity_bids", "pct_time_no_liquidity_asks", "pct_time_no_liquidity_bids")}}
                    for agent in agents for symbol, book in getattr(agent, "order_books", {}).items()],
                "native_sides": 0, "native_levels": 0})
        if SPEC.get("observer_probe"):
            import observer
            state = observer.STATE
            if state is None:
                raise ValueError("expected observer was not active in real episode")
            witnesses[-1]["observer"] = {name: getattr(state, name) for name in (
                "order_rows", "quote_rows", "private_rows", "termination_frames_avoided", "range_replays")}
            if state.order_rows <= 0 or state.termination_frames_avoided <= 0:
                raise ValueError("observer canonical producers/termination path not exercised")
        if SPEC.get("online_probe"):
            import online_metric
            row = {"episode": online_metric.EPISODES, "active": online_metric.ACTIVE, "books": []}
            expected_active = SPEC.get("online_expect_admitted", True)
            if online_metric.ACTIVE is not expected_active:
                raise ValueError("online metric admission/fallback path differs")
            if row["episode"] != len(witnesses):
                raise ValueError("online metric episode reset/roster differs")
            for agent in args[0]["agents"]:
                for symbol, book in getattr(agent, "order_books", {}).items():
                    accumulator = book._online_metric
                    if expected_active:
                        if type(accumulator) is not online_metric.OnlineMetric or book.book_log2:
                            raise ValueError("online accumulator/depth history path differs")
                        info = {"rows": accumulator.rows,
                            "first_type": type(accumulator.first).__name__, "last_type": type(accumulator.last).__name__}
                    else:
                        if accumulator is not None:
                            raise ValueError("fallback created online accumulator")
                        info = {"rows": len(book.book_log2)}
                    metric = agent.metric_trackers[symbol]
                    row["books"].append({"symbol": symbol, "accumulator_type": type(accumulator).__name__,
                        "retained_depth_rows": len(book.book_log2), **info,
                        "metrics": {name: {"type": type(getattr(metric, name)).__name__, "repr": repr(getattr(metric, name))}
                            for name in ("total_time_no_liquidity_asks", "total_time_no_liquidity_bids", "pct_time_no_liquidity_asks", "pct_time_no_liquidity_bids")}})
            if not row["books"]:
                raise ValueError("online metric has no observed books")
            witnesses[-1]["online_metric"] = row
        return result
    if not SPEC.get("no_enabled_patch"):
        entry.enabled = witnessed_enabled
    if not SPEC.get("no_run_patch"):
        abides.run = witnessed_run
    if SPEC.get("observer_probe") or SPEC.get("online_probe") or SPEC.get("no_enabled_patch"):
        entry.extract_trace = witnessed_extract
    error = None
    try:
        entry.main()
    except BaseException as exc:
        error = type(exc).__name__ + ": " + str(exc)
        raise
    finally:
        entry.enabled, abides.run = original_enabled, original_run
        entry.extract_trace = original_extract
        receipt = {"schema": "t3-screen-execution-bindings-v1", "arm": SPEC["name"], "rankable": False,
                   "probe_schema": PROBE_SCHEMA, "witnesses": witnesses, "cli_error": error,
                   "startup_probe_schema": "t3-observer-startup-probe-v1", "cold_stock_visibility": cold_stock,
                   "timing_scope": "real CLI entry timer includes finite post-market capture; post authentication excluded"}
        try:
            receipt["authentication"] = authenticate(entry)
            receipt["warm_observer_admissions"] = warm_observer_admissions()
            if SPEC.get("online_probe") and not entry.authenticate_loaded():
                raise ValueError("restored online loaded domain differs")
            if not witnesses:
                raise ValueError("no real episode path witnessed")
            if SPEC["native"] and any(row["native_sides"] <= 0 for row in witnesses):
                raise ValueError("native book extension was not exercised in every episode")
            if SPEC.get("active_probe"):
                receipt["active_probe"] = resolve(SPEC["active_probe"])()
                if not receipt["active_probe"]:
                    raise ValueError("candidate active probe is empty")
                for key, value in SPEC["probe_equals"].items():
                    if receipt["active_probe"].get(key) != value:
                        raise ValueError("candidate active/fallback probe differs: " + key)
            receipt["passed"] = error is None
        except BaseException as exc:
            receipt["passed"] = False
            receipt["authentication_error"] = type(exc).__name__ + ": " + str(exc)
            print(MARKER + json.dumps(receipt, sort_keys=True), flush=True)
            raise
        print(MARKER + json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
