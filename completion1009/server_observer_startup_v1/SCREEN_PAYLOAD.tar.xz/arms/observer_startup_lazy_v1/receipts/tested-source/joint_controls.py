#!/usr/bin/env python3
"""Prepared serial import and inherited observer controls, with immutable attempts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OBSERVER = HERE.parent / "observer_mixed_v2_authcache"
OUTPUT = ROOT / "verification/observer_startup_lazy_controls_v1"
EXPORTS = ("MomentumAgent", "AdaptiveMarketMakerAgent", "ExchangeAgent", "FinancialAgent", "NoiseAgent", "TradingAgent", "ValueAgent")
CASES = ("cold", "missing", "dir", "wildcard", "all_absent", "caller_global", "pickle") + tuple(
    "export:" + name + ":" + mode for name in EXPORTS for mode in ("getattr", "from", "submodule")) + tuple(
    mode + ":" + name for name in EXPORTS for mode in ("first_submodule", "first_package")) + tuple(
    "module:" + name for name in ("examples", "market_makers", "noise_agent", "value_agent")) + (
    "order:MomentumAgent,AdaptiveMarketMakerAgent,NoiseAgent,ValueAgent",
    "order:ValueAgent,NoiseAgent,AdaptiveMarketMakerAgent,MomentumAgent",
    "order:TradingAgent,MomentumAgent,ExchangeAgent,ValueAgent,FinancialAgent,NoiseAgent,AdaptiveMarketMakerAgent",
    "order:AdaptiveMarketMakerAgent,TradingAgent,ValueAgent,ExchangeAgent,NoiseAgent,MomentumAgent,FinancialAgent",
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(root):
    return {str(path.relative_to(root)): sha(path) for path in sorted(root.rglob("*"))
        if path.is_file() and not path.name.startswith("._") and "__pycache__" not in path.parts}


def sources():
    return {path.name: sha(path) for path in sorted(HERE.glob("*.py")) if not path.name.startswith("._")}


def hashes():
    return {"runtime_sha256": inventory(ROOT / "runtime"),
        "candidate_runtime_sha256": inventory(HERE / "runtime"),
        "candidate_source_sha256": sources(), "observer_parent_runtime_sha256": inventory(OBSERVER / "runtime"),
        "manifest_sha256": sha(HERE / "SNAPSHOT_MANIFEST.json"),
        "patch_manifest_sha256": sha(HERE / "PATCH_MANIFEST.json"),
        "source_diff_sha256": sha(HERE / "SOURCE_DIFF.patch")}


def authenticate_snapshot():
    manifest = json.loads((HERE / "SNAPSHOT_MANIFEST.json").read_text())
    patch = json.loads((HERE / "PATCH_MANIFEST.json").read_text())
    if inventory(HERE / "runtime") != {row["path"]: row["sha256"] for row in manifest["files"]}:
        raise ValueError("joint runtime snapshot differs")
    if sha(ROOT / "RUNTIME_MANIFEST.json") != manifest["frozen_manifest_sha256"]:
        raise ValueError("frozen original manifest differs")
    original = {str(Path(row["path"]).relative_to("runtime")): row["sha256"]
        for row in json.loads((ROOT / "RUNTIME_MANIFEST.json").read_text())["files"]}
    if inventory(ROOT / "runtime") != original:
        raise ValueError("original complete runtime inventory differs")
    if sha(HERE / "PATCH_MANIFEST.json") != manifest["patch_manifest_sha256"]:
        raise ValueError("joint patch manifest differs")
    if sha(HERE / "SOURCE_DIFF.patch") != patch["source_diff_sha256"] or sources() != patch["controls_source_sha256"]:
        raise ValueError("joint source/control bindings differ")
    parents = patch["parent_bindings"]
    if inventory(OBSERVER / "runtime") != parents["observer"]["candidate_runtime_sha256"]:
        raise ValueError("observer frozen parent differs")
    for name, digest in parents["observer"]["candidate_source_sha256"].items():
        if sha(OBSERVER / name) != digest:
            raise ValueError("observer frozen parent source differs")
    if sha(OBSERVER / "SNAPSHOT_MANIFEST.json") != parents["observer_manifest_sha256"]:
        raise ValueError("observer frozen parent manifest differs")
    startup = HERE.parent / "startup_lazy_exports_v1"
    if inventory(startup / "runtime") != parents["startup"]["candidate_runtime_sha256"]:
        raise ValueError("startup frozen parent differs")
    for category in ("candidate_sha256", "control_sha256"):
        for name, digest in parents["startup"][category].items():
            if sha(startup / name) != digest:
                raise ValueError("startup parent source/control differs")
    for relative, digest in parents["receipts"].items():
        if sha(ROOT / relative) != digest:
            raise ValueError("parent passing receipt differs")


def launch(worker, arm, runtime, directory, extra=()):
    directory.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update(PYTHONPATH=str(ROOT.parent / ".runtime"), PYTHONDONTWRITEBYTECODE="1")
    command = [sys.executable, str(HERE / worker), "--runtime", str(runtime), "--out", str(directory), *extra]
    with (directory / "run.log").open("w") as stream:
        process = subprocess.run(command, cwd=runtime, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    if process.returncode:
        raise ValueError("worker failed: " + arm + "; preserve " + str(directory))
    return {"arm": arm, "command": command, "exit_code": 0,
        "worker_receipt_sha256": sha(directory / "WORKER_RECEIPT.json"), "timing_claim": False}


def imports(result, output):
    for arm, runtime in (("parent", OBSERVER / "runtime"), ("joint", HERE / "runtime")):
        directory = output / ("cold_observer_" + arm)
        extra = ("--expect-lazy",) if arm == "joint" else ()
        result["runs"].append(launch("cold_observer_worker.py", arm, runtime, directory, extra))
    assert (output / "cold_observer_parent/VALUES.json").read_bytes() == (output / "cold_observer_joint/VALUES.json").read_bytes(), "cold admission results differ"
    result["cases"].append({"family": "cold_observer_two_admissions", "passed": True,
        "candidate_stock_modules_before_after": "absent", "expected_compile_and_ast_count": 13})
    for index, case in enumerate(CASES):
        paths = {}
        for arm, runtime in (("parent", OBSERVER / "runtime"), ("joint", HERE / "runtime")):
            directory = output / (str(index).zfill(2) + "_" + arm)
            extra = ("--case", case) + (("--expect-lazy",) if arm == "joint" else ())
            result["runs"].append(launch("export_worker.py", arm + ":" + case, runtime, directory, extra))
            paths[arm] = directory
        assert (paths["parent"] / "VALUES.json").read_bytes() == (paths["joint"] / "VALUES.json").read_bytes(), "API values differ: " + case
        result["cases"].append({"case": case, "passed": True, "values_sha256": sha(paths["parent"] / "VALUES.json")})
        if case == "pickle":
            pickle_paths = paths
    for donor, arm, runtime in (("parent", "joint", HERE / "runtime"), ("joint", "parent", OBSERVER / "runtime")):
        directory = output / ("cross_pickle_" + donor + "_to_" + arm)
        extra = ("--case", "pickle_read", "--pickle-in", str(pickle_paths[donor] / "EXPORT_INSTANCES.pkl")) + (("--expect-lazy",) if arm == "joint" else ())
        result["runs"].append(launch("export_worker.py", donor + "_to_" + arm, runtime, directory, extra))
        values = json.loads((directory / "VALUES.json").read_text())
        donor_values = json.loads((pickle_paths[donor] / "VALUES.json").read_text())
        assert values["instances"] == donor_values["instances"] and values["instance_types_exact"] is True
        result["cases"].append({"case": "pickle_" + donor + "_to_" + arm, "passed": True})


def inherited_observer(result, output):
    target = output / "inherited_observer"
    command = [sys.executable, str(HERE / "observer_controls_driver.py"), "--out", str(target)]
    env = os.environ.copy()
    env.update(PYTHONPATH=str(ROOT.parent / ".runtime"), PYTHONDONTWRITEBYTECODE="1")
    with (output / "observer_controls.log").open("w") as stream:
        process = subprocess.run(command, cwd=HERE / "runtime", env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
    if process.returncode:
        raise ValueError("inherited full observer controls failed; preserve " + str(target))
    receipt = json.loads((target / "RESULT.json").read_text())
    if receipt.get("all_passed") is not True or receipt.get("sources_unchanged") is not True or receipt.get("finite_only") is True:
        raise ValueError("inherited observer receipt incomplete")
    expected = hashes()
    for key in ("runtime_sha256", "candidate_runtime_sha256", "candidate_source_sha256", "manifest_sha256", "patch_manifest_sha256", "source_diff_sha256"):
        if receipt.get(key) != expected[key]:
            raise ValueError("inherited observer final source binding stale: " + key)
    result["runs"].append({"arm": "inherited_full_observer", "command": command, "exit_code": 0,
        "worker_receipt_sha256": sha(target / "RESULT.json"), "timing_claim": False})
    result["cases"].append({"family": "inherited_full_observer", "passed": True,
        "receipt": str(target / "RESULT.json"), "receipt_sha256": sha(target / "RESULT.json"),
        "case_count": len(receipt["cases"]), "finite_only": False})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("imports", "observer", "all"), default="imports")
    parser.add_argument("--attempt", type=int, default=1)
    args = parser.parse_args()
    if args.attempt < 1:
        raise ValueError("positive attempt required")
    authenticate_snapshot()
    before = hashes()
    output = OUTPUT / (args.phase + "_attempt" + str(args.attempt))
    output.mkdir(parents=True, exist_ok=False)
    result = {"schema": "t3-observer-startup-lazy-joint-controls-v1", "attempt": args.attempt,
        "phase": args.phase, "all_passed": False, "rankable": False, "official_gate": False,
        "timing_claim": False, **before, "cases": [], "runs": [], "failures": []}
    (output / "PREDECLARED_PLAN.json").write_text(json.dumps({**before, "phase": args.phase,
        "import_api_cases": 52, "fresh_import_processes": 104,
        "observer_scope": "35 output/inference,4summary,20admission,19warm cache,4termination,288book,34lazy,4fullmarket",
        "comparison_scope": "same inherited exact retained observer state/aliases/output/dtype/parquet/RNG/ID and explicit private log/book representation exclusions; cold namespace/API visibility from original lazy candidate",
        "timer": "none", "rankable": False}, indent=2) + "\n")
    try:
        if args.phase in ("imports", "all"):
            imports(result, output)
        if args.phase in ("observer", "all"):
            inherited_observer(result, output)
        assert hashes() == before, "source changed during joint controls"
        result.update(all_passed=True, sources_unchanged=True)
    except Exception as error:
        result["failures"].append({"type": type(error).__name__, "message": str(error)})
    data = json.dumps(result, indent=2) + "\n"
    (output / "RESULT.json").write_text(data)
    current = HERE / ("JOINT_" + args.phase.upper() + "_RESULT.json")
    if current.exists():
        previous = current.with_name(current.stem + "_previous_before_attempt" + str(args.attempt) + ".json")
        if previous.exists():
            raise ValueError("previous receipt already preserved")
        previous.write_bytes(current.read_bytes())
    current.write_text(data)
    print(json.dumps({"all_passed": result["all_passed"], "phase": args.phase,
        "result": str(output / "RESULT.json"), "failures": result["failures"]}))
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
