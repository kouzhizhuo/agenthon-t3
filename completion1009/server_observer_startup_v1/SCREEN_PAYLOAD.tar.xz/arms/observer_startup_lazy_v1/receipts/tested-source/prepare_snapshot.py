#!/usr/bin/env python3
"""Source-only init splice; authenticate passing parents without runtime imports."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OBSERVER = HERE.parent / "observer_mixed_v2_authcache"
STARTUP = HERE.parent / "startup_lazy_exports_v1"
DEST = HERE / "runtime"
CHANGED = "vendor/abides/abides-markets/abides_markets/agents/__init__.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root, python_only=False):
    return {str(path.relative_to(root)): sha(path) for path in sorted(root.rglob("*.py" if python_only else "*"))
        if path.is_file() and not path.name.startswith("._") and "__pycache__" not in path.parts}


def source_inventory(root):
    return {path.name: sha(path) for path in sorted(root.glob("*.py")) if not path.name.startswith("._")}


def parent_bindings():
    frozen_path = ROOT / "RUNTIME_MANIFEST.json"
    frozen = json.loads(frozen_path.read_text())
    original = {str(Path(row["path"]).relative_to("runtime")): row["sha256"] for row in frozen["files"]}
    if inventory(ROOT / "runtime") != original:
        raise ValueError("complete original runtime differs")
    observer_manifest = json.loads((OBSERVER / "SNAPSHOT_MANIFEST.json").read_text())
    observer_proof = json.loads((OBSERVER / "CORRECTNESS_EVIDENCE.json").read_text())
    observer_result_path = Path(observer_proof["result_path"])
    observer_result = json.loads(observer_result_path.read_text())
    observer_sources = source_inventory(OBSERVER)
    expected_observer = {"candidate_runtime_sha256": inventory(OBSERVER / "runtime"),
        "candidate_source_sha256": observer_sources, "runtime_sha256": original,
        "manifest_sha256": sha(OBSERVER / "SNAPSHOT_MANIFEST.json"),
        "patch_manifest_sha256": sha(OBSERVER / "PATCH_MANIFEST.json"),
        "source_diff_sha256": sha(OBSERVER / "SOURCE_DIFF.patch")}
    if (observer_result.get("all_passed") is not True or observer_result.get("sources_unchanged") is not True
            or observer_result.get("finite_only") is True
            or any(observer_result.get(key) != value for key, value in expected_observer.items())
            or observer_proof["result_sha256"] != sha(observer_result_path)
            or observer_proof["candidate_runtime_sha256"] != expected_observer["candidate_runtime_sha256"]
            or observer_proof["candidate_source_sha256"] != observer_sources
            or observer_proof["snapshot_manifest_sha256"] != expected_observer["manifest_sha256"]):
        raise ValueError("observer parent final receipt/source bindings differ")
    if expected_observer["candidate_runtime_sha256"] != {row["path"]: row["sha256"] for row in observer_manifest["files"]}:
        raise ValueError("observer snapshot inventory differs")
    if (observer_manifest["frozen_manifest_sha256"] != sha(frozen_path)
            or observer_manifest["patch_manifest_sha256"] != sha(OBSERVER / "PATCH_MANIFEST.json")):
        raise ValueError("observer parent frozen/patch pins differ")
    startup_manifest = json.loads((STARTUP / "SNAPSHOT_MANIFEST.json").read_text())
    expected_startup = {"candidate_sha256": {name: sha(STARTUP / name) for name in
        ("cli.py", "PINNED_RUNTIME.json", "PATCH_MANIFEST.json", "SNAPSHOT_MANIFEST.json", "lazy_agents_init.py", "prepare_snapshot.py", "admission.py")},
        "candidate_runtime_sha256": inventory(STARTUP / "runtime"),
        "parent_runtime_sha256": inventory(HERE.parent / "mixed_static_v2/runtime"),
        "runtime_sha256": inventory(ROOT / "runtime", True),
        "control_sha256": {path.name: sha(path) for path in sorted(STARTUP.glob("*.py"))
            if not path.name.startswith("._") and (path.name.endswith("worker.py") or path.name.endswith("controls.py") or path.name == "semantic_helpers.py")}}
    if expected_startup["candidate_runtime_sha256"] != {row["path"]: row["sha256"] for row in startup_manifest["files"]}:
        raise ValueError("startup snapshot inventory differs")
    if (startup_manifest["frozen_manifest_sha256"] != sha(frozen_path)
            or startup_manifest["patch_manifest_sha256"] != sha(STARTUP / "PATCH_MANIFEST.json")):
        raise ValueError("startup parent frozen/patch pins differ")
    receipts = {str((OBSERVER / "CORRECTNESS_EVIDENCE.json").relative_to(ROOT)): sha(OBSERVER / "CORRECTNESS_EVIDENCE.json"),
        str(observer_result_path.relative_to(ROOT)): sha(observer_result_path)}
    for name in ("CONTROLS_RESULT.json", "COMPOSITION_FINITE_RESULT.json", "COMPOSITION_SEMANTIC_RESULT.json"):
        path = STARTUP / name
        result = json.loads(path.read_text())
        if result.get("all_passed") is not True or result.get("sources_unchanged") is not True:
            raise ValueError("startup parent receipt not passing: " + name)
        if any(result.get(key) != value for key, value in expected_startup.items()):
            raise ValueError("startup parent receipt stale: " + name)
        receipts[str(path.relative_to(ROOT))] = sha(path)
    return observer_manifest, {"observer": expected_observer, "startup": expected_startup,
        "receipts": receipts, "frozen_manifest_sha256": sha(frozen_path),
        "observer_manifest_sha256": sha(OBSERVER / "SNAPSHOT_MANIFEST.json"),
        "startup_manifest_sha256": sha(STARTUP / "SNAPSHOT_MANIFEST.json")}


def main():
    if DEST.exists():
        raise ValueError("runtime snapshot exists; preserve historical candidate")
    parent, bindings = parent_bindings()
    rows, diffs = [], []
    for row in parent["files"]:
        relative = row["path"]
        parent_path = OBSERVER / "runtime" / relative
        source = STARTUP / "runtime" / relative if relative == CHANGED else parent_path
        data = source.read_bytes()
        if relative.endswith(".py"):
            ast.parse(data)
        target = DEST / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod(parent_path.stat().st_mode & 0o777)
        rows.append({"path": relative, "bytes": len(data), "sha256": sha(target),
            "observer_parent_sha256": row["sha256"], "changed_from_observer": relative == CHANGED,
            "startup_donor_sha256": sha(source) if relative == CHANGED else None})
        if relative == CHANGED:
            diffs.extend(difflib.unified_diff(parent_path.read_text().splitlines(True), data.decode().splitlines(True),
                fromfile="observer_mixed_v2_authcache/runtime/" + relative,
                tofile="observer_startup_lazy_v1/runtime/" + relative))
    (HERE / "SOURCE_DIFF.patch").write_text("".join(diffs))
    patch = {"schema": "t3-observer-startup-lazy-source-v1", "source_only": True,
        "tests_run": False, "market_run": False, "timing_run": False, "build_run": False,
        "rankable": False, "official_gate": False, "changed_runtime_files": [CHANGED],
        "observer_domain_unchanged": True, "observer_source_pins_unchanged": True,
        "parent_bindings": bindings, "builder_sha256": sha(Path(__file__)),
        "source_diff_sha256": sha(HERE / "SOURCE_DIFF.patch"),
        "controls_source_sha256": source_inventory(HERE),
        "fresh_controls_required": True, "parent_pass_is_not_joint_pass": True}
    (HERE / "PATCH_MANIFEST.json").write_text(json.dumps(patch, indent=2) + "\n")
    manifest = {"schema": patch["schema"], "source_only": True, "rankable": False,
        "files": rows, "changed_runtime_files": [CHANGED],
        "frozen_manifest_sha256": bindings["frozen_manifest_sha256"],
        "patch_manifest_sha256": sha(HERE / "PATCH_MANIFEST.json"),
        "direct_cli": str(DEST / "agent.py")}
    (HERE / "SNAPSHOT_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"prepared_source_only": True, "files": len(rows),
        "changes": [CHANGED], "tests_run": False, "observer_domain_unchanged": True}))


if __name__ == "__main__":
    main()
