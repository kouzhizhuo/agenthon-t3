#!/usr/bin/env python3
"""Fresh untimed observer admission without requesting any stock export."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys
import types

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--expect-lazy", action="store_true")
args = parser.parse_args()
RUNTIME = Path(args.runtime).resolve()
OUTPUT = Path(args.out).resolve()
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
import numpy as np
import pandas as pd
np.random.seed(741009)
before = np.random.get_state()
pd.set_option("display.max_rows", 731)
import agent
import observer
import observer_domain as domain
from abides_fork import config, agents
package = importlib.import_module("abides_markets.agents")
from abides_markets.agents.exchange_agent import ExchangeAgent
from abides_markets.agents.financial_agent import FinancialAgent
from abides_markets.agents.trading_agent import TradingAgent

stock = ("MomentumAgent", "AdaptiveMarketMakerAgent", "NoiseAgent", "ValueAgent")
modules = ("abides_markets.agents.examples.momentum_agent",
    "abides_markets.agents.market_makers.adaptive_market_maker_agent",
    "abides_markets.agents.noise_agent", "abides_markets.agents.value_agent")


def visibility():
    loaded = [name for name in modules if name in sys.modules]
    names = [name for name in stock if name in vars(package)]
    if args.expect_lazy:
        assert loaded == [] and names == [], "observer admission forced unused stock export"
    else:
        assert loaded == list(modules) and names == list(stock), "eager observer control lost original exports"
    return {"loaded_stock_modules": loaded, "stock_dict_names": names}


assert Path(package.__file__).resolve() == RUNTIME / "vendor/abides/abides-markets/abides_markets/agents/__init__.py"
assert Path(domain.__file__).resolve() == RUNTIME / "observer_domain.py"
assert Path(observer.__file__).resolve() == RUNTIME / "observer.py"
assert config.ExchangeAgent is package.ExchangeAgent is ExchangeAgent
assert agents.TradingAgent is package.TradingAgent is TradingAgent
assert package.FinancialAgent is FinancialAgent
assert pd.get_option("display.max_rows") == 500
observations = [visibility()]
assert domain.authenticate_loaded() is True, "first observer admission declined"
observations.append(visibility())
counts = (domain._CACHE_COMPILES, domain._CACHE_AST_PARSES)
assert counts == (13, 13) == (len(domain._SOURCE_PINS), len(domain._SOURCE_PINS))
assert domain.authenticate_loaded() is True, "warm observer admission declined"
observations.append(visibility())
assert (domain._CACHE_COMPILES, domain._CACHE_AST_PARSES) == counts
assert not any(name == "scipy" or name.startswith("scipy.") for name in sys.modules)
after = np.random.get_state()
assert before[0] == after[0] and np.array_equal(before[1], after[1]) and before[2:] == after[2:]
if args.expect_lazy:
    path = Path(package.__file__)
    compiled = compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
    for name in ("_load_export", "_materialize_exports", "__getattr__", "__dir__"):
        function = vars(package)[name]
        expected = next(value for value in compiled.co_consts if type(value) is types.CodeType and value.co_name == name)
        assert type(function) is types.FunctionType and function.__code__ == expected
        assert function.__globals__ is vars(package)

values = {"admissions": [True, True], "compile_count": counts[0], "ast_parse_count": counts[1],
    "eager_identity": True, "display_max_rows": 500, "global_rng_unchanged": True,
    "scipy_unloaded": True, "observer_active_state": observer.STATE is not None}
data = json.dumps(values, sort_keys=True, indent=2).encode() + b"\n"
(OUTPUT / "VALUES.json").write_bytes(data)
(OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps({"passed": True,
    "runtime": str(RUNTIME), "observations": observations,
    "timing_claim": False, "market_run": False,
    "values_sha256": hashlib.sha256(data).hexdigest()}, indent=2) + "\n")
print(json.dumps({"passed": True, "admissions": 2, "market_run": False}))
