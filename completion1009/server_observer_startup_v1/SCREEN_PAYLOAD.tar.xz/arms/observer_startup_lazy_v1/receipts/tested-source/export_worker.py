#!/usr/bin/env python3
"""One fresh process for one import/API control, with no market or timing run."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import pickle
import sys
import types

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--case", required=True)
parser.add_argument("--expect-lazy", action="store_true")
parser.add_argument("--pickle-in")
args = parser.parse_args()
RUNTIME = Path(args.runtime).resolve()
OUTPUT = Path(args.out).resolve()
sys.path.insert(0, str(RUNTIME))
from bootstrap import activate
activate()
import numpy as np
import pandas as pd

PACKAGE = "abides_markets.agents"
EXPORTS = {
    "MomentumAgent": "examples.momentum_agent",
    "AdaptiveMarketMakerAgent": "market_makers.adaptive_market_maker_agent",
    "ExchangeAgent": "exchange_agent",
    "FinancialAgent": "financial_agent",
    "NoiseAgent": "noise_agent",
    "TradingAgent": "trading_agent",
    "ValueAgent": "value_agent",
}
LAZY = ("MomentumAgent", "AdaptiveMarketMakerAgent", "NoiseAgent", "ValueAgent")
STOCK_MODULES = tuple(PACKAGE + "." + EXPORTS[name] for name in LAZY)


def encode(value):
    if value is None or type(value) in (int, str, bool):
        return [type(value).__name__, value]
    if type(value) is float:
        return ["float", value.hex()]
    if isinstance(value, np.generic):
        return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.ndarray):
        return ["ndarray", str(value.dtype), list(value.shape), value.tobytes().hex()]
    if isinstance(value, np.random.RandomState):
        return ["RandomState", encode(value.get_state())]
    if isinstance(value, types.ModuleType):
        return ["module", value.__name__]
    if isinstance(value, type):
        return ["class", value.__module__, value.__qualname__]
    if type(value) in (tuple, list):
        return [type(value).__name__, [encode(item) for item in value]]
    if type(value) is dict:
        return ["dict", [[encode(key), encode(item)] for key, item in value.items()]]
    if isinstance(value, (types.FunctionType, types.BuiltinFunctionType)):
        return ["callable", value.__module__, value.__qualname__]
    if hasattr(value, "__dict__"):
        return [type(value).__module__, type(value).__qualname__, encode(vars(value))]
    raise TypeError("unhandled export-control value: " + type(value).__name__)


def original_class(name):
    module = importlib.import_module(PACKAGE + "." + EXPORTS[name])
    expected_file = RUNTIME / "vendor/abides/abides-markets/abides_markets/agents" / (EXPORTS[name].replace(".", "/") + ".py")
    assert Path(module.__file__).resolve() == expected_file, "class module comes from wrong runtime"
    cls = getattr(module, name)
    assert cls.__module__ == module.__name__ and cls.__qualname__ == name
    assert isinstance(cls, type)
    tree = compile(expected_file.read_bytes(), str(expected_file), "exec", dont_inherit=True)
    cls_code = next(item for item in tree.co_consts if type(item) is types.CodeType and item.co_name == name)
    init_code = next(item for item in cls_code.co_consts if type(item) is types.CodeType and item.co_name == "__init__")
    assert type(cls.__init__) is types.FunctionType and cls.__init__.__code__ == init_code
    assert cls.__init__.__globals__["__file__"] == str(expected_file)
    return cls


def requested_class(name, mode):
    if mode == "getattr":
        value = getattr(package, name)
    elif mode == "from":
        namespace = {}
        exec("from " + PACKAGE + " import " + name, namespace)
        value = namespace[name]
    elif mode == "submodule":
        value = original_class(name)
    else:
        raise ValueError("unknown request mode")
    original = original_class(name)
    assert value is original and getattr(package, name) is original
    assert getattr(package, name) is value and vars(package)[name] is value
    assert pickle.loads(pickle.dumps(value, protocol=4)) is value
    return {"name": name, "mode": mode, "binding": encode(value),
        "defaults": encode(value.__init__.__defaults__),
        "kwdefaults": encode(value.__init__.__kwdefaults__),
        "repeat_identity": True, "class_pickle_identity": True}


def assert_lazy_cold():
    loaded = [name for name in STOCK_MODULES if name in sys.modules]
    if args.expect_lazy:
        assert not loaded, "unused stock module loaded at cold T3 import"
        assert not any(name in vars(package) for name in LAZY)
    else:
        assert loaded == list(STOCK_MODULES), "eager control did not import stock modules"
        assert all(name in vars(package) for name in LAZY)
    return loaded


def public_namespace(namespace):
    return {name: encode(value) for name, value in sorted(namespace.items()) if not name.startswith("_")}


def instance_for(name):
    cls = original_class(name)
    kwargs = {"id": 1, "name": "EXPORT_CTRL", "type": name,
        "random_state": np.random.RandomState(941009)}
    if name in ("MomentumAgent", "AdaptiveMarketMakerAgent"):
        kwargs.update(symbol="ABM", starting_cash=10000)
    elif name in ("NoiseAgent", "ValueAgent"):
        kwargs["symbol"] = "ABM"
    return cls(**kwargs)


np.random.seed(9341009)
rng_before = encode(np.random.get_state())
pd.set_option("display.max_rows", 731)
pieces = args.case.split(":")
first_request = None
if pieces[0] == "first_submodule":
    # Enter the package through a direct child module before T3 config import.
    first_request = original_class(pieces[1])
elif pieces[0] == "first_package":
    namespace = {}
    exec("from " + PACKAGE + " import " + pieces[1], namespace)
    first_request = namespace[pieces[1]]
from abides_fork import config
package = importlib.import_module(PACKAGE)
assert Path(package.__file__).resolve() == RUNTIME / "vendor/abides/abides-markets/abides_markets/agents/__init__.py"
assert config.ExchangeAgent is package.ExchangeAgent is original_class("ExchangeAgent")
assert pd.get_option("display.max_rows") == 500, "exchange import option side effect changed"
assert encode(np.random.get_state()) == rng_before, "stock/config import consumed global RNG"
assert not any(name == "scipy" or name.startswith("scipy.") for name in sys.modules), "mixed parent/startup imports SciPy before fallback"

if args.expect_lazy:
    tree = compile(Path(package.__file__).read_bytes(), str(Path(package.__file__)), "exec", dont_inherit=True)
    for name in ("_load_export", "_materialize_exports", "__getattr__", "__dir__"):
        expected = next(item for item in tree.co_consts if type(item) is types.CodeType and item.co_name == name)
        assert vars(package)[name].__code__ == expected, "lazy helper differs from bound source"

loaded_at_cold = ([name for name in STOCK_MODULES if name in sys.modules]
    if first_request is not None else assert_lazy_cold())
state = {"case": args.case, "exchange_option": pd.get_option("display.max_rows"),
    "global_rng_before": rng_before}
if pieces[0] == "cold":
    assert encode(np.random.get_state()) == rng_before
    state["needed_exports"] = [encode(getattr(package, name)) for name in ("ExchangeAgent", "FinancialAgent", "TradingAgent")]
elif pieces[0] == "export":
    state["request"] = requested_class(pieces[1], pieces[2])
elif pieces[0] in ("first_submodule", "first_package"):
    original = original_class(pieces[1])
    assert first_request is original is getattr(package, pieces[1])
    state["first_request"] = encode(first_request)
    state["repeat"] = requested_class(pieces[1], "from")
elif pieces[0] == "module":
    name = pieces[1]
    value = getattr(package, name)
    expected = importlib.import_module(PACKAGE + "." + name)
    assert value is expected and vars(package)[name] is expected
    state["module"] = encode(value)
elif pieces[0] == "order":
    state["requests"] = [requested_class(name, "submodule" if index % 2 else "from")
        for index, name in enumerate(pieces[1].split(","))]
elif pieces[0] == "missing":
    name = "undefined_attribute_for_export_control"
    for mode in ("getattr", "hasattr"):
        if mode == "hasattr":
            assert hasattr(package, name) is False
        else:
            try:
                getattr(package, name)
            except AttributeError as error:
                message = f"module '{PACKAGE}' has no attribute '{name}'"
                assert str(error) == message
                state["missing_exception"] = [type(error).__name__, str(error)]
            else:
                raise AssertionError("missing attribute accepted")
    assert_lazy_cold()
elif pieces[0] == "dir":
    state["dir"] = dir(package)
    assert state["dir"] == dir(package)
    state["public"] = public_namespace(vars(package))
    assert all(name in state["dir"] for name in EXPORTS)
    assert all(name in sys.modules for name in STOCK_MODULES)
elif pieces[0] == "wildcard":
    namespace = {}
    exec("from " + PACKAGE + " import *", namespace)
    state["wildcard"] = public_namespace(namespace)
    state["public"] = public_namespace(vars(package))
    assert state["wildcard"] == state["public"]
    assert "__all__" not in vars(package)
    for name in EXPORTS:
        assert namespace[name] is original_class(name)
elif pieces[0] == "all_absent":
    assert "__all__" not in vars(package)
    try:
        package.__all__
    except AttributeError as error:
        assert str(error) == f"module '{PACKAGE}' has no attribute '__all__'"
        state["missing_all_exception"] = [type(error).__name__, str(error)]
    else:
        raise AssertionError("upstream-absent __all__ became present")
    assert "__all__" not in vars(package)
    state["public"] = public_namespace(vars(package))
elif pieces[0] == "caller_global":
    marker = object()
    package.ExportControlMarker = marker
    package.ValueAgent = marker
    assert "ExportControlMarker" in dir(package)
    assert package.ExportControlMarker is marker and package.ValueAgent is marker
    del package.ExportControlMarker
    del package.ValueAgent
    # A deleted eager reexport is absent in the original, so deliberate deletion
    # is not an exact lazy compatibility promise. Inspect caller preservation
    # before cleanup; no reset or fabricated original binding is admitted here.
    state["caller_globals_preserved"] = True
elif pieces[0] == "pickle":
    values = [instance_for(name) for name in LAZY]
    blob = pickle.dumps(values, protocol=4)
    roundtrip = pickle.loads(blob)
    assert encode(values) == encode(roundtrip)
    for name, value in zip(LAZY, roundtrip):
        assert type(value) is original_class(name) is getattr(package, name)
    (OUTPUT / "EXPORT_INSTANCES.pkl").write_bytes(blob)
    state["instances"] = encode(roundtrip)
    state["instance_types_exact"] = True
elif pieces[0] == "pickle_read":
    assert args.pickle_in
    values = pickle.loads(Path(args.pickle_in).read_bytes())
    assert len(values) == len(LAZY)
    for name, value in zip(LAZY, values):
        assert type(value) is original_class(name) is getattr(package, name)
    state["instances"] = encode(values)
    state["instance_types_exact"] = True
else:
    raise ValueError("unknown fresh-process case")

state["global_rng_after"] = encode(np.random.get_state())
assert state["global_rng_after"] == rng_before, "API import/pickle control consumed global RNG"
data = json.dumps(state, sort_keys=True, indent=2).encode() + b"\n"
(OUTPUT / "VALUES.json").write_bytes(data)
(OUTPUT / "WORKER_RECEIPT.json").write_text(json.dumps({"case": args.case, "passed": True,
    "timing_claim": False, "market_run": False, "runtime": str(RUNTIME),
    "loaded_stock_modules_at_cold": loaded_at_cold,
    "loaded_stock_modules_after": [name for name in STOCK_MODULES if name in sys.modules],
    "values_sha256": hashlib.sha256(data).hexdigest(), "loaded_bindings_authenticated": True}, indent=2) + "\n")
print(json.dumps({"case": args.case, "passed": True, "timing_claim": False}))
