# Paired observer and startup Linux screen v1

This is a finite, source-only plan for comparing the passing
`observer_mixed_v2_authcache` server winner with the new
`observer_startup_lazy_v1` composition. The composition retains the parent's
complete 64-file runtime and changes only the vendor agents initializer. The
observer-domain thirteen source pins and all producer implementations must be
byte-identical to the winner. Stage is prohibited until the composition's
fresh export/cold-admission and full observer controls pass under final hashes.

Two images are built once each. The strict v2 host verifier and official
developer gate stay unchanged. Smoke uses S001, AS06 and the original five-sub
hetero batch: six total runs. The main paired screen uses the same original
five units (S001, AS06, MP01, RA01, hetero batch), one warmup and three measured
repeats: 40 runs, of which 30 are timed. Baseline/candidate order alternates for
each adjacent pair. Ten final fresh-process batch-member isolations preserve
the earlier reset/byte/metric guarantees. Total: 56 runs, 46 official verifier
executions / 184 gates; no stress/default scenarios, old canonical or online
arms, full71 evaluation, image publication or competition submission.

The v2 entry probe continues to invoke the actual `runtime/agent.py`, keeping
its import-through-Parquet CLI timer. It leaves authenticated `enabled`,
`abides.run` and observer producer callbacks unchanged. A CLI-local extraction
witness records actual observer activity and four liquidity metric values and
types in ordered per-episode book rosters. The additive probe captures cold
stock-module visibility immediately after entry import; package helper
authentication uses static definitions and never `dir`, wildcard or `__all__`.
After CLI completion, two unchanged observer admissions must preserve the
existing thirteen expected-source cache entries and compile/AST counters.
Cold visibility and post-run admission are diagnostics; post-run admission
overhead belongs to Docker/host time but is outside CLI sidecar time.
Both arms pay that same additional admission proof. This round's host ratios
must be compared within this paired experiment, not combined with the earlier
v2 host ratio, whose probe did not perform these two admissions.

All original reference frames, schemas, event counts and sidecars are checked.
Paired outputs require exact values, dtypes and Parquet bytes. Own-repeat
comparisons use distinct warmup outputs for measured runs; warmup self-pairs
are explicitly counted. Batch isolations compare the exact sub-output bytes
and preserved metrics. Source files, actual loaded module paths/code,
resource settings, ownership, process exit, staged input hashes and cleanup
absence stay checked. Successful outputs remain on the runner until its job
ends; compact artifacts retain their comparison/hash records and all failures.

This screen must report measured composition gain directly. Prior observer or
startup ratios cannot be added or multiplied into a predicted competition
score. `IMPORTTIME_PLAN.md` proposes separate diagnostics only; no diagnostic
entry is implemented in this version.

The inherited v2 generic helpers retain inactive native/online build branches.
The fixed two-arm recipes set native extensions to an empty list and use only
the observer probe. This screen builds no native compiler stage and measures no
online or direct-core arm.
