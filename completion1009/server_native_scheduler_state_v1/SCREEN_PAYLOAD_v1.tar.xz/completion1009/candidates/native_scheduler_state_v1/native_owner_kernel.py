"""Original constructor/initialize retained; cold authority migration afterward."""
from abides_core.kernel import Kernel as OriginalKernel


class NativeOwnerKernel(OriginalKernel):
    def initialize(self):
        if "_chain_migration" in self.__dict__:
            raise ValueError("chain does not reinitialize a live owner")
        super().initialize()
        import dynamic_arena_chain
        from state_mapper import migrate
        migrate(self, dynamic_arena_chain)

    def runner(self, agent_actions=None):
        return self._chain_scheduler.run(agent_actions)

    def send_message(self, sender_id, recipient_id, message, delay=0):
        if "_chain_scheduler" not in self.__dict__:
            return super().send_message(sender_id, recipient_id, message, delay)
        return self._chain_scheduler.send(sender_id, recipient_id, message, delay)

    def set_wakeup(self, sender_id, requested_time=None):
        if "_chain_scheduler" not in self.__dict__:
            return super().set_wakeup(sender_id, requested_time)
        return self._chain_scheduler.set_wakeup(sender_id, requested_time)


def _state_property(name):
    def read(kernel):
        values = kernel.__dict__
        scheduler = values.get("_chain_scheduler")
        if scheduler is not None and scheduler.state_bound():
            return getattr(scheduler.state, name)
        try:
            return values[name]
        except KeyError:
            raise AttributeError(name) from None

    def write(kernel, value):
        values = kernel.__dict__
        scheduler = values.get("_chain_scheduler")
        if scheduler is not None and scheduler.state_bound():
            setattr(scheduler.state, name, value)
        else:
            values[name] = value

    return property(read, write)


# Public Python boundaries and inherited Kernel methods see the same state.
# Initialization keeps the original dictionaries until the cold transfer.
NativeOwnerKernel.agents = _state_property('agents')
NativeOwnerKernel.stop_time = _state_property('stop_time')
NativeOwnerKernel.current_time = _state_property('current_time')
NativeOwnerKernel.ttl_messages = _state_property('ttl_messages')
NativeOwnerKernel.current_agent_additional_delay = _state_property('current_agent_additional_delay')
NativeOwnerKernel.agent_current_times = _state_property('agent_current_times')
NativeOwnerKernel.agent_computation_delays = _state_property('agent_computation_delays')
NativeOwnerKernel._current_causal_uid = _state_property('_current_causal_uid')
NativeOwnerKernel._deliver_seq_by_key = _state_property('_deliver_seq_by_key')
NativeOwnerKernel._deliver_seq = _state_property('_deliver_seq')
NativeOwnerKernel.agent_latency_model = _state_property('agent_latency_model')
NativeOwnerKernel.agent_latency = _state_property('agent_latency')
NativeOwnerKernel.random_state = _state_property('random_state')
NativeOwnerKernel.latency_noise = _state_property('latency_noise')
NativeOwnerKernel.event_queue_wall_clock_start = _state_property('event_queue_wall_clock_start')
