"""Read-only canonical projection and exact Arrow primitive buffer writer.

Domain decline is a value, never an exception catch. The caller chooses both
legacy outputs before writing anything. Once admitted, conversion/IO failures
propagate. No array/table constructor receives Python lists or numpy arrays.
"""
import base64
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from contracts import TRACE_TYPES, MESSAGE_TYPES, EVENT_TYPES

_INTEGER_TYPES = (int, np.int64, np.int32)
_MESSAGE_SOURCE = {"message_id": 0, "src_id": 1, "dst_id": 2, "t_send_ns": 3,
                   "t_recv_ns": 4, "latency_ns": 5, "msg_type": 6, "order_id": 7,
                   "causal_parent": 8}
_SCHEMA_CACHE = None


class Declined:
    def __init__(self, reason):
        self.reason = reason


class Columns:
    def __init__(self, kind, values):
        self.kind = kind
        self.values = values
        self.contract = TRACE_TYPES if kind == "trace" else MESSAGE_TYPES
        self.n_rows = len(values[next(iter(self.contract))])


def _exact_order_integer(value):
    actual = type(value)
    return (actual is int or actual is np.int64 or actual is np.int32) and -(1 << 53) <= value <= (1 << 53)


def _integer(value, dtype):
    actual = type(value)
    if actual is not int and actual is not np.int64 and actual is not np.int32:
        return False
    bits = 32 if dtype == "int32" else 64
    return -(1 << (bits - 1)) <= value < (1 << (bits - 1))


def _trusted_dict(mapping):
    return type(mapping) is dict and all(type(key) is str for key in mapping)


def _type_is(actual, expected):
    for item in expected:
        if actual is item:
            return True
    return False


def project_trace(end_state, episode, side_type, side_to_str, owner_engine=None):
    # Only authenticated built-in containers are inspected. No iterators, custom
    # mappings or user callbacks are consumed merely to try an optimization.
    import observer
    from abides_fork.agents import AGENT_REGISTRY
    from abides_markets.agents.exchange_agent import ExchangeAgent
    from abides_markets.orders import Side
    from abides_fork.trace import _side_to_str
    if side_type is not Side or side_to_str is not _side_to_str:
        return Declined("untrusted-side-type-or-callback")
    if type(episode) is not observer.Episode or not _trusted_dict(end_state) or type(end_state.get("agents")) is not list:
        return Declined("inactive-or-untrusted-trace-state")
    if type(episode.contract) is not dict or type(episode.has_scalar) is not bool:
        return Declined("untrusted-contract-container")
    trusted_agents = (ExchangeAgent, *AGENT_REGISTRY.values())
    if owner_engine is None:
        if any(not _type_is(type(agent), trusted_agents) for agent in end_state["agents"]):
            return Declined("untrusted-agent-type")
        if any(not _type_is(type(agent), trusted_agents) for agent in episode.contract):
            return Declined("untrusted-contract-agent-key")
    else:
        from composite_boundary import exact_dynamic_engine
        if not exact_dynamic_engine(owner_engine):
            return Declined("untrusted-native-engine-provenance")
        roster = end_state["agents"]
        owner_ids = {id(agent) for agent in roster}
        if (not roster or type(roster[0]) is not owner_engine.NativeExchange
                or any(type(agent) is not owner_engine.NativeTrader for agent in roster[1:])
                or len({id(agent) for agent in roster}) != len(roster)
                or any(id(agent) not in owner_ids for agent in episode.contract)):
            return Declined("untrusted-native-owner-roster")
        for index, agent in enumerate(roster):
            if not agent.authority_bound() or type(agent.id) is not int or agent.id != index:
                return Declined("unbound-or-nondense-native-owner")
            source = agent.source_identity()
            expected = ExchangeAgent if index == 0 else agent.origin_class()
            if (not _type_is(expected, trusted_agents) or type(source) is not expected
                    or vars(source) != {"_native_moved_to": id(agent)}):
                return Declined("untrusted-native-origin-or-retirement")
        packed = owner_engine.cold_trace_buffers(end_state, episode)
        if type(packed) is str:
            return Declined(packed)
        if type(packed) is not owner_engine.NativeColumns or not packed.sealed():
            raise ValueError("actual native trace projection produced unsealed columns")
        return packed
    events, quotes, final_exec = [], {}, {}
    for agent in end_state["agents"]:
        records = episode.contract.get(agent, ())
        if not _type_is(type(records), (list, tuple)):
            return Declined("untrusted-contract-records")
        for record in records:
            if type(record) is not tuple or len(record) != 4:
                return Declined("untrusted-contract-record")
            timestamp, event_type, kind, data = record
            if type(event_type) is not str or type(kind) is not str or type(data) is not tuple:
                return Declined("untrusted-contract-fields")
            if _type_is(type(timestamp), (int, bool, np.int64)):
                if not -(1 << 63) <= timestamp < (1 << 63):
                    return Declined("timestamp-range")
            elif _type_is(type(timestamp), (float, np.int32, type(None), str)):
                timestamp = 0
            else:
                return Declined("untrusted-timestamp-type")
            if kind == "raw":
                return Declined("legacy-raw-record")
            if kind in ("order", "market"):
                if len(data) != 6:
                    return Declined("order-shape")
                aid, oid, side, quantity, limit_price, fill_price = data
                if oid is None:
                    continue
                if aid is None:
                    aid = agent.id
                price = fill_price if event_type == "ORDER_EXECUTED" else limit_price
                if (not _exact_order_integer(oid) or not _exact_order_integer(aid)
                        or not _integer(aid, "int32") or not _exact_order_integer(quantity)
                        or (price is not None and not _exact_order_integer(price))
                        or not _type_is(type(side), (Side, str, type(None)))):
                    return Declined("legacy-order-inference")
                row = [int(timestamp), int(aid), event_type, side_to_str(side),
                       0 if price is None else int(price), int(quantity), int(oid)]
                events.append(row)
                if event_type == "ORDER_EXECUTED":
                    # Stable timestamp sorting chooses the greatest timestamp,
                    # and the last original encounter on an equal timestamp.
                    # Track that exact winner without sorting every event first.
                    row[2] = "PARTIAL_FILL"
                    previous = final_exec.get(row[6])
                    if previous is None or previous[0] <= row[0]:
                        final_exec[row[6]] = row
            elif kind == "quote":
                if len(data) != 3:
                    return Declined("quote-shape")
                symbol, price, quantity = data
                if (type(symbol) is not str or "," in symbol or not _exact_order_integer(price)
                        or not _exact_order_integer(quantity) or not _exact_order_integer(agent.id)
                        or not _integer(agent.id, "int32")):
                    return Declined("legacy-quote-inference")
                side = "BID" if event_type == "BEST_BID" else "ASK"
                timestamp = int(timestamp)
                quotes[(timestamp, side)] = [timestamp, int(agent.id), "QUOTE_UPDATE", side,
                                             int(price), int(quantity), -1]
            else:
                return Declined("unknown-contract-kind")
    if not events or not episode.has_scalar:
        return Declined("legacy-empty-or-scalar-inference")
    # Only new rows are changed. The final stable (time, order_id) sort has the
    # same ties as timestamp sort followed by that sort: original encounter.
    # Quotes are still extended after all orders, preserving the -1 tie case.
    for row in final_exec.values():
        row[2] = "ORDER_FILLED"
    events.extend(quotes.values())
    events.sort(key=lambda row: (row[0], row[6]))
    return Columns("trace", {name: [row[i] for row in events] for i, name in enumerate(TRACE_TYPES)})


def project_messages(end_state, ledger_type):
    if not _trusted_dict(end_state):
        return Declined("legacy-ledger-type")
    from t3_canonical_engine import ColumnLedger
    if ledger_type is not ColumnLedger:
        from composite_boundary import exact_dynamic_engine
        engine = sys.modules.get("dynamic_arena_chain")
        if not exact_dynamic_engine(engine) or ledger_type is not engine.ColumnLedger:
            return Declined("untrusted-ledger-owner-type")
        packed = engine.cold_message_buffers(end_state, ledger_type)
        if type(packed) is str:
            return Declined(packed)
        if type(packed) is not engine.NativeColumns or not packed.sealed():
            raise ValueError("actual native message projection produced unsealed columns")
        return packed
    if not _trusted_dict(end_state) or type(end_state.get("message_ledger")) is not ledger_type:
        return Declined("legacy-ledger-type")
    ledger = end_state["message_ledger"]
    source = ledger.columns
    seqmap = end_state.get("deliver_seq_by_key")
    if type(source) is not tuple or len(source) != 9 or any(type(c) is not list for c in source) or type(seqmap) is not dict:
        return Declined("untrusted-ledger-containers")
    if len({id(column) for column in source}) != 9:
        return Declined("aliased-ledger-columns")
    # Inspect exact builtin tuple/scalar keys before lookup. A custom key whose
    # hash collides must never receive __eq__ during read-only admission.
    for key, value in seqmap.items():
        if (type(key) is not tuple or len(key) != 2 or type(key[0]) is not int
                or type(key[1]) is not int or type(value) is not int):
            return Declined("untrusted-delivery-map-key-or-value")
    n = len(source[0])
    if any(len(c) != n for c in source):
        return Declined("ledger-column-lengths")
    rows = []
    for index in range(n):
        mid, dst = source[0][index], source[2][index]
        if not _integer(mid, "int64") or not _integer(dst, "int32"):
            return Declined("legacy-ledger-key-inference")
        seq = seqmap.get((int(mid), int(dst)))
        if seq is not None:
            if not _integer(seq, "int64"):
                return Declined("legacy-sequence-inference")
            rows.append((seq, index))
    rows.sort(key=lambda row: row[0])
    values = {}
    for name, dtype in MESSAGE_TYPES.items():
        column = [seq for seq, _ in rows] if name == "seq" else [source[_MESSAGE_SOURCE[name]][i] for _, i in rows]
        # Both key columns were admitted across the complete ledger above;
        # selected rows cannot add a new scalar. Sequence was range checked.
        for value in (() if name in ("message_id", "dst_id", "seq") else column):
            if dtype == "string":
                if not _type_is(type(value), (str, type(None))):
                    return Declined("legacy-message-string-inference")
            elif value is None and dtype == "Int64":
                continue
            elif not _integer(value, dtype):
                return Declined("legacy-message-integer-inference")
        values[name] = column
    return Columns("message_trace", values)


def validate_columns(trace, messages):
    for kind, columns, contract in (("trace", trace, TRACE_TYPES), ("message_trace", messages, MESSAGE_TYPES)):
        if type(columns) is not Columns or columns.kind != kind or list(columns.values) != list(contract):
            raise ValueError(kind + " exact column roster differs")
        if columns.n_rows == 0:
            raise ValueError(kind + " must demonstrate actual simulation events")
        for name, dtype in contract.items():
            values = columns.values[name]
            if type(values) is not list or len(values) != columns.n_rows:
                raise ValueError(kind + " column lengths differ")
            for value in values:
                if dtype == "string":
                    valid = _type_is(type(value), (str, type(None)))
                else:
                    valid = value is None and dtype == "Int64" or _integer(value, dtype)
                if not valid:
                    raise ValueError(kind + " admitted type/range violation: " + name)
    if not set(trace.values["msg_type"]).issubset(EVENT_TYPES):
        raise ValueError("unknown canonical event type")
    if any(value is not None and value not in ("BID", "ASK") for value in trace.values["side"]):
        raise ValueError("unknown side encoding")


def validate_admitted_columns(trace, messages):
    """Production check immediately after the authenticated projectors.

    Their source already admits every scalar and allocates all output storage.
    No callback or external mutation runs between projection and this check.
    Keep the public full validator above for independently constructed columns.
    """
    from composite_boundary import exact_dynamic_engine
    engine = sys.modules.get("dynamic_arena_chain")
    native_trace = exact_dynamic_engine(engine) and type(trace) is engine.NativeColumns
    native_messages = exact_dynamic_engine(engine) and type(messages) is engine.NativeColumns
    if native_trace or native_messages:
        if not native_trace or not native_messages:
            raise ValueError("native primitive trace/message pair must be complete")
        for kind, columns, contract in (("trace", trace, TRACE_TYPES), ("message_trace", messages, MESSAGE_TYPES)):
            if not columns.sealed() or columns.kind != kind or columns.n_rows == 0 or len(columns.fields) != len(contract):
                raise ValueError("exact sealed native output roster differs")
            for descriptor, dtype in zip(columns.fields, contract.values()):
                if type(descriptor) is not tuple or len(descriptor) != 5 or descriptor[0] != dtype:
                    raise ValueError("exact native primitive descriptor differs")
                actual_dtype, validity, offsets, payload, nulls = descriptor
                if type(payload) is not bytes or type(nulls) is not int or not 0 <= nulls <= columns.n_rows:
                    raise ValueError("native immutable payload/null count differs")
                if (validity is None) != (nulls == 0) or (validity is not None and (type(validity) is not bytes or len(validity) != (columns.n_rows + 7) // 8)):
                    raise ValueError("native exact validity buffer differs")
                if dtype == "string":
                    if type(offsets) is not bytes or len(offsets) != (columns.n_rows + 1) * 4:
                        raise ValueError("native exact UTF8 offset buffer differs")
                elif offsets is not None or len(payload) != columns.n_rows * (4 if dtype == "int32" else 8):
                    raise ValueError("native exact numeric buffer differs")
        return
    for kind, columns, contract in (("trace", trace, TRACE_TYPES), ("message_trace", messages, MESSAGE_TYPES)):
        if type(columns) is not Columns or columns.kind != kind or list(columns.values) != list(contract):
            raise ValueError(kind + " exact column roster differs")
        if columns.n_rows == 0:
            raise ValueError(kind + " must demonstrate actual simulation events")
        if any(type(values) is not list or len(values) != columns.n_rows for values in columns.values.values()):
            raise ValueError(kind + " column lengths differ")
    if not set(trace.values["msg_type"]).issubset(EVENT_TYPES):
        raise ValueError("unknown canonical event type")
    if any(value is not None and value not in ("BID", "ASK") for value in trace.values["side"]):
        raise ValueError("unknown side encoding")


def _metadata(items):
    return {base64.b64decode(row["key_b64"], validate=True): base64.b64decode(row["value_b64"], validate=True) for row in items} or None


def _schemas(pa):
    global _SCHEMA_CACHE
    if _SCHEMA_CACHE is not None:
        return _SCHEMA_CACHE
    metadata_path = Path(__file__).with_name("schema_metadata_v1.json")
    from schema_metadata_pin_v1 import SCHEMA_METADATA_SHA256
    data = metadata_path.read_bytes()
    if hashlib.sha256(data).hexdigest() != SCHEMA_METADATA_SHA256:
        raise ValueError("deployed metadata differs from exact build pin")
    source = json.loads(data)
    if (source["schema"] != "t3-pandas-free-schema-metadata-v1" or source["numpy_version"] != "1.26.4"
            or source["pandas_version"] != "1.5.3" or source["pyarrow_version"] != "15.0.2"
            or pa.__version__ != "15.0.2" or np.__version__ != "1.26.4"):
        raise ValueError("pinned build schema/dependency versions differ")
    physical = {"int64": pa.int64(), "Int64": pa.int64(), "int32": pa.int32(), "string": pa.string()}
    schemas = {}
    for kind, contract in (("trace", TRACE_TYPES), ("message_trace", MESSAGE_TYPES)):
        definition = source["tables"][kind]
        roster = definition["columns"]
        if [(row["name"], row["pandas_dtype"]) for row in roster] != list(contract.items()):
            raise ValueError("build schema logical roster differs")
        fields = []
        for row in roster:
            arrow_type = physical[row["pandas_dtype"]]
            if row["arrow_type"] != str(arrow_type) or type(row["nullable"]) is not bool:
                raise ValueError("build schema physical type differs")
            fields.append(pa.field(row["name"], arrow_type, nullable=row["nullable"], metadata=_metadata(row["field_metadata"])))
        schema = pa.schema(fields, metadata=_metadata(definition["schema_metadata"]))
        serialized = schema.serialize().to_pybytes()
        if (base64.b64encode(serialized).decode("ascii") != definition["schema_serialized_b64"]
                or hashlib.sha256(serialized).hexdigest() != definition["schema_serialized_sha256"]):
            raise ValueError("exact built schema serialization differs")
        schemas[kind] = schema
    _SCHEMA_CACHE = schemas
    return schemas


def _array(pa, field, dtype, values):
    n = len(values)
    null_count, validity = 0, None
    if dtype == "string":
        offsets = [0] * (n + 1)
        data = bytearray()
        bitmap = bytearray((n + 7) // 8)
        encodings = {}
        for i, value in enumerate(values):
            if value is None:
                null_count += 1
            else:
                bitmap[i >> 3] |= 1 << (i & 7)
                encoded = encodings.get(value)
                if encoded is None:
                    encoded = value.encode("utf8")
                    # Actual message/event/side columns repeat a small vocabulary.
                    # Bound the cache for legitimate general string columns.
                    if len(encodings) < 256:
                        encodings[value] = encoded
                data.extend(encoded)
            offsets[i + 1] = len(data)
        if offsets[-1] >= (1 << 31):
            raise OverflowError("canonical UTF8 offsets exceed Arrow string range")
        if null_count:
            validity = pa.py_buffer(bitmap)
        offset_array = np.asarray(offsets, dtype="<i4")
        buffers = [validity, pa.py_buffer(offset_array), pa.py_buffer(data)]
    else:
        # Projection admits exact fixed-width integers before reaching this
        # internal writer. NumPy's list conversion packs them in C, without the
        # Python fromiter generator or any Arrow pandas-array probe.
        packed = values
        if dtype == "Int64":
            bitmap = bytearray((n + 7) // 8)
            packed = [0] * n
            for i, value in enumerate(values):
                if value is None:
                    null_count += 1
                else:
                    bitmap[i >> 3] |= 1 << (i & 7)
                    packed[i] = value
            if null_count:
                validity = pa.py_buffer(bitmap)
        numbers = np.asarray(packed, dtype="<i4" if dtype == "int32" else "<i8")
        buffers = [validity, pa.py_buffer(numbers)]
    result = pa.Array.from_buffers(field.type, n, buffers, null_count=null_count, offset=0)
    # Offsets, signed range and UTF8 validity are established above/by admission.
    # Array owns each supplied buffer; the table keeps the array alive through IO.
    return result


def write_outputs(trace, messages, trace_path):
    import pyarrow as pa
    import pyarrow.parquet as pq
    schemas = _schemas(pa)
    trace_path = Path(trace_path)
    trace_path.parent.mkdir(parents=True, exist_ok=True)
    for columns, path in ((trace, trace_path), (messages, trace_path.parent / "message_trace.parquet")):
        schema = schemas[columns.kind]
        if type(columns) is Columns:
            arrays = [_array(pa, field, columns.contract[field.name], columns.values[field.name]) for field in schema]
        else:
            arrays = []
            for field, descriptor in zip(schema, columns.fields):
                dtype, validity, offsets, data, null_count = descriptor
                buffers = [None if validity is None else pa.py_buffer(validity)]
                if offsets is not None: buffers.append(pa.py_buffer(offsets))
                buffers.append(pa.py_buffer(data))
                arrays.append(pa.Array.from_buffers(field.type, columns.n_rows, buffers, null_count=null_count, offset=0))
        table = pa.Table.from_arrays(arrays, schema=schema)
        if table.num_rows != columns.n_rows or not table.schema.equals(schema, check_metadata=True):
            raise ValueError("admitted actual Arrow table differs")
        # Match pandas1.5.3/PyArrow15 baseline defaults and actual writer.
        pq.write_table(table, path, compression="snappy")


def import_witness():
    names = sorted(name for name in sys.modules if name == "pandas" or name.startswith("pandas."))
    scipy_names = sorted(name for name in sys.modules if name == "scipy" or name.startswith("scipy."))
    unused_stock = ("abides_markets.agents.examples.momentum_agent",
                    "abides_markets.agents.market_makers.adaptive_market_maker_agent",
                    "abides_markets.agents.noise_agent", "abides_markets.agents.value_agent")
    return {"pandas_loaded": bool(names), "pandas_modules": names,
            "scipy_loaded": bool(scipy_names), "scipy_modules": scipy_names,
            "unused_stock_modules_loaded": [name for name in unused_stock if name in sys.modules],
            "stock_cli_loaded": "abides_fork.simulate" in sys.modules}
