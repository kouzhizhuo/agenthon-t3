"""Select an exact scalar latency algorithm once for the closed original model.

The model, its RandomState, and every draw remain the original objects. Unknown
classes, callbacks, field types or distribution parameters use their own method.
"""
from math import isfinite
from types import MethodType
import numpy as np
import abides_fork.config as config_module
from abides_fork.config import ScenarioLatencyModel

ORIGINAL_GET_LATENCY = ScenarioLatencyModel.get_latency


def scalar_latency(self, sender_id, recipient_id):
    if sender_id == recipient_id:
        return 0
    if self._model == "log_normal":
        value = self.random_state.lognormal(mean=self._mu, sigma=self._sigma)
    elif self._model == "uniform":
        value = self.random_state.uniform(self._min_ns, self._max_ns)
    elif self._model == "pareto":
        base = self._min_ns if self._min_ns > 0 else 1.0
        value = base * (1.0 + self.random_state.pareto(self._alpha))
    else:
        value = self._mean_ns
    # Exact scalar clip followed by the original Python float/round/int sequence.
    # A stochastic constant distribution still makes its original random draw.
    if value < self._min_ns:
        value = self._min_ns
    if value > self._max_ns:
        value = self._max_ns
    return int(round(float(value)))


def select_latency(model):
    """Choose before the first event; do not mutate the original model or class."""
    original = model.get_latency
    if (type(model) is not ScenarioLatencyModel
            or ScenarioLatencyModel.get_latency is not ORIGINAL_GET_LATENCY
            or getattr(original, '__func__', None) is not ORIGINAL_GET_LATENCY
            or getattr(original, '__self__', None) is not model
            or type(model.random_state) is not np.random.RandomState
            or type(model._model) is not str):
        return original
    # Authenticate constructor/method bytecode, defaults and owning globals
    # against fresh pinned original source before choosing its scalar variant.
    from observer_domain import _code_at, _defaults_match
    images = {}
    if config_module.np is not np:
        return original
    for name in ('__init__', 'get_latency'):
        function = getattr(ScenarioLatencyModel, name)
        if (function.__code__ != _code_at(config_module, 'ScenarioLatencyModel', name, images)
                or function.__globals__ is not vars(config_module)
                or not _defaults_match(function, config_module, 'ScenarioLatencyModel', name, images)):
            return original
    fields = (model._mean_ns, model._sigma, model._min_ns,
              model._max_ns, model._alpha, model._mu)
    if any(type(value) is not float or not isfinite(value) for value in fields):
        return original
    if (model._min_ns > model._max_ns
            or (model._model == 'log_normal' and model._sigma < 0)
            or (model._model == 'pareto' and model._alpha <= 0)):
        return original
    return MethodType(scalar_latency, model)
