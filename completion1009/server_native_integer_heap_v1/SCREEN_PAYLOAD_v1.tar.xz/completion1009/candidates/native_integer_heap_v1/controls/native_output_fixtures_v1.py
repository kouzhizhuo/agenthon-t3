"""Future two-process exact original/native cold-output controller."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-runtime", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists(): raise ValueError("fresh native fixture result required")
    args.out.mkdir(parents=True)
    worker = Path(__file__).with_name("native_output_fixture_worker_v1.py")
    report = {"schema": "t3-cold-native-projection-buffer-fixture-controller-v1", "all_passed": False,
        "source_only": False, "market_executed": False, "rankable": False, "speed_claim": False}
    try:
        receipts = {}
        for arm, runtime in (("original", args.baseline_runtime), ("native", args.runtime)):
            command = [sys.executable, "-B", str(worker), "--arm", arm, "--runtime", str(runtime), "--out", str(args.out / arm)]
            if arm == "native": command += ["--build", str(args.build)]
            with (args.out / (arm + ".log")).open("xb") as log:
                child = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if child.returncode: raise RuntimeError("actual cold native fixture child failed: " + arm)
            receipts[arm] = json.loads((args.out / arm / "FIXTURE_RECEIPT.json").read_bytes())
        if receipts["native"]["cases"] != receipts["original"]["cases"]: raise AssertionError("cold fixture independent explicit expected values differ")
        original_files = receipts["original"]["files"]
        native_files = {row["path"]: row for row in receipts["native"]["files"]}
        for row in original_files:
            if native_files[row["path"]] != row: raise AssertionError("exact native fixture Parquet bytes/hash differ: " + row["path"])
        # Readback starts only after the cold native child has exited.
        import pandas as pd
        for row in original_files:
            original = pd.read_parquet(args.out / "original" / row["path"])
            native = pd.read_parquet(args.out / "native" / row["path"])
            pd.testing.assert_frame_equal(original, native, check_dtype=True, check_exact=True)
        report.update(all_passed=True, children=receipts, actual_parquet_bytes_equal=True,
            actual_independent_pandas_readback_equal=True, worker_sha256=hashlib.sha256(worker.read_bytes()).hexdigest())
    except BaseException as error:
        report["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (args.out / "NATIVE_OUTPUT_FIXTURES.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__": main()
