"""Freeze reviewed source and PASS receipts; this command does not run experiments."""
import argparse
import io
import json
from pathlib import Path
import shutil
import tarfile
from common import BASE, MAX_BYTES, MAX_FILES, SMOKE, STRESS, UNITS, get_field, inventory, safe_name, sha, write

HERE = Path(__file__).resolve().parent
COMPLETION = HERE.parent
MODULES = {
    "abides_core.agent": "vendor/abides/abides-core/abides_core/agent.py",
    "abides_core.kernel": "vendor/abides/abides-core/abides_core/kernel.py",
    "abides_core.abides": "vendor/abides/abides-core/abides_core/abides.py",
    "abides_core.message": "vendor/abides/abides-core/abides_core/message.py",
    "abides_fork.agents": "abides_fork/agents.py", "abides_fork.config": "abides_fork/config.py",
    "abides_fork.trace": "abides_fork/trace.py", "abides_fork.simulate": "abides_fork/simulate.py",
    "abides_markets.agents.exchange_agent": "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py",
    "abides_markets.agents.trading_agent": "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py",
    "abides_markets.orders": "vendor/abides/abides-markets/abides_markets/orders.py",
    "abides_markets.order_book": "vendor/abides/abides-markets/abides_markets/order_book.py",
    "abides_markets.price_level": "vendor/abides/abides-markets/abides_markets/price_level.py",
    "optimizations": "optimizations.py", "t3_canonical_engine": "t3_canonical_engine.py",
    "column_trace": "column_trace.py", "contracts": "contracts.py"}


def standard_recipes():
    return [
        {"name": "canonical", "root": str(COMPLETION), "runtime": "runtime", "entrypoint": "runtime/agent.py",
         "runtime_manifest": "RUNTIME_MANIFEST.json", "manifest_paths_have_runtime": True,
         "receipts": [], "extra_files": [], "native": [], "extra_modules": {}},
        {"name": "mixed_static_v2", "root": str(COMPLETION / "candidates/mixed_static_v2"), "runtime": "runtime",
         "entrypoint": "runtime/agent.py", "runtime_manifest": "SNAPSHOT_MANIFEST.json", "extra_files": [], "native": [], "extra_modules": {},
         "receipts": [{"path": "CONTROLS_RESULT.json", "pass_field": "all_passed"},
                      {"path": str(COMPLETION / "verification/mixed_static_semantic_v2/RESULT.json"), "pass_field": "all_passed"}]},
        {"name": "closed_book_store_v1", "root": str(COMPLETION / "candidates/closed_book_store_v1"), "runtime": "runtime",
         "entrypoint": "runtime/agent.py", "runtime_manifest": "SNAPSHOT_MANIFEST.json", "extra_files": ["store.pyx"],
         "extra_modules": {"closed_book_runtime": "runtime/closed_book_runtime.py"},
         "native": [{"module": "closed_book_store", "source": "store.pyx", "install_dir": "runtime"}],
         "receipts": [{"path": "CORRECTNESS_EVIDENCE.json", "pass_field": "all_passed"}]},
        {"name": "direct_state_engine_v2", "root": str(COMPLETION / "candidates/direct_state_engine_v2"), "runtime": "runtime",
         "entrypoint": "static_cli.py", "runtime_manifest": "PINNED_RUNTIME.json", "tested_source_manifest": "TESTED_SOURCE_MANIFEST.json",
         "extra_files": ["audit.py", "cli.py", "control_worker.py", "controls.py", "engine.py", "finite_controls.py", "installed.py", "preflight.py", "prepare.py", "static_cli.py", "PINNED_RUNTIME.json"],
         "native": [], "extra_modules": {"engine": "engine.py", "audit": "audit.py", "installed": "installed.py"},
         "preflight": "preflight.py", "generated_files": ["STATIC_BINDING_PINS.json"], "no_run_patch": True,
         "host_only_sources": ["control_worker.py", "controls.py", "finite_controls.py", "prepare.py"],
         "expected_kernel": "engine:DirectKernel", "active_probe": "installed:active_probe",
         "probe_equals": {"candidate": "direct_state_engine_v2", "direct_active": True, "fallback_used": False},
         "receipts": [{"path": str(COMPLETION / "verification/direct_state_engine_v2_controls_v2/RESULT.json"), "pass_field": "all_passed"},
                      {"path": str(COMPLETION / "verification/direct_state_engine_v2_controls_v2/FINITE_RESULT.json"), "pass_field": "all_passed"}]},
        {"name": "streaming_observer_v1", "root": str(COMPLETION / "candidates/streaming_observer_v1"), "runtime": "runtime",
         "entrypoint": "runtime/agent.py", "runtime_manifest": "SNAPSHOT_MANIFEST.json", "extra_files": [], "native": [],
         "extra_modules": {"observer": "runtime/observer.py", "observer_domain": "runtime/observer_domain.py"},
         "observer_probe": True,
         "binding_aliases": {"abides_fork.trace:extract_trace#0": "abides_fork.trace:_extract_trace_observer_original", "abides_fork.trace:extract_trace#1": "abides_fork.trace:extract_trace"},
         "receipts": [{"path": "CORRECTNESS_EVIDENCE.json", "pass_field": "status", "pass_equals": "passed_untimed_finite_and_four_market_controls"}]},
    ]


def copy_source(source, target):
    if source.is_symlink() or not source.is_file():
        raise ValueError("ordinary source file required: " + str(source))
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def freeze_arm(recipe, destination):
    root = Path(recipe["root"]).resolve()
    runtime_relative = safe_name(recipe["runtime"])
    runtime = root / runtime_relative
    if not recipe.get("receipts") and recipe["name"] != "canonical":
        raise ValueError("candidate lacks final PASS receipts: " + recipe["name"])
    receipt_rows = []
    for index, item in enumerate(recipe["receipts"]):
        path = Path(item["path"])
        if not path.is_absolute():
            path = root / path
        data = json.loads(path.read_text())
        if get_field(data, item["pass_field"]) != item.get("pass_equals", True):
            raise ValueError("candidate PASS receipt is missing/false: " + str(path))
        relative = "receipts/%02d-%s" % (index, path.name)
        copy_source(path, destination / relative)
        receipt_rows.append({"source_path": str(path), "path": relative, "sha256": sha(path), "pass_field": item["pass_field"]})
        # Follow exact recorded receipts; never treat a stale summary as evidence.
        for recorded, digest in data.get("receipts", {}).items():
            bound = Path(recorded)
            if not bound.is_file() or sha(bound) != digest:
                raise ValueError("nested semantic receipt changed: " + recorded)
            follow = json.loads(bound.read_text())
            if follow.get("all_passed") is not True:
                raise ValueError("nested semantic receipt is not PASS")
            nested = "receipts/%02d-nested-%s-%s" % (index, digest[:12], bound.name)
            copy_source(bound, destination / nested)
        if "result_path" in data:
            bound = Path(data["result_path"])
            if sha(bound) != data["result_sha256"] or json.loads(bound.read_text()).get("all_passed") is not True:
                raise ValueError("exact recorded semantic result differs/is not PASS")
            copy_source(bound, destination / ("receipts/%02d-final-RESULT.json" % index))
    snapshot = json.loads((root / recipe["runtime_manifest"]).read_text())
    expected = {}
    for row in snapshot.get("files", snapshot.get("runtime_files", [])):
        relative = safe_name(row["path"])
        if recipe.get("manifest_paths_have_runtime"):
            relative = Path(relative).relative_to(runtime_relative).as_posix()
        expected[relative] = row["sha256"]
    actual = {name: row["sha256"] for name, row in inventory(runtime).items()
              if not name.endswith((".so", ".pyd", ".pyc"))}
    if actual != expected:
        raise ValueError("complete candidate runtime differs from final manifest: " + recipe["name"])
    for name in expected:
        copy_source(runtime / name, destination / runtime_relative / name)
    for name in recipe.get("extra_files", []):
        copy_source(root / safe_name(name), destination / safe_name(name))
    if recipe.get("tested_source_manifest"):
        tested_path = root / recipe["tested_source_manifest"]
        tested = json.loads(tested_path.read_text())
        for row in tested["source_files"]:
            path = destination / row["path"]
            if not path.is_file() or sha(path) != row["sha256"] or path.stat().st_size != row["bytes"]:
                raise ValueError("tested candidate top-level source differs: " + row["path"])
        if sha(root / recipe["runtime_manifest"]) != tested["runtime_pin_sha256"]:
            raise ValueError("tested runtime manifest differs")
        copy_source(tested_path, destination / "receipts/TESTED_SOURCE_MANIFEST.json")
        foreign = root / "STATIC_BINDING_PINS.json"
        if sha(foreign) != tested["static_binding_pins_sha256"]:
            raise ValueError("preserved foreign interpreter binding evidence differs")
        copy_source(foreign, destination / "receipts/FOREIGN_STATIC_BINDING_PINS.json")
        if sha(Path(recipe["receipts"][0]["path"])) != tested["control_result_sha256"] or sha(Path(recipe["receipts"][1]["path"])) != tested["finite_result_sha256"]:
            raise ValueError("tested direct PASS receipt differs")
    copy_source(root / recipe["runtime_manifest"], destination / "receipts/RUNTIME_INPUT_MANIFEST.json")
    entrypoint = safe_name(recipe["entrypoint"])
    if not (destination / entrypoint).is_file():
        raise ValueError("final entrypoint has not been staged")
    sources = inventory(destination)
    sources = {name: row for name, row in sources.items() if not name.startswith("receipts/")}
    # Bind source hashes published by the finite control receipts when available.
    for item in recipe["receipts"]:
        path = Path(item["path"])
        path = path if path.is_absolute() else root / path
        data = json.loads(path.read_text())
        for name, digest in data.get("candidate_runtime_sha256", {}).items():
            if name.endswith((".so", ".pyd", ".pyc")):
                continue
            staged = destination / runtime_relative / name
            if not staged.is_file() or sha(staged) != digest:
                raise ValueError("finite runtime binding differs: " + name)
        # runtime_sha256 in finite mixed receipts describes its original
        # comparison arm. Only final observer evidence binds candidate here.
        for name, digest in (data.get("runtime_sha256", {}) if data.get("snapshot_manifest_sha256") else {}).items():
            staged = destination / runtime_relative / name
            if not staged.is_file() or sha(staged) != digest:
                raise ValueError("final runtime receipt binding differs: " + name)
        if data.get("snapshot_manifest_sha256") and sha(root / recipe["runtime_manifest"]) != data["snapshot_manifest_sha256"]:
            raise ValueError("final snapshot receipt differs")
        for name, digest in data.get("candidate_source_sha256", {}).items():
            if sha(root / name) != digest:
                raise ValueError("final candidate helper/control source differs: " + name)
        for name, digest in data.get("source", {}).items():
            staged = destination / name
            if staged.is_file() and sha(staged) != digest:
                raise ValueError("semantic source binding differs: " + name)
        for key, prefix in (("sources", ""), ("runtime", runtime_relative + "/")):
            for name, digest in data.get("bindings", {}).get(key, {}).items():
                staged = destination / (prefix + name)
                if staged.is_file() and sha(staged) != digest:
                    raise ValueError("source-closed control binding differs: " + name)
    native = []
    for item in recipe.get("native", []):
        source = safe_name(item["source"])
        native.append({**item, "source": source, "sha256": sha(destination / source)})
    excluded = set(recipe.get("host_only_sources", [])) | {item["source"] for item in native}
    participant = {name: row for name, row in sources.items() if name not in excluded}
    spec = {"schema": "t3-screen-arm-v1", "name": recipe["name"], "runtime": runtime_relative,
        "entrypoint": entrypoint, "source_inventory": sources, "mode": "optimized", "native": native,
        "participant_inventory": participant, "host_only_source_files": recipe.get("host_only_sources", []),
        "dependency_versions": {"numpy": "1.26.4", "pandas": "1.5.3", "pyarrow": "15.0.2"},
        "modules": {**{name: runtime_relative + "/" + path for name, path in MODULES.items()},
                    "@entry": entrypoint, **recipe.get("extra_modules", {})},
        "expected_kernel": recipe.get("expected_kernel", "t3_canonical_engine:CanonicalKernel"),
        "expected_latency": recipe.get("expected_latency", "optimizations:scalar_latency"),
        "active_probe": recipe.get("active_probe"), "probe_equals": recipe.get("probe_equals", {}),
        "no_run_patch": recipe.get("no_run_patch", False), "preflight": recipe.get("preflight"),
        "generated_files": recipe.get("generated_files", []),
        "binding_aliases": recipe.get("binding_aliases", {}),
        "observer_probe": recipe.get("observer_probe", False),
        "receipts": receipt_rows}
    write(destination / "ARM.json", spec)
    return spec


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True, help="new staging directory")
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--recipes", type=Path, help="explicit complete JSON recipe list; unready candidates must be omitted")
    parser.add_argument("--arms", nargs="+", help="explicit chosen names; canonical must be first")
    args = parser.parse_args()
    if args.out.exists() or args.archive.exists():
        raise ValueError("new staging and archive paths required")
    recipes = json.loads(args.recipes.read_text()) if args.recipes else standard_recipes()
    if args.arms:
        mapping = {row["name"]: row for row in recipes}
        recipes = [mapping[name] for name in args.arms]
    names = [item["name"] for item in recipes]
    if not names or names[0] != "canonical" or len(set(names)) != len(names) or any(safe_name(n) != n or "/" in n for n in names):
        raise ValueError("canonical first plus unique simple arm names required")
    args.out.mkdir(parents=True)
    arms = [freeze_arm(item, args.out / "arms" / item["name"]) for item in recipes]
    for path in HERE.glob("*.py"):
        if not path.name.startswith("._"):
            copy_source(path, args.out / "control" / path.name)
    for name in ("verify_linux.py", "verify_public.py", "fetch_evaluation.py"):
        copy_source(COMPLETION / name, args.out / "host" / name)
    write(args.out / "SCREEN_PLAN.json", {"schema": "t3-linux-screen-plan-v1", "rankable": False,
        "scope": "serial rotating candidate screen; one canonical baseline per round, less closely paired than dedicated paired experiments",
        "base": BASE, "arms": names, "smoke_units": SMOKE, "stress_units": STRESS, "units": UNITS,
        "warmups": 1, "measured_repeats": 3, "retain_success_outputs_until_job_end": True,
        "promotion_requires_separate_full71": True, "unready_arms_omitted": [n for n in ("direct_state_engine_v2", "streaming_observer_v1") if n not in names]})
    files = inventory(args.out)
    if len(files) + 1 > MAX_FILES or sum(row["bytes"] for row in files.values()) > MAX_BYTES:
        raise ValueError("source payload exceeds materialization bounds")
    write(args.out / "PAYLOAD_MANIFEST.json", {"schema": "t3-screen-payload-v1", "files": files})
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.archive, "w:xz", preset=6) as archive:
        for path in sorted(args.out.rglob("*")):
            if not path.is_file() or path.name.startswith("._") or "__pycache__" in path.parts:
                continue
            data = path.read_bytes()
            info = tarfile.TarInfo(path.relative_to(args.out).as_posix())
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
    write(args.archive.with_name(args.archive.name + ".json"), {"archive": str(args.archive),
        "sha256": sha(args.archive), "bytes": args.archive.stat().st_size, "arms": names,
        "source_only": True, "builds_or_simulations_executed": False})
    print(json.dumps({"archive_sha256": sha(args.archive), "arms": names}))


if __name__ == "__main__":
    main()
