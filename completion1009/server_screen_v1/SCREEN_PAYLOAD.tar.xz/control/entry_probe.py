"""Run the real CLI with finite path witnesses, then authenticate outside its timer."""
from contextlib import contextmanager
import ast
import functools
import importlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import platform
import resource
import sys
import types
from common import sha

ROOT = Path("/opt/t3-screen")
SPEC = json.loads(Path("/screen/ARM.json").read_text())
MARKER = "T3_SCREEN_RECEIPT="


def resolve(binding):
    module, name = binding.rsplit(":", 1)
    value = importlib.import_module(module)
    for part in name.split("."):
        value = getattr(value, part)
    return value


def definition_codes(code):
    return {value.co_name: value for value in code.co_consts if type(value) is types.CodeType}


def auth_definitions(module, path):
    """Compare loaded explicit Python definitions, including wrapped methods."""
    tree = ast.parse(path.read_bytes())
    compiled = compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
    checked = []
    def walk(nodes, loaded, code, prefix=""):
        definitions = definition_codes(code)
        counts = {}
        for node in nodes:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                counts[node.name] = counts.get(node.name, 0) + 1
        seen = {}
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                target = getattr(loaded, node.name)
                if target.__module__ != module.__name__:
                    raise ValueError("loaded class origin differs: " + node.name)
                walk(node.body, target, definitions[node.name], prefix + node.name + ".")
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                ordinal = seen.get(node.name, 0)
                seen[node.name] = ordinal + 1
                matching_codes = [c for c in code.co_consts if type(c) is types.CodeType and c.co_name == node.name]
                if counts[node.name] > 1:
                    key = module.__name__ + ":" + prefix + node.name + "#" + str(ordinal)
                    alias = SPEC.get("binding_aliases", {}).get(key)
                    if alias is None:
                        raise ValueError("duplicate source definition requires exact saved-binding alias: " + key)
                    target = resolve(alias)
                else:
                    target = inspect.getattr_static(loaded, node.name)
                if isinstance(target, property):
                    target = target.fget
                elif isinstance(target, (classmethod, staticmethod)):
                    target = target.__func__
                target = inspect.unwrap(target)
                if type(target) is not types.FunctionType or target.__code__ != matching_codes[ordinal]:
                    raise ValueError("loaded definition differs: " + module.__name__ + ":" + prefix + node.name)
                checked.append(prefix + node.name)
    walk(tree.body, module, compiled)
    return checked


def authenticate(entry):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64") or platform.python_version() != "3.11.17" or os.getuid() != 65534:
        raise ValueError("exact participant Linux amd64 Python/nonroot ABI differs")
    import numpy, pandas, pyarrow
    versions = {"numpy": numpy.__version__, "pandas": pandas.__version__, "pyarrow": pyarrow.__version__}
    if versions != SPEC["dependency_versions"]:
        raise ValueError("participant numeric dependency versions differ")
    files = {}
    for relative, expected in SPEC["participant_inventory"].items():
        path = ROOT / relative
        if path.is_symlink() or not path.is_file() or sha(path) != expected["sha256"] or path.stat().st_size != expected["bytes"]:
            raise ValueError("participant source changed: " + relative)
        files[relative] = expected
    modules = []
    for name, relative in SPEC["modules"].items():
        module = entry if name == "@entry" else importlib.import_module(name)
        path = ROOT / relative
        if Path(module.__file__).resolve() != path:
            raise ValueError("source-only loaded module origin differs: " + name)
        modules.append({"module": name, "path": str(path), "sha256": sha(path),
                        "definitions": auth_definitions(module, path)})
    native = []
    if SPEC["native"]:
        receipt = json.loads((ROOT / "NATIVE_BUILD_RECEIPT.json").read_text())
        for row in receipt["modules"]:
            module = importlib.import_module(row["module"])
            path = ROOT / row["extension"]
            if Path(module.__file__).resolve() != path or sha(path) != row["extension_sha256"]:
                raise ValueError("native loaded origin/hash differs")
            native.append(row)
    allowed = {row["module"] for row in native}
    incidental = []
    for name, module in list(sys.modules.items()):
        filename = getattr(module, "__file__", None)
        if filename and str(filename).startswith(str(ROOT) + "/") and str(filename).endswith((".so", ".pyd")) and name not in allowed:
            incidental.append({"module": name, "file": filename})
    if incidental:
        raise ValueError("incidental native runtime module prohibited: " + repr(incidental))
    limits = {name: list(resource.getrlimit(value)) for name, value in (
        ("nofile", resource.RLIMIT_NOFILE), ("nproc", resource.RLIMIT_NPROC), ("fsize", resource.RLIMIT_FSIZE))}
    if limits != {"nofile": [1024, 1024], "nproc": [256, 256], "fsize": [268435456, 268435456]}:
        raise ValueError("effective process ulimits differ")
    generated = list(SPEC.get("generated_files", []))
    if SPEC.get("preflight"):
        generated.append("LINUX_PREFLIGHT_RECEIPT.json")
    if SPEC["native"]:
        generated.append("NATIVE_BUILD_RECEIPT.json")
    generated_hashes = {relative: sha(ROOT / relative) for relative in generated}
    return {"passed": True, "source_files": files, "loaded_modules": modules, "native_modules": native,
        "generated_file_hashes": generated_hashes,
        "python": sys.version, "dependencies": versions, "uid": os.getuid(), "limits": limits}


def main():
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / SPEC["runtime"]))
    filename = ROOT / SPEC["entrypoint"]
    module_spec = importlib.util.spec_from_file_location("_t3_screen_real_entry", filename)
    entry = importlib.util.module_from_spec(module_spec)
    sys.modules[module_spec.name] = entry
    module_spec.loader.exec_module(entry)
    if SPEC.get("preflight"):
        # Authenticate clean immutable bindings before any external witness.
        entry.ensure_static_admission()
    from abides_core import abides
    from abides_fork.config import ScenarioLatencyModel
    original_enabled, original_run = entry.enabled, abides.run
    original_extract = entry.extract_trace
    witnesses = []
    @contextmanager
    def witnessed_enabled(*args, **kwargs):
        with original_enabled(*args, **kwargs) as extractor:
            expected = resolve(SPEC["expected_kernel"])
            if abides.Kernel is not expected:
                raise ValueError("expected exact kernel path is not active")
            if ScenarioLatencyModel.get_latency is not resolve(SPEC["expected_latency"]):
                raise ValueError("expected scalar latency path is not active")
            witnesses.append({"kernel": expected.__module__ + ":" + expected.__qualname__,
                "latency": ScenarioLatencyModel.get_latency.__module__ + ":" + ScenarioLatencyModel.get_latency.__qualname__,
                "extractor": extractor.__module__ + ":" + extractor.__qualname__, "native_sides": 0, "native_levels": 0})
            yield extractor
    def witnessed_run(*args, **kwargs):
        state = original_run(*args, **kwargs)
        witness = witnesses[-1]
        for agent in state["agents"]:
            if type(agent.kernel) is not resolve(SPEC["expected_kernel"]):
                raise ValueError("returned market used unexpected kernel")
            for book in getattr(agent, "order_books", {}).values():
                for side in (book.bids, book.asks):
                    if type(side).__module__ == "closed_book_store":
                        witness["native_sides"] += 1
                        witness["native_levels"] += len(side)
        return state
    def witnessed_extract(*args, **kwargs):
        # This CLI-local alias is outside the observer domain's authenticated
        # helpers. The original extractor runs unchanged before state capture.
        result = original_extract(*args, **kwargs)
        import observer
        state = observer.STATE
        if state is None:
            raise ValueError("expected observer was not active in real episode")
        witnesses[-1]["observer"] = {name: getattr(state, name) for name in (
            "order_rows", "quote_rows", "private_rows", "termination_frames_avoided", "range_replays")}
        if state.order_rows <= 0 or state.termination_frames_avoided <= 0:
            raise ValueError("observer canonical producers/termination path not exercised")
        return result
    entry.enabled = witnessed_enabled
    if not SPEC.get("no_run_patch"):
        abides.run = witnessed_run
    if SPEC.get("observer_probe"):
        entry.extract_trace = witnessed_extract
    error = None
    try:
        entry.main()
    except BaseException as exc:
        error = type(exc).__name__ + ": " + str(exc)
        raise
    finally:
        entry.enabled, abides.run = original_enabled, original_run
        entry.extract_trace = original_extract
        receipt = {"schema": "t3-screen-execution-bindings-v1", "arm": SPEC["name"], "rankable": False,
                   "witnesses": witnesses, "cli_error": error, "timing_scope": "real CLI entry timer includes finite path capture; post authentication excluded"}
        try:
            receipt["authentication"] = authenticate(entry)
            if not witnesses:
                raise ValueError("no real episode path witnessed")
            if SPEC["native"] and any(row["native_sides"] <= 0 for row in witnesses):
                raise ValueError("native book extension was not exercised in every episode")
            if SPEC.get("active_probe"):
                receipt["active_probe"] = resolve(SPEC["active_probe"])()
                if not receipt["active_probe"]:
                    raise ValueError("candidate active probe is empty")
                for key, value in SPEC["probe_equals"].items():
                    if receipt["active_probe"].get(key) != value:
                        raise ValueError("candidate active/fallback probe differs: " + key)
            receipt["passed"] = error is None
        except BaseException as exc:
            receipt["passed"] = False
            receipt["authentication_error"] = type(exc).__name__ + ": " + str(exc)
            print(MARKER + json.dumps(receipt, sort_keys=True), flush=True)
            raise
        print(MARKER + json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
