"""Finite serial Linux screen with exact references, byte pairs and pinned paths."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import statistics
import sys
import uuid
from common import BASE, SMOKE, STRESS, UNITS, inventory, sha, write

PAYLOAD = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PAYLOAD / "host"))
import verify_linux as linux
import verify_public as public

MARKER = "T3_SCREEN_RECEIPT="


class StrictCommands(linux.DockerCommands):
    def call(self, arguments, label, seconds=30, cleanup=False):
        if arguments and arguments[0] == "create":
            arguments = [arguments[0], "--ulimit", "nproc=256:256", "--ulimit", "fsize=268435456:268435456", *arguments[1:]]
        return super().call(arguments, label, seconds, cleanup)

    def inspect(self, name, cleanup=False, seconds=30):
        info, command = super().inspect(name, cleanup, seconds)
        if info is not None and not cleanup:
            limits = {row["Name"]: (row["Soft"], row["Hard"]) for row in info["HostConfig"].get("Ulimits", [])}
            if any(limits.get(key) != value for key, value in {"nofile": (1024, 1024), "nproc": (256, 256), "fsize": (268435456, 268435456)}.items()):
                raise ValueError("actual complete resource ulimits differ before container starts")
            mounted = info.get("Mounts", [])
            binds = [row for row in mounted if row.get("Destination") != "/tmp"]
            temporary = [row for row in mounted if row.get("Destination") == "/tmp"]
            if (len(binds) != 2 or {row.get("Destination") for row in binds} != {"/input", "/output"}
                    or any(row.get("Type") != "bind" for row in binds)
                    or any(row.get("Type") != "tmpfs" for row in temporary)):
                raise ValueError("participant mounts must contain only scenario input and output")
        return info, command


linux.DockerCommands = StrictCommands


def execute(command, prefix, timeout=1200, env=None):
    # Builds run with one serial command. Docker stage is daemon owned; timeout
    # is diagnostic, with exact failure logs retained and no publication step.
    old = None
    if env is not None:
        old = dict(os.environ)
        os.environ.clear()
        os.environ.update(env)
    try:
        result = linux.run_command(command, prefix, timeout, 4 * 1024 ** 2)
    finally:
        if old is not None:
            os.environ.clear()
            os.environ.update(old)
    write(prefix.with_name(prefix.name + ".json"), result)
    if not result["succeeded"]:
        raise RuntimeError("failed stage; preserve diagnostics: " + str(prefix))
    return result


def inspect_image(args, image, directory):
    directory.mkdir(parents=True, exist_ok=True)
    return linux.image_metadata(args, image, directory)


def build(args, plan, evidence):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise ValueError("real Linux amd64 runner required")
    anonymous = evidence / "anonymous-config"
    anonymous.mkdir()
    env = dict(os.environ, DOCKER_CONFIG=str(anonymous))
    execute([args.docker, "pull", "--platform", "linux/amd64", BASE], evidence / "base-pull", 600, env)
    base = inspect_image(args, BASE, evidence / "base")
    write(evidence / "BASE.json", base)
    images = {}
    for name in plan["arms"]:
        source = PAYLOAD / "arms" / name
        spec = public.read_json(source / "ARM.json")
        context = evidence / "contexts" / name
        context.mkdir(parents=True)
        (context / "arm").mkdir()
        for relative in list(spec["participant_inventory"]) + [row["source"] for row in spec["native"]]:
            target = context / "arm" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / relative, target)
        image_spec = {key: value for key, value in spec.items() if key not in ("source_inventory", "receipts")}
        write(context / "arm/ARM.json", image_spec)
        shutil.copytree(PAYLOAD / "control", context / "control")
        lines = []
        if spec["native"]:
            lines += ["FROM " + BASE + " AS compiler", "USER 0",
                "RUN apt-get update && apt-get install -y --no-install-recommends gcc libc6-dev && rm -rf /var/lib/apt/lists/*",
                "RUN python -m pip install --no-cache-dir Cython==3.1.3",
                "COPY arm /build/arm", "COPY control /build/control",
                "RUN python /build/control/build_extension.py --root /build/arm"]
        lines += ["FROM " + BASE + " AS participant", "USER 0", "COPY arm /opt/t3-screen", "COPY control/entry_probe.py control/common.py /screen/",
                  "COPY arm/ARM.json /screen/ARM.json"]
        # Genuine native build sources are compiler-only. The runtime imports
        # the exact installed extension and retains its build receipt.
        if spec["native"]:
            lines += ["RUN " + " && ".join("rm /opt/t3-screen/" + row["source"] for row in spec["native"])]
        if spec["native"]:
            lines += ["COPY --from=compiler /build/arm/" + spec["runtime"] + " /opt/t3-screen/" + spec["runtime"],
                      "COPY --from=compiler /build/arm/NATIVE_BUILD_RECEIPT.json /opt/t3-screen/NATIVE_BUILD_RECEIPT.json"]
        if spec.get("preflight"):
            lines += ["RUN python -B /opt/t3-screen/" + spec["preflight"] + " > /opt/t3-screen/LINUX_PREFLIGHT_RECEIPT.json"]
        lines += ["RUN find /opt/t3-screen /screen -type d -exec chmod 755 {} + && find /opt/t3-screen /screen -type f -exec chmod 644 {} +",
            "ENV PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONHASHSEED=0",
            'LABEL qfbench2.interface_version="2.0" org.opencontainers.image.licenses="BSD-3-Clause"',
            "USER 65534:65534", "WORKDIR /output", 'ENTRYPOINT ["/usr/local/bin/python","-B","/screen/entry_probe.py"]',
            'CMD ["simulate","--help"]']
        dockerfile = context / "Dockerfile"
        dockerfile.write_text("\n".join(lines) + "\n")
        tag = "t3-screen-v1:" + name
        iid = evidence / (name + ".image-id")
        execute([args.docker, "build", "--platform", "linux/amd64", "--iidfile", str(iid), "-t", tag,
            "-f", str(dockerfile), str(context)], evidence / (name + "-build"), 1200)
        images[name] = inspect_image(args, iid.read_text().strip(), evidence / "images" / name)
        # Source/generated pins are copied from an owned never-started container.
        token = uuid.uuid4().hex
        container = "t3-screen-receipts-" + token[:12]
        commands = StrictCommands(args.docker, evidence / "receipt-commands" / name, args.log_cap_bytes)
        created = commands.call(["create", "--name", container, "--label", linux.OWNER_LABEL + "=" + token,
            "--entrypoint", "/usr/local/bin/python", images[name]["id"], "--help"], "create")
        if not created["succeeded"]:
            raise RuntimeError("receipt container creation failed")
        try:
            for relative in (["NATIVE_BUILD_RECEIPT.json"] if spec["native"] else []) + (spec.get("generated_files", []) + ["LINUX_PREFLIGHT_RECEIPT.json"] if spec.get("preflight") else []):
                target = evidence / "build-receipts" / name / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                copied = commands.call(["cp", container + ":/opt/t3-screen/" + relative, str(target)], "copy-" + Path(relative).stem)
                if not copied["succeeded"]:
                    raise ValueError("exact generated/build receipt unavailable: " + relative)
        finally:
            # Receipt containers were never started and are not resource runs.
            cleaned = linux.settle_container(commands, container, token, images[name]["id"])
            write(evidence / (name + "-receipt-cleanup.json"), cleaned)
            if not cleaned["settled"] or not cleaned["final_absent"] or cleaned["errors"]:
                raise RuntimeError("owned receipt container cleanup failed")
    write(evidence / "IMAGES.json", images)
    return images


def frame_names(item):
    return list(public.SUB_FILES[:2]) if item["shape"] == "single" else [entry["sub"] + "/" + name for entry in item["subs"] for name in public.SUB_FILES[:2]]


def sidecar_names(item):
    return ["events.json"] if item["shape"] == "single" else [entry["sub"] + "/events.json" for entry in item["subs"]] + ["batch_events.json"]


def stable_sidecar(path):
    value = public.read_json(path)
    # Only runtime telemetry is unstable. Every deterministic field is retained.
    for name in ("wall_clock_sec", "events_per_sec", "peak_memory_bytes", "gpu_seconds"):
        value.pop(name, None)
    return value


def pair_outputs(output, baseline, item):
    frames = [public.compare_frame(output / name, baseline / name) for name in frame_names(item)]
    sidecars = [{"path": name, "candidate": stable_sidecar(output / name), "baseline": stable_sidecar(baseline / name)} for name in sidecar_names(item)]
    for row in sidecars:
        row["passed"] = row["candidate"] == row["baseline"]
    return {"passed": all(row["passed"] and row.get("byte_equal") for row in frames) and all(row["passed"] for row in sidecars),
            "frames": frames, "stable_sidecars": sidecars}


def output_inventory(directory):
    return inventory(directory)


def parse_binding(execution):
    text = Path(execution["attach"]["stdout"]["path"]).read_text(errors="replace") if execution.get("attach") else ""
    values = [json.loads(line[len(MARKER):]) for line in text.splitlines() if line.startswith(MARKER)]
    if len(values) != 1 or values[0].get("passed") is not True:
        raise ValueError("exact successful source/loaded/native binding receipt missing")
    return values[0]


def settled_runtime_seconds(execution):
    state = execution.get("state") or {}
    try:
        started = datetime.fromisoformat(state["StartedAt"].replace("Z", "+00:00"))
        finished = datetime.fromisoformat(state["FinishedAt"].replace("Z", "+00:00"))
        return (finished - started).total_seconds()
    except (KeyError, ValueError):
        return None


def run_one(args, images, name, item, folder, token, suffix, reference=True):
    row = {"arm": name, "unit": item["unit"], "rankable": False, "passed": False, "failure": None}
    execution, output = linux.run_container(args, images[name]["id"], "optimized", item, folder, token, suffix)
    row["execution"] = execution
    row["output"] = str(output)
    try:
        row["output_inventory"] = output_inventory(output)
        row["binding_receipt"] = parse_binding(execution)
        if row["binding_receipt"]["arm"] != name:
            raise ValueError("binding arm identity differs")
        for relative, digest in row["binding_receipt"]["authentication"].get("generated_file_hashes", {}).items():
            saved = args.evidence / "build-receipts" / name / relative
            if not saved.is_file() or sha(saved) != digest:
                raise ValueError("actual loaded/generated source pin differs from immutable image build receipt")
        if reference:
            row["reference_checks"] = public.verify_outputs(args.reference_root / item["unit"], output, item)
            row["developer_verifier"] = linux.gate(args, args.reference_root / item["unit"], output, folder)
            if not row["reference_checks"]["passed"] or row["developer_verifier"]["admissible"] is not True:
                raise ValueError("original reference values/dtypes/sidecars/tree or official developer gate failed")
        else:
            sidecars = [public.verify_events(output, public.read_json(Path(item["scenario_paths"][0])),
                __import__("pandas").read_parquet(output / "trace.parquet").shape[0])]
            tree = public.check_tree(output, set(public.SUB_FILES))
            if not tree["passed"] or not all(s["passed"] for s in sidecars):
                raise ValueError("synthetic default-latency sidecars/tree failed")
            row["reference_checks"] = {"passed": True, "original_reference_available": False,
                "sidecars": sidecars, "output_tree": tree, "actual_events": sidecars[0]["events"]["n_events"]}
        if not execution["succeeded"]:
            raise ValueError("resource-isolated container execution failed")
        row["passed"] = True
        row["settled_container_runtime_sec"] = settled_runtime_seconds(execution)
        events = public.read_json(output / ("events.json" if item["shape"] == "single" else "batch_events.json"))
        row["cli_wall_sec"] = events["wall_clock_sec"]
        row["actual_events"] = row["reference_checks"]["actual_events"]
        row["host_events_per_sec"] = row["actual_events"] / execution["host_wall_sec"]
        row["cli_events_per_sec"] = row["actual_events"] / row["cli_wall_sec"]
        row["peak_memory_bytes"] = max(public.read_json(output / p).get("peak_memory_bytes", 0) for p in sidecar_names(item) if p.endswith("events.json") and p != "batch_events.json")
    except BaseException as error:
        row["failure"] = type(error).__name__ + ": " + str(error)
    write(folder / "RUN_RESULT.json", row)
    print(name, item["unit"], "PASS" if row["passed"] else "FAIL", flush=True)
    return row


def rounds(args, images, names, items, evidence, stage, repeats, warmups, rows, serial, reference=True):
    first_outputs = {}
    for repeat in range(-warmups, repeats):
        for index, item in enumerate(items):
            candidates = names[1:]
            shift = (repeat + warmups + index) % max(1, len(candidates))
            rotation = candidates[shift:] + candidates[:shift]
            # Alternate baseline position, rotate candidate position every round.
            order = (["canonical"] + rotation) if (repeat + warmups + index) % 2 == 0 else (rotation + ["canonical"])
            group = {}
            for name in order:
                serial[0] += 1
                folder = evidence / stage / ("warmup-%d" % (-repeat) if repeat < 0 else "repeat-%d" % repeat) / item["unit"] / name
                row = run_one(args, images, name, item, folder, args.owner, "%04d" % serial[0], reference)
                row.update(stage=stage, repeat=repeat, warmup=repeat < 0, order=order, timing_included=stage == "screen" and repeat >= 0)
                group[name] = row
                rows.append(row)
                write(folder / "RUN_RESULT.json", row)
                write(evidence / "RAW_RESULTS.json", rows)
                if not row["passed"]:
                    raise ValueError("screen stopped after retained failed run")
            baseline = Path(group["canonical"]["output"])
            for name, row in group.items():
                folder = Path(row["output"]).parent
                row["same_round_canonical_pair"] = pair_outputs(Path(row["output"]), baseline, item)
                first = first_outputs.setdefault((item["unit"], name), Path(row["output"]))
                row["same_arm_repeat_pair"] = pair_outputs(Path(row["output"]), first, item)
                row["passed"] &= row["same_round_canonical_pair"]["passed"] and row["same_arm_repeat_pair"]["passed"]
                row["paired_checks_complete"] = True
                write(folder / "RUN_RESULT.json", row)
                write(evidence / "RAW_RESULTS.json", rows)
                if not row["passed"]:
                    raise ValueError("exact corresponding Parquet bytes/stable sidecar or repeat comparison failed")
    return rows


def isolated_batch(args, images, names, item, batch_rows, evidence, rows, serial):
    for name in names:
        batch = next(row for row in reversed(batch_rows) if row["unit"] == item["unit"] and row["arm"] == name)
        for entry in item["subs"]:
            serial[0] += 1
            sub = entry["sub"]
            original = args.reference_root / item["unit"] / entry["scenario_file"]
            single = {"unit": item["unit"] + "/" + sub, "shape": "single", "subs": [], "scenario_paths": [str(original)]}
            folder = evidence / "batch-isolated" / name / sub
            row = run_one(args, images, name, single, folder, args.owner, "%04d" % serial[0], reference=False)
            row.update(stage="batch-isolated", timing_included=False)
            try:
                row["isolated_batch_pair"] = pair_outputs(Path(row["output"]), Path(batch["output"]) / sub, single)
                row["passed"] &= row["isolated_batch_pair"]["passed"]
                row["paired_checks_complete"] = True
            except BaseException as error:
                row["passed"] = False
                row["failure"] = type(error).__name__ + ": " + str(error)
            rows.append(row)
            write(folder / "RUN_RESULT.json", row)
            write(evidence / "RAW_RESULTS.json", rows)
            if not row["passed"]:
                raise ValueError("batch reset/isolation control failed")


def summarize(plan, rows, failure, inputs_unchanged):
    measured = [row for row in rows if row.get("timing_included")]
    comparisons = []
    for name in plan["arms"][1:]:
        per_unit = []
        for unit in UNITS:
            baseline = [r for r in measured if r["arm"] == "canonical" and r["unit"] == unit]
            candidate = [r for r in measured if r["arm"] == name and r["unit"] == unit]
            if len(baseline) != 3 or len(candidate) != 3 or not all(r["passed"] for r in baseline + candidate):
                continue
            per_unit.append({"unit": unit, "host_baseline_sec": [r["execution"]["host_wall_sec"] for r in baseline],
                "host_candidate_sec": [r["execution"]["host_wall_sec"] for r in candidate],
                "cli_baseline_sec": [r["cli_wall_sec"] for r in baseline], "cli_candidate_sec": [r["cli_wall_sec"] for r in candidate],
                "median_host_ratio": statistics.median(r["execution"]["host_wall_sec"] for r in baseline) / statistics.median(r["execution"]["host_wall_sec"] for r in candidate),
                "median_cli_ratio": statistics.median(r["cli_wall_sec"] for r in baseline) / statistics.median(r["cli_wall_sec"] for r in candidate),
                "median_settled_runtime_ratio": statistics.median(r["settled_container_runtime_sec"] for r in baseline) / statistics.median(r["settled_container_runtime_sec"] for r in candidate) if all(r["settled_container_runtime_sec"] is not None and r["settled_container_runtime_sec"] > 0 for r in baseline + candidate) else None,
                "candidate_peak_memory_bytes": max(r["peak_memory_bytes"] for r in candidate)})
        comparisons.append({"arm": name, "complete_five_units": len(per_unit) == 5, "per_unit": per_unit,
            "mean_unit_median_host_ratio": statistics.mean(row["median_host_ratio"] for row in per_unit) if len(per_unit) == 5 else None,
            "mean_unit_median_cli_ratio": statistics.mean(row["median_cli_ratio"] for row in per_unit) if len(per_unit) == 5 else None})
    expected = len(plan["arms"]) * (len(SMOKE) + len(STRESS) + 1 + len(UNITS) * 4)
    return {"schema": "t3-linux-screen-summary-v1", "rankable": False, "official_score": None,
        "scope": plan["scope"], "failure": failure, "all_passed": failure is None and bool(rows) and all(row["passed"] for row in rows) and inputs_unchanged,
        "runs": len(rows), "minimum_planned_non_isolated_runs": expected, "original_inputs_references_unchanged": inputs_unchanged,
        "comparisons": comparisons, "stress_and_default_and_batch_isolated_excluded_from_timing": True,
        "full71_or_publication_performed": False, "successful_outputs_retained_on_runner": True,
        "timing_note": "host create-to-settled inspection includes finite source/loaded authentication; participant CLI sidecars exclude post-run authentication; baseline shared per rotating round is less closely paired"}


def compact(args):
    rows = public.read_json(args.evidence / "RAW_RESULTS.json") if (args.evidence / "RAW_RESULTS.json").is_file() else []
    success_roots = {Path(row["output"]).parent.resolve() for row in rows if row["passed"] and row.get("paired_checks_complete") is True}
    args.artifact.mkdir(parents=True, exist_ok=False)
    excluded = []
    for source in sorted(args.evidence.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(args.evidence)
        successful_run = any(root == source.parent.resolve() or root in source.resolve().parents for root in success_roots)
        # An interrupted run may have EXECUTION.json but no aggregated row. Its
        # outputs are failed/unknown evidence and must remain in the artifact.
        failure = ("output" in relative.parts or "input" in relative.parts) and not successful_run
        bulky = "output" in relative.parts or "input" in relative.parts or relative.parts[0] in ("contexts", "anonymous-config")
        if bulky and not failure:
            excluded.append({"path": relative.as_posix(), "bytes": source.stat().st_size})
            continue
        target = args.artifact / "evidence" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    shutil.copyfile(args.archive, args.artifact / "SCREEN_PAYLOAD.tar.xz")
    for name in ("SCREEN_PLAN.json", "PAYLOAD_MANIFEST.json", "MATERIALIZATION.json"):
        shutil.copyfile(PAYLOAD / name, args.artifact / name)
    write(args.artifact / "ARTIFACT_POLICY.json", {"source_archive_sha256": sha(args.archive),
        "excluded_success_runner_files": excluded, "failed_outputs_preserved": True,
        "successful_outputs_deleted": False, "evidence_inventory": inventory(args.artifact)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("build", "screen", "compact"))
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--reference-root", type=Path)
    parser.add_argument("--gate-python", default=sys.executable)
    parser.add_argument("--gate-kit", type=Path)
    parser.add_argument("--docker", default="docker")
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--artifact", type=Path)
    args = parser.parse_args()
    args.evidence = args.evidence.resolve()
    args.evidence.mkdir(parents=True, exist_ok=True)
    args.timeout, args.log_cap_bytes, args.owner = 300, 4 * 1024 ** 2, uuid.uuid4().hex
    plan = public.read_json(PAYLOAD / "SCREEN_PLAN.json")
    if args.stage == "compact":
        if not args.archive or not args.artifact:
            parser.error("compact requires archive and artifact")
        compact(args)
        return 0
    if args.stage == "build":
        build(args, plan, args.evidence)
        return 0
    if not args.reference_root or not args.gate_kit:
        parser.error("screen requires original references and current official gate")
    args.reference_root, args.gate_kit = args.reference_root.resolve(), args.gate_kit.resolve()
    signal.signal(signal.SIGINT, linux.cancellation)
    signal.signal(signal.SIGTERM, linux.cancellation)
    roster = public.collect_plan(args.reference_root, UNITS + STRESS)
    items = {row["unit"]: row for row in roster["units"]}
    write(args.evidence / "REFERENCE_PLAN.json", roster)
    images = public.read_json(args.evidence / "IMAGES.json")
    rows, serial, failure = [], [0], None
    try:
        rounds(args, images, plan["arms"], [items[n] for n in SMOKE], args.evidence, "smoke", 1, 0, rows, serial)
        rounds(args, images, plan["arms"], [items[n] for n in STRESS], args.evidence, "stress", 1, 0, rows, serial)
        default = public.read_json(Path(items[SMOKE[0]]["scenario_paths"][0]))
        default.pop("latency_config", None)
        default["scenario_id"] = str(default["scenario_id"]) + "-default-latency-control"
        default_path = args.evidence / "default-latency-scenario.json"
        write(default_path, default)
        synthetic = {"unit": "default-latency-control", "shape": "single", "subs": [], "scenario_paths": [str(default_path)]}
        rounds(args, images, plan["arms"], [synthetic], args.evidence, "default-latency", 1, 0, rows, serial, reference=False)
        rounds(args, images, plan["arms"], [items[n] for n in UNITS], args.evidence, "screen", 3, 1, rows, serial)
        isolated_batch(args, images, plan["arms"], items[UNITS[-1]], rows[:], args.evidence, rows, serial)
    except BaseException as error:
        failure = type(error).__name__ + ": " + str(error)
    unchanged = all(sha(args.reference_root / item["unit"] / name) == digest for item in roster["units"]
        for mapping in (item["input_sha256"], item["reference_sha256"]) for name, digest in mapping.items())
    summary = summarize(plan, rows, failure, unchanged)
    write(args.evidence / "SUMMARY.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0 if summary["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
