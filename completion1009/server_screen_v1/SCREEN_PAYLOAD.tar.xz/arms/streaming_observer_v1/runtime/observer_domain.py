"""Authenticate the actual frozen source domain once before each CLI episode."""
from pathlib import Path
import ast
import types


def _code_at(module, class_name, method_name, compiled, first=False):
    path = Path(module.__file__).resolve()
    code = compiled.get(path)
    if code is None:
        code = compile(path.read_bytes(), str(path), "exec", dont_inherit=True)
        compiled[path] = code
    if class_name:
        code = next(c for c in code.co_consts if type(c) is types.CodeType and c.co_name == class_name)
    matches = [c for c in code.co_consts if type(c) is types.CodeType and c.co_name == method_name]
    return matches[0] if first else matches[-1]


def _defaults_match(function, module, class_name, name, parsed, first=False):
    path = Path(module.__file__).resolve()
    tree = parsed.get(path)
    if tree is None:
        tree = ast.parse(path.read_bytes())
        parsed[path] = tree
    nodes = tree.body
    if class_name:
        nodes = next(node.body for node in nodes if isinstance(node, ast.ClassDef) and node.name == class_name)
    matches = [node for node in nodes if isinstance(node, ast.FunctionDef) and node.name == name]
    node = matches[0] if first else matches[-1]
    positional = tuple(ast.literal_eval(value) for value in node.args.defaults) or None
    keywords = {argument.arg: ast.literal_eval(value) for argument, value in zip(node.args.kwonlyargs, node.args.kw_defaults) if value is not None} or None
    return function.__defaults__ == positional and function.__kwdefaults__ == keywords


def authenticate_loaded():
    """Return False for an unsupported loaded domain before any agents exist.

    The shipped snapshot is manifest-verified during preparation and packaging.
    This check authenticates producer code, inherited logging/constructors and
    all four mappings as actually imported; no hot-loop checks are installed.
    """
    from abides_core import agent, kernel
    from abides_markets import orders, order_book
    from abides_markets.agents import trading_agent, exchange_agent
    from abides_fork import agents, config, trace
    import observer
    runtime = Path(observer.__file__).resolve().parent
    checks = (
        (agent, "vendor/abides/abides-core/abides_core/agent.py", "Agent", ("__init__", "logEvent", "kernel_terminating", "write_log")),
        (kernel, "vendor/abides/abides-core/abides_core/kernel.py", "Kernel", ("write_log", "append_summary_log")),
        (orders, "vendor/abides/abides-markets/abides_markets/orders.py", "Order", ("__init__", "to_dict")),
        (orders, "vendor/abides/abides-markets/abides_markets/orders.py", "LimitOrder", ("__init__", "__deepcopy__")),
        (trading_agent, "vendor/abides/abides-markets/abides_markets/agents/trading_agent.py", "TradingAgent", (
            "__init__", "create_limit_order", "place_limit_order", "place_market_order", "place_multiple_orders", "cancel_order", "partial_cancel_order", "modify_order", "replace_order", "order_executed", "order_accepted", "order_cancelled", "order_partial_cancelled", "order_modified", "order_replaced", "kernel_starting", "kernel_stopping", "query_spread")),
        (exchange_agent, "vendor/abides/abides-markets/abides_markets/agents/exchange_agent.py", "ExchangeAgent", ("__init__", "receive_message", "send_message", "kernel_terminating")),
        (order_book, "vendor/abides/abides-markets/abides_markets/order_book.py", "OrderBook", ("handle_limit_order", "execute_order", "enter_order", "append_book_log2")),
        (config, "abides_fork/config.py", None, ("build_config", "_agent_kwargs")),
        (agents, "abides_fork/agents.py", "ScheduledAgent", ("__init__", "wakeup", "receive_message", "kernel_starting")),
        (trace, "abides_fork/trace.py", None, ("extract_trace", "_parse_trace_logs", "_canonical_trace")),
    )
    try:
        compiled, parsed = {}, {}
        for module, relative, class_name, names in checks:
            if Path(module.__file__).resolve() != runtime / relative:
                return False
            cls = getattr(module, class_name) if class_name else module
            for name in names:
                function = getattr(cls, name)
                if type(function) is not types.FunctionType or function.__code__ != _code_at(module, class_name, name, compiled):
                    return False
                if (function.__globals__ is not vars(module)
                        or Path(function.__globals__["__file__"]).resolve() != runtime / relative
                        or not _defaults_match(function, module, class_name, name, parsed)):
                    return False
        for name in observer.STRATEGIES:
            cls = getattr(agents, name)
            if cls.act.__code__ != _code_at(agents, name, "act", compiled):
                return False
            if cls.__init__.__code__ != _code_at(agents, name, "__init__", compiled):
                return False
            if (cls.act.__globals__ is not vars(agents) or cls.__init__.__globals__ is not vars(agents)
                    or not _defaults_match(cls.act, agents, name, "act", parsed)
                    or not _defaults_match(cls.__init__, agents, name, "__init__", parsed)):
                return False
        if agents.AGENT_REGISTRY != {name: getattr(agents, name) for name in observer.STRATEGIES}:
            return False
        if config.AGENT_REGISTRY is not agents.AGENT_REGISTRY:
            return False
        if (config.ExchangeAgent is not exchange_agent.ExchangeAgent
                or agents.TradingAgent is not trading_agent.TradingAgent
                or trading_agent.LimitOrder is not orders.LimitOrder
                or trading_agent.Side is not orders.Side
                or exchange_agent.OrderBook is not order_book.OrderBook):
            return False
        if any(getattr(module, "_observer", None) is not observer
               for module in (agent, trading_agent, exchange_agent, order_book)):
            return False
        for name in ("begin_episode", "finish_episode", "record_log", "order", "quote",
                     "skip_termination", "_payload", "replay_state", "extract_trace"):
            function = getattr(observer, name)
            if (function.__code__ != _code_at(observer, None, name, compiled)
                    or function.__globals__ is not vars(observer)
                    or not _defaults_match(function, observer, None, name, parsed)):
                return False
        for name in ("__init__", "append"):
            function = getattr(observer.Episode, name)
            if (function.__code__ != _code_at(observer, "Episode", name, compiled)
                    or function.__globals__ is not vars(observer)
                    or not _defaults_match(function, observer, "Episode", name, parsed)):
                return False
        fallback = trace._extract_trace_observer_original
        if type(fallback) is not types.FunctionType or fallback.__code__ != _code_at(trace, None, "extract_trace", compiled, first=True):
            return False
        if fallback.__globals__ is not vars(trace) or not _defaults_match(fallback, trace, None, "extract_trace", parsed, first=True):
            return False
        if (trace._side_to_str.__code__ != _code_at(trace, None, "_side_to_str", compiled)
                or trace._side_to_str.__globals__ is not vars(trace)
                or trace.Side is not orders.Side):
            return False
        if (observer.ORDER_FIELDS != ("agent_id", "order_id", "side", "quantity", "limit_price", "fill_price")
                or observer.FIELDS != ("ScalarEventValue", "agent_id", "order_id", "side", "quantity", "limit_price", "fill_price", "EventTime", "EventType")
                or observer.STRATEGIES != frozenset(("NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"))
                or observer.ORDER_TYPES != frozenset(("ORDER_SUBMITTED", "ORDER_ACCEPTED", "ORDER_EXECUTED", "ORDER_CANCELLED", "ORDER_REPLACED"))):
            return False
        columns = ["t_ns", "agent_id", "msg_type", "side", "price", "size", "order_id"]
        dtypes = {"t_ns": "int64", "agent_id": "int32", "msg_type": "string", "side": "string", "price": "int64", "size": "int64", "order_id": "int64"}
        if (trace.TRACE_COLUMNS != columns or trace._TRACE_DTYPES != dtypes
                or trace._ORDER_EVENT_MAP != {name: name for name in observer.ORDER_TYPES if name != "ORDER_EXECUTED"}):
            return False
        # Plain field defaults are a separate witness from bytecode equality.
        if trading_agent.TradingAgent.place_limit_order.__defaults__ != (None, False, False, False, False, True, None):
            return False
        if orders.LimitOrder.__init__.__defaults__ != (False, False, False, False, None, None):
            return False
        return True
    except (AttributeError, KeyError, IndexError, StopIteration, TypeError, ValueError, OSError, SyntaxError):
        return False
