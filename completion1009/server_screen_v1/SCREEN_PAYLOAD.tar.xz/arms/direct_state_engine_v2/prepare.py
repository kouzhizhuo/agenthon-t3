#!/usr/bin/env python3
"""Pin and copy the frozen runtime; no candidate execution or compilation."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
def sha(data): return hashlib.sha256(data).hexdigest()
def main():
    target = HERE / "runtime"
    if target.exists(): raise ValueError("prototype runtime exists")
    manifest = json.loads((ROOT / "RUNTIME_MANIFEST.json").read_text())
    records = []
    for item in manifest["files"]:
        relative = str(Path(item["path"]).relative_to("runtime"))
        data = (ROOT / "runtime" / relative).read_bytes()
        if len(data) != item["bytes"] or sha(data) != item["sha256"]: raise ValueError("frozen source differs: " + relative)
        path = target / relative; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
        records.append({"path": relative, "bytes": len(data), "sha256": sha(data)})
    if len(records) != 62: raise ValueError("frozen file count differs")
    pins = {str(p.relative_to(target)): sha(p.read_bytes()) for p in sorted(target.rglob("*.py"))
            if not p.name.startswith("._") and "__pycache__" not in p.parts}
    value = {"schema": "t3-direct-state-engine-prototype-pins-v1", "runtime_files": records,
             "python_sources": pins, "frozen_manifest_sha256": sha((ROOT / "RUNTIME_MANIFEST.json").read_bytes()),
             "prepared_only": True, "runtime_source_changes": 0}
    (HERE / "PINNED_RUNTIME.json").write_text(json.dumps(value, indent=2) + "\n")
    print(json.dumps({"prepared_only": True, "runtime_files": len(records), "source_changes": 0, "market_or_build_execution": False}))
if __name__ == "__main__": main()
