#!/usr/bin/env python3
"""Explicit offline hash/binding proof only; no market simulation or timing."""
from pathlib import Path
import json
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "runtime"))
from bootstrap import activate
activate()
from audit import prove_sources, source_files, interpreter_pin, sha

def main():
    destination = HERE / "STATIC_BINDING_PINS.json"
    if destination.exists():
        raise ValueError("binding evidence exists; preserve it")
    bindings = prove_sources()
    value = {"schema": "t3-direct-v2-static-source-pins", "interpreter": interpreter_pin(),
             "bindings": bindings, "candidate_sources": source_files(),
             "runtime_pins_sha256": sha((HERE / "PINNED_RUNTIME.json").read_bytes()),
             "full_source_hash_and_binding_proof": True,
             "simulation_execution": False, "timing_claim": False}
    destination.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"source_proof_passed": True, "modules": len(bindings),
                      "static_pins_sha256": sha(destination.read_bytes()),
                      "simulation_execution": False, "timing_claim": False}))

if __name__ == "__main__":
    main()
