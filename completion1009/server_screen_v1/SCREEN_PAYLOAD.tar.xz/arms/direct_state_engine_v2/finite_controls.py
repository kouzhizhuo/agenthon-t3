#!/usr/bin/env python3
"""Prepared untimed direct-path finite controls; do not execute during pilots."""
from pathlib import Path
import argparse
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "runtime"))
from bootstrap import activate
activate()
import hashlib
import json
from types import SimpleNamespace
import numpy as np
from abides_core.message import Message, MessageBatch, WakeupMsg
from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
from abides_fork.config import ScenarioLatencyModel
from abides_markets.agents.exchange_agent import ExchangeAgent
from abides_markets.orders import Order, LimitOrder, Side
from abides_markets.oracles.sparse_mean_reverting_oracle import SparseMeanRevertingOracle
from t3_canonical_engine import CanonicalKernel
from engine import (DirectKernel, AgentState, MessageArena, EventCalendar, SPECS,
                    WAKE, HOURS, CLOSE_PRICE, CLOSED, SPREAD, ACCEPTED, EXECUTED, CANCELLED)
from installed import authenticate, ensure_static_admission
from copy import deepcopy
import warnings

def encode(value):
    if value is None or type(value) in (int, str, bool): return [type(value).__name__, value]
    if type(value) is float: return ["float", value.hex()]
    if isinstance(value, np.generic): return [type(value).__name__, encode(value.item())]
    if isinstance(value, np.random.RandomState): return ["RandomState", encode(value.get_state())]
    if isinstance(value, np.ndarray): return ["ndarray", str(value.dtype), list(value.shape), encode(value.tolist())]
    if type(value) is Side: return ["Side", value.value]
    if type(value) in (list, tuple): return [type(value).__name__, [encode(x) for x in value]]
    if isinstance(value, dict): return ["dict", [[encode(k), encode(v)] for k, v in value.items()]]
    if hasattr(value, "__dict__"): return [type(value).__name__, encode({k: v for k, v in vars(value).items() if k != "kernel"})]
    return [type(value).__name__, str(value)]

def reset():
    Order._order_id_counter = 0; Message._Message__message_id_counter = 1

def arena_cases():
    results = []
    for code, (cls, fields) in SPECS.items():
        values = tuple({"mkt_open": 100, "mkt_close": 1000, "symbol": "ABM", "mkt_closed": False,
            "close_prices": {"ABM": 100}, "depth": 1, "bids": [(99, 3)], "asks": [(101, 4)],
            "last_trade": 100, "order": None, "new_order": None, "old_order": None,
            "tag": None, "metadata": {}, "length": 1, "orders": [], "bid_volume": 3,
            "ask_volume": 5, "messages": []}[name] for name in fields)
        reset(); original = cls(*values); original_state = encode(vars(original)); original_counter = Message._Message__message_id_counter
        reset(); arena = MessageArena(); slot = arena.compact(code, values); result = arena.materialize(slot)
        assert type(result) is cls and encode(vars(result)) == original_state
        assert Message._Message__message_id_counter == original_counter
        assert arena.materialize(slot) is result, "materialization must retain one identity"
        assert Message._Message__message_id_counter == original_counter, "materialization incremented UID"
        results.append({"name": "arena_" + cls.__name__, "passed": True, "uid": result.message_id})
    return results

def calendar_cases():
    keys = [(10, 2, 1), (10, 1, 2), (9, 5, 1), (10, 1, 1), (10, 1, 1), (-2, 0, 0)]
    reset(); ref = []; calendar = EventCalendar(); arena = MessageArena()
    import heapq
    for time, sender, recipient in keys:
        message = WakeupMsg(); slot = arena.original(message)
        heapq.heappush(ref, (time, sender, recipient, message))
        calendar.push(time, sender, recipient, message.message_id, slot)
    a = [(t, s, r, m.message_id) for t, s, r, m in [heapq.heappop(ref) for _ in keys]]
    b = [calendar.pop()[:4] for _ in keys]
    assert a == b
    return [{"name": "calendar_full_tuple_ties", "passed": True, "ordered_keys": a}]

class FixedOracle:
    def observe_price(self, symbol, time, random_state, sigma_n):
        # Consume one original normal draw while supplying a reproducible
        # oracle boundary value; this tests call order/full RNG state.
        return 100 + random_state.normal(0., sigma_n)

def pinned_oracle():
    return SparseMeanRevertingOracle(100, 2000, {"ABM": {"r_bar": 100,
        "kappa": .01, "fund_vol": .01, "megashock_lambda_a": .01,
        "megashock_mean": 0, "megashock_var": 0,
        "random_state": np.random.RandomState(35009)}})

def setup(kind, direct, open_market, closed, bids, asks):
    reset(); np.random.seed(36009)
    cls = (NoiseTrader, MarketMaker, ValueTrader, MomentumTrader)[kind - 1]
    agent = cls(id=1, name="CTRL", type=cls.__name__, symbol="ABM", starting_cash=10000,
        random_state=np.random.RandomState(31009), interval_ns=100)
    exchange = ExchangeAgent(0, 100, 1000, ["ABM"], random_state=np.random.RandomState(32009), log_orders=None)
    latency = ScenarioLatencyModel(2, {"model": "uniform", "params": {"min_ns": 0, "max_ns": 7}}, np.random.RandomState(33009))
    kernel_cls = DirectKernel if direct else CanonicalKernel
    kernel = kernel_cls([exchange, agent], start_time=1, stop_time=2000,
        random_state=np.random.RandomState(34009), agent_latency_model=latency,
        custom_properties={"oracle": pinned_oracle()})
    exchange.kernel = agent.kernel = kernel; agent.exchange_id = 0; agent.oracle = kernel.oracle
    agent.mkt_open, agent.mkt_close = (100, 1000) if open_market else (None, None)
    agent.mkt_closed = closed; agent.current_time = 120; kernel.current_time = 120
    agent.known_bids["ABM"], agent.known_asks["ABM"] = bids, asks
    if kind == 4: agent._mid_history.extend([98., 99., 99., 100., 100.])
    if direct: kernel.states[1] = AgentState(agent)
    return kernel, agent

def snapshot(kernel, agent):
    if isinstance(kernel, DirectKernel):
        kernel.states[1].sync()
        queue = [(t, s, r, encode(vars(kernel.arena.materialize(slot)))) for t, s, r, uid, slot in sorted(kernel.messages.queue)]
    else:
        queue = [(t, s, r, encode(vars(message))) for t, s, r, message in sorted(kernel.messages.queue)]
    return {"agent": encode({k: v for k, v in vars(agent).items() if k != "kernel"}), "queue": queue, "ledger": encode(kernel._msg_ledger.columns),
            "rng": encode(kernel.agent_latency_model.random_state.get_state()),
            "ids": [Order._order_id_counter, Message._Message__message_id_counter],
            "global_rng": encode(np.random.get_state()), "oracle": encode(vars(kernel.oracle)),
            "kernel_times": [kernel.current_time, kernel.ttl_messages if hasattr(kernel, "ttl_messages") else None,
                kernel.agent_current_times, kernel.agent_computation_delays, kernel._deliver_seq,
                kernel._deliver_seq_by_key, kernel._current_causal_uid]}

def lifecycle_cases():
    reset(); arena = MessageArena(); original = WakeupMsg(); slot = arena.original(original)
    arena.retain(slot); arena.retain(slot)
    assert arena.original(original) == slot and arena.materialize(slot) is original
    arena.release(slot)
    assert arena.materialize(slot) is original and arena.references[slot] == 1
    arena.release(slot)
    assert arena.raw[slot] is None and arena.payloads[slot] is None and arena.live == 0
    # External object remains valid; re-send keeps the exact original identity.
    again = arena.original(original); arena.retain(again)
    assert arena.materialize(again) is original and arena.uids[again] == original.message_id
    arena.release(again)
    next_slot = arena.compact(WAKE, ()); arena.retain(next_slot)
    assert next_slot == slot and arena.live == arena.peak_live == 1
    arena.release(next_slot)
    return [{"name": "arena_broadcast_release_external_resend_and_slot_reuse", "passed": True}]

def collision_cases():
    calendar = EventCalendar(); calendar.push(100, 1, 2, 8, 0)
    original = list(calendar.queue); original_keys = set(calendar.pending_keys)
    try: calendar.push(100, 1, 2, 8, 1)
    except ValueError: pass
    else: raise AssertionError("ambiguous repeated full key was admitted")
    assert calendar.queue == original and calendar.pending_keys == original_keys
    calendar.push(100, 1, 3, 8, 0)  # broadcast recipient disambiguates UID.
    assert calendar.pop() == (100, 1, 2, 8, 0)
    calendar.push(100, 1, 2, 8, 0)  # popped key is available for busy transfer.
    return [{"name": "calendar_duplicate_refused_before_mutation_and_broadcast_supported", "passed": True}]

def notification_cases():
    result = []
    for kind in (1, 2, 3, 4):
        for code, quantity, side, owned in ((ACCEPTED, 7, Side.BID, True),
            (EXECUTED, 2, Side.BID, True), (EXECUTED, 7, Side.ASK, True),
            (EXECUTED, 9, Side.BID, False), (CANCELLED, 7, Side.BID, True),
            (CANCELLED, 7, Side.ASK, False)):
            values = []
            for direct in (False, True):
                kernel, agent = setup(kind, direct, True, False, [(99, 3)], [(101, 4)])
                order = LimitOrder(1, 110, "ABM", 7, side, 100)
                if owned: agent.orders[order.order_id] = deepcopy(order)
                report = deepcopy(order); report.quantity = quantity; report.fill_price = 101
                message = SPECS[code][0](report)
                with warnings.catch_warnings(record=True) as observed:
                    warnings.simplefilter("always")
                    if direct: kernel._receive(kernel.states[1], 0, kernel.arena.original(message))
                    else: agent.receive_message(120, 0, message)
                values.append([snapshot(kernel, agent), [(w.category.__name__, str(w.message)) for w in observed]])
            assert values[0] == values[1], "notification differs: " + str(kind) + "/" + str(code)
            result.append({"name": "strategy_" + str(kind) + "_notification_" + str(code) + "_" + str(quantity) + "_" + str(owned), "passed": True})
    return result

def runner_cases():
    result = []
    for name, stop, busy, batch in (("batch_subuids", 140, 0, True),
                                  ("previous_clock_stop_boundary", 121, 0, False),
                                  ("busy_requeue", 200, 130, False)):
        values = []
        for direct in (False, True):
            kernel, agent = setup(1, direct, True, False, [(99, 3)], [(101, 4)])
            kernel.stop_time = stop; kernel.ttl_messages = 0
            kernel.agent_current_times[1] = busy
            # Fixed deterministic latency puts events at 170: the original
            # previous-clock condition permits the first pop past stop.
            kernel.agent_latency_model = ScenarioLatencyModel(2, {"model": "deterministic",
                "params": {"mean_ns": 0}}, np.random.RandomState(33009))
            if batch:
                messages = [SPECS[HOURS][0](100, 1000), SPECS[CLOSE_PRICE][0]({"ABM": 111})]
                envelope = MessageBatch(messages)
                kernel.send_message(0, 1, envelope)
            else:
                message = SPECS[CLOSE_PRICE][0]({"ABM": 111})
                kernel.send_message(0, 1, message, delay=-45 if busy else 0)
                kernel.send_message(0, 1, SPECS[CLOSE_PRICE][0]({"ABM": 112}), delay=20)
            kernel.runner()
            values.append(snapshot(kernel, agent))
            if direct and not kernel.messages.queue:
                assert kernel.arena.live == 0, "delivered arena messages were not reclaimed"
        assert values[0] == values[1], "runner boundary differs: " + name
        result.append({"name": "runner_" + name, "passed": True})
    # Collision may arise from a busy transfer, not only initial send.
    kernel, agent = setup(1, True, True, False, [], [])
    kernel.ttl_messages = 0; kernel.agent_current_times[1] = 130
    message = SPECS[CLOSE_PRICE][0]({"ABM": 111})
    slot = kernel.arena.original(message); kernel.arena.retain(slot); kernel.arena.retain(slot)
    kernel.messages.push(125, 0, 1, message.message_id, slot)
    kernel.messages.push(130, 0, 1, message.message_id, slot)
    try: kernel.runner()
    except ValueError: pass
    else: raise AssertionError("busy transfer collision was admitted")
    assert kernel.messages.queue == [(130, 0, 1, message.message_id, slot)]
    assert kernel.arena.materialize(slot) is message
    result.append({"name": "runner_busy_duplicate_domain_refusal", "passed": True})
    return result

def latency_cases():
    from optimizations import scalar_latency
    result = []
    for model, params in (("deterministic", {"mean_ns": 0}),
        ("uniform", {"min_ns": 0, "max_ns": 1000000000000}),
        ("log_normal", {"mean_ns": 1000, "sigma": 4., "min_ns": 0, "max_ns": 1000000000000}),
        ("pareto", {"alpha": .5, "min_ns": 1, "max_ns": 1000000000000})):
        for sender, recipient in ((1, 1), (1, 0)):
            a = ScenarioLatencyModel(2, {"model": model, "params": params}, np.random.RandomState(39009))
            b = ScenarioLatencyModel(2, {"model": model, "params": params}, np.random.RandomState(39009))
            before = encode(a.random_state.get_state())
            actual = [a.get_latency(sender, recipient) for _ in range(50)]
            candidate = [scalar_latency(b, sender, recipient) for _ in range(50)]
            assert actual == candidate and encode(a.random_state.get_state()) == encode(b.random_state.get_state())
            if sender == recipient: assert before == encode(a.random_state.get_state())
            result.append({"name": "latency_" + model + "_" + str(sender) + "_" + str(recipient), "passed": True})
    return result

def failed_hook_cases():
    from audit import static_admission
    from abides_core import abides, kernel as core_kernel
    from abides_fork import config
    from abides_markets.agents.trading_agent import TradingAgent
    result = []
    for module, name in ((abides, "Kernel"), (core_kernel.Kernel, "initialize"),
                         (config.ScenarioLatencyModel, "get_latency"),
                         (TradingAgent, "get_current_spread"),
                         (ExchangeAgent, "logEvent")):
        original = getattr(module, name); present = name in vars(module)
        setattr(module, name, lambda *args, **kwargs: None)
        try:
            try: static_admission()
            except ValueError: pass
            else: raise AssertionError("replaced canonical binding was admitted: " + name)
        finally:
            if present: setattr(module, name, original)
            else: delattr(module, name)
        result.append({"name": "admission_replaced_" + name, "passed": True})
    for target, name in (("agent", "get_current_spread"), ("agent", "order_accepted"),
        ("exchange", "logEvent"), ("exchange", "receive_message"),
        ("latency", "get_latency"), ("oracle", "observe_price"), ("kernel", "set_agent_compute_delay")):
        canonical, agent = setup(1, False, True, False, [], [])
        exchange = canonical.agents[0]; latency = canonical.agent_latency_model; oracle = canonical.oracle
        value = {"agent": agent, "exchange": exchange, "latency": latency, "oracle": oracle}.get(target)
        custom = {"oracle": oracle}
        if target == "kernel": custom[name] = lambda *args, **kwargs: None
        else: setattr(value, name, lambda *args, **kwargs: None)
        try:
            try: DirectKernel(canonical.agents, start_time=1, stop_time=2000,
                random_state=np.random.RandomState(34009), agent_latency_model=latency,
                custom_properties=custom)
            except ValueError: pass
            else: raise AssertionError("instance override was admitted: " + target + "." + name)
        finally:
            if value is not None: delattr(value, name)
        result.append({"name": "admission_instance_" + target + "_" + name, "passed": True})
    return result

def transition_cases():
    results = []
    for kind in (1, 2, 3, 4):
        for operation, ready, closed, bids, asks in (
            ("wake_initial", False, False, [], []),
            ("wake_open", True, False, [(99, 3)], [(101, 4)]),
            ("wake_closed", True, True, [(99, 3)], [(101, 4)]),
            ("spread_empty", True, False, [], []),
            ("spread_bid_only", True, False, [(99, 3)], []),
            ("spread_both", True, False, [(99, 3)], [(101, 4)]),
            ("spread_closed", True, True, [(99, 3)], [(101, 4)])):
            values = []
            for direct in (False, True):
                kernel, agent = setup(kind, direct, ready, closed, bids, asks)
                if operation.startswith("wake"):
                    if direct: kernel._wake(kernel.states[1])
                    else: agent.wakeup(120)
                else:
                    agent.state = "AWAITING_SPREAD"
                    if direct: kernel.states[1].read_original()
                    message = SPECS[SPREAD][0]("ABM", closed, 1, bids, asks, 100)
                    if direct: kernel._receive(kernel.states[1], 0, kernel.arena.original(message))
                    else: agent.receive_message(120, 0, message)
                values.append(snapshot(kernel, agent))
            assert values[0] == values[1], "direct finite transition differs: " + str(kind) + "/" + operation
            results.append({"name": "strategy_" + str(kind) + "_" + operation, "passed": True})
    return results

def main():
    authenticate()
    ensure_static_admission()
    parser = argparse.ArgumentParser(); parser.add_argument("--out", default=str(HERE / "FINITE_RESULT.json")); args = parser.parse_args()
    destination = Path(args.out)
    if destination.exists(): raise ValueError("finite evidence exists; preserve it")
    result = {"all_passed": False, "rankable": False, "timing_claim": False, "cases": [], "failures": []}
    try:
        result["cases"] = (arena_cases() + calendar_cases() + lifecycle_cases() + collision_cases()
            + transition_cases() + notification_cases() + runner_cases() + latency_cases() + failed_hook_cases())
        result["all_passed"] = True
    except Exception as error: result["failures"].append({"type": type(error).__name__, "message": str(error)})
    result["engine_sha256"] = hashlib.sha256((HERE / "engine.py").read_bytes()).hexdigest()
    result["control_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2)); return 0 if result["all_passed"] else 1

if __name__ == "__main__": raise SystemExit(main())
