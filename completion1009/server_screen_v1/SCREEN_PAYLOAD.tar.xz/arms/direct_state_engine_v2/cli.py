#!/usr/bin/env python3
"""Compatibility entry alias for the reviewable static CLI."""
from static_cli import main
if __name__ == "__main__": main()
