"""Static direct-kernel install, with source proof performed by preflight.py."""
from contextlib import contextmanager

def quiet_summary_writer(self):
    """Exact named diagnostic-IO suppression used by both comparison arms."""
    return None

def authenticate():
    # Explicit diagnostic entry for controls; never called by static CLI.
    from audit import prove_sources
    prove_sources()
    from abides_core import abides
    from abides_fork import config, trace
    return abides, config, trace

_static_ready = False
_last_episode = None
_callable_bindings = None
def ensure_static_admission():
    global _static_ready, _callable_bindings
    if not _static_ready:
        from audit import static_admission
        static_admission()
        from audit import callable_bindings
        _callable_bindings = callable_bindings()
        _static_ready = True

@contextmanager
def enabled(active=True):
    from abides_core import abides
    from abides_fork import config, trace
    if not active:
        yield trace.extract_message_trace
        return
    ensure_static_admission()
    from engine import DirectKernel, ColumnLedger
    from column_trace import make_extractor
    from optimizations import scalar_latency
    from audit import cross_bindings, check_callable_bindings
    # Cheap cross-binding proof still runs once per episode; full module checks
    # run once per process. No source compilation or fresh exec on this path.
    cross_bindings()
    check_callable_bindings(_callable_bindings)
    original_kernel, original_latency = abides.Kernel, config.ScenarioLatencyModel.get_latency
    extractor = make_extractor(ColumnLedger, trace.extract_message_trace,
                               trace.MESSAGE_TRACE_COLUMNS, trace._MSG_DTYPES)
    abides.Kernel, config.ScenarioLatencyModel.get_latency = DirectKernel, scalar_latency
    try:
        yield extractor
    finally:
        abides.Kernel, config.ScenarioLatencyModel.get_latency = original_kernel, original_latency

def capture_episode(kernel):
    """Source-closed probe data only; no callbacks/simulation/output mutation."""
    global _last_episode
    _last_episode = {"candidate": "direct_state_engine_v2", "direct_active": True,
        "fallback_used": False, "counts": dict(kernel.direct_counts),
        "ttl_messages": kernel.ttl_messages, "arena_live": kernel.arena.live,
        "arena_peak_live": kernel.arena.peak_live, "arena_slots": len(kernel.arena.codes),
        "calendar_pending": kernel.messages.qsize()}

def active_probe():
    return None if _last_episode is None else dict(_last_episode)
