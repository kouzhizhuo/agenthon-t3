"""Reviewable fused four-strategy state engine v2 prototype; not production.

The event loop dispatches compact message tags directly to closed strategy
state transitions. Original order-book mutations, RandomState and oracle are
the first slice's bridge. Python integer/float semantics stay in this version.
No performance or equivalence claim exists before differential controls run.
"""
from copy import deepcopy
import heapq
import warnings

from abides_core.message import Message, MessageBatch, WakeupMsg
from abides_core.kernel import Kernel, logger
from abides_fork.agents import NoiseTrader, MarketMaker, ValueTrader, MomentumTrader
from abides_markets.agents.exchange_agent import ExchangeAgent
from abides_markets.agents.trading_agent import TradingAgent
from abides_markets.orders import LimitOrder, Side
from abides_markets.messages.market import (MarketHoursRequestMsg, MarketHoursMsg,
    MarketClosePriceRequestMsg, MarketClosePriceMsg, MarketClosedMsg)
from abides_markets.messages.query import (QuerySpreadMsg, QuerySpreadResponseMsg,
    QueryLastTradeResponseMsg, QueryOrderStreamResponseMsg, QueryTransactedVolResponseMsg)
from abides_markets.messages.order import LimitOrderMsg, CancelOrderMsg
from abides_markets.messages.orderbook import (OrderAcceptedMsg, OrderExecutedMsg,
    OrderCancelledMsg, OrderPartialCancelledMsg, OrderModifiedMsg, OrderReplacedMsg)
from t3_canonical_engine import CanonicalKernel, ColumnLedger

RAW = 0
WAKE = 1
HOURS_REQUEST = 2
HOURS = 3
CLOSE_REQUEST = 4
CLOSE_PRICE = 5
CLOSED = 6
SPREAD_REQUEST = 7
SPREAD = 8
LIMIT = 9
CANCEL = 10
ACCEPTED = 11
EXECUTED = 12
CANCELLED = 13
PART_CANCELLED = 14
MODIFIED = 15
REPLACED = 16
LAST_TRADE = 17
ORDER_STREAM = 18
TRANSACTED = 19
BATCH = 20

# Exact class lookup avoids subclass admission by accident. Integer tags are
# internal only; ledger names and construction-counter order remain original.
SPECS = {
    WAKE: (WakeupMsg, ()),
    HOURS_REQUEST: (MarketHoursRequestMsg, ()),
    HOURS: (MarketHoursMsg, ("mkt_open", "mkt_close")),
    CLOSE_REQUEST: (MarketClosePriceRequestMsg, ()),
    CLOSE_PRICE: (MarketClosePriceMsg, ("close_prices",)),
    CLOSED: (MarketClosedMsg, ()),
    SPREAD_REQUEST: (QuerySpreadMsg, ("symbol", "depth")),
    SPREAD: (QuerySpreadResponseMsg, ("symbol", "mkt_closed", "depth", "bids", "asks", "last_trade")),
    LIMIT: (LimitOrderMsg, ("order",)),
    CANCEL: (CancelOrderMsg, ("order", "tag", "metadata")),
    ACCEPTED: (OrderAcceptedMsg, ("order",)),
    EXECUTED: (OrderExecutedMsg, ("order",)),
    CANCELLED: (OrderCancelledMsg, ("order",)),
    PART_CANCELLED: (OrderPartialCancelledMsg, ("new_order",)),
    MODIFIED: (OrderModifiedMsg, ("new_order",)),
    REPLACED: (OrderReplacedMsg, ("old_order", "new_order")),
    LAST_TRADE: (QueryLastTradeResponseMsg, ("symbol", "mkt_closed", "last_trade")),
    ORDER_STREAM: (QueryOrderStreamResponseMsg, ("symbol", "mkt_closed", "length", "orders")),
    TRANSACTED: (QueryTransactedVolResponseMsg, ("symbol", "mkt_closed", "bid_volume", "ask_volume")),
    BATCH: (MessageBatch, ("messages",)),
}
CODES = {cls: code for code, (cls, _) in SPECS.items()}
STRATEGIES = {NoiseTrader: 1, MarketMaker: 2, ValueTrader: 3, MomentumTrader: 4}
DEFAULT_CANCEL_METADATA = TradingAgent.cancel_order.__defaults__[-1]

def reserve_uid():
    uid = Message._Message__message_id_counter
    Message._Message__message_id_counter += 1
    return uid

class MessageArena:
    """Live compact messages; only arena-owned references are reclaimed.

    Pending events and active callbacks own counted references. A busy requeue
    transfers the same reference; a broadcast acquires another. Reclaim never
    edits external order/log/agent objects, and an externally retained message
    sent later keeps its original identity and UID.
    """
    __slots__ = ("codes", "uids", "payloads", "raw", "references", "free", "original_slots", "live", "peak_live")
    def __init__(self):
        self.codes, self.uids, self.payloads, self.raw = [], [], [], []
        self.references, self.free, self.original_slots = [], [], {}
        self.live = self.peak_live = 0
    def append(self, code, uid, payload, raw=None):
        if self.free:
            index = self.free.pop()
            self.codes[index], self.uids[index] = code, uid
            self.payloads[index], self.raw[index] = payload, raw
            self.references[index] = 0
        else:
            index = len(self.codes)
            self.codes.append(code); self.uids.append(uid)
            self.payloads.append(payload); self.raw.append(raw)
            self.references.append(0)
        self.live += 1
        self.peak_live = max(self.peak_live, self.live)
        if raw is not None:
            self.original_slots[id(raw)] = index
        return index
    def original(self, message):
        existing = self.original_slots.get(id(message))
        if existing is not None and self.raw[existing] is message:
            self.refresh(existing)
            return existing
        code = CODES.get(type(message), RAW)
        payload = tuple(getattr(message, name) for name in SPECS[code][1]) if code else ()
        return self.append(code, message.message_id, payload, message)
    def compact(self, code, payload):
        if code not in SPECS: raise ValueError("compact message tag is unknown")
        if len(payload) != len(SPECS[code][1]): raise ValueError("compact payload arity differs")
        return self.append(code, reserve_uid(), tuple(payload))
    def retain(self, index):
        if self.codes[index] is None:
            raise ValueError("retaining reclaimed message slot")
        self.references[index] += 1
    def release(self, index):
        if self.references[index] <= 0:
            raise ValueError("unbalanced message reference release")
        self.references[index] -= 1
        if self.references[index] == 0:
            message = self.raw[index]
            if message is not None and self.original_slots.get(id(message)) == index:
                del self.original_slots[id(message)]
            self.codes[index] = self.uids[index] = None
            self.payloads[index] = self.raw[index] = None
            self.live -= 1
            self.free.append(index)
    def refresh(self, index):
        message = self.raw[index]
        if message is None:
            return
        code = self.codes[index]
        if message.message_id != self.uids[index]:
            raise ValueError("direct slice refuses mutation of a pending message UID")
        if code:
            self.payloads[index] = tuple(getattr(message, name) for name in SPECS[code][1])
    def materialize(self, index):
        existing = self.raw[index]
        if existing is not None: return existing
        code = self.codes[index]
        cls, fields = SPECS[code]
        # Dataclass fields are populated before __post_init__ sets message_id.
        # Reconstruct without another counter increment at the book boundary.
        message = object.__new__(cls)
        for name, value in zip(fields, self.payloads[index]): setattr(message, name, value)
        message.message_id = self.uids[index]
        self.raw[index] = message
        self.original_slots[id(message)] = index
        return message
    def type_name(self, index):
        code = self.codes[index]
        return SPECS[code][0].__name__ if code else self.raw[index].type()
    def order_id(self, index):
        code = self.codes[index]
        if code in (LIMIT, CANCEL, ACCEPTED, EXECUTED, CANCELLED):
            return getattr(self.payloads[index][0], "order_id", None)
        if code: return None
        return getattr(getattr(self.raw[index], "order", None), "order_id", None)

class EventCalendar:
    """Exact full-key domain, with ambiguous repeated pending keys refused.

    Original message comparison does not define a total ordering for distinct
    objects sharing one UID/full envelope. The admitted direct domain excludes
    that collision; it never invents fifth-slot tie order. Different recipients
    may share one raw message/UID. Busy requeues are checked before heap mutation.
    """
    __slots__ = ("queue", "pending_keys")
    def __init__(self): self.queue, self.pending_keys = [], set()
    def empty(self): return not self.queue
    def qsize(self): return len(self.queue)
    def push(self, time, sender, recipient, uid, slot):
        key = (time, sender, recipient, uid)
        if key in self.pending_keys:
            raise ValueError("direct slice refuses duplicate pending complete calendar key")
        heapq.heappush(self.queue, (time, sender, recipient, uid, slot))
        self.pending_keys.add(key)
    def pop(self):
        result = heapq.heappop(self.queue)
        self.pending_keys.remove(result[:4])
        return result

class AgentState:
    """Owned compact scheduling state; trading dictionaries are original owners."""
    __slots__ = ("agent", "kind", "id", "symbol", "interval", "current_time",
                 "state", "first_wake", "mkt_open", "mkt_close", "mkt_closed",
                 "rng", "orders", "holdings", "last_trade", "known_bids", "known_asks", "mid_history")
    def __init__(self, agent):
        self.agent, self.kind, self.id = agent, STRATEGIES[type(agent)], agent.id
        self.symbol, self.interval, self.rng = agent.symbol, agent.interval_ns, agent.random_state
        self.orders, self.holdings, self.last_trade = agent.orders, agent.holdings, agent.last_trade
        self.known_bids, self.known_asks = agent.known_bids, agent.known_asks
        self.mid_history = agent._mid_history if type(agent) is MomentumTrader else None
        self.read_original()
    def read_original(self):
        a = self.agent
        self.current_time, self.state, self.first_wake = a.current_time, a.state, a.first_wake
        self.mkt_open, self.mkt_close, self.mkt_closed = a.mkt_open, a.mkt_close, a.mkt_closed
    def sync(self):
        a = self.agent
        a.current_time, a.state, a.first_wake = self.current_time, self.state, self.first_wake
        a.mkt_open, a.mkt_close, a.mkt_closed = self.mkt_open, self.mkt_close, self.mkt_closed

class DirectKernel(CanonicalKernel):
    """Fused scheduler and fixed-strategy transitions, with exact book bridge."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.agents or type(self.agents[0]) is not ExchangeAgent:
            raise ValueError("direct slice requires the pinned exchange first")
        if any(type(a) not in STRATEGIES for a in self.agents[1:]):
            raise ValueError("direct slice refuses unknown strategy classes")
        if [a.id for a in self.agents] != list(range(len(self.agents))):
            raise ValueError("direct slice requires canonical contiguous IDs")
        if self.gym_agents: raise ValueError("direct slice has no Gym adapter")
        if logger.isEnabledFor(10) or self.show_trace_messages:
            raise ValueError("direct slice refuses debug callback logging mode")
        from audit import admit_episode
        admit_episode(self)
        self.messages, self.arena = EventCalendar(), MessageArena()
        self.states = [None] * len(self.agents)
        self.direct_counts = {"wake": 0, "receive": 0, "act": 0,
                              "exchange_query": 0, "exchange_book_bridge": 0, "raw_bridge": 0}
    def initialize(self):
        # Retain exact oracle/init/first-wakeup/summary ordering.
        super().initialize()
        for a in self.agents[1:]: self.states[a.id] = AgentState(a)
    def terminate(self):
        for state in self.states:
            if state is not None: state.sync()
        result = super().terminate()
        from installed import capture_episode
        capture_episode(self)
        return result
    def _schedule(self, slot, sender, recipient, delay):
        sent = self.current_time + self.agent_computation_delays[sender] + self.current_agent_additional_delay + delay
        if self.agent_latency_model is not None:
            latency = self.agent_latency_model.get_latency(sender_id=sender, recipient_id=recipient)
            receive = sent + int(latency)
        else:
            latency = self.agent_latency[sender][recipient]
            noise = self.random_state.choice(len(self.latency_noise), p=self.latency_noise)
            receive = sent + int(latency + noise)
        uid = self.arena.uids[slot]
        self.messages.push(receive, sender, recipient, uid, slot)
        self.arena.retain(slot)
        if self.arena.codes[slot] == BATCH:
            # Batch UID is the outer calendar tie key; each submessage has its
            # own ledger and causal delivery sequence, as in the incumbent.
            for message in self.arena.payloads[slot][0]:
                order = getattr(message, "order", None)
                self._msg_ledger.append_values(message.message_id, sender, recipient, sent, receive,
                    receive - sent, message.type(), getattr(order, "order_id", None), self._current_causal_uid)
        else:
            self._msg_ledger.append_values(uid, sender, recipient, sent, receive, receive - sent,
                self.arena.type_name(slot), self.arena.order_id(slot), self._current_causal_uid)
    def send_message(self, sender_id, recipient_id, message, delay=0):
        self._schedule(self.arena.original(message), sender_id, recipient_id, delay)
    def _send(self, sender, recipient, code, payload=(), delay=0):
        self._schedule(self.arena.compact(code, payload), sender, recipient, delay)
    def logical_calendar(self):
        """Untimed control projection back to original four-field queue shape."""
        return [(time, sender, recipient, self.arena.materialize(slot))
                for time, sender, recipient, uid, slot in self.messages.queue]
    def set_wakeup(self, sender_id, requested_time=None):
        if requested_time is None: requested_time = self.current_time + 1
        if self.current_time and requested_time < self.current_time:
            raise ValueError("set_wakeup() called with requested time not in future",
                             "current_time:", self.current_time, "requested_time:", requested_time)
        slot = self.arena.compact(WAKE, ())
        self.messages.push(requested_time, sender_id, sender_id, self.arena.uids[slot], slot)
        self.arena.retain(slot)
    def runner(self, agent_actions=None):
        if agent_actions is not None: raise ValueError("direct slice refuses Gym actions")
        # Keep the original previous-clock stop condition, including its pop
        # boundary. Requeue retains the same UID and payload identity.
        while not self.messages.empty() and self.current_time and self.current_time <= self.stop_time:
            self.current_time, sender, recipient, uid, slot = self.messages.pop()
            self.ttl_messages += 1
            self.current_agent_additional_delay = 0
            if self.agent_current_times[recipient] > self.current_time:
                self.messages.push(self.agent_current_times[recipient], sender, recipient, uid, slot)
                continue
            self.agent_current_times[recipient] = self.current_time
            self.arena.refresh(slot)
            code = self.arena.codes[slot]
            if code == WAKE:
                self._current_causal_uid = uid
                self._deliver_seq_by_key[uid, recipient] = self._deliver_seq; self._deliver_seq += 1
                self._msg_ledger.append_values(uid, recipient, recipient, None, self.current_time, 0, "AGENT_WAKEUP", None, None)
                try:
                    state = self.states[recipient]
                    if state is None: result = self.agents[recipient].wakeup(self.current_time)
                    else: result = self._wake(state)
                    self.agent_current_times[recipient] += self.agent_computation_delays[recipient] + self.current_agent_additional_delay
                finally:
                    self.arena.release(slot)
                if result is not None: return {"done": False, "result": result}
            else:
                try:
                    if code == BATCH:
                        # Borrow the original live list; callbacks see mutations
                        # to subsequent messages/list membership exactly as the
                        # original for-loop would. Outer slot lives to loop end.
                        for message in self.arena.payloads[slot][0]:
                            subslot = self.arena.original(message)
                            self.arena.retain(subslot)
                            try: self._deliver_nonwake(sender, recipient, subslot)
                            finally: self.arena.release(subslot)
                    else:
                        self._deliver_nonwake(sender, recipient, slot)
                finally:
                    self.arena.release(slot)
        return {"done": True, "result": None}
    def _deliver_nonwake(self, sender, recipient, slot):
        self.arena.refresh(slot)
        self.agent_current_times[recipient] += self.agent_computation_delays[recipient] + self.current_agent_additional_delay
        uid = self.arena.uids[slot]
        self._current_causal_uid = uid
        self._deliver_seq_by_key[uid, recipient] = self._deliver_seq; self._deliver_seq += 1
        state = self.states[recipient]
        if state is None: self._exchange(sender, slot)
        else: self._receive(state, sender, slot)
    def _wake(self, s):
        self.direct_counts["wake"] += 1
        s.current_time = self.current_time; s.sync()
        a = s.agent
        if s.first_wake:
            a.logEvent("HOLDINGS_UPDATED", s.holdings)
            s.first_wake = False
            self._send(s.id, a.exchange_id, CLOSE_REQUEST)
        if s.mkt_open is None: self._send(s.id, a.exchange_id, HOURS_REQUEST)
        if not s.mkt_open or not s.mkt_close or s.mkt_closed:
            s.sync(); return None
        self.set_wakeup(s.id, self.current_time + s.interval)
        self._send(s.id, a.exchange_id, SPREAD_REQUEST, (s.symbol, 1))
        s.state = "AWAITING_SPREAD"; s.sync()
        return None
    def _last_trade(self, s, symbol, price):
        s.last_trade[symbol] = price
        if s.mkt_closed: s.agent.daily_close_price[symbol] = price
    def _receive(self, s, sender, slot):
        self.direct_counts["receive"] += 1
        s.current_time = self.current_time; s.sync()
        a = s.agent; code = self.arena.codes[slot]; payload = self.arena.payloads[slot]
        had_hours = s.mkt_open is not None and s.mkt_close is not None
        if code == HOURS:
            s.mkt_open, s.mkt_close = payload
        elif code == CLOSE_PRICE:
            for symbol, price in payload[0].items(): s.last_trade[symbol] = price
        elif code == CLOSED:
            a.logEvent("MKT_CLOSED"); s.mkt_closed = True
        elif code in (ACCEPTED, EXECUTED, CANCELLED):
            order = payload[0]
            if a.log_orders:
                a.logEvent({ACCEPTED: "ORDER_ACCEPTED", EXECUTED: "ORDER_EXECUTED", CANCELLED: "ORDER_CANCELLED"}[code],
                           order.to_dict(), deepcopy_event=False)
            if code == EXECUTED:
                quantity = order.quantity if order.side.is_bid() else -1 * order.quantity
                symbol = order.symbol
                if symbol in s.holdings: s.holdings[symbol] += quantity
                else: s.holdings[symbol] = quantity
                if s.holdings[symbol] == 0: del s.holdings[symbol]
                s.holdings["CASH"] -= quantity * order.fill_price
                if order.order_id in s.orders:
                    original = s.orders[order.order_id]
                    if order.quantity >= original.quantity: del s.orders[order.order_id]
                    else: original.quantity -= order.quantity
                else: warnings.warn(f"Execution received for order not in orders list: {order}")
                a.logEvent("HOLDINGS_UPDATED", s.holdings)
            elif code == CANCELLED:
                if order.order_id in s.orders: del s.orders[order.order_id]
                else: warnings.warn(f"Cancellation received for order not in orders list: {order}")
        elif code == SPREAD:
            symbol, closed, depth, bids, asks, price = payload
            if closed: s.mkt_closed = True
            self._last_trade(s, symbol, price)
            s.known_bids[symbol], s.known_asks[symbol] = bids, asks
            a.logEvent("BID_DEPTH", bids); a.logEvent("ASK_DEPTH", asks)
            a.logEvent("IMBALANCE", [sum([x[1] for x in bids]), sum([x[1] for x in asks])])
            a.book = ""
        elif code == LAST_TRADE:
            symbol, closed, price = payload
            if closed: s.mkt_closed = True
            self._last_trade(s, symbol, price)
        elif code == ORDER_STREAM:
            symbol, closed, length, orders = payload
            if closed: s.mkt_closed = True
            a.stream_history[symbol] = orders
        elif code == TRANSACTED:
            symbol, closed, bid, ask = payload
            if closed: s.mkt_closed = True
            a.transacted_volume[symbol] = (bid, ask)
        else:
            # Rare notification/subscription semantics stay exact original;
            # synchronize before crossing and refresh owned scalar state after.
            s.sync(); self.direct_counts["raw_bridge"] += 1
            TradingAgent.receive_message(a, self.current_time, sender, self.arena.materialize(slot))
            s.read_original()
            had_hours = True  # original handler already performed this transition
        have_hours = s.mkt_open is not None and s.mkt_close is not None
        if have_hours and not had_hours: self.set_wakeup(s.id, s.mkt_open + 0)
        if s.state == "AWAITING_SPREAD" and code == SPREAD:
            if not s.mkt_closed: self._act(s)
            s.state = "AWAITING_WAKEUP"
        s.sync()
    def _place(self, s, quantity, side, price):
        a = s.agent
        # All four prescribed formulas produce positive quantity, plain orders,
        # ignore_risk=True, no flags/tag. Constructor and copy semantics remain.
        order = LimitOrder(s.id, self.current_time, s.symbol, quantity, side, price)
        if quantity <= 0: raise ValueError("direct strategy produced nonpositive order")
        s.orders[order.order_id] = deepcopy(order)
        self._send(s.id, a.exchange_id, LIMIT, (order,))
        if a.log_orders: a.logEvent("ORDER_SUBMITTED", order.to_dict(), deepcopy_event=False)
    def _act(self, s):
        self.direct_counts["act"] += 1
        a = s.agent
        bid = s.known_bids[s.symbol][0][0] if s.known_bids[s.symbol] else None
        ask = s.known_asks[s.symbol][0][0] if s.known_asks[s.symbol] else None
        if s.kind == 1:
            size = int(max(1, round(s.rng.normal(a.order_size_mean, a.order_size_std))))
            buy = bool(s.rng.randint(0, 2)); offset = int(s.rng.randint(0, a.price_offset_ticks + 1))
            if buy:
                anchor = int(ask) if ask else (int(bid) if bid else a.reference_price)
                self._place(s, size, Side.BID, anchor + offset)
            else:
                anchor = int(bid) if bid else (int(ask) if ask else a.reference_price)
                self._place(s, size, Side.ASK, anchor - offset)
        elif s.kind == 2:
            mid = int((bid + ask) // 2) if bid and ask else a.reference_price
            for order in s.orders.values():
                if isinstance(order, LimitOrder):
                    self._send(s.id, a.exchange_id, CANCEL, (order, None, DEFAULT_CANCEL_METADATA))
                    if a.log_orders: a.logEvent("CANCEL_SUBMITTED", order.to_dict(), deepcopy_event=False)
            half = a.spread_ticks // 2
            for level in range(a.depth_levels):
                self._place(s, a.size_per_level, Side.BID, mid - half - level)
                self._place(s, a.size_per_level, Side.ASK, mid + half + level)
        else:
            if bid and ask: mid = (int(bid) + int(ask)) / 2.0
            elif bid: mid = float(bid)
            elif ask: mid = float(ask)
            else: return
            if s.kind == 3:
                fundamental = int(a.oracle.observe_price(s.symbol, self.current_time, s.rng, sigma_n=a.sigma_n))
                size = int(max(1, round(a.order_size_mean)))
                if mid < fundamental - a.threshold_ticks and ask: self._place(s, size, Side.BID, int(ask))
                elif mid > fundamental + a.threshold_ticks and bid: self._place(s, size, Side.ASK, int(bid))
            elif s.kind == 4:
                s.mid_history.append(mid)
                if len(s.mid_history) > a.lookback + 1: s.mid_history.pop(0)
                if len(s.mid_history) <= a.lookback: return
                past = s.mid_history[0]; size = int(max(1, round(a.order_size_mean)))
                if mid > past + a.threshold_ticks and ask: self._place(s, size, Side.BID, int(ask))
                elif mid < past - a.threshold_ticks and bid: self._place(s, size, Side.ASK, int(bid))
    def _exchange(self, sender, slot):
        exchange = self.agents[0]; exchange.current_time = self.current_time
        code, payload = self.arena.codes[slot], self.arena.payloads[slot]
        if code in (HOURS_REQUEST, CLOSE_REQUEST, SPREAD_REQUEST) and self.current_time <= exchange.mkt_close:
            self.direct_counts["exchange_query"] += 1
            self.set_agent_compute_delay(0, exchange.computation_delay)
            message = self.arena.materialize(slot)
            exchange.logEvent(message.type(), message)
            if code == HOURS_REQUEST:
                self.set_agent_compute_delay(0, 0)
                self._send(0, sender, HOURS, (exchange.mkt_open, exchange.mkt_close))
            elif code == CLOSE_REQUEST: exchange.market_close_price_subscriptions.append(sender)
            else:
                symbol, depth = payload
                if symbol not in exchange.order_books:
                    warnings.warn(f"Bid-ask spread request discarded. Unknown symbol: {symbol}")
                else:
                    book = exchange.order_books[symbol]
                    self._send(0, sender, SPREAD, (symbol, self.current_time > exchange.mkt_close, depth,
                        book.get_l2_bid_data(depth), book.get_l2_ask_data(depth), book.last_trade))
        else:
            # Exact existing matching, STP, history, depth/metric logging,
            # subscriptions and pipeline-delay sends remain this slice's bridge.
            self.direct_counts["exchange_book_bridge"] += 1
            exchange.receive_message(self.current_time, sender, self.arena.materialize(slot))
