#!/usr/bin/env python3
"""Run prepared direct engine finite/full-state controls only when authorized."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUTPUT = ROOT / "verification/direct_state_engine_v2_controls_v1"
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def bindings():
    return {"sources": {p.name: sha(p) for p in HERE.glob("*.py") if not p.name.startswith("._")},
            "pins_sha256": sha(HERE / "PINNED_RUNTIME.json"),
            "static_binding_pins_sha256": sha(HERE / "STATIC_BINDING_PINS.json"),
            "runtime": {str(p.relative_to(HERE / "runtime")): sha(p) for p in sorted((HERE / "runtime").rglob("*.py"))
                        if not p.name.startswith("._") and "__pycache__" not in p.parts}}
def launch(command, output):
    env = os.environ.copy(); env["PYTHONPATH"] = str(ROOT.parent / ".runtime"); env["PYTHONDONTWRITEBYTECODE"] = "1"
    with output.open("w") as stream: result = subprocess.run(command, cwd=HERE, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    if result.returncode: raise ValueError("control command failed; retained log: " + str(output))
def main():
    global OUTPUT
    parser = argparse.ArgumentParser(); parser.add_argument("--output-dir", default=str(OUTPUT)); args = parser.parse_args()
    OUTPUT = Path(args.output_dir).resolve()
    if OUTPUT.exists(): raise ValueError("control evidence exists; preserve failures")
    OUTPUT.mkdir(parents=True); before = bindings()
    result = {"all_passed": False, "rankable": False, "official_gate": False, "timing_claim": False,
              "bindings": before, "cases": [], "failures": []}
    try:
        launch(["/usr/bin/python3", str(HERE / "finite_controls.py"), "--out", str(OUTPUT / "FINITE_RESULT.json")], OUTPUT / "finite.log")
        finite = json.loads((OUTPUT / "FINITE_RESULT.json").read_text())
        if finite["all_passed"] is not True: raise ValueError("finite controls failed")
        for arm in ("canonical", "direct"):
            directory = OUTPUT / arm; directory.mkdir()
            launch(["/usr/bin/python3", str(HERE / "control_worker.py"), "--arm", arm, "--out", str(directory)], directory / "run.log")
        sys.path.insert(0, str(ROOT.parent / ".runtime")); import pandas as pd
        a, b = [pickle.loads((OUTPUT / arm / "VALUES.pkl").read_bytes()) for arm in ("canonical", "direct")]
        assert len(a) == len(b) == 4
        for original, candidate in zip(a, b):
            assert original["seed"] == candidate["seed"]
            for x, y in zip(original["frames"], candidate["frames"]): pd.testing.assert_frame_equal(x, y, check_exact=True, check_dtype=True, rtol=0, atol=0)
            for label, x, y in zip(("Parquet", "logical business state/aliases", "RNG", "IDs", "warnings"), original["payload"], candidate["payload"]):
                assert x == y, label + " differs at seed " + str(original["seed"])
            assert candidate["stats"]["direct_counts"]["act"] > 0, "direct strategy path unexercised"
            assert candidate["stats"]["arena_slots"] < candidate["stats"]["ttl_messages"], "arena lifetime reclaim path unexercised"
            result["cases"].append({"seed": original["seed"], "passed": True, **candidate["stats"]})
        assert bindings() == before, "source changed during controls"
        result.update(all_passed=True, finite_cases=len(finite["cases"]), sources_unchanged=True)
    except Exception as error: result["failures"].append({"type": type(error).__name__, "message": str(error)})
    (OUTPUT / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "bindings"}, indent=2)); return 0 if result["all_passed"] else 1
if __name__ == "__main__": raise SystemExit(main())
