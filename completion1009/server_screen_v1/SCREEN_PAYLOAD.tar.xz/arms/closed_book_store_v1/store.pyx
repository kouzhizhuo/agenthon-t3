# cython: language_level=3, boundscheck=True, wraparound=True
"""Native owned plain-order queues and price index for the fixed strategy CLI."""
from libc.stdlib cimport realloc, free
from bisect import bisect_left
from abides_markets.orders import Side

cdef struct Link:
    Py_ssize_t previous
    Py_ssize_t next


cdef class NativeLevel:
    cdef Link* links
    cdef Py_ssize_t capacity, head, tail, count, free_head
    cdef list roots
    cdef dict slots
    cdef object quantity
    cdef public object price, side

    def __cinit__(self):
        self.links = NULL
        self.capacity = self.count = 0
        self.head = self.tail = self.free_head = -1
        self.roots = []
        self.slots = {}
        self.quantity = 0

    def __init__(self, rows):
        if not rows:
            raise ValueError("At least one LimitOrder must be given when initialising a PriceLevel.")
        self.price, self.side = rows[0][0].limit_price, rows[0][0].side
        for order, metadata in rows:
            self.add_order(order, metadata)

    def __dealloc__(self):
        free(self.links)

    cdef Py_ssize_t allocate(self, object row) except -2:
        cdef Py_ssize_t slot, capacity
        cdef Link* fresh
        if self.free_head >= 0:
            slot = self.free_head
            self.free_head = self.links[slot].next
            self.roots[slot] = row
            return slot
        slot = len(self.roots)
        if slot >= self.capacity:
            capacity = 16 if self.capacity == 0 else self.capacity * 2
            if capacity < self.capacity or capacity > (<Py_ssize_t>9223372036854775807) // sizeof(Link):
                raise MemoryError("closed book capacity overflow")
            fresh = <Link*>realloc(self.links, capacity * sizeof(Link))
            if fresh == NULL:
                raise MemoryError("closed book allocation failed")
            self.links = fresh
            self.capacity = capacity
        self.roots.append(row)
        return slot

    cdef object detach(self, Py_ssize_t slot):
        cdef Py_ssize_t before = self.links[slot].previous, after = self.links[slot].next
        cdef object row = self.roots[slot]
        if before >= 0:
            self.links[before].next = after
        else:
            self.head = after
        if after >= 0:
            self.links[after].previous = before
        else:
            self.tail = before
        self.count -= 1
        self.quantity -= row[0].quantity
        del self.slots[row[0].order_id]
        self.roots[slot] = None
        self.links[slot].next = self.free_head
        self.free_head = slot
        return row

    cpdef add_order(self, object order, object metadata=None):
        cdef Py_ssize_t slot
        # The episode is admitted before agent construction. These assertions
        # detect a violated implementation invariant, not a per-operation scan.
        if order.is_hidden or order.insert_by_id or order.is_price_to_comply or order.is_post_only or order.tag is not None:
            raise ValueError("plain closed book ownership invariant violated")
        if order.order_id in self.slots:
            raise ValueError("duplicate closed book order ID")
        slot = self.allocate((order, metadata or {}))
        self.links[slot].previous, self.links[slot].next = self.tail, -1
        if self.tail >= 0:
            self.links[self.tail].next = slot
        else:
            self.head = slot
        self.tail = slot
        self.count += 1
        self.slots[order.order_id] = slot
        self.quantity += order.quantity

    cpdef peek(self):
        if self.head < 0:
            raise ValueError("Can't peek at LimitOrder in PriceLevel as it contains no orders")
        return self.roots[self.head]

    cpdef pop(self):
        if self.head < 0:
            raise ValueError("Can't pop LimitOrder from PriceLevel as it contains no orders")
        return self.detach(self.head)

    cpdef remove_order(self, object identifier):
        cdef object slot = self.slots.get(identifier)
        if slot is None:
            return None
        return self.detach(slot)

    cpdef decrease_order_quantity(self, object identifier, object amount):
        cdef Py_ssize_t slot = self.slots[identifier]
        cdef object order = self.roots[slot][0]
        order.quantity -= amount
        self.quantity -= amount

    cpdef update_order_quantity(self, object identifier, object new_quantity):
        cdef object slot_value, row, old
        cdef Py_ssize_t slot
        if new_quantity == 0:
            return False
        slot_value = self.slots.get(identifier)
        if slot_value is None:
            return False
        slot = slot_value
        row = self.roots[slot]
        old = row[0].quantity
        if new_quantity <= old:
            row[0].quantity = new_quantity
            self.quantity += new_quantity - old
        else:
            row = self.detach(slot)
            row[0].quantity = new_quantity
            self.add_order(row[0], row[1])
        return True

    cpdef snapshot(self):
        cdef Py_ssize_t slot = self.head
        cdef list rows = []
        while slot >= 0:
            rows.append(self.roots[slot])
            slot = self.links[slot].next
        return rows

    @property
    def visible_orders(self):
        # The fixed strategies never read this; live L3 returns order quantities
        # through this snapshot without exposing the native queue topology.
        return self.snapshot()

    @property
    def hidden_orders(self):
        return []

    @property
    def total_quantity(self):
        return self.quantity

    @property
    def is_empty(self):
        return self.count == 0

    cpdef order_is_match(self, object order):
        if order.side == self.side:
            raise ValueError("Attempted to compare order on wrong side of book")
        return ((order.side.is_bid() and order.limit_price >= self.price)
                or (order.side.is_ask() and order.limit_price <= self.price)) and not (order.is_post_only and self.quantity == 0)

    cpdef order_has_better_price(self, object order):
        if order.side != self.side:
            raise ValueError("Attempted to compare order on wrong side of book")
        return (order.side.is_bid() and order.limit_price > self.price) or (order.side.is_ask() and order.limit_price < self.price)

    cpdef order_has_worse_price(self, object order):
        if order.side != self.side:
            raise ValueError("Attempted to compare order on wrong side of book")
        return (order.side.is_bid() and order.limit_price < self.price) or (order.side.is_ask() and order.limit_price > self.price)

    cpdef order_has_equal_price(self, object order):
        if order.side != self.side:
            raise ValueError("Attempted to compare order on wrong side of book")
        return order.limit_price == self.price

    def __len__(self):
        return self.count


cdef class NativeSide:
    cdef list levels, keys
    cdef dict by_price
    cdef bint is_bid

    def __init__(self, is_bid):
        self.levels, self.keys, self.by_price = [], [], {}
        self.is_bid = is_bid

    cpdef add_at_price(self, object order, object metadata=None):
        cdef object level = self.by_price.get(order.limit_price)
        cdef object key
        cdef Py_ssize_t position
        if level is not None:
            level.add_order(order, metadata)
            return
        level = NativeLevel([(order, metadata or {})])
        key = -order.limit_price if self.is_bid else order.limit_price
        position = bisect_left(self.keys, key)
        self.keys.insert(position, key)
        self.levels.insert(position, level)
        self.by_price[order.limit_price] = level

    cpdef find_level(self, object order):
        return self.by_price.get(order.limit_price)

    cpdef remove_level(self, object level):
        cdef object key = -level.price if self.is_bid else level.price
        cdef Py_ssize_t position = bisect_left(self.keys, key)
        if position >= len(self.levels) or self.levels[position] is not level:
            raise ValueError("closed book price index invariant violated")
        del self.levels[position]
        del self.keys[position]
        del self.by_price[level.price]

    def __getitem__(self, index):
        return self.levels[index]

    def __delitem__(self, index):
        cdef object level = self.levels[index]
        del self.by_price[level.price]
        del self.levels[index]
        del self.keys[index]

    def __len__(self):
        return len(self.levels)

    def __iter__(self):
        return iter(self.levels)

    cpdef snapshot(self):
        return list(self.levels)
