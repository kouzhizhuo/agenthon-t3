"""One episode admission before agent creation; no hot-loop source guards."""
try:
    from closed_book_store import NativeSide, NativeLevel
except ImportError:
    NativeSide = NativeLevel = None

ACTIVE = False
EPISODES = 0


def begin_episode(scenario):
    global ACTIVE, EPISODES
    # Validated JSON plus frozen build_config maps these four constructors to
    # exact LimitOrders with default flags/tag and unique monotonic IDs.
    types = {"NoiseTrader", "MarketMaker", "ValueTrader", "MomentumTrader"}
    ACTIVE = (NativeSide is not None and type(scenario) is dict
              and type(scenario.get("agent_configs")) is list
              and all(type(item) is dict and item.get("agent_type") in types
                      and type(item.get("count")) is int for item in scenario["agent_configs"]))
    EPISODES += 1
    return ACTIVE


def side(is_bid):
    return NativeSide(is_bid) if ACTIVE else []


def indexed_levels(book, order):
    if type(book) is NativeSide:
        level = book.find_level(order)
        return [] if level is None else [(None, level)]
    return enumerate(book)


def remove_level(book, index, level):
    if type(book) is NativeSide:
        return book.remove_level(level)
    del book[index]


def enter_at_price(book, order, metadata):
    if type(book) is NativeSide:
        book.add_at_price(order, metadata)
        return True
    return False


def decrease(level, order, amount):
    if type(level) is NativeLevel:
        level.decrease_order_quantity(order.order_id, amount)
    else:
        order.quantity -= amount
